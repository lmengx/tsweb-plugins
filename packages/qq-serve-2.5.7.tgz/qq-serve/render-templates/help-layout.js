const themes = {
  space: ['#0b1426', '#14233b', '#e9f0ff', '#a0b0cf', '#9cc4ff', '#293b58', 18],
  pixel: ['#222c32', '#303e3e', '#f6efd9', '#bbc7b8', '#f1d496', '#4b5d50', 0],
  cream: ['#fcf3e8', '#fffaf3', '#4a3930', '#80695b', '#96563b', '#e3d2bd', 24],
}
const xml = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[c])
const wrap = (v, max) => { const out = []; let line = '', size = 0; for (const c of String(v)) { const n = /[^\x00-\xff]/.test(c) ? 2 : 1; if (size + n > max) { out.push(line); line = ''; size = 0 } line += c; size += n } if (line) out.push(line); return out }
export function renderHelpPages(document, theme = 'pixel') {
  const [paper, panel, ink, muted, accent, rule, radius] = themes[theme] || themes.pixel
  const text = (x, y, value, size = 22, color = ink, weight = 400) => `<text x="${x}" y="${y}" font-size="${size}" fill="${color}" font-weight="${weight}">${xml(value)}</text>`
  // Repeat section headings across page breaks; no command or description is truncated.
  const chunks = []; let chunk = [], used = 0
  for (const section of document.sections) for (const item of section.items) {
    const lines = wrap(item.desc, 56), commands = wrap(item.cmd, 54)
    const height = 22 + commands.length * 30 + lines.length * 25
    const heading = chunk.at(-1)?.title !== section.title
    if (used + height + (heading ? 55 : 0) > 1160 && chunk.length) { chunks.push(chunk); chunk = []; used = 0 }
    const newSection = chunk.at(-1)?.title !== section.title
    chunk.push({ title: section.title, item, lines, commands, height, heading: newSection }); used += height + (newSection ? 55 : 0)
  }
  if (chunk.length || !chunks.length) chunks.push(chunk)
  return chunks.map((rows, index) => {
    const height = 255 + rows.reduce((n, r) => n + r.height + (r.heading ? 55 : 0), 0)
    let y = 177, body = ''
    for (const row of rows) {
      if (row.heading) { body += text(48, y + 30, row.title, 24, accent, 700); y += 55 }
      body += `<rect x="32" y="${y - 3}" width="756" height="${row.height - 8}" rx="${radius}" fill="${panel}"/>`
      row.commands.forEach((line, i) => { body += text(50, y + 28 + i * 30, line, 25, ink, 700) })
      body += text(724, y + 25, row.item.channel, 17, muted)
      row.lines.forEach((line, i) => { body += text(50, y + 29 + row.commands.length * 30 + i * 25, line, 20, muted) }); y += row.height
    }
    return `<svg xmlns="http://www.w3.org/2000/svg" width="820" height="${height}" viewBox="0 0 820 ${height}"><rect width="820" height="${height}" fill="${paper}"/><g font-family="Microsoft YaHei, Noto Sans CJK SC, sans-serif">${text(40, 45, 'TSWEB / BOT COMMANDS', 16, accent, 700)}${text(40, 96, document.title, 38, ink, 700)}${text(40, 132, document.subtitle, 21, muted)}<path d="M40 153H780" stroke="${rule}"/>${body}<path d="M40 ${y + 10}H780" stroke="${rule}"/>${text(40, y + 42, document.hint, 18, muted)}${text(40, y + 69, `发送 help 查看本卡片 · ${index + 1} / ${chunks.length}`, 16, muted)}</g></svg>`
  })
}
