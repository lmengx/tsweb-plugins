// Public all-server fallback shared by both transports; never publish REST errors.
export function onlinePages({ rows }) {
  const available = rows.filter(row => row.available)
  const total = available.reduce((sum, row) => sum + row.players.length, 0)
  const heading = `全服在线：${total} 人（已查询 ${available.length}/${rows.length} 个服务器）`
  const pages = []; let page = [heading], length = heading.length
  const append = (line, section) => {
    if (length + line.length > 650) {
      pages.push(page); page = [heading]; length = heading.length
      if (section && section !== line) { page.push(section); length += section.length + 1 }
    }
    page.push(line); length += line.length + 1
  }
  for (const row of rows) {
    const section = `【${row.name}】${row.available ? `${row.players.length} 人在线` : '暂不可用，在线人数未知'}`
    append(section)
    if (row.available) {
      if (!row.players.length) append('当前没有在线玩家。', section)
      row.players.forEach((name, i) => append(`${i + 1}. ${name}`, section))
    }
  }
  if (!rows.length) append('暂无启用的服务器。')
  pages.push(page)
  return pages
}
