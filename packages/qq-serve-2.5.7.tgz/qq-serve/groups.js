/** 群发现、启用名单与实时识别信息。只读取本版本自己的 groups.json，不导入任何旧配置。 */
import { mkdir, readFile, rename, writeFile, unlink } from 'node:fs/promises'
import path from 'node:path'
import { randomUUID } from 'node:crypto'

export const GROUP_PREVIEW_TTL_MS = 10 * 60_000
export const GROUP_POLL_MS = 2000
const text = (value, max = 160) => String(value ?? '').replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ').trim().slice(0, max)
const numeric = value => /^\d{5,15}$/.test(String(value ?? ''))
const validOpenid = value => /^[a-zA-Z0-9_-]{1,128}$/.test(String(value ?? ''))
const fail = (status, message) => Object.assign(new Error(message), { status })

export class GroupService {
  constructor({ dataDir, getMode, getAppId, getOnebot, now = () => Date.now(), warn = () => {} }) {
    this.file = path.join(dataDir, 'groups.json')
    this.getMode = getMode
    this.getAppId = getAppId
    this.getOnebot = getOnebot
    this.now = now
    this.warn = warn
    this.numeric = new Map()
    this.official = new Map()
    this.previews = new Map()
    this.revocations = new WeakMap()
    this.identity = null
    this.version = 0
    this.queue = Promise.resolve()
    this.disposed = false
    this.refreshing = null
    this.lastSyncAt = 0
    this.lastAttempt = 0
    this.syncError = ''
  }

  officialKey(openid, appId = this.getAppId()) { return `${appId}:${openid}` }

  async load() {
    let doc
    try { doc = JSON.parse(await readFile(this.file, 'utf8')) }
    catch (error) { if (error.code === 'ENOENT') return; throw fail(500, '群管理数据无法读取，已保留原文件') }
    if (doc?.schema !== 1 || !Array.isArray(doc.numeric) || !Array.isArray(doc.official)) throw fail(500, '群管理数据格式无效，已保留原文件')
    for (const row of doc.numeric) if (row && numeric(row.id)) this.numeric.set(String(row.id), { id: String(row.id), name: text(row.name), count: Number.isSafeInteger(row.count) ? row.count : null, enabled: row.enabled === true, joined: row.joined !== false })
    for (const row of doc.official) if (row && validOpenid(row.id) && /^\d{1,32}$/.test(String(row.appId))) {
      this.official.set(this.officialKey(row.id, row.appId), { id: String(row.id), appId: String(row.appId), enabled: row.enabled === true,
        name: text(row.name), count: Number.isSafeInteger(row.count) ? row.count : null, memo: text(row.memo, 300), owner: text(row.owner),
        joined: row.joined !== false, firstSeenAt: Number(row.firstSeenAt) || 0, joinedAt: Number(row.joinedAt) || 0,
        lastSeenAt: Number(row.lastSeenAt) || 0, infoState: ['available', 'denied', 'error'].includes(row.infoState) ? row.infoState : 'unknown' })
    }
  }

  enqueue(operation) {
    const task = this.queue.then(operation)
    this.queue = task.catch(() => {})
    return task
  }

  async write() {
    await mkdir(path.dirname(this.file), { recursive: true })
    const temporary = `${this.file}.${randomUUID()}.tmp`
    try {
      // 消息预览只在内存保存十分钟，不随群资料写入磁盘。
      const doc = { schema: 1, numeric: [...this.numeric.values()], official: [...this.official.values()] }
      await writeFile(temporary, JSON.stringify(doc, null, 2) + '\n', { mode: 0o600, flag: 'wx' })
      await rename(temporary, this.file)
    } finally { await unlink(temporary).catch(() => {}) }
  }

  changed({ persist = true } = {}) {
    this.version++
    if (!persist || this.disposed || this.saveTimer) return
    this.saveTimer = setTimeout(() => {
      this.saveTimer = null
      void this.enqueue(() => this.write()).catch(() => this.warn('群资料保存失败，请检查数据目录权限'))
    }, 500)
    this.saveTimer.unref?.()
  }

  attachIdentity(engine, mapping) {
    const identity = { engine, mapping }
    this.identity = identity
    return () => { if (this.identity === identity) this.identity = null }
  }

  groupOf(openid) {
    const mapping = this.identity?.mapping
    return mapping?.isConfirmed(openid) ? String(mapping.groupOf(openid) || '') : ''
  }

  revoke(row) {
    row.enabled = false
    // 保存中的授权请求失败时，不得回滚覆盖更晚发生的退群撤权。
    this.revocations.set(row, {})
  }

  allowsNumeric(id) { return this.numeric.get(String(id))?.enabled === true && this.numeric.get(String(id))?.joined !== false }
  allowsOfficial(openid, appId = this.getAppId()) {
    if (!validOpenid(openid) || String(appId) !== String(this.getAppId())) return false
    const row = this.official.get(this.officialKey(openid, appId))
    if (row?.joined === false) return false
    if (this.getMode() === 'hybrid') return this.allowsNumeric(this.groupOf(openid))
    return this.getMode() === 'official' && row?.enabled === true
  }

  observeNumeric(event) {
    if (this.disposed || !numeric(event?.group_id)) return
    const id = String(event.group_id)
    if (!this.numeric.has(id)) {
      this.numeric.set(id, { id, name: text(event.group_name), count: null, enabled: false, joined: true })
      this.changed()
    } else if (this.numeric.get(id).joined === false) {
      this.numeric.get(id).joined = true
      this.changed()
    }
  }

  observeNumericMembership(event, self) {
    if (this.disposed || event?.post_type !== 'notice' || !numeric(event.group_id) || !self || String(event.user_id) !== String(self)) return
    if (!['group_increase', 'group_decrease'].includes(event.notice_type)) return
    this.observeNumeric(event)
    const row = this.numeric.get(String(event.group_id))
    row.joined = event.notice_type === 'group_increase'
    // 重新入群需重新授权，避免已退出的群沿用历史开关。
    this.revoke(row)
    this.changed()
  }

  observeOfficial(openid, { appId = this.getAppId(), joined, joinedAt, content, author, role } = {}) {
    if (this.disposed || !validOpenid(openid) || !/^\d{1,32}$/.test(String(appId))) return
    const key = this.officialKey(openid, appId), now = this.now()
    let row = this.official.get(key)
    if (!row) {
      row = { id: String(openid), appId: String(appId), enabled: false, name: '', count: null, memo: '', owner: '', joined: true,
        firstSeenAt: now, joinedAt: 0, lastSeenAt: now, infoState: 'unknown' }
      this.official.set(key, row)
    }
    row.lastSeenAt = now
    if (joined !== undefined) row.joined = joined === true
    if (joined === false) { this.revoke(row); this.previews.delete(key) }
    if (joinedAt) row.joinedAt = Number(joinedAt) || now
    if (role === 'owner' && author) row.owner = text(author)
    if (content !== undefined) {
      // 识别群不应在控制台泄露用户发来的改密内容。
      const preview = text(String(content).replace(/^(?:\s*<@!?[^>]+>\s*)+/, ''), 240)
        .replace(/^(\/?(?:password|改密码|修改密码))\s+.+$/i, '$1 [已隐藏]')
      this.previews.set(key, { text: preview || '[非文本消息]', author: text(author), at: now })
    }
    this.prunePreviews()
    this.changed()
    return row
  }

  updateOfficialInfo(openid, appId, info, state = 'available') {
    const row = this.official.get(this.officialKey(openid, appId))
    if (!row || this.disposed) return
    row.infoState = state
    if (info && state === 'available') {
      row.name = text(info.group_name)
      row.count = Number.isSafeInteger(info.group_member_num) && info.group_member_num >= 0 ? info.group_member_num : null
      row.memo = text(info.group_finger_memo, 300)
    }
    this.changed()
  }

  prunePreviews() {
    const cutoff = this.now() - GROUP_PREVIEW_TTL_MS
    for (const [key, row] of this.previews) if (row.at <= cutoff) this.previews.delete(key)
  }

  async refreshNumeric({ force = false } = {}) {
    if (this.disposed || this.getMode() === 'official') return
    if (this.refreshing) return this.refreshing
    if (!force && this.lastAttempt && this.now() - this.lastAttempt < 30_000) return
    const adapter = this.getOnebot()
    if (!adapter?.config?.enabled || !adapter.config.endpoint) return
    const generation = adapter.events?.generation, endpoint = adapter.config.endpoint, botQq = adapter.config.botQq
    const current = () => !this.disposed && !adapter.disposed && this.getMode() !== 'official' &&
      this.getOnebot() === adapter && adapter.events?.generation === generation &&
      adapter.config.endpoint === endpoint && adapter.config.botQq === botQq
    this.lastAttempt = this.now()
    this.refreshing = (async () => {
      try {
        const rows = await adapter.client().getGroupList()
        if (!current()) return
        if (!Array.isArray(rows)) throw new Error('群列表格式无效')
        for (const row of this.numeric.values()) row.joined = false
        for (const item of rows) {
          if (!numeric(item?.group_id)) continue
          const id = String(item.group_id), previous = this.numeric.get(id)
          this.numeric.set(id, { id, name: text(item.group_name), count: Number.isSafeInteger(item.member_count) ? item.member_count : null, enabled: previous?.enabled === true, joined: true })
        }
        for (const row of this.numeric.values()) if (!row.joined) this.revoke(row)
        this.lastSyncAt = this.now(); this.syncError = ''; this.changed()
      } catch {
        if (current()) this.syncError = '读取 OneBot 群列表失败，请检查连接和接口权限后重试。'
      } finally { this.refreshing = null }
    })()
    return this.refreshing
  }

  async setEnabled({ mode, id, enabled }) {
    if (this.disposed) throw fail(503, '群管理服务已停用')
    if (mode !== this.getMode()) throw fail(409, '运行模式已变化，请刷新群列表后重试')
    if (typeof enabled !== 'boolean') throw fail(400, 'enabled 必须是布尔值')
    const key = String(id || '')
    if (mode === 'official' ? !validOpenid(key) : !numeric(key)) throw fail(400, '群标识格式无效')
    return this.enqueue(async () => {
      if (this.disposed) throw fail(503, '群管理服务已停用')
      if (mode !== this.getMode()) throw fail(409, '运行模式已变化，请刷新群列表后重试')
      const row = mode === 'official' ? this.official.get(this.officialKey(key)) : this.numeric.get(key)
      if (!row) throw fail(404, '尚未发现这个群，请先刷新群列表或在目标群发送消息')
      if (enabled && row.joined === false) throw fail(409, '机器人已不在该群，无法启用')
      const previous = row.enabled
      const revocation = this.revocations.get(row)
      row.enabled = enabled
      try { await this.write() } catch (error) {
        if (this.revocations.get(row) === revocation) row.enabled = previous
        throw fail(500, '群授权保存失败，请重试')
      }
      this.changed({ persist: false })
      return this.snapshot()
    })
  }

  async deleteMappings({ id, all = false }) {
    const identity = this.identity
    if (!identity) throw fail(503, '自动映射服务尚未就绪')
    if (!all && !validOpenid(id)) throw fail(400, '映射标识格式无效')
    // 先让旧的等待任务失效，再清除候选、已确认关系以及匹配缓存。
    identity.engine.forgetMappings(all ? null : String(id))
    await identity.mapping.remove(all ? null : String(id))
    this.changed({ persist: false })
    return this.snapshot()
  }

  snapshot() {
    this.prunePreviews()
    const mode = this.getMode(), appId = String(this.getAppId())
    const mappings = this.identity?.engine.discoveredMappings() || []
    return { mode, pollMs: GROUP_POLL_MS, previewTtlMs: GROUP_PREVIEW_TTL_MS, version: this.version,
      lastSyncAt: this.lastSyncAt, syncing: Boolean(this.refreshing), syncError: this.syncError,
      groups: mode === 'official' ? [...this.official.entries()].filter(([, row]) => row.appId === appId).map(([key, row]) => ({ ...row, preview: this.previews.get(key) || null }))
        : [...this.numeric.values()].map(row => ({ ...row, mappings: mappings.filter(item => item.groupId === row.id) })),
      mappings }
  }

  async dispose() {
    this.disposed = true
    clearTimeout(this.saveTimer)
    this.previews.clear()
    await this.enqueue(() => this.write())
  }
}
