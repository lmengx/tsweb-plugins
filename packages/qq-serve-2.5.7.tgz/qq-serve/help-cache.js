import fs from 'node:fs/promises'
import path from 'node:path'
import { createHash, randomUUID } from 'node:crypto'
const digest = value => createHash('sha256').update(value).digest('hex')
const caches = new WeakMap()
// Cordis exposes a different service proxy to each consumer context. The engine's
// lifetime signal is stable across those proxies and changes on every reload.
const cacheOwner = renderer => renderer.abort?.signal || renderer
const valid = image => Buffer.isBuffer(image) && image.length >= 24 && image.length <= 8 * 1024 * 1024 && image.subarray(0, 8).toString('hex') === '89504e470d0a1a0a'
export class HelpImageCache {
  constructor({ directory, render }) { this.directory = directory; this.render = render; this.memory = new Map(); this.pending = new Map(); this.abort = new AbortController() }
  async get(document, theme, { signal } = {}) {
    signal?.throwIfAborted(); this.abort.signal.throwIfAborted()
    const key = digest(JSON.stringify({ version: 1, theme, document }))
    let task = this.pending.get(key)
    if (!task) {
      task = this.load(key, document, theme).finally(() => this.pending.delete(key))
      this.pending.set(key, task)
    }
    if (!signal) return task
    return new Promise((resolve, reject) => {
      const cancel = () => reject(signal.reason || new Error('帮助请求已取消'))
      signal.addEventListener('abort', cancel, { once: true })
      task.then(resolve, reject).finally(() => signal.removeEventListener('abort', cancel))
      if (signal.aborted) cancel()
    })
  }
  async load(key, document, theme) {
    const live = () => this.abort.signal.throwIfAborted()
    live()
    if (this.memory.has(key)) return { images: this.memory.get(key) }
    const file = path.join(this.directory, `tsweb-help-${key}.json`)
    let images
    try {
      const info = await fs.stat(file)
      if (info.size > 45 * 1024 * 1024) throw new Error('帮助缓存过大')
      const record = JSON.parse(await fs.readFile(file, 'utf8'))
      if (record.key !== key || !Array.isArray(record.images) || !record.images.length || record.images.length > 20) throw new Error('帮助缓存格式无效')
      images = record.images.map(item => { const image = Buffer.from(item.data, 'base64'); if (!valid(image) || digest(image) !== item.sha256) throw new Error('帮助缓存已损坏'); return image })
      if (images.reduce((n, image) => n + image.length, 0) > 32 * 1024 * 1024) throw new Error('帮助缓存过大')
    } catch { images = undefined /* Missing/corrupt/unsupported disk cache is regenerated. */ }
    live()
    if (!images) {
      const signal = AbortSignal.any([this.abort.signal, AbortSignal.timeout(15000)])
      const result = await new Promise((resolve, reject) => {
        const cancel = () => reject(signal.reason)
        signal.addEventListener('abort', cancel, { once: true })
        Promise.resolve().then(() => this.render(document, theme, signal)).then(resolve, reject).finally(() => signal.removeEventListener('abort', cancel))
      })
      live(); signal.throwIfAborted()
      images = result?.images
      if (!Array.isArray(images) || !images.length || images.length > 20 || images.some(image => !valid(image)) || images.reduce((n, image) => n + image.length, 0) > 32 * 1024 * 1024) throw new Error('帮助图片无效')
      let temporary
      try {
        await fs.mkdir(this.directory, { recursive: true }); live()
        temporary = file + '.' + randomUUID() + '.tmp'
        await fs.writeFile(temporary, JSON.stringify({ key, images: images.map(image => ({ data: image.toString('base64'), sha256: digest(image) })) }))
        live(); await fs.rename(temporary, file)
        await this.prune()
      } catch { /* Disk failure must not prevent the freshly rendered image. */ }
      finally { if (temporary) await fs.rm(temporary, { force: true }).catch(() => {}) }
    }
    live()
    this.memory.set(key, images)
    while (this.memory.size > 8) this.memory.delete(this.memory.keys().next().value)
    return { images }
  }
  async prune() {
    const entries = await fs.readdir(this.directory)
    const files = await Promise.all(entries.filter(name => /^tsweb-help-[a-f0-9]{64}\.json$/.test(name)).map(async name => ({ name, time: (await fs.stat(path.join(this.directory, name))).mtimeMs })))
    files.sort((a, b) => b.time - a.time)
    await Promise.all(files.filter((file, i) => i >= 16 || file.time < Date.now() - 7 * 86400000).map(file => fs.rm(path.join(this.directory, file.name), { force: true })))
  }
  dispose() { this.abort.abort(new Error('帮助渲染已停用')); this.memory.clear(); this.pending.clear() }
}
export function registerHelpCache(renderer, directory) {
  const cache = new HelpImageCache({ directory, render: (document, theme, signal) => renderer.render('help', { document, theme, signal }) })
  caches.set(cacheOwner(renderer), cache)
  return () => { cache.dispose(); if (caches.get(cacheOwner(renderer)) === cache) caches.delete(cacheOwner(renderer)) }
}
export async function renderHelp(renderer, document, options = {}) {
  if (!renderer?.config?.enabled) throw new Error('图片渲染未启用')
  const cache = caches.get(cacheOwner(renderer))
  if (!cache) throw new Error('帮助图片模板未就绪')
  return cache.get(document, renderer.config.theme || 'pixel', options)
}
