/**
 * 身份闸门：给"需要真实 QQ 号"的命令用（注册 / 绑定 / 绑定转移）
 *
 * 规则（按需求）：
 *   1. 已绑定对象直接短路：openid 已登记过 → 直接取用，**不参与竞争、也不消耗 OneBot 观测**。
 *   2. 已绑定 QQ 不参与竞争：候选里凡 qq 已在台账绑定的，一律排除，
 *      这样"别人同一秒发的同一句"不会把自己的对应搅成歧义。
 *   3. 竞争（同群同文本同窗口多个候选）→ 返回 ambiguous，调用方**静默失败**（不回复）。
 *   4. 对应成功 → 调用方把信息写进表单（qq / openid / 群 / 角色名）。
 */
export const IDENTIFY_STATE = Object.freeze({
  /** openid 已登记，直接可用 */
  KNOWN: 'known',
  /** 通过跨通道对应确认了 QQ */
  VERIFIED: 'verified',
  /** 竞争失败（多条候选），调用方应静默 */
  AMBIGUOUS: 'ambiguous',
  /** 框架机器人没送来 / 没连通 */
  NONE: 'none',
})

/**
 * @param {object} options
 * @param {object} options.engine    CorrespondenceEngine
 * @param {object} options.subjects  SubjectStore
 * @param {() => object|null} options.getLedger 返回 qq-bind 的 Ledger
 * @param {(line:string)=>void} [options.log]
 */
export function createIdentityGate({ engine, subjects, getLedger, log = () => {} }) {
  /** 台账里已绑定 QQ 的集合（第二档候选：不抢占未绑定者的唯一性，但仍可被识别） */
  function boundQqSet() {
    const set = new Set()
    const ledger = getLedger?.()
    if (!ledger) return set
    try {
      for (const row of ledger.list?.({ pageSize: 100000 })?.rows || []) {
        if (row.qq) set.add(String(row.qq))
      }
    } catch {
      /* 台账不可读时不做排除（宁可按原样判定） */
    }
    return set
  }

  /** 已经"QQ + openid"都齐的主体所属 QQ（完全绑定）：硬排除，不参与任何竞争 */
  function linkedQqSet() {
    const set = new Set()
    try {
      for (const row of subjects.list?.({ platform: 'qq-official' }) || []) {
        if (row.qq) set.add(String(row.qq))
      }
    } catch {
      /* 读不到就不排除 */
    }
    return set
  }

  /** 已登记的主体行（openid + 群精确匹配） */
  function knownRow(read) {
    try {
      return subjects.get({
        platform: read.platform,
        botId: read.botId,
        sceneKey: read.sceneKey,
        subject: read.subject,
      }) || null
    } catch {
      return null
    }
  }

  /**
   * 解析一条官方消息的发送者。
   *
   * @param {object} read MessageRead
   * @param {{waitMs?:number}} [options]
   * @returns {Promise<{state:string, qq:string, username:string, row:object|null, matched:object|null, read:object}>}
   */
  async function identify(read, options = {}) {
    const waitMs = Number(options.waitMs) > 0 ? Number(options.waitMs) : 2000
    const base = { read, qq: '', username: '', row: null, matched: null }

    // ── 1. 已登记（openid）→ 短路，不参与竞争 ─────────────────────────────
    try { await subjects.load() } catch { /* 读失败按未登记处理 */ }
    const row = knownRow(read)
    const ledger = getLedger?.()
    if (row?.qq) {
      return { ...base, state: IDENTIFY_STATE.KNOWN, row, qq: String(row.qq), username: row.username || '' }
    }

    // ── 2. 跨通道对应（两档：完全绑定的硬排除；台账已绑 QQ 只降档，不被排除）───
    const matched = await engine.waitForMatch(read, {
      timeoutMs: waitMs,
      excludeQq: linkedQqSet(),
      boundQq: boundQqSet(),
    })
    if (matched?.status === 'matched') {
      const qq = String(matched.observation.qq)
      const rec = ledger?.getByQq?.(qq) || null
      return {
        ...base,
        state: IDENTIFY_STATE.VERIFIED,
        qq,
        username: rec?.username || '',
        matched,
      }
    }
    if (matched?.status === 'ambiguous') {
      log(`身份竞争失败（多条候选）：${matched.candidates?.length || 0} 条，静默不处理`)
      return { ...base, state: IDENTIFY_STATE.AMBIGUOUS, matched }
    }
    return { ...base, state: IDENTIFY_STATE.NONE, matched }
  }

  /**
   * 写表单：把 qq / openid / 群 / 角色名一次写全。
   * 台账侧补 qq（若该角色原本没有），主体登记侧补 openid → qq/角色。
   *
   * @param {object} read
   * @param {{qq:string, username:string, proof?:string}} info
   */
  async function writeForm(read, info, options = {}) {
    const result = { ledger: false, identity: false, subjects: false, error: '' }
    const active = () => options.isActive?.() !== false
    if (!active()) return result
    const qq = String(info.qq || '')
    const username = String(info.username || '')
    const ledger = getLedger?.()
    try {
      if (ledger && qq && username) {
        // 该角色原本没绑定 qq 时补上；已有别的 qq 则不动（不覆盖既有绑定）
        const rec = ledger.getByUsername?.(username)
        if (rec && !rec.qq) {
          await ledger.rebind({ username, newQq: qq })
          result.ledger = true
        }
      }
    } catch (error) {
      result.error = `台账写入失败：${error?.message || error}`
    }
    // 台账侧合并官方身份：让面板记录变成"QQ + openid 齐全"（complete）
    if (!active()) return result
    try {
      if (ledger && read?.botId && read?.subject) {
        const rec = ledger.getByUsername?.(username)
        if (rec && !rec.identity && typeof ledger.attachIdentity === 'function') {
          await ledger.attachIdentity({
            username,
            identity: { provider: 'qq-official', appId: read.botId, subject: read.subject },
          })
          result.identity = true
        }
      }
    } catch (error) {
      result.error = `${result.error} 官方身份挂接失败：${error?.message || error}`.trim()
    }
    try {
      await subjects.load()
      if (!active()) return result
      await subjects.bind({
        platform: read.platform,
        botId: read.botId,
        sceneKey: read.sceneKey,
        subject: read.subject,
        qq,
        username: username || read.subject.slice(0, 12),
        proof: String(info.proof || 'verified-command'),
        note: `命令期身份确认：官方消息 ${read.messageId}`,
      })
      result.subjects = true
    } catch (error) {
      result.error = `${result.error} 主体登记写入失败：${error?.message || error}`.trim()
    }
    return result
  }

  /**
   * 静默转移（菜单触发）：判定"已绑定 QQ 但还没有 openid 接入官方机器人"的人，命中就补绑 openid。
   *   - 完全绑定（openid 已有）→ 短路，不参与竞争
   *   - 只排除"已完全绑定"的 QQ；已绑定但缺 openid 的 QQ 正常参与（正是目标人群）
   *   - 竞争 → 静默失败，不写任何东西、不回复
   */
  async function silentLinkOpenid(read, options = {}) {
    try { await subjects.load() } catch { /* 忽略 */ }
    if (options.isActive?.() === false) return { linked: false, reason: 'cancelled' }
    const existing = knownRow(read)
    if (existing?.qq) {
      // 已登记 openid：不参与竞争；但台账记录若还没挂官方身份，这里补齐（面板显示为 complete）
      try {
        const rec = getLedger?.()?.getByUsername?.(existing.username)
        if (rec && !rec.identity) {
          await writeForm(read, { qq: existing.qq, username: existing.username, proof: 'silent-menu-link' }, options)
          log(`已为 ${existing.username} 补挂官方身份（此前只有数字 QQ）`)
        }
      } catch (error) {
        log(`补挂官方身份失败：${error?.message || error}`)
      }
      return { linked: false, reason: 'already-linked' }
    }
    const matched = await engine.waitForMatch(read, {
      timeoutMs: Number(options.waitMs) > 0 ? Number(options.waitMs) : 1500,
      excludeQq: linkedQqSet(),
    })
    if (options.isActive?.() === false) return { linked: false, reason: 'cancelled' }
    if (matched?.status !== 'matched') {
      return { linked: false, reason: matched?.status || 'no-match' }
    }
    const qq = String(matched.observation.qq)
    const ledger = getLedger?.()
    const rec = ledger?.getByQq?.(qq) || null
    if (!rec?.username) return { linked: false, reason: 'qq-not-bound' }
    const written = await writeForm(read, { qq, username: rec.username, proof: 'silent-menu-link' }, options)
    if (written.subjects) log(`已静默补写 openid 关联：官方 ${read.subject.slice(0, 8)}… ↔ QQ ${qq}（角色 ${rec.username}）`)
    return { linked: written.subjects, reason: written.subjects ? 'ok' : written.error || 'write-failed' }
  }

  return { identify, writeForm, silentLinkOpenid, boundQqSet, knownRow }
}
