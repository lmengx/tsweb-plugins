import fs from 'node:fs/promises'
import path from 'node:path'
import { randomUUID, createHash } from 'node:crypto'
const revision = new URL(import.meta.url).search
const { builtinCommands, parseCommand } = await import(`./commands.js${revision}`)
const { ui, normalizeReply, outbound, richPermissionRejected } = await import(`./messages.js${revision}`)
const { InteractionStore, interactionMessage } = await import(`./interactions.js${revision}`)

const defaults = () => ({ appId: '', appSecret: '', autoConnect: false, replyEnabled: true, messagePreview: false, welcomeEnabled: false,
  welcomeText: '欢迎加入本群！发送“菜单”查看功能。', autoApprove: false,
  responseMode: 'text', keyboardMode: 'none', markdownTemplateId: '', markdownTemplateKey: 'content', keyboardTemplateId: '', fallbackToText: true })
const fail = (status, message) => Object.assign(new Error(message), { status })
const shortId = value => { const s = String(value || ''); return s.length > 12 ? `${s.slice(0, 6)}...${s.slice(-4)}` : s }
const clean = value => String(value ?? '').replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ')
const fingerprint = value => value ? createHash('sha256').update(String(value)).digest('hex').slice(0, 12) : undefined

export class BotManager {
  constructor({ dataDir, createBot, writeConfig, renderReply, now = () => Date.now() }) {
    this.dataDir = dataDir
    this.instanceId = randomUUID().slice(0, 8)
    this.file = path.join(dataDir, 'official-config.json')
    this.createBot = createBot
    this.renderReply = renderReply
    this.writeConfig = writeConfig || (async (file, content) => {
      const temporary = `${file}.${randomUUID()}.tmp`
      try {
        await fs.writeFile(temporary, content, { mode: 0o600, flag: 'wx' })
        await fs.rename(temporary, file)
      } finally { await fs.unlink(temporary).catch(() => {}) }
    })
    this.now = now
    this.config = defaults()
    this.revision = randomUUID()
    this.state = 'unconfigured'
    this.current = null
    this.disposed = false
    this.queue = Promise.resolve()
    this.entries = []
    this.secretHistory = new Set()
    this.commands = new Map()
    this.actions = new Map()
    this.commandList = new Set()
    this.counts = { messagesReceived: 0, fullGroupMessagesReceived: 0, repliesSent: 0, reconnects: 0, interactionsReceived: 0, interactionsHandled: 0, interactionsFailed: 0, interactionsSuppressed: 0, richFallbacks: 0 }
    this.lastError = ''
    for (const command of builtinCommands) this.registerCommand(command)
  }

  async load() {
    await fs.mkdir(this.dataDir, { recursive: true })
    try {
      const content = await fs.readFile(this.file, 'utf8')
      if (content.length > 16384) throw new Error('配置文件过大')
      const data = JSON.parse(content)
      this.config = this.validate(data.config, defaults())
      if (typeof data.revision !== 'string' || !data.revision) throw new Error('配置版本无效')
      this.revision = data.revision
    } catch (error) {
      if (error.code !== 'ENOENT') throw fail(500, 'QQ 机器人配置无法读取；已保留原文件，请检查配置后重试')
    }
    if (this.config.appSecret) this.secretHistory.add(this.config.appSecret)
    this.state = this.config.appId && this.config.appSecret ? 'stopped' : 'unconfigured'
  }

  validate(patch, base) {
    if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw fail(400, '配置格式无效')
    const next = { ...base }
    for (const key of ['autoConnect', 'replyEnabled', 'messagePreview', 'fallbackToText', 'welcomeEnabled', 'autoApprove']) {
      if (key in patch) {
        if (typeof patch[key] !== 'boolean') throw fail(400, `${key} 必须是布尔值`)
        next[key] = patch[key]
      }
    }
    for (const key of ['welcomeText']) {
      if (key in patch) {
        if (typeof patch[key] !== 'string' || patch[key].length > 500) throw fail(400, '欢迎语格式无效')
        next[key] = patch[key]
      }
    }
    for (const [key, values] of Object.entries({ responseMode: ['text', 'markdown', 'template'], keyboardMode: ['none', 'custom', 'template'] })) {
      if (key in patch) {
        if (!values.includes(patch[key])) throw fail(400, `${key} 选项无效`)
        next[key] = patch[key]
      }
    }
    for (const key of ['markdownTemplateId', 'markdownTemplateKey', 'keyboardTemplateId']) {
      if (!(key in patch)) continue
      if (typeof patch[key] !== 'string' || !/^[a-zA-Z0-9_.-]{0,128}$/.test(patch[key])) throw fail(400, `${key} 格式无效`)
      next[key] = patch[key]
    }
    if (next.responseMode === 'template' && (!next.markdownTemplateId || !next.markdownTemplateKey)) throw fail(400, '模板 Markdown 需要模板 ID 和正文参数名')
    if (next.keyboardMode !== 'none' && next.responseMode === 'text') throw fail(400, '消息按钮需要 Markdown 模式')
    if (next.keyboardMode === 'template' && !next.keyboardTemplateId) throw fail(400, '模板按钮需要按钮模板 ID')
    for (const key of ['appId', 'appSecret']) {
      if (key in patch) {
        if (typeof patch[key] !== 'string') throw fail(400, `${key} 必须是文本`)
        next[key] = patch[key].trim()
      }
    }
    if (next.appId && !/^\d{1,32}$/.test(next.appId)) throw fail(400, 'AppID 只能包含数字，最多 32 位')
    if (next.appSecret.length > 256 || /[\u0000-\u0020\u007f]/.test(next.appSecret)) throw fail(400, 'AppSecret 格式无效')
    if (next.autoConnect && (!next.appId || !next.appSecret)) throw fail(400, '自动连接需要填写 AppID 和 AppSecret')
    return next
  }

  publicConfig() {
    const { appSecret, ...config } = this.config
    return { ...config, hasSecret: Boolean(appSecret), revision: this.revision }
  }

  async applyCanonicalConfig(config) {
    /**
     * 空 canonical 表示"模式域没有统一凭据"，不等于"要求把官方凭据清空"。
     *
     * 旧实现无条件 validate({appId:'', appSecret:''})，于是只在「官方机器人」页保存过凭据的
     * 部署，只要发生一次 applyMode（切模式、保存模式配置、插件重载）就会被抹成未配置并断开连接，
     * 表现为"配好的机器人自己变回等待配置"，而且磁盘上旧 official-config.json 还留着凭据，
     * 每次启动都重复一次。真要清空必须走 clearSecret（它会把 canonical 一并写空）。
     */
    const appId = String(config?.appId ?? '').trim()
    const appSecret = String(config?.appSecret ?? '').trim()
    if (!appId && !appSecret) return this.publicConfig()
    const next = this.validate({ appId, appSecret }, this.config)
    const changed = next.appId !== this.config.appId || next.appSecret !== this.config.appSecret
    if (!changed) return this.publicConfig()
    const running = Boolean(this.current)
    if (running) await this.stopInternal('统一 QQ 配置更新')
    this.config = next
    this.state = next.appId && next.appSecret ? 'stopped' : 'unconfigured'
    if (running && next.appId && next.appSecret) await this.startInternal()
    return this.publicConfig()
  }

  safeError(error) {
    let text = clean(error?.message || error || '未知错误')
    for (const secret of this.secretHistory) if (secret) text = text.split(secret).join('[已隐藏]')
    return text.replace(/(\/v2\/(?:users|groups)\/)([^/\s\]]+)/g, (_match, prefix, id) => prefix + shortId(id))
      .replace(/(?:QQBot|Bearer)\s+[^\s"']+/gi, '[鉴权信息已隐藏]')
      .replace(/("?(?:access_token|clientSecret|appSecret)"?\s*[:=]\s*")([^"]+)(")/gi, '$1[已隐藏]$3').slice(0, 500)
  }

  log(type, text, details = {}) {
    this.entries.push({ id: randomUUID(), at: new Date(this.now()).toISOString(), instance: this.instanceId, processId: process.pid, type,
      text: this.safeError(text), ...details })
    if (this.entries.length > 200) this.entries.shift()
  }
  logs() { return this.entries.map(entry => ({ ...entry })) }
  status() {
    return { state: this.state, appId: this.config.appId, configured: Boolean(this.config.appId && this.config.appSecret),
      connected: this.state === 'connected', startedAt: this.startedAt || null,
      runtime: { instance: this.instanceId, processId: process.pid },
      uptimeSeconds: this.current ? Math.max(0, Math.floor((this.now() - this.current.createdAt) / 1000)) : 0,
      ...this.counts, lastError: this.lastError,
      interaction: { responseMode: this.config.responseMode, keyboardMode: this.config.keyboardMode, callbackTtlSeconds: 300 },
      commands: [...this.commandList].map(({ name, description }) => ({ name, description })) }
  }

  exclusive(operation) {
    const task = this.queue.then(() => {
      if (this.disposed) throw fail(503, '插件已停用')
      return operation()
    })
    this.queue = task.catch(() => {})
    return task
  }

  saveConfig(body) {
    return this.exclusive(async () => {
      if (!body || typeof body !== 'object') throw fail(400, '缺少配置')
      if ('clearSecret' in body && typeof body.clearSecret !== 'boolean') throw fail(400, 'clearSecret 必须是布尔值')
      if (body.expectedRevision !== this.revision) throw fail(409, '配置已被其他操作更新，请重新读取后合并')
      const patch = body.config
      if (patch?.appSecret === '') throw fail(400, '留空保留密钥时请省略 appSecret 字段；清除密钥请使用 clearSecret')
      if (patch?.appId && patch.appId !== this.config.appId && this.config.appSecret && !patch.appSecret && !body.clearSecret) {
        throw fail(400, '更换 AppID 时必须同时填写对应的新 AppSecret')
      }
      const candidate = this.validate(body.clearSecret ? { ...patch, appSecret: '', autoConnect: false } : patch, this.config)
      const revision = randomUUID()
      await this.writeConfig(this.file, JSON.stringify({ revision, config: candidate }, null, 2) + '\n')
      if (this.disposed) return this.publicConfig()
      const running = Boolean(this.current)
      this.config = candidate
      if (!candidate.messagePreview) this.entries = this.entries.map(({ preview, ...entry }) => entry)
      this.revision = revision
      if (candidate.appSecret) this.secretHistory.add(candidate.appSecret)
      this.log('config', '机器人配置已保存')
      if (running) await this.stopInternal('配置更新')
      this.state = candidate.appId && candidate.appSecret ? 'stopped' : 'unconfigured'
      if (candidate.appId && candidate.appSecret && (running || candidate.autoConnect)) await this.startInternal()
      return this.publicConfig()
    })
  }

  start() { return this.exclusive(() => this.startInternal()) }
  async startInternal() {
    if (this.current) return this.status()
    if (!this.config.appId || !this.config.appSecret) throw fail(400, '请先保存自己的 AppID 和 AppSecret')
    const bot = await this.createBot({ appId: this.config.appId, appSecret: this.config.appSecret, onDiagnostic: entry => {
      if (!this.disposed && this.current?.bot === bot) this.log('transport', `${entry.phase} ${entry.route}${entry.httpStatus ? ` HTTP ${entry.httpStatus}` : ''}${entry.durationMs !== undefined ? ` ${entry.durationMs}ms` : ''}`, entry)
    } })
    if (this.disposed) { bot.stop(); throw fail(503, '插件已停用') }
    const session = { bot, abort: new AbortController(), createdAt: this.now(), handlers: [], seen: new Map(),
      recent: new Map(), pending: new Set(), task: null, interactionFlights: new Set(),
      interactions: new InteractionStore(this.now, name => this.actions.get(name) || this.commands.get(name)) }
    this.current = session
    this.state = 'connecting'
    this.startedAt = new Date(session.createdAt).toISOString()
    this.lastError = ''
    const active = () => !this.disposed && this.current === session && !session.abort.signal.aborted
    const on = (name, handler) => { bot.on(name, handler); session.handlers.push([name, handler]) }
    on('ready', () => {
      if (!active()) return
      this.state = 'connected'; this.lastError = ''; this.log('ready', '机器人已上线，正在接收群消息与单聊')
    })
    on('resumed', () => {
      if (!active()) return
      this.state = 'connected'; this.lastError = ''; this.counts.reconnects++; this.log('ready', '连接已恢复')
    })
    on('disconnected', event => {
      if (!active()) return
      this.state = event?.willReconnect ? 'reconnecting' : 'error'
      this.log('disconnect', event?.willReconnect ? '连接断开，正在重连' : '连接已断开', { code: event?.code })
    })
    on('error', error => {
      if (!active()) return
      this.lastError = this.safeError(error); this.log('error', this.lastError)
    })
    on('rawEvent', event => {
      if (active()) this.log('event', `平台事件：${clean(event?.eventType).slice(0, 80)}`)
      if (active()) this.captureGroupEvent(session, event)
      if (active() && event?.eventType === 'GROUP_ADD_ROBOT') void this.handleGroupAdd(session, event.data)
    })
    on('message', (_ctx, message) => {
      if (!active()) return
      // 页面识别信息不受业务处理容量/回复开关影响，群消息到达就更新。
      this.captureGroupMessage(session, message)
      if (session.pending.size >= 4) return
      const task = this.handleMessage(session, message).catch(error => {
        if (active()) { this.lastError = this.safeError(error); this.log('error', this.lastError) }
      })
      session.pending.add(task)
      void task.finally(() => session.pending.delete(task))
      return task
    })
    on('interaction', (_ctx, event) => {
      if (!active()) return
      const task = this.handleInteraction(session, event).catch(error => {
        if (active()) { this.lastError = this.safeError(error); this.log('error', this.lastError) }
      })
      // Rejections are acknowledged even when business-handler slots are full.
      session.pending.add(task)
      void task.finally(() => session.pending.delete(task))
      return task
    })
    this.log('connecting', '正在连接 QQ 官方平台')
    session.task = Promise.resolve().then(() => {
      if (active()) return bot.start(session.abort.signal)
    }).then(() => {
      if (!active()) return
      this.current = null; this.state = 'error'; this.lastError = '连接已结束，请检查凭证和平台设置后重试'
      this.log('error', this.lastError)
    }).catch(error => {
      if (!active()) return
      this.current = null; this.state = 'error'; this.lastError = this.safeError(error); this.log('error', this.lastError)
    }).finally(() => { for (const [event, handler] of session.handlers) bot.off(event, handler) })
    session.groups = new Set()
    session.groupTimer = setInterval(() => { if (this.active(session)) void this.approvePending(session) }, 10000)
    session.groupTimer.unref?.()
    return this.status()
  }

  stop() { return this.exclusive(async () => { await this.stopInternal('手动断开'); return this.status() }) }
  async stopInternal(reason) {
    const session = this.current
    this.current = null
    if (session) {
      session.abort.abort()
      session.interactions.clear()
      session.interactionFlights.clear()
      for (const [event, handler] of session.handlers) session.bot.off(event, handler)
      session.bot.stop()
      clearInterval(session.groupTimer)
      clearTimeout(session.groupInfoTimer)
      session.groupInfoQueue?.clear()
      let timer
      await Promise.race([Promise.allSettled([session.task, ...session.pending]),
        new Promise(resolve => { timer = setTimeout(resolve, 3000) })]).finally(() => clearTimeout(timer))
    }
    this.state = this.config.appId && this.config.appSecret ? 'stopped' : 'unconfigured'
    this.log('stopped', reason)
  }

  async handleGroupAdd(session, data) {
    const groupId = String(data?.group_openid || '')
    if (!groupId) return
    session.groups.add(groupId)
    this.groupPolicy?.observeOfficial(groupId, { joined: true, joinedAt: Number(data.timestamp) * 1000 })
    this.queueGroupInfo(session, groupId)
    if (!this.config.welcomeEnabled || !this.groupAllowed({ kind: 'group', groupOpenid: groupId })) return
    try {
      await session.bot.send({ target: { scope: 'group', targetId: groupId }, content: this.config.welcomeText,
        extra: { event_id: data.gatewayEventId, msg_seq: 1 } })
      this.counts.repliesSent++
      this.log('welcome', '已发送入群欢迎语', { group: shortId(groupId) })
    } catch (error) { this.log('error', `入群欢迎语发送失败：${this.safeError(error)}`, { group: shortId(groupId) }) }
  }

  async approvePending(session) {
    if (!this.config.autoApprove || typeof session.bot.listJoinRequests !== 'function') return
    for (const groupId of session.groups || []) {
      if (!this.active(session) || !this.groupAllowed({ kind: 'group', groupOpenid: groupId })) continue
      try {
        const page = await session.bot.listJoinRequests(groupId)
        for (const item of Array.isArray(page?.list) ? page.list : []) {
          if (!this.active(session) || !this.groupAllowed({ kind: 'group', groupOpenid: groupId })) break
          if (!item?.member_openid || !item?.join_request_id) continue
          await session.bot.approveJoinRequest(groupId, item.member_openid, { op: 'approve', join_request_id: item.join_request_id })
          this.log('group-approval', '已自动通过入群申请', { group: shortId(groupId), member: shortId(item.member_openid) })
        }
      } catch (error) { this.log('error', `自动审批失败：${this.safeError(error)}`, { group: shortId(groupId) }) }
    }
  }

  registerCommand(command) {
    if (!command || typeof command.run !== 'function') throw new Error('命令缺少处理函数')
    const names = [command.name, ...(command.aliases || [])]
    if (names.some(name => typeof name !== 'string' || !/^[a-z0-9_\-\u4e00-\u9fff]{1,32}$/.test(name)) || new Set(names).size !== names.length) {
      throw new Error('命令名称无效或重复')
    }
    if (names.some(name => this.commands.has(name) || this.actions.has(name))) throw new Error('命令已注册')
    const record = { ...command, description: clean(command.description).slice(0, 100) }
    for (const name of names) this.commands.set(name, record)
    this.commandList.add(record)
    return () => { for (const name of names) if (this.commands.get(name) === record) this.commands.delete(name); this.commandList.delete(record) }
  }

  registerAction(action) {
    if (!action || typeof action.run !== 'function' || !/^[a-z0-9_\-\u4e00-\u9fff]{1,32}$/.test(action.name || '')) throw new Error('按钮处理逻辑无效')
    if (this.actions.has(action.name) || this.commands.has(action.name)) throw new Error('按钮处理逻辑已注册')
    const record = { ...action }
    this.actions.set(action.name, record)
    return () => { if (this.actions.get(action.name) === record) this.actions.delete(action.name) }
  }

  active(session) { return !this.disposed && this.current === session && !session.abort.signal.aborted }
  groupAllowed(message) {
    return message?.kind !== 'group' || !this.groupPolicy || this.groupPolicy.allowsOfficial(message.groupOpenid, this.config.appId)
  }

  captureGroupEvent(session, event) {
    const data = event?.data, type = event?.eventType
    if (!this.groupPolicy || !data?.group_openid) return
    if (type === 'GROUP_DEL_ROBOT') {
      this.groupPolicy.observeOfficial(data.group_openid, { joined: false })
      session.groups?.delete(data.group_openid)
    } else if (['GROUP_AT_MESSAGE_CREATE', 'GROUP_MESSAGE_CREATE'].includes(type)) {
      this.groupPolicy.observeOfficial(data.group_openid, { joined: true, content: this.safeError(data.content || '[非文本消息]'),
        author: data.author?.username, role: data.author?.member_role })
      session.rawGroupMessages ||= new Set()
      if (data.id) session.rawGroupMessages.add(data.id)
      if (session.rawGroupMessages.size > 2000) session.rawGroupMessages.delete(session.rawGroupMessages.values().next().value)
      session.groups?.add(data.group_openid)
      this.queueGroupInfo(session, data.group_openid)
    }
  }

  captureGroupMessage(session, message) {
    if (!this.groupPolicy || message?.kind !== 'group' || !message.groupOpenid || session.rawGroupMessages?.has(message.messageId)) return
    // SDK 将消息放入 message 事件，原始群主角色保留在 raw，不会再触发 rawEvent。
    const raw = message.raw || {}
    this.groupPolicy.observeOfficial(message.groupOpenid, { joined: true, content: this.safeError(raw.content ?? message.content),
      author: raw.author?.username || message.senderName || message.author?.username, role: raw.author?.member_role || message.author?.member_role })
    session.groups?.add(message.groupOpenid)
    this.queueGroupInfo(session, message.groupOpenid)
  }

  queueGroupInfo(session, groupId) {
    if (!this.groupPolicy || !this.active(session) || typeof session.bot.getGroupInfo !== 'function') return
    session.groupInfoSeen ||= new Map()
    session.groupInfoQueue ||= new Set()
    if (session.groupInfoSeen.has(groupId) && this.now() - session.groupInfoSeen.get(groupId) < 10 * 60_000) return
    if (session.groupInfoDeniedUntil > this.now()) {
      this.groupPolicy.updateOfficialInfo(groupId, this.config.appId, null, 'denied'); return
    }
    session.groupInfoQueue.add(groupId)
    if (session.groupInfoBusy || session.groupInfoTimer) return
    const run = async () => {
      session.groupInfoTimer = null
      if (!this.active(session) || !session.groupInfoQueue.size) return
      const id = session.groupInfoQueue.values().next().value, appId = this.config.appId
      session.groupInfoQueue.delete(id); session.groupInfoSeen.set(id, this.now()); session.groupInfoBusy = true
      session.groupInfoNextAt = this.now() + 2200
      try {
        const info = await session.bot.getGroupInfo(id)
        if (this.active(session)) this.groupPolicy.updateOfficialInfo(id, appId, info)
      } catch (error) {
        if (this.active(session)) {
          const denied = Number(error.bizCode ?? error.code) === 11253 || Number(error.httpStatus) === 403
          if (denied) {
            session.groupInfoDeniedUntil = this.now() + 60 * 60_000
            for (const pending of session.groupInfoQueue) this.groupPolicy.updateOfficialInfo(pending, appId, null, 'denied')
            session.groupInfoQueue.clear()
          }
          this.groupPolicy.updateOfficialInfo(id, appId, null, denied ? 'denied' : 'error')
        }
      } finally {
        session.groupInfoBusy = false
        // 官方接口 30 QPM：单队列最多约 27 次/分钟，不逐条消息请求。
        if (this.active(session) && session.groupInfoQueue.size) {
          session.groupInfoTimer = setTimeout(run, 2200); session.groupInfoTimer.unref?.()
        }
      }
    }
    session.groupInfoTimer = setTimeout(run, Math.max(0, (session.groupInfoNextAt || 0) - this.now())); session.groupInfoTimer.unref?.()
  }
  seen(session, key) {
    const now = this.now()
    for (const [id, timestamp] of session.seen) if (now - timestamp > 600000) session.seen.delete(id)
    if (session.seen.has(key)) return true
    session.seen.set(key, now)
    if (session.seen.size > 2000) session.seen.delete(session.seen.keys().next().value)
    return false
  }
  limited(session, key) {
    const now = this.now()
    if (session.recent.has(key) && now - session.recent.get(key) < 1000) return true
    session.recent.set(key, now)
    if (session.recent.size > 2000) session.recent.delete(session.recent.keys().next().value)
    return false
  }
  async handleInteraction(session, event) {
    if (!this.active(session) || !event?.id) return
    if (this.seen(session, `interaction:${event.id}`)) return
    // Delivery retries may reuse the gateway event while changing the click ID.
    if (event.gatewayEventId && this.seen(session, `gateway-interaction:${event.gatewayEventId}`)) {
      this.counts.interactionsSuppressed++
      await session.bot.acknowledgeInteraction(event.id, 3)
      return
    }
    this.counts.interactionsReceived++
    const message = interactionMessage(event)
    let decision = message ? session.interactions.resolveEvent(event, message) : { code: 4, reason: 'invalid-interaction-shape' }
    if (message && !message.replyTarget.eventId) decision = { code: 1, reason: 'missing-gateway-event-id' }
    if (!this.config.replyEnabled) decision = { code: 4, reason: 'replies-disabled' }
    if (message && !this.groupAllowed(message)) decision = { code: 4, reason: 'group-disabled' }
    const flightKey = message ? JSON.stringify([message.kind, message.replyTarget.targetId, message.senderId]) : ''
    if (decision.code === 0 && session.interactionFlights.has(flightKey)) decision = { code: 0, suppressed: true, reason: 'in-flight' }
    else if (decision.code === 0 && session.pending.size >= 4) decision = { code: 2, reason: 'capacity' }
    // Consume before awaiting ACK to prevent two simultaneous unique events from
    // running a one-shot action. A failed ACK never executes business logic.
    const accepted = decision.code === 0 && !decision.suppressed
    if (accepted) { decision.consume?.(); session.interactionFlights.add(flightKey) }
    else if (decision.suppressed || [2, 3].includes(decision.code)) this.counts.interactionsSuppressed++
    try {
      await session.bot.acknowledgeInteraction(event.id, decision.code)
      if (!this.active(session)) return
      if (accepted) decision.accepted?.()
      this.log('interaction', accepted ? `收到按钮操作：${decision.record.name}` :
        decision.suppressed ? '操作已接收：等待正在处理的回复' :
          decision.code === 3 ? '已拦截重复操作：此操作已经执行' : `按钮操作已拒绝（${decision.code}，${decision.reason || 'unknown'}）`,
        { operation: shortId(event.id), event: shortId(event.gatewayEventId), reason: decision.reason,
          buttonId: clean(event.data?.resolved?.button_id).slice(0, 64), expectedButton: decision.expectedButton,
          tokenFingerprint: fingerprint(event.data?.resolved?.button_data),
          ...(message ? { kind: message.kind, sender: shortId(message.senderId), group: shortId(message.groupOpenid) } : {}) })
      if (!accepted) return
      try {
        await this.runHandler(session, decision.record, decision.args, message, 'interaction', event)
        if (this.active(session)) this.counts.interactionsHandled++
      } catch (error) {
        if (this.active(session)) this.counts.interactionsFailed++
        throw new Error(`按钮 ${decision.record.name} 处理或回复失败：${this.safeError(error)}`, { cause: error })
      }
    } finally {
      if (accepted) { decision.release?.(); session.interactionFlights.delete(flightKey) }
    }
  }

  async runHandler(session, command, args, message, source, interaction) {
    if (!this.active(session) || !this.groupAllowed(message)) return
    let sequence = 0
    const replyInConversation = async value => {
      if (!this.active(session) || !this.config.replyEnabled || !this.groupAllowed(message)) throw fail(503, '机器人已断开或群已停用')
      const count = await this.sendReply(session, message, value, command.name, sequence + 1)
      sequence += count || 1
      return count
    }
    const reply = await command.run({ args, message, signal: session.abort.signal, source, interaction, ui,
      isActive: () => this.active(session) && this.config.replyEnabled && this.groupAllowed(message),
      status: () => this.status(), commands: this.status().commands, ...this.helpContext?.(message), reply: replyInConversation,
      sendPrivate: async value => {
        if (!this.active(session) || !this.config.replyEnabled || !this.groupAllowed(message)) throw fail(503, '机器人已断开或群已停用')
        try {
          // A group msg_id/event_id cannot authorize a C2C reply. A group-origin
          // notification is an independent proactive send and can be refused.
          const target = message.kind === 'c2c' ? message.replyTarget : { scope: 'c2c', targetId: message.senderId }
          await this.sendReply(session, { ...message, kind: 'c2c', groupOpenid: undefined, replyTarget: target }, value,
            'private-credential', message.kind === 'c2c' ? ++sequence : 1, { sensitive: true })
          this.log('account', '私信凭据已发送', { kind: 'c2c' })
        } catch { throw fail(502, '私信发送未确认成功') }
      } })
    if (!this.active(session) || !this.config.replyEnabled) return
    await replyInConversation(reply)
  }
  async sendReply(session, message, value, name, sequence = 1, { sensitive = false } = {}) {
    if (!this.active(session) || !this.config.replyEnabled || !this.groupAllowed(message)) return
    const prepared = !sensitive && this.renderReply
      ? await this.renderReply(value, { signal: session.abort.signal, botStatus: this.status() })
      : value
    const reply = normalizeReply(prepared)
    if (!reply || !reply.text.trim()) return
    if (reply.images) {
      if (!session.bot.uploadMedia) throw new Error('QQ SDK 不支持图片上传，请更新官方机器人插件')
      for (const [index, image] of reply.images.entries()) {
        if (!this.active(session) || !this.config.replyEnabled || !this.groupAllowed(message)) return
        const uploaded = await session.bot.uploadMedia({ target: message.replyTarget, fileType: 1, buffer: image, srvSendMsg: false })
        if (!uploaded?.file_info) throw new Error('QQ 图片上传未返回文件标识')
        if (!this.active(session) || !this.config.replyEnabled || !this.groupAllowed(message)) return
        await session.bot.send({ target: message.replyTarget, msgType: 7, media: { file_info: uploaded.file_info },
          extra: { msg_seq: sequence + index, ...(message.replyTarget.eventId ? { event_id: message.replyTarget.eventId } : {}) } })
        if (this.active(session)) { this.counts.repliesSent++; this.log('reply', '已回复图片 ' + name, { kind: message.kind, page: index + 1, pages: reply.images.length }) }
      }
      // Media messages do not carry the native Markdown keyboard. Send the
      // navigation card afterwards with its own sequence and callback tokens.
      if (reply.markdown || reply.buttons.length) {
        await this.sendReply(session, message, { ...prepared, visual: undefined, images: undefined }, name, sequence + reply.images.length, { sensitive })
        return reply.images.length + 1
      }
      return reply.images.length
    }
    let keyboard, sent, issued = []
    if (reply.markdown && this.config.responseMode !== 'text') {
      if (this.config.keyboardMode === 'custom' && reply.buttons.length) {
        const built = session.interactions.keyboard(reply.buttons, message)
        keyboard = built.payload; issued = built.issued
      } else if (this.config.keyboardMode === 'template') keyboard = { id: this.config.keyboardTemplateId }
    }
    const payload = outbound(reply, this.config, keyboard)
    // One reply per inbound event: use the same sequence across reconnects or
    // gateway replays. SDK 1.0.5's default is random, defeating QQ idempotency.
    const send = body => {
      if (!this.active(session) || !this.config.replyEnabled || !this.groupAllowed(message)) return
      return session.bot.send({ target: message.replyTarget, ...body,
        extra: { msg_seq: sequence, ...(message.replyTarget.eventId ? { event_id: message.replyTarget.eventId } : {}) } })
    }
    try {
      sent = await send(payload)
    } catch (error) {
      // A timeout/read failure does not prove QQ rejected the POST. The card
      // may already be visible; keep its buttons usable without resending it.
      if (error.httpStatus >= 400 && error.httpStatus < 500 && error.httpStatus !== 408) session.interactions.revoke(issued)
      if (!this.active(session) || !this.config.replyEnabled || payload.msgType !== 2 || !this.config.fallbackToText || !richPermissionRejected(error)) throw error
      this.counts.richFallbacks++
      this.log('fallback', sensitive ? '私信富文本权限被平台拒绝，改用文字回复' : `Markdown/按钮权限被平台拒绝，改用文字回复：${this.safeError(error)}`)
      sent = await send({ msgType: 0, content: reply.text })
    }
    if (this.active(session)) { this.counts.repliesSent++; this.log('reply', `已回复 ${name}`, {
      kind: message.kind, operation: shortId(message.interactionId || message.messageId), replyId: shortId(sent?.id),
    }) }
  }

  async handleMessage(session, message) {
    if (!message?.messageId || !['c2c', 'group'].includes(message.kind)) return
    const active = () => !this.disposed && this.current === session && !session.abort.signal.aborted
    if (!active()) return
    if (this.seen(session, `message:${message.messageId}`)) return
    this.captureGroupMessage(session, message)
    if (message.kind === 'group') await this.observeGroupMessage?.(message)
    if (!active() || !this.groupAllowed(message)) return
    this.counts.messagesReceived++
    if (message.kind === 'group' && message.rawEventType === 'GROUP_MESSAGE_CREATE') this.counts.fullGroupMessagesReceived++
    this.log('message', '收到消息', { kind: message.kind, sender: shortId(message.senderId), group: shortId(message.groupOpenid),
      ...(this.config.messagePreview && !this.commands.get(parseCommand(message.content).name)?.sensitive ? { preview: this.safeError(message.content).slice(0, 240) } : {}) })
    if (!this.config.replyEnabled || !message.replyTarget) return
    const { name, args } = parseCommand(message.content)
    const command = this.commands.get(name)
    if (!command) return
    const target = JSON.stringify([message.kind, message.groupOpenid || message.senderId, command.name])
    if (this.limited(session, target)) return
    await this.runHandler(session, command, args, message, 'message')
  }

  async dispose() {
    if (this.disposed) return
    this.disposed = true
    await this.stopInternal('插件停用')
    await this.queue
    this.commands.clear(); this.commandList.clear(); this.actions.clear()
  }
}
