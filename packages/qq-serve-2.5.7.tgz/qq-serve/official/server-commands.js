import { collect } from '../render-templates/data.js'
import { onlinePages } from '../online.js'
// Read-only Cordis integration. Never forward user input as a REST path/command.
const clean = (value, limit = 80) => String(value ?? '').replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ').slice(0, limit)
const positive = value => /^\d+$/.test(String(value)) && Number(value) > 0 ? Number(value) : 1
const count = value => typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 ? String(value) : '未知'
const error = (message, kind = 'unavailable') => Object.assign(new Error(message), { publicMessage: message, queryKind: kind })

export function registerServerCommands(manager, { getService }) {
  // Builders are passed by the manager at invocation time, just like external
  // command plugins. No SDK or QQ identity-to-numeric-account mapping is needed.
  const footer = tools => [tools.button.callback('服务器列表', 'servers', [], { style: 0 }), tools.button.callback('主菜单', 'menu', [], { style: 0 })]
  const registrations = []
  const rendered = async (kind, signal, ui) => {
    const renderer = getService('qqRenderer')
    if (!renderer?.config?.enabled) return null
    let result
    try { result = await renderer.render(kind, { signal }) } catch (cause) {
      if (signal?.aborted) throw cause
      manager.log('query', '图片渲染未完成，改用文字查询', { reason: 'render-unavailable' })
      return null
    }
    return { ...ui.card({ title: kind === 'players' ? '全服在线玩家' : '服务器列表',
      lines: ['图片显示最新查询结果；使用按钮刷新或返回主菜单。'],
      buttons: [[ui.button.callback('刷新图片', kind === 'players' ? 'online' : 'servers'), ui.button.callback('主菜单', 'menu', [], { style: 0 })]] }),
      images: result.images }
  }
  const list = async () => {
    const registry = getService('servers')
    if (!registry?.list) throw error('服务器查询暂不可用，请管理员启用 servers 插件。')
    let rows
    try { rows = await registry.list() } catch { throw error('服务器清单暂时无法读取，请管理员检查服务器配置。') }
    if (!Array.isArray(rows)) throw error('服务器清单格式异常，请管理员检查 servers 插件。')
    // Only publish enabled servers through these read-only bot commands.
    // Whitelist fields so REST tokens, hosts, ports, notes and errors never leak.
    return rows.filter(row => row.enabled !== false).map((row, index) => ({
      id: String(row.id), name: clean(row.name || '未命名服务器', 60), number: index + 1,
      connection: row.connected ? '已连接' : '未连接',
    }))
  }
  const picker = (tools, rows, action = 'server', requestedPage = 1, notice = '') => {
    const pages = Math.max(1, Math.ceil(rows.length / 4)), page = Math.min(pages, positive(requestedPage))
    const slice = rows.slice((page - 1) * 4, page * 4)
    const lines = [notice || (action === 'online' ? '选择服务器，查看当前在线玩家。' : '选择服务器查看状态，或直接查看在线玩家。'), ...slice.map(row => `${row.number}. ${tools.escapeMarkdown(row.name)} — ${row.connection}`)]
    if (!rows.length) lines.push('暂无启用的服务器，请管理员在面板中添加并启用。')
    const buttons = slice.map(row => [tools.button.callback(`${row.number}. ${row.name}`.slice(0, 45), action, [row.id]),
      action === 'online' ? tools.button.callback('服务器状态', 'server', [row.id], { style: 0 }) : tools.button.callback('全服在线', 'online', [], { style: 0 })])
    buttons.push([...(page > 1 ? [tools.button.callback('上一页', 'server-picker', [action, String(page - 1)])] : []),
      ...(page < pages ? [tools.button.callback('下一页', 'server-picker', [action, String(page + 1)])] : []),
      tools.button.callback('刷新列表', 'server-picker', [action, String(page)], { style: 0 }), tools.button.callback('主菜单', 'menu', [], { style: 0 })])
    return tools.card({ title: `服务器列表 ${page}/${pages}`, lines, buttons })
  }
  const select = (rows, value, fromButton) => {
    if (!value) return rows.length === 1 ? rows[0] : null
    // Dynamic buttons always carry immutable IDs, not indexes or mutable names.
    if (fromButton) return rows.find(row => row.id === value) || null
    const byId = rows.find(row => row.id === value)
    if (byId) return byId
    const byName = rows.filter(row => row.name.toLowerCase() === value.toLowerCase())
    if (byName.length === 1) return byName[0]
    if (byName.length > 1) throw error('存在同名服务器，请通过按钮选择，或使用服务器列表中的序号。', 'selection')
    return /^\d+$/.test(value) ? rows.find(row => row.number === Number(value)) || null : null
  }
  const read = async (server, endpoint) => {
    const registry = getService('servers'), tshock = getService('tshock')
    if (!registry?.getRaw || !tshock?.fetchFor) throw error('服务器查询服务暂不可用，请管理员检查 servers 插件。')
    const raw = registry.getRaw(server.id)
    if (!raw || raw.enabled === false) throw error('该服务器已移除或停用，请刷新服务器列表。', 'selection')
    let result
    try { result = await tshock.fetchFor(raw, endpoint, {}, { timeoutMs: 5000 }) }
    catch (cause) { throw error(cause?.type === 'timeout' ? '查询超时，服务器未在 5 秒内响应，请稍后刷新。' : '暂时无法连接游戏服，请管理员检查运行状态与 REST 连接。', 'network') }
    if ([401, 403].includes(Number(result.status)) || [401, 403].includes(Number(result.data?.status))) throw error('游戏服 REST 鉴权失败，请管理员检查凭据与权限。', 'auth')
    if (!result.ok || !result.data || result.data.error || Number(result.data.status) >= 400) throw error('游戏服未返回有效数据，请稍后刷新或联系管理员。', 'upstream')
    return result.data
  }
  const safe = handler => async context => {
    if (context.signal.aborted) return
    try { return await handler(context) } catch (cause) {
      if (context.signal.aborted) return
      manager.log('query', '服务器查询未完成', { reason: cause.queryKind || 'unavailable' })
      return context.ui.card({ title: '服务器查询暂不可用', lines: [cause.publicMessage || '查询服务暂不可用，请稍后重试。'], buttons: [footer(context.ui)] })
    }
  }
  registrations.push(manager.registerCommand({ name: 'servers', aliases: ['服务器', '服务器列表', '选服'], description: '服务器列表：servers [页码]', templateAction: true,
    run: safe(async ({ args, ui, signal }) => await rendered('servers', signal, ui) || picker(ui, await list(), 'server', args[0])) }))
  registrations.push(manager.registerAction({ name: 'server-picker', run: safe(async ({ args, ui }) => picker(ui, await list(), args[0] === 'online' ? 'online' : 'server', args[1])) }))
  registrations.push(manager.registerCommand({ name: 'server', aliases: ['服务器状态', '服状态'], description: '运行状态：server [序号或服名]', templateAction: true,
    run: safe(async ({ args, source, ui }) => {
      const rows = await list(), value = args.join(' ').trim(), selected = select(rows, value, source === 'interaction')
      if (!selected) return picker(ui, rows, 'server', 1, value ? '未找到该服务器，请通过按钮选择。' : '')
      const data = await read(selected, '/v2/server/status')
      if (typeof data.playercount !== 'number') throw error('游戏服状态数据不完整，请稍后刷新。', 'format')
      const lines = [`服务器：${ui.escapeMarkdown(selected.name)}`, '运行状态：REST 查询成功',
        `当前在线：${count(data.playercount)} / ${count(data.maxplayers)}`, `世界：${ui.escapeMarkdown(clean(data.world || '未返回'))}`]
      if (data.uptime !== undefined) lines.push(`运行时长：${ui.escapeMarkdown(clean(data.uptime, 60))}`)
      if (data.serverversion) lines.push(`游戏版本：${ui.escapeMarkdown(clean(data.serverversion, 40))}`)
      return ui.card({ title: '服务器运行状态', lines, buttons: [[ui.button.callback('刷新状态', 'server', [selected.id]), ui.button.callback('全服在线', 'online')], footer(ui)] })
    }) }))
  registrations.push(manager.registerCommand({ name: 'online', aliases: ['在线', '在线玩家', 'players'], description: '在线：查看全部服务器在线玩家', templateAction: true,
    run: safe(async ({ args, source, ui, signal }) => {
      const image = await rendered('players', signal, ui)
      if (image) return image
      const data = await collect({ servers: getService('servers'), tshock: getService('tshock') }, {}, signal)
      const pages = onlinePages(data), page = Math.min(pages.length, source === 'interaction' && args[0] === 'all' ? positive(args[1]) : 1)
      return ui.card({ title: `全服在线玩家 ${page}/${pages.length}`, lines: pages[page - 1].map(line => ui.escapeMarkdown(line)), buttons: [[
        ...(page > 1 ? [ui.button.callback('上一页', 'online', ['all', String(page - 1)])] : []),
        ...(page < pages.length ? [ui.button.callback('下一页', 'online', ['all', String(page + 1)])] : []),
        ui.button.callback('刷新在线', 'online', ['all', String(page)]),
      ], footer(ui)] })
    }) }))
  return () => { for (const unregister of registrations.reverse()) unregister() }
}
