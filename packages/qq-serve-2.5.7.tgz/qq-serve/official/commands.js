import { buildHelp, helpText } from '../help.js'
const { ui } = await import(`./messages.js${new URL(import.meta.url).search}`)
const navigation = () => [[ui.button.callback('主菜单', 'menu', [], { style: 0 }), ui.button.callback('机器人状态', 'status', [], { style: 0 })]]
const menu = ({ commands }) => {
  const allowed = new Set(commands.map(command => command.name))
  const rows = [[['服务器列表', 'servers'], ['在线玩家', 'online']], [['账号服务', 'account'], ['使用帮助', 'help']]]
  return ui.card({ title: 'TSWeb 机器人', lines: ['查服务器、看在线，或管理自己的游戏账号。', '发送“菜单”可随时返回。'],
    buttons: rows.map(row => row.filter(([, command]) => allowed.has(command)).map(([label, command]) => ui.button.callback(label, command))).filter(row => row.length) })
}
export const builtinCommands = [
  { name: 'group-info', description: '获取当前官方群标识', aliases: ['群信息', '群标识'],
    run: ({ message }) => message?.groupOpenid ? '当前群 group_openid：' + message.groupOpenid + '\n在 QQ 控制台 → 群管理启用目标群；混合模式的群映射由系统自动建立，无需填写。' : '请在目标 QQ 群中 @机器人 发送“群信息”。' },
  { name: 'menu', description: '打开交互主菜单', aliases: ['菜单', '开始'], templateAction: true, run: menu },
  { name: 'ping', description: '测试机器人连接', aliases: ['测试'],
    run: () => 'pong：QQ 官方机器人已连接。' },
  { name: 'help', description: '查看可用命令', aliases: ['帮助'], templateAction: true,
    run: ({ commands, message, helpDocument }) => {
      const document = helpDocument || buildHelp({ commands, scene: message?.kind === 'group' ? 'group' : 'private' })
      const allowed = new Set(commands.map(command => command.name))
      const buttons = navigation().map(row => row.filter(button => allowed.has(button.action))).filter(row => row.length)
      return { ...ui.card({ title: document.title, lines: helpText(document).split('\n').slice(1), buttons }), visual: { kind: 'help', document } }
    } },
  { name: 'status', description: '查看机器人运行状态', aliases: ['状态'], templateAction: true,
    run: ({ status }) => {
      const s = status()
      return ui.card({ title: '机器人状态', lines: [s.connected ? '机器人在线' : '机器人正在连接', `运行 ${s.uptimeSeconds} 秒`,
        `收到 ${s.messagesReceived} 条消息，回复 ${s.repliesSent} 条。`, `按钮回调 ${s.interactionsReceived} 次。`], buttons: navigation() })
    } },
]

export function parseCommand(content) {
  // Group command buttons prepend <@OpenID>, not necessarily a numeric AppID.
  // Strip address prefixes only: mentions inside arguments must remain literal.
  const text = String(content || '').replace(/^(?:\s*<@!?[A-Za-z0-9_-]{1,128}>)+\s*/, '').trim().replace(/^\//, '')
  const [name = '', ...args] = text.split(/\s+/)
  return { name: name.toLowerCase(), args }
}
