export default {
  owner: 'qq-serve',
  version: 2,
  modules: [{ id: 'qq-serve.settings', permission: 'qq-serve.ui.settings', title: 'QQ 服务模式', roles: ['superadmin'], scope: 'global', requires: [
    'qq-serve.get.config', 'qq-serve.post.config', 'qq-serve.get.status', 'qq-serve.post.test',
    'qq-serve.get.rendering', 'qq-serve.post.rendering', 'qq-serve.post.render-preview',
    'qq-serve.groups.read', 'qq-serve.groups.enabled', 'qq-serve.groups.refresh', 'qq-serve.groups.mappings.delete',
  ] }],
  actions: [
    { id: 'qq-serve.groups.read', method: 'GET', path: '/api/qq-serve/groups', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.groups.enabled', method: 'POST', path: '/api/qq-serve/groups/enabled', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.groups.refresh', method: 'POST', path: '/api/qq-serve/groups/refresh', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.groups.mappings.delete', method: 'POST', path: '/api/qq-serve/groups/mappings/delete', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.get.rendering', method: 'GET', path: '/api/qq-serve/rendering', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.post.rendering', method: 'POST', path: '/api/qq-serve/rendering', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.post.render-preview', method: 'POST', path: '/api/qq-serve/rendering/preview', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.post.test', method: 'POST', path: '/api/qq-serve/test', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.get.status', method: 'GET', path: '/api/qq-serve/status', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.get.config', method: 'GET', path: '/api/qq-serve/config', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.post.config', method: 'POST', path: '/api/qq-serve/config', scope: 'global', module: 'qq-serve.settings' },
  ],
  features: [{ id: 'qq-serve:settings', module: 'qq-serve.settings', requires: [
    'qq-serve.get.config', 'qq-serve.post.config', 'qq-serve.get.status', 'qq-serve.post.test',
  ] }, { id: 'qq-serve:groups', module: 'qq-serve.settings', requires: ['qq-serve.groups.read', 'qq-serve.groups.enabled', 'qq-serve.groups.refresh', 'qq-serve.groups.mappings.delete'] },
  { id: 'qq-serve:rendering', module: 'qq-serve.settings', requires: ['qq-serve.get.rendering', 'qq-serve.post.rendering', 'qq-serve.post.render-preview'] }],
}
