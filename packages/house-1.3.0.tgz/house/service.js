import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID, createHash } from "node:crypto";
/**
 * 建筑预览解码迁到独立插件 world-preview。
 *
 * 用动态 import 而不是静态 import：市场会先装依赖再启用本插件，但本地手工安装/目录被删时，
 * 静态 import 的报错是 "Cannot find module ..."，完全看不出是缺插件；这里给出可执行的指引。
 */
let buildingPreview;
try {
  buildingPreview = await import("../world-preview/building-preview.js");
} catch {
  throw new Error(
    "房屋插件依赖 world-preview（世界预览）插件：请先在插件市场安装 world-preview 后重试",
  );
}
const { decodeBuilding, buildingChunk, buildingOverview, MAX_BUILDING_BYTES } = buildingPreview;
export const fail = (status, message) =>
  Object.assign(new Error(message), { status });
export function fileName(value) {
  if (
    typeof value !== "string" ||
    value.length > 180 ||
    !value ||
    /[\\/:*?"<>|\x00-\x1f]/.test(value) ||
    value !== path.basename(value) ||
    !/\.(tsb|trb)$/i.test(value) ||
    /[. ]$/.test(value)
  )
    throw fail(400, "建筑文件名无效，仅支持 .tsb/.trb");
  return value;
}
export class HouseService {
  constructor(ctx) {
    this.ctx = ctx;
    this.dir = path.join(ctx.paths.dataOf("house"), "buildings");
    this.previews = new Map();
    this.disposed = false;
  }
  server(req) {
    const id =
      req.headers["x-server-id"] ||
      req.query?.serverId ||
      req.user?.serverId ||
      req.user?.extraServerIds?.[0];
    if (typeof id !== "string" || !id) throw fail(400, "请先选择服务器");
    const s = this.ctx.servers.getRaw(id);
    if (!s) throw fail(404, "服务器不存在");
    return s;
  }
  async call(req, suffix, params = {}, signal) {
    signal?.throwIfAborted();
    if (this.disposed) throw fail(503, "房屋插件正在停用");
    const server = this.server(req);
    let response;
    const form =
      suffix === "buildings/upload" ||
      suffix === "commands/save" ||
      suffix === "settings/save" ||
      suffix === "members/save";
    if (
      form &&
      Buffer.byteLength(new URLSearchParams(params).toString()) > 24 * 1024
    )
      throw fail(
        413,
        "提交内容过大，请精简进入指令后重试（编码后最多 24 KiB）",
      );
    try {
      const method = form ? "postFor" : "fetchFor";
      response = await this.ctx.tshock[method](
        server,
        `/data/house/${suffix}`,
        params,
        { signal, timeoutMs: 20000, encoding: "form" },
      );
    } catch (e) {
      signal?.throwIfAborted();
      throw fail(502, "连接房屋插件失败：" + e.message);
    }
    signal?.throwIfAborted();
    if (this.disposed) throw fail(503, "房屋插件正在停用");
    const data = response.data,
      status = Number(data?.status || response.status || 502);
    if (!response.ok || !data || status >= 400 || data.error)
      throw fail(
        [400, 404, 409, 413, 422, 429, 503].includes(status) ? status : 502,
        data?.error ||
          "请检查独立 House.dll 的部署和 tsweb.house.manage 令牌权限",
      );
    return data;
  }
  backendDir(req) {
    const id = this.server(req).id;
    if (!/^[A-Za-z0-9_-]{1,128}$/.test(id)) throw fail(400, "服务器编号无效");
    return path.join(this.dir, "servers", id);
  }
  localPath(req, name) {
    return path.join(this.backendDir(req), fileName(name));
  }
  async readBackend(req, name) {
    const full = this.localPath(req, name);
    let f;
    try {
      f = await fs.open(full, "r");
      const s = await f.stat();
      if (!s.isFile() || s.size > MAX_BUILDING_BYTES)
        throw fail(413, "建筑文件无效或超过 32 MiB");
      return await f.readFile();
    } catch (e) {
      if (e.code === "ENOENT") throw fail(404, "后端建筑文件不存在");
      throw e;
    } finally {
      await f?.close();
    }
  }
  async readLocal(req, name, signal) {
    const parts = [];
    let offset = 0,
      total = null,
      hash = null;
    do {
      const r = await this.call(
        req,
        "buildings/read",
        { file: fileName(name), offset: String(offset) },
        signal,
      );
      if (
        !Number.isInteger(r.total) ||
        r.total < 1 ||
        r.total > MAX_BUILDING_BYTES ||
        r.offset !== offset ||
        typeof r.sha256 !== "string"
      )
        throw fail(502, "服务器文件响应无效");
      if (total !== null && (r.total !== total || r.sha256 !== hash))
        throw fail(409, "建筑文件已变化，请重新读取");
      total = r.total;
      hash = r.sha256;
      const b = Buffer.from(r.data || "", "base64");
      if (!b.length || b.length > 128 * 1024 || offset + b.length > total)
        throw fail(502, "服务器文件分片无效");
      parts.push(b);
      offset += b.length;
    } while (offset < total);
    const b = Buffer.concat(parts);
    if (createHash("sha256").update(b).digest("hex") !== hash)
      throw fail(409, "服务器文件校验失败");
    return b;
  }
  async read(req, source, name, signal) {
    if (!["local", "backend"].includes(source)) throw fail(400, "存档来源无效");
    return source === "local"
      ? this.readLocal(req, name, signal)
      : this.readBackend(req, name);
  }
  async list(req, source, signal) {
    if (source === "local")
      return this.call(
        req,
        "buildings/list",
        {
          page: String(req.query.page || 1),
          pageSize: "100",
          query: String(req.query.query || ""),
        },
        signal,
      );
    if (source !== "backend") throw fail(400, "存档来源无效");
    const dir = this.backendDir(req);
    await fs.mkdir(dir, { recursive: true });
    const items = [];
    for (const e of await fs.readdir(dir, { withFileTypes: true })) {
      if (!e.isFile() || !/\.(tsb|trb)$/i.test(e.name)) continue;
      const st = await fs.stat(this.localPath(req, e.name));
      let meta = {},
        error = "";
      try {
        const b = decodeBuilding(await this.readBackend(req, e.name));
        meta = { ...b.meta, width: b.width, height: b.height };
      } catch (e) {
        error = e.message;
      }
      items.push({
        file: e.name,
        ...meta,
        sizeBytes: st.size,
        modifiedAt: st.mtimeMs,
        error,
      });
    }
    items.sort((a, b) => b.modifiedAt - a.modifiedAt);
    return { items, total: items.length };
  }
  async saveBackend(req, name, bytes) {
    decodeBuilding(bytes);
    const dir = this.backendDir(req);
    await fs.mkdir(dir, { recursive: true });
    const temp = path.join(dir, randomUUID() + ".tmp");
    try {
      await fs.writeFile(temp, bytes, { flag: "wx" });
      let output = fileName(name);
      try {
        await fs.link(temp, this.localPath(req, output));
      } catch (e) {
        if (e.code !== "EEXIST") throw e;
        output =
          path.basename(name, path.extname(name)) +
          "_" +
          randomUUID().slice(0, 8) +
          path.extname(name);
        await fs.link(temp, this.localPath(req, output));
      }
      return output;
    } finally {
      await fs.rm(temp, { force: true });
    }
  }
  async upload(req, name, bytes, signal) {
    const sha256 = createHash("sha256").update(bytes).digest("hex"),
      uploadId = randomUUID();
    let index = 0;
    for (let off = 0; off < bytes.length; off += 12 * 1024, index++) {
      const part = bytes.subarray(off, off + 12 * 1024),
        last = off + part.length === bytes.length;
      const result = await this.call(
        req,
        "buildings/upload",
        {
          file: name,
          world: req.body.world,
          uploadId,
          index: String(index),
          total: String(bytes.length),
          sha256,
          data: part.toString("base64url"),
          final: last ? "1" : "0",
        },
        signal,
      );
      if (
        result.committed !== last ||
        (!last && result.received !== off + part.length)
      )
        throw fail(502, "上传未得到完整分片确认，请检查 House.dll 版本");
    }
  }
  async importSaved(req, params, signal) {
    const { source } = req.body;
    if (!["local", "backend"].includes(source)) throw fail(400, "存档来源无效");
    if (source === "local")
      return this.call(req, "buildings/import", params, signal);
    const bytes = await this.readBackend(req, params.file);
    decodeBuilding(bytes);
    signal?.throwIfAborted();
    const remote = "house-import-" + randomUUID() + ".tsb";
    await this.upload(req, remote, bytes, signal);
    let result, cleanupError;
    try {
      result = await this.call(
        req,
        "buildings/import",
        { ...params, file: remote },
        signal,
      );
    } finally {
      if (!signal?.aborted && !this.disposed)
        try {
          await this.call(
            req,
            "buildings/delete",
            { file: remote, world: params.world },
            signal,
          );
        } catch (e) {
          cleanupError = e.message;
        }
    }
    return cleanupError
      ? {
          ...result,
          warning: `导入已完成，临时文件 ${remote} 未清理：${cleanupError}`,
        }
      : result;
  }
  async preview(req, signal) {
    const source = req.query.source,
      name = fileName(req.query.file),
      building = decodeBuilding(await this.read(req, source, name, signal)),
      id = randomUUID();
    const overview = await buildingOverview(building);
    signal?.throwIfAborted();
    if (this.disposed) throw fail(503, "房屋插件正在停用");
    this.prune();
    let used = [...this.previews.values()].reduce(
      (n, p) => n + p.building.raw.length,
      0,
    );
    while (
      this.previews.size >= 8 ||
      used + building.raw.length > 64 * 1024 * 1024
    ) {
      const [key, p] = this.previews.entries().next().value;
      used -= p.building.raw.length;
      this.previews.delete(key);
    }
    this.previews.set(id, {
      building,
      actor: req.user.username,
      server: this.server(req).id,
      source,
      name,
      expires: Date.now() + 300000,
    });
    return {
      previewId: id,
      meta: building.meta,
      width: building.width,
      height: building.height,
      map: { base64: overview },
      snapshot: {
        format: "tsweb-tiles-v1",
        world: "archive:" + building.hash,
        width: building.width,
        height: building.height,
        chunkSize: 128,
        recordBytes: 16,
        surface: building.height + 1,
        chunks: {},
        lazy: true,
        live: false,
      },
    };
  }
  prune() {
    for (const [key, p] of this.previews)
      if (p.expires < Date.now()) this.previews.delete(key);
  }
  previewChunk(req) {
    this.prune();
    const p = this.previews.get(req.query.id);
    if (!p || p.actor !== req.user.username || p.server !== this.server(req).id)
      throw fail(404, "预览已过期，请重新选择存档");
    return {
      base64: buildingChunk(
        p.building,
        Number(req.query.cx),
        Number(req.query.cy),
      ),
    };
  }
  async transfer(req, name, signal) {
    const saved = await this.saveBackend(
      req,
      name,
      await this.readLocal(req, name, signal),
    );
    let localDeleted = false,
      error = "";
    try {
      await this.call(
        req,
        "buildings/delete",
        { file: name, world: req.body.world },
        signal,
      );
      localDeleted = true;
    } catch (e) {
      error = e.message;
    }
    return {
      success: true,
      file: saved,
      localDeleted,
      warning: error ? `后端已保存，本地未删除：${error}` : "",
    };
  }
}
