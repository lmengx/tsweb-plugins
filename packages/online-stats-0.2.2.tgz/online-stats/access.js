// Module permissions authorize both UI features and their backend routes.
export default {
  "owner": "online-stats",
  "version": 2,
  "modules": [
    {
      "id": "online-stats.statistics",
      "permission": "online-stats.module.statistics",
      "title": "在线统计",
      "roles": [
        "superadmin",
        "admin",
        "subadmin"
      ],
      "scope": "server",
      "requires": [
        "online-stats.get.online.stats.current",
        "online-stats.get.online.stats.trend",
        "online-stats.get.online.stats.players",
        "online-stats.get.online.stats.player",
        "online-stats.get.online.stats.servers",
        "online-stats.get.online.stats.hourly",
        "online-stats.get.online.stats.ranking",
        "online-stats.get.online.stats.ranking.stats",
        "online-stats.get.online.stats.playtime",
        "online-stats.get.online.stats.all.playtime"
      ]
    }
  ],
  "actions": [
    {
      "id": "online-stats.get.online.stats.current",
      "method": "GET",
      "path": "/api/online-stats/current",
      "scope": "server",
      "module": "online-stats.statistics"
    },
    {
      "id": "online-stats.get.online.stats.trend",
      "method": "GET",
      "path": "/api/online-stats/trend",
      "scope": "server",
      "module": "online-stats.statistics"
    },
    {
      "id": "online-stats.get.online.stats.players",
      "method": "GET",
      "path": "/api/online-stats/players",
      "scope": "server",
      "module": "online-stats.statistics"
    },
    {
      "id": "online-stats.get.online.stats.player",
      "method": "GET",
      "path": "/api/online-stats/player",
      "scope": "server",
      "module": "online-stats.statistics"
    },
    {
      "id": "online-stats.get.online.stats.servers",
      "method": "GET",
      "path": "/api/online-stats/servers",
      "scope": "server",
      "module": "online-stats.statistics"
    },
    {
      "id": "online-stats.get.online.stats.hourly",
      "method": "GET",
      "path": "/api/online-stats/hourly",
      "scope": "server",
      "module": "online-stats.statistics"
    },
    {
      "id": "online-stats.get.online.stats.ranking",
      "method": "GET",
      "path": "/api/online-stats/ranking",
      "scope": "server",
      "module": "online-stats.statistics"
    },
    {
      "id": "online-stats.get.online.stats.ranking.stats",
      "method": "GET",
      "path": "/api/online-stats/ranking-stats",
      "scope": "server",
      "module": "online-stats.statistics"
    },
    {
      "id": "online-stats.get.online.stats.playtime",
      "method": "GET",
      "path": "/api/online-stats/playtime",
      "scope": "server",
      "module": "online-stats.statistics"
    },
    {
      "id": "online-stats.get.online.stats.all.playtime",
      "method": "GET",
      "path": "/api/online-stats/all-playtime",
      "scope": "server",
      "module": "online-stats.statistics"
    }
  ],
  "features": []
}
