/**
 * 玩家管理插件（cordis）—— 后端代理层
 *
 * 职责：
 *   - 把前端 /api/players/* 请求代理到目标服务器 TShock REST /data/players/*
 *     （由同包 Players.dll 提供，经 TsWebHost 下发热加载）
 *   - PATCH 语义：JSON Patch（RFC 6902）ops 数组经 query 透传，自由编辑任意字段
 *   - 全部路由 admin 鉴权（verifyAuth + requireAdmin），复用 ctx.tshock.fetchFor 多服代理
 *
 * 依赖：webServer / auth / servers / tshock
 */
import { readFileSync } from 'node:fs'
export const name = 'players'
export const inject = ['webServer', 'auth', 'servers', 'tshock']

/** 包内版本号：随包发布的 package.json 为准，便于日志/排障确认实际运行的版本 */
const PKG_VERSION = JSON.parse(
  readFileSync(new URL('./package.json', import.meta.url), 'utf8')
).version

export function apply(ctx) {
  const app = ctx.webServer.app
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]

  /** 解析目标服务器：优先 x-server-id 头，其次 query serverId，缺省取第一台 */
  function resolveServer(req) {
    const id = req.headers['x-server-id'] || (req.query && req.query.serverId)
    if (id) {
      const raw = ctx.servers.getRaw(String(id))
      if (raw) return raw
      const err = new Error('目标服务器不存在')
      err.status = 404
      throw err
    }
    const list = ctx.servers.list()
    if (list.length === 0) {
      const err = new Error('尚未配置任何服务器')
      err.status = 400
      throw err
    }
    return list[0]
  }

  /** 统一代理：转发到 TShock REST，透传其状态码与 JSON 数据 */
  async function proxy(res, server, pathname, params) {
    try {
      const result = await ctx.tshock.fetchFor(server, pathname, params)
      res.status(result.status || (result.ok ? 200 : 500)).json(result.data || { error: '空响应' })
    } catch (err) {
      res.status(err.status || (err.type === 'timeout' ? 504 : 502)).json({ error: err.message })
    }
  }

  // 玩家账号列表 / 搜索 / 筛选 / 分页
  app.get('/api/players/list', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/players/list', {
        page: q.page, pageSize: q.pageSize,
        keyword: q.keyword, username: q.username,
        onlineOnly: q.onlineOnly, hasCharacter: q.hasCharacter,
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 玩家详情（完整文档：account + stats + inventory）
  app.get('/api/players/:username', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      await proxy(res, server, '/data/players/detail', { player: req.params.username })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // JSON Patch 自由编辑（body: { ops: [...] }，转 query ops 透传）
  app.patch('/api/players/:username', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      const ops = (req.body && req.body.ops) || []
      await proxy(res, server, '/data/players/patch', {
        player: req.params.username,
        ops: JSON.stringify(ops),
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 单账号重复 IP 检测
  app.get('/api/players/duplicateips', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      await proxy(res, server, '/data/players/duplicateips', { username: (req.query || {}).username })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 全量重复 IP 聚类
  app.get('/api/players/allduplicateips', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      await proxy(res, server, '/data/players/allduplicateips', {})
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // ── P0 管理操作（转 Players.dll AdminActions 端点，不走 rawcmd）──

  // 踢出在线玩家
  app.get('/api/players/kick', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/players/kick', { player: q.player, reason: q.reason })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 封禁（acc+uuid+ip 三重 + 踢在线）
  app.get('/api/players/ban', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/players/ban', { player: q.player, reason: q.reason })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 解封
  app.get('/api/players/unban', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/players/unban', {
        ticket: q.ticket, fullDelete: q.fullDelete,
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 清角色（删 SSC + 在线重建初始）
  app.get('/api/players/clearcharacter', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/players/clearcharacter', { player: q.player })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 改密码
  app.get('/api/players/password', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/players/password', {
        player: q.player, password: q.password,
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 改组
  app.get('/api/players/group', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/players/group', { player: q.player, group: q.group })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 全部用户组名（用户组切换下拉）
  app.get('/api/players/groups', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      await proxy(res, server, '/data/players/groups', {})
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 互动操作命令（私聊/传送/给物品）：转 TShock /v3/server/rawcmd
  app.post('/api/players/command', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      const cmd = (req.body || {}).cmd
      if (!cmd || !String(cmd).trim()) return res.status(400).json({ error: '命令不能为空' })
      const result = await ctx.tshock.fetchFor(server, '/v3/server/rawcmd', { cmd: String(cmd) })
      if (result.ok) return res.json(result.data)
      res.status(result.status || 502).json({ error: `TShock REST 返回 ${result.status}`, detail: result.data })
    } catch (err) {
      res.status(err.status || 502).json({ error: err.message, type: err.type || 'network' })
    }
  })

  // 改名
  app.get('/api/players/rename', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/players/rename', { player: q.player, newName: q.newName })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // UUID 管理（uuid 空 = 清除）
  app.get('/api/players/uuid', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/players/uuid', { player: q.player, uuid: q.uuid || '' })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 删除账号
  app.get('/api/players/delete', ...admin, async (req, res) => {
    try {
      const server = resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/players/delete', { player: q.player, deleteCharacter: q.deleteCharacter })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  console.log(`[players] 玩家管理后端已挂载 v${PKG_VERSION}（/api/players/*）`)
}
