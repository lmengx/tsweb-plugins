# world-preview（世界预览）

从 Base 插件剥离出来的世界预览能力，独立发布、按需安装。

## 目录职责

| 路径 | 说明 |
|------|------|
| `assets/world-v1/` | 图格贴图（1138 张 PNG）、`properties.json`、`blendrules.json.gz`；宿主静态服务地址 `/plugins/world-preview/assets/` |
| `ui/world/` | 前端渲染器源码（`world-renderer.js`、`TilePreview.vue`、`WorldSnapshotLayer.vue`、`ClientMapLayer.vue`、`map-data.js`、`geometry.js`、`client-map.js`）。**只在源码树内供消费插件构建期引用，不随包发布**（打包器跳过 `ui/`） |
| `world-map.js` | Node 半：`WorldMapService`，提供 cordis 服务 `worldMap`（历史/房屋通过 `inject` 使用），负责按服务器转发到游戏服 `/data/world-preview/map*` |
| `building-preview.js` / `building-codec.js` | 建筑存档（`.tsb/.trb`）解码与预览切片，供房屋插件使用 |
| `plugin/` | C# 半：`WorldPreview.dll`（地图区块采集、PNG 编码、任务队列） |

## 运行期约定

- 本插件没有可视页面、没有前端口 bundle；`ui/world/` 由 `history` 与 `house` 在构建时打包进各自的 dist。
- 前端渲染器写死的资产基址是 `/plugins/world-preview/assets/world-v1/`；未安装或停用本插件时预览会 404，因此**必须先安装并启用本插件**。
- 依赖它的插件在 `package.json` 里声明 `tsweb.requires: ["world-preview"]`；市场安装时会先确认并安装依赖。
- 卸载保护：只要已安装的插件仍声明依赖它，注册表拒绝卸载（会提示先卸载/更新依赖方）。
- 游戏服侧：`WorldPreview.dll` 随插件启用按哈希自动同步到各服务器；未就绪时地图接口返回“游戏服尚未启用新版 WorldPreview.dll”。

## 版本与依赖

- 资产与前端渲染器、Node 服务、游戏服 DLL 都属于同一个插件包；升级其中任何一部分都要求三端同版本。
- 新建 `history` / `house` 包时必须先在源码树中具备本插件的 `ui/world/` 源码（构建期引用），并提升本插件版本时同步升消费方版本。
