export { decodeBuilding, MAX_BUILDING_BYTES, MAX_BUILDING_TILES } from "./building-codec.js";
import { createRequire } from "node:module";
import { gzipSync } from "node:zlib";
import { readFileSync } from "node:fs";
const metadata = JSON.parse(
  readFileSync(
    new URL("./assets/world-v1/properties.json", import.meta.url),
    "utf8",
  ),
);
const framed = new Set(
  metadata.tiles.filter((t) => t.isFramed).map((t) => t.id),
);
const tileColors = new Map(metadata.tiles.map((t) => [t.id, t.color])),
  wallColors = new Map(metadata.walls.map((w) => [w.id, w.color]));
const bad = (message) => Object.assign(new Error(message), { status: 422 });
/** raw14 is column-major; Base snapshots are row-major, including actual edge chunk width. */
export function buildingChunk(building, cx, cy) {
  if (
    !Number.isInteger(cx) ||
    !Number.isInteger(cy) ||
    cx < 0 ||
    cy < 0 ||
    cx * 128 >= building.width ||
    cy * 128 >= building.height
  )
    throw bad("存档区块坐标无效");
  const w = Math.min(128, building.width - cx * 128),
    h = Math.min(128, building.height - cy * 128),
    out = Buffer.alloc(w * h * 16),
    raw = building.raw;
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const i = ((cx * 128 + x) * building.height + cy * 128 + y) * 14,
        o = (y * w + x) * 16,
        id = raw.readUInt16LE(i),
        s = raw.readUInt16LE(i + 5),
        b = raw[i + 7],
        c = raw[i + 9],
        liquid = raw[i + 4],
        shape = s & 0x400 ? 1 : (s >> 12) & 7 ? ((s >> 12) & 7) + 1 : 0;
      out.writeUInt16LE(s & 0x20 ? id + 1 : 0, o);
      out.writeUInt16LE(raw.readUInt16LE(i + 2), o + 2);
      out.writeInt16LE(framed.has(id) ? raw.readInt16LE(i + 10) : -1, o + 4);
      out.writeInt16LE(framed.has(id) ? raw.readInt16LE(i + 12) : -1, o + 6);
      out[o + 8] =
        (s & 0x80 ? 2 : 0) |
        (s & 0x100 ? 4 : 0) |
        (s & 0x200 ? 8 : 0) |
        (shape << 4);
      out[o + 9] =
        (s & 0x800 ? 2 : 0) | (s & 0x40 ? 4 : 0) | (b & 0x80 ? 32 : 0);
      out[o + 10] =
        (c & 0x20 ? 2 : 0) |
        (c & 0x40 ? 4 : 0) |
        (c & 0x80 ? 8 : 0) |
        (s & 0x8000 ? 16 : 0);
      out[o + 11] = s & 31;
      out[o + 12] = b & 31;
      out[o + 13] = liquid;
      out[o + 14] = liquid ? ((b >> 5) & 3) + 1 : 0;
    }
  return gzipSync(out).toString("base64");
}
export async function buildingOverview(building) {
  const sharp = createRequire(import.meta.url)("sharp");
  const out = Buffer.alloc(building.width * building.height * 4);
  for (let x = 0; x < building.width; x++)
    for (let y = 0; y < building.height; y++) {
      const i = (x * building.height + y) * 14,
        o = (y * building.width + x) * 4,
        s = building.raw.readUInt16LE(i + 5),
        wall = building.raw.readUInt16LE(i + 2);
      const color =
        (s & 0x20
          ? tileColors.get(building.raw.readUInt16LE(i))
          : wallColors.get(wall)) || "#6397BAFF";
      out[o] = parseInt(color.slice(1, 3), 16);
      out[o + 1] = parseInt(color.slice(3, 5), 16);
      out[o + 2] = parseInt(color.slice(5, 7), 16);
      out[o + 3] = 255;
    }
  return (
    await sharp(out, {
      raw: { width: building.width, height: building.height, channels: 4 },
    })
      .png()
      .toBuffer()
  ).toString("base64");
}
