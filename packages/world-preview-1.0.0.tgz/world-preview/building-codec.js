import { gunzipSync } from "node:zlib";
import { createHash } from "node:crypto";
export const MAX_BUILDING_BYTES = 32 * 1024 * 1024,
  MAX_BUILDING_TILES = 1024 * 1024;
const bad = (message) => Object.assign(new Error(message), { status: 422 });
const show = (value) => value === undefined ? '缺失' : value === null ? 'null' : typeof value === 'object' ? (Array.isArray(value) ? '数组' : '对象') : JSON.stringify(value).slice(0, 100);
/** Older Hero exports use jsonSize/jsonTile/etc. for the same v1 sections. */
export function parseBuildingDocument(input) {
  if (!Buffer.isBuffer(input)) throw bad('建筑文件内容无效：需要二进制文件数据');
  if (input.length > MAX_BUILDING_BYTES)
    throw bad(`建筑文件超过 32 MiB：实际 ${input.length} 字节，上限 ${MAX_BUILDING_BYTES} 字节，请缩小区域后重新导出`);
  if (!input.length) throw bad('建筑文件为空：请重新导出非空 .trb 建筑文件');
  let doc;
  try {
    doc = JSON.parse(input.toString("utf8").replace(/^\uFEFF/, ""));
  } catch (error) {
    const position = /position (\d+)(?: \(line (\d+) column (\d+)\))?/.exec(error.message);
    const where = position ? `（字符位置 ${position[1]}${position[2] ? `，第 ${position[2]} 行第 ${position[3]} 列` : ''}）` : '';
    throw bad(`建筑文件不是有效 JSON${where}：需要 UTF-8 编码的 tsweb-building v1 文件，请检查是否下载完整或误选了世界 / 压缩包文件；仅修改扩展名不能转换其它格式`);
  }
  if (doc && typeof doc === 'object' && !Array.isArray(doc)) {
    for (const key of ['size', 'tile', 'meta', 'compat', 'entities']) {
      const legacy = 'json' + key[0].toUpperCase() + key.slice(1);
      if (!Object.hasOwn(doc, key) && Object.hasOwn(doc, legacy)) doc[key] = doc[legacy];
    }
  }
  return doc;
}
/** Decode saved building contents, never consult the current game world or expose entity inventory. */
export function decodeBuilding(input) {
  const doc = parseBuildingDocument(input);
  const w = doc?.size?.width,
    h = doc?.size?.height,
    t = doc?.tile;
  if (doc?.format !== 'tsweb-building') throw bad(`建筑格式无效：format 应为 "tsweb-building"，实际 ${show(doc?.format)}；请使用房屋 / 建筑导出或兼容的 TRB 导出功能`);
  if (doc.formatVersion !== 1) throw bad(`建筑版本不支持：formatVersion 应为 1，实际 ${show(doc.formatVersion)}；请按 tsweb-building v1 重新导出`);
  if (
    !Number.isInteger(w) ||
    !Number.isInteger(h) ||
    w < 1 ||
    h < 1 ||
    w > 4096 ||
    h > 4096 ||
    w * h > MAX_BUILDING_TILES
  )
    throw bad(`建筑尺寸无效：size.width=${show(w)}、size.height=${show(h)}，宽高须为 1 至 4096 的整数，总图格最多 ${MAX_BUILDING_TILES} 格；请缩小导出区域或修复尺寸字段`);
  if (!t || typeof t !== 'object') throw bad('建筑图格数据缺失：需要 tile 对象（encoding、compression、expectedCount、data、checksum），请重新导出原始建筑文件');
  if (t.encoding !== 'raw14') throw bad(`建筑图格编码无效：tile.encoding 应为 "raw14"（每格 14 字节），实际 ${show(t.encoding)}；请使用兼容的 TRB 导出格式`);
  if (!['none', 'gzip'].includes(t.compression)) throw bad(`建筑压缩方式不支持：tile.compression 应为 "none" 或 "gzip"，实际 ${show(t.compression)}`);
  if (t.expectedCount !== w * h) throw bad(`建筑图格数量不符：tile.expectedCount=${show(t.expectedCount)}，尺寸 ${w}×${h} 应有 ${w * h} 格；请重新导出，勿单独修改尺寸`);
  if (typeof t.data !== 'string' || !t.data.length || t.data.length > (MAX_BUILDING_BYTES * 4) / 3 + 4 || t.data.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/.test(t.data))
    throw bad('建筑图格编码无效：tile.data 需要非空、完整的 Base64 数据且不得超过文件上限，请重新上传或导出');
  let raw;
  try {
    const b = Buffer.from(t.data, "base64");
    if (b.toString('base64') !== t.data) throw bad('建筑图格编码无效：tile.data 的 Base64 数据不完整或编码不规范');
    raw =
      t.compression === "gzip"
        ? gunzipSync(b, { maxOutputLength: w * h * 14 })
        : b;
  } catch (error) {
    if (error.status) throw error;
    throw bad(`图格解压失败：${error.code === 'ERR_BUFFER_TOO_LARGE' ? '解压结果超过声明尺寸' : 'gzip 数据损坏、截断或与声明的压缩方式不符'}；声明 ${w}×${h} 格，应为 ${w * h * 14} 字节，请重新导出完整文件`);
  }
  if (raw.length !== w * h * 14) throw bad(`图格长度校验失败：解码后实际 ${raw.length} 字节，尺寸 ${w}×${h} 的 raw14 应为 ${w * h * 14} 字节；请检查文件是否截断并重新导出`);
  if (typeof t.checksum !== 'string' || !/^[a-f0-9]{64}$/i.test(t.checksum)) throw bad('图格 SHA-256 校验失败：tile.checksum 缺失或不是 64 位十六进制摘要，请重新导出完整文件');
  if (createHash('sha256').update(raw).digest('hex') !== t.checksum.toLowerCase()) throw bad('图格 SHA-256 校验失败：图格内容与 tile.checksum 不一致，文件可能损坏或被修改，请重新上传原始文件或重新导出');
  for (let i = 0; i < raw.length; i += 14) {
    const header = raw.readUInt16LE(i + 5);
    if (((header >> 12) & 7) > 4) throw bad(`图格斜坡类型无效：X=${Math.floor(i / 14 / h)}、Y=${i / 14 % h} 的斜坡值为 ${(header >> 12) & 7}，允许 0 至 4；请检查导出器 raw14 编码`);
    if (header & 0x20 && raw.readUInt16LE(i) === 65535)
      throw bad(`图格 ID 超过预览编码范围：X=${Math.floor(i / 14 / h)}、Y=${i / 14 % h} 的活动图格 ID 为 65535，请使用当前游戏版本兼容的建筑重新导出`);
  }
  return {
    raw,
    width: w,
    height: h,
    meta: {
      name: String(doc.meta?.name || ""),
      author: String(doc.meta?.author || ""),
      createdAt: String(doc.meta?.createdAt || ""),
      source: doc.meta?.source?.world || "",
      entities: Array.isArray(doc.entities) ? doc.entities.length : 0,
    },
    hash: createHash("sha256").update(input).digest("hex"),
  };
}
