# 旧版 QQ 数据导入

旧版 Koishi/TsWeb 使用的绑定表位置是：

```text
C:\Users\lyt\Documents\GitHub\TsWeb\TsWeb\backend\data\qq_accounts.json
```

本地开发实例的导入副本位置是：

```text
C:\Users\lyt\Documents\GitHub\TsWeb\tsweb-cordis\data\legacy-import\qq_accounts.json
```

管理面打开“旧版数据导入”，选择模块“旧版 QQ 台账”，先执行试运行，再执行正式导入。导入会写入统一的 `qq-bind` 台账，不会覆盖已有角色或 QQ 冲突记录。

本次删除旧版原表前的完整备份位置是：

```text
C:\Users\lyt\Documents\GitHub\TsWeb\tsweb-cordis\data\migration-backups\qq_accounts.json.before-delete-20261026-202527.json
```
