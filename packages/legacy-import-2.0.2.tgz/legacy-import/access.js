// Module permissions authorize both UI features and their backend routes.
export default {
  "owner": "legacy-import",
  "version": 2,
  "modules": [
    {
      "id": "legacy-import.legacy-import",
      "permission": "legacy-import.ui.legacy-import",
      "title": "旧数据导入",
      "roles": [
        "superadmin"
      ],
      "scope": "global",
      "requires": [
        "legacy-import.get.legacy.import.modules",
        "legacy-import.post.legacy.import.run",
        "legacy-import.get.legacy.import.history"
      ]
    }
  ],
  "actions": [
    {
      "id": "legacy-import.get.legacy.import.modules",
      "method": "GET",
      "path": "/api/legacy-import/modules",
      "scope": "global",
      "module": "legacy-import.legacy-import"
    },
    {
      "id": "legacy-import.post.legacy.import.run",
      "method": "POST",
      "path": "/api/legacy-import/run",
      "scope": "global",
      "module": "legacy-import.legacy-import"
    },
    {
      "id": "legacy-import.get.legacy.import.history",
      "method": "GET",
      "path": "/api/legacy-import/history",
      "scope": "global",
      "module": "legacy-import.legacy-import"
    }
  ],
  "features": [
    {
      "id": "legacy-import:legacy-import",
      "module": "legacy-import.legacy-import",
      "requires": [
        "legacy-import.get.legacy.import.modules",
        "legacy-import.post.legacy.import.run",
        "legacy-import.get.legacy.import.history"
      ]
    }
  ]
}
