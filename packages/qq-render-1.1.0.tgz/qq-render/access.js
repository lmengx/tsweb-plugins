export default {
  owner: 'qq-render',
  version: 2,
  modules: [],
  actions: [],
  features: [],
}
