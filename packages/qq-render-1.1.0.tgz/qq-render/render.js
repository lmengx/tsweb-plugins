import sharp from 'sharp'

const palettes = {
  space: {
    paper: '#0b1426',
    ink: '#e5edff',
    muted: '#8d9dbd',
    accent: '#88b6ff',
    rule: '#26324d',
    tile: '#182b48',
    panel: '#111e34',
    radius: 16,
  },
  pixel: {
    paper: '#242b37',
    ink: '#f2ecd9',
    muted: '#b0b6ae',
    accent: '#e9cc8d',
    rule: '#46514c',
    tile: '#35433c',
    panel: '#323d41',
    radius: 0,
  },
  cream: {
    paper: '#fbf2e7',
    ink: '#543e35',
    muted: '#937769',
    accent: '#a3583d',
    rule: '#e7d8c8',
    tile: '#f2e4d5',
    panel: '#fffaf3',
    radius: 28,
  },
}
const xml = (value) =>
  String(value).replace(
    /[&<>"']/g,
    (char) =>
      ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&apos;',
      })[char],
  )
const widthOf = (value, size) =>
  Array.from(String(value)).reduce(
    (sum, char) =>
      sum +
      (/[^\x00-\xff]/.test(char) ? 1 : /[ilI1.,: ]/.test(char) ? 0.32 : 0.62) *
        size,
    0,
  )
function wrap(value, width, size) {
  const result = []
  let line = ''
  for (const char of String(value)) {
    if (line && widthOf(line + char, size) > width) {
      result.push(line)
      line = ''
    }
    line += char
  }
  result.push(line)
  return result
}
const rect = (x, y, width, height, fill, radius = 0, stroke) =>
  '<rect x="' +
  x +
  '" y="' +
  y +
  '" width="' +
  width +
  '" height="' +
  height +
  '" rx="' +
  radius +
  '" fill="' +
  fill +
  '"' +
  (stroke ? ' stroke="' + stroke + '"' : '') +
  '/>'
const text = (x, y, value, size, fill, weight = 400, anchor = 'start') =>
  '<text x="' +
  x +
  '" y="' +
  y +
  '" font-size="' +
  size +
  '" fill="' +
  fill +
  '" font-weight="' +
  weight +
  '" text-anchor="' +
  anchor +
  '">' +
  xml(value) +
  '</text>'
const line = (x1, y1, x2, y2, color) =>
  '<path d="M ' + x1 + ' ' + y1 + ' H ' + x2 + '" stroke="' + color + '"/>'
function chips(players) {
  let x = 0,
    y = 0,
    rowHeight = 0
  const parts = []
  for (const name of players) {
    const lines = wrap(name, 710, 21),
      w = Math.min(
        742,
        Math.max(64, ...lines.map((value) => widthOf(value, 21) + 26)),
      ),
      h = lines.length * 29 + 14
    if (x && x + w > 816) {
      y += rowHeight + 10
      x = 0
      rowHeight = 0
    }
    parts.push({ x, y, w, h, lines })
    x += w + 10
    rowHeight = Math.max(rowHeight, h)
  }
  return { parts, height: y + rowHeight }
}
function blocks(data, kind) {
  if (!data.rows.length) return [{ empty: true, height: 140 }]
  return data.rows.flatMap((row, index) => {
    const title = wrap(row.name, 660, 25),
      addresses = wrap(row.address, 680, 23)
    if (kind === 'servers')
      return [
        {
          row,
          index,
          title,
          addresses,
          height: Math.max(145, 75 + title.length * 34 + addresses.length * 31),
        },
      ]
    if (!row.available || !row.players.length)
      return [{ row, index, title, height: 80 + title.length * 32 }]
    const chunks = []
    for (let start = 0; start < row.players.length;) {
      let end = start + 1,
        layout = chips(row.players.slice(start, end))
      while (end < row.players.length && end - start < 24) {
        const candidate = chips(row.players.slice(start, end + 1))
        if (candidate.height > 1000) break
        layout = candidate
        end++
      }
      chunks.push({
        row,
        index,
        title,
        layout,
        continued: start > 0,
        height: 76 + title.length * 32 + layout.height,
      })
      start = end
    }
    return chunks
  })
}
function scenery() {
  return (
    '<g transform="translate(0 247)">' +
    rect(0, 0, 960, 92, '#34334c') +
    rect(792, 13, 23, 23, '#f0dca8') +
    '<path fill="#48465c" d="M0 65H76V48H144V25H210V48H284V34H362V56H440V28H512V48H620V23H686V49H796V67H870V41H960V92H0Z"/><path fill="#455749" d="M0 78H90V65H160V52H210V66H310V57H380V75H500V60H584V43H648V64H734V57H830V72H960V92H0Z"/>' +
    rect(0, 79, 960, 13, '#705843') +
    rect(0, 76, 960, 6, '#87a45e') +
    rect(172, 47, 7, 31, '#a07850') +
    rect(151, 26, 43, 32, '#709960') +
    rect(161, 18, 35, 22, '#709960') +
    rect(856, 47, 6, 31, '#a07850') +
    rect(838, 29, 36, 29, '#709960') +
    '</g>'
  )
}
export function renderSvgPages(data, kind = 'servers', theme = 'pixel') {
  if (!Object.hasOwn(palettes, theme) || !['servers', 'players'].includes(kind))
    throw Object.assign(new Error('渲染风格或图片类型无效'), { status: 400 })
  const p = palettes[theme],
    pixel = theme === 'pixel',
    startY = pixel ? 365 : 260
  const prepared = blocks(data, kind),
    pages = [[]]
  let used = startY
  for (const block of prepared) {
    if (used + block.height + 100 > 1900 && pages.at(-1).length) {
      pages.push([])
      used = startY
    }
    pages.at(-1).push(block)
    used += block.height + 14
  }
  const total = data.rows
      .filter((row) => row.available)
      .reduce((sum, row) => sum + row.players.length, 0),
    responding = data.rows.filter((row) => row.available).length,
    partial = responding !== data.rows.length
  const date = new Date(data.generatedAt),
    stamp = Number.isFinite(date.getTime())
      ? new Intl.DateTimeFormat('zh-CN', {
          timeZone: 'Asia/Shanghai',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
          hour12: false,
        }).format(date)
      : '时间未知'
  return pages.map((page, pageIndex) => {
    const height = Math.max(
      670,
      startY + page.reduce((sum, block) => sum + block.height + 14, 0) + 100,
    )
    let body = rect(0, 0, 960, height, p.paper, p.radius)
    if (theme === 'space') {
      for (let x = 0; x < 960; x += 32)
        body +=
          '<path d="M' +
          x +
          ' 0V' +
          height +
          '" stroke="#789cff" opacity="0.035"/>'
      for (let y = 0; y < height; y += 32) body += line(0, y, 960, y, '#14233d')
    }
    if (pixel) body += rect(6, 6, 948, height - 12, 'none', 0, p.rule)
    body += text(
      48,
      52,
      theme === 'space'
        ? 'TSWEB / SERVER NETWORK'
        : pixel
          ? 'PICK A WORLD / START AN ADVENTURE'
          : 'A LITTLE GUIDE TO OUR WORLDS',
      13,
      p.muted,
    )
    if (data.sample) body += text(912, 52, 'DEMO', 13, p.accent, 400, 'end')
    body += text(
      48,
      108,
      kind === 'players' ? '全服在线玩家' : '服务器列表',
      19,
      p.accent,
    )
    body += text(
      48,
      166,
      kind === 'players' ? '此刻，一起冒险。' : '下一站，去哪里？',
      47,
      p.ink,
      700,
    )
    body += text(
      48,
      204,
      kind === 'players'
        ? '每一个世界，都有正在发生的故事。'
        : '找到你的世界，和朋友一起出发。',
      17,
      p.muted,
    )
    if (theme !== 'pixel')
      body += rect(
        766,
        87,
        146,
        132,
        theme === 'cream' ? '#f0ddc9' : '#192845',
        theme === 'cream' ? 26 : 0,
      )
    body += text(
      890,
      119,
      kind === 'players' ? (partial ? '已确认在线' : '全服在线') : '可用服务器',
      14,
      p.muted,
      400,
      'end',
    )
    body +=
      text(
        857,
        185,
        kind === 'players' ? total : responding,
        65,
        p.accent,
        400,
        'end',
      ) +
      text(
        871,
        183,
        kind === 'players' ? '人' : '/ ' + data.rows.length,
        18,
        p.muted,
      )
    if (pixel) body += scenery()
    let y = startY
    if (partial) {
      body += text(
        48,
        y - 14,
        '部分服务器未响应 · ' +
          responding +
          '/' +
          data.rows.length +
          ' 已响应，未知人数不计为 0',
        15,
        p.muted,
      )
    }
    for (const block of page) {
      if (block.empty) {
        body += text(
          48,
          y + 54,
          '暂无启用的服务器，请先在后台添加服务器。',
          23,
          p.muted,
        )
        y += block.height + 14
        continue
      }
      const { row, index, title } = block
      if (kind === 'servers') {
        body += rect(
          48,
          y,
          864,
          block.height,
          p.panel,
          theme === 'cream' ? 18 : pixel ? 0 : 8,
        )
        if (pixel) body += rect(48, y, 4, block.height, '#879b69')
        body += text(
          66,
          y + 36,
          String(index + 1).padStart(2, '0'),
          16,
          p.muted,
        )
        title.forEach((value, i) => {
          body += text(106, y + 38 + i * 34, value, 25, p.ink, 700)
        })
        block.addresses.forEach((value, i) => {
          body += text(
            106,
            y + 43 + title.length * 34 + i * 31,
            value,
            23,
            p.accent,
          )
        })
        body += text(
          890,
          y + 37,
          row.available ? '● 在线' : '未响应',
          15,
          row.available ? (theme === 'cream' ? '#59785d' : '#aecbba') : p.muted,
          400,
          'end',
        )
        body += text(
          890,
          y + 79,
          row.available ? row.players.length + ' 人' : '人数未知',
          21,
          p.ink,
          400,
          'end',
        )
      } else {
        if (theme === 'cream')
          body += rect(48, y, 864, block.height, p.panel, 18)
        else body += line(48, y, 912, y, p.rule)
        body += text(
          65,
          y + 34,
          String(index + 1).padStart(2, '0'),
          14,
          p.muted,
        )
        title.forEach((value, i) => {
          body += text(
            106,
            y + 36 + i * 32,
            value + (block.continued && i === title.length - 1 ? ' · 续' : ''),
            23,
            p.ink,
            700,
          )
        })
        body += text(
          890,
          y + 34,
          row.available ? row.players.length + ' 人' : '状态未知',
          16,
          p.muted,
          400,
          'end',
        )
        if (block.layout)
          for (const chip of block.layout.parts) {
            const cy = y + 50 + title.length * 32 + chip.y
            body += rect(
              65 + chip.x,
              cy,
              chip.w,
              chip.h,
              p.tile,
              theme === 'cream' ? 21 : pixel ? 0 : 5,
              pixel ? p.rule : undefined,
            )
            chip.lines.forEach((value, i) => {
              body += text(78 + chip.x, cy + 28 + i * 29, value, 21, p.ink)
            })
          }
        else
          body += text(
            65,
            y + 54 + title.length * 32,
            row.available
              ? '暂时没有玩家，等你来探索。'
              : '暂未响应，未计入在线人数。',
            19,
            p.muted,
          )
      }
      y += block.height + 14
    }
    body +=
      line(48, height - 67, 912, height - 67, p.rule) +
      text(
        48,
        height - 31,
        'TSWEB / ' +
          (kind === 'players' ? '跨服在线一览' : '游戏连接地址') +
          (data.sample ? ' · 演示数据' : ''),
        13,
        p.muted,
      ) +
      text(
        912,
        height - 31,
        stamp + ' · ' + (pageIndex + 1) + '/' + pages.length,
        13,
        p.muted,
        400,
        'end',
      )
    return (
      '<svg xmlns="http://www.w3.org/2000/svg" width="960" height="' +
      height +
      '" viewBox="0 0 960 ' +
      height +
      '"><g font-family="Microsoft YaHei,Noto Sans CJK SC,WenQuanYi Zen Hei,sans-serif">' +
      body +
      '</g></svg>'
    )
  })
}
export async function renderPages(data, kind, theme) {
  const images = []
  for (const svg of renderSvgPages(data, kind, theme))
    images.push(await sharp(Buffer.from(svg)).png().toBuffer())
  return images
}
