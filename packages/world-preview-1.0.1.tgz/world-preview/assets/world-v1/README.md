# 世界贴图资源 v1

本目录是详细地图的静态资源，不包含世界存档、玩家资料、箱子内容或服务器凭据。

- 游戏贴图来自本机已安装的 Terraria 1.4.5.8 `Content/Images` XNB，转为 PNG；包含 764 张 `Tiles_*`、367 张 `Wall_*`（含边框）及树冠、树枝、遗物等辅助纹理，共 1138 张 PNG。
- `properties.json` 与 `blendrules.json.gz` 来自本地 TEdit 图格元数据、`TileFraming` / `BlendRules` 参考，沿用已验收快照原型的规则表。
- 运行时 URL 为 `/plugins/world-preview/assets/world-v1/`，由宿主按插件目录静态服务提供；打包器会包含 `assets/`。
- 压缩规则表按 gzip 文件读取后用 `DecompressionStream` 解压；普通静态服务不得把文件内容当成 HTTP 已解压的 JSON。
- 当前按需解码和绘制；油漆、涂层、部分特殊帧、其他树种、动态光照和动画并未完整复刻。图格数据保留这些字段供检查，不将画面称为游戏客户端的精确截图。

来源于现有游戏资源，版权归各原作者；本次工作未生成替代美术。
