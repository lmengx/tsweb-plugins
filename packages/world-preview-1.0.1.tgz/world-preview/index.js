import { WorldMapService } from './world-map.js?v=1.0.1'

/**
 * 世界预览插件（world-preview）
 *
 * 原先是 Base 插件的一部分：地图贴图资产、前端渲染器源码、建筑预览解码，
 * 以及游戏服侧 WorldMap.dll 的地图采集。现在独立成插件：
 *   - 资产：assets/world-v1/**（地图贴图与拼接元数据），由宿主静态服务挂在
 *     /plugins/world-preview/assets/ 下；
 *   - Node 半：提供 cordis 服务 `worldMap`（history / house 通过 inject 使用）；
 *   - C# 半：WorldPreview.dll，注册 /data/world-preview/map*，读当前世界图格。
 *
 * 依赖关系（由市场安装依赖机制保证，不是软依赖）：
 *   history、house 的 package.json 声明 tsweb.requires: ["world-preview"]；
 *   市场在安装它们时若本机没有 world-preview，会先弹窗确认再下载安装本插件。
 */

export const name = 'world-preview'
// 地图数据来自游戏服：servers 提供服务器记录与 token，tshock 提供带鉴权的 REST 转发。
export const inject = ['servers', 'tshock']

export function apply(ctx) {
  try {
    const worldMap = new WorldMapService(ctx)
    try {
      ctx.provide('worldMap', worldMap)
    } catch (err) {
      // 旧版 base（<=2.3.x）仍自带世界预览并提供同名服务，这里会撞车。
      // 与其让插件停在 failed，不如给出可执行的升级指引。
      throw new Error('worldMap 服务已被其它插件提供（旧版 base 仍自带世界预览时会出现）：请先把 base 更新到 2.4.0 或更高版本再启用本插件。原始错误：' + err.message)
    }
    ctx.effect(() => () => { worldMap.disposed = true })
    console.log('[world-preview] 世界预览服务已就绪')
  } catch (err) {
    // cordis 对"等待 inject 后才执行"的插件，apply 异常不会冒泡到加载器，必须在此显式记录
    console.error('[world-preview] 初始化失败: ' + err.message)
    throw err
  }
}
