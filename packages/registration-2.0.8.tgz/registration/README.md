# 注册登录控制

`registration` 的后端、Vue 页面和 `TsWebRegistration.dll` 提供普通玩家的默认注册、自动注册及白名单准入。默认保持 TShock 原生注册。配置直接读取、保存至所选游戏服 `tshock/TSWeb/Registration.json`，不在后端维护另一份。不读取旧版配置；不支持的 schema 报错并保留原文件。

注册登录页面在「更多插件」中。权限模块为 `registration.settings`，默认 superadmin/admin，可按账号追加并限制服务器范围。普通账号的进服密码验证、开关和踢出文本均由本插件管理，QQ 角色交由 QQ 插件验证；未登录玩家人工登录功能不在本插件中。

## QQ 接管

QQ 插件初始化登录处理器时，以 `shared/LoginProviders.cs` 的版本 1 契约发布 `qq-bind` 接管声明，卸载时撤销。该文件分别编译进两个 DLL，同进程使用 AppDomain 存放的 BCL 字典共享回调，不引用对方 DLL，不依赖后端或 Host。

每次连接及手动注册都实时询问声明：0 为普通角色，1 为 QQ 验证接管，2 为绑定名已保留但验证不可用。1 直接交 QQ 验证，不因本地 Users 缺号被白名单拒绝，也不由自动注册创建账户。2 拒绝连接和手动注册，避免凭据同步关闭或验证器异常时转入自动注册。QQ 插件的接管声明使用本服当前已接收的绑定表；尚未同步的后台绑定不能凭空识别。

声明先于 QQ 登录钩子注册；先加载任一插件、单独重新加载 registration、QQ 的凭据变更均无需重新注册名单。旧实例 Dispose 只撤销自己的声明，不会删除新实例替换后的声明。所有 QQ 密码、UUID、封禁与 SSC 判断继续由 QqBind 执行。

QQ 后端服务加载时，页面下方显示：

> QQ登录会绕过白名单自动创建角色，未验证的连接无法通过自动注册抢占QQ绑定玩家的用户名

页面每 5 秒核对该服务是否仍加载，卸载后移除说明；此文案表示协作规则，不作为游戏服接收端已安装成功的凭据。需同时更新 QqBind.dll 与部署 TsWebRegistration.dll。配置响应 `qqProvider` 可核对目标服是否已有 QQ 接管声明。如果检测到旧版 QqBind 实例已加载但未声明协议，registration 暂停新连接和手动注册，页面显示版本不匹配；更新 QQ 接收端后自动恢复，避免分步升级期间抢占绑定名。

## 生命周期与边界

本插件临时替换 `/register`、`/reg`，普通默认模式转交原生处理器，QQ 接管名禁止手动注册。开启 TShock 的 `AllowRegisterAnyUsername` 时，`/register 用户名 密码` 同时检查当前角色名与目标用户名，避免普通角色抢占 QQ 绑定名。卸载恢复原命令，移除本实例钩子及 REST 路由，不删除账号和配置。

不能与旧版整套 TSWeb 的 AutoRegister 同时启用，两套处理器会重复接管注册。自动注册账号使用本服默认注册组和随机密码，保留设备 UUID，处理封禁及 SSC，触发一次 PostLogin 事件。自动注册完整消费连接包、推进连接状态并发送 WorldInfo，避免原生连接处理再次登录；开启或关闭原生 UUID 登录均适用。所有服务器侧登录控制在后台不可达时仍独立运行。

验证：`node --test plugins/registration/test/*.test.mjs plugins/qq-bind/test/credentials.test.mjs`；`node --test --test-name-pattern=registration client/test/views.test.mjs`；`npm run check:access`。QQ 凭据隔离测试同时编译并执行真实 RegistrationPolicy、RegistrationPlugin 和 QQ 登录处理器，覆盖两种钩子顺序、三种注册模式、冒名密码失败、白名单首次建号、原生命令恢复及配置迁移。新增回归检查显式注册目标名（含大小写、验证不可用状态）及普通注册保留行为；后续连接处理桩检查连接包已消费，并统计 PostLogin、SSC 恢复与 WorldInfo 次数。测试使用隔离 API 桩，不连接用户游戏服。

## 注册设置界面（2026-10-18）

还原旧版两张纵向卡片：注册模式选项与密码不匹配踢出文本，修改后 500ms 自动保存。切服和卸载取消未提交请求；保存失败保留编辑内容并提供重试。QQ 接管提示保留。

密码提示及验证开关使用独立 GET/POST `/api/registration/password-message`，受同一个注册管理模块及服务器范围保护，仅转发 `kickPasswordMessage` 与可选布尔 `enabled`。游戏服 Registration 2.0.3 的 `/data/registration/password-message` 与 `/set` 读写 `TSWeb/Registration.json`（schema 2）。注册模式、普通账号验证开关与提示文本统一落盘；同一把锁保护部分更新，先原子落盘再更新不可变内存快照，避免两张卡片同时保存时覆盖字段。

当前配置规则：只读取本版本配置；缺失时使用默认值，不读取、复制、备份或转换旧版配置。旧版导入统一由 legacy-import 插件显式执行。

普通验证器按玩家连接实例保存挑战，离服或卸载清理；正确密码校验封禁、恢复 SSC、更新 UUID 并触发一次 PostLogin，错误密码使用本插件配置的多行提示；QQ 接管名不走普通账号验证。新安装默认开启验证，升级保持原有效状态，页面可独立启停。
