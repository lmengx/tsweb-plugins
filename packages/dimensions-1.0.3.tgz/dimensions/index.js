const revision = new URL(import.meta.url).search
const { default: access } = await import(`./access.js${revision}`)
const { DimensionsService } = await import(`./service.js${revision}`)
const { WorldOnboarding } = await import(`./worlds.js${revision}`)
export const name = 'dimensions'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths', 'plugins']
export async function apply(ctx) {
  const service = new DimensionsService(ctx)
  const worlds = new WorldOnboarding(service)
  ctx.effect(() => async () => { await worlds.close(); await service.close() })
  try {
    await service.init()
    const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx)
    const wrap = execute => async (req, res) => {
      try { service.active(); const result = await execute(req); if (!res.destroyed) res.json(result) }
      catch (error) { if (!res.headersSent && !res.destroyed) res.status(error.status || 502).json({ error: error.message }) }
    }
    app.get('/api/dimensions/config', wrap(req => { service.assertScope(req.user); return { config: structuredClone(service.state.config), targetIssues: service.targetIssues() } }))
    app.put('/api/dimensions/config', wrap(req => {
      if (Array.isArray(req.body?.targets) && req.body.targets.some(row => !service.state.config.targets.some(old => old.id === row.id))) throw Object.assign(new Error('新增世界必须通过添加向导完成 DLL 与游戏协议验证'), { status: 400 })
      return service.save(req.body, req.user)
    }))
    app.get('/api/dimensions/status', wrap(req => service.status(req.user)))
    app.get('/api/dimensions/logs', wrap(req => service.logs(req.query || {}, req.user)))
    app.get('/api/dimensions/captcha-worlds', wrap(req => service.captchaWorld('list', null, req.user)))
    app.get('/api/dimensions/captcha-world', wrap(req => service.captchaWorld('read', req.query || {}, req.user)))
    app.post('/api/dimensions/captcha-world', wrap(req => service.captchaWorld('upload', req.body || {}, req.user)))
    app.delete('/api/dimensions/captcha-world', wrap(req => service.captchaWorld('remove', req.query || {}, req.user)))
    app.post('/api/dimensions/process/start', wrap(req => service.control('start', req.body || {}, req.user)))
    app.post('/api/dimensions/process/stop', wrap(req => service.control('stop', req.body || {}, req.user)))
    app.post('/api/dimensions/process/restart', wrap(req => service.control('restart', req.body || {}, req.user)))
    app.get('/api/dimensions/servers', wrap(async req => ({ servers: ctx.auth.filterServers(req.user, await ctx.servers.list()).map(row => ({ id: row.id, name: row.name, enabled: row.enabled })) })))
    app.post('/api/dimensions/reconcile', wrap(async req => { service.assertScope(req.user); await service.reconcile(); return service.status(req.user) }))
    app.post('/api/dimensions/switch', wrap(req => service.switch(req.body, req.user)))
    app.post('/api/dimensions/kick', wrap(req => service.kick(req.body, req.user)))
    app.get('/api/dimensions/worlds/jobs', wrap(req => worlds.list(req.user)))
    app.post('/api/dimensions/worlds/prepare', wrap(req => worlds.prepare(req.body || {}, req.user)))
    app.post('/api/dimensions/worlds/check', wrap(req => worlds.check(req.body?.jobId, req.body || {}, req.user)))
    app.post('/api/dimensions/worlds/cancel', wrap(req => worlds.cancel(req.body?.jobId, req.user)))
    app.get('/api/dimensions/admission', wrap(req => service.admission(req.query?.targetId, req.user)))
    app.post('/api/dimensions/admission', wrap(req => service.admission(req.body?.targetId, req.user, req.body)))
    ctx.on('push/connected', () => service.reconcile().catch(() => {}))
    ctx.on('servers/loaded', () => service.reconcile().catch(() => {}))
  } catch (error) { await service.close(); console.error('[dimensions] 初始化失败：' + error.message); throw error }
}
