import { randomBytes, randomUUID } from 'node:crypto'
const { validateConfig, fail } = await import('./config.js' + new URL(import.meta.url).search)
import { probeBridge } from './probe.js'

export class WorldOnboarding {
  jobs = new Map()
  constructor(service, probe = probeBridge) { this.service = service; this.probe = probe }
  view(job) { return { id: job.id, phase: job.phase, message: job.message, steps: job.steps, targetId: job.row.id, target: { ...job.row }, revision: job.revision, expired: Date.now() - job.at > 1200000, running: !!job.running, config: job.config, runtime: job.runtime } }
  list(user) {
    this.service.active(); this.service.assertScope(user)
    const owner = user?.id ?? user?.username ?? ''
    return { jobs: [...this.jobs.values()].filter(job => job.owner === owner && !['complete', 'cancelled'].includes(job.phase) && this.service.ctx.auth.canAccessServer(user, job.row.serverId)).map(job => this.view(job)) }
  }
  get(id, user) {
    this.service.active(); this.service.assertScope(user)
    const job = this.jobs.get(id)
    if (!job || job.owner !== (user?.id ?? user?.username ?? '')) throw fail(404, '添加任务不存在或已过期')
    this.service.assertScope(user, [job.row]); return job
  }
  async prepare(body, user) {
    const s = this.service; s.active(); s.assertScope(user)
    for (const [id, job] of this.jobs) if (!job.running && Date.now() - job.at > 1200000) { await this.cleanup(job); this.jobs.delete(id) }
    if (this.jobs.size >= 32) throw fail(429, '未完成添加任务过多，请先取消旧任务')
    if (body.revision !== s.state.config.revision) throw fail(409, '配置已更新，请刷新后再添加')
    const first = s.state.config.targets.length === 0
    const row = { ...body.target, id: randomUUID(), enabled: true, entry: first, hidden: false, distributionValue: 10 }
    const config = validateConfig({ ...s.state.config, targets: [...s.state.config.targets, row], fallbackId: s.state.config.fallbackId || (first ? row.id : '') })
    s.assertScope(user, config.targets)
    if (!s.ctx.servers.getRaw(row.serverId)) throw fail(400, '请选择已有管理服务器')
    if ([...this.jobs.values()].some(j => j.row.serverId === row.serverId && !['complete', 'cancelled'].includes(j.phase))) throw fail(409, '此服务器已有添加任务，请先完成或取消')
    const job = { id: randomUUID(), owner: user?.id ?? user?.username ?? '', row: config.targets.at(-1), key: randomBytes(32).toString('hex'), revision: body.revision, phase: 'deploying', steps: { deploy: false, pairing: false, protocol: false }, message: '正在沿原有链路下发 DLL', at: Date.now() }
    this.jobs.set(job.id, job)
    try { await s.ctx.plugins.deploy('dimensions', row.serverId) } catch (error) {
      this.jobs.delete(job.id)
      console.error('[dimensions] DLL 下发任务提交失败：', error)
      // Submission can fail inside the panel before contacting Host. Do not
      // misreport it as a connection failure or expose internal error details.
      throw fail(502, 'DLL 下发任务提交失败，请查看面板日志；此提示不代表子服 DLL 未安装')
    }
    return this.view(job)
  }
  async check(id, body, user) {
    const job = this.get(id, user), s = this.service
    if (job.running) return this.view(job)
    if (['complete', 'cancelled'].includes(job.phase)) return this.view(job)
    job.running = true
    try {
      if (Date.now() - job.at > 1200000) throw fail(410, '添加任务已过期，请重新添加')
      if (job.revision !== s.state.config.revision) throw fail(409, '世界配置已更新，请取消任务后重新添加')
      const sync = s.ctx.plugins.get('dimensions')?.sync?.[job.row.serverId]
      if (!sync || sync.phase !== 'synced' || !sync.desiredHash || sync.runningHash !== sync.desiredHash || sync.installedHash !== sync.desiredHash) {
        job.phase = 'deploying'; job.message = '等待 DLL 下发并加载；若子服提示需要重启，请手动重启后继续验证'; return this.view(job)
      }
      job.steps.deploy = true; job.phase = 'pairing'; job.message = '正在验证管理接口和子服签名对接'
      await s.bridge(job.row, job.key); job.paired = true; job.steps.pairing = true
      const info = await s.remote(job.row.serverId, '/data/dimensions/status')
      job.phase = 'verifying'; job.message = '正在通过填写的游戏 IP / 端口验证签名握手'
      if (body?.password !== undefined && (typeof body.password !== 'string' || body.password.length > 256)) throw fail(400, '验证用密码格式无效')
      await this.probe(job.row, job.key, { version: info.gameVersion, password: body?.password || '' })
      job.steps.protocol = true
      if (job.cancelled) throw fail(409, '添加已取消')
      const first = s.state.config.targets.length === 0
      const result = await s.save({ ...s.state.config, revision: job.revision, targets: [...s.state.config.targets, job.row], fallbackId: s.state.config.fallbackId || (first ? job.row.id : '') }, user, { [job.row.id]: job.key })
      job.phase = 'complete'; job.message = first ? '协议验证通过，已添加并设为默认世界' : '协议验证通过，世界已添加'; job.config = result.config; job.runtime = result.runtime
      delete job.key
      return this.view(job)
    } catch (error) {
      job.phase = 'error'; job.message = error.message
      return this.view(job)
    } finally { job.running = false }
  }
  async cleanup(job) {
    if (job.paired && job.key && !this.service.state.config.targets.some(row => row.id === job.row.id)) {
      await this.service.bridge(job.row, job.key, true).catch(() => {})
      job.paired = false
    }
  }
  async cancel(id, user) {
    const job = this.get(id, user)
    if (job.phase === 'complete') return this.view(job)
    if (job.running) throw fail(409, '正在验证，请等待本步完成后取消')
    await this.cleanup(job); job.cancelled = true; job.phase = 'cancelled'; job.message = '已取消添加'; delete job.key
    return this.view(job)
  }
  async close() { for (const job of this.jobs.values()) job.cancelled = true; await Promise.all([...this.jobs.values()].map(job => this.cleanup(job))); this.jobs.clear() }
}
