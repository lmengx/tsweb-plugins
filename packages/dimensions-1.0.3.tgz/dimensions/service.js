import fs from 'node:fs/promises'
import path from 'node:path'
import { createHash, randomBytes, randomUUID } from 'node:crypto'
const { defaults, validateConfig, fail } = await import('./config.js' + new URL(import.meta.url).search)
const { ProxySupervisor } = await import('./supervisor.js' + new URL(import.meta.url).search)
const { CaptchaWorldAssets } = await import('./captcha-worlds.js' + new URL(import.meta.url).search)

const fingerprint = key => createHash('sha256').update(key).digest('hex')
export class DimensionsService {
  constructor(ctx, { supervisor = new ProxySupervisor(), intervalMs = 10000 } = {}) {
    this.ctx = ctx; this.supervisor = supervisor; this.file = path.join(ctx.paths.dataOf('dimensions'), 'state.json')
    this.state = { config: defaults(), keys: {}, retired: [] }; this.closed = false
    this.queue = Promise.resolve(); this.syncing = null; this.bridges = {}; this.verified = new Map(); this.events = []; this.lastApplied = ''; this.intervalMs = intervalMs; this.processQueue = Promise.resolve()
    this.populationRows = []; this.populationTask = null
    this.captchaWorlds = new CaptchaWorldAssets(path.join(path.dirname(this.file), 'captcha-worlds'))
    supervisor.on('event', event => {
      // Whitelist diagnostic fields. Never retain packet bytes, login information or keys.
      const details = { sessionId: event.sessionId, targetId: event.targetId }
      if (event.type === 'transfer.finished' && event.transfer) {
        const { id, targetId, startedAt, mapReady, tileSections, playerSpawnSelfSeen, c2sSpawnConfirmed, confirmationAmbiguous, result, switchMs } = event.transfer
        details.transfer = { id, targetId, startedAt, mapReady, tileSections, playerSpawnSelfSeen, c2sSpawnConfirmed, confirmationAmbiguous, result, switchMs }
      }
      this.audit(event.type, details)
    })
  }
  audit(type, details = {}) { this.events.push({ type, at: Date.now(), ...details }); if (this.events.length > 100) this.events.shift() }
  active() { if (this.closed) throw fail(503, '维度中转已停用') }
  async init() {
    try {
      const state = JSON.parse(await fs.readFile(this.file, 'utf8'))
      this.state = { config: validateConfig(state.config), keys: state.keys, retired: state.retired ?? [] }
      for (const row of this.state.config.targets) if (!/^[a-f0-9]{64}$/.test(this.state.keys?.[row.id] ?? '')) throw new Error('子服密钥记录损坏')
    } catch (err) { if (err.code !== 'ENOENT') throw fail(500, '中转配置无法读取，请保留原文件并检查备份：' + err.message) }
    this.timer = setInterval(() => this.reconcile().catch(() => {}), this.intervalMs); this.timer.unref?.()
    this.populationTimer = setInterval(() => this.refreshPopulation().catch(() => {}), 2000); this.populationTimer.unref?.()
    this.reconcile().catch(() => {})
  }
  serial(action) { const result = this.queue.then(() => { this.active(); return action() }); this.queue = result.catch(() => {}); return result }
  async persist(state) {
    await fs.mkdir(path.dirname(this.file), { recursive: true })
    const temp = this.file + '.' + randomUUID() + '.tmp'
    try { await fs.writeFile(temp, JSON.stringify(state, null, 2), { flag: 'wx', mode: 0o600 }); this.active(); await fs.rename(temp, this.file); this.state = state } finally { await fs.rm(temp, { force: true }) }
  }
  assertScope(user, targets = this.state.config.targets) {
    if (targets.some(row => !this.ctx.auth.canAccessServer(user, row.serverId))) throw fail(403, '需要具有全部已配置子服的管理范围')
  }
  targetIssues() {
    return this.state.config.targets.flatMap(row => {
      const server = this.ctx.servers.getRaw(row.serverId)
      if (!server) return [{ id: row.id, reason: 'missing', message: '管理服务器已删除，可移除此残留配置' }]
      if (server.enabled === false) return [{ id: row.id, reason: 'disabled', message: '管理服务器已停用，请先在服务器管理中启用' }]
      return []
    })
  }
  async save(input, user, prepared = {}) {
    return this.serial(async () => {
      const config = validateConfig(input); this.assertScope(user); this.assertScope(user, config.targets)
      if (config.revision !== this.state.config.revision) throw fail(409, '配置已被其他管理员更新，请重新读取后再保存')
      // Validate new selections and active admission, but never block a stop or
      // captcha disable because the previously selected resource is damaged.
      const worldChanged = JSON.stringify(config.captchaWorld) !== JSON.stringify(this.state.config.captchaWorld)
      if ((config.enabled && config.captchaEnabled) || worldChanged) await this.captchaWorlds.prepare(config.captchaWorld)
      for (const row of config.targets) {
        const previous = this.state.config.targets.find(old => old.id === row.id && old.serverId === row.serverId)
        const server = this.ctx.servers.getRaw(row.serverId)
        // Existing broken references must remain editable and removable one at a time.
        // New bindings and activation still require an available management server.
        if (!server && !previous) throw fail(400, `管理服务器不存在：${row.name}`)
        if (server?.enabled === false && !previous) throw fail(400, `管理服务器已停用：${row.name}，请选择可用服务器`)
        if (config.enabled && row.enabled && (!this.state.config.enabled || !previous?.enabled) && (!server || server.enabled === false)) throw fail(400, `管理服务器已删除或停用：${row.name}，请先修复或移除此配置`)
      }
      const keys = {}, retired = [...this.state.retired]
      for (const row of this.state.config.targets) {
        const next = config.targets.find(t => t.id === row.id && t.serverId === row.serverId)
        if (!next) retired.push({ serverId: row.serverId, dimension: row.id, key: this.state.keys[row.id] })
      }
      for (const row of config.targets) keys[row.id] = this.state.config.targets.some(old => old.id === row.id && old.serverId === row.serverId) ? this.state.keys[row.id] : prepared[row.id] ?? randomBytes(32).toString('hex')
      config.revision++
      await this.persist({ config, keys, retired }); this.audit('config.saved', { actor: user?.username ?? '', revision: config.revision })
      return { config: structuredClone(config), saved: true }
    }).then(async result => { await this.reconcile().catch(() => {}); return { ...result, runtime: { ...this.supervisor.status }, bridges: this.bridges } })
  }
  async bridge(row, key, revoke = false) {
    const server = this.ctx.servers.getRaw(row.serverId)
    if (!server || (!revoke && server.enabled === false)) throw fail(502, '管理服务器已删除或停用')
    const response = await this.ctx.tshock.postFor(server, '/data/dimensions/configure', { dimension: row.id ?? row.dimension, key, enabled: revoke ? 'false' : 'true' }, { timeoutMs: 5000 })
    this.active()
    if (!response.ok || Number(response.data?.status) >= 400 || response.data?.protocol !== 1 || (!revoke && (response.data?.keyId !== fingerprint(key) || response.data?.enabled !== true || response.data?.dimension !== row.id))) throw fail(502, '子服未完成对接，请检查 DimensionsBridge.dll 下发状态及令牌的 tsweb.dimensions.manage 权限')
    return { ready: !revoke, checkedAt: Date.now(), version: response.data.version }
  }
  async captchaWorld(action, body, user) {
    this.active(); this.assertScope(user)
    if (action === 'list') return this.captchaWorlds.list()
    if (action === 'read') return this.captchaWorlds.describe(body?.id)
    return this.serial(async () => {
      this.assertScope(user)
      if (action === 'upload') return this.captchaWorlds.upload(body)
      if (action === 'remove') return this.captchaWorlds.remove(body?.id, this.state.config.captchaWorld)
      throw fail(400, '验证码建筑操作无效')
    })
  }
  async remote(serverId, pathname, body) {
    const server = this.ctx.servers.getRaw(serverId)
    if (!server || server.enabled === false) throw fail(404, '管理服务器不存在或已停用')
    const response = body === undefined ? await this.ctx.tshock.fetchFor(server, pathname, {}, { timeoutMs: 4000 }) : await this.ctx.tshock.postFor(server, pathname, body, { timeoutMs: 4000 })
    this.active()
    if (!response.ok || Number(response.data?.status) >= 400) throw fail(Number(response.data?.status) === 409 ? 409 : 502, response.data?.error || '子服管理接口未就绪，请检查 DLL 与权限')
    return response.data
  }
  async readPopulation() {
    if (!this.ctx.tshock.fetchFor) return []
    const config = this.state.config
    const rows = await Promise.all(config.targets.filter(t => t.enabled).map(async row => {
      try {
        const data = await this.remote(row.serverId, '/data/dimensions/status')
        if (data.protocol !== 1 || !Number.isSafeInteger(data.online) || data.online < 0 || !Array.isArray(data.sessions)) throw new Error('人数上报无效')
        return { id: row.id, online: data.online, sessions: data.sessions.filter(s => typeof s === 'string' && s.length <= 64).slice(0, 255), checkedAt: Date.now() }
      } catch { return null }
    }))
    if (this.state.config.revision !== config.revision) return this.populationRows
    this.populationRows = rows.filter(Boolean)
    return this.populationRows
  }
  refreshPopulation() {
    if (this.closed || !this.state.config.enabled || this.supervisor.status.phase !== 'running') return Promise.resolve()
    if (this.populationTask) return this.populationTask
    this.populationTask = this.readPopulation().then(rows => { if (!this.closed && this.supervisor.status.phase === 'running') return this.supervisor.rpc('population', rows) }).finally(() => { this.populationTask = null })
    return this.populationTask
  }
  async admission(id, user, body) {
    this.assertScope(user)
    const row = this.state.config.targets.find(t => t.id === id)
    if (!row) throw fail(404, '子服不存在')
    if (body !== undefined) {
      if (!/^[a-f0-9]{64}$/.test(body?.revision ?? '') || !Number.isInteger(body.maxSlots) || body.maxSlots < 1 || body.maxSlots > 255 || !Number.isInteger(body.reservedSlots) || body.reservedSlots < 0 || body.reservedSlots > 255 || typeof body.serverFullReason !== 'string' || !body.serverFullReason.trim() || body.serverFullReason.length > 500) throw fail(400, '人数上限参数无效')
      body = { revision: body.revision, maxSlots: body.maxSlots, reservedSlots: body.reservedSlots, serverFullReason: body.serverFullReason }
    }
    return this.remote(row.serverId, '/data/dimensions/settings', body)
  }
  reconcile() {
    if (this.closed) return Promise.resolve()
    if (this.syncing) return this.syncing.then(() => { if (!this.closed && this.syncedRevision !== this.state.config.revision) return this.reconcile() })
    this.syncing = (async () => {
      const snapshot = structuredClone(this.state), config = snapshot.config
      const remaining = []
      await Promise.all(snapshot.retired.map(async retired => {
        try { await this.bridge(retired, retired.key, true) } catch { remaining.push(retired) }
      }))
      if (this.closed || config.revision !== this.state.config.revision) return
      if (remaining.length !== snapshot.retired.length) await this.serial(async () => {
        if (config.revision === this.state.config.revision) await this.persist({ ...this.state, retired: remaining })
      })
      if (!config.enabled) {
        this.lastApplied = ''; await this.supervisor.apply({ ...config, enabled: false }); this.supervisor.publish({ entryReady: false }); this.syncedRevision = config.revision; return
      }
      const bridges = {}
      await Promise.all(config.targets.filter(t => t.enabled).map(async row => {
        const server = this.ctx.servers.getRaw(row.serverId)
        const identity = fingerprint(JSON.stringify([row.serverId, row.host, row.port, snapshot.keys[row.id], server?.host, server?.port, server?.token]))
        try { bridges[row.id] = await this.bridge(row, snapshot.keys[row.id]); this.verified.set(row.id, identity) }
        catch (error) {
          // A REST outage does not invalidate a proven game connection. The game handshake
          // still verifies the current key on every new connection and switch.
          bridges[row.id] = { ready: !!server && server.enabled !== false && this.verified.get(row.id) === identity, degraded: true, checkedAt: Date.now(), error: error.message }
        }
      }))
      if (this.closed || config.revision !== this.state.config.revision) return
      this.bridges = bridges
      const effective = { ...config, requirePopulation: !!this.ctx.tshock.fetchFor, targets: config.targets.map(row => ({ ...row, enabled: row.enabled && bridges[row.id]?.ready === true, bridgeKey: snapshot.keys[row.id] })) }
      try { if (config.captchaEnabled) effective.captchaPreparedWorld = await this.captchaWorlds.prepare(config.captchaWorld) }
      catch (error) { this.supervisor.publish({ error: '验证码世界加载失败：' + error.message }); throw error }
      if (this.closed || config.revision !== this.state.config.revision) return
      const entryReady = effective.targets.some(t => t.enabled && t.entry)
      if (!entryReady && this.supervisor.status.phase !== 'running') {
        await this.supervisor.apply({ ...effective, enabled: false }); this.lastApplied = ''; this.supervisor.publish({ phase: 'waiting', entryReady: false, error: '暂无完成对接的入口子服，正在重试' }); this.syncedRevision = config.revision; return
      }
      const hash = fingerprint(JSON.stringify(effective))
      if (hash !== this.lastApplied || this.supervisor.status.phase !== 'running') {
        effective.population = await this.readPopulation()
        if (this.closed || config.revision !== this.state.config.revision) return
        await this.supervisor.apply(effective); this.lastApplied = hash
      }
      this.supervisor.publish({ entryReady, error: entryReady ? '' : '暂无完成对接的入口子服，新玩家暂时无法进入，现有连接继续运行' })
      this.syncedRevision = config.revision
    })().finally(() => { this.syncing = null })
    return this.syncing
  }
  async status(user) {
    this.active(); this.assertScope(user)
    let sessions = [], error = ''
    if (this.supervisor.status.phase === 'running') {
      try { sessions = await this.supervisor.rpc('sessions', null) } catch (err) { error = err.message }
    }
    return { runtime: { ...this.supervisor.status }, revision: this.state.config.revision, targetIssues: this.targetIssues(), bridges: structuredClone(this.bridges), population: this.populationRows.map(({ id, online, checkedAt }) => ({ id, online, checkedAt })), sessions, events: this.events.slice().reverse(), error, pendingRevocations: this.state.retired.length }
  }
  logs(query, user) {
    this.active(); this.assertScope(user)
    return this.supervisor.logs.read(query.after === undefined ? 0 : Number(query.after), query.limit === undefined ? 200 : Number(query.limit))
  }
  control(action, body, user) {
    const operation = this.processQueue.then(async () => {
      this.active(); this.assertScope(user)
      if (!['start', 'stop', 'restart'].includes(action)) throw fail(400, '未知进程操作')
      if (!Number.isSafeInteger(body?.revision) || body.revision !== this.state.config.revision) throw fail(409, '配置已被更新，请刷新后再操作')
      if (['stop', 'restart'].includes(action) && this.supervisor.status.pid && body.confirm !== true) throw fail(409, '此操作会断开当前中转玩家，请确认后重试')
      if (action !== 'stop') {
        const issue = this.targetIssues().find(issue => this.state.config.targets.some(row => row.id === issue.id && row.enabled))
        if (issue) throw fail(400, `${this.state.config.targets.find(row => row.id === issue.id).name}：${issue.message}；处理后再启动`)
      }
      if (action === 'restart') {
        if (!this.state.config.enabled) throw fail(409, '中转已停用，请先启动进程')
        await this.save({ ...this.state.config, enabled: false }, user)
      }
      this.supervisor.log('info', ({ start: '管理员请求启动维度进程', stop: '管理员请求停止维度进程', restart: '管理员请求重启维度进程' })[action])
      await this.save({ ...this.state.config, enabled: action !== 'stop' }, user)
      this.audit('process.' + action)
      return { ...(await this.status(user)), config: structuredClone(this.state.config) }
    })
    this.processQueue = operation.catch(() => {}); return operation
  }
  async switch(body, user) {
    this.active(); this.assertScope(user)
    if (typeof body?.sessionId !== 'string' || typeof body?.targetId !== 'string') throw fail(400, '请选择玩家连接和目标子服')
    const sessions = await this.supervisor.rpc('sessions', null)
    const current = sessions.find(row => row.id === body.sessionId), target = this.state.config.targets.find(row => row.id === body.targetId && row.enabled)
    if (!current || !target) throw fail(404, '玩家连接或目标子服不存在')
    this.audit('switch.requested', { actor: user?.username ?? '', sessionId: body.sessionId, targetId: target.id })
    return this.supervisor.rpc('switch', { sessionId: body.sessionId, targetId: target.id }, this.state.config.connectTimeoutMs + 5000)
  }
  async kick(body, user) { this.active(); this.assertScope(user); if (typeof body?.sessionId !== 'string') throw fail(400, '请选择玩家连接'); const result = await this.supervisor.rpc('kick', { sessionId: body.sessionId }); this.audit('kick', { actor: user?.username ?? '', sessionId: body.sessionId }); return result }
  async close() { if (this.closed) return; this.closed = true; clearInterval(this.timer); clearInterval(this.populationTimer); await this.queue; await this.syncing?.catch(() => {}); await this.populationTask?.catch(() => {}); await this.supervisor.close() }
}
