const actions = [
  { id: 'emote-command.config.read', method: 'GET', path: '/api/emote-command/config' },
  { id: 'emote-command.config.save', method: 'POST', path: '/api/emote-command/config' },
].map(action => ({ ...action, module: 'emote-command.manage', scope: 'server' }));
export default {
  owner: 'emote-command', version: 2,
  modules: [{ id: 'emote-command.manage', permission: 'emote-command.manage', title: '表情指令管理',
    roles: ['superadmin', 'admin'], scope: 'server', requires: actions.map(a => a.id) }],
  actions,
  features: [{ id: 'emote-command:manage', module: 'emote-command.manage', requires: actions.map(a => a.id) }],
};
