const revision = new URL(import.meta.url).search;
const { default: access } = await import(`./access.js${revision}`);
const { EmoteService } = await import(`./service.js${revision}`);
export const name = 'emote-command';
export const inject = ['webServer', 'auth', 'servers', 'tshock'];
export function apply(ctx) {
  try {
    const service = new EmoteService(ctx), controllers = new Set();
    const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx);
    ctx.on('dispose', () => { service.disposed = true; for (const c of controllers) c.abort(); });
    const wrap = write => async (req, res) => {
      const controller = new AbortController(); controllers.add(controller);
      const closed = () => { if (!res.writableFinished) controller.abort(); };
      res.on('close', closed);
      try {
        const id = req.headers['x-server-id'] || req.query?.serverId || req.user?.serverId || req.user?.extraServerIds?.[0];
        const result = await service.call(id, write, req.body, controller.signal);
        if (!res.destroyed) res.json(result);
      } catch (err) {
        if (!res.headersSent && !res.destroyed) res.status(err.status || 502).json({ error: err.message });
      } finally { controllers.delete(controller); res.off('close', closed); }
    };
    app.get('/api/emote-command/config', wrap(false));
    app.post('/api/emote-command/config', wrap(true));
  } catch (err) { console.error('[emote-command] 初始化失败：' + err.message); throw err; }
}
