"""Export Terraria's actual emote atlas, IDs, names, categories and two frames.

Requires Python + Pillow, .NET 9, ilspycmd and a MonoGame.Framework.dll.
Reads the client installation; does not start or modify the game/server.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import tempfile

from PIL import Image

HERE = Path(__file__).resolve().parent


def run(*args):
    subprocess.run([str(x) for x in args], check=True, capture_output=True)


def read_localization(path):
    # Game resources allow comments/trailing commas. Preserve every quoted string.
    source = path.read_text(encoding='utf-8-sig')
    pattern = r'("(?:\\.|[^"\\])*")|//[^\r\n]*|/\*[\s\S]*?\*/|,(\s*[}\]])'
    source = re.sub(pattern, lambda match: match[1] or match[2] or '', source)
    return json.loads(source)


def read7(data, position):
    value = shift = 0
    while True:
        byte = data[position]
        position += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, position
        shift += 7


def texture(raw):
    readers, pos = read7(raw, 0)
    for _ in range(readers):
        length, pos = read7(raw, pos)
        pos += length + 4
    shared, pos = read7(raw, pos)
    reader, pos = read7(raw, pos)
    surface, width, height, mips, size = struct.unpack_from('<iiiii', raw, pos)
    if shared != 0 or reader != 1 or surface != 0 or mips != 1 or size != width * height * 4:
        raise ValueError('Unexpected texture layout; review the exporter for this client')
    pixels = bytearray(raw[pos + 20:pos + 20 + size])
    if len(pixels) != size:
        raise ValueError('Truncated texture')
    # XNA uses premultiplied RGBA; browser PNG uses straight alpha.
    for offset in range(0, len(pixels), 4):
        alpha = pixels[offset + 3]
        if 0 < alpha < 255:
            for channel in range(3):
                pixels[offset + channel] = min(255, (pixels[offset + channel] * 255 + alpha // 2) // alpha)
    return Image.frombytes('RGBA', (width, height), bytes(pixels))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--game', type=Path, required=True)
    parser.add_argument('--monogame', type=Path, required=True, help='MonoGame.Framework.dll containing the LZX decoder')
    parser.add_argument('--out', type=Path, default=HERE.parent / 'ui/assets/game-emotes')
    args = parser.parse_args()
    game = args.game.resolve()
    assembly = game / 'Terraria.exe'
    source = game / 'Content/Images/Extra_48.xnb'
    output = args.out.resolve()
    output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='tsweb-emote-export-') as temp:
        temp = Path(temp)
        run('dotnet', 'run', '--project', HERE / 'SourceReader', '--', assembly, temp)
        for name in ['EmoteID', 'EmoteBubble', 'States.UIEmotesMenu', 'Elements.EmoteButton']:
            run('ilspycmd', '-t', 'Terraria.GameContent.UI.' + name, assembly, '-o', temp)
        run('dotnet', 'run', '--no-build', '--project', HERE / 'SourceReader', '--', '--texture', source, temp / 'atlas.raw', args.monogame.resolve())
        atlas = texture((temp / 'atlas.raw').read_bytes())
        ids = json.loads((temp / 'ids.json').read_text(encoding='utf-8'))
        ids = {number: key for key, number in ids.items() if number >= 0}
        id_code = (temp / 'Terraria.GameContent.UI.EmoteID.decompiled.cs').read_text(encoding='utf-8-sig')
        bubble_code = (temp / 'Terraria.GameContent.UI.EmoteBubble.decompiled.cs').read_text(encoding='utf-8-sig')
        button_code = (temp / 'Terraria.GameContent.UI.Elements.EmoteButton.decompiled.cs').read_text(encoding='utf-8-sig')
        count = int(re.search(r'int Count = (\d+)', id_code)[1])
        if sorted(ids) != list(range(count)):
            raise ValueError('Missing or duplicate IDs')
        if 'emote * 2 % 8 + frame, 1 + emote / 4' not in bubble_code or '_frameCounter >= 10' not in button_code:
            raise ValueError('Game frame calculation changed; review crop/animation timing')
        rows = 2 + (count - 1) // 4
        if atlas.width % 8 or atlas.height % rows:
            raise ValueError('Atlas is not divisible by game frame layout')
        width, height = atlas.width // 8, atlas.height // rows
        zh, en = {}, {}
        for resource in temp.glob('Terraria.Localization.Content.*.json'):
            if 'zh-Hans' in resource.name:
                zh.update(read_localization(resource))
            if 'en-US' in resource.name:
                en.update(read_localization(resource))
        menu_code = (temp / 'Terraria.GameContent.UI.States.UIEmotesMenu.decompiled.cs').read_text(encoding='utf-8-sig')
        groups = []
        membership = {}
        for key in ['General', 'RPS', 'Items', 'BiomesAndEvents', 'TownNPCs', 'Critters', 'Bosses']:
            body = re.search(r'private List<int> GetEmotes' + key + r'\(\)\s*\{(.*?)(?=\n\tprivate |\n\tpublic )', menu_code, re.S)[1]
            if 'return new List<int>' in body:
                values = [int(x) for x in re.findall(r'\d+', re.search(r'return new List<int>\s*\{(.*?)\}', body, re.S)[1])]
            else:
                values = []
                for match in re.finditer(r'list\.AddRange\(new int\[\d+\]\s*\{([^}]+)\}\)|list\.Add\((\d+)\)', body):
                    values.extend(int(x) for x in re.findall(r'\d+', match[1] or match[2]))
            groups.append({'key': key, 'name': zh['UI']['EmoteCategory' + key], 'ids': values})
            for number in values:
                membership.setdefault(number, []).append(key)
        if set(membership) != set(ids):
            raise ValueError('Some IDs have no game category')
        atlas.save(output / 'atlas.png', optimize=True)
        background = atlas.crop((width, 0, width * 2, height))
        background.save(output / 'bubble.png', optimize=True)
        icons = output / 'frames'
        icons.mkdir(exist_ok=True)
        emotes = []
        contact = Image.new('RGBA', (width * 2 * 12, height * 2 * ((count + 11) // 12)))
        for number, key in sorted(ids.items()):
            if key not in zh['EmojiName'] or key not in en['EmojiName']:
                raise ValueError('Missing localized emote name: ' + key)
            strip = Image.new('RGBA', (width * 2, height))
            frames = []
            for frame in range(2):
                x, y = (number % 4 * 2 + frame) * width, (1 + number // 4) * height
                crop = atlas.crop((x, y, x + width, y + height))
                if crop.getbbox() is None:
                    raise ValueError('Blank emote frame: ' + str(number))
                strip.paste(crop, (frame * width, 0))
                frames.append({'x': x, 'y': y, 'width': width, 'height': height})
                if frame == 0:
                    preview = Image.alpha_composite(background, crop).resize((width * 2, height * 2), Image.Resampling.NEAREST)
                    contact.paste(preview, (number % 12 * width * 2, number // 12 * height * 2))
            strip.save(icons / f'{number}.png', optimize=True)
            emotes.append({'id': number, 'key': key, 'name': zh['EmojiName'][key], 'englishName': en['EmojiName'][key],
                           'categories': membership[number], 'frames': frames, 'strip': f'frames/{number}.png'})
        contact.save(output / 'contact-sheet.png', optimize=True)
        manifest = {'game': 'Terraria', 'version': json.loads((temp / 'version.json').read_text(encoding='utf-8')), 'count': count,
                    'source': {'assembly': 'Terraria.exe', 'texture': 'Content/Images/Extra_48.xnb',
                               'assemblySha256': hashlib.sha256(assembly.read_bytes()).hexdigest(),
                               'textureSha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                               'names': 'Embedded zh-Hans/en-US EmojiName resources',
                               'categories': 'UIEmotesMenu.GetEmotes* (all unlock conditions included)'},
                    'atlas': {'file': 'atlas.png', 'width': atlas.width, 'height': atlas.height,
                              'columns': 8, 'rows': rows, 'frameWidth': width, 'frameHeight': height,
                              'framesPerEmote': 2, 'frameDurationMs': 1000 * 10 / 60,
                              'bubble': {'x': width, 'y': 0, 'width': width, 'height': height}},
                    'categories': groups, 'emotes': emotes}
        # JSON is deterministic for the same client files.
        (output / 'catalog.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'count': count, 'categories': len(groups), 'atlas': atlas.size, 'out': str(output)}, ensure_ascii=True))


if __name__ == '__main__':
    main()
