export const error = (status, message) => Object.assign(new Error(message), { status });
export function validateConfig(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
    !Number.isSafeInteger(value.cooldownMs) || value.cooldownMs < 0 || !Array.isArray(value.emotes))
    throw error(400, '请填写非负整数触发间隔和完整的表情规则');
  return {
    cooldownMs: value.cooldownMs,
    emotes: value.emotes.map((rule, index) => {
      if (!rule || !Number.isInteger(rule.emojiId) || rule.emojiId < 0 || rule.emojiId > 255 ||
        typeof rule.enabled !== 'boolean' || typeof rule.ignorePermission !== 'boolean' ||
        typeof rule.remark !== 'string' || !Array.isArray(rule.commands) || rule.commands.some(c => typeof c !== 'string'))
        throw error(400, `第 ${index + 1} 条规则无效，请检查表情 ID（0–255）、开关及指令`);
      return { emojiId: rule.emojiId, enabled: rule.enabled, commands: rule.commands.map(c => c.trim()).filter(Boolean),
        remark: rule.remark.trim(), ignorePermission: rule.ignorePermission };
    }),
  };
}
