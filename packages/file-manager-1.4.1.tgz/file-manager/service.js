import fs from "node:fs/promises";
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";

export const CHUNK_SIZE = 256 * 1024;
export const MAX_FILE = 200 * 1024 * 1024;
export const httpError = (status, message) =>
  Object.assign(new Error(message), { status });
const sha256 = (data) => createHash("sha256").update(data).digest("hex");

function safeName(name) {
  if (
    typeof name !== "string" ||
    !name ||
    name === "." ||
    name === ".." ||
    /[/\\:\x00-\x1f]/.test(name) ||
    /[. ]$/.test(name) ||
    name.startsWith(".partial-")
  )
    throw httpError(400, "无效的文件名");
  return name;
}

export class FileManagerService {
  constructor(ctx) {
    this.ctx = ctx;
    this.root = path.resolve(ctx.paths.dataOf("file-manager"), "transfer");
    this.active = new Set();
    this.disposed = false;
  }

  server(id) {
    if (typeof id !== "string" || !id) throw httpError(400, "请先选择服务器");
    const server = this.ctx.servers.getRaw(id);
    if (!server) throw httpError(404, "服务器不存在");
    return server;
  }

  assertActive(signal) {
    if (this.disposed) throw httpError(503, "文件管理正在卸载，请稍后重试");
    signal?.throwIfAborted();
  }

  async remote(server, action, params = {}, { write = false, signal } = {}) {
    this.assertActive(signal);
    const result = await this.ctx.tshock[write ? "postFor" : "fetchFor"](
      server,
      "/data/file-manager/" + action,
      params,
      { timeoutMs: 15000, signal },
    );
    this.assertActive(signal);
    const status = Number(result.data?.status || result.status);
    if (
      !result.ok ||
      status >= 400 ||
      result.data?.error ||
      !result.data?.result
    )
      throw httpError(
        [400, 404, 409, 413].includes(status) ? status : 502,
        result.data?.error ||
          "文件管理插件未响应，请检查 FileManager.dll 和 REST 权限 tsweb.files.manage",
      );
    if (action === "download") {
      const part = result.data.result;
      const bytes =
        typeof part.data === "string" ? Buffer.from(part.data, "base64") : null;
      if (!bytes || bytes.length > CHUNK_SIZE || sha256(bytes) !== part.sha256)
        throw httpError(502, "下载分块校验失败");
    }
    return result.data.result;
  }

  async directory(serverId) {
    // 服务器 ID 只参与哈希，不能被当成宿主路径。
    const directory = path.join(this.root, sha256(String(serverId)));
    await fs.mkdir(directory, { recursive: true });
    // 检查状态目录的每级祖先，防止用目录联接绕出转存目录。
    let current = directory;
    for (;;) {
      if ((await fs.lstat(current)).isSymbolicLink())
        throw httpError(400, "转存目录不允许使用符号链接");
      const parent = path.dirname(current);
      if (parent === current) break;
      current = parent;
    }
    return directory;
  }

  async savedFile(serverId, name) {
    const file = path.join(await this.directory(serverId), safeName(name));
    let stat;
    try {
      stat = await fs.lstat(file);
    } catch (err) {
      if (err.code === "ENOENT") throw httpError(404, "转存文件不存在");
      throw err;
    }
    if (!stat.isFile() || stat.isSymbolicLink())
      throw httpError(400, "只能操作普通文件");
    return { file, stat };
  }

  async listSaved(serverId) {
    const directory = await this.directory(serverId);
    const entries = [];
    for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
      if (!entry.isFile() || entry.name.startsWith(".partial-")) continue;
      const stat = await fs.lstat(path.join(directory, entry.name));
      if (stat.isFile() && !stat.isSymbolicLink()) {
        let metadata = {};
        try {
          const meta = await this.metadataFile(serverId, entry.name);
          metadata = JSON.parse(await fs.readFile(meta, "utf8"));
        } catch {
          /* Earlier transfers have no source metadata. */
        }
        entries.push({
          name: entry.name,
          size: stat.size,
          originalName: metadata.originalName || entry.name,
          sourcePath: metadata.sourcePath || "",
          savedAt: metadata.savedAt || stat.mtime.toISOString(),
          modified: stat.mtime.toISOString(),
          version: `${stat.size}:${stat.mtimeMs}`,
        });
      }
    }
    return {
      entries: entries.sort((a, b) => a.name.localeCompare(b.name, "zh-CN")),
    };
  }

  async deleteSaved(serverId, name, version) {
    const { file, stat } = await this.savedFile(serverId, name);
    if (!version || version !== `${stat.size}:${stat.mtimeMs}`)
      throw httpError(409, "文件已变化，请刷新后重试");
    await fs.unlink(file);
    await fs.rm(await this.metadataFile(serverId, name), { force: true });
    return { deleted: true };
  }

  async metadataFile(serverId, name) {
    const directory = path.join(await this.directory(serverId), ".metadata");
    await fs.mkdir(directory, { recursive: true });
    if ((await fs.lstat(directory)).isSymbolicLink())
      throw httpError(400, "转存元数据目录不允许使用链接");
    const file = path.join(directory, sha256(safeName(name)) + ".json");
    try {
      if ((await fs.lstat(file)).isSymbolicLink())
        throw httpError(400, "元数据文件不允许使用链接");
    } catch (err) {
      if (err.code !== "ENOENT") throw err;
    }
    return file;
  }

  async restore(
    serverId,
    { name, path: target, version, overwrite = false, savedVersion },
    signal,
  ) {
    const server = this.server(serverId);
    const { file, stat } = await this.savedFile(serverId, name);
    if (!savedVersion || savedVersion !== `${stat.size}:${stat.mtimeMs}`)
      throw httpError(409, "转存文件已变化，请刷新后重试");
    if (stat.size > MAX_FILE) throw httpError(413, "还原最大支持 200 MB");
    if (typeof target !== "string" || !target)
      throw httpError(400, "请输入还原到游戏服的相对路径");
    this.assertActive(signal);
    const handle = await fs.open(file, "r");
    const controller = new AbortController();
    const combined = signal
      ? AbortSignal.any([signal, controller.signal])
      : controller.signal;
    this.active.add(controller);
    let session;
    try {
      session = (
        await this.remote(
          server,
          "upload/start",
          { path: target, total: stat.size, overwrite, version },
          { write: true, signal: combined },
        )
      ).id;
      let offset = 0;
      const buffer = Buffer.alloc(CHUNK_SIZE);
      while (offset < stat.size) {
        this.assertActive(combined);
        const { bytesRead } = await handle.read(
          buffer,
          0,
          Math.min(CHUNK_SIZE, stat.size - offset),
          offset,
        );
        if (!bytesRead) throw httpError(409, "转存文件已变化，请重新选择");
        await this.remote(
          server,
          "upload/chunk",
          {
            id: session,
            offset,
            data: buffer.subarray(0, bytesRead).toString("base64"),
          },
          { write: true, signal: combined },
        );
        offset += bytesRead;
      }
      const current = await handle.stat();
      if (`${current.size}:${current.mtimeMs}` !== savedVersion)
        throw httpError(409, "转存文件已变化，请重新选择");
      const result = await this.remote(
        server,
        "upload/finish",
        { id: session },
        { write: true, signal: combined },
      );
      session = null;
      return result;
    } finally {
      await handle.close();
      this.active.delete(controller);
      if (session)
        await this.ctx.tshock
          .postFor(
            server,
            "/data/file-manager/upload/cancel",
            { id: session },
            { timeoutMs: 15000 },
          )
          .catch(() => {});
    }
  }

  async receive(server, remotePath, destination, signal) {
    this.assertActive(signal);
    const handle = await fs.open(destination, "wx");
    const digest = createHash("sha256");
    let offset = 0,
      version,
      total;
    try {
      do {
        const part = await this.remote(
          server,
          "download",
          {
            path: remotePath,
            offset,
            length: CHUNK_SIZE,
            ...(version ? { version } : {}),
          },
          { signal },
        );
        const bytes = Buffer.from(String(part.data), "base64");
        if (
          !Number.isSafeInteger(part.total) ||
          part.total < 0 ||
          part.total > MAX_FILE ||
          part.offset !== offset ||
          bytes.length > CHUNK_SIZE ||
          offset + bytes.length > part.total ||
          sha256(bytes) !== part.sha256 ||
          typeof part.version !== "string" ||
          !part.version ||
          (version && (part.version !== version || part.total !== total)) ||
          (bytes.length === 0 && offset < part.total)
        )
          throw httpError(502, "下载分块校验失败，文件可能已变化");
        total = part.total;
        version = part.version;
        await handle.writeFile(bytes);
        digest.update(bytes);
        offset += bytes.length;
      } while (offset < total);
      this.assertActive(signal);
      await handle.sync();
      return { size: offset, sha256: digest.digest("hex") };
    } finally {
      await handle.close();
    }
  }

  async transfer(serverId, remotePath, signal) {
    const server = this.server(serverId);
    if (typeof remotePath !== "string" || !remotePath)
      throw httpError(400, "请选择文件");
    const originalName = safeName(
      remotePath.replaceAll("\\", "/").split("/").pop(),
    );
    let name = originalName;
    const directory = await this.directory(serverId);
    let destination = path.join(directory, name);
    const stage = path.join(directory, ".partial-" + randomUUID());
    const controller = new AbortController();
    const combined = signal
      ? AbortSignal.any([signal, controller.signal])
      : controller.signal;
    this.active.add(controller);
    try {
      try {
        await fs.lstat(destination);
        name =
          new Date().toISOString().replaceAll(/[:.]/g, "-") +
          "-" +
          randomUUID().slice(0, 8) +
          "-" +
          originalName;
        destination = path.join(directory, name);
      } catch (err) {
        if (err.code !== "ENOENT") throw err;
      }
      const result = await this.receive(server, remotePath, stage, combined);
      this.assertActive(combined);
      // 同目录硬链接发布，原子拒绝同名覆盖；失败时不会留下半个目标文件。
      await fs.link(stage, destination);
      try {
        await fs.writeFile(
          await this.metadataFile(serverId, name),
          JSON.stringify({
            originalName,
            sourcePath: remotePath,
            savedAt: new Date().toISOString(),
          }),
          { flag: "wx" },
        );
      } catch (err) {
        await fs.rm(destination, { force: true });
        throw err;
      }
      return { name, originalName, sourcePath: remotePath, ...result };
    } catch (err) {
      if (err.code === "EEXIST") throw httpError(409, "同名转存文件已存在");
      throw err;
    } finally {
      this.active.delete(controller);
      await fs.rm(stage, { force: true });
    }
  }

  dispose() {
    this.disposed = true;
    for (const controller of this.active) controller.abort();
    this.active.clear();
  }
}
