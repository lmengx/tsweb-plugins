const { default: accessContract } = await import(
  `./access.js${new URL(import.meta.url).search}`
);
const { FileManagerService, httpError, CHUNK_SIZE } = await import(
  `./service.js${new URL(import.meta.url).search}`
);

export const name = "file-manager";
export const inject = ["webServer", "auth", "servers", "tshock", "paths"];

export function apply(ctx) {
  try {
    const service = new FileManagerService(ctx);
    const app = ctx.auth.access.policyApp(
      ctx.webServer.app,
      accessContract,
      ctx,
    );
    const controllers = new Set();
    ctx.on("dispose", () => {
      for (const controller of controllers) controller.abort();
      service.dispose();
    });

    function route(handler) {
      return async (req, res) => {
        const controller = new AbortController();
        const abort = () => {
          if (!res.writableFinished) controller.abort();
        };
        controllers.add(controller);
        res.on("close", abort);
        try {
          const id = req.headers["x-server-id"];
          const server = service.server(id);
          const result = await handler(req, res, server, id, controller.signal);
          if (!res.headersSent && !res.destroyed) res.json(result);
        } catch (err) {
          if (!res.headersSent && !res.destroyed)
            res.status(err.status || 502).json({ error: err.message });
          else if (!res.writableFinished) res.destroy();
        } finally {
          controllers.delete(controller);
          res.off("close", abort);
        }
      };
    }
    const get = (action) =>
      route((req, res, server, id, signal) =>
        service.remote(server, action, req.query, { signal }),
      );
    const post = (action) =>
      route((req, res, server, id, signal) => {
        if (
          action === "upload/chunk" &&
          (typeof req.body?.data !== "string" ||
            req.body.data.length > 4 * Math.ceil(CHUNK_SIZE / 3))
        )
          throw httpError(413, "上传分块过大或缺少数据");
        if (
          action === "write" &&
          (typeof req.body?.content !== "string" ||
            Buffer.byteLength(req.body.content) > 5 * 1024 * 1024)
        )
          throw httpError(413, "文本保存最大支持 5 MB");
        return service.remote(server, action, req.body, {
          write: true,
          signal,
        });
      });
    app.get("/api/file-manager/list", get("list"));
    app.get("/api/file-manager/tree", get("tree"));
    app.get("/api/file-manager/read", get("read"));
    app.post("/api/file-manager/write", post("write"));
    app.post("/api/file-manager/delete", post("delete"));
    app.post("/api/file-manager/create", post("create"));
    app.post("/api/file-manager/move", post("move"));
    app.post("/api/file-manager/copy", post("copy"));
    app.get("/api/file-manager/download", get("download"));
    app.post("/api/file-manager/upload/start", post("upload/start"));
    app.post("/api/file-manager/upload/chunk", post("upload/chunk"));
    app.post("/api/file-manager/upload/finish", post("upload/finish"));
    app.post("/api/file-manager/upload/cancel", post("upload/cancel"));
    app.get(
      "/api/file-manager/saved",
      route((req, res, server, id) => service.listSaved(id)),
    );
    app.post(
      "/api/file-manager/transfer",
      route((req, res, server, id, signal) =>
        service.transfer(id, req.body?.path, signal),
      ),
    );
    app.post(
      "/api/file-manager/restore",
      route((req, res, server, id, signal) =>
        service.restore(id, req.body || {}, signal),
      ),
    );
    app.post(
      "/api/file-manager/saved/delete",
      route((req, res, server, id) =>
        service.deleteSaved(id, req.body?.name, req.body?.version),
      ),
    );
    app.get(
      "/api/file-manager/saved/download",
      route(async (req, res, server, id) => {
        const { file } = await service.savedFile(id, req.query.name);
        await new Promise((resolve, reject) =>
          res.download(file, req.query.name, (err) =>
            err ? reject(err) : resolve(),
          ),
        );
      }),
    );
  } catch (err) {
    console.error("[file-manager] 初始化失败：" + err.message);
    throw err;
  }
}
