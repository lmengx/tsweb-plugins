/**
 * qq-bind 前端半 —— 管理页「QQ 绑定」（后端设置 → /b/qq-bind）
 *
 * 三个分页（Tab，一次只显示一个，点击切换；写法照 plugins/market/client/market.js）：
 *   绑定列表 —— 台账分页浏览、搜索、手动绑定、改绑 / 转移 / 解绑、批量解绑、重新统计时长
 *   设置     —— 适配器（legacy-http）配置、**bot token（状态 / 掩码 / 轮换 / 手动设置）**、
 *               自动晋升配置、导入旧版台账
 *   审计     —— 最近的 qqbind.* 审计流水
 *
 * 所有请求走 window.tsweb.api（带 Bearer），但统一经过 shared.js 的 req() 包一层：
 * 网络错误、401、404（插件被停用/后端半版本旧）都不抛错，而是如实显示在页面上。
 *
 * 接口字段全部对着 plugins/qq-bind/index.js 的实现读过（具体行号见各调用点注释），没有猜的字段名。
 */
import {
  esc, req, errText, fmtTime, fmtMinutes, svg, ICON, copyText, snapshotText,
} from './shared.js'

var tsw = window.tsweb
var root = null
var styleDone = false

var TAB_IDS = ['list', 'settings', 'audit']

/** 与后端一致：单次批量解绑上限（plugins/qq-bind/index.js BATCH_LIMIT = 100） */
var BATCH_LIMIT = 100

/** 审计里已被单独成列展示的键，详情列不重复显示 */
var AUDIT_COLUMN_KEYS = { t: 1, action: 1, actor: 1, adapter: 1 }

/** 判断某个键是否"已单独成列"：必须用自有键判断，否则键名叫 toString 时会被误当成列键而漏显示 */
function isAuditColumnKey(k) {
  return Object.prototype.hasOwnProperty.call(AUDIT_COLUMN_KEYS, k)
}

var state = {
  tab: 'list',
  /** 列表：搜索关键字（走服务端 keyword 参数，见下方 loadList 注释） */
  keyword: '',
  page: 1,
  pageSize: 20,
  total: 0,
  rows: [],
  /** service.list 的返回值：'online-stats' | 'unavailable'（见 plugins/qq-bind/index.js 的 service.list） */
  playtimeSource: '',
  /** 勾选的用户名集合（本页范围；翻页/重新加载时清理已消失的项）
   *  用 null 原型对象：键是角色名，普通对象下 `selected['toString']` 会命中原型链成员而"凭空勾选" */
  selected: Object.create(null),
  /** GET /api/servers 的 servers（手动绑定的「指定服务器」下拉） */
  servers: [],
  /** GET /api/qq-bind/config 的 config（已脱敏）与 configFile */
  config: null,
  configFile: '',
  /** 审计 */
  audit: [],
  auditLimit: 100,
  /** 设置页顶部的显著提示（环境变量优先等），跨重渲染保留 */
  banner: null,
  /** token 轮换后**只显示这一次**的明文 */
  tokenReveal: null,
  /** 导入结果（保留显示到下一次导入） */
  importResult: null,
  importError: '',
  busy: false,
}

/** 搜索输入防抖句柄（服务端分页 + 服务端过滤，不能每敲一个字发一次请求） */
var searchTimer = null

// ═══════════ 工具 ═══════════

function $(id) {
  return root ? root.querySelector('#' + id) : null
}

/** 消息区（textContent 写入，纯文本，不需要转义；也避免把后端错误当 HTML 解析） */
function setMsgEl(id, text, cls) {
  var el = $(id)
  if (!el) return
  el.className = cls || 'muted'
  el.textContent = text || ''
}

function setListMsg(text, cls) { setMsgEl('tswq-list-msg', text, cls) }
function setCfgMsg(text, cls) { setMsgEl('tswq-cfg-msg', text, cls) }
function setAuditMsg(text, cls) { setMsgEl('tswq-audit-msg', text, cls) }

/** 忙时禁用本页所有动作按钮（请求回来再放开；重渲染会顺带恢复） */
function setBusy(on) {
  state.busy = on
  var btns = root ? root.querySelectorAll('button[data-qbact]') : []
  for (var i = 0; i < btns.length; i++) btns[i].disabled = on
}

/**
 * 触发一个不 await 的异步流程（点标签页 / 首屏加载）。
 * 请求层 req() 已经不抛错，这里兜的是渲染期意外：没有它，一次漏网异常会变成
 * unhandledrejection，页面停在"正在加载..."上而看不出原因。
 */
function background(promise, onError) {
  if (!promise || typeof promise.then !== 'function') return
  promise.catch(function (err) {
    console.warn('[qq-bind] 后台任务异常：' + ((err && err.message) || err))
    if (onError) onError(err)
  })
}

/** 适配器配置（已脱敏） */
function legacyAdapter() {
  var adapters = (state.config && state.config.adapters) || {}
  return adapters['legacy-http'] || {}
}

/** configFile 的父目录 = 本插件数据目录（index.js: `configFile = path.join(dataDir, 'config.json')`） */
function dataDirHint() {
  var f = String(state.configFile || '')
  if (!f) return ''
  var i = Math.max(f.lastIndexOf('/'), f.lastIndexOf('\\'))
  return i > 0 ? f.slice(0, i) : ''
}

/** 换行 / 逗号 / 空格分隔的文本 → 去重后的字符串数组（群白名单、忽略组共用） */
function splitList(text) {
  var parts = String(text || '').split(/[\s,，;；]+/)
  var out = []
  // null 原型：条目里出现 "toString" 之类的值时，普通 {} 的去重判断会命中原型链成员而误判"已见过"
  var seen = Object.create(null)
  for (var i = 0; i < parts.length; i++) {
    var v = parts[i].trim()
    if (!v || seen[v]) continue
    seen[v] = true
    out.push(v)
  }
  return out
}

// ═══════════ 样式（tswq- 前缀，避免与宿主及别的插件冲突）═══════════
function injectStyle() {
  if (styleDone) return
  styleDone = true
  var st = document.createElement('style')
  st.textContent = [
    '.tswq-wrap{display:flex;flex-direction:column;min-width:0}',
    // 分页标签：沿用宿主胶囊语言（--secondary 底 + --border 描边），选中态用 --accent
    '.tswq-tabs{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:0 0 14px}',
    '.tswq-tab{display:inline-flex;align-items:center;gap:6px;font-family:inherit;font-size:13px;font-weight:600;height:auto;',
    'padding:5px 12px;border:1px solid var(--border);border-radius:999px;background:var(--secondary);',
    'color:var(--secondary-foreground);cursor:pointer;line-height:1.7}',
    '.tswq-tab:hover{border-color:var(--accent);background:var(--accent);color:var(--accent-foreground)}',
    '.tswq-tab.on{background:var(--accent);color:var(--accent-foreground);border-color:var(--accent)}',
    '.tswq-tab .count{font-weight:400;font-size:12px;opacity:.85}',
    '.tswq-pane{display:flex;flex-direction:column;gap:12px;min-width:0}',
    // 必须显式写：本样式表在宿主样式之后注入，同优先级下 .tswq-pane 的 display:flex 会盖掉宿主的 .hidden
    '.tswq-pane.hidden{display:none}',
    // 显著提示横幅（服务端 warning、保存异常等）
    '.tswq-banner{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-start;padding:10px 14px;margin:0 0 14px;',
    'border:1px solid var(--border);border-radius:var(--radius-md);font-size:13px;line-height:1.7}',
    '.tswq-banner.is-warn{border-color:var(--warn);background:hsla(38, 92%, 50%, 0.10)}',
    '.tswq-banner.is-danger{border-color:var(--danger);background:hsla(0, 72%, 51%, 0.08)}',
    '.tswq-banner .ttl{display:flex;align-items:center;gap:6px;font-weight:600;flex:0 0 auto}',
    '.tswq-banner .txt{flex:1;min-width:200px;word-break:break-all}',
    '.tswq-banner.hidden{display:none}',
    // 表单
    '.tswq-form-row{display:flex;flex-direction:column;gap:6px;margin:0 0 12px}',
    '.tswq-form-row>label{font-size:12px;color:var(--muted-foreground)}',
    '.tswq-inline{display:flex;gap:8px;align-items:center;flex-wrap:wrap}',
    '.tswq-check{display:flex;align-items:center;gap:8px;font-size:13px;margin:0 0 12px;cursor:pointer;line-height:1.7}',
    '.tswq-check input{width:auto;margin:0;flex:0 0 auto}',
    '.tswq-hint{font-size:12px;color:var(--muted-foreground);line-height:1.75;margin:0}',
    '.tswq-hint code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}',
    // 键值展示（token 状态区）
    '.tswq-kv{display:flex;justify-content:space-between;gap:10px;align-items:baseline;padding:7px 0;',
    'border-bottom:1px solid var(--border);font-size:13px}',
    '.tswq-kv:last-of-type{border-bottom:none}',
    '.tswq-kv .k{color:var(--muted-foreground);font-size:12px;flex:0 0 auto}',
    '.tswq-kv .v{text-align:right;word-break:break-all}',
    '.tswq-mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px;',
    'background:var(--muted);border-radius:var(--radius-sm);padding:1px 6px;word-break:break-all}',
    // 一次性明文展示框
    '.tswq-reveal{display:flex;flex-direction:column;gap:8px;margin:12px 0 0;padding:12px 14px;',
    'border:1px solid var(--accent);border-radius:var(--radius-md);background:var(--secondary)}',
    // 注意：明文框**不**用 effective 判红绿。新密钥是即时生效的（适配器每请求实时读内存配置），
    // effective:false 只表示"下次启动会被环境变量覆盖"，所以这里只有中性的"已生效"外观。
    '.tswq-reveal .ttl{display:flex;align-items:center;gap:6px;font-weight:600;font-size:13px}',
    '.tswq-reveal .ok-note{font-size:12px;line-height:1.75;color:var(--muted-foreground);word-break:break-all}',
    // 服务端 warning 原文（黄色警告条，不是失败红）
    '.tswq-warn{display:flex;flex-direction:column;gap:6px;margin:10px 0 0;padding:10px 12px;',
    'border:1px solid var(--warn);border-radius:var(--radius);background:hsla(38, 92%, 50%, 0.10);font-size:12px;line-height:1.75}',
    '.tswq-warn .ttl{display:flex;align-items:center;gap:6px;font-weight:600;font-size:13px}',
    '.tswq-warn .txt{word-break:break-all;white-space:pre-wrap}',
    '.tswq-reveal .val{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:13px;',
    'word-break:break-all;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-sm);padding:8px 10px}',
    '.tswq-reveal .ops{display:flex;gap:8px;flex-wrap:wrap;align-items:center}',
    '.tswq-reveal .txt{font-size:12px;line-height:1.75;word-break:break-all}',
    // 分页器
    '.tswq-pager{display:flex;align-items:center;justify-content:center;gap:6px;flex-wrap:wrap;padding:4px 0 0}',
    '.tswq-pager .info{width:100%;text-align:center;font-size:12px;color:var(--muted-foreground);margin-bottom:2px}',
    '.tswq-pg{font-size:12px;padding:2px 8px;border:1px solid var(--border);border-radius:var(--radius-sm);',
    'background:var(--card);color:var(--foreground);cursor:pointer;line-height:1.7;font-family:inherit}',
    '.tswq-pg:hover:not(:disabled){border-color:var(--accent);background:var(--accent);color:var(--accent-foreground)}',
    '.tswq-pg:disabled{opacity:.45;cursor:default}',
    '.tswq-pg.on{background:var(--accent);color:var(--accent-foreground);border-color:var(--accent)}',
    '.tswq-pager .gap{font-size:12px;color:var(--muted-foreground)}',
    // 结果块
    '.tswq-result{margin:10px 0 0;padding:10px 12px;border:1px solid var(--border);border-radius:var(--radius-sm);',
    'background:var(--muted);font-size:13px;line-height:1.8;word-break:break-all}',
    '.tswq-result .scroll{max-height:220px;overflow:auto;margin-top:8px}',
    '.tswq-result table{font-size:12px}',
    '.tswq-cands{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0 0}',
    '.tswq-table-wrap{padding:0;overflow-x:auto}',
  ].join('')
  document.head.appendChild(st)
}

// ═══════════ 渲染：外壳 ═══════════
function renderShell(container) {
  container.innerHTML = '' +
    '<div class="tswq-wrap">' +
    '  <div class="tswq-tabs">' +
    '    <button class="tswq-tab" data-qbtab="list">' + svg(ICON.list) + ' 绑定列表 <span class="count" id="tswq-tabcount"></span></button>' +
    '    <button class="tswq-tab" data-qbtab="settings">' + svg(ICON.gear) + ' 设置</button>' +
    '    <button class="tswq-tab" data-qbtab="audit">' + svg(ICON.scroll) + ' 审计</button>' +
    '  </div>' +
    '  <div class="tswq-pane hidden" id="tswq-pane-list">' + listPaneHtml() + '</div>' +
    '  <div class="tswq-pane hidden" id="tswq-pane-settings">' +
    '    <p id="tswq-cfg-msg" class="muted" style="min-height:18px;margin:0"></p>' +
    '    <div id="tswq-settings-body"></div>' +
    '  </div>' +
    '  <div class="tswq-pane hidden" id="tswq-pane-audit">' + auditPaneHtml() + '</div>' +
    '</div>'
  // 立即对齐标签选中态与分页显隐，避免先闪一片空白
  renderTabs()
}

function listPaneHtml() {
  return '' +
    '<div class="toolbar">' +
    '  <input id="tswq-search" type="search" placeholder="搜索角色名 / QQ 号" value="' + esc(state.keyword) + '" style="min-width:200px;max-width:320px">' +
    '  <span class="muted" style="font-size:12px">每页</span>' +
    '  <select id="tswq-pagesize" style="width:auto">' +
    [20, 50, 100].map(function (n) {
      return '<option value="' + n + '"' + (n === state.pageSize ? ' selected' : '') + '>' + n + '</option>'
    }).join('') +
    '  </select>' +
    '  <div class="spacer"></div>' +
    '  <button class="primary sm" data-qbact="open-bind">' + svg(ICON.plus) + ' 手动绑定</button>' +
    '  <button class="ghost sm" data-qbact="playtime">' + svg(ICON.refresh) + ' 重新统计时长</button>' +
    '  <button class="danger sm" data-qbact="batch-unbind">' + svg(ICON.trash) + ' 批量解绑</button>' +
    '</div>' +
    '<p id="tswq-list-msg" class="muted" style="min-height:18px;margin:0"></p>' +
    '<div class="panel tswq-table-wrap">' +
    '  <table class="players-table">' +
    '    <thead><tr>' +
    '      <th style="width:34px"><input type="checkbox" id="tswq-check-all" title="全选本页"></th>' +
    '      <th>角色名</th>' +
    '      <th style="width:120px">QQ 号</th>' +
    '      <th style="width:130px">绑定来源</th>' +
    '      <th style="width:150px">绑定时间</th>' +
    '      <th style="width:150px">最近更新</th>' +
    '      <th style="width:110px">游戏时长</th>' +
    '      <th style="width:210px;text-align:right">操作</th>' +
    '    </tr></thead>' +
    '    <tbody id="tswq-tbody"></tbody>' +
    '  </table>' +
    '  <p id="tswq-empty" class="muted hidden" style="text-align:center;padding:24px 0;margin:0">暂无绑定</p>' +
    '</div>' +
    '<div id="tswq-pager"></div>'
}

function auditPaneHtml() {
  var opts = [50, 100, 200, 500, 1000].map(function (n) {
    return '<option value="' + n + '"' + (n === state.auditLimit ? ' selected' : '') + '>' + n + '</option>'
  }).join('')
  return '' +
    '<div class="toolbar">' +
    '  <h2 style="margin:0;font-size:16px">审计流水</h2>' +
    '  <div class="spacer"></div>' +
    '  <span class="muted" style="font-size:12px">显示最近</span>' +
    '  <select id="tswq-audit-limit" style="width:auto">' + opts + '</select>' +
    '  <span class="muted" style="font-size:12px">条</span>' +
    '  <button class="ghost sm" data-qbact="audit-refresh">' + svg(ICON.refresh) + ' 刷新</button>' +
    '</div>' +
    '<p id="tswq-audit-msg" class="muted" style="min-height:18px;margin:0"></p>' +
    '<div class="panel tswq-table-wrap">' +
    '  <table>' +
    '    <thead><tr>' +
    '      <th style="width:160px">时间</th>' +
    '      <th style="width:190px">动作</th>' +
    '      <th style="width:110px">操作者</th>' +
    '      <th style="width:120px">接入方式</th>' +
    '      <th>详情</th>' +
    '    </tr></thead>' +
    '    <tbody id="tswq-audit-tbody"></tbody>' +
    '  </table>' +
    '  <p id="tswq-audit-empty" class="muted hidden" style="text-align:center;padding:24px 0;margin:0">暂无审计记录</p>' +
    '</div>' +
    '<p class="tswq-hint">审计接口只支持 limit（最近 N 条，服务端上限 1000），没有服务端分页；要更早的记录请看数据目录下的 audit.jsonl。</p>'
}

function renderTabs() {
  if (!root) return
  var tabs = root.querySelectorAll('.tswq-tab[data-qbtab]')
  for (var i = 0; i < tabs.length; i++) {
    if (tabs[i].getAttribute('data-qbtab') === state.tab) tabs[i].classList.add('on')
    else tabs[i].classList.remove('on')
  }
  for (var j = 0; j < TAB_IDS.length; j++) {
    var pane = $('tswq-pane-' + TAB_IDS[j])
    if (!pane) continue
    if (TAB_IDS[j] === state.tab) pane.classList.remove('hidden')
    else pane.classList.add('hidden')
  }
}

function switchTab(tab) {
  if (TAB_IDS.indexOf(tab) < 0 || state.tab === tab) return
  state.tab = tab
  renderTabs()
  if (tab === 'settings') {
    background(loadConfig(), function () { setCfgMsg('读取配置异常，请重试', 'error') })
  } else if (tab === 'audit') {
    background(loadAudit(), function () { setAuditMsg('加载审计异常，请重试', 'error') })
  }
}

// ═══════════ 数据：服务器列表 / 台账列表 ═══════════

/**
 * 服务器列表（手动绑定的「指定服务器」下拉）。
 * 拉不到不阻塞页面：仍然可以"自动定位"，只是无法指定服务器。
 */
async function loadServers() {
  var res = await req('/api/servers')
  if (res.ok && res.data && Array.isArray(res.data.servers)) {
    state.servers = res.data.servers
    return
  }
  state.servers = []
  console.warn('[qq-bind] 服务器列表加载失败（仅影响「指定服务器」下拉）：' + errText(res))
}

/**
 * 台账列表。用**服务端** keyword + page/pageSize：
 * 后端 ledger.list 的 keyword 是"角色名或 QQ 的子串、大小写不敏感"过滤，且分页在过滤之后
 * （plugins/qq-bind/ledger.js:256-274），所以前端本地过滤只会过滤当前页，是错的。
 * 响应形状：{ total, page, pageSize, rows, playtimeSource }（index.js 的 GET /api/qq-bind/list 路由 + service.list）
 */
async function loadList() {
  setListMsg('正在加载...', 'muted')
  var url = '/api/qq-bind/list?keyword=' + encodeURIComponent(state.keyword) +
    '&page=' + state.page + '&pageSize=' + state.pageSize
  var res = await req(url)
  if (!res.ok || !res.data) {
    state.rows = []
    state.total = 0
    renderRows()
    renderPager()
    setListMsg('加载失败：' + errText(res), 'error')
    return
  }
  var d = res.data
  state.rows = Array.isArray(d.rows) ? d.rows : []
  state.total = Number(d.total) || 0
  if (Number(d.page) > 0) state.page = Number(d.page)
  if (Number(d.pageSize) > 0) state.pageSize = Number(d.pageSize)
  state.playtimeSource = d.playtimeSource || ''

  // 清理勾选：只保留本页仍存在的角色（翻页/搜索/解绑后不能让旧勾选继续生效）
  var alive = Object.create(null)
  for (var i = 0; i < state.rows.length; i++) {
    var n = state.rows[i] && state.rows[i].username
    if (n) alive[n] = true
  }
  for (var k in state.selected) {
    if (!Object.prototype.hasOwnProperty.call(state.selected, k)) continue
    if (!alive[k]) delete state.selected[k]
  }

  renderRows()
  renderPager()

  var msg = '共 ' + state.total + ' 条绑定'
  if (state.keyword) msg += '（关键字：' + state.keyword + '）'
  if (state.playtimeSource === 'unavailable') {
    msg += '；时长列不可用（未安装 online-stats 或取数失败）'
  }
  setListMsg(msg, 'muted')
}

function renderRows() {
  var tbody = $('tswq-tbody')
  if (!tbody) return
  var countEl = $('tswq-tabcount')
  if (countEl) countEl.textContent = state.total ? '(' + state.total + ')' : ''

  var empty = $('tswq-empty')
  if (!state.rows.length) {
    tbody.innerHTML = ''
    if (empty) empty.classList.remove('hidden')
    syncCheckAll()
    return
  }
  if (empty) empty.classList.add('hidden')

  tbody.innerHTML = state.rows.map(function (r) {
    var name = r && r.username != null ? String(r.username) : ''
    var qq = r && r.qq != null ? String(r.qq) : ''
    var checked = state.selected[name] ? ' checked' : ''

    // 时长：playtimeUnavailable=true 表示整份时长数据取不到（如实标注，不假装 0）；
    // 有数据时单位是分钟（online-stats getAllPlaytime 的契约）
    var timeCell
    if (r && r.playtimeUnavailable) {
      timeCell = '<span class="muted" title="未安装 online-stats 或时长数据取不到">-</span>'
    } else if (r && r.playtime != null) {
      timeCell = esc(fmtMinutes(r.playtime) || String(r.playtime) + ' 分钟')
    } else {
      timeCell = '<span class="muted">-</span>'
    }

    return '<tr>' +
      '<td><input type="checkbox" data-qbrow="' + esc(name) + '"' + checked + '></td>' +
      '<td><span class="tswq-mono" style="background:none;padding:0">' + esc(name) + '</span></td>' +
      '<td>' + (qq ? '<span class="tswq-mono">' + esc(qq) + '</span>' : '<span class="muted">-</span>') + '</td>' +
      '<td>' + (r && r.source ? esc(r.source) : '<span class="muted">-</span>') + '</td>' +
      '<td>' + (r && r.boundAt ? esc(fmtTime(r.boundAt)) : '<span class="muted">-</span>') + '</td>' +
      '<td>' + (r && r.updatedAt ? esc(fmtTime(r.updatedAt)) : '<span class="muted">-</span>') + '</td>' +
      '<td>' + timeCell + '</td>' +
      '<td style="text-align:right"><span class="ops" style="justify-content:flex-end">' +
      '<button class="ghost sm" data-qbact="rebind" data-qbname="' + esc(name) + '">改绑 QQ</button>' +
      '<button class="ghost sm" data-qbact="transfer" data-qbname="' + esc(name) + '">转移绑定</button>' +
      '<button class="danger sm" data-qbact="unbind" data-qbname="' + esc(name) + '">解绑</button>' +
      '</span></td>' +
      '</tr>'
  }).join('')
  syncCheckAll()
}

function renderPager() {
  var el = $('tswq-pager')
  if (!el) return
  var pages = Math.max(1, Math.ceil(state.total / state.pageSize))
  // 页码夹取：搜索/解绑会让总数变小，停在失效页码上会渲染出一片空白
  var p = parseInt(state.page, 10)
  if (!isFinite(p)) p = 1
  var cur = Math.min(Math.max(1, p), pages)
  state.page = cur
  if (state.total === 0) { el.innerHTML = ''; return }

  function btn(pg, text, on, disabled) {
    return '<button class="tswq-pg' + (on ? ' on' : '') + '" data-qbpage="' + pg + '"' +
      (disabled ? ' disabled' : '') + '>' + text + '</button>'
  }
  var lo = Math.max(2, cur - 2)
  var hi = Math.min(pages - 1, cur + 2)
  var html = '<div class="tswq-pager">' +
    '<span class="info">共 ' + state.total + ' 条绑定 · 第 ' + cur + '/' + pages + ' 页</span>' +
    btn('prev', '上一页', false, cur <= 1) +
    btn(1, '1', cur === 1, false)
  if (lo > 2) html += '<span class="gap">…</span>'
  for (var i = lo; i <= hi; i++) html += btn(i, String(i), i === cur, false)
  if (hi < pages - 1) html += '<span class="gap">…</span>'
  if (pages > 1) html += btn(pages, String(pages), cur === pages, false)
  html += btn('next', '下一页', false, cur >= pages) + '</div>'
  el.innerHTML = html
}

function selectedNames() {
  var out = []
  for (var k in state.selected) {
    if (Object.prototype.hasOwnProperty.call(state.selected, k) && state.selected[k]) out.push(k)
  }
  return out
}

function syncCheckAll() {
  var all = $('tswq-check-all')
  if (!all) return
  var total = state.rows.length
  var n = selectedNames().length
  all.checked = total > 0 && n === total
  all.indeterminate = n > 0 && n < total
}

async function reloadListThen(msg, cls) {
  await loadList()
  if (msg) setListMsg(msg, cls || 'ok')
}

// ═══════════ 分页 1：动作 ═══════════

/** 行内动作需要的台账行 */
function rowByName(name) {
  for (var i = 0; i < state.rows.length; i++) {
    var r = state.rows[i]
    if (r && String(r.username || '') === String(name)) return r
  }
  return null
}

/** 通用小弹窗外壳（挂在 document.body，事件直接绑在弹窗上，不走容器委托） */
function buildModal(title, innerHtml) {
  var el = document.createElement('div')
  el.className = 'modal-mask'
  el.innerHTML = '<div class="modal">' + '<h3>' + esc(title) + '</h3>' + innerHtml + '</div>'
  document.body.appendChild(el)
  return {
    el: el,
    q: function (sel) { return el.querySelector(sel) },
    close: function () { if (el.parentNode) el.parentNode.removeChild(el) },
    err: function (text) {
      var e = el.querySelector('.tswq-m-err')
      if (!e) return
      e.textContent = text || ''
      if (text) e.classList.remove('hidden')
      else e.classList.add('hidden')
    },
  }
}

function modalFooter(okText, danger) {
  return '<p class="tswq-m-err error hidden" style="margin:4px 0 0"></p>' +
    '<div class="row-actions">' +
    '<button type="button" class="ghost sm" data-mk="cancel">取消</button>' +
    '<button type="button" class="' + (danger ? 'danger' : 'primary') + ' sm" data-mk="ok">' + esc(okText) + '</button>' +
    '</div>'
}

function wireModal(m, onOk) {
  m.el.addEventListener('click', function (ev) {
    var t = ev.target
    if (!t || !t.closest) return
    var b = t.closest('[data-mk]')
    if (!b) return
    if (b.getAttribute('data-mk') === 'cancel') return m.close()
    // 与 safeHandler 同理：弹窗里的异常也不能漏出去（弹窗后台请求失败会 reject）
    try {
      var r = onOk(m, b)
      if (r && typeof r.then === 'function') background(r)
    } catch (err) {
      console.warn('[qq-bind] 弹窗操作异常：' + ((err && err.message) || err))
    }
  })
}

function serverOptionsHtml(defId) {
  var html = '<option value="">自动定位（角色名在所有服务器中唯一时可用）</option>'
  for (var i = 0; i < state.servers.length; i++) {
    var s = state.servers[i]
    if (!s || s.id == null) continue
    var label = String(s.name || s.id)
    if (s.enabled === false) label += '（已停用）'
    else if (s.connected) label += '（已连接）'
    else label += '（未连接）'
    html += '<option value="' + esc(s.id) + '"' + (String(s.id) === String(defId) ? ' selected' : '') + '>' +
      esc(label) + '</option>'
  }
  return html
}

/**
 * 手动绑定。
 * 接口：POST /api/qq-bind/bind { qq, player, serverId }（index.js 的该路由 → service.bind）
 * 成功响应：{ player, username, qq, server, servers, uuidSync, snapshot }
 * 冲突：角色名在多个服务器存在时抛 409，fail() 会把 err.servers 透传出来
 *   （index.js:972-979 的透传键含 'servers'；注意 'conflict' 与 'candidates' **不在**透传列表里，
 *     所以只能靠 data.servers 判断，不能读 data.conflict —— 那是读代码确认过的）
 * 其它错误：data.owner（该 QQ 已绑角色）/ data.boundQq（该角色已绑 QQ）/ data.serverHalfMissing
 */
function openBindModal() {
  var def = (state.config && state.config.binding && state.config.binding.defaultServerId) || ''
  var m = buildModal('手动绑定 QQ', '' +
    '<form>' +
    '<label>角色名<input id="tswq-bind-player" placeholder="游戏内角色名"></label>' +
    '<label>QQ 号<input id="tswq-bind-qq" placeholder="5-15 位数字"></label>' +
    '<label>指定服务器<select id="tswq-bind-server">' + serverOptionsHtml(def) + '</select></label>' +
    '<p class="tswq-hint">角色在多个服务器同名时必须指定服务器；不指定时服务端会自动定位，' +
    '定位到多个就会返回冲突并列出候选服。</p>' +
    '<div id="tswq-bind-cands"></div>' +
    modalFooter('绑定') +
    '</form>')

  wireModal(m, function (mm, btn) {
    if (btn.disabled) return
    return submit()
  })

  async function submit() {
    var player = String((m.q('#tswq-bind-player') || {}).value || '').trim()
    var qq = String((m.q('#tswq-bind-qq') || {}).value || '').trim()
    var serverId = String((m.q('#tswq-bind-server') || {}).value || '')
    if (!player) { m.err('请填写角色名'); return }
    if (!qq) { m.err('请填写 QQ 号'); return }

    var okBtn = m.q('[data-mk="ok"]')
    if (okBtn) okBtn.disabled = true
    m.err('')
    var res = await req('/api/qq-bind/bind', { method: 'POST', json: { player: player, qq: qq, serverId: serverId } })
    if (okBtn) okBtn.disabled = false

    var d = res.data || {}
    if (!res.ok || d.success === false) {
      var text = errText(res)
      if (d.owner) text += '（该 QQ 当前绑定角色：' + d.owner + '）'
      if (d.boundQq) text += '（该角色当前绑定 QQ：' + d.boundQq + '）'
      if (d.serverHalfMissing) text += '（目标服务器未安装 QqBind.dll，无法查询/建号）'
      m.err(text)
      renderCandidates(d)
      return
    }
    m.close()
    await reloadListThen('已绑定：' + (d.player || d.username || player) + ' → ' + (d.qq || qq) +
      (d.server ? '（服务器 ' + d.server + '）' : '') + snapshotText(d.snapshot))
  }

  /** 多服同名的候选服：让用户点一下就用那台服务器重试（这就是"把冲突提示给用户并让他选"） */
  function renderCandidates(d) {
    var box = m.q('#tswq-bind-cands')
    if (!box) return
    box.innerHTML = ''
    var list = Array.isArray(d.servers) ? d.servers : []
    if (!list.length) return
    box.innerHTML = '<p class="tswq-hint" style="margin:10px 0 6px">该角色名在这些服务器都存在，请选择要绑定的服务器：</p>' +
      '<div class="tswq-cands">' + list.map(function (s) {
        var id = s && s.id != null ? String(s.id) : ''
        var name = s && s.name != null ? String(s.name) : id
        return '<button type="button" class="ghost sm" data-qbsid="' + esc(id) + '">绑定到 ' + esc(name) + '</button>'
      }).join('') + '</div>'
    var btns = box.querySelectorAll('[data-qbsid]')
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener('click', safeHandler('弹窗候选服', function (ev) {
        var t = ev.target
        var b = t && t.closest ? t.closest('[data-qbsid]') : null
        if (!b) return
        var sel = m.q('#tswq-bind-server')
        if (sel) {
          var want = b.getAttribute('data-qbsid')
          // 下拉里未必有这台服务器（例如 /api/servers 拉取失败）：补一个选项再选中
          var found = false
          for (var k = 0; k < sel.options.length; k++) if (sel.options[k].value === want) found = true
          if (!found) {
            var opt = document.createElement('option')
            opt.value = want
            opt.textContent = b.textContent || want
            sel.appendChild(opt)
          }
          sel.value = want
        }
        return submit()
      }))
    }
  }
}

/**
 * 改绑 QQ。
 * 接口：POST /api/qq-bind/rebind { username, newQq }（index.js 的该路由 → service.rebind）
 * 成功响应：{ action:'rebound', username, fromQq, toQq, snapshot }
 * 注意：这里**只有**改 QQ。台账层面的"改名"没有管理路由（index.js 里没有 /rename），
 * 改名走 base 的玩家管理页，由 base 调 ctx.qqBind.renameAccount 联动（见 index.js 的 renameAccount）。
 */
function openRebindModal(name) {
  var row = rowByName(name)
  var oldQq = row && row.qq != null ? String(row.qq) : ''
  var m = buildModal('改绑 QQ - ' + name, '' +
    '<form>' +
    (oldQq ? '<p class="tswq-hint">当前绑定：<span class="tswq-mono">' + esc(oldQq) + '</span></p>' : '') +
    '<label>新的 QQ 号<input id="tswq-rebind-qq" placeholder="5-15 位数字"></label>' +
    '<p class="tswq-hint">改绑只改这台角色对应的 QQ 号，角色与账号数据不动。' +
    '改名请在「服务器设置 → 玩家管理」里改（那会联动台账下发快照）。</p>' +
    modalFooter('改绑') +
    '</form>')
  wireModal(m, function () {
    return doSubmit()
  })

  async function doSubmit() {
    var qq = String((m.q('#tswq-rebind-qq') || {}).value || '').trim()
    if (!qq) { m.err('请填写新的 QQ 号'); return }
    var okBtn = m.q('[data-mk="ok"]')
    if (okBtn) okBtn.disabled = true
    m.err('')
    var res = await req('/api/qq-bind/rebind', { method: 'POST', json: { username: name, newQq: qq } })
    if (okBtn) okBtn.disabled = false
    var d = res.data || {}
    if (!res.ok || d.success === false) {
      var text = errText(res)
      if (d.owner) text += '（该 QQ 当前绑定角色：' + d.owner + '）'
      m.err(text)
      return
    }
    m.close()
    await reloadListThen('已改绑：' + (d.username || name) + '　' + (d.fromQq || oldQq) + ' → ' + (d.toQq || qq) +
      snapshotText(d.snapshot))
  }
}

/**
 * 转移绑定：把 QQ 从当前角色移到另一个角色（原角色的绑定解除、账号与角色数据保留）。
 * 接口：POST /api/qq-bind/transfer { username, newPlayer, qq? }（index.js 的该路由 → service.transfer）
 * 成功响应：{ action:'transferred', fromUsername, toUsername, qq, snapshot }
 * 目标角色必须已在某个服务器存在且唯一（服务端会 locateAccount，否则 404 / 409+servers）。
 */
function openTransferModal(name) {
  var row = rowByName(name)
  var oldQq = row && row.qq != null ? String(row.qq) : ''
  var m = buildModal('转移绑定 - ' + name, '' +
    '<form>' +
    (oldQq ? '<p class="tswq-hint">要转移的 QQ：<span class="tswq-mono">' + esc(oldQq) + '</span></p>' : '') +
    '<label>目标角色名<input id="tswq-transfer-name" placeholder="已在游戏里存在的角色名"></label>' +
    '<p class="tswq-hint">把 QQ 绑定从「' + esc(name) + '」转到目标角色：原角色的绑定关系删除（账号与角色数据都保留），' +
    '目标角色必须已存在且在所有服务器里唯一，否则服务端会返回错误或冲突。</p>' +
    modalFooter('转移') +
    '</form>')
  wireModal(m, function () {
    return doSubmit()
  })

  async function doSubmit() {
    var target = String((m.q('#tswq-transfer-name') || {}).value || '').trim()
    if (!target) { m.err('请填写目标角色名'); return }
    var okBtn = m.q('[data-mk="ok"]')
    if (okBtn) okBtn.disabled = true
    m.err('')
    var res = await req('/api/qq-bind/transfer', { method: 'POST', json: { username: name, newPlayer: target } })
    if (okBtn) okBtn.disabled = false
    var d = res.data || {}
    if (!res.ok || d.success === false) {
      var text = errText(res)
      if (Array.isArray(d.servers) && d.servers.length) {
        text += '（候选服务器：' + d.servers.map(function (s) { return (s && (s.name || s.id)) || '?' }).join('、') + '）'
      }
      m.err(text)
      return
    }
    m.close()
    await reloadListThen('已转移：' + (d.fromUsername || name) + ' → ' + (d.toUsername || target) +
      '（QQ ' + (d.qq || oldQq) + '）' + snapshotText(d.snapshot))
  }
}

/**
 * 单条解绑。
 * 接口：POST /api/qq-bind/unbind { username }（index.js 的该路由 → service.unbind）
 * 成功响应：{ action:'unbound', username, qq, snapshot }
 */
async function unbindOne(name) {
  if (state.busy) return
  var row = rowByName(name)
  var qq = row && row.qq != null ? String(row.qq) : ''
  if (!window.confirm('确定解绑角色「' + name + '」' + (qq ? '（QQ ' + qq + '）' : '') + '？\n' +
    '只会删除绑定关系；各服账号与角色数据都保留，之后可以重新绑定。')) return
  setBusy(true)
  var res = await req('/api/qq-bind/unbind', { method: 'POST', json: { username: name } })
  setBusy(false)
  var d = res.data || {}
  if (!res.ok || d.success === false) {
    setListMsg('解绑失败：' + errText(res), 'error')
    return
  }
  delete state.selected[name]
  await reloadListThen('已解绑：' + (d.username || name) + '（QQ ' + (d.qq || qq) + '）' + snapshotText(d.snapshot))
}

/**
 * 批量解绑。
 * 接口：POST /api/qq-bind/batch { action:'unbind', users:[...] }（index.js 的该路由 → service.batchUnbind）
 * 成功响应：{ ok: 成功数, total, succeeded:[名字], failed:[{username,error}], snapshot }
 * 上限 100（index.js BATCH_LIMIT，超出返回 400）。
 */
async function batchUnbind() {
  if (state.busy) return
  var names = selectedNames()
  if (!names.length) { setListMsg('请先勾选要解绑的角色', 'error'); return }
  if (names.length > BATCH_LIMIT) {
    setListMsg('单次最多 ' + BATCH_LIMIT + ' 个，当前勾选 ' + names.length + ' 个', 'error')
    return
  }
  if (!window.confirm('确定批量解绑这 ' + names.length + ' 个角色？\n' +
    '只会删除绑定关系；各服账号与角色数据都保留。\n\n' + names.slice(0, 10).join('、') +
    (names.length > 10 ? ' 等' : ''))) return

  setBusy(true)
  setListMsg('正在批量解绑 ' + names.length + ' 个...', 'muted')
  var res = await req('/api/qq-bind/batch', { method: 'POST', json: { action: 'unbind', users: names } })
  setBusy(false)
  var d = res.data || {}
  if (!res.ok || d.success === false) {
    setListMsg('批量解绑失败：' + errText(res), 'error')
    return
  }
  for (var i = 0; i < names.length; i++) delete state.selected[names[i]]
  var msg = '批量解绑完成：成功 ' + (d.ok != null ? d.ok : '?') + '/' + (d.total != null ? d.total : names.length)
  var failed = Array.isArray(d.failed) ? d.failed : []
  if (failed.length) {
    msg += '；失败 ' + failed.length + ' 个：' + failed.slice(0, 5).map(function (f) {
      return ((f && f.username) || '?') + '（' + ((f && f.error) || '未知原因') + '）'
    }).join('、') + (failed.length > 5 ? ' 等' : '')
  }
  await reloadListThen(msg + snapshotText(d.snapshot))
}

/**
 * 重新统计时长。
 * 接口：POST /api/qq-bind/playtime-refresh（index.js:1085-1095）
 * 成功响应：{ ok:true, refreshed: 玩家数 }；未装 online-stats 时 501 { error, missingPlugin:'online-stats' }
 */
async function refreshPlaytime() {
  if (state.busy) return
  setBusy(true)
  setListMsg('正在触发时长统计（会向各服务器取数）...', 'muted')
  var res = await req('/api/qq-bind/playtime-refresh', { method: 'POST', json: {} })
  setBusy(false)
  var d = res.data || {}
  if (!res.ok || d.ok === false) {
    var text = '重新统计时长失败：' + errText(res)
    if (d.missingPlugin) text += '（缺少插件：' + d.missingPlugin + '）'
    setListMsg(text, 'error')
    return
  }
  await reloadListThen('已重新统计：刷新了 ' + (d.refreshed != null ? d.refreshed : '?') + ' 名玩家的累计时长')
}

// ═══════════ 分页 2：设置 ═══════════

/**
 * 读配置。
 * 接口：GET /api/qq-bind/config（index.js:1101-1103）→ { config, configFile }
 * config 已过 redactConfig（config.js:217-231）：adapters.<名>.token 是掩码字符串
 * `abc***xy（已设置，长度 N）`，并且补了布尔字段 tokenSet。
 */
async function loadConfig() {
  setCfgMsg('正在读取配置...', 'muted')
  var res = await req('/api/qq-bind/config')
  if (!res.ok || !res.data) {
    state.config = null
    state.configFile = ''
    renderSettings()
    setCfgMsg('读取配置失败：' + errText(res), 'error')
    return
  }
  state.config = res.data.config || null
  state.configFile = res.data.configFile || ''
  renderSettings()
  if (!state.config) setCfgMsg('服务端响应里没有 config 字段', 'error')
  else setCfgMsg('', 'muted')
}

function renderSettings() {
  var el = $('tswq-settings-body')
  if (!el) return
  if (!state.config) {
    el.innerHTML = '<div class="panel"><p class="error" style="margin:0 0 10px">配置未加载，无法显示设置项。</p>' +
      '<button class="ghost sm" data-qbact="cfg-reload">重新加载配置</button></div>'
    return
  }
  el.innerHTML = bannerHtml() + adapterPanelHtml() + tokenPanelHtml() + promotionPanelHtml() + importPanelHtml()
}

function bannerHtml() {
  var b = state.banner
  if (!b) return ''
  // 标题只表达"严重程度"，不表达具体语义：绝不再用「未生效」这类判断
  // （token 的 effective:false 不等于没生效，见 revealHtml 注释）
  var danger = b.kind === 'danger'
  return '<div class="tswq-banner ' + (danger ? 'is-danger' : 'is-warn') + '">' +
    '<div class="ttl">' + svg(ICON.alert) + (danger ? '出错' : '请注意') + '</div>' +
    '<div class="txt">' + esc(b.text) + '</div>' +
    '<button class="ghost sm" data-qbact="banner-dismiss">知道了</button>' +
    '</div>'
}

function adapterPanelHtml() {
  var a = legacyAdapter()
  var enabled = a.enabled !== false
  var perMin = (a.rateLimit && a.rateLimit.perMinute != null) ? a.rateLimit.perMinute : 60
  var wl = Array.isArray(a.groupWhitelist) ? a.groupWhitelist.join('\n') : ''
  return '<div class="panel">' +
    '<h3>机器人接入（内置适配器 legacy-http）</h3>' +
    '<p class="tswq-hint" style="margin-bottom:12px">' +
    '接入路径一律是 <code>/api/bot/*</code>，鉴权用请求头 <code>X-Bot-Token</code> 或查询参数 <code>?token=</code>' +
    '（adapters/legacy-http.js:124-143）。关闭适配器只影响机器人接口，不影响本管理页与其它接入方式。' +
    '</p>' +
    '<label class="tswq-check"><input type="checkbox" id="tswq-adapter-enabled"' + (enabled ? ' checked' : '') + '>' +
    ' 启用 /api/bot/*（关闭后机器人命令返回 503）</label>' +
    '<div class="tswq-form-row"><label>限流：每分钟请求数</label>' +
    '<input id="tswq-adapter-rate" type="number" min="0" step="1" value="' + esc(perMin) + '" style="max-width:160px">' +
    '<p class="tswq-hint">按适配器独立分桶的滑动窗口；0 = 不限流（legacy-http.js:78-87）。默认 60。</p></div>' +
    '<div class="tswq-form-row"><label>群白名单</label>' +
    '<textarea id="tswq-adapter-groups" rows="3" placeholder="一行一个群号，也可用逗号分隔">' + esc(wl) + '</textarea>' +
    '<p class="tswq-hint">当前后端只有保存与展示，未见据此拦截请求的实现（全仓库检索 groupWhitelist 只命中 ' +
    'config.js 的默认值 / 归一 / 白名单校验），改这里不会改变现有鉴权行为。</p></div>' +
    '<div class="tswq-form-row"><button class="primary sm" data-qbact="adapter-save">保存适配器配置</button></div>' +
    '</div>'
}

/** bot token 区：状态 / 掩码 / 轮换时间 / 手动设置 / 一次性明文回显 */
function tokenPanelHtml() {
  var a = legacyAdapter()
  var tokenSet = a.tokenSet === true
  var masked = typeof a.token === 'string' ? a.token : ''
  var rotatedAt = a.tokenRotatedAt ? String(a.tokenRotatedAt) : ''

  var html = '<div class="panel">' +
    '<h3>机器人密钥（bot token）</h3>' +
    '<div class="tswq-kv"><div class="k">状态</div><div class="v">' +
    (tokenSet ? '<span class="badge ok">已设置</span>' : '<span class="badge warn">未设置</span>') +
    '</div></div>' +
    '<div class="tswq-kv"><div class="k">当前值</div><div class="v">' +
    (tokenSet
      ? '<span class="tswq-mono">' + esc(masked || '（服务端未回显掩码）') + '</span>'
      : '<span class="muted">未设置：机器人接口返回 503，接入不可用</span>') +
    '</div></div>' +
    '<div class="tswq-kv"><div class="k">最近轮换</div><div class="v">' +
    (rotatedAt ? esc(fmtTime(rotatedAt)) : '<span class="muted">从未轮换</span>') +
    '</div></div>' +
    '<p class="tswq-hint" style="margin:10px 0 12px">' +
    '服务端只回显掩码，<strong>不提供任何明文回读通道</strong>：明文只出现在「重新生成」那一次响应里' +
    '（index.js:1175-1193）。掩码格式为 <code>前3位***后2位（已设置，长度 N）</code>。' +
    '</p>' +

    '<div class="tswq-form-row"><label>手动设置密钥</label>' +
    '<div class="tswq-inline">' +
    '<input id="tswq-token-input" type="password" autocomplete="new-password" placeholder="粘贴新的 bot token" style="min-width:240px;flex:1">' +
    '<button class="ghost sm" data-qbact="token-eye">显示</button>' +
    '<button class="primary sm" data-qbact="token-save">保存</button>' +
    '</div>' +
    '<p class="tswq-hint">首尾空白会被去掉（机器人鉴权是逐字符比较，粘贴带来的换行会让密钥永远不匹配）。' +
    '保存后立即生效（内存热更新 + 落盘），机器人那边要同步改成同一个值。' +
    '注意：若宿主设了环境变量 <code>TSWEB_QQBIND_TOKEN</code>，它在<strong>下次启动加载配置时会覆盖</strong>这里保存的值' +
    '（config.js:65-74 applyEnv），那时请改用环境变量。</p></div>' +

    '<div class="tswq-form-row"><label>轮换</label>' +
    '<div class="tswq-inline">' +
    '<button class="danger sm" data-qbact="token-rotate">' + svg(ICON.refresh) + ' 重新生成密钥</button>' +
    '<span class="muted" style="font-size:12px">旧密钥立即失效，机器人必须同步更新</span>' +
    '</div>' +
    '<p class="tswq-hint">不填内容时由服务端用 CSPRNG 生成 32 字节随机值（base64url，43 个字符）。</p></div>' +

    revealHtml() +
    '</div>'
  return html
}

/**
 * 轮换（或手动设置）后的一次性明文回显。
 *
 * 关于 effective / tokenFromEnv 的口径（**必须**理解对，否则会写错文案）：
 *   - 适配器是**每请求实时读内存配置**的，所以新 token 在本进程内**立即生效、马上就能用**；
 *   - tokenFromEnv:true + effective:false 表达的是「**不会被长期采用**」：只要环境变量
 *     TSWEB_QQBIND_TOKEN 还在，**下次启动**时 applyEnv（config.js:65-74）就会用环境变量
 *     把配置里的值覆盖回去，等于"重启后又变回环境变量那个 token"。
 *   → 所以这里**不**把 effective 当成败，也**不**给红绿图标：成功照常显示"已立即生效"，
 *     warning 存在时只额外把 warning 原文显示成一条黄色警告条。
 */
function revealHtml() {
  var r = state.tokenReveal
  if (!r) return ''
  var html = '<div class="tswq-reveal">' +
    '<div class="ttl">' + svg(ICON.key) + ' 新密钥（明文，只显示这一次）</div>' +
    '<div class="val" id="tswq-token-plain">' + esc(r.token || '（服务端未返回明文）') + '</div>' +
    '<div class="ok-note">已写入配置文件并<strong>立即生效</strong>，机器人现在就可以用这个值。' +
    (r.tokenRotatedAt ? '本次轮换时间：' + esc(fmtTime(r.tokenRotatedAt)) + '。' : '') +
    '</div>'
  // 服务端 warning 原文照抄，不改写、不判断成败
  if (r.warning) {
    html += '<div class="tswq-warn">' +
      '<div class="ttl">' + svg(ICON.alert) + ' 服务端提示</div>' +
      '<div class="txt">' + esc(r.warning) + '</div>' +
      '</div>'
  }
  html += '<div class="ops">' +
    (r.token ? '<button class="primary sm" data-qbact="token-copy">' + svg(ICON.copy) + ' 复制</button>' : '') +
    '<button class="ghost sm" data-qbact="token-dismiss">我已保存，关闭</button>' +
    '</div>' +
    '<div class="txt">此明文只显示这一次，请立即复制到机器人配置里（Koishi 的「机器人密钥」）。' +
    '关闭后无法再次查看，只能重新生成。</div>' +
    '</div>'
  return html
}

function promotionPanelHtml() {
  var p = (state.config && state.config.promotion) || {}
  var enabled = p.enabled === true
  var group = p.targetGroup == null ? '' : String(p.targetGroup)
  var mode = String(p.mode || 'auto') === 'auto' ? 'auto' : 'force'
  var ignore = Array.isArray(p.ignoreGroups) ? p.ignoreGroups.join('\n') : ''
  return '<div class="panel">' +
    '<h3>自动晋升（promotion）</h3>' +
    '<p class="tswq-hint" style="margin-bottom:12px">' +
    '这份配置随快照下发给游戏服，由服端在玩家登录时判断是否晋升' +
    '（plugins/qq-bind/plugin/QqPromotion.cs；载荷见 index.js 的 _snapshotPayloadFor）。改动会即时下发，不必重启。' +
    '</p>' +
    '<label class="tswq-check"><input type="checkbox" id="tswq-promo-enabled"' + (enabled ? ' checked' : '') + '>' +
    ' 启用登录时自动晋升</label>' +
    '<div class="tswq-form-row"><label>目标用户组</label>' +
    '<input id="tswq-promo-group" value="' + esc(group) + '" placeholder="例如 vip" style="max-width:240px">' +
    '<p class="tswq-hint">不能为空（服务端会拒绝空值）。该组必须在各服 TShock 里已存在，否则服端跳过并记警告。</p></div>' +
    '<div class="tswq-form-row"><label>模式</label>' +
    '<select id="tswq-promo-mode" style="max-width:420px">' +
    '<option value="auto"' + (mode === 'auto' ? ' selected' : '') + '>auto - 沿父组链判断，已达目标组则跳过</option>' +
    '<option value="force"' + (mode === 'force' ? ' selected' : '') + '>force - 直接改组，不做判断</option>' +
    '</select>' +
    '<p class="tswq-hint">语义来自服端（QqPromotion.cs:36、:112-117）：只有 auto 有特殊语义，其它值一律按 force。</p></div>' +
    '<div class="tswq-form-row"><label>忽略的用户组</label>' +
    '<textarea id="tswq-promo-ignore" rows="3" placeholder="一行一个，或用逗号分隔">' + esc(ignore) + '</textarea>' +
    '<p class="tswq-hint">命中这些组的玩家不晋升（QqPromotion.cs:81）。默认 owner / superadmin。</p></div>' +
    '<div class="tswq-form-row"><button class="primary sm" data-qbact="promo-save">保存晋升配置</button></div>' +
    '</div>'
}

function importPanelHtml() {
  var dir = dataDirHint()
  return '<div class="panel">' +
    '<h3>导入旧版台账</h3>' +
    '<p class="tswq-hint" style="margin-bottom:12px">' +
    '服务端只接受两类入参：<code>file</code>（<strong>必须在本插件数据目录内</strong>，目录外路径会被拒绝：' +
    '“只允许读取本插件数据目录下的文件”，index.js:1070-1083）或 <code>data</code>（直接给 JSON 对象）。' +
    '导入是幂等的，冲突逐条列出、不覆盖既有绑定。' +
    '</p>' +
    (dir ? '<p class="tswq-hint" style="margin-bottom:12px">本插件数据目录：<code>' + esc(dir) + '</code></p>' : '') +
    '<p class="tswq-hint" style="margin-bottom:12px">' +
    '要导入数据目录外的文件，请用终端命令：<code>qqbind-import &lt;路径&gt; [--dry]</code>' +
    '（它走的是同一个导入实现，只是不受数据目录限制）。</p>' +
    '<div class="tswq-form-row"><label>文件路径（相对上面的数据目录）</label>' +
    '<input id="tswq-import-path" placeholder="例如 legacy-qq_accounts.json"></div>' +
    '<label class="tswq-check"><input type="checkbox" id="tswq-import-dry"> 试运行（只统计，不写入台账）</label>' +
    '<div class="tswq-form-row"><div class="tswq-inline">' +
    '<button class="primary sm" data-qbact="import-file">从文件导入</button>' +
    '<button class="ghost sm" data-qbact="import-json">导入下方粘贴的 JSON</button>' +
    '</div></div>' +
    '<div class="tswq-form-row"><label>或直接粘贴旧台账 JSON</label>' +
    '<textarea id="tswq-import-json" rows="4" placeholder="{\"records\":{\"角色名\":{\"qq\":\"12345\"}}}"></textarea></div>' +
    importResultHtml() +
    '</div>'
}

function importResultHtml() {
  if (state.importError) {
    return '<div class="tswq-result"><span class="error">' + esc(state.importError) + '</span></div>'
  }
  var r = state.importResult
  if (!r) return ''

  var imported = Array.isArray(r.imported) ? r.imported : []
  var skipped = Array.isArray(r.skipped) ? r.skipped : []
  var conflicts = Array.isArray(r.conflicts) ? r.conflicts : []
  var dry = r.applied !== true

  var html = '<div class="tswq-result">' +
    (dry ? '<strong>试运行：未写入台账</strong>（或本次没有可新增的条目）' : '<strong>已写入台账</strong>') +
    '<br>新增 ' + imported.length + ' 条 · 跳过 ' + skipped.length + ' 条 · 冲突 ' + conflicts.length + ' 条'
  if (r.appliedCount != null) html += ' · 实际写入 ' + esc(r.appliedCount) + ' 条'
  if (!dry && imported.length) html += '<br>' + esc(snapshotText(r.snapshot) || '；快照下发结果未返回')

  if (conflicts.length) {
    html += '<div class="scroll"><table><thead><tr><th>角色名</th><th>说明</th></tr></thead><tbody>' +
      conflicts.slice(0, 50).map(function (c) {
        var name = (c && c.username) || ''
        var why = ''
        if (c && (c.existingQq != null || c.incomingQq != null)) {
          why = '台账已绑 ' + (c.existingQq != null ? c.existingQq : '?') + '，导入值为 ' + (c.incomingQq != null ? c.incomingQq : '?')
        } else if (c && (c.reason || c.error)) {
          why = c.reason || c.error
        } else {
          try { why = JSON.stringify(c) } catch (e) { why = '（无法显示）' }
        }
        return '<tr><td>' + esc(name) + '</td><td>' + esc(why) + '</td></tr>'
      }).join('') + '</tbody></table></div>'
    if (conflicts.length > 50) html += '<br>（另有 ' + (conflicts.length - 50) + ' 条冲突未显示）'
  }
  if (skipped.length) {
    html += '<div class="scroll"><table><thead><tr><th>跳过</th><th>原因</th></tr></thead><tbody>' +
      skipped.slice(0, 30).map(function (s) {
        return '<tr><td>' + esc((s && s.username) || '') + '　' + esc((s && s.qq) || '') + '</td><td>' +
          esc((s && s.reason) || '') + '</td></tr>'
      }).join('') + '</tbody></table></div>'
    if (skipped.length > 30) html += '<br>（另有 ' + (skipped.length - 30) + ' 条跳过记录未显示）'
  }
  return html + '</div>'
}

/**
 * 保存一组配置项：POST /api/qq-bind/config { updates }（index.js:1106-1126）→ { ok, config, snapshot }
 *
 * 只发请求并算好要显示的话，**不自己写消息区**：调用方随后要 loadConfig() 刷新状态区，
 * 而 loadConfig 会重渲染并清空消息，先写就会立刻被清掉（"保存失败"闪一下就不见了）。
 * @returns {Promise<{ ok: boolean, msg: string, cls: string }>}
 */
async function saveUpdates(updates, okMsg) {
  setBusy(true)
  setCfgMsg('正在保存...', 'muted')
  var res = await req('/api/qq-bind/config', { method: 'POST', json: { updates: updates } })
  setBusy(false)
  var d = res.data || {}
  if (!res.ok || d.ok === false) {
    return { ok: false, msg: '保存失败：' + errText(res), cls: 'error' }
  }
  // 成败只看 ok；响应里若带 warning（例如环境变量会在下次启动覆盖），原文显示成一条警告条，
  // 但**不**据此改成败、也不改图标颜色 —— 配置已经写进去且本进程立即生效
  if (d.warning) {
    state.banner = { kind: 'warn', text: String(d.warning) }
  }
  var msg = okMsg
  var sn = snapshotText(d.snapshot)
  if (sn) msg += sn
  return { ok: true, msg: msg, cls: 'ok' }
}

/** 手动设置密钥：走 POST /config 写 adapters.legacy-http.token（白名单可写，config.js:163） */
async function saveToken() {
  if (state.busy) return
  var input = $('tswq-token-input')
  if (!input) return
  var val = String(input.value || '').trim()
  if (!val) {
    setCfgMsg('请填写新的 bot token。本页不支持把密钥清空（清空会让机器人接口返回 503，等于关掉接入）。', 'error')
    return
  }
  var r = await saveUpdates({ 'adapters.legacy-http.token': val }, '密钥已保存')
  await loadConfig()
  if (!r.ok) { setCfgMsg(r.msg, r.cls); return }
  // 二次核对：服务端回显的掩码应当正好对应刚写入的值（掩码格式见 config.js:222；
  // 口径不一致说明服务端当前的 token 不是我们刚写进去的那个值——这是真的异常，要报出来）
  var after = legacyAdapter()
  var expect = val.slice(0, 3) + '***' + val.slice(-2) + '（已设置，长度 ' + val.length + '）'
  if (after.tokenSet === true && typeof after.token === 'string' && after.token !== '' && after.token !== expect) {
    state.banner = {
      kind: 'warn',
      text: '保存后服务端回显的密钥与刚写入的值不一致，当前实际使用的可能不是这次保存的值。服务端回显：' + after.token,
    }
    renderSettings()
    setCfgMsg('已保存，但服务端回显的密钥与写入值不一致（见上方提示）', 'error')
    return
  }
  setCfgMsg(r.msg + '。请把同一个值填到机器人的「机器人密钥」里。', r.cls)
}

/**
 * 重新生成密钥。
 * 接口：POST /api/qq-bind/token/rotate（index.js:1142-1193；响应契约由 test/lookup.test.mjs:278-298 严格断言）
 * → { ok, token, tokenSet, tokenRotatedAt, tokenFromEnv, effective, warning? }
 * 明文只在这一条响应里返回，之后 /config 与 /status 永远只有掩码 —— 所以必须当场显示出来。
 */
async function rotateToken() {
  if (state.busy) return
  if (!window.confirm('重新生成机器人密钥？\n旧密钥会立即失效，机器人（Koishi）必须同步改成新密钥才能继续工作。')) return
  setBusy(true)
  setCfgMsg('正在重新生成...', 'muted')
  var res = await req('/api/qq-bind/token/rotate', { method: 'POST', json: {} })
  setBusy(false)
  var d = res.data || {}
  if (!res.ok || d.ok === false) {
    setCfgMsg('重新生成失败：' + errText(res), 'error')
    return
  }

  state.tokenReveal = {
    token: typeof d.token === 'string' ? d.token : '',
    tokenRotatedAt: d.tokenRotatedAt || '',
    // 只留 warning：不保留 tokenFromEnv / effective，避免以后再被误当成"成败"来判断
    warning: d.warning ? String(d.warning) : '',
  }
  // warning 存在（例如"环境变量还在，下次启动会覆盖回来"）时额外给一条黄色警告条，
  // 原文照抄。这**不影响**成功状态：新密钥在本进程内已经立即生效了。
  if (state.tokenReveal.warning) {
    state.banner = { kind: 'warn', text: state.tokenReveal.warning }
  }
  await loadConfig() // 刷新状态区的 tokenSet / 掩码 / 轮换时间（tokenReveal 在 state 里，会一起重渲染）
  setCfgMsg('密钥已重新生成并立即生效，请立即复制下方明文，然后更新机器人配置', 'ok')
}

/** 保存适配器配置（enabled / rateLimit.perMinute / groupWhitelist，均为白名单可写项） */
async function saveAdapter() {
  if (state.busy) return
  var enabledEl = $('tswq-adapter-enabled')
  var rateEl = $('tswq-adapter-rate')
  var groupsEl = $('tswq-adapter-groups')
  if (!enabledEl || !rateEl || !groupsEl) return

  var perMin = Number(String(rateEl.value || '').trim())
  if (!isFinite(perMin) || perMin < 0) {
    setCfgMsg('限流必须是 >= 0 的数字（0 表示不限流）', 'error')
    return
  }
  var r = await saveUpdates({
    'adapters.legacy-http.enabled': enabledEl.checked === true,
    'adapters.legacy-http.rateLimit.perMinute': Math.floor(perMin),
    'adapters.legacy-http.groupWhitelist': splitList(groupsEl.value),
  }, '适配器配置已保存并即时下发')
  await loadConfig()
  setCfgMsg(r.msg, r.cls)
}

/** 保存晋升配置（promotion.*，均为白名单可写项；targetGroup 不能为空） */
async function savePromotion() {
  if (state.busy) return
  var enabledEl = $('tswq-promo-enabled')
  var groupEl = $('tswq-promo-group')
  var modeEl = $('tswq-promo-mode')
  var ignoreEl = $('tswq-promo-ignore')
  if (!enabledEl || !groupEl || !modeEl || !ignoreEl) return

  var group = String(groupEl.value || '').trim()
  if (!group) {
    setCfgMsg('目标用户组不能为空（服务端会拒绝空值）', 'error')
    return
  }
  var mode = String(modeEl.value || 'auto') === 'auto' ? 'auto' : 'force'
  var r = await saveUpdates({
    'promotion.enabled': enabledEl.checked === true,
    'promotion.targetGroup': group,
    'promotion.mode': mode,
    'promotion.ignoreGroups': splitList(ignoreEl.value),
  }, '晋升配置已保存并即时下发')
  await loadConfig()
  setCfgMsg(r.msg, r.cls)
}

/**
 * 导入旧台账。
 * 接口：POST /api/qq-bind/import { file | data, dryRun }（index.js:1070-1083）
 * → ledger.import 的结果 { imported, skipped, conflicts, applied, appliedCount? } + snapshot
 *   （ledger.js:453-508：dryRun 或没有可新增条目时 applied=false，且**没有** appliedCount）
 */
async function doImport(kind) {
  if (state.busy) return
  var dryEl = $('tswq-import-dry')
  var dryRun = !!(dryEl && dryEl.checked)
  var body = { dryRun: dryRun }

  if (kind === 'file') {
    var pathEl = $('tswq-import-path')
    var file = String((pathEl && pathEl.value) || '').trim()
    if (!file) { setCfgMsg('请填写数据目录内的文件路径', 'error'); return }
    body.file = file
  } else {
    var jsonEl = $('tswq-import-json')
    var text = String((jsonEl && jsonEl.value) || '').trim()
    if (!text) { setCfgMsg('请先粘贴旧台账 JSON', 'error'); return }
    var parsed
    try {
      parsed = JSON.parse(text)
    } catch (err) {
      setCfgMsg('粘贴的内容不是合法 JSON：' + ((err && err.message) || err), 'error')
      return
    }
    body.data = parsed
  }

  state.importError = ''
  state.importResult = null
  setBusy(true)
  setCfgMsg(dryRun ? '正在试运行导入...' : '正在导入...', 'muted')
  var res = await req('/api/qq-bind/import', { method: 'POST', json: body })
  setBusy(false)
  var d = res.data || {}
  if (!res.ok || d.success === false) {
    state.importError = errText(res) + (d.hint ? '（' + d.hint + '）' : '')
    // loadConfig() 会重渲染设置区（把 importError 显示出来），但它同时清空消息区，
    // 所以失败提示必须在它之后再写一次
    await loadConfig()
    setCfgMsg('导入失败', 'error')
    return
  }
  state.importResult = d
  var n = Array.isArray(d.imported) ? d.imported.length : 0
  await loadConfig()
  setCfgMsg(d.applied === true ? '导入完成：新增 ' + n + ' 条' : '试运行完成：可新增 ' + n + ' 条（未写入）')
  if (d.applied === true) await loadList()
}

// ═══════════ 分页 3：审计 ═══════════

/**
 * 审计流水。
 * 接口：GET /api/qq-bind/audit?limit=N（index.js:1097-1099）→ { rows: [...] }
 * 行形状（audit.js:26-39）：{ t, action, actor, adapter, ...entry }，新的在前；limit 夹在 1..1000。
 */
async function loadAudit() {
  setAuditMsg('正在加载...', 'muted')
  var res = await req('/api/qq-bind/audit?limit=' + encodeURIComponent(state.auditLimit))
  if (!res.ok || !res.data) {
    state.audit = []
    renderAudit()
    setAuditMsg('加载失败：' + errText(res), 'error')
    return
  }
  state.audit = Array.isArray(res.data.rows) ? res.data.rows : []
  renderAudit()
  setAuditMsg('共 ' + state.audit.length + ' 条（最近 ' + state.auditLimit + ' 条以内）', 'muted')
}

function auditDetailText(row) {
  var parts = []
  for (var k in row) {
    if (!Object.prototype.hasOwnProperty.call(row, k)) continue
    if (isAuditColumnKey(k)) continue
    var val = row[k]
    if (val === null || val === undefined || val === '') continue
    var text
    if (typeof val === 'object') {
      try { text = JSON.stringify(val) } catch (e) { text = '[无法序列化的值]' }
    } else {
      text = String(val)
    }
    parts.push(k + '=' + text)
  }
  return parts.join('　')
}

function renderAudit() {
  var tbody = $('tswq-audit-tbody')
  if (!tbody) return
  var empty = $('tswq-audit-empty')
  if (!state.audit.length) {
    tbody.innerHTML = ''
    if (empty) empty.classList.remove('hidden')
    return
  }
  if (empty) empty.classList.add('hidden')
  tbody.innerHTML = state.audit.map(function (r) {
    var row = r || {}
    var detail = auditDetailText(row)
    // 详情可能很长（例如 servers 数组）：显示截断，完整内容放 title
    var shown = detail.length > 240 ? detail.slice(0, 240) + '…' : detail
    return '<tr>' +
      '<td>' + (row.t ? esc(fmtTime(row.t)) : '<span class="muted">-</span>') + '</td>' +
      '<td><span class="tswq-mono">' + esc(row.action || '-') + '</span></td>' +
      '<td>' + esc(row.actor || '-') + '</td>' +
      '<td>' + (row.adapter ? esc(row.adapter) : '<span class="muted">-</span>') + '</td>' +
      '<td style="font-size:12px;word-break:break-all"' + (detail ? ' title="' + esc(detail) + '"' : '') + '>' +
      esc(shown) + '</td>' +
      '</tr>'
  }).join('')
}

// ═══════════ 事件 ═══════════

function onInput(ev) {
  var t = ev.target
  if (!t || t.id !== 'tswq-search') return
  state.keyword = String(t.value || '')
  if (searchTimer) clearTimeout(searchTimer)
  searchTimer = setTimeout(function () {
    searchTimer = null
    state.page = 1
    background(loadList())
  }, 350)
}

function onChange(ev) {
  var t = ev.target
  if (!t || !t.id) return
  if (t.id === 'tswq-check-all') {
    var on = t.checked === true
    state.selected = Object.create(null)
    if (on) {
      for (var i = 0; i < state.rows.length; i++) {
        var n = state.rows[i] && state.rows[i].username
        if (n) state.selected[n] = true
      }
    }
    renderRows()
    return
  }
  if (t.id === 'tswq-pagesize') {
    var ps = parseInt(t.value, 10)
    if (isFinite(ps) && ps > 0) {
      state.pageSize = ps
      state.page = 1
      background(loadList())
    }
    return
  }
  if (t.id === 'tswq-audit-limit') {
    var lim = parseInt(t.value, 10)
    if (isFinite(lim) && lim > 0) {
      state.auditLimit = lim
      background(loadAudit())
    }
    return
  }
  if (t.getAttribute && t.getAttribute('data-qbrow') != null) {
    var name = t.getAttribute('data-qbrow')
    if (t.checked) state.selected[name] = true
    else delete state.selected[name]
    syncCheckAll()
  }
}

/**
 * 把事件处理函数包成"绝不向外抛"的形式：
 * 同步异常就地记日志，返回的 Promise 交给 background() 兜 rejection。
 * 事件监听器里的异常浏览器不会替我们处理（顶多在控制台报一条 unhandledrejection），
 * 后果是"点了按钮没反应"且看不出原因。
 */
function safeHandler(label, fn) {
  return function (ev) {
    try {
      var r = fn(ev)
      if (r && typeof r.then === 'function') background(r)
    } catch (err) {
      console.warn('[qq-bind] ' + label + '处理异常：' + ((err && err.message) || err))
    }
  }
}

function onClick(ev) {
  var t = ev.target
  if (!t || !t.closest) return
  // container（#plugin-view-content）是所有插件视图共享的容器，本监听器挂上后不随视图切换消失：
  // 只有本页确实渲染在容器里时才处理，避免与别的插件视图串扰
  if (!root || !root.querySelector('.tswq-wrap')) return

  var tabEl = t.closest('.tswq-tab[data-qbtab]')
  if (tabEl && root.contains(tabEl)) {
    switchTab(tabEl.getAttribute('data-qbtab'))
    return
  }

  var pgBtn = t.closest('[data-qbpage]')
  if (pgBtn && root.contains(pgBtn)) {
    if (pgBtn.disabled) return
    var pages = Math.max(1, Math.ceil(state.total / state.pageSize))
    var want = pgBtn.getAttribute('data-qbpage')
    if (want === 'prev') want = state.page - 1
    else if (want === 'next') want = state.page + 1
    want = parseInt(want, 10)
    if (!(want >= 1) || want > pages || want === state.page) return
    state.page = want
    background(loadList())
    return
  }

  // 按钮内容多是 svg 图标，点击落在 <svg>/<path> 上，必须向上找最近的 [data-qbact]
  var btn = t.closest('[data-qbact]')
  if (!btn || !root.contains(btn) || btn.disabled) return
  var act = btn.getAttribute('data-qbact')
  var name = btn.getAttribute('data-qbname') || ''

  if (act === 'search') { state.page = 1; loadList(); return }
  if (act === 'open-bind') return openBindModal()
  if (act === 'playtime') return refreshPlaytime()
  if (act === 'batch-unbind') return batchUnbind()
  if (act === 'rebind') return openRebindModal(name)
  if (act === 'transfer') return openTransferModal(name)
  if (act === 'unbind') return unbindOne(name)
  if (act === 'cfg-reload') return loadConfig()
  if (act === 'banner-dismiss') { state.banner = null; renderSettings(); return }
  if (act === 'adapter-save') return saveAdapter()
  if (act === 'promo-save') return savePromotion()
  if (act === 'token-save') return saveToken()
  if (act === 'token-rotate') return rotateToken()
  if (act === 'token-dismiss') { state.tokenReveal = null; renderSettings(); return }
  if (act === 'token-copy') return copyTokenPlain()
  if (act === 'token-eye') {
    var input = $('tswq-token-input')
    if (!input) return
    var show = input.type === 'password'
    input.type = show ? 'text' : 'password'
    btn.textContent = show ? '隐藏' : '显示'
    return
  }
  if (act === 'import-file') return doImport('file')
  if (act === 'import-json') return doImport('json')
  if (act === 'audit-refresh') return loadAudit()
}

/** 复制一次性明文（复制失败要如实说，不能静默假装成功） */
async function copyTokenPlain() {
  var r = state.tokenReveal
  if (!r || !r.token) return
  var ok = await copyText(r.token)
  setCfgMsg(ok ? '已复制到剪贴板，请粘贴到机器人配置里' : '复制失败：请手动选中下方明文复制', ok ? 'ok' : 'error')
}

// ═══════════ 视图注册 ═══════════

if (tsw && typeof tsw.registerView === 'function') {
  try {
    tsw.registerView({
      id: 'qq-bind',
      title: 'QQ 绑定',
      section: '后端设置',
      path: '/b/qq-bind',
      icon: 'key',
      render: function (container) {
        root = container
        injectStyle()
        renderShell(container)

        /**
         * 事件委托：每次都先按同一引用解绑、再绑（不是用"只绑一次"的标记）。
         * 宿主的 route() 每次进入本路由都调 render(container)，而 container 是常驻的
         * #plugin-view-content：无条件下 addEventListener 会让监听器随访问次数累加，
         * 一次点击被执行 N 次（解绑弹 N 个确认框、批量解绑发 N 个请求）。
         * 但也不能只靠标记：插件热重载会用新的 cache-busting query 重新 import，
         * 新实例若因标记仍在而跳过绑定，点击会继续由旧 bundle 的闭包处理。
         */
        if (container.__tswqClick) container.removeEventListener('click', container.__tswqClick)
        if (container.__tswqInput) container.removeEventListener('input', container.__tswqInput)
        if (container.__tswqChange) container.removeEventListener('change', container.__tswqChange)
        container.__tswqClick = safeHandler('点击', onClick)
        container.__tswqInput = safeHandler('输入', onInput)
        container.__tswqChange = safeHandler('选择', onChange)
        container.addEventListener('click', container.__tswqClick)
        container.addEventListener('input', container.__tswqInput)
        container.addEventListener('change', container.__tswqChange)

        // 首屏：服务器列表（绑定弹窗用）+ 配置（token 状态 / 合法默认值）+ 台账列表
        background(loadServers())
        background(loadConfig(), function () { setCfgMsg('读取配置异常，请重试', 'error') })
        background(loadList(), function () { setListMsg('加载异常，请重试', 'error') })
      },
    })
    console.log('[tsweb] qq-bind 客户端插件已注册: #/b/qq-bind')
  } catch (err) {
    console.warn('[qq-bind] 注册管理页失败：' + ((err && err.message) || err))
  }
} else {
  console.warn('[qq-bind] 宿主未提供 window.tsweb.registerView，管理页未注册')
}
