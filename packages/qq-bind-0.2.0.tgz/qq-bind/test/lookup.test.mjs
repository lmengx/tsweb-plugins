/**
 * 「查 QQ 号」公共 API + bot token 轮换的测试
 *
 * 覆盖两件容易出错的对外契约：
 *   1. ctx.qqBind.qqOf / qqMap（供其它插件在玩家列表里显示"QQ 用户名"）与
 *      POST /api/qq-bind/lookup —— 未绑定的名字**不出现**（不是 null 占位），
 *      且批量查询**只遍历一次台账内存索引**（打桩计量，见下）
 *   2. POST /api/qq-bind/token/rotate —— 明文只在响应里出现一次，
 *      之后 GET /api/qq-bind/config 仍只给掩码；环境变量 TSWEB_QQBIND_TOKEN
 *      生效时如实返回 tokenFromEnv/effective/warning，不静默假成功
 *
 * 注意：本测试**不启动任何服务器进程**，只在测试进程内挂一个 express 实例
 * （与 apply.test.mjs 同款做法）。
 * 运行：node test/lookup.test.mjs（本沙箱里 node --test test/ 会 spawn EPERM，必须逐个文件跑）
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, readFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import express from 'express'
import { Context } from '@deepseek-ai/cordis'

import { Ledger } from '../ledger.js'
import { loadConfig } from '../config.js'

let dataDir
let app
let server
let base
let ctx
let svc
let dispose

const ENV_TOKEN = 'token-from-env-for-rotate-test'

before(async () => {
  dataDir = await mkdtemp(path.join(tmpdir(), 'qqbind-lookup-'))
  // 本文件默认**不带**环境变量：tokenFromEnv 分支由用例临时设置后自行还原
  delete process.env.TSWEB_QQBIND_TOKEN

  app = express()
  app.use(express.json())

  ctx = new Context()
  ctx.webServer = { app }
  // 鉴权中间件做成**可观测行为**：不带 x-test-auth 头即 401，
  // 这样"新路由是否真的抄了 ...admin"是被行为验证的，而不是看代码结构
  ctx.auth = {
    verifyAuth: () => (req, res, next) =>
      String(req.get('x-test-auth') || '') === 'ok' ? next() : res.status(401).json({ error: '未登录' }),
    requireAdmin: () => (req, res, next) => next(),
  }
  ctx.paths = { dataOf: (n) => path.join(dataDir, n) }
  ctx.logger = { info() {}, warn() {}, error() {} }
  // 台账直写时不希望推送真的打游戏服：没有启用中的服务器即可
  ctx.servers = { list: async () => [], getRaw: () => null }
  ctx.tshock = { fetchFor: async () => ({ ok: false, status: 404, data: {} }), postFor: async () => ({ ok: false, status: 404, data: {} }) }

  const mod = await import('../index.js')
  dispose = mod.apply(ctx)
  await ctx.qqBind.ready
  svc = ctx.qqBind

  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', resolve)
  })
  base = `http://127.0.0.1:${server.address().port}`
})

after(async () => {
  delete process.env.TSWEB_QQBIND_TOKEN
  if (dispose) dispose()
  if (server) await new Promise((resolve) => server.close(resolve))
  await rm(dataDir, { recursive: true, force: true })
})

/** 管理路由请求（默认带头通过测试鉴权） */
function api(pathname, body, { auth = 'ok' } = {}) {
  return fetch(`${base}${pathname}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(auth ? { 'x-test-auth': auth } : {}) },
    body: JSON.stringify(body === undefined ? {} : body),
  })
}

async function readJson(res) {
  const text = await res.text()
  let data = null
  try {
    data = JSON.parse(text)
  } catch {
    data = null
  }
  return { status: res.status, data, text }
}

// ══════════════════════════════════════════════════════════════
// 服务公共方法（其它插件直接调用）
// ══════════════════════════════════════════════════════════════

test('qqOf：命中 / 未命中 / 大小写不敏感（aliases 只解析大小写，不解析改名历史）', async () => {
  await svc.ledger.bind({ qq: '10001', username: 'Steve', passwordHash: 'h1', source: 'test' })
  await svc.ledger.bind({ qq: '10002', username: 'Alex', passwordHash: 'h2', source: 'test' })
  // 改名：旧名进入 aliases（台账既有语义），新名可查
  await svc.renameAccount('Alex', 'AlexRenamed', { source: 'test' })

  assert.equal(svc.qqOf('Steve'), '10001', '命中')
  assert.equal(svc.qqOf('steve'), '10001', '大小写不敏感')
  assert.equal(svc.qqOf('  STEVE  '), '10001', '首尾空白应被规范化')
  assert.equal(svc.qqOf('AlexRenamed'), '10002', '新名可查')
  assert.equal(
    svc.qqOf('Alex'),
    null,
    '改名后的旧名不再解析（ledger.rename 把 aliases["alex"] 指向已删除的 "Alex"，getByUsername 同样返回 null）',
  )
  assert.equal(svc.qqOf('alexrenamed'), '10002', '新名大小写不敏感')
  assert.equal(svc.qqOf('Nobody'), null, '未绑定 → null')
  assert.equal(svc.qqOf(''), null, '空入参 → null')
  assert.equal(svc.qqOf(null), null, 'null 入参 → null')
})

test('qqMap：批量划分命中/未命中，键是传入名字原文', () => {
  const out = svc.qqMap(['Steve', 'STEVE', 'AlexRenamed', 'alexrenamed', 'Nobody', ''])
  // 键 = 传入原文（不归一大小写）；未查到的键**不出现**；重复名字合并为一个键
  assert.deepEqual(out, {
    Steve: '10001',
    STEVE: '10001',
    AlexRenamed: '10002',
    alexrenamed: '10002',
  })
  assert.equal('Nobody' in out, false, '未绑定的名字不应出现（不是 null 占位）')
  assert.equal('' in out, false, '空名字不应出现')

  assert.deepEqual(svc.qqMap([]), {}, '空数组 → 空对象')
  assert.deepEqual(svc.qqMap(null), {}, '非数组入参 → 空对象（不抛错，调用方不必先判类型）')
})

test('qqMap 只读一次台账：一趟建索引，之后 O(1) 查表（打桩计量）', () => {
  const ledger = new Ledger({ file: path.join(dataDir, 'bindings.json') })
  const records = { Steve: { qq: '10001' }, Alex: { qq: '10002' }, Bob: { qq: '10003' } }
  let enumerations = 0
  // 台账内存索引被遍历几次，直接计量（Object.entries 会触发一次 ownKeys）
  ledger.records = new Proxy(records, {
    ownKeys: (t) => {
      enumerations++
      return Reflect.ownKeys(t)
    },
  })
  ledger.aliases = { steve: 'Steve', alex: 'Alex', bob: 'Bob', ghost: 'Ghost' }

  const index = ledger.qqIndex()
  assert.equal(enumerations, 1, '建索引只应遍历台账一次，与查询名字个数无关')
  assert.equal(index.get('steve'), '10001')
  assert.equal(index.get('bob'), '10003')
  assert.equal(index.has('ghost'), false, 'aliases 指向已不在册的名字（解绑/删号后）不收录，与 getByUsername 一致')

  // 与逐个查的口径完全一致（不论大小写）
  for (const name of ['Steve', 'STEVE', 'alex', 'Bob', 'Nobody', 'ghost']) {
    const one = ledger.getByUsername(name)
    assert.equal(index.get(String(name).trim().toLowerCase()) ?? null, one ? one.qq : null)
  }
})

test('qqMap 不逐个查台账：全程只调一次 qqIndex，且不碰 getByUsername/getByQq', () => {
  let indexCalls = 0
  let perNameCalls = 0
  const realIndex = svc.ledger.qqIndex
  svc.ledger.qqIndex = function countingIndex() {
    indexCalls++
    return realIndex.call(this)
  }
  svc.ledger.getByUsername = () => {
    perNameCalls++
    throw new Error('qqMap 不应逐个查台账')
  }
  svc.ledger.getByQq = () => {
    perNameCalls++
    throw new Error('qqMap 不应逐个查台账')
  }
  let out
  try {
    out = svc.qqMap(['Steve', 'STEVE', 'AlexRenamed', 'Nobody'])
  } finally {
    // 桩是挂在实例上的自有属性，必须删掉才能露出原型上的真方法
    // （否则后面的用例会一直撞到这个会抛错的桩）
    delete svc.ledger.qqIndex
    delete svc.ledger.getByUsername
    delete svc.ledger.getByQq
  }
  assert.deepEqual(out, { Steve: '10001', STEVE: '10001', AlexRenamed: '10002' })
  assert.equal(indexCalls, 1, '4 个名字也只应读一次台账')
  assert.equal(perNameCalls, 0, '循环里不得逐个查台账')
})

// ══════════════════════════════════════════════════════════════
// POST /api/qq-bind/lookup
// ══════════════════════════════════════════════════════════════

test('lookup 路由：正常批量查询，响应体形状严格', async () => {
  const res = await api('/api/qq-bind/lookup', { names: ['Steve', 'STEVE', 'Nobody', 'AlexRenamed'] })
  const body = await readJson(res)
  assert.equal(body.status, 200, body.text)
  // 严格形状：多一个字段都算破坏契约（前端半按字段直读）
  assert.deepEqual(body.data, {
    ok: true,
    qq: { Steve: '10001', STEVE: '10001', AlexRenamed: '10002' },
    missing: ['Nobody'],
    count: 3,
  })
})

test('lookup 路由：names 缺失或不是数组 → 400', async () => {
  for (const payload of [{}, { names: 'Steve' }, { names: null }, { names: { 0: 'Steve' } }]) {
    const res = await api('/api/qq-bind/lookup', payload)
    const body = await readJson(res)
    assert.equal(body.status, 400, JSON.stringify(payload) + ' → ' + body.text)
    assert.match(body.data.error, /缺少参数: names/)
  }
})

test('lookup 路由：超过上限 500 → 400（并说明上限）；恰好 500 仍可用', async () => {
  const over = await api('/api/qq-bind/lookup', { names: Array.from({ length: 501 }, (_, i) => `p${i}`) })
  const overBody = await readJson(over)
  assert.equal(overBody.status, 400, overBody.text)
  assert.match(overBody.data.error, /上限 500/)
  assert.match(overBody.data.error, /501/)

  const edge = await api('/api/qq-bind/lookup', {
    names: ['Steve', ...Array.from({ length: 499 }, (_, i) => `p${i}`)],
  })
  const edgeBody = await readJson(edge)
  assert.equal(edgeBody.status, 200, edgeBody.text)
  assert.equal(edgeBody.data.count, 1)
  assert.equal(edgeBody.data.missing.length, 499)
})

test('lookup 路由：与其它管理路由同权限（未通过鉴权 → 401，不进业务逻辑）', async () => {
  const denied = await fetch(`${base}/api/qq-bind/lookup`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ names: ['Steve'] }),
  })
  const body = await readJson(denied)
  assert.equal(body.status, 401, body.text)
  assert.equal(body.data.qq, undefined, '未鉴权不得返回任何台账数据')
})

test('名字与 Object.prototype 成员撞名时仍如实划分（toString / constructor / __proto__）', async () => {
  // 这三个名字是 TShock 允许的角色名风格；若用 qq[name] === undefined 判"未查到"，
  // 原型链上的同名成员会把它们从 missing 里挤掉（静默给错答案）
  const unbound = await readJson(
    await api('/api/qq-bind/lookup', { names: ['toString', 'constructor', 'hasOwnProperty'] }),
  )
  assert.equal(unbound.status, 200, unbound.text)
  assert.deepEqual(unbound.data, {
    ok: true,
    qq: {},
    missing: ['toString', 'constructor', 'hasOwnProperty'],
    count: 0,
  })

  // 真的绑定了 "__proto__" 这个角色名时必须能查到（直接对象赋值会让它凭空消失）
  await svc.ledger.bind({ qq: '10009', username: '__proto__', passwordHash: 'h9', source: 'test' })
  assert.equal(svc.qqOf('__proto__'), '10009')
  const bound = await readJson(await api('/api/qq-bind/lookup', { names: ['__proto__', 'toString'] }))
  assert.equal(bound.status, 200, bound.text)
  assert.equal(bound.data.count, 1)
  assert.equal(Object.prototype.hasOwnProperty.call(bound.data.qq, '__proto__'), true)
  assert.equal(bound.data.qq['__proto__'], '10009')
  assert.deepEqual(bound.data.missing, ['toString'])
})

// ══════════════════════════════════════════════════════════════
// POST /api/qq-bind/token/rotate
// ══════════════════════════════════════════════════════════════

test('token 轮换（生成模式）：返回新 token，且 config 响应里只有掩码（明文不泄漏）', async () => {
  const res = await api('/api/qq-bind/token/rotate', {})
  const body = await readJson(res)
  assert.equal(body.status, 200, body.text)

  const token = body.data.token
  assert.equal(body.data.ok, true)
  assert.equal(typeof token, 'string')
  assert.match(token, /^[A-Za-z0-9_-]{43}$/, '32 字节随机 → base64url 固定 43 字符（无 +/= 需转义）')
  assert.equal(body.data.tokenSet, true)
  assert.equal(body.data.tokenFromEnv, false, '测试未设置 TSWEB_QQBIND_TOKEN')
  assert.equal(body.data.effective, true)
  assert.equal(body.data.warning, undefined, '无环境变量覆盖时不应出现 warning')
  assert.deepEqual(Object.keys(body.data).sort(), [
    'effective',
    'ok',
    'token',
    'tokenFromEnv',
    'tokenRotatedAt',
    'tokenSet',
  ])
  assert.equal(Number.isNaN(Date.parse(body.data.tokenRotatedAt)), false, 'tokenRotatedAt 应是 ISO 时间')

  // 关键：明文只此一次 —— 配置接口（以及状态接口）永远只给掩码
  const cfg = await readJson(await fetch(`${base}/api/qq-bind/config`, { headers: { 'x-test-auth': 'ok' } }))
  assert.equal(cfg.status, 200)
  const masked = cfg.data.config.adapters['legacy-http'].token
  assert.equal(masked, `${token.slice(0, 3)}***${token.slice(-2)}（已设置，长度 43）`)
  assert.notEqual(masked, token)
  assert.equal(cfg.data.config.adapters['legacy-http'].tokenSet, true)
  assert.equal(cfg.text.includes(token), false, '明文 token 不得出现在 config 响应体任何位置')
  assert.equal(cfg.data.config.adapters['legacy-http'].tokenRotatedAt, body.data.tokenRotatedAt)

  const status = await readJson(await fetch(`${base}/api/qq-bind/status`, { headers: { 'x-test-auth': 'ok' } }))
  assert.equal(status.text.includes(token), false, '明文 token 不得出现在 status 响应体任何位置')

  // 走的是既有保存路径（saveConfig）：配置文件里应有明文 + 轮换时间
  const onDisk = JSON.parse(await readFile(path.join(dataDir, 'qq-bind', 'config.json'), 'utf8'))
  assert.equal(onDisk.adapters['legacy-http'].token, token, '新 token 必须真的落盘')
  assert.equal(onDisk.adapters['legacy-http'].tokenRotatedAt, body.data.tokenRotatedAt)
  // 且适配器读的是同一份内存配置 → 立即生效，不必重启
  assert.equal(svc.config.adapters['legacy-http'].token, token)

  // 两次生成应是不同的 token（随机性基本检查）
  const again = await readJson(await api('/api/qq-bind/token/rotate', {}))
  assert.notEqual(again.data.token, token)

  // 审计留痕但不记明文
  const rows = await svc.audit.tail(50)
  const rotateRows = rows.filter((r) => r.action === 'qqbind.token.rotate')
  assert.ok(rotateRows.length >= 2, '轮换应写审计')
  assert.equal(JSON.stringify(rotateRows).includes(again.data.token), false, '审计不得记录 token 明文')
})

test('token 轮换（手动设置）：用传入的 token；空串/非字符串 → 400', async () => {
  const manual = 'my-manual-bot-token-123'
  const res = await api('/api/qq-bind/token/rotate', { token: manual })
  const body = await readJson(res)
  assert.equal(body.status, 200, body.text)
  assert.equal(body.data.token, manual, '传了就用它，不做任何加工')
  assert.equal(body.data.tokenSet, true)
  assert.equal(body.data.effective, true)
  assert.equal(svc.config.adapters['legacy-http'].token, manual)

  const cfg = await readJson(await fetch(`${base}/api/qq-bind/config`, { headers: { 'x-test-auth': 'ok' } }))
  assert.equal(
    cfg.data.config.adapters['legacy-http'].token,
    `${manual.slice(0, 3)}***${manual.slice(-2)}（已设置，长度 ${manual.length}）`,
  )

  for (const bad of ['', '   ', 123, true, [], {}]) {
    const badRes = await api('/api/qq-bind/token/rotate', { token: bad })
    const badBody = await readJson(badRes)
    assert.equal(badBody.status, 400, `${JSON.stringify(bad)} → ${badBody.text}`)
    assert.match(badBody.data.error, /非空字符串/)
  }
  assert.equal(svc.config.adapters['legacy-http'].token, manual, '400 不得改动现有 token')
})

test('token 轮换：环境变量生效时 tokenFromEnv=true / effective=false + warning，重启后被环境变量盖回', async () => {
  const before = svc.config.adapters['legacy-http'].token
  process.env.TSWEB_QQBIND_TOKEN = ENV_TOKEN
  let body
  try {
    const res = await api('/api/qq-bind/token/rotate', { token: 'config-side-token-xyz' })
    body = await readJson(res)
  } finally {
    delete process.env.TSWEB_QQBIND_TOKEN
  }
  assert.equal(body.status, 200, body.text)
  assert.equal(body.data.token, 'config-side-token-xyz')
  assert.equal(body.data.tokenFromEnv, true, '进程环境里有 TSWEB_QQBIND_TOKEN → 必须如实标注')
  assert.equal(body.data.effective, false, '不得报告一个当前不生效的"成功"')
  assert.match(body.data.warning, /环境变量/, '要讲清"环境变量优先"')
  assert.match(body.data.warning, /重启/, '要讲清"需重启"')
  assert.notEqual(body.data.token, before)

  // 配置文件确实写进去了（不静默丢掉管理员的输入）
  const onDisk = JSON.parse(await readFile(path.join(dataDir, 'qq-bind', 'config.json'), 'utf8'))
  assert.equal(onDisk.adapters['legacy-http'].token, 'config-side-token-xyz')

  // 行为验证（不受注释影响的事实）：适配器每请求实时读内存配置（legacy-http.js:125、:131），
  // 所以新 token 在本进程内**能**通过 /api/bot 鉴权，而环境变量的旧值此时已不通过；
  // "环境变量优先"体现在**下一次加载**（见下面的 loadConfig 断言），不是体现在当前这一秒。
  // 用 /api/bot/bind（空参数）区分：通过鉴权 → 400 参数校验；未通过 → 401。
  const botCall = (token) =>
    fetch(`${base}/api/bot/bind?token=${encodeURIComponent(token)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    })
  const withNew = await botCall('config-side-token-xyz')
  assert.equal(withNew.status, 400, '本进程内新 token 应可用（已读到内存配置）')
  const withEnv = await botCall(ENV_TOKEN)
  assert.equal(withEnv.status, 401, '内存配置已被覆盖，环境变量里的旧值此时不再被接受')

  // 而"重启"（重新 loadConfig + applyEnv）时环境变量仍然赢 → 这正是 warning 说的事
  process.env.TSWEB_QQBIND_TOKEN = ENV_TOKEN
  try {
    const { config } = await loadConfig(path.join(dataDir, 'qq-bind', 'config.json'))
    assert.equal(config.adapters['legacy-http'].token, ENV_TOKEN, '带环境变量加载时，配置里的新 token 被覆盖')
  } finally {
    delete process.env.TSWEB_QQBIND_TOKEN
  }
})
