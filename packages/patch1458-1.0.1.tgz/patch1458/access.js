// Module permissions authorize both UI features and their backend routes.
export default {
  "owner": "patch1458",
  "version": 2,
  "modules": [
    {
      "id": "patch1458.compatibility",
      "permission": "patch1458.module.compatibility",
      "title": "兼容补丁管理",
      "roles": [
        "superadmin",
        "admin",
        "subadmin"
      ],
      "scope": "server",
      "requires": [
        "patch1458.get.patch1458.status"
      ]
    }
  ],
  "actions": [
    {
      "id": "patch1458.get.patch1458.status",
      "method": "GET",
      "path": "/api/patch1458/status",
      "scope": "server",
      "module": "patch1458.compatibility"
    }
  ],
  "features": []
}
