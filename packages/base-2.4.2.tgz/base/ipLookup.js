/**
 * 玩家详情页「已知 IP」的归属地查询（宿主侧代理）
 *
 * 为什么必须由宿主代理、不能让浏览器直连：
 *   1. 浏览器直连会被 CORS 拦下（对方不返回 Access-Control-Allow-Origin），
 *      旧版就是因此在后端加了一层代理（旧 `backend/server.js:241-258`，提交 f509882）。
 *   2. 该接口返回 **GBK** 编码，浏览器 `response.json()` 会按 UTF-8 解，中文地名必然乱码。
 *      旧版为此引入了 iconv-lite；本仓库宿主依赖里没有它，而 Node 官方构建自带完整 ICU，
 *      `new TextDecoder('gbk')` 直接可用（本机 Node v24.20.0 实测解码 `B1B1 BE A9` → "北京"），
 *      所以这里不新增任何依赖。
 *
 * 返回形状**沿用旧版后端**（`ip` + `pro`/`city`/`addr`，失败时给 `err` 字段），
 * 因为旧前端就是按这个形状写的（`UserDetailView.vue:386-416`）：有 `err` 时不显示位置。
 *
 * 边界：内网/本机 IP 的判定**只在客户端做**（`client/io-logic.js` 的 `isLocalIp`，现役调用方是
 * Vue 侧的 ui/PlayerTools.vue；老原生客户端的 players.js 已移除），命中即显示"本地 IP"且根本不发请求，
 * 这一点与旧版一致（旧版也是在 `UserDetailView.vue:440-444` 前端判的）。
 * 本模块**刻意不再放一份**同规则实现：宿主只做"来什么查什么"的代理，重复一份只会两边漂移。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */

/** 归属地接口（与旧版同一个服务） */
export const IP_LOOKUP_URL = 'https://whois.pconline.com.cn/ipJson.jsp'

/**
 * 查询超时。旧版没有超时（`fetch` 默认行为），对方不响应时那张 IP 卡片会一直转圈；
 * 5s 是本机默认值的保守选择，超时后前端会如实显示"查询失败"。
 */
export const DEFAULT_TIMEOUT_MS = 5000

/**
 * 取"裸 IP"：去掉 IPv6 方括号、端口、`::ffff:` 前缀。
 *
 * TShock 入库的 IP 本身是裸地址（`TShockAPI/TSPlayer.cs:1119-1129` 走 `Utils.GetRealIP`，
 * `TShockAPI/TShock.cs:557/569` 写入 KnownIps），所以正常情况这里是空操作；
 * 之所以仍然归一化，是因为**查询串里带上端口对方一定查不到**，
 * 而面板显示的仍是原始值（显示与查询各用各的，不改用户看到的内容）。
 */
export function bareIp(ip) {
  let s = String(ip == null ? '' : ip).trim()
  if (s.startsWith('[')) {
    const end = s.indexOf(']')
    if (end > 0) s = s.slice(1, end)
  } else if (/^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(s)) {
    s = s.slice(0, s.lastIndexOf(':'))
  }
  if (s.toLowerCase().startsWith('::ffff:')) s = s.slice(7)
  return s
}

/** 失败时统一返回的骨架（与旧版后端的 catch 分支同形） */
function failure(ip, err) {
  return { ip: ip == null ? '' : String(ip), pro: '', city: '', addr: '', err: err || '归属地查询失败' }
}

/**
 * 查询单个 IP 的归属地。**永不抛错**（失败把原因放进 `err`），因为调用方是详情页的一段渲染，
 * 查不到位置不该让整页渲染中断。
 *
 * @param {string} ip 待查 IP（可带端口，内部会归一化）
 * @param {{ fetchImpl?: Function, timeoutMs?: number }} [opts] 测试用注入点
 */
export async function lookupIp(ip, opts = {}) {
  const fetchImpl = opts.fetchImpl || fetch
  const timeoutMs = opts.timeoutMs || DEFAULT_TIMEOUT_MS
  const raw = String(ip == null ? '' : ip).trim()
  // 防御性分支：HTTP 链路上不可达（路由 index.js 已先对空 ip 回 400）。
  // 保留是为了让本函数单独被调用（测试、将来的其它插件）时也有确定行为，而不是去第三方查一个空 IP。
  if (!raw) return failure('', '缺少 ip 参数')

  const url = `${IP_LOOKUP_URL}?ip=${encodeURIComponent(bareIp(raw))}&json=true`
  const ac = new AbortController()
  const timer = setTimeout(() => ac.abort(), timeoutMs)
  try {
    const res = await fetchImpl(url, { signal: ac.signal })
    if (!res || (typeof res.ok === 'boolean' && !res.ok)) {
      return failure(raw, `归属地服务返回 ${res && res.status ? res.status : '异常'}`)
    }
    // 必须按 buffer 读，再按 GBK 解；直接 res.json() 会因 UTF-8 误解码而出乱码
    const buf = Buffer.from(await res.arrayBuffer())
    const text = new TextDecoder('gbk').decode(buf)
    let data
    try {
      data = JSON.parse(text)
    } catch {
      return failure(raw, '归属地服务返回内容无法解析')
    }
    return {
      ip: raw,
      pro: data.pro || '',
      city: data.city || '',
      addr: data.addr || '',
      err: data.err ? String(data.err) : '',
    }
  } catch (err) {
    const msg = err && err.name === 'AbortError'
      ? `归属地查询超时（${timeoutMs}ms）`
      : (err && err.message) || '归属地查询失败'
    return failure(raw, msg)
  } finally {
    clearTimeout(timer)
  }
}
