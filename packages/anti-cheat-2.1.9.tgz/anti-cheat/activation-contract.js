// 反作弊插件后端与前端共用的一份约定：状态码、错误码与给用户看的那句话。
//
// 为什么单独放一个文件：后端（index.js，跑在面板 Node 进程）与前端（ui/，打包进浏览器）
// 都要用同一句文案与同一个 424 状态。两处各写一份的话，只要改了其中一处，前端就会认不出
// 后端返回的失败（review 里实际发生过），所以这里做单一来源，两边都 import 它。
export const ACTIVATION_STATUS = 424
export const ACTIVATION_CODE = 'anti-cheat.not-activated'
export const ACTIVATION_MESSAGE =
  '反作弊插件在当前游戏服上还没有可用接口：请先在 TShock 窗口里选择世界并启动（插件要等首次游戏线程才激活）；若世界已启动仍然如此，说明服上的反作弊 DLL 没加载或版本过旧，需要重新下发最新版。'
