export const httpError = (status, message) => Object.assign(new Error(message), { status });
export function validateConfig(config) {
  if (!config || typeof config !== 'object' || Array.isArray(config)) throw httpError(400, '缺少 Boss 配置');
  if (!['disabled', 'playerlimit', 'killrequired'].includes(config.bossLimitMode)) throw httpError(400, '请选择有效的召唤模式');
  for (const [key, min, max, label] of [
    ['bossLimitMinPlayers', 1, 999, '最低在线人数'], ['ghostRespawnSeconds', 1, 3600, '幽灵复活倒计时'],
  ]) if (!Number.isInteger(config[key]) || config[key] < min || config[key] > max) throw httpError(400, `${label}应为 ${min}～${max} 的整数`);
  for (const key of ['quitLimitEnabled', 'lateCompEnabled', 'timeLockEnabled', 'blockLockedBossSpawn'])
    if (typeof config[key] !== 'boolean') throw httpError(400, '开关值无效');
  if (typeof config.serverStartTime !== 'string' || (config.serverStartTime && !/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2})?$/.test(config.serverStartTime)))
    throw httpError(400, '开服时间格式无效');
  if (!Array.isArray(config.summonRules) || config.summonRules.length > 64 || config.summonRules.some(r => !r || typeof r.name !== 'string' || !['allow', 'deny', 'auto'].includes(r.policy)))
    throw httpError(400, 'Boss 召唤许可无效');
  if (new Set(config.summonRules.map(r => r.name)).size !== config.summonRules.length) throw httpError(400, 'Boss 召唤许可不能重复');
  if (!Array.isArray(config.timeSchedule) || config.timeSchedule.length > 18 || config.timeSchedule.some(s => !s || typeof s.name !== 'string' || !Number.isInteger(s.day) || s.day < 1 || s.day > 3650 || !/^([01]\d|2[0-3]):[0-5]\d$/.test(s.time)))
    throw httpError(400, '请检查解锁计划的 Boss、天数和时间');
  if (new Set(config.timeSchedule.map(s => s.name)).size !== config.timeSchedule.length) throw httpError(400, '同一 Boss 只能有一条解锁计划');
  return config;
}

export class BossLimitService {
  constructor(ctx) { this.ctx = ctx; this.disposed = false; }
  async call(id, suffix, params = {}, signal) {
    if (this.disposed) throw httpError(503, 'Boss 限制正在卸载');
    signal?.throwIfAborted();
    if (typeof id !== 'string' || !id) throw httpError(400, '请先选择服务器');
    const server = this.ctx.servers.getRaw(id);
    if (!server) throw httpError(404, '服务器不存在');
    let response;
    try { response = await this.ctx.tshock.fetchFor(server, `/data/boss-limit/${suffix}`, params, { signal, timeoutMs: 12000 }); }
    catch (err) { throw httpError(502, '连接游戏服失败：' + err.message); }
    signal?.throwIfAborted();
    if (this.disposed) throw httpError(503, 'Boss 限制正在卸载');
    const data = response.data;
    const status = Number(data?.status || response.status);
    if (status === 404) throw httpError(501, '游戏服尚未启用 BossLimit.dll，请检查插件同步状态');
    if (status === 401 || status === 403) throw httpError(502, '游戏服令牌需要 tsweb.boss-limit.manage 权限');
    if (!response.ok || status >= 400 || !data || data.error)
      throw httpError([400, 409, 503].includes(status) ? status : 502, data?.error || 'Boss 限制未响应');
    return data;
  }
  save(id, config, signal) {
    validateConfig(config);
    return this.call(id, 'config/set', { config: JSON.stringify(config) }, signal);
  }
  release(id, player, signal) {
    if (typeof player !== 'string' || !player.trim() || player.length > 64) throw httpError(400, '请选择需要解除幽灵状态的玩家');
    return this.call(id, 'release', { player }, signal);
  }
}
