const revision = new URL(import.meta.url).search;
const { default: access } = await import(`./access.js${revision}`);
const { BossLimitService } = await import(`./service.js${revision}`);
export const name = 'boss-limit';
export const inject = ['webServer', 'auth', 'servers', 'tshock'];

export function apply(ctx) {
  try {
    const service = new BossLimitService(ctx);
    const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx);
    const controllers = new Set();
    ctx.on('dispose', () => {
      service.disposed = true;
      for (const controller of controllers) controller.abort();
    });
    const route = fn => async (req, res) => {
      const controller = new AbortController();
      const close = () => { if (!res.writableFinished) controller.abort(); };
      res.on('close', close);
      controllers.add(controller);
      try {
        const result = await fn(req, controller.signal);
        if (!res.destroyed) res.json(result);
      } catch (err) {
        if (!res.headersSent && !res.destroyed)
          res.status(err.status || 502).json({ error: err.message });
      } finally {
        controllers.delete(controller);
        res.off('close', close);
      }
    };
    app.get('/api/boss-limit/config', route((req, signal) => service.call(req.headers['x-server-id'], 'config', {}, signal)));
    app.get('/api/boss-limit/status', route((req, signal) => service.call(req.headers['x-server-id'], 'status', {}, signal)));
    app.post('/api/boss-limit/config', route((req, signal) => service.save(req.headers['x-server-id'], req.body?.config, signal)));
    app.post('/api/boss-limit/release', route((req, signal) => service.release(req.headers['x-server-id'], req.body?.player, signal)));
  } catch (err) {
    console.error('[boss-limit] 初始化失败：' + err.message);
    throw err;
  }
}
