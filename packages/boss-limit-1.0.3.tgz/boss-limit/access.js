const actions = [
  ['read', 'GET', 'config'],
  ['save', 'POST', 'config'],
  ['status', 'GET', 'status'],
  ['release', 'POST', 'release'],
].map(([id, method, suffix]) => ({
  id: `boss-limit.${id}`, method, path: `/api/boss-limit/${suffix}`,
  module: 'boss-limit.manage', scope: 'server',
}));
export default {
  owner: 'boss-limit', version: 2,
  modules: [{
    id: 'boss-limit.manage', permission: 'boss-limit.manage', title: 'Boss 限制',
    roles: ['superadmin', 'admin', 'subadmin'], scope: 'server',
    requires: actions.map(a => a.id),
  }],
  actions,
  features: [{ id: 'boss-limit:manage', module: 'boss-limit.manage', requires: actions.map(a => a.id) }],
};
