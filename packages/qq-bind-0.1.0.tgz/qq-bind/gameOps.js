/**
 * 游戏服调用层（宿主 → TShock）
 *
 * 端点契约见 docs/QQ绑定基础件设计.md §6.3：账号本身的增删改复用既有通道
 * （TShock 原生 /v2/users/create、base 插件的 /data/base/players/*），本件只新增
 * 快照下发与查询两个端点。
 *
 * 错误语义照抄 online-stats 的既有约定（plugins/online-stats/index.js:539-570），
 * 保证"服务器半缺失"在各插件里表现一致：
 *   404            → 501 + serverHalfMissing=true（目标服没装 QqBind.dll）
 *   401/403        → 502（token 缺 data.rest.invsee 权限）
 *   网络/超时      → 502
 */
import { httpError } from './ledger.js'

/** 游戏服半的端点前缀 */
export const SERVER_HALF_PREFIX = '/data/qq'

/** 游戏服半的 DLL 名（报错文案用） */
export const DLL_NAME = 'QqBind.dll'

/**
 * 快照每块记录数。取 20 的理由：单条记录（用户名 + QQ + 可选 60 字符哈希）
 * JSON 约 100-160 字节，URL 编码后约 2 倍，20 条约 4-6KB，远低于 http.sys 默认 16KB URL 上限；
 * 典型台账（几十条）仍然只推 1 块，不增加请求数。
 */
export const CHUNK_RECORDS = 20

export function createGameOps({ ctx }) {
  const log = (...args) => {
    try {
      console.log('[qq-bind]', ...args)
    } catch {
      /* 忽略 */
    }
  }

  /** 启用中的服务器（拉原始记录，含 token，代理要用） */
  async function enabledServers() {
    const list = await ctx.servers.list()
    const out = []
    for (const s of list) {
      if (s.enabled === false) continue
      const raw = ctx.servers.getRaw(s.id)
      if (raw) out.push(raw)
    }
    return out
  }

  function rawOf(serverId) {
    return ctx.servers.getRaw(String(serverId)) || null
  }

  /**
   * 统一把 fetchFor/postFor 的结果翻成数据或抛错（dll 名用于把 404 说清楚）。
   *
   * allow404：本件端点的 404 有两种完全不同的含义，必须区分，否则会把业务结果
   * 误报成环境问题：
   *   - 路由不存在（没装 DLL）→ 501 serverHalfMissing（框架 404，body 无 code 字段）
   *   - 业务"本地无该账号"（/data/qq/uuid）→ 由本件自己的端点用 code 字段标记，
   *     调用方按业务失败处理（见 syncUuidToServer）
   */
  function unwrap(server, result, label, dll, { allow404 = false } = {}) {
    if (result.ok) return result.data || {}
    if (result.status === 404) {
      const body = result.data || {}
      if (allow404 && body.code) return { ...body, __httpStatus: 404 }
      throw httpError(501, `游戏服端未安装 ${dll}（${label} 返回 404）：请在「插件下发」页对该服务器启用`, {
        serverHalfMissing: true,
        serverId: server.id,
        missingDll: dll,
      })
    }
    if (result.status === 401 || result.status === 403) {
      throw httpError(502, `游戏服 token 权限不足（HTTP ${result.status}）：需要 data.rest.invsee 权限`, {
        serverId: server.id,
      })
    }
    const detail = result.data && result.data.error ? `：${result.data.error}` : ''
    throw httpError(502, `游戏服返回异常（HTTP ${result.status}）${detail}`, { serverId: server.id })
  }

  /**
   * 任意游戏服路径 GET（base 插件与 TShock 原生端点用）。
   * 本件自有端点走 callGet（自动加 /data/qq 前缀）。
   */
  async function callRaw(server, pathname, params = {}, { dll = DLL_NAME, allow404 = false } = {}) {
    let result
    try {
      result = await ctx.tshock.fetchFor(server, pathname, params)
    } catch (err) {
      throw httpError(502, `连接游戏服失败：${err.message}`, { serverId: server.id })
    }
    return unwrap(server, result, `GET ${pathname}`, dll, { allow404 })
  }

  function callGet(server, suffix, params = {}, opts = {}) {
    return callRaw(server, `${SERVER_HALF_PREFIX}${suffix}`, params, opts)
  }

  return {
    enabledServers,
    rawOf,

    /** 单服查账号（含密码哈希与在线 UUID） */
    async findAccount(server, name) {
      const data = await callGet(server, '/find-account', { name })
      return {
        found: data.found === true,
        passwordHash: String(data.passwordHash || ''),
        uuid: String(data.uuid || ''),
        group: String(data.group || ''),
        online: data.online === true,
        onlineUuid: String(data.onlineUuid || ''),
      }
    },

    /** 单服取游戏数据（我的信息用） */
    async playerData(server, name) {
      const data = await callGet(server, '/player-data', { name })
      return {
        found: data.found === true,
        player: String(data.player || name),
        group: String(data.group || ''),
        registered: String(data.registered || ''),
        deaths: Number(data.deaths || 0),
        fishing_quests: Number(data.fishing_quests || 0),
      }
    },

    /**
     * 下发快照（整份替换，幂等）。
     *
     * 传输契约：**GET + query 参数，按块下发**。为什么不用 body：
     *   - TShock 的 `SecureRestCommand` 语义是"带 token 的 GET"（实证见设计 §6.3：
     *     旧版后端连 /v2/users/create 都用 GET 调，tshockService.js:986-996）；
     *   - 插件侧只读 `args.Parameters`（旧版全部 REST 端点皆如此），
     *     "form body 是否被解析进 Parameters" 在本项目**没有任何先例可证**，
     *     赌它会解析等于把失败做成静默；
     *   - 把复杂 JSON 编码进 query 是本项目已验证的做法（tshockService.js:1178）。
     * 代价是 URL 长度，故按块切分（每块 CHUNK_RECORDS 条），块内载荷上限远低于 16KB。
     *
     * 游戏服半**收齐同一 version 的全部块才整体替换**（QqSnapshot.ApplyChunk），
     * 所以丢块不会产生半份快照；下一次变更/重连/对账会重新推完整份。
     */
    async pushSnapshot(server, payload) {
      const records = Array.isArray(payload && payload.records) ? payload.records : []
      const total = records.length
      const chunks = Math.max(1, Math.ceil(total / CHUNK_RECORDS))
      let last = null
      for (let i = 0; i < chunks; i += 1) {
        const slice = records.slice(i * CHUNK_RECORDS, (i + 1) * CHUNK_RECORDS)
        last = await callGet(server, '/snapshot', {
          version: payload && payload.version != null ? payload.version : 0,
          chunk: i,
          chunks,
          total,
          syncAccounts: payload && payload.syncAccounts ? 1 : 0,
          syncUuid: payload && payload.syncUuid ? 1 : 0,
          promotion: payload && payload.promotion ? JSON.stringify(payload.promotion) : '',
          payload: JSON.stringify(slice),
        })
      }
      return {
        ...(last || {}),
        chunks,
        total,
        // 只有最后一块返回 applied=true 才代表整份快照已生效
        applied: !!(last && last.applied),
      }
    },

    /** 快照状态（排障：version/count/updatedAt） */
    async snapshotStatus(server) {
      return callGet(server, '/status', {})
    },

    /**
     * 单服 UUID 落盘（免密）+ 可选踢重复登录。
     *
     * 用本件自己的 `GET /data/qq/uuid`，**不用** base 的通用 `/data/base/players/uuid`：
     * 两者语义不等价，旧版 AccountSync 的两条规则只有本端点能满足
     * （移植自 TsWeb/plugin/AccountSync.cs:203-273）：
     *   1. 按**账号名**匹配在线角色（通用端点按角色名，而角色名可与账号名不同）；
     *   2. 只踢**已登录**的同名角色（未登录不构成"多服登录重复"）。
     * 另：本端点返回 400/404/409/500 可区分状态码（旧版为修"200 却未落盘"特意加的），
     * 宿主据此能精确报出失败环节。
     */
    async syncUuidToServer(server, { name, uuid, kick = false }) {
      const data = await callGet(server, '/uuid', { username: name, uuid, kick: kick ? 1 : 0 }, { allow404: true })
      if (data.__httpStatus === 404) {
        // 业务失败（该服没这个账号），不是"没装 DLL"——两者此前共用一个 404，
        // 若混淆会报"请安装 QqBind.dll"而实际 DLL 好着（误导排查方向）
        throw httpError(409, `服务器「${server.name}」本地没有账号「${name}」：该服尚未建号，无法落盘 UUID`, {
          serverId: server.id,
          noLocalAccount: true,
        })
      }
      return { ...data, kicked: !!kick }
    },

    /** 建号（沿用旧版通道：TShock 原生 REST） */
    async createUser(server, username, password) {
      const result = await ctx.tshock.fetchFor(server, '/v2/users/create', {
        user: username,
        password,
      })
      if (result.ok) return true
      const detail = result.data && result.data.error ? `：${result.data.error}` : ''
      throw httpError(502, `服务器「${server.name}」建号失败（HTTP ${result.status}）${detail}`, {
        serverId: server.id,
      })
    },

    /**
     * 多服定位角色（旧版语义：唯一命中才允许绑定；同名多服 → 冲突让用户指定服）。
     * @returns {{ server: object, info: object }}
     * @throws 404 全部服务器都没有该角色；409 多服同名（带服务器列表）
     */
    async locateAccount(name, { serverId = '' } = {}) {
      const all = await enabledServers()
      const targets = serverId ? all.filter((s) => String(s.id) === String(serverId)) : all
      if (targets.length === 0) {
        throw httpError(404, serverId ? '指定的服务器不存在或未启用' : '没有可查询的服务器')
      }

      const hits = []
      const errors = []
      /** 真正答复了的服务器数（答复"没有该角色"也算答复） */
      let answered = 0
      for (const server of targets) {
        try {
          const info = await this.findAccount(server, name)
          answered++
          if (info.found) hits.push({ server, info })
        } catch (err) {
          errors.push({ serverId: server.id, name: server.name, error: err.message, status: err.status })
        }
      }

      if (hits.length === 0) {
        // 一台都没答上来、且全是"没装 DLL"：如实报 501，不能把"查不了"说成"角色不存在"
        if (answered === 0 && errors.length > 0 && errors.every((e) => e.status === 501)) {
          throw httpError(501, `所有服务器都未安装 ${DLL_NAME}，无法查询角色`, {
            serverHalfMissing: true,
            errors,
          })
        }
        // 有服务器明确答复"没有该角色" → 404；同时如实标注哪些服没查到（结论可能不完整）
        const note = errors.length > 0 ? `（另有 ${errors.length} 台服务器未能查询）` : ''
        throw httpError(404, `该角色名在所有可查询的服务器中都不存在${note}`, { errors })
      }

      if (hits.length > 1) {
        throw httpError(409, '该角色名在多个服务器存在，请指定服务器后重试', {
          conflict: true,
          servers: hits.map((h) => ({ id: h.server.id, name: h.server.name })),
          candidates: hits.map((h) => ({ id: h.server.id, name: h.server.name })),
        })
      }

      const hit = hits[0]
      if (!hit.info.passwordHash) {
        throw httpError(500, `服务器「${hit.server.name}」未返回密码哈希`, { serverId: hit.server.id })
      }
      return { server: hit.server, info: hit.info }
    },

    log,
  }
}
