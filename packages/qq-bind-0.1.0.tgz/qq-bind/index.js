/**
 * QQ 绑定基础件（qq-bind）—— 宿主侧半
 *
 * 设计：docs/QQ绑定基础件设计.md ｜ 对接：docs/QQ绑定功能对接文档.md
 *
 * 三条硬约束（违反即"看起来成功、实际没生效"）：
 *   1. 台账唯一权威在本件（<dataDir>/qq-bind/bindings.json）；游戏服只持有只读快照
 *   2. 核心不认识任何机器人框架：接入方式是适配器（内置 legacy-http 让旧 Koishi 零改动），
 *      能力注册一次、所有适配器可见（adapters/registry.js）
 *   3. 台账**任何**变更（含改名）都必须下发快照——旧版改名漏推导致"改名后不晋升、不豁免"
 *      （TsWeb/backend/services/userAdminService.js:44-90 对比 :122-131）
 *
 * 职责划分：
 *   - 本文件：服务（ctx.qqBind）+ 绑定域能力 + 管理 REST + 快照下发
 *   - ledger.js    ：台账（原子落盘、1:1、大小写不敏感 + aliases、导入幂等）
 *   - gameOps.js   ：游戏服调用（查询/建号/改密/快照）
 *   - adapters/    ：接入层（适配器注册表 + 能力注册表 + 内置 legacy-http）
 *
 * 依赖全部为既有服务：webServer / auth / servers / tshock / paths
 * 约定：禁止 emoji；状态数据走 ctx.paths.dataOf('qq-bind')（不在插件目录内）
 */
import { Service } from '@deepseek-ai/cordis'
import { mkdir, readFile } from 'node:fs/promises'
import { randomBytes } from 'node:crypto'
import path from 'node:path'

import { Ledger, httpError, normQq, isValidQq } from './ledger.js'
import {
  loadConfig,
  saveConfig,
  normalizeConfig,
  setByPath,
  redactConfig,
  serverFlags,
} from './config.js'
import { AuditLog } from './audit.js'
import { CapabilityRegistry, AdapterRegistry } from './adapters/registry.js'
import { createLegacyHttpAdapter } from './adapters/legacy-http.js'
import { createGameOps } from './gameOps.js'

export const name = 'qq-bind'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths']

/** 自助注册时的随机密码长度（用户随后用「改密码」设置自己的密码；免密登录不依赖它） */
const RANDOM_PASSWORD_BYTES = 9

/** 批量操作上限（旧版语义：100 人，userAdminService.js:191） */
const BATCH_LIMIT = 100

/** 台账变更 → 事件名 */
const EVENT_OF_ACTION = {
  bound: 'qqbind/bound',
  unbound: 'qqbind/unbound',
  rebound: 'qqbind/rebound',
  transferred: 'qqbind/transferred',
  renamed: 'qqbind/renamed',
  'password-changed': 'qqbind/password-changed',
  registered: 'qqbind/registered',
  removed: 'qqbind/removed',
  imported: 'qqbind/imported',
}

class QqBindService extends Service {
  constructor(ctx) {
    super(ctx, 'qqBind')
    /** @type {Ledger} */ this.ledger = null
    /** @type {AuditLog} */ this.audit = null
    /** @type {object} */ this.config = null
    /** @type {object} */ this.gameOps = null
    /** @type {string} */ this.configFile = ''
    this.capabilities = new CapabilityRegistry()
    this.adapters = new AdapterRegistry()
    /** 快照版本号：每次下发自增，供排障与游戏侧判断新旧 */
    this.snapshotVersion = 0
    /** serverId -> { ok, at, version, count, error, serverHalfMissing } */
    this.pushStatus = new Map()
    /** 快照推送串行链（单一推送者：由 onLedgerChange 排队，业务方法只负责等待结果） */
    this._pushQueue = null
    this._pushResult = null
    /** 台账变更序号与"已排队推送覆盖到的序号"，用于判断本次变更是否已排队 */
    this._mutationSeq = 0
    this._pushSeq = -1
    /** 兜底对账定时器 */
    this._reconcile = null
  }

  // ══════════════════════════════════════════════════════════
  // 查询（其他插件用软依赖 ctx.qqBind?.xxx 调用）
  // ══════════════════════════════════════════════════════════

  getByQq(qq) {
    return this.ledger.getByQq(qq)
  }

  getByUsername(username) {
    return this.ledger.getByUsername(username)
  }

  /** 按 QQ 或角色名解析（大小写不敏感） */
  resolve(identifier) {
    return this.ledger.get(identifier)
  }

  isBound(identifier) {
    return this.ledger.isBound(identifier)
  }

  /** 绑定列表（可选叠加多服时长；时长缺失时如实标注，不假装 0） */
  async list({ keyword = '', page = 1, pageSize = 50 } = {}) {
    const base = this.ledger.list({ keyword, page, pageSize })
    const playtime = await this._playtimeAll()
    const rows = base.rows.map((row) => ({
      ...row,
      playtime: playtime && playtime.stats ? playtime.stats[row.username] ?? 0 : null,
      playtimeUnavailable: !(playtime && playtime.stats),
    }))
    // 与旧版一致：按时长降序（旧版由后端排序，botController.js:608）
    if (playtime && playtime.stats) {
      rows.sort((a, b) => (b.playtime || 0) - (a.playtime || 0))
    }
    return { ...base, rows, playtimeSource: playtime && playtime.stats ? 'online-stats' : 'unavailable' }
  }

  /** 统计（供其它插件/前端展示，替代旧版前端全量拉取后自算） */
  stats() {
    return {
      bound: this.ledger.size,
      updatedAt: this.ledger.updatedAt,
      snapshotVersion: this.snapshotVersion,
    }
  }

  /**
   * 身份补全（接入层调用；领域逻辑留在核心，适配器不碰台账）。
   * 依据请求参数里的 qq / player / username 找出台账记录，回填 principal。
   */
  async identify(principal, params = {}) {
    const out = { ...(principal || {}) }
    if (!this.ledger) return out // 初始化尚未完成：不猜测身份
    const qq = params.qq != null && String(params.qq).trim() !== '' ? normQq(params.qq) : ''
    const name = String(params.player || params.username || '').trim()
    if (qq) out.qq = qq
    let rec = null
    if (qq) rec = this.ledger.getByQq(qq)
    if (!rec && name) rec = this.ledger.getByUsername(name)
    if (rec) {
      out.boundUsername = rec.username
      out.qq = rec.qq
    }
    return out
  }

  // ══════════════════════════════════════════════════════════
  // 变更（全部写台账 + 广播事件 + 下发快照）
  // ══════════════════════════════════════════════════════════

  /**
   * 绑定已有角色（机器人「绑定」/ 管理端「手动绑定」）。
   * @returns {Promise<object>} 含 server/uuidSync/snapshot，供调用方回显
   */
  async bind({ qq, player, serverId = '', source = 'bot' }) {
    const q = normQq(qq)
    const target = String(player || '').trim()
    if (!q) throw httpError(400, '缺少参数: qq')
    if (!target) throw httpError(400, '缺少参数: player')
    if (!isValidQq(q)) throw httpError(400, 'QQ 号格式不正确')
    this._assertFree(q, target)

    const { server, info } = await this.gameOps.locateAccount(target, { serverId })
    if (this.config.binding.requireOnlineForBind && !info.online) {
      throw httpError(409, '该角色当前不在线（当前配置要求绑定前角色在线）')
    }

    const rec = await this.ledger.bind({
      qq: q,
      username: target,
      passwordHash: info.passwordHash,
      source,
    })

    const snapshot = await this._ensurePushed()
    let uuidSync = null
    if (info.online && info.onlineUuid) {
      // 旧版语义：角色在线时绑定即全服免密（botController.js:742-749）
      uuidSync = await this.syncUuid(target, info.onlineUuid, { excludeServerId: server.id })
    }

    await this.audit.append('qqbind.bind', {
      username: rec.username,
      qq: q,
      server: server.name,
      source,
      actor: source,
    })
    return {
      player: rec.username,
      username: rec.username,
      qq: q,
      server: server.name,
      servers: [server.name],
      uuidSync,
      snapshot,
    }
  }

  /** 自助注册：逐服建号（TShock 原生 REST）→ 取回哈希 → 写台账 → 下发 */
  async registerPlayer({ qq, player, source = 'bot' }) {
    if (!this.config.binding.allowSelfRegister) throw httpError(403, '当前未开放自助注册')
    const q = normQq(qq)
    const target = String(player || '').trim()
    if (!q) throw httpError(400, '缺少参数: qq')
    if (!target) throw httpError(400, '缺少参数: player')
    if (!isValidQq(q)) throw httpError(400, 'QQ 号格式不正确')
    this._assertFree(q, target)

    const servers = await this.gameOps.enabledServers()
    if (servers.length === 0) throw httpError(400, '尚未配置任何启用服务器')

    // 已存在同名账号 → 引导用「绑定」（旧版语义）
    for (const server of servers) {
      const info = await this.gameOps.findAccount(server, target)
      if (info.found) {
        throw httpError(409, `角色「${target}」在服务器「${server.name}」已存在，请使用「绑定」`, {
          serverId: server.id,
        })
      }
    }

    const password = randomPassword()
    const created = []
    for (const server of servers) {
      await this.gameOps.createUser(server, target, password)
      created.push(server.name)
    }

    // 取回 TShock 自己算的哈希（免密登录与快照同步都用它）
    let passwordHash = ''
    let hashFrom = ''
    for (const server of servers) {
      const info = await this.gameOps.findAccount(server, target)
      if (info.found && info.passwordHash) {
        passwordHash = info.passwordHash
        hashFrom = server.name
        break
      }
    }
    if (!passwordHash) throw httpError(502, '建号成功但未能从服务器取回密码哈希，请稍后重试或联系管理员')

    await this.ledger.bind({ qq: q, username: target, passwordHash, source })
    const snapshot = await this._ensurePushed()
    await this.audit.append('qqbind.register', {
      username: target,
      qq: q,
      servers: created,
      hashFrom,
      source,
    })
    return {
      player: target,
      username: target,
      qq: q,
      servers: created,
      created: true,
      snapshot,
    }
  }

  /** 改密：写台账哈希（免密依据）+ 下发快照；哈希由 TShock 生成后回读，保证与游戏内一致 */
  async changePassword({ username, qq, password, source = 'bot' }) {
    const rec = username ? this.ledger.getByUsername(username) : this.ledger.getByQq(qq)
    if (!rec) throw httpError(404, '该角色未绑定 QQ')
    const pass = String(password ?? '')
    if (!pass) throw httpError(400, '缺少参数: password')
    if (pass.length < 6) throw httpError(400, '密码长度至少 6 位')

    const servers = await this.gameOps.enabledServers()
    if (servers.length === 0) throw httpError(400, '尚未配置任何启用服务器')

    // 让游戏侧按 TShock 自身算法落盘（复用 base 插件既有端点），再回读哈希写台账：
    // 这样台账里的哈希与账户里的 hash 完全一致，避免快照同步时反复重写密码
    const applied = []
    const failed = []
    let passwordHash = ''
    for (const server of servers) {
      try {
        const result = await this.ctx.tshock.fetchFor(server, '/data/base/players/password', {
          player: rec.username,
          password: pass,
        })
        if (!result.ok) {
          failed.push({
            server: server.name,
            error:
              result.status === 404
                ? '该服务器未安装 base 服务端半（Base.dll），无法改密'
                : `HTTP ${result.status}`,
          })
          continue
        }
        applied.push(server.name)
        if (!passwordHash) {
          const info = await this.gameOps.findAccount(server, rec.username)
          if (info.passwordHash) passwordHash = info.passwordHash
        }
      } catch (err) {
        failed.push({ server: server.name, error: err.message })
      }
    }
    if (applied.length === 0) {
      throw httpError(502, '所有服务器改密均失败', { failed })
    }

    if (passwordHash) await this.ledger.setPasswordHash(rec.username, passwordHash)
    const snapshot = await this._ensurePushed()
    await this.audit.append('qqbind.change_password', {
      username: rec.username,
      qq: rec.qq,
      servers: applied,
      failed,
      source,
    })
    return { username: rec.username, qq: rec.qq, servers: applied, failed, snapshot }
  }

  /** 换绑 QQ */
  async rebind({ username, newQq, source = 'admin' }) {
    const rec = await this.ledger.rebind({ username, newQq })
    const snapshot = await this._ensurePushed()
    await this.audit.append('qqbind.rebind', {
      username: rec.username,
      fromQq: rec.fromQq,
      toQq: rec.toQq,
      source,
    })
    return { ...rec, snapshot }
  }

  /** 转移绑定（原角色数据保留，仅解除 QQ 绑定） */
  async transfer({ fromUsername, toUsername, qq, source = 'admin' }) {
    const name = String(toUsername || '').trim()
    if (name) {
      // 新角色的免密哈希从服务器重新获取（旧版语义）
      const { info } = await this.gameOps.locateAccount(name, {})
      const rec = await this.ledger.transfer({
        fromUsername,
        toUsername: name,
        qq,
        passwordHash: info.passwordHash,
      })
      const snapshot = await this._ensurePushed()
      await this.audit.append('qqbind.transfer', {
        from: rec.fromUsername,
        to: rec.toUsername,
        qq: rec.qq,
        source,
      })
      return { ...rec, snapshot }
    }
    const rec = await this.ledger.transfer({ fromUsername, toUsername, qq })
    const snapshot = await this._ensurePushed()
    return { ...rec, snapshot }
  }

  /** 解绑（仅删绑定关系；各服账号与角色数据保留） */
  async unbind({ username, qq, source = 'admin' }) {
    const rec = await this.ledger.unbind({ username, qq })
    const snapshot = await this._ensurePushed()
    await this.audit.append('qqbind.unbind', { username: rec.username, qq: rec.qq, source })
    return { ...rec, snapshot }
  }

  /**
   * 改名联动（供 base 调用；软依赖）。
   * 旧版缺陷 B1 的正解：改名同样触发快照下发。
   */
  async renameAccount(oldName, newName, { source = 'base' } = {}) {
    const rec = await this.ledger.rename(oldName, newName)
    if (rec.skipped) return rec
    const snapshot = await this._ensurePushed()
    await this.audit.append('qqbind.rename', {
      from: rec.from,
      to: rec.to,
      source,
    })
    return { ...rec, snapshot }
  }

  /** 删号级联（供 base 调用；仅删台账记录，账号由 base 删） */
  async deleteAccount(username, { source = 'base' } = {}) {
    const rec = await this.ledger.remove(username)
    if (rec.skipped) return rec
    const snapshot = await this._ensurePushed()
    await this.audit.append('qqbind.delete', { username: rec.username, qq: rec.qq, source })
    return { ...rec, snapshot }
  }

  /** 批量解绑（上限 100，逐条回显失败，旧版语义） */
  async batchUnbind(users, { source = 'admin' } = {}) {
    const list = Array.isArray(users) ? users.map(String).filter(Boolean) : []
    if (list.length === 0) throw httpError(400, '缺少参数: users')
    if (list.length > BATCH_LIMIT) throw httpError(400, `单次批量上限 ${BATCH_LIMIT} 人`)

    const ok = []
    const failed = []
    for (const username of list) {
      try {
        const rec = await this.ledger.unbind({ username })
        ok.push(rec.username)
      } catch (err) {
        failed.push({ username, error: err.message })
      }
    }
    const snapshot = ok.length > 0 ? await this._ensurePushed() : null
    await this.audit.append('qqbind.batch_unbind', { ok: ok.length, total: list.length, source })
    return { ok: ok.length, total: list.length, succeeded: ok, failed, snapshot }
  }

  /** 导入旧台账（幂等；冲突逐条列出） */
  async importLegacy(source, { dryRun = false, actor = 'admin' } = {}) {
    const result = await this.ledger.import(source, { dryRun })
    const snapshot = result.applied && result.appliedCount > 0 ? await this._ensurePushed() : null
    await this.audit.append('qqbind.import', {
      imported: result.imported.length,
      skipped: result.skipped.length,
      conflicts: result.conflicts.length,
      dryRun,
      actor,
    })
    return { ...result, snapshot }
  }

  // ══════════════════════════════════════════════════════════
  // 快照下发（P4：变更即推 + 连接恢复补推；周期对账为后续项）
  // ══════════════════════════════════════════════════════════

  /**
   * 组装某服的快照载荷（密码哈希只发给开了 syncAccounts 的服，最小暴露）。
   *
   * promotion 是**全局**配置（不是逐服），随快照一起下发 —— 游戏服半在玩家登录时
   * 按它决定是否自动晋升（旧版是经 /data/promotion/config/set 单独下发，
   * tshockService.js:1849-1868；合并进快照可少一个端点与一处状态不一致的可能）。
   */
  _snapshotPayloadFor(server, version) {
    const flags = serverFlags(this.config, server.id)
    const records = []
    for (const username of this.ledger.usernames()) {
      const rec = this.ledger.getByUsername(username)
      if (!rec) continue
      const item = { username: rec.username, qq: rec.qq }
      if (flags.syncAccounts) item.passwordHash = rec.passwordHash
      records.push(item)
    }
    const promo = this.config.promotion || {}
    return {
      version,
      records,
      syncAccounts: flags.syncAccounts,
      syncUuid: flags.syncUuid,
      promotion: {
        enabled: promo.enabled === true,
        targetGroup: String(promo.targetGroup || ''),
        mode: String(promo.mode || 'auto'),
        ignoreGroups: Array.isArray(promo.ignoreGroups) ? promo.ignoreGroups.map(String) : [],
      },
    }
  }

  /**
   * 下发快照到启用服（默认全部）。
   * 永不静默失败：逐服状态写进 pushStatus 并发事件，调用方可原样回给用户。
   */
  async pushSnapshot({ serverIds = null } = {}) {
    const servers = await this.gameOps.enabledServers()
    const targets = serverIds && serverIds.length > 0
      ? servers.filter((s) => serverIds.map(String).includes(String(s.id)))
      : servers
    if (targets.length === 0) {
      return { ok: true, version: this.snapshotVersion, total: 0, servers: [], note: '没有启用中的服务器' }
    }

    const version = this.snapshotVersion + 1
    const results = []
    for (const server of targets) {
      const payload = this._snapshotPayloadFor(server, version)
      try {
        const data = await this.gameOps.pushSnapshot(server, payload)
        const entry = {
          id: server.id,
          name: server.name,
          ok: true,
          count: payload.records.length,
          version,
          hashSent: payload.syncAccounts,
          upstreamVersion: data && data.version != null ? data.version : null,
        }
        results.push(entry)
        this.pushStatus.set(server.id, { ...entry, at: new Date().toISOString() })
      } catch (err) {
        const entry = {
          id: server.id,
          name: server.name,
          ok: false,
          version,
          error: err.message,
          serverHalfMissing: err.serverHalfMissing === true,
        }
        results.push(entry)
        this.pushStatus.set(server.id, { ...entry, at: new Date().toISOString() })
      }
    }

    const okCount = results.filter((r) => r.ok).length
    if (okCount > 0) this.snapshotVersion = version
    for (const r of results) {
      try {
        this.ctx.emit('qqbind/snapshot', { serverId: r.id, ok: r.ok, error: r.error, version })
      } catch {
        /* 无监听者忽略 */
      }
    }
    return { ok: okCount === results.length, version, total: results.length, okCount, servers: results }
  }

  /** 各服快照状态（前端状态区与排障用） */
  snapshotStatus() {
    return {
      version: this.snapshotVersion,
      count: this.ledger.size,
      updatedAt: this.ledger.updatedAt,
      servers: [...this.pushStatus.entries()].map(([id, v]) => ({ serverId: id, ...v })),
    }
  }

  /**
   * 兜底对账：周期补推，防"某次推送丢了但无人察觉"（快照失配 → 免密/豁免悄悄不生效）。
   * 配置改动后调用可立即按新周期重启（不依赖重启宿主）。
   */
  startReconcile() {
    this.stopReconcile()
    const ms = Number(this.config && this.config.snapshot && this.config.snapshot.reconcileIntervalMs) || 0
    if (ms <= 0) return false
    this._reconcile = setInterval(() => {
      this.pushSnapshot().catch((err) => {
        this.ctx.logger?.warn?.(`[qq-bind] 兜底对账下发失败：${err.message}`)
      })
    }, ms)
    // 定时器不应阻止宿主退出
    this._reconcile.unref?.()
    return true
  }

  stopReconcile() {
    if (this._reconcile) {
      clearInterval(this._reconcile)
      this._reconcile = null
    }
  }

  /** 插件被禁用/卸载时由 apply 返回的释放钩子调用 */
  shutdown() {
    this.stopReconcile()
  }

  /**
   * 跨服 UUID 同步（免密）。旧版语义：UUID 只转发、不落台账；
   * 目标 = 开启 syncUuid 的服，排除来源服；kick 由逐服 kickDuplicate 决定。
   */
  async syncUuid(username, uuid, { excludeServerId = null } = {}) {
    const value = String(uuid || '')
    if (!value) return { ok: false, error: '缺少 uuid', servers: [] }
    const servers = await this.gameOps.enabledServers()
    const targets = servers.filter(
      (s) => serverFlags(this.config, s.id).syncUuid && String(s.id) !== String(excludeServerId ?? ''),
    )
    const results = []
    for (const server of targets) {
      const kick = serverFlags(this.config, server.id).kickDuplicate
      try {
        const data = await this._pushUuid(server, username, value, kick)
        results.push({ id: server.id, name: server.name, ok: true, kicked: !!data.kicked })
      } catch (err) {
        results.push({ id: server.id, name: server.name, ok: false, error: err.message })
      }
    }
    return { ok: results.every((r) => r.ok), servers: results, targetCount: targets.length }
  }

  async _pushUuid(server, username, uuid, kick) {
    // 复用 base 既有 UUID 端点（不需要本件新增游戏服端点）
    return this.gameOps.syncUuidToServer(server, { name: username, uuid, kick })
  }

  // ══════════════════════════════════════════════════════════
  // 接入层（扩展点）
  // ══════════════════════════════════════════════════════════

  /** 注册接入方式（Koishi/官方 Node 应用/…）：{ name, authenticate, capabilities, mount, send } */
  registerAdapter(adapter) {
    return this.adapters.register(adapter)
  }

  /** 注册能力：registerCapability(name, handler, meta) → 取消函数 */
  registerCapability(name, handler, meta = {}) {
    return this.capabilities.register(name, handler, meta)
  }

  /** 统一调用入口：先做适配器放行检查，再分发到能力处理器 */
  async invoke(capability, { principal = null, params = {} } = {}) {
    const adapterName = principal && principal.adapter
    if (adapterName && !this.adapters.allows(adapterName, capability)) {
      throw httpError(403, `接入方式 ${adapterName} 未放行能力：${capability}`)
    }
    return this.capabilities.invoke(capability, { principal, params })
  }

  /** 宿主 → 用户/群 下发（适配器未实现则 501） */
  async sendNotify(adapterName, target, message) {
    return this.adapters.send(adapterName, target, message)
  }

  // ══════════════════════════════════════════════════════════
  // 台账变更统一出口（事件 + 快照）
  // ══════════════════════════════════════════════════════════

  /** 由 Ledger 的 onChange 调用；保证"台账变 → 事件 + 快照"不被漏掉 */
  onLedgerChange(evt) {
    if (!evt || !evt.action) return
    this._mutationSeq++
    const eventName = EVENT_OF_ACTION[evt.action]
    if (eventName) {
      try {
        this.ctx.emit(eventName, { ...evt, source: evt.source ?? '' })
      } catch {
        /* 无监听者忽略 */
      }
    }
    if (this.config && this.config.snapshot.pushOnChange === false) return
    this._schedulePush()
  }

  /**
   * 排队一次快照推送（串行执行，避免并发变更引发推送洪水）。
   * 单一推送者设计：推送只由"台账变更"这一条通路触发，任何变更都不可能漏推
   * （旧版缺陷 B1 的根因正是"改名走了另一条通路、没人推"）。
   */
  _schedulePush() {
    this._pushSeq = this._mutationSeq
    const run = async () => {
      this._pushResult = await this.pushSnapshot()
      return this._pushResult
    }
    this._pushQueue = (this._pushQueue || Promise.resolve())
      .catch(() => {})
      .then(run)
      .catch((err) => {
        this._pushResult = {
          ok: false,
          version: this.snapshotVersion,
          total: 0,
          okCount: 0,
          servers: [],
          error: err.message,
        }
        this.ctx.logger?.warn?.(`[qq-bind] 下发快照失败：${err.message}`)
        return this._pushResult
      })
    return this._pushQueue
  }

  /**
   * 等待"本次台账变更"引发的推送完成，并返回其结果（业务方法用它回显给调用方）。
   * pushOnChange=false 时改为就地推送一次，保证变更方法永远拿到真实结果。
   */
  async _ensurePushed() {
    if (this._pushQueue && this._pushSeq === this._mutationSeq) return this._pushQueue
    if (!this.config || this.config.snapshot.pushOnChange === false) return this._schedulePush()
    if (!this._pushQueue) return this._schedulePush()
    return this._pushQueue
  }

  // ── 内部工具 ──────────────────────────────────────────────

  /** 1:1 前置校验（旧版文案） */
  _assertFree(qq, player) {
    const byQq = this.ledger.getByQq(qq)
    if (byQq) throw httpError(409, '该 QQ 已绑定角色', { owner: byQq.username })
    const byName = this.ledger.getByUsername(player)
    if (byName) {
      throw httpError(409, `该角色已绑定 QQ：${byName.qq}（如需更换请用「改绑」）`, {
        boundQq: byName.qq,
      })
    }
  }

  /** 时长（软依赖 online-stats；缺失时明确 unavailable，不假装 0） */
  async _playtimeAll() {
    const os = this.ctx.onlineStats
    if (!os || typeof os.getAllPlaytime !== 'function') return null
    try {
      const out = await os.getAllPlaytime()
      return out && typeof out === 'object' ? out : null
    } catch {
      return null
    }
  }

  /** 单玩家时长（player-info 用） */
  async _playtimeOf(username) {
    const os = this.ctx.onlineStats
    if (!os) return { total: null, servers: {}, unavailable: true, hint: '未安装 online-stats 插件' }
    try {
      if (typeof os.getPlayerStats === 'function') {
        const st = await os.getPlayerStats(username)
        const pt = st && st.playtime
        if (pt && typeof pt === 'object') {
          return {
            total: Number(pt.total ?? 0),
            servers: pt.servers ?? {},
            source: 'online-stats',
          }
        }
        if (typeof pt === 'number') return { total: pt, servers: {}, source: 'online-stats' }
      }
      const all = await this._playtimeAll()
      if (all && all.stats) {
        return { total: Number(all.stats[username] ?? 0), servers: {}, source: 'online-stats' }
      }
    } catch {
      /* 落到 unavailable */
    }
    return { total: null, servers: {}, unavailable: true, hint: '时长数据暂不可用' }
  }

  /** 我的信息（机器人 /api/bot/player-info）：主服游戏数据 + 多服时长 */
  async playerInfo(identifier, { serverId = '' } = {}) {
    const rec = this.ledger.get(identifier)
    if (!rec) throw httpError(404, '该角色未绑定 QQ')

    const servers = await this.gameOps.enabledServers()
    const preferred = serverId || this.config.binding.defaultServerId
    const main =
      (preferred && servers.find((s) => String(s.id) === String(preferred))) || servers[0] || null
    if (!main) throw httpError(400, '尚未配置任何启用服务器')

    const game = await this.gameOps.playerData(main, rec.username)
    const playtime = await this._playtimeOf(rec.username)
    return {
      username: rec.username,
      player: rec.username,
      qq: rec.qq,
      server: main.name,
      boundAt: rec.boundAt,
      game: {
        player: game.player,
        group: game.group,
        registered: game.registered,
        deaths: game.deaths,
        fishing_quests: game.fishing_quests,
        found: game.found,
      },
      playtime,
      onlineMinutes: playtime.total,
    }
  }
}

/** 随机密码（用户随后用「改密码」设置；免密登录不依赖它） */
function randomPassword() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'
  const bytes = randomBytes(RANDOM_PASSWORD_BYTES)
  let out = ''
  for (const b of bytes) out += alphabet[b % alphabet.length]
  return out
}

// ══════════════════════════════════════════════════════════════
// apply
// ══════════════════════════════════════════════════════════════

export function apply(ctx) {
  const dataDir = ctx.paths.dataOf('qq-bind')
  const configFile = path.join(dataDir, 'config.json')
  const ledgerFile = path.join(dataDir, 'bindings.json')
  const auditFile = path.join(dataDir, 'audit.jsonl')

  const service = new QqBindService(ctx)
  service.configFile = configFile

  /** 同步占位服务：让后续同步代码立刻可用 ctx.qqBind（异步初始化在下面补） */
  ctx.qqBind = service

  const ready = (async () => {
    await mkdir(dataDir, { recursive: true })
    const { config, existed } = await loadConfig(configFile)
    service.config = config
    if (!existed) await saveConfig(configFile, config)

    service.audit = new AuditLog({ file: auditFile })
    service.ledger = new Ledger({ file: ledgerFile, onChange: (evt) => service.onLedgerChange(evt) })
    await service.ledger.load()
    service.gameOps = createGameOps({ ctx })

    ctx.logger?.info?.(
      `[qq-bind] 台账就绪：${service.ledger.size} 条绑定（${ledgerFile}）`,
    )
    return service
  })()
  /** 初始化完成信号：其他插件/适配器可 await ctx.qqBind.ready 后再读台账 */
  service.ready = ready

  // 绑定域能力（本件自己拥有的那一支）
  service.registerCapability(
    'binding.bind',
    async ({ principal, params }) => {
      await ready
      return service.bind({
        qq: params.qq,
        player: params.player,
        serverId: params.serverId || '',
        source: principal?.adapter ? `${principal.adapter}:${principal.kind || 'bot'}` : 'api',
      })
    },
    { legacy: { path: '/api/bot/bind', method: 'post' }, description: '绑定已有角色' },
  )

  service.registerCapability(
    'binding.register',
    async ({ principal, params }) => {
      await ready
      return service.registerPlayer({
        qq: params.qq,
        player: params.player,
        source: principal?.adapter ? `${principal.adapter}:${principal.kind || 'bot'}` : 'api',
      })
    },
    { legacy: { path: '/api/bot/register', method: 'post' }, description: '注册新角色' },
  )

  service.registerCapability(
    'binding.changePassword',
    async ({ principal, params }) => {
      await ready
      return service.changePassword({
        username: principal?.boundUsername || params.username,
        qq: params.qq,
        password: params.password,
        source: principal?.adapter ? `${principal.adapter}:${principal.kind || 'bot'}` : 'api',
      })
    },
    {
      legacy: { path: '/api/bot/change-password', method: 'post' },
      requireBound: true,
      description: '修改密码（全服覆盖免密哈希）',
    },
  )

  service.registerCapability(
    'binding.resolve',
    async ({ principal, params }) => {
      await ready
      return service.playerInfo(params.qq || principal?.qq || params.username || principal?.boundUsername, {
        serverId: params.serverId || '',
      })
    },
    {
      legacy: { path: '/api/bot/player-info', method: 'get' },
      requireBound: true,
      description: '我的信息（身份 + 游戏数据 + 多服时长）',
    },
  )

  service.registerCapability(
    'binding.status',
    async ({ params }) => {
      await ready
      const rec = service.ledger.get(params.qq || params.username || params.player)
      if (!rec) return { bound: false }
      return { bound: true, username: rec.username, qq: rec.qq, boundAt: rec.boundAt }
    },
    { description: '查询绑定状态（新接入方式用，无旧路径）' },
  )

  // 内置兼容适配器：让旧版 Koishi 机器人零改动
  service.registerAdapter(
    createLegacyHttpAdapter({
      ctx,
      capabilities: service.capabilities,
      adapters: service.adapters,
      getConfig: () => service.config,
      identify: (principal, params) => service.identify(principal, params),
      audit: service.audit,
    }),
  )

  // ── 管理接口（verifyAuth + requireAdmin；不经适配器）──
  const app = ctx.webServer.app
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]
  const fail = (res, err) => {
    const status = err.status || 500
    const body = { error: err.message }
    for (const key of ['failed', 'conflicts', 'servers', 'owner', 'boundQq', 'serverHalfMissing', 'hint']) {
      if (err[key] !== undefined) body[key] = err[key]
    }
    if (!res.headersSent) res.status(status).json(body)
  }
  const wrap = (handler) => async (req, res) => {
    try {
      await ready
      res.json(await handler(req, res))
    } catch (err) {
      fail(res, err)
    }
  }

  app.get('/api/qq-bind/list', ...admin, wrap(async (req) => {
    const q = req.query || {}
    return service.list({
      keyword: q.keyword || '',
      page: Number(q.page) || 1,
      pageSize: Number(q.pageSize) || 50,
    })
  }))

  app.get('/api/qq-bind/status', ...admin, wrap(async () => ({
    ledger: {
      file: ledgerFile,
      count: service.ledger.size,
      updatedAt: service.ledger.updatedAt,
      schema: service.ledger.schema,
    },
    snapshot: service.snapshotStatus(),
    adapters: service.adapters.list(),
    capabilities: service.capabilities.list(),
    config: redactConfig(service.config),
    configFile,
  })))

  app.post('/api/qq-bind/bind', ...admin, wrap(async (req) => {
    const b = req.body || {}
    return service.bind({
      qq: b.qq,
      player: b.player || b.username,
      serverId: b.serverId || '',
      source: 'admin',
    })
  }))

  app.post('/api/qq-bind/rebind', ...admin, wrap(async (req) => {
    const b = req.body || {}
    return service.rebind({ username: b.username, newQq: b.qq || b.newQq, source: 'admin' })
  }))

  app.post('/api/qq-bind/transfer', ...admin, wrap(async (req) => {
    const b = req.body || {}
    return service.transfer({
      fromUsername: b.username || b.fromUsername,
      toUsername: b.newPlayer || b.toUsername,
      qq: b.qq,
      source: 'admin',
    })
  }))

  app.post('/api/qq-bind/unbind', ...admin, wrap(async (req) => {
    const b = req.body || {}
    return service.unbind({ username: b.username, qq: b.qq, source: 'admin' })
  }))

  app.post('/api/qq-bind/batch', ...admin, wrap(async (req) => {
    const b = req.body || {}
    const action = String(b.action || '').trim()
    if (action !== 'unbind') throw httpError(400, `不支持的批量动作：${action || '(空)'}`)
    return service.batchUnbind(b.users, { source: 'admin' })
  }))

  app.post('/api/qq-bind/import', ...admin, wrap(async (req) => {
    const b = req.body || {}
    let payload = b.data
    if (!payload && b.file) {
      // 安全：只允许读本件数据目录下的文件（拒绝任意路径读取）
      const resolved = path.resolve(dataDir, String(b.file))
      if (!resolved.startsWith(path.resolve(dataDir) + path.sep)) {
        throw httpError(400, '只允许读取本插件数据目录下的文件')
      }
      payload = JSON.parse(await readFile(resolved, 'utf8'))
    }
    if (!payload) throw httpError(400, '缺少参数: data 或 file')
    return service.importLegacy(payload, { dryRun: b.dryRun === true, actor: 'admin' })
  }))

  app.post('/api/qq-bind/playtime-refresh', ...admin, wrap(async () => {
    const os = ctx.onlineStats
    if (!os || typeof os.getAllPlaytime !== 'function') {
      throw httpError(501, '未安装 online-stats 插件，无法刷新时长', {
        missingPlugin: 'online-stats',
      })
    }
    // online-stats 自身按分钟采样；这里主动拉一次全量累计，触发其向各服取数
    const data = await os.getAllPlaytime()
    return { ok: true, refreshed: Object.keys((data && data.stats) || {}).length }
  }))

  app.get('/api/qq-bind/audit', ...admin, wrap(async (req) => ({
    rows: await service.audit.tail(Number((req.query || {}).limit) || 100),
  })))

  app.get('/api/qq-bind/config', ...admin, wrap(async () => ({
    config: redactConfig(service.config),
    configFile,
  })))

  app.post('/api/qq-bind/config', ...admin, wrap(async (req) => {
    const b = req.body || {}
    const updates = b.updates && typeof b.updates === 'object' ? b.updates : null
    if (updates) {
      for (const [key, value] of Object.entries(updates)) setByPath(service.config, key, value)
    } else if (b.path) {
      setByPath(service.config, b.path, b.value)
    } else {
      throw httpError(400, '缺少参数: path/value 或 updates')
    }
    service.config = normalizeConfig(service.config)
    await saveConfig(configFile, service.config)
    service.startReconcile() // 周期改动即时生效（0 = 关闭）
    await service.audit.append('qqbind.config.set', { actor: 'admin', keys: Object.keys(updates || { [b.path]: true }) })
    // 配置变更必须立刻下发：快照载荷里带着 syncAccounts / syncUuid / promotion，
    // 不推的话管理员的改动要等"下一次台账变更 / 服务器重连 / 对账周期"才生效，
    // 而 reconcileIntervalMs=0（关闭周期对账）时可能**永远不生效**——这正是
    // "界面显示已启用、实际没生效"那类静默失效。结果如实回显，不假装成功。
    const snapshot = await service._schedulePush()
    return { ok: true, config: redactConfig(service.config), snapshot }
  }))

  // ── 连接恢复 / 服务器加载完成后补推快照（P4）──
  const repush = (why) => {
    if (service.config && service.config.snapshot.pushOnServerConnect === false) return
    ready
      .then(() => service.pushSnapshot())
      .then((r) => ctx.logger?.info?.(`[qq-bind] ${why}后补推快照：成功 ${r.okCount ?? 0}/${r.total ?? 0}`))
      .catch((err) => ctx.logger?.warn?.(`[qq-bind] ${why}后补推快照失败：${err.message}`))
  }
  ctx.on('push/connected', () => repush('服务器连接建立'))
  ctx.on('servers/loaded', () => repush('服务器列表加载'))

  // 初始化完成后按配置启动兜底对账
  ready.then(() => service.startReconcile()).catch(() => {})

  // ── 终端命令（可选服务，对应设计 §11 的 qqbind-import）──
  // 用可选访问而不是写进 inject：宿主没有 terminal 服务时本件仍应能加载，
  // 不该因为一个辅助命令把整个插件变成"依赖不满足即不可用"。
  try {
    const terminal =
      (typeof ctx.get === 'function' ? ctx.get('terminal') : null) ?? ctx.terminal ?? null
    if (terminal && typeof terminal.register === 'function') {
      terminal.register(
        'qqbind-import',
        '导入旧版 QQ 台账（用法: qqbind-import <qq_accounts.json 路径> [--dry]）',
        async (args) => {
          const list = Array.isArray(args) ? args : String(args || '').split(/\s+/)
          const dry = list.includes('--dry')
          const file = list.find((a) => a && !String(a).startsWith('--'))
          if (!file) {
            console.log('用法: qqbind-import <旧 qq_accounts.json 路径> [--dry]')
            return
          }
          let parsed
          try {
            parsed = JSON.parse(await readFile(file, 'utf8'))
          } catch (err) {
            console.log(`读取或解析失败：${err.message}`)
            return
          }
          const r = await service.importLegacy(parsed, { dryRun: dry, actor: 'terminal' })
          console.log(
            `${dry ? '[试运行，未写入] ' : ''}新增 ${r.imported.length}　跳过 ${r.skipped.length}　冲突 ${r.conflicts.length}`,
          )
          for (const c of r.conflicts.slice(0, 20)) {
            console.log(`  冲突：${c.username}　${c.reason || c.error || ''}`)
          }
          if (r.conflicts.length > 20) {
            console.log(`  （另有 ${r.conflicts.length - 20} 条冲突未显示）`)
          }
          if (!dry && r.applied) {
            console.log(`已写台账并下发快照：成功 ${r.snapshot?.okCount ?? 0}/${r.snapshot?.total ?? 0}`)
          }
        },
      )
    }
  } catch (err) {
    ctx.logger?.warn?.(`[qq-bind] 终端命令 qqbind-import 注册跳过：${err.message}`)
  }

  ctx.logger?.info?.(`[qq-bind] 已挂载：接入适配器 ${service.adapters.list().map((a) => a.name).join(', ') || '(无)'}；数据目录 ${dataDir}`)

  // cordis 释放钩子（宿主在插件禁用/卸载时调用，见 plugins/online-stats/index.js:916-918 同款约定）
  return () => service.shutdown()
}
