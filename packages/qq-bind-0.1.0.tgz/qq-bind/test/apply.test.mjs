/**
 * 装配级集成测试（真实 cordis Context + 真实 apply + 真实 HTTP）
 *
 * 验证 P1/P2 的装配是否成立：
 *   - apply 能注册 5 个绑定域能力与内置 legacy-http 适配器
 *   - /api/bot 路由真的挂在 webServer.app 上，且托管了台账/配置/下发
 *   - 走真实 HTTP 的「机器人绑定」全链路：查角色 → 写台账 → 下发快照
 *   - 错误路径同样走通（角色不存在 404 / 服务器未装 DLL → 501 serverHalfMissing）
 *
 * 注意：本测试**不启动任何服务器进程**，只在测试进程内挂一个 express 实例。
 * 运行：node test/apply.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import express from 'express'
import { Context } from '@deepseek-ai/cordis'

const TOKEN = 'integration-bot-token'

let dataDir
let app
let server
let base
let ctx
let svc
/** apply 返回的释放钩子 */
let dispose
let terminalHandlers = {}
/** 模拟"先于 qq-bind 加载的插件"：用 ctx.inject 注册能力，验证晚到补注册 */
let lateInject = { ran: false }
/** 记录宿主对游戏服的调用 */
let calls
/** 每台假服务器的行为可单独覆盖 */
let fakeServers

before(async () => {
  dataDir = await mkdtemp(path.join(tmpdir(), 'qqbind-apply-'))
  process.env.TSWEB_QQBIND_TOKEN = TOKEN

  app = express()
  app.use(express.json({ limit: '100mb' }))
  calls = []

  ctx = new Context()
  ctx.webServer = { app }
  ctx.auth = {
    verifyAuth: () => (req, res, next) => next(),
    requireAdmin: () => (req, res, next) => next(),
  }
  ctx.paths = { dataOf: (n) => path.join(dataDir, n) }
  ctx.logger = { info() {}, warn() {}, error() {} }

  // 三台假服务器：缺失标志按路径前缀生效（"装了 Base、没装 QqBind"是现实中的常见组合）
  fakeServers = {
    s1: {
      raw: { id: 's1', name: '一服', host: '127.0.0.1', port: 7777, token: 'token-s1', enabled: true },
      findAccount: { found: true, passwordHash: '$2y$hash-from-tshock', uuid: 'uuid-s1', online: false },
      halfMissing: false, // 没装 QqBind.dll
      baseMissing: false, // 没装 Base.dll
    },
    s2: {
      raw: { id: 's2', name: '二服', host: '127.0.0.1', port: 7778, token: 'token-s2', enabled: true },
      halfMissing: true,
      baseMissing: true,
    },
    s3: {
      raw: { id: 's3', name: '三服', host: '127.0.0.1', port: 7779, token: 'token-s3', enabled: true },
      halfMissing: false, // 装了 QqBind.dll（UUID 落盘走本件端点，见 gameOps.syncUuidToServer 注释）
      baseMissing: false,
    },
  }

  ctx.servers = {
    list: async () => Object.values(fakeServers).map((s) => ({ ...s.raw })),
    getRaw: (id) => (fakeServers[id] ? { ...fakeServers[id].raw } : null),
  }
  ctx.tshock = {
    fetchFor: async (srv, pathname, params) => {
      calls.push({ kind: 'GET', server: srv.id, pathname, params })
      const fake = fakeServers[srv.id]
      if (fake.halfMissing && pathname.startsWith('/data/qq/')) return { ok: false, status: 404, data: {} }
      if (fake.baseMissing && pathname.startsWith('/data/base/')) return { ok: false, status: 404, data: {} }
      if (fake.baseMissing && pathname.startsWith('/v2/')) return { ok: false, status: 404, data: {} }
      if (pathname === '/data/qq/uuid') {
        // 本件端点：落盘 UUID（kick 由游戏服半按账号名匹配已登录角色后自行执行）
        return { ok: true, status: 200, data: { ok: true, username: params.username } }
      }
      if (pathname === '/data/qq/find-account') {
        const wanted = String(params.name || '').toLowerCase()
        if (wanted === 'steve') return { ok: true, status: 200, data: fake.findAccount }
        if (wanted === 'onlineguy') {
          // 该角色只在 s1 存在：s3 虽然装了 QqBind.dll 但没有这个账号
          if (srv.id !== 's1') return { ok: true, status: 200, data: { found: false } }
          return {
            ok: true,
            status: 200,
            data: {
              found: true,
              passwordHash: '$2y$hash-online',
              uuid: '0'.repeat(32),
              group: 'default',
              online: true,
              onlineUuid: 'abcdef0123456789abcdef0123456789',
            },
          }
        }
        return { ok: true, status: 200, data: { found: false } }
      }
      if (pathname === '/data/qq/player-data') {
        return {
          ok: true,
          status: 200,
          data: { found: true, player: params.name, group: 'vip', registered: '2026-01-01', deaths: 3, fishing_quests: 5 },
        }
      }
      return { ok: true, status: 200, data: { ok: true } }
    },
    postFor: async (srv, pathname, body) => {
      calls.push({ kind: 'POST', server: srv.id, pathname, body })
      const fake = fakeServers[srv.id]
      if (fake.halfMissing && pathname.startsWith('/data/qq/')) return { ok: false, status: 404, data: {} }
      return { ok: true, status: 200, data: { ok: true, version: body && body.version, count: (body && body.records || []).length } }
    },
  }

  // 终端命令用的假服务（可选服务：本件用可选访问，不写进 inject）
  terminalHandlers = {}
  ctx.terminal = {
    register(cmdName, desc, fn) {
      terminalHandlers[cmdName] = fn
    },
  }

  // 关键：在 qq-bind 之前注册（模拟 servers/online-stats 先加载的真实顺序）。
  // 这正是 servers/online-stats 里用的写法：ctx.inject 让"服务晚到"也能补注册。
  lateInject = { ran: false }
  ctx.inject(['qqBind'], (c) => {
    lateInject.ran = true
    const off = c.qqBind.registerCapability(
      'server.list',
      async () => ({ servers: [{ id: 's1', name: '主服', enabled: true, note: '' }] }),
      { legacy: { path: '/api/bot/servers', method: 'get' }, description: '服务器列表' },
    )
    return off
  })
  assert.equal(lateInject.ran, false, 'qqBind 尚未出现，注入回调不应提前执行')

  const mod = await import('../index.js')
  assert.equal(mod.name, 'qq-bind')
  assert.deepEqual(mod.inject, ['webServer', 'auth', 'servers', 'tshock', 'paths'])
  dispose = mod.apply(ctx)
  assert.equal(typeof dispose, 'function', 'apply 必须返回释放钩子（宿主在卸载时调用）')
  await ctx.qqBind.ready
  svc = ctx.qqBind

  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', resolve)
  })
  base = `http://127.0.0.1:${server.address().port}`
})

after(async () => {
  delete process.env.TSWEB_QQBIND_TOKEN
  if (server) await new Promise((resolve) => server.close(resolve))
  await rm(dataDir, { recursive: true, force: true })
})

function bot(pathname, body, { token = TOKEN, method = 'POST' } = {}) {
  const sep = pathname.includes('?') ? '&' : '?'
  return fetch(`${base}${pathname}${sep}token=${token}`, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: method === 'POST' ? JSON.stringify(body || {}) : undefined,
  })
}

/** 一次读完响应体（避免 text() 与 json() 二次读取同一 Response） */
async function readJson(res) {
  const text = await res.text()
  let data = null
  try {
    data = JSON.parse(text)
  } catch {
    data = null
  }
  return { status: res.status, data, text }
}

test('装配：能力、适配器、服务与数据目录齐备', async () => {
  const names = svc.capabilities.list().map((c) => c.name).sort()
  // 本件自带的是绑定域能力；server.list 由测试里"先加载的插件"注册（见 P6 端到端用例），
  // 它出现在这里恰好证明能力注册表是跨插件共享的（本件不反向依赖业务插件）。
  assert.deepEqual(names, [
    'binding.bind',
    'binding.changePassword',
    'binding.register',
    'binding.resolve',
    'binding.status',
    'server.list',
  ])
  const adapters = svc.adapters.list()
  assert.equal(adapters.length, 1)
  assert.equal(adapters[0].name, 'legacy-http')
  assert.equal(adapters[0].capabilities[0], '*')
  assert.equal(svc.ledger.size, 0)

  // 配置首次运行应落盘，token 来自环境变量
  const cfg = JSON.parse(await readFile(path.join(dataDir, 'qq-bind', 'config.json'), 'utf8'))
  assert.equal(cfg.adapters['legacy-http'].token, TOKEN)
  assert.equal(cfg.snapshot.pushOnChange, true)
})

test('装配：/api/bot 中间件与管理路由都以可观测行为生效', async () => {
  // 用行为断言而不是 Express 内部结构（Express 5 已把 app._router 改为 app.router）
  const botUnknown = await readJson(await bot('/api/bot/not-a-real-command', {}))
  assert.equal(botUnknown.status, 404, botUnknown.text)
  assert.match(botUnknown.data.error, /未知的机器人命令/, '/api/bot 中间件未挂载')

  // 未带令牌访问任何路径都先 401（不泄漏"哪些能力已注册"）
  const botNoToken = await readJson(await fetch(`${base}/api/bot/not-a-real-command`, { method: 'POST' }))
  assert.equal(botNoToken.status, 401, '鉴权必须先于路径匹配')
  assert.equal(botNoToken.data.error, '机器人密钥不正确')

  // 用无副作用的参数校验路径验证路由已通（避免污染台账）
  const bind = await readJson(await fetch(`${base}/api/qq-bind/bind`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  }))
  assert.equal(bind.status, 400, bind.text)
  assert.match(bind.data.error, /缺少参数: qq/)

  for (const p of ['/api/qq-bind/list', '/api/qq-bind/status', '/api/qq-bind/config']) {
    const res = await fetch(`${base}${p}`)
    assert.equal(res.status, 200, `管理路由未生效：${p}`)
    assert.equal(typeof (await res.json()), 'object')
  }
})

test('端到端：机器人「绑定」→ 查角色 → 写台账 → 下发快照', async () => {
  // 逐服开关默认全 false（对齐旧版 backend/config.js:171-172）：显式开启 s1、保持 s2 关闭，
  // 以验证"哈希只发给开了 syncAccounts 的服"
  const cfgRes = await fetch(`${base}/api/qq-bind/config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      updates: {
        'servers.s1.syncAccounts': true,
        'servers.s1.syncUuid': true,
        'servers.s2.syncAccounts': false,
      },
    }),
  })
  assert.equal(cfgRes.status, 200, await cfgRes.text())

  calls.length = 0
  const res = await readJson(await bot('/api/bot/bind', { qq: '10001', player: 'steve' }))
  assert.equal(res.status, 200, res.text)
  const data = res.data

  assert.equal(data.success, true)
  assert.equal(data.player, 'steve', '角色名按用户输入回显（旧版卡片读 res.data.player）')
  assert.equal(data.server, '一服')
  assert.equal(data.qq, '10001')
  assert.equal(data.uuidSync, null, '角色离线时不做 UUID 同步')

  // 台账已落盘
  assert.equal(svc.ledger.size, 1)
  assert.equal(svc.getByQq('10001').username, 'steve')
  const onDisk = JSON.parse(await readFile(path.join(dataDir, 'qq-bind', 'bindings.json'), 'utf8'))
  assert.equal(onDisk.records.steve.qq, '10001')
  assert.equal(onDisk.records.steve.passwordHash, '$2y$hash-from-tshock', '免密哈希来自游戏服')

  // 下发快照：三台启用服各一次（s1/s3 成功、s2 未装 QqBind.dll → 501）
  const pushes = calls.filter((c) => c.pathname === '/data/qq/snapshot')
  assert.equal(pushes.length, 3)
  // 传输契约：分块 GET；每块的 payload 是该块的**记录数组**，
  // 元数据（version/chunk/chunks/total/开关）在 query 参数里
  const parsed = pushes.map((p) => ({ server: p.server, records: JSON.parse(p.params.payload), params: p.params }))
  const toS1 = parsed.find((p) => p.server === 's1')
  const toS2 = parsed.find((p) => p.server === 's2')
  assert.equal(toS1.records.length, 1)
  assert.equal(toS1.records[0].username, 'steve')
  assert.equal(toS1.records[0].passwordHash, '$2y$hash-from-tshock')
  assert.equal(toS1.params.syncAccounts, 1)
  assert.equal(toS1.params.chunks, 1, '单条记录只推一块')
  assert.equal(toS1.params.total, 1)
  assert.equal(toS2.records[0].passwordHash, undefined, '未开 syncAccounts 的服不下发哈希')

  const failed = data.snapshot.servers.find((s) => s.id === 's2')
  assert.equal(failed.ok, false)
  assert.equal(failed.serverHalfMissing, true, '未装 QqBind.dll 必须如实标注，不能假装成功')
  assert.equal(data.snapshot.ok, false, '有服未成功时整体 ok=false（不静默）')
})

test('端到端：1:1 约束与旧版文案（重复绑定被拒）', async () => {
  const again = await readJson(await bot('/api/bot/bind', { qq: '10001', player: 'steve' }))
  assert.equal(again.status, 409)
  assert.equal(again.data.error, '该 QQ 已绑定角色')

  const other = await readJson(await bot('/api/bot/bind', { qq: '10002', player: 'STEVE' }))
  assert.equal(other.status, 409)
  assert.match(other.data.error, /该角色已绑定 QQ：10001/)
})

test('端到端：绑定在线角色 → 复用 base 端点同步 UUID，并按开关踢重复登录', async () => {
  // s3 开启 UUID 同步与踢重复（s1 是来源服，必须被排除；s2 未开）
  const cfg = await fetch(`${base}/api/qq-bind/config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      updates: { 'servers.s3.syncUuid': true, 'servers.s3.kickDuplicate': true },
    }),
  })
  assert.equal(cfg.status, 200)

  calls.length = 0
  const res = await readJson(await bot('/api/bot/bind', { qq: '30001', player: 'onlineguy' }))
  assert.equal(res.status, 200, res.text)
  const sync = res.data.uuidSync
  assert.equal(sync.ok, true, JSON.stringify(sync))
  assert.equal(sync.targetCount, 1, '只应同步到开了 syncUuid 的 s3')

  const uuidCalls = calls.filter((c) => c.pathname === '/data/qq/uuid')
  assert.equal(uuidCalls.length, 1)
  assert.equal(uuidCalls[0].server, 's3', '来源服 s1 必须被排除')
  assert.equal(uuidCalls[0].params.username, 'onlineguy', '按账号名匹配（旧版语义），不是角色名')
  assert.equal(uuidCalls[0].params.uuid, 'abcdef0123456789abcdef0123456789')
  assert.equal(uuidCalls[0].params.kick, 1, 'kickDuplicate=true 时请求游戏服半踢重复登录')
  // 踢人由游戏服半按账号名+已登录条件执行，宿主不再单独调 TShock 的通用 kick 端点
  assert.equal(calls.filter((c) => c.pathname === '/v2/players/kick').length, 0)
  assert.equal(sync.servers[0].kicked, true)

  // 收尾：解绑，避免影响后续用例的计数断言
  const off = await fetch(`${base}/api/qq-bind/unbind`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'onlineguy' }),
  })
  assert.equal(off.status, 200)
})

test('端到端：角色不存在 → 404；全服未装 DLL → 501 + serverHalfMissing', async () => {
  const missing = await readJson(await bot('/api/bot/bind', { qq: '20001', player: 'Nobody' }))
  assert.equal(missing.status, 404, missing.text)
  assert.match(missing.data.error, /所有可查询的服务器中都不存在/)
  assert.match(missing.data.error, /另有 1 台服务器未能查询/, '部分服查不到时应如实标注')

  // 三台服都没装 QqBind.dll → 一台都没答上来，必须报 501 而不是"角色不存在"
  const saved = { s1: fakeServers.s1.halfMissing, s3: fakeServers.s3.halfMissing }
  fakeServers.s1.halfMissing = true
  fakeServers.s3.halfMissing = true
  const half = await readJson(await bot('/api/bot/bind', { qq: '20002', player: 'Nobody' }))
  assert.equal(half.status, 501, half.text)
  assert.equal(half.data.serverHalfMissing, true)
  fakeServers.s1.halfMissing = saved.s1
  fakeServers.s3.halfMissing = saved.s3
})

test('端到端：绑定后可查「我的信息」（卡片所需字段齐全）', async () => {
  const res = await readJson(await bot('/api/bot/player-info?qq=10001', null, { method: 'GET' }))
  assert.equal(res.status, 200, res.text)
  const data = res.data
  assert.equal(data.username, 'steve')
  assert.equal(data.qq, '10001')
  assert.equal(data.game.group, 'vip')
  assert.equal(data.game.fishing_quests, 5)
  assert.equal(data.playtime.unavailable, true, '未装 online-stats 时应如实标注不可用')
  assert.ok(data.playtime.hint)

  const unbound = await readJson(await bot('/api/bot/player-info?qq=99999', null, { method: 'GET' }))
  assert.equal(unbound.status, 403)
  assert.equal(unbound.data.needBind, true)
})

test('端到端：改密走 base 游戏侧端点并回读哈希（无 bcrypt 依赖）', async () => {
  calls.length = 0
  const res = await readJson(await bot('/api/bot/change-password', { qq: '10001', password: 'newpass123' }))
  assert.equal(res.status, 200, res.text)
  const data = res.data
  assert.ok(data.servers.includes('一服'), '一服改密应成功')
  assert.equal(data.failed.length, 1, '二服未装 base 服务端半 → 计入 failed')
  assert.match(data.failed[0].error, /Base\.dll/)

  const setCalls = calls.filter((c) => c.pathname === '/data/base/players/password')
  assert.ok(setCalls.length >= 1, '应调用 base 插件的游戏侧改密端点')
  assert.equal(setCalls[0].params.player, 'steve')
  assert.equal(setCalls[0].params.password, 'newpass123')

  // 改密后再次下发快照，且哈希来自服务器回读（仍为假服务器的哈希）
  const pushes = calls.filter((c) => c.pathname === '/data/qq/snapshot')
  assert.ok(pushes.length >= 1, '改密后必须下发快照')
})

test('端到端：管理接口受保护且可用（列表/状态/配置）', async () => {
  const list = await fetch(`${base}/api/qq-bind/list`)
  assert.equal(list.status, 200)
  const listData = await list.json()
  assert.equal(listData.total, 1)
  assert.equal(listData.rows[0].username, 'steve')

  const status = await fetch(`${base}/api/qq-bind/status`)
  assert.equal(status.status, 200)
  const statusData = await status.json()
  assert.equal(statusData.ledger.count, 1)
  assert.equal(statusData.adapters[0].name, 'legacy-http')
  assert.ok(statusData.snapshot.servers.length >= 1)
  assert.notEqual(statusData.config.adapters['legacy-http'].token, TOKEN, '状态接口必须脱敏令牌')
  assert.equal(statusData.config.adapters['legacy-http'].tokenSet, true)

  const config = await fetch(`${base}/api/qq-bind/config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path: 'binding.allowSelfRegister', value: true }),
  })
  assert.equal(config.status, 200)
  assert.equal((await config.json()).config.binding.allowSelfRegister, true)
  const reread = JSON.parse(await readFile(path.join(dataDir, 'qq-bind', 'config.json'), 'utf8'))
  assert.equal(reread.binding.allowSelfRegister, true, '配置变更必须落盘')
})

test('端到端：解绑只删绑定关系（旧版语义），并再下发一次快照', async () => {
  calls.length = 0
  const res = await fetch(`${base}/api/qq-bind/unbind`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'steve' }),
  })
  assert.equal(res.status, 200, await res.text())
  assert.equal(svc.ledger.size, 0)
  const pushes = calls.filter((c) => c.pathname === '/data/qq/snapshot')
  assert.equal(JSON.parse(pushes[0].params.payload).length, 0, '快照应变为空（旧版：整份替换）')
})

test('审计：绑定/解绑/配置变更都留痕', async () => {
  const rows = await svc.audit.tail(50)
  const actions = rows.map((r) => r.action)
  for (const a of ['qqbind.bind', 'qqbind.unbind', 'qqbind.config.set']) {
    assert.ok(actions.includes(a), `审计缺少 ${a}（实际：${actions.join(',')}）`)
  }
})

test('配置变更立即下发快照（含晋升配置），不依赖对账周期', async () => {
  // 先关闭周期对账：证明"立即下发"不是靠对账定时器兜的
  const off = await fetch(`${base}/api/qq-bind/config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path: 'snapshot.reconcileIntervalMs', value: 0 }),
  })
  assert.equal(off.status, 200)

  calls.length = 0
  const res = await fetch(`${base}/api/qq-bind/config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      updates: { 'promotion.enabled': true, 'promotion.targetGroup': 'vip', 'promotion.mode': 'force' },
    }),
  })
  const data = await readJson(res)
  assert.equal(data.status, 200, data.text)

  const pushes = calls.filter((c) => c.pathname === '/data/qq/snapshot')
  assert.ok(pushes.length >= 1, '配置变更后必须立即下发快照（否则要等对账周期，关闭时永远不生效）')
  assert.ok(data.data.snapshot, '响应应如实回显下发结果，不假装成功')

  // 晋升配置随快照下发：游戏服半据此在玩家登录时自动晋升
  const promo = JSON.parse(pushes[0].params.promotion)
  assert.equal(promo.enabled, true)
  assert.equal(promo.targetGroup, 'vip')
  assert.equal(promo.mode, 'force')
  assert.deepEqual(promo.ignoreGroups, ['owner', 'superadmin'], '忽略组默认保护 owner/superadmin')
})

test('终端命令 qqbind-import：导入旧台账、幂等、试运行不写入', async () => {
  assert.ok(terminalHandlers['qqbind-import'], '应注册 qqbind-import 终端命令')
  const handler = terminalHandlers['qqbind-import']

  const file = path.join(dataDir, 'legacy-qq_accounts.json')
  await writeFile(
    file,
    JSON.stringify({ records: { termguy: { qq: '70001', passwordHash: '$2y$term' } } }),
  )

  // 捕获终端输出（约定用 console.log 打印）
  const lines = []
  const origLog = console.log
  console.log = (...a) => lines.push(a.join(' '))
  try {
    // 试运行：不得写入台账
    lines.length = 0
    await handler([file, '--dry'])
    assert.match(lines.join('\n'), /试运行/)
    assert.match(lines.join('\n'), /新增 1/)
    assert.equal(svc.ledger.getByQq('70001'), null, '--dry 不得写入台账')

    // 正式导入
    lines.length = 0
    await handler([file])
    assert.match(lines.join('\n'), /新增 1/)
    assert.equal(svc.ledger.getByQq('70001').username, 'termguy')

    // 幂等：再导一次不应重复（同一 QQ/角色已存在 → 跳过）
    lines.length = 0
    await handler([file])
    assert.match(lines.join('\n'), /新增 0/, '重复导入必须幂等')
    assert.equal(svc.ledger.size, 1)

    // 用法提示
    lines.length = 0
    await handler([])
    assert.match(lines.join('\n'), /用法/)
  } finally {
    console.log = origLog
    // 收尾：清掉导入的记录，避免影响后续计数断言
    await svc.unbind({ username: 'termguy', source: 'test' })
  }
})

test('P6 端到端：先于本件加载的插件用 ctx.inject 注册的能力，旧路径立刻可用；无人提供的目录路径回 501', async () => {
  assert.equal(lateInject.ran, true, 'qqBind 服务出现后，晚注册的回调应已执行（加载顺序无关）')

  // 真实 HTTP + 真实适配器：旧机器人路径 /api/bot/servers 由 meta.legacy 投影而来
  const res = await fetch(`${base}/api/bot/servers?token=${TOKEN}`)
  assert.equal(res.status, 200, '能力注册后旧路径必须立刻可用')
  const data = await res.json()
  assert.equal(data.success, true)
  assert.deepEqual(data.servers, [{ id: 's1', name: '主服', enabled: true, note: '' }])

  // 目录里有（vote.list 归属投票类插件）但无人提供 → 501 + 指明该装哪个插件
  const missing = await fetch(`${base}/api/bot/votes?token=${TOKEN}`)
  assert.equal(missing.status, 501, '已知路径但无人提供能力 → 501，而不是 404 或空数据')
  const body = await missing.json()
  assert.equal(body.missingCapability, 'vote.list')
  assert.match(String(body.missingPlugin), /投票/)

  // 完全未知的路径仍 404
  const unknown = await fetch(`${base}/api/bot/not-a-real-command?token=${TOKEN}`)
  assert.equal(unknown.status, 404)
})

test('兜底对账：按配置周期补推，释放钩子能停下来', async () => {
  const set = await fetch(`${base}/api/qq-bind/config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path: 'snapshot.reconcileIntervalMs', value: 60 }),
  })
  assert.equal(set.status, 200)
  assert.equal(svc.startReconcile(), true, '配置变更后应立即按新周期重启对账')

  calls.length = 0
  await new Promise((r) => setTimeout(r, 220))
  const periodic = calls.filter((c) => c.pathname === '/data/qq/snapshot').length
  assert.ok(periodic > 0, `未看到兜底对账推送（实际 ${periodic}）`)

  // 0 = 关闭
  const off = await fetch(`${base}/api/qq-bind/config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path: 'snapshot.reconcileIntervalMs', value: 0 }),
  })
  assert.equal(off.status, 200)
  calls.length = 0
  await new Promise((r) => setTimeout(r, 150))
  assert.equal(calls.filter((c) => c.pathname === '/data/qq/snapshot').length, 0, '0 应关闭对账')

  // 释放钩子：即使定时器在跑也必须停下（否则插件卸载后仍在打游戏服）
  await fetch(`${base}/api/qq-bind/config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path: 'snapshot.reconcileIntervalMs', value: 60 }),
  })
  await new Promise((r) => setTimeout(r, 100))
  dispose()
  calls.length = 0
  await new Promise((r) => setTimeout(r, 200))
  assert.equal(calls.filter((c) => c.pathname === '/data/qq/snapshot').length, 0, '释放后不得再推送')
})
