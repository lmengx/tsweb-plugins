/**
 * qq-bind 配置（<dataDir>/qq-bind/config.json）
 *
 * 设计依据：docs/QQ绑定基础件设计.md §4.2
 *   - adapters 以适配器名为键：每个接入方式独立凭据，关掉一个不影响其它
 *   - 逐服能力开关放本件自己的配置里，不写进 servers 插件记录（避免插件间数据污染）
 *   - promotion 字段与旧版 PromotionConfig 对齐，便于迁移
 *
 * 读取顺序：文件 > 环境变量 > 默认值。写入只允许白名单路径（防越权改结构）。
 */
import { readFile, writeFile, mkdir, copyFile, rename } from 'node:fs/promises'
import path from 'node:path'

export const CONFIG_SCHEMA = 1

/** 默认配置（字段语义见设计 §4.2） */
export function defaultConfig() {
  return {
    schema: CONFIG_SCHEMA,
    adapters: {
      'legacy-http': {
        enabled: true,
        token: '',
        tokenRotatedAt: '',
        groupWhitelist: [],
        rateLimit: { perMinute: 60 },
      },
    },
    binding: {
      allowSelfRegister: true,
      requireOnlineForBind: false,
      defaultServerId: '',
    },
    snapshot: {
      pushOnChange: true,
      pushOnServerConnect: true,
      reconcileIntervalMs: 600000,
    },
    servers: {},
    promotion: {
      enabled: false,
      targetGroup: 'vip',
      mode: 'auto',
      ignoreGroups: ['owner', 'superadmin'],
    },
  }
}

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v)
}

/** 深合并：对象递归，数组整体替换（配置语义：给了就替换） */
export function mergeConfig(base, patch) {
  if (!isPlainObject(patch)) return base
  const out = Array.isArray(base) ? base.slice() : { ...base }
  for (const [k, v] of Object.entries(patch)) {
    if (v === undefined) continue
    if (isPlainObject(v) && isPlainObject(out[k])) out[k] = mergeConfig(out[k], v)
    else out[k] = v
  }
  return out
}

/** 环境变量覆盖：TSWEB_QQBIND_TOKEN（legacy-http 适配器的 token） */
export function applyEnv(cfg, env = process.env) {
  const out = mergeConfig(defaultConfig(), cfg)
  const token = env.TSWEB_QQBIND_TOKEN
  if (token != null && String(token) !== '') {
    out.adapters = out.adapters || {}
    out.adapters['legacy-http'] = { ...(out.adapters['legacy-http'] || {}), token: String(token) }
  }
  return normalizeConfig(out)
}

/** 类型归一与兜底（读到脏配置时不让它把功能静默关掉） */
export function normalizeConfig(cfg) {
  const out = mergeConfig(defaultConfig(), cfg)
  out.adapters = isPlainObject(out.adapters) ? out.adapters : {}
  const lh = isPlainObject(out.adapters['legacy-http']) ? out.adapters['legacy-http'] : {}
  out.adapters['legacy-http'] = {
    enabled: lh.enabled !== false,
    token: String(lh.token ?? ''),
    tokenRotatedAt: String(lh.tokenRotatedAt ?? ''),
    groupWhitelist: Array.isArray(lh.groupWhitelist) ? lh.groupWhitelist.map(String) : [],
    rateLimit: {
      perMinute: Math.max(0, Number(lh.rateLimit?.perMinute ?? 60) || 0),
    },
  }
  out.binding = {
    allowSelfRegister: out.binding?.allowSelfRegister !== false,
    requireOnlineForBind: out.binding?.requireOnlineForBind === true,
    defaultServerId: String(out.binding?.defaultServerId ?? ''),
  }
  const snap = out.snapshot || {}
  out.snapshot = {
    pushOnChange: snap.pushOnChange !== false,
    pushOnServerConnect: snap.pushOnServerConnect !== false,
    reconcileIntervalMs: Math.max(0, Number(snap.reconcileIntervalMs ?? 600000) || 0),
  }
  out.servers = isPlainObject(out.servers) ? out.servers : {}
  const promo = out.promotion || {}
  out.promotion = {
    enabled: promo.enabled === true, // 旧版 C# 默认 false（PromotionConfig.cs:29）
    targetGroup: String(promo.targetGroup || 'vip'),
    // 旧版只有 'auto' 有特殊语义，其它值一律按 force（PromotionConfig.cs:275、:328-333）
    mode: String(promo.mode || 'auto') === 'auto' ? 'auto' : String(promo.mode || 'force'),
    ignoreGroups: Array.isArray(promo.ignoreGroups) ? promo.ignoreGroups.map(String) : ['owner', 'superadmin'],
  }
  out.schema = CONFIG_SCHEMA
  return out
}

/** 逐服能力开关（缺省一律 false，与旧版每服默认一致） */
export function serverFlags(cfg, serverId) {
  const s = (cfg.servers || {})[String(serverId ?? '')] || {}
  return {
    syncAccounts: s.syncAccounts === true,
    syncUuid: s.syncUuid === true,
    kickDuplicate: s.kickDuplicate === true,
  }
}

/** 读配置：不存在 → 默认值；形状非法 → 抛错（不静默吞掉用户的配置） */
export async function loadConfig(file) {
  let raw
  try {
    raw = await readFile(file, 'utf8')
  } catch (err) {
    if (err.code === 'ENOENT') return { config: applyEnv(defaultConfig()), existed: false }
    throw err
  }
  let parsed
  try {
    parsed = JSON.parse(raw)
  } catch (err) {
    throw new Error(`配置文件不是合法 JSON：${file}（${err.message}）`)
  }
  return { config: applyEnv(parsed), existed: true }
}

/** 原子落盘（.tmp + rename，保留 .bak） */
export async function saveConfig(file, cfg) {
  const payload = JSON.stringify(normalizeConfig(cfg), null, 2)
  await mkdir(path.dirname(file), { recursive: true })
  const tmp = `${file}.tmp`
  await writeFile(tmp, payload, 'utf8')
  try {
    await copyFile(file, `${file}.bak`)
  } catch (err) {
    if (err.code !== 'ENOENT') throw err
  }
  await rename(tmp, file)
  return file
}

/**
 * 管理接口可写的路径白名单（值是校验器）。
 * 结构类字段（schema）不可写；token 只在适配器分组内可写。
 */
export const EDITABLE_PATHS = {
  'adapters.legacy-http.enabled': (v) => typeof v === 'boolean',
  'adapters.legacy-http.token': (v) => typeof v === 'string',
  'adapters.legacy-http.groupWhitelist': (v) => Array.isArray(v) && v.every((x) => typeof x === 'string'),
  'adapters.legacy-http.rateLimit.perMinute': (v) => Number.isFinite(Number(v)) && Number(v) >= 0,
  'binding.allowSelfRegister': (v) => typeof v === 'boolean',
  'binding.requireOnlineForBind': (v) => typeof v === 'boolean',
  'binding.defaultServerId': (v) => typeof v === 'string',
  'snapshot.pushOnChange': (v) => typeof v === 'boolean',
  'snapshot.pushOnServerConnect': (v) => typeof v === 'boolean',
  'snapshot.reconcileIntervalMs': (v) => Number.isFinite(Number(v)) && Number(v) >= 0,
  'promotion.enabled': (v) => typeof v === 'boolean',
  'promotion.targetGroup': (v) => typeof v === 'string' && v.trim() !== '',
  'promotion.mode': (v) => v === 'auto' || v === 'force',
  'promotion.ignoreGroups': (v) => Array.isArray(v) && v.every((x) => typeof x === 'string'),
}

/**
 * 按路径写值（仅白名单；类型不符即 400）。
 * 逐服开关单独支持：servers.<id>.{syncAccounts,syncUuid,kickDuplicate}
 */
export function setByPath(cfg, dottedPath, value) {
  const key = String(dottedPath || '').trim()
  if (!key) throw badRequest('缺少参数: path')

  const serverMatch = /^servers\.([^.]+)\.(syncAccounts|syncUuid|kickDuplicate)$/.exec(key)
  if (serverMatch) {
    if (typeof value !== 'boolean') throw badRequest(`${key} 需要布尔值`)
    const [, serverId, flag] = serverMatch
    cfg.servers = cfg.servers || {}
    cfg.servers[serverId] = { ...(cfg.servers[serverId] || {}), [flag]: value }
    return cfg
  }

  const validator = EDITABLE_PATHS[key]
  if (!validator) throw badRequest(`不可写的配置项：${key}`)
  if (!validator(value)) throw badRequest(`${key} 的值类型不合法`)

  const parts = key.split('.')
  let node = cfg
  for (const part of parts.slice(0, -1)) {
    if (!isPlainObject(node[part])) node[part] = {}
    node = node[part]
  }
  node[parts[parts.length - 1]] = value
  return cfg
}

function badRequest(message, extra = {}) {
  const err = new Error(message)
  err.status = 400
  Object.assign(err, extra)
  return err
}

/** 出口脱敏：token 只回显掩码，避免泄漏到前端与日志 */
export function redactConfig(cfg) {
  const out = JSON.parse(JSON.stringify(cfg))
  for (const [name, adapter] of Object.entries(out.adapters || {})) {
    if (isPlainObject(adapter) && typeof adapter.token === 'string' && adapter.token !== '') {
      const t = adapter.token
      adapter.token = `${t.slice(0, 3)}***${t.slice(-2)}（已设置，长度 ${t.length}）`
      adapter.tokenSet = true
    } else if (isPlainObject(adapter)) {
      adapter.tokenSet = false
      adapter.token = ''
    }
    out.adapters[name] = adapter
  }
  return out
}
