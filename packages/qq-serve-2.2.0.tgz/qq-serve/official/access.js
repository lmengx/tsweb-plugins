const actions = [
  ['qq-official.test', 'POST', '/api/qq-official/test'],
  ['qq-official.config.read', 'GET', '/api/qq-official/config'],
  ['qq-official.config.save', 'POST', '/api/qq-official/config'],
  ['qq-official.status', 'GET', '/api/qq-official/status'],
  ['qq-official.logs', 'GET', '/api/qq-official/logs'],
  ['qq-official.identity.read', 'GET', '/api/qq-official/identity'],
  ['qq-official.identity.save', 'POST', '/api/qq-official/identity'],
  ['qq-official.start', 'POST', '/api/qq-official/start'],
  ['qq-official.stop', 'POST', '/api/qq-official/stop'],
].map(([id, method, path]) => ({ id, method, path, module: 'qq-official.manage', scope: 'global' }))
export default {
  owner: 'qq-official', version: 2,
  modules: [{ id: 'qq-official.manage', permission: 'qq-official.manage', title: 'QQ 官方机器人管理',
    roles: ['superadmin'], scope: 'global', requires: actions.map(a => a.id) }],
  actions,
  features: [{ id: 'qq-official:manage', module: 'qq-official.manage', requires: actions.map(a => a.id) }],
}
