# qq-serve（统一 QQ 服务）

**一个插件提供全部 QQ 能力**：QQ 绑定台账与登录凭据、QQ 官方机器人、OneBot 11 接入、双端身份补全。
图片渲染是独立可选插件 `qq-render`（`requires: ["qq-serve"]`），未安装时自动回退文字回复。

合并历史：本插件吸收了原来的 `qq-bind`（台账/凭据/适配器注册表）、`qq-official`（官方机器人）、
`onebot-bridge`（OneBot 接入）三个独立插件。它们不再是独立安装包。

## 运行模式

模式只决定消息适配器，不决定数据表；三种模式共用同一份中心台账，切换模式不会清空、覆盖或重建绑定记录：

- `official`：启用 QQ 官方机器人，提供 Markdown、按钮和输入交互；台账只记录官方 OpenID，QQ 号可为空。
- `onebot`：启用 OneBot 11，使用真实 QQ 号作为身份源；OneBot 消息不提供官方卡片按钮交互。
- `hybrid`：官方机器人负责交互，OneBot 通过一次性“绑定转移”流程补全 QQ 号与昵称，并支持旧版 QQ 绑定迁移。

保存模式后自动启用对应适配器并应用配置，不需要启动第二个程序、不需要中转脚本或额外端口。

## 数据目录

所有状态都在**同一个** `data/qq-serve/` 下（不再按插件分目录）：

| 文件 | 内容 |
|---|---|
| `config.json` | 运行模式、官方 AppID/Secret、OneBot Endpoint/token/群映射/转移开关 |
| `bindings.json` | 绑定台账（唯一权威） |
| `audit.jsonl`、`nicknames.json` | 审计流水、QQ 昵称缓存 |
| `credential-channel.key` | 各服务器机器凭据派生密钥 |
| `bind-config.json`、`official-config.json`、`official-identity.json`、`onebot-config.json` | 各域自己的配置 |
| `official-credential-delivery.{json,key}`、`onebot-credential-delivery.{json,key}` | 待私信投递的初始密码（加密、按域隔离） |

接口只返回“是否已设置”，不返回密钥原文；源码、发行包、日志和本文档都不包含真实 Token。
生产安装必须包含宿主的 `ws` 依赖。

## 对外接口（前缀保持不变）

合并没有重命名任何路由，已有调用方与外部 OneBot 推送地址都不需要改：

- `/api/qq-serve/*`：模式、凭据、连接测试、渲染设置
- `/api/qq-bind/*`：台账查询与绑定管理（`base` 的玩家列表、`legacy-import` 的迁移在用）
- `/api/qq-official/*`：官方机器人配置、状态、日志、指令开关
- `/api/onebot-bridge/config|test`：OneBot 配置；`/api/onebot-bridge/webhook` 仍挂在原始 app 上，用机器令牌鉴权

权限契约合并为一份（owner `qq-serve`），但 `qq-bind:*`、`qq-official:*`、`qq-serve:*` 这些模块与功能 id
**原样保留**，既有管理员的模块授权不会失效。

cordis 服务名也不变：`ctx.qqBind`（台账/能力注册表，`servers`、`online-stats`、`vote`、`promotion` 在用）、
`ctx.qqServe`（模式与配置源）、`ctx.qqOfficial`、`ctx.onebotBridge`。

## 前端入口（唯一入口 /b/qq-serve）

侧栏只有「QQ 控制台」一个入口，全部配置都在它的页签里，且每项配置只有一处归属：

| 页签 | 内容 |
|---|---|
| 绑定列表（默认） | 完整台账查询、新增、详情编辑、解绑、绑定规则、审计、刷新昵称与游戏时长 |
| 渠道配置 | 运行模式；左栏选择官方机器人 / OneBot，右栏按连接认证 → 草稿测试与实际状态 → 消息行为 → 高级设置排序；官方连接断开、清除密钥、指令开关保持可用 |
| 身份协同 | 观测、辅助获取 QQ、旧用户自动转移、回写台账、触发时机与群映射确认策略、身份覆盖及连接总览 |
| 消息渲染 | qq-render 安装启用、三种图片风格、游戏连接地址、真实只读预览 |
| 运行日志 | 官方机器人事件、收信与回复诊断，每 3 秒刷新 |

两种渠道使用宿主浅色 / 深色主题变量；窄屏自动改为单列，渠道切换与主页面切换保留未保存草稿。
/b/qq-bind 与 /b/qq-official 继续保留直达路径。/b/qq-serve/classic 不恢复。

表格遵循宿主设计系统：本插件不再自带表头/内边距/悬停规则，只用宿主 `.tsweb-ui table`
与 `.table-scroll`，自己只补列宽助手（`.qs-col-flag`/`.qs-col-wide`）。


## 配置与凭据

运行模式统一在「渠道配置」切换，凭据在左栏对应渠道填写；每项配置仍只有一个编辑点。

切换前前端与后端用同一套规则检查所需配置：官方模式要求 AppID、AppSecret；OneBot 模式要求有效 Endpoint，
Token 按服务端认证设置填写；混合模式要求两者齐全。缺少配置时前端不提交、直接说明缺哪一项；后端 `validateMode`
同样拒绝，已选模式与台账保留。

官方凭据只有一个权威来源：`data/qq-serve/config.json` 的 `official` 与 `official-config.json` 互为镜像
（`POST /api/qq-official/config` 保存后会回写前者），任一处保存都会同步；**空 canonical 不再被当成“清空凭据”**
（旧实现会让只保存过官方页的部署在下次切换模式/重载时被无声断开）。

`group_openid` 来自官方机器人收到的群事件，不能用 QQ 群号计算。官方机器人接入目标群后，在群内发送
“@官方机器人 群信息”取得完整 `group_openid`；「渠道配置 → OneBot」的群映射每行填写“获取的group_openid=本群数字QQ群号”。

`POST /api/qq-serve/test` 仍在（管理员权限、不保存配置、不启停适配器、不发送消息）：验证官方令牌认证与
OneBot API 认证/QQ 号/在线状态。两个渠道均有独立「测试连接」按钮，读取当前未保存草稿，空密钥保留已保存值，修改草稿后丢弃旧测试结果。
官方界面使用 /api/qq-official/test（官方管理权限）；更换 AppID 时必须提供对应的新密钥，测试不会继承旧应用密钥。
测试不等同于实际连接；官方群消息权限以真实事件为准。保存与实际连接 / 断开仍是独立操作。
`/api/onebot-bridge/config|test` 保留给合并前的外部调用方，界面统一走 `/api/qq-serve/config`。


## OneBot 指令

- 群聊或私聊：菜单、服务器、在线 服务器名、注册 角色名、绑定 角色名、我的信息。
- 仅私聊：领取密码、改密码 新密码。群聊修改密码会提示转到私聊，不写入新密码。
- 初始密码为 6 位数字与小写字母，群里仅返回角色和私信通知。私信失败后注册仍有效，待领取密码加密保存，
  24 小时内仅原 QQ 可领取，修改密码后旧待领取密码自动失效。
- OneBot 提供的昵称仅用于显示；不会用昵称推测官方 OpenID。

## 身份补全与旧用户迁移

使用显式 `group_openid=数字群号` 映射；两种平台的消息 ID 不存在可计算的转换。从主菜单或“账号服务”打开
“绑定转移”二级菜单，每次打开生成新的 20 字符编码（5 分钟有效），点击“一键转移”自动发送 `/绑定转移 编码`。

官方端记录发起人 OpenID 与原群，OneBot 记录相同编码消息的真实 QQ 并核验群成员信息；两端都到达后一次写入
统一台账，允许任意到达顺序，单端到达不写入。时间字段只用于生成编码与有效期，不比较两端消息时间或消息哈希。

## 验证

```powershell
node --test plugins/qq-serve/test/*.test.mjs `
          plugins/qq-serve/bind/test/*.test.mjs `
          plugins/qq-serve/official/test/*.test.mjs `
          plugins/qq-serve/onebot/test/*.test.mjs
node --test plugins/qq-render/test/*.test.mjs
npm run check:access          # 合并契约与路由一致性
node scripts/build-client.mjs qq-serve
node scripts/pack-plugin.mjs qq-serve
```

`plugins/qq-serve/test/installation.test.mjs` 用真实宿主装载打出的 tgz，验证包内容只含运行所需、
三域服务同时就位、四类路由按合并契约鉴权、停用能释放管理器且重启用恢复。

自动业务测试使用本地 OneBot 模拟端，不向真实群和用户发送测试消息；官方凭据缺失时不得宣称官方平台
实际收发或真实跨机器人迁移已验收。
