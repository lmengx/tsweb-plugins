const actions = [
  ['config.read', 'GET', 'config'],
  ['config.save', 'POST', 'config'],
  ['players', 'GET', 'players'],
  ['kick', 'POST', 'kick'],
  ['refresh', 'POST', 'proxy/refresh'],
].map(([id, method, path]) => ({
  id: `risk-control.${id}`, method, path: `/api/risk-control/${path}`,
  module: 'risk-control.manage', scope: 'server',
}));
export default {
  owner: 'risk-control', version: 2,
  modules: [{ id: 'risk-control.manage', permission: 'risk-control.manage',
    title: '实时风控', roles: ['superadmin', 'admin', 'subadmin'], scope: 'server',
    requires: actions.map(a => a.id) }],
  actions,
  features: [{ id: 'risk-control:manage', module: 'risk-control.manage',
    requires: actions.map(a => a.id) }],
};
