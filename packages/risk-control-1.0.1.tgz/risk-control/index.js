const revision = new URL(import.meta.url).search;
const { default: access } = await import(`./access.js${revision}`);
export const name = 'risk-control';
export const inject = ['webServer', 'auth', 'servers', 'tshock'];
export function apply(ctx) {
  try {
    const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx);
    let disposed = false;
    ctx.on('dispose', () => { disposed = true; });
    const fail = (status, message) => Object.assign(new Error(message), { status });
    const route = (suffix, write = false, prepare = () => ({})) => async (req, res) => {
      try {
        if (disposed) throw fail(503, '实时风控插件已停用');
        const allowed = ctx.auth.filterServers(req.user, await ctx.servers.list()).filter(s => s.enabled !== false);
        const id = req.headers['x-server-id'] || req.query.serverId || req.body?.serverId;
        const server = allowed.find(s => s.id === (id || allowed[0]?.id));
        if (!server) throw fail(id ? 403 : 400, id ? '无权访问该服务器或服务器已停用' : '请先选择服务器');
        const raw = ctx.servers.getRaw(server.id);
        if (!raw || raw.enabled === false) throw fail(503, '目标服务器不可用');
        const params = prepare(req);
        const response = await ctx.tshock[write ? 'postFor' : 'fetchFor'](raw,
          '/data/risk-control/' + suffix, params, { timeoutMs: 12000 });
        if (disposed) throw fail(503, '实时风控插件已停用');
        const data = response.data, status = Number(data?.status || response.status);
        if (!response.ok || !data || !Number.isFinite(status) || status >= 400 || data.error) {
          throw fail([400, 409, 503].includes(status) ? status : 502,
            status === 404 ? '游戏服尚未加载 RiskControl.dll，请检查插件同步'
            : status === 401 || status === 403 ? '游戏服 token 缺少 tsweb.risk-control.manage 权限'
            : data?.error || '游戏服未确认操作，请重新读取状态核对');
        }
        if (write) console.info(`[risk-control] ${JSON.stringify({ actor: req.user.username, serverId: server.id,
          operation: suffix, revision: data.config?.revision, kicked: data.kicked, skipped: data.skipped, failed: data.failed })}`);
        if (!res.destroyed) res.json(data);
      } catch (err) {
        if (!res.headersSent && !res.destroyed) res.status(err.status || 502).json({ error: err.message });
      }
    };
    app.get('/api/risk-control/config', route('config'));
    app.get('/api/risk-control/players', route('players'));
    app.post('/api/risk-control/config', route('config/set', true, req => {
      if (typeof req.body?.revision !== 'string' || !req.body.revision ||
          !req.body.patch || typeof req.body.patch !== 'object' || Array.isArray(req.body.patch))
        throw fail(400, '缺少配置版本或修改内容');
      return { revision: req.body.revision, patch: JSON.stringify(req.body.patch) };
    }));
    app.post('/api/risk-control/kick', route('kick', true, req => {
      const { targets, confirmed, revision } = req.body || {};
      if (confirmed !== true || typeof revision !== 'string' || !revision || !Array.isArray(targets) || !targets.length ||
          targets.some(t => !['all', 'proxy', 'register-under-1h', 'playtime-under-1h', 'not-logged-in'].includes(t)))
        throw fail(400, '请先选择群体并确认踢出');
      return { targets: [...new Set(targets)].join(','), revision, confirmed: true };
    }));
    app.post('/api/risk-control/proxy/refresh', route('proxy/refresh', true));
  } catch (err) {
    console.error('[risk-control] 初始化失败：' + err.message);
    throw err;
  }
}
