// Cache raw game snapshots only. Authorization and QQ lookups still run per request.
export function createSnapshotCache({ ttlMs = 15000, now = Date.now } = {}) {
  const entries = new Map();
  return {
    async get(server, load, { fresh = false } = {}) {
      const key = JSON.stringify([server.host, server.port, server.token]);
      const previous = entries.get(server.id);
      if (fresh) {
        entries.delete(server.id);
        return load();
      }
      if (
        previous?.key === key &&
        (previous.pending || previous.expires > now())
      )
        return previous.promise;
      if (entries.size >= 128) entries.delete(entries.keys().next().value);
      const entry = { key, pending: true, expires: 0 };
      entry.promise = Promise.resolve()
        .then(load)
        .then(
          (value) => {
            entry.pending = false;
            entry.expires = now() + ttlMs;
            return value;
          },
          (error) => {
            if (entries.get(server.id) === entry) entries.delete(server.id);
            throw error;
          },
        );
      entries.set(server.id, entry);
      return entry.promise;
    },
    invalidate(id) {
      entries.delete(id);
    },
    clear() {
      entries.clear();
    },
  };
}
