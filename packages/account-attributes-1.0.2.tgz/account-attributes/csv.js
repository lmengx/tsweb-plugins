const columns = [
  ["serverName", "服务器"],
  ["username", "账号"],
  ["qq", "QQ"],
  ["group", "用户组"],
  ["registered", "注册时间"],
  ["lastAccess", "最后登录"],
  ["totalMinutes", "累计时长(分)"],
  ["recent7dMinutes", "近7天(分)"],
  ["recent14dMinutes", "近14天(分)"],
  ["recent30dMinutes", "近30天(分)"],
  ["activeDays7", "近7天活跃天数"],
  ["activeDays14", "近14天活跃天数"],
  ["activeDays30", "近30天活跃天数"],
  ["relGroupSize", "关联组大小"],
  ["attributes", "属性"],
];
export function csv(accounts, label = (k) => k) {
  const esc = (value) => {
    let s = String(value ?? "");
    if (/^[\s\uFEFF]*[=+@-]/.test(s) || /^[\t\r\n]/.test(s)) s = "'" + s;
    return /[",\r\n]/.test(s) ? '"' + s.replaceAll('"', '""') + '"' : s;
  };
  return (
    "\uFEFF" +
    [
      columns.map(([, title]) => esc(title)).join(","),
      ...accounts.map((a) =>
        columns
          .map(([key]) =>
            esc(
              key === "attributes"
                ? (a.attributes || []).map(label).join("|")
                : a[key],
            ),
          )
          .join(","),
      ),
    ].join("\r\n")
  );
}
