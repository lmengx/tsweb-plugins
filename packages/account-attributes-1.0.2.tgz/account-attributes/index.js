import { mkdir, appendFile } from "node:fs/promises";
import path from "node:path";
const revision = new URL(import.meta.url).search;
const [
  { default: access },
  { createQuery, fetchSnapshot },
  { fail, preview, execute, validateItems, validateDays },
  { csv },
  { createSnapshotCache },
] = await Promise.all([
  import(`./access.js${revision}`),
  import(`./query.js${revision}`),
  import(`./cleanup.js${revision}`),
  import(`./csv.js${revision}`),
  import(`./snapshots.js${revision}`),
]);
export const name = "account-attributes";
export const inject = ["webServer", "auth", "servers", "tshock", "paths"];
export function apply(ctx) {
  try {
    const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx);
    const controllers = new Set();
    let disposed = false,
      writeQueue = Promise.resolve();
    const busyServers = new Set();
    const snapshots = createSnapshotCache();
    const auditFile = path.join(ctx.paths.dataOf(name), "audit.jsonl");
    const record = (actor, operation, details) => {
      const next = writeQueue
        .catch(() => {})
        .then(async () => {
          await mkdir(path.dirname(auditFile), { recursive: true });
          await appendFile(
            auditFile,
            JSON.stringify({
              at: new Date().toISOString(),
              actor,
              operation,
              ...details,
            }) + "\n",
            { mode: 0o600 },
          );
        });
      writeQueue = next;
      return next;
    };
    ctx.on("dispose", () => {
      disposed = true;
      snapshots.clear();
      for (const c of controllers) c.abort();
    });
    const route = (operation) => async (req, res) => {
      const controller = new AbortController(),
        { signal } = controller;
      controllers.add(controller);
      const closed = () => {
        if (!res.writableFinished) controller.abort();
      };
      res.on("close", closed);
      const locks = [];
      const checkActive = () => {
        signal.throwIfAborted();
        if (disposed) throw fail(503, "账号属性插件已停用");
      };
      try {
        checkActive();
        const available = ctx.auth
          .filterServers(req.user, await ctx.servers.list())
          .filter((s) => s.enabled !== false);
        const requested = req.query.serverId;
        if (requested !== undefined && typeof requested !== "string")
          throw fail(400, "服务器参数无效");
        if (requested && !available.some((s) => s.id === requested))
          throw fail(403, "无权访问该服务器或服务器已停用");
        const targets = (
          requested ? available.filter((s) => s.id === requested) : available
        )
          .map((s) => ctx.servers.getRaw(s.id))
          .filter(Boolean);
        const authorize = async (id) => {
          checkActive();
          const user = await ctx.auth.authenticateToken(
            req.headers.authorization?.slice(7),
          );
          if (
            !ctx.auth.access.authorize(
              user,
              ctx.auth.access.action("account-attributes.execute"),
              id,
            ) ||
            !ctx.servers.getRaw(id) ||
            ctx.servers.getRaw(id).enabled === false
          )
            throw fail(403, "清理权限或服务器范围已失效");
        };
        const qqMap = async (names) => {
          let service;
          try {
            service =
              typeof ctx.get === "function" ? ctx.get("qqBind") : ctx.qqBind;
          } catch {
            /* optional service */
          }
          if (!service) throw fail(503, "QQ 绑定插件不可用");
          await service.ready;
          if (!service.ledger) throw fail(503, "QQ 台账尚未就绪");
          return service.qqMap(names);
        };
        const call = async (
          server,
          suffix,
          params,
          write = false,
          shared = false,
        ) => {
          if (disposed) throw fail(503, "账号属性插件已停用");
          if (!shared) checkActive();
          const response = await ctx.tshock[write ? "postFor" : "fetchFor"](
            server,
            "/data/account-attributes/" + suffix,
            params,
            { timeoutMs: 20000 },
          );
          if (disposed) throw fail(503, "账号属性插件已停用");
          if (!shared) checkActive();
          const data = response.data,
            status = Number(data?.status || response.status);
          if (!response.ok || status >= 400 || !data || data.error)
            throw fail(
              [400, 409, 503].includes(status) ? status : 502,
              status === 404
                ? "游戏服未启用账号属性 DLL，请检查插件同步"
                : status === 401 || status === 403
                  ? "游戏服令牌缺少账号属性读取或清理权限"
                  : data?.error || "游戏服响应无效",
            );
          return data;
        };
        const query = createQuery({
          targets,
          signal,
          getQqMap: qqMap,
          fetchPage: (s, p) => call(s, "attributes", p),
          loadSnapshot: (server) =>
            snapshots.get(
              server,
              () =>
                fetchSnapshot(server, (s, p) =>
                  call(s, "attributes", p, false, true),
                ),
              { fresh: operation !== "list" || req.query.refresh === "1" },
            ),
        });
        const audit = (event, details) =>
          record(req.user.username, event, details);
        let result;
        if (operation === "servers")
          result = {
            servers: available.map((s) => ({ id: s.id, name: s.name })),
          };
        else if (operation === "execute") {
          const days = validateDays(req.body?.days);
          const items = validateItems(
            req.body?.items,
            new Set(targets.map((s) => s.id)),
          );
          if (req.body?.confirmed !== true)
            throw fail(400, "请先确认清理选中的账号");
          for (const id of new Set(items.map((i) => i.serverId))) {
            if (busyServers.has(id))
              throw fail(409, "目标服已有清理任务，请完成后重新扫描");
          }
          for (const id of new Set(items.map((i) => i.serverId))) {
            busyServers.add(id);
            locks.push(id);
          }
          for (const id of locks) await authorize(id);
          await audit("purge.begin", {
            serverIds: locks,
            days,
            requested: items.length,
          });
          result = await execute({
            items,
            days,
            query,
            signal,
            authorize,
            audit,
            remove: async (row, inactive) => {
              // Read the live authoritative QQ record immediately before sending each deletion.
              const bindings = await qqMap([row.username]);
              if (
                Object.hasOwn(bindings, row.username) &&
                bindings[row.username]
              )
                throw fail(409, "已绑定 QQ（保护）");
              await authorize(row.serverId);
              snapshots.invalidate(row.serverId);
              try {
                return await call(
                  ctx.servers.getRaw(row.serverId),
                  "purge",
                  { username: row.username, id: row.id, days: inactive },
                  true,
                );
              } finally {
                // Also discard readers started while this deletion was in flight.
                snapshots.invalidate(row.serverId);
              }
            },
          });
          try {
            await audit("purge.complete", result);
          } catch (err) {
            result.auditError = [result.auditError, err.message]
              .filter(Boolean)
              .join("；");
          }
        } else if (operation === "preview") {
          result = await preview(query, req.query.days);
          await audit("purge.preview", {
            serverIds: targets.map((s) => s.id),
            candidates: result.total,
            days: result.inactiveDays,
          });
        } else if (operation === "meta") {
          const states = await Promise.all(
            targets.map(async (s) => {
              try {
                const data = await call(s, "attributes", { meta: "1" });
                return {
                  id: s.id,
                  name: s.name,
                  status: "ok",
                  error: "",
                  meta: data.meta,
                };
              } catch (err) {
                return {
                  id: s.id,
                  name: s.name,
                  status: "error",
                  error: err.message,
                };
              }
            }),
          );
          result = {
            meta: states.find((s) => s.meta)?.meta || null,
            servers: states,
          };
        } else {
          for (const key of ["minMinutes", "maxMinutes", "activeDays14Min"]) {
            if (
              req.query[key] !== undefined &&
              (!Number.isFinite(Number(req.query[key])) ||
                Number(req.query[key]) < 0)
            )
              throw fail(400, "筛选数值无效");
          }
          result =
            operation === "export"
              ? await query.getAllFiltered(req.query)
              : await query.aggregateAttributes(req.query);
          await audit(
            operation === "export" ? "attributes.export" : "attributes.view",
            {
              serverIds: targets.map((s) => s.id),
              total: result.total,
              servers: result.servers.map(({ id, status, error }) => ({
                id,
                status,
                error,
              })),
            },
          );
          if (operation === "export") {
            if (result.servers.some((s) => s.error))
              throw fail(
                502,
                "部分服务器读取失败，请刷新后重新导出，避免导出不完整结果",
              );
            // Host SDK speaks JSON; browser makes the CSV Blob without bypassing its auth lifecycle.
            result = {
              filename: `account-attributes-${new Date().toISOString().slice(0, 10)}.csv`,
              csv: csv(result.accounts, query.attrLabel),
            };
          }
        }
        checkActive();
        if (!res.destroyed) res.json(result);
      } catch (err) {
        if (!res.headersSent && !res.destroyed)
          res.status(err.status || 502).json({ error: err.message });
      } finally {
        for (const id of locks) busyServers.delete(id);
        controllers.delete(controller);
        res.off("close", closed);
      }
    };
    app.get("/api/account-attributes/servers", route("servers"));
    app.get("/api/account-attributes/attributes", route("list"));
    app.get("/api/account-attributes/meta", route("meta"));
    app.get("/api/account-attributes/export", route("export"));
    app.get("/api/account-attributes/purge/preview", route("preview"));
    app.post("/api/account-attributes/purge/execute", route("execute"));
  } catch (err) {
    console.error("[account-attributes] 初始化失败：" + err.message);
    throw err;
  }
}
