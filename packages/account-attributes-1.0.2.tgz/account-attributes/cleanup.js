export const fail = (status, message) =>
  Object.assign(new Error(message), { status });
export const keyOf = (s, u) => JSON.stringify([s, u]);
export function inactiveDays(lastAccess, today) {
  const parse = (value) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value || "")) return null;
    const ms = Date.parse(value + "T00:00:00Z");
    return Number.isFinite(ms) &&
      new Date(ms).toISOString().slice(0, 10) === value
      ? ms
      : null;
  };
  const a = parse(lastAccess),
    b = parse(today);
  return a === null || b === null ? null : Math.floor((b - a) / 86400000);
}
export function validateDays(value = 30) {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1 || n > 36500)
    throw fail(400, "未登录天数须为 1 至 36500 的整数");
  return n;
}
export async function preview(query, value) {
  const days = validateDays(value),
    data = await query.getAllFiltered({ attr: "alt" });
  if (!data.qqAvailable)
    throw fail(503, "无法核对 QQ 绑定，暂不能清理：" + data.qqError);
  const dates = new Map(data.servers.map((s) => [s.id, s.today]));
  const excluded = {
    adminGroup: 0,
    qqBound: 0,
    unknownLastAccess: 0,
    recentlyActive: 0,
  };
  const candidates = [];
  for (const a of data.accounts) {
    const gap = inactiveDays(a.lastAccess, dates.get(a.serverId));
    if (/admin|owner/i.test(a.group)) excluded.adminGroup++;
    else if (a.qq) excluded.qqBound++;
    else if (gap === null) excluded.unknownLastAccess++;
    else if (gap < days) excluded.recentlyActive++;
    else candidates.push({ ...a, inactiveDays: gap });
  }
  candidates.sort((a, b) => b.inactiveDays - a.inactiveDays);
  return {
    generatedAt: data.generatedAt,
    inactiveDays: days,
    servers: data.servers,
    scanned: data.accounts.length,
    total: candidates.length,
    candidates,
    excluded,
    limits: { maxExecuteItems: 500 },
    rule: {
      description: `判定为小号 且 最后登录距今 >= ${days} 天`,
      protectedGroups: "组名含 admin / owner 的管理组账号",
      qqBound: "已绑定 QQ 的账号",
      scope:
        "仅该账号所在服，只删 TShock 账号行；保留角色存档、封禁、QQ 绑定与后台账户",
      recheck: "面板端和游戏服端都会重新核对；当前在线的账号不会删除",
      note: "删除成员后关联组可能解散，剩余账号可能变为游客。名单变化不代表账号已删除。",
    },
  };
}
export function validateItems(items, allowed) {
  if (!Array.isArray(items) || !items.length || items.length > 500)
    throw fail(400, "每批须选择 1 至 500 个账号");
  const unique = new Map();
  for (const item of items) {
    if (typeof item?.serverId !== "string" || !allowed.has(item.serverId))
      throw fail(403, "批次包含无权访问或未启用的服务器");
    if (
      typeof item.username !== "string" ||
      !item.username.trim() ||
      item.username.length > 256
    )
      throw fail(400, "账号名无效");
    unique.set(keyOf(item.serverId, item.username), {
      serverId: item.serverId,
      username: item.username,
    });
  }
  return [...unique.values()];
}
export async function execute({
  items,
  days,
  query,
  remove,
  authorize,
  audit,
  signal,
}) {
  const fresh = await preview(query, days);
  const byKey = new Map(
    fresh.candidates.map((a) => [keyOf(a.serverId, a.username), a]),
  );
  const statuses = new Map(fresh.servers.map((s) => [s.id, s]));
  const deleted = [],
    skipped = [],
    stillPresent = [];
  let auditError = "";
  // Reserve all scopes before the first mutation, then check again before every account.
  for (const id of new Set(items.map((i) => i.serverId))) await authorize(id);
  const groups = new Map();
  for (const item of items) {
    if (!groups.has(item.serverId)) groups.set(item.serverId, []);
    groups.get(item.serverId).push(item);
  }
  await Promise.all(
    [...groups].map(async ([serverId, group]) => {
      for (const item of group) {
        let outcome,
          issued = false;
        try {
          if (auditError) throw fail(503, "审计写入失败，后续清理已停止");
          signal?.throwIfAborted();
          await authorize(serverId);
          const row = byKey.get(keyOf(serverId, item.username));
          if (!row)
            throw fail(
              409,
              statuses.get(serverId)?.error ||
                "复检未通过：账号不存在或已不再满足清理条件",
            );
          try {
            await audit("purge.attempt", { ...item, id: row.id });
          } catch (err) {
            auditError = err.message;
            throw fail(503, "审计写入失败，后续清理已停止");
          }
          if (auditError) throw fail(503, "审计写入失败，后续清理已停止");
          issued = true;
          const result = await remove(row, fresh.inactiveDays);
          if (
            result.deleted !== true ||
            result.username !== row.username ||
            result.id !== row.id
          )
            throw fail(502, "游戏服未确认删除，请重新扫描核对");
          outcome = { ...item, serverName: row.serverName, id: row.id };
          deleted.push(outcome);
        } catch (err) {
          const uncertain = issued && ![400, 403, 409].includes(err.status);
          outcome = {
            ...item,
            reason: uncertain
              ? `删除结果未确认，请重新扫描核对：${err.message}`
              : err.message,
            ...(uncertain ? { uncertain: true } : {}),
          };
          skipped.push(outcome);
        }
        try {
          await audit("purge.outcome", {
            ...outcome,
            deleted: !outcome.reason,
          });
        } catch (err) {
          auditError = err.message;
        }
      }
    }),
  );
  let verifyError = "";
  if (deleted.length) {
    try {
      const all = await query.getAllFiltered({});
      const errors = all.servers.filter(
        (s) => s.error && deleted.some((d) => d.serverId === s.id),
      );
      if (errors.length)
        verifyError = errors.map((s) => `${s.name}: ${s.error}`).join("；");
      const present = new Set(
        all.accounts.map((a) => keyOf(a.serverId, a.username)),
      );
      for (let i = deleted.length - 1; i >= 0; i--) {
        const d = deleted[i];
        if (present.has(keyOf(d.serverId, d.username))) {
          const row = { ...d, reason: "删除后复核仍存在，请检查游戏服日志" };
          stillPresent.push(row);
          skipped.push(row);
          deleted.splice(i, 1);
        }
      }
    } catch (err) {
      verifyError = err.message;
    }
  }
  return {
    executedAt: new Date().toISOString(),
    inactiveDays: fresh.inactiveDays,
    requested: items.length,
    deletedCount: deleted.length,
    skippedCount: skipped.length,
    deleted,
    skipped,
    stillPresent,
    verifyError,
    auditError,
  };
}
