// Account rules and the visual summary retain the legacy contract. Inputs are already authorized.
export async function fetchSnapshot(server, fetchPage, signal) {
  const PAGE_SIZE = 1000;
  const accounts = [],
    seen = new Set();
  let total = null,
    meta = null,
    today = null,
    snapshot;
  for (let page = 1; page <= 10000; page++) {
    signal?.throwIfAborted();
    const json = await fetchPage(server, {
      page,
      pageSize: PAGE_SIZE,
      ...(snapshot ? { snapshot } : { fresh: "1" }),
    });
    if (
      !Array.isArray(json.accounts) ||
      !Number.isSafeInteger(json.total) ||
      json.total < 0 ||
      (total !== null && total !== json.total) ||
      (snapshot && snapshot !== json.snapshot) ||
      !/^\d{4}-\d{2}-\d{2}$/.test(json.today || "")
    )
      throw new Error("账号快照不完整或正在变化，请刷新重试");
    total = json.total;
    meta = json.meta;
    today = json.today;
    snapshot = json.snapshot || snapshot;
    for (const a of json.accounts) {
      if (
        typeof a.username !== "string" ||
        !Number.isInteger(a.id) ||
        !Array.isArray(a.attributes) ||
        !Number.isFinite(a.totalMinutes) ||
        a.totalMinutes < 0 ||
        seen.has(a.id)
      )
        throw new Error("账号快照重复或字段无效，请刷新重试");
      seen.add(a.id);
      accounts.push(a);
    }
    if (accounts.length === total)
      return {
        accounts,
        total,
        meta,
        today,
        generatedAt: new Date().toISOString(),
      };
    if (!json.accounts.length || accounts.length > total)
      throw new Error("账号分页不完整，请刷新重试");
  }
  throw new Error("账号数量超出单次扫描范围");
}

export function createQuery({
  targets: authorizedServers,
  fetchPage,
  getQqMap,
  signal,
  loadSnapshot,
}) {
  /**
   * 拉取 + 合并 + 筛选 + 排序（不分页）——aggregateAttributes 与 getAllFiltered 的公共前段。
   * 只在这里访问各服插件一次，避免「每个输出页都重新拉全量」的放大。
   * @returns {Promise<{ generatedAt, servers, summary, filteredSummary, total, filtered }>}
   */
  async function collectFiltered(filters = {}) {
    const servers = authorizedServers;
    const { serverId } = filters;

    const targets = serverId
      ? servers.filter((s) => String(s.id) === String(serverId))
      : servers;
    const results = await Promise.allSettled(
      targets.map(async (s) => ({
        server: s,
        data: await (loadSnapshot
          ? loadSnapshot(s)
          : fetchSnapshot(s, fetchPage, signal)),
      })),
    );

    const serverInfo = [];
    const accounts = [];
    for (const r of results) {
      const s = targets[results.indexOf(r)];
      const data =
        r.status === "fulfilled"
          ? r.value.data
          : { error: r.reason?.message || "读取失败" };
      serverInfo.push({
        id: s.id,
        name: s.name,
        status: data.error ? "error" : "ok",
        error: data.error || "",
        total: data.error ? null : data.total || 0,
        today: data.today || "",
        meta: data.meta || null,
        generatedAt: data.generatedAt || "",
      });
      if (!data.error) {
        for (const acc of data.accounts || []) {
          accounts.push({
            ...acc,
            serverId: s.id,
            serverName: s.name,
          });
        }
      }
    }

    // 合并 QQ 绑定（后端台账，原始大小写 key）
    let bindings = {},
      qqAvailable = false,
      qqError = "";
    try {
      bindings = await getQqMap(accounts.map((a) => a.username));
      qqAvailable = true;
    } catch (err) {
      qqError = err.message;
    }
    for (const acc of accounts)
      acc.qq = Object.hasOwn(bindings, acc.username)
        ? bindings[acc.username] || ""
        : "";
    signal?.throwIfAborted();

    // ── 概览统计（基于全量聚合，与筛选无关；语义固定）──
    const summary = buildSummary(accounts);

    // ── 筛选 ──
    const {
      attr,
      keyword,
      minMinutes,
      maxMinutes,
      activeDays14Min,
      sortBy = "totalMinutes",
      sortDir = "desc",
    } = filters;
    let filtered = accounts;
    if (attr) {
      const attrSet = new Set(
        String(attr)
          .split(",")
          .map((a) => a.trim().toLowerCase())
          .filter(Boolean),
      );
      if (attrSet.has("__none__")) {
        // 前端"全不选"：不显示任何账号
        filtered = [];
      } else {
        const showNormal = attrSet.has("normal");
        filtered = filtered.filter((a) => {
          if (showNormal && a.primaryAttribute === "normal") return true;
          const attrs = a.attributes || [];
          if (attrs.length === 0) return showNormal; // 无属性标签账号 = 普通账号
          return attrs.some((x) => attrSet.has(x));
        });
      }
    }
    if (keyword) {
      const kw = String(keyword).toLowerCase();
      filtered = filtered.filter((a) =>
        String(a.username || "")
          .toLowerCase()
          .includes(kw),
      );
    }
    if (minMinutes != null && !Number.isNaN(Number(minMinutes))) {
      const m = Number(minMinutes);
      filtered = filtered.filter((a) => (a.totalMinutes || 0) >= m);
    }
    if (maxMinutes != null && !Number.isNaN(Number(maxMinutes))) {
      const m = Number(maxMinutes);
      filtered = filtered.filter((a) => (a.totalMinutes || 0) <= m);
    }
    if (activeDays14Min != null && !Number.isNaN(Number(activeDays14Min))) {
      const m = Number(activeDays14Min);
      filtered = filtered.filter((a) => (a.activeDays14 || 0) >= m);
    }

    // 筛选后分布（饼图/条形图数据：当前选中项目内各属性占比）
    //   byPrimary   主属性分布（互斥分区，饼图用）
    //   byAttribute 属性标签分布（可重叠，一个账号可命中多个属性，条形图用）
    const filteredSummary = {
      total: filtered.length,
      byPrimary: {},
      byAttribute: {},
    };
    for (const a of filtered) {
      const primary = a.primaryAttribute || "normal";
      filteredSummary.byPrimary[primary] =
        (filteredSummary.byPrimary[primary] || 0) + 1;
      for (const attr of a.attributes || []) {
        filteredSummary.byAttribute[attr] =
          (filteredSummary.byAttribute[attr] || 0) + 1;
      }
    }

    const getSortVal = (a) => {
      switch (sortBy) {
        case "lastAccess":
          return a.lastAccess || "";
        case "registered":
          return a.registered || "";
        case "activeDays14":
          return a.activeDays14 || 0;
        case "relGroupSize":
          return a.relGroupSize || 1;
        default:
          return a.totalMinutes || 0;
      }
    };
    filtered = [...filtered].sort((a, b) => {
      const va = getSortVal(a);
      const vb = getSortVal(b);
      let cmp = 0;
      if (typeof va === "string" && typeof vb === "string")
        cmp = va.localeCompare(vb);
      else cmp = va > vb ? 1 : va < vb ? -1 : 0;
      return sortDir === "asc" ? cmp : -cmp;
    });

    return {
      qqAvailable,
      qqError,
      generatedAt:
        serverInfo
          .map((s) => s.generatedAt)
          .filter(Boolean)
          .sort()[0] || new Date().toISOString(),
      servers: serverInfo,
      summary,
      filteredSummary,
      total: filtered.length,
      filtered,
    };
  }

  /**
   * 聚合全部启用服账号属性（分页视图）。
   * @param {object} filters { attr, keyword, minMinutes, maxMinutes, sortBy, sortDir, page, pageSize, serverId }
   * @returns 聚合结果：{ generatedAt, servers, summary, filteredSummary, total, page, pageSize, accounts }
   */
  async function aggregateAttributes(filters = {}) {
    const base = await collectFiltered(filters);
    const page = Math.max(1, parseInt(filters.page) || 1);
    const pageSize = Math.min(
      1000,
      Math.max(1, parseInt(filters.pageSize) || 100),
    );
    return {
      qqAvailable: base.qqAvailable,
      qqError: base.qqError,
      generatedAt: base.generatedAt,
      servers: base.servers,
      summary: base.summary,
      filteredSummary: base.filteredSummary,
      total: base.total,
      page,
      pageSize,
      accounts: base.filtered.slice((page - 1) * pageSize, page * pageSize),
    };
  }

  /**
   * 全量筛选结果（CSV 导出 / 小号清理扫描用，不受分页限制）。
   * 走 collectFiltered 直接拿未分页结果：既不会被 1000 的 pageSize 上限静默截断，
   * 也不会因为翻页而重复拉取各服。
   */
  async function getAllFiltered(filters = {}) {
    const base = await collectFiltered(filters);
    return {
      qqAvailable: base.qqAvailable,
      qqError: base.qqError,
      generatedAt: base.generatedAt,
      servers: base.servers,
      summary: base.summary,
      filteredSummary: base.filteredSummary,
      total: base.total,
      page: 1,
      pageSize: base.total,
      accounts: base.filtered,
    };
  }

  // ── 概览统计 ──

  const ATTR_LABELS = {
    alt: "小号",
    guest: "游客账号",
    churn: "流失玩家",
    new_active: "近期新增活跃",
    returning: "回流玩家",
    sustained: "持续活跃",
    dormant: "长期沉睡",
    high_risk_group: "高风险关联组",
    normal: "普通账号",
  };

  const ATTR_ORDER = [
    "alt",
    "guest",
    "churn",
    "dormant",
    "returning",
    "new_active",
    "sustained",
    "high_risk_group",
  ];

  function attrLabel(key) {
    return ATTR_LABELS[key] || key;
  }

  function attrList() {
    return ATTR_ORDER.map((k) => ({ key: k, label: ATTR_LABELS[k] }));
  }

  function buildSummary(accounts) {
    const byPrimary = {};
    const byAttribute = {};
    let total = accounts.length;
    let altGroupCount = 0; // 关联组总数（组大小 > 1）
    let highRiskGroupCount = 0; // 高风险组数（>= 3 账号）
    let qqBound = 0;
    let nonAltSum = 0; // 非小号账号累计时长（分）
    let nonAltCount = 0; // 非小号账号数

    const relGroups = new Map(); // serverId:groupIndex -> size

    for (const a of accounts) {
      const primary = a.primaryAttribute || "normal";
      byPrimary[primary] = (byPrimary[primary] || 0) + 1;

      const attrs = a.attributes || [];
      for (const attr of attrs) {
        byAttribute[attr] = (byAttribute[attr] || 0) + 1;
      }

      if (a.qq) qqBound++;

      // 排除小号（alt）后的实际平均游玩时长
      if (!attrs.includes("alt")) {
        nonAltSum += a.totalMinutes || 0;
        nonAltCount++;
      }

      if ((a.relGroupSize || 1) > 1) {
        const key = `${a.serverId}:${a.relGroupIndex}`;
        relGroups.set(key, a.relGroupSize || 0);
      }
    }
    for (const size of relGroups.values()) {
      altGroupCount++;
      if (size >= 3) highRiskGroupCount++;
    }

    // 实际玩家数：每个关联账号组合并为一个玩家（组内 size 个账号只算 1 人），无关联账号各算 1 人
    let actualPlayers = total;
    for (const size of relGroups.values()) {
      actualPlayers -= size - 1;
    }

    return {
      total,
      actualPlayers,
      qqBound,
      altGroupCount,
      highRiskGroupCount,
      avgMinutesExclAlt:
        nonAltCount > 0 ? Math.round(nonAltSum / nonAltCount) : 0,
      byPrimary,
      byAttribute,
    };
  }

  return { aggregateAttributes, getAllFiltered, attrLabel, attrList };
}
