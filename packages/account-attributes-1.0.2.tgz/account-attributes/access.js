const read = [
  ["list", "attributes"],
  ["servers", "servers"],
  ["meta", "meta"],
  ["export", "export"],
].map(([id, path]) => ({
  id: `account-attributes.${id}`,
  method: "GET",
  path: `/api/account-attributes/${path}`,
  module: "account-attributes.manage",
  scope: "server",
}));
const purge = [
  {
    id: "account-attributes.preview",
    method: "GET",
    path: "/api/account-attributes/purge/preview",
  },
  {
    id: "account-attributes.execute",
    method: "POST",
    path: "/api/account-attributes/purge/execute",
  },
].map((a) => ({ ...a, module: "account-attributes.manage", scope: "server" }));
export default {
  owner: "account-attributes",
  version: 2,
  modules: [
    {
      id: "account-attributes.manage",
      permission: "account-attributes.manage",
      title: "账号属性与小号清理",
      roles: ["superadmin", "admin", "subadmin"],
      scope: "server",
      requires: [...read, ...purge].map((a) => a.id),
    },
  ],
  actions: [...read, ...purge],
  features: [
    {
      id: "account-attributes:analysis",
      module: "account-attributes.manage",
      requires: read.map((a) => a.id),
    },
    {
      id: "account-attributes:cleanup",
      module: "account-attributes.manage",
      requires: [...read, ...purge].map((a) => a.id),
    },
  ],
};
