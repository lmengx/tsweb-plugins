// DLL deployment and lifecycle use the existing host registry.
export const name = 'connection-guard'
export function apply() {}
