# ConnectionGuard 连接防护

无前端 Cordis 插件，市场包名 `connection-guard`，游戏 DLL `ConnectionGuard.dll`。
沿用独立版 1.1.0 的挂起连接清理、入槽前限流、包头检查及临时 IP 封禁。

## 安装

通过市场安装并启用，宿主按分服范围同步，无页面、REST 接口或额外面板权限。
先移除手工投放的同名 DLL，避免重复加载。卸载仅释放当前实例持有的防护核心。

## 配置与边界

配置仍位于游戏服 `tshock/ConnectionGuard/connection-guard.json`；首次加载生成默认配置。
默认每 IP 每 5 秒 10 次连接、全局每 5 秒 200 次；非法包头来源临时封禁 60 秒。
回环/白名单免限流与封禁，仍拦截非法包头。TCP 半包不按坏包处理，日志按周期汇总。
主动恢复监听继续禁用，即使旧配置 restoreListening=true 也不重启 accept 循环。
仅验证帧结构，合法包头下的恶意负载与高强度流量仍需其他防护。

未部署到真实游戏服；回归为实际源码与替身宿主，不代表压力验收。
回归：`dotnet run --project plugins/connection-guard/test/Regression.csproj -c Release`。
