/* TSWeb 在线统计客户端插件（online-stats 的前端半）
 *
 * 依赖宿主能力（window.tsweb，由 web 插件提供）：
 *   - window.tsweb.registerView({ id, title, section, path, render })
 *   - window.tsweb.api(path, opts)   带 Bearer 的统一请求：{ ok, status, data }
 *
 * 页面：#/b/online-stats（后端设置 → 在线统计）
 *   - 当前在线：全部已登记服务器在线人数 / 上限（后端聚合 total）
 *   - 24h 趋势：内联 SVG 折线图（多服合计，鼠标悬停显示数值与时间）
 *   - 在线玩家：当前在线玩家明细（昵称 / 账号 / 组 / 所在服）
 *   - 单玩家查询：输入用户名查看在线状态 / 最近活跃 / 采集出现次数
 *
 * 约定：禁止 emoji；图标用内联 SVG / 纯文字；不引入图表库（宿主无框架原则）。
 */
(function () {
  'use strict'

  var tsw = window.tsweb
  if (!tsw) return

  // ═══════════ 工具 ═══════════
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    })
  }

  function api(path, opts) {
    return tsw.api(path, opts)
  }

  /** 日期时间：MM-DD HH:MM */
  function fmtDateTime(t) {
    if (!t) return '-'
    var d = new Date(t)
    function pad(n) { return (n < 10 ? '0' : '') + n }
    return pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes())
  }

  var root = null

  function $(id) {
    return root ? root.querySelector('#' + id) : null
  }

  function setMsg(text, cls) {
    var el = $('os-msg')
    if (!el) return
    el.className = cls || 'muted'
    el.textContent = text || ''
  }

  // ═══════════ SVG 折线图 ═══════════
  // 纯内联 SVG：不引入任何图表库。输入 points=[{t,n}]（n 为 null 表示断点），输出 svg 字符串。
  // 超过 MAX_POINTS 时按窗口降采样（每窗口取最后一个有效值），避免 7 天（~10080 点）渲染卡顿。
  var MAX_POINTS = 400

  function sparklineSvg(points, w, h) {
    w = w || 760
    h = h || 160
    var padL = 34, padR = 8, padT = 8, padB = 20
    var innerW = w - padL - padR
    var innerH = h - padT - padB

    // ── 降采样 ──
    if (points.length > MAX_POINTS) {
      var step = Math.ceil(points.length / MAX_POINTS)
      var ds = []
      for (var si = 0; si < points.length; si += step) {
        var slice = points.slice(si, si + step)
        var last = null
        for (var sj = slice.length - 1; sj >= 0; sj--) {
          if (slice[sj].n !== null && slice[sj].n !== undefined) { last = slice[sj]; break }
        }
        if (last) ds.push(last)
        else if (slice.length) ds.push(slice[slice.length - 1]) // 全断点：保留末点（n=null）
      }
      points = ds
    }

    var nums = points.filter(function (p) { return p.n !== null && p.n !== undefined })
    var t0 = points.length ? points[0].t : Date.now() - 3600 * 1000
    var t1 = points.length ? points[points.length - 1].t : Date.now()
    if (t1 === t0) t1 = t0 + 1
    var maxN = 1
    for (var i = 0; i < nums.length; i++) { if (nums[i].n > maxN) maxN = nums[i].n }
    maxN = Math.max(1, Math.ceil(maxN * 1.1))

    var x = function (t) { return padL + ((t - t0) / (t1 - t0)) * innerW }
    var y = function (n) { return padT + innerH - (n / maxN) * innerH }

    // 网格线 + Y 轴刻度（4 条）
    var grid = ''
    for (var g = 0; g <= 4; g++) {
      var gy = padT + innerH - (g / 4) * innerH
      var gv = Math.round((maxN * g) / 4)
      grid += '<line x1="' + padL + '" y1="' + gy + '" x2="' + (w - padR) + '" y2="' + gy + '" stroke="#333" stroke-width="1" stroke-dasharray="2 3"/>'
      grid += '<text x="' + (padL - 6) + '" y="' + (gy + 3) + '" text-anchor="end" font-size="10" fill="#888">' + gv + '</text>'
    }

    // 折线：分段（null 断点断开）
    var path = ''
    var started = false
    for (var i2 = 0; i2 < points.length; i2++) {
      var p = points[i2]
      if (p.n === null || p.n === undefined) {
        started = false
        continue
      }
      var px = x(p.t).toFixed(1)
      var py = y(p.n).toFixed(1)
      if (!started) {
        path += 'M' + px + ' ' + py
        started = true
      } else {
        path += 'L' + px + ' ' + py
      }
    }

    // X 轴 4 个时间刻度（跨天显示日期）
    var xLabels = ''
    for (var xg = 0; xg <= 4; xg++) {
      var xt = t0 + ((t1 - t0) * xg) / 4
      xLabels += '<text x="' + x(xt).toFixed(1) + '" y="' + (h - 5) + '" text-anchor="middle" font-size="10" fill="#888">' + fmtAxisTime(xt, t0, t1) + '</text>'
    }

    // 悬停数据点（title 提示）
    var dots = ''
    for (var i3 = 0; i3 < nums.length; i3++) {
      var np = nums[i3]
      dots += '<circle cx="' + x(np.t).toFixed(1) + '" cy="' + y(np.n).toFixed(1) + '" r="2.2" fill="#4a9eff">' +
        '<title>' + fmtDateTime(np.t) + '  在线 ' + np.n + '</title></circle>'
    }

    return '<svg viewBox="0 0 ' + w + ' ' + h + '" style="width:100%;height:auto;display:block" role="img">' +
      '<rect x="0" y="0" width="' + w + '" height="' + h + '" fill="#16181d"/>' +
      grid + xLabels +
      (path ? '<path d="' + path + '" fill="none" stroke="#4a9eff" stroke-width="1.6" stroke-linejoin="round"/>' : '') +
      dots +
      '<text x="' + (w - padR) + '" y="' + (padT + 10) + '" text-anchor="end" font-size="10" fill="#4a9eff">在线人数</text>' +
      '</svg>'
  }

  /** 时间轴刻度：跨度跨天时显示日期+时间，否则仅时间 */
  function fmtAxisTime(t, t0, t1) {
    var spanMs = t1 - t0
    var d = new Date(t)
    function pad(n) { return (n < 10 ? '0' : '') + n }
    var hm = pad(d.getHours()) + ':' + pad(d.getMinutes())
    return spanMs > 24 * 3600 * 1000 ? (pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + hm) : hm
  }

  // ═══════════ 视图渲染 ═══════════
  function renderShell(container) {
    container.innerHTML = '' +
      '<div class="toolbar">' +
      '  <h2 style="margin:0">在线统计</h2>' +
      '  <div class="spacer"></div>' +
      '  <button id="os-refresh" class="ghost sm">刷新</button>' +
      '</div>' +
      '<p id="os-msg" class="muted" style="min-height:18px"></p>' +

      // 当前在线
      '<div class="panel" style="margin-bottom:16px">' +
      '  <h3>当前在线 <span id="os-total" class="badge"></span></h3>' +
      '  <table>' +
      '    <thead><tr><th>服务器</th><th>在线 / 上限</th><th>连接状态</th><th>采集时间</th></tr></thead>' +
      '    <tbody id="os-servers"></tbody>' +
      '  </table>' +
      '</div>' +

      // 趋势
      '<div class="panel" style="margin-bottom:16px">' +
      '  <div class="toolbar">' +
      '    <h3 style="margin:0">历史趋势</h3>' +
      '    <div class="spacer"></div>' +
      '    <select id="os-hours" class="sm">' +
      '      <option value="1">近 1 小时</option>' +
      '      <option value="6">近 6 小时</option>' +
      '      <option value="24" selected>近 24 小时</option>' +
      '      <option value="72">近 3 天</option>' +
      '      <option value="168">近 7 天</option>' +
      '    </select>' +
      '  </div>' +
      '  <div id="os-chart" style="margin-top:10px"></div>' +
      '  <p id="os-chart-meta" class="muted" style="font-size:13px;margin-top:8px"></p>' +
      '</div>' +

      // 在线玩家
      '<div class="panel" style="margin-bottom:16px">' +
      '  <h3>在线玩家 <span id="os-players-count" class="badge"></span></h3>' +
      '  <table>' +
      '    <thead><tr><th>昵称</th><th>账号</th><th>组</th><th>服务器</th></tr></thead>' +
      '    <tbody id="os-players"></tbody>' +
      '  </table>' +
      '</div>' +

      // 单玩家查询
      '<div class="panel">' +
      '  <h3>单玩家查询</h3>' +
      '  <div style="display:flex;gap:8px;align-items:center;margin-top:8px">' +
      '    <input id="os-player-input" type="text" placeholder="输入用户名或昵称" style="flex:1;max-width:320px"/>' +
      '    <button id="os-player-query" class="ghost sm">查询</button>' +
      '  </div>' +
      '  <div id="os-player-result" class="muted" style="font-size:13px;line-height:1.8;margin-top:10px"></div>' +
      '</div>'
  }

  // ── 当前在线表 ──
  function renderServers(data) {
    var tbody = $('os-servers')
    var total = $('os-total')
    if (!tbody) return
    var list = data.servers || []
    if (total) {
      total.textContent = '合计 ' + (data.total != null ? data.total : '-') + ' 人'
      total.className = 'badge'
    }
    if (!list.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="muted">尚未配置任何服务器</td></tr>'
      return
    }
    tbody.innerHTML = list.map(function (s) {
      var online = s.playercount != null ? s.playercount : '-'
      var max = s.maxplayers != null ? s.maxplayers : '-'
      var st = s.connected ? '<span class="ok">已连接</span>' : '<span class="muted">' + esc(s.status || '未连接') + '</span>'
      return '<tr>' +
        '<td>' + esc(s.name) + '</td>' +
        '<td>' + online + ' / ' + max + '</td>' +
        '<td>' + st + '</td>' +
        '<td class="muted">' + fmtDateTime(s.fetchedAt) + '</td>' +
        '</tr>'
    }).join('')
  }

  // ── 趋势图 ──
  function renderTrend(data) {
    var chart = $('os-chart')
    var meta = $('os-chart-meta')
    if (!chart) return
    var points = data.points || []
    if (!points.length) {
      chart.innerHTML = '<p class="muted" style="padding:24px 0;text-align:center">暂无趋势数据（等待采集）</p>'
      if (meta) meta.textContent = ''
      return
    }
    chart.innerHTML = sparklineSvg(points, 760, 160)
    if (meta) {
      meta.textContent = '峰值 ' + (data.max != null ? data.max : '-') + ' 人 · 平均 ' + (data.avg != null ? data.avg : '-') + ' 人 · ' + points.length + ' 个采样点'
    }
  }

  // ── 在线玩家表 ──
  function renderPlayers(data) {
    var tbody = $('os-players')
    var count = $('os-players-count')
    if (!tbody) return
    var list = data.players || []
    if (count) { count.textContent = list.length + ' 人'; count.className = 'badge' }
    if (!list.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="muted">当前没有在线玩家</td></tr>'
      return
    }
    tbody.innerHTML = list.map(function (p) {
      return '<tr>' +
        '<td>' + esc(p.nickname || '-') + '</td>' +
        '<td>' + esc(p.username || '-') + '</td>' +
        '<td>' + esc(p.group || '-') + '</td>' +
        '<td>' + esc(p.serverName || p.serverId || '-') + '</td>' +
        '</tr>'
    }).join('')
  }

  // ── 单玩家结果 ──
  function renderPlayerResult(d) {
    var el = $('os-player-result')
    if (!el) return
    if (d.error) {
      el.innerHTML = '<span class="error">' + esc(d.error) + '</span>'
      return
    }
    var lines = []
    lines.push('玩家：<b>' + esc(d.username) + '</b>')
    if (d.online) {
      lines.push('状态：<span class="ok">在线</span>（' + esc(d.currentServer ? (d.currentServer.name || d.currentServer.id) : '未知服务器') + (d.currentGroup ? ' · 组 ' + esc(d.currentGroup) : '') + '）')
    } else {
      lines.push('状态：<span class="muted">离线</span>')
    }
    lines.push('最近活跃：' + fmtDateTime(d.lastSeen))
    lines.push('采集出现次数：' + (d.totalTicks || 0))
    if (d.sessions && d.sessions.length) {
      lines.push('分服记录：')
      d.sessions.forEach(function (s) {
        lines.push('  · ' + esc(s.serverName || s.serverId) + '：首次 ' + fmtDateTime(s.firstSeen) + '，最近 ' + fmtDateTime(s.lastSeen) + '，' + (s.totalTicks || 0) + ' 次')
      })
    }
    el.innerHTML = lines.join('<br>')
  }

  // ── 数据加载 ──
  var loading = false

  async function loadAll() {
    if (loading) return
    loading = true
    setMsg('正在加载 ...', 'muted')
    try {
      var hours = Number(($('os-hours') && $('os-hours').value) || 24)
      var results = await Promise.all([
        api('/api/online-stats/current'),
        api('/api/online-stats/trend?hours=' + hours),
        api('/api/online-stats/players'),
      ])
      var cur = results[0], trend = results[1], players = results[2]
      if (cur.ok && cur.data) renderServers(cur.data)
      else setMsg('当前在线获取失败：' + ((cur.data && cur.data.error) || ('HTTP ' + cur.status)), 'error')
      if (trend.ok && trend.data) renderTrend(trend.data)
      if (players.ok && players.data) renderPlayers(players.data)
      setMsg('')
    } catch (err) {
      setMsg('加载失败：' + (err.message || err), 'error')
    } finally {
      loading = false
    }
  }

  async function queryPlayer() {
    var input = $('os-player-input')
    var username = input ? String(input.value || '').trim() : ''
    var el = $('os-player-result')
    if (!username) {
      if (el) el.innerHTML = '<span class="muted">请输入用户名或昵称</span>'
      return
    }
    if (el) el.innerHTML = '查询中 ...'
    try {
      var res = await api('/api/online-stats/player?username=' + encodeURIComponent(username))
      if (res.ok && res.data) renderPlayerResult(res.data)
      else renderPlayerResult({ error: (res.data && res.data.error) || ('HTTP ' + res.status) })
    } catch (err) {
      renderPlayerResult({ error: err.message || String(err) })
    }
  }

  // ═══════════ 视图注册 ═══════════
  tsw.registerView({
    id: 'online-stats',
    title: '在线统计',
    section: '后端设置',
    path: '/b/online-stats',
    render: function (container) {
      root = container
      renderShell(container)
      var refresh = $('os-refresh')
      if (refresh) refresh.addEventListener('click', loadAll)
      var hours = $('os-hours')
      if (hours) hours.addEventListener('change', loadAll)
      var qbtn = $('os-player-query')
      if (qbtn) qbtn.addEventListener('click', queryPlayer)
      var qinput = $('os-player-input')
      if (qinput) qinput.addEventListener('keydown', function (e) { if (e.key === 'Enter') queryPlayer() })
      loadAll()
    },
  })

  // ═══════════ 玩家详情页扩展点（可选接入）══════════════
  // 若宿主/players 已实现 window.tsweb.registerPlayerDetailSection（设计文档 3.2 节），
  // 则注册一个"在线统计"区块；未实现时无感跳过（详情页不出现该区块）。
  if (typeof tsw.registerPlayerDetailSection === 'function') {
    tsw.registerPlayerDetailSection({
      id: 'online-stats',
      title: '在线统计',
      order: 5,
      render: function (container, account) {
        var username = account && (account.Username || account.username)
        if (!username) {
          container.innerHTML = '<p class="muted">缺少账号名，无法查询</p>'
          return function () {}
        }
        var holder = document.createElement('div')
        container.appendChild(holder)
        holder.innerHTML = '查询中 ...'
        var cancelled = false
        api('/api/online-stats/player?username=' + encodeURIComponent(username))
          .then(function (res) {
            if (cancelled) return
            if (!res.ok || !res.data) {
              holder.innerHTML = '<p class="error">查询失败：' + esc((res.data && res.data.error) || ('HTTP ' + res.status)) + '</p>'
              return
            }
            var d = res.data
            var html = '<p class="muted" style="font-size:13px;line-height:1.8;margin:0">'
            if (d.online) html += '状态：<b class="ok">在线</b>'
            else html += '状态：<span class="muted">离线</span>'
            html += ' · 最近活跃：' + fmtDateTime(d.lastSeen) + ' · 采集出现 ' + (d.totalTicks || 0) + ' 次'
            html += '</p>'
            holder.innerHTML = html
          })
          .catch(function (err) {
            if (!cancelled) holder.innerHTML = '<p class="error">查询失败：' + esc(err.message || err) + '</p>'
          })
        return function () { cancelled = true }
      },
    })
  }
})()
