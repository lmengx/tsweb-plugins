/**
 * 在线统计插件（online-stats）
 *
 * 职责：
 *   - 周期采集全部已登记服务器的在线人数（TShock REST /v2/server/status → playercount），
 *     写入内存环形缓冲（默认 24h × 60s = 1440 点/服），并持久化到 <dataDir>/online-stats/trends.json
 *   - 提供 REST 端点（全部 verifyAuth + requireAdmin）：
 *       GET /api/online-stats/current         当前在线（单服或多服聚合）
 *       GET /api/online-stats/trend?hours=24  历史趋势（单服或全部）
 *       GET /api/online-stats/players         当前在线玩家列表
 *       GET /api/online-stats/player?username= 单玩家统计（第一版：基于采集快照的近似统计）
 *
 * 对外服务（ctx.onlineStats，其他插件可 inject: ['onlineStats'] 依赖调用）：
 *   - getCurrent(serverId?)      → { servers: [{id,name,playercount,maxplayers,...}], total, fetchedAt }
 *   - getTrend(serverId?, hours) → { points: [{t,n}], max, avg, perServer?, serverId? }
 *   - getPlayers(serverId?)      → { players: [...], serverId? }
 *   - getPlayerStats(serverId?, username) → 单玩家统计（online/offline/lastSeen/totalTicks/...）
 *   - getServers()               → 已登记服务器摘要（id/name/enabled/status/在线数）
 *   - on(event, handler)         → 事件订阅：'tick'（每轮采集完成）、'change'（某服在线数变化）
 *   - on() 返回取消函数；事件仅在同一进程内有效（不跨进程广播）
 *
 * 依赖：webServer / auth / servers / tshock / paths（全部由宿主或基础插件提供）
 * 约定：禁止 emoji；状态数据走 ctx.paths.dataOf('online-stats')（不在插件目录内）
 */
import { Service } from '@deepseek-ai/cordis'
import { readFile, writeFile, mkdir } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'online-stats'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths']

const __dirname = path.dirname(fileURLToPath(import.meta.url))

/** 默认采集间隔（毫秒）：60s 一采样，24h 共 1440 点/服 */
const DEFAULT_INTERVAL_MS = 60_000
/** 环形缓冲保留时长（毫秒）：24h */
const DEFAULT_KEEP_MS = 24 * 60 * 60 * 1000
/** 单玩家在线快照保留时长：48h */
const SESSION_KEEP_MS = 48 * 60 * 60 * 1000

/** 采集结果缓存有效期：getCurrent 直接问询太频繁会打服务器，缓存 30s */
const CURRENT_CACHE_MS = 30_000

class OnlineStatsService extends Service {
  constructor(ctx, options = {}) {
    super(ctx, 'onlineStats')
    this.servers = null      // 由 apply 注入（ServerRegistryService）
    this.tshock = null       // 由 apply 注入（TshockService）
    this.dataFile = null     // 由 apply 注入（<dataDir>/online-stats/trends.json）

    this.intervalMs = Number(options.intervalMs) || DEFAULT_INTERVAL_MS
    this.keepMs = Number(options.keepMs) || DEFAULT_KEEP_MS

    /** serverId -> [{ t, n }]（t=毫秒时间戳，n=在线数），按时间升序 */
    this.buffer = new Map()
    /** serverId -> { playercount, maxplayers, name, fetchedAt, players } 最近一次采集快照（含在线玩家明细） */
    this.snapshots = new Map()
    /** serverId -> { playercount, fetchedAt } getCurrent 的短缓存 */
    this.currentCache = new Map()
    /** username -> { lastSeen, firstSeen, totalTicks, currentServer } 单玩家统计（采集快照近似） */
    this.playerSessions = new Map()

    /** 采集定时器 / 运行状态 */
    this._timer = null
    this._running = false
    this._lastTickAt = 0
    this._tickSeq = 0
    /** 事件订阅：eventName -> Set<handler> */
    this._listeners = new Map()
  }

  // ═════════════ 事件订阅（供其他插件响应式使用）═════════════

  /**
   * 订阅事件。返回取消函数。
   * 事件：
   *   'tick'   → 每轮采集完成：({ tickSeq, at, servers: [{id,name,playercount}], total })
   *   'change' → 某服在线数与上次采集不同：({ serverId, name, prev, cur, at })
   */
  on(event, handler) {
    if (typeof handler !== 'function') return () => {}
    let set = this._listeners.get(event)
    if (!set) {
      set = new Set()
      this._listeners.set(event, set)
    }
    set.add(handler)
    return () => { set.delete(handler) }
  }

  _emit(event, payload) {
    const set = this._listeners.get(event)
    if (!set || set.size === 0) return
    for (const handler of set) {
      try { handler(payload) } catch (err) { console.error('[online-stats] 事件处理异常:', err.message) }
    }
  }

  // ═════════════ 对外数据接口（其他插件 inject 调用）═════════════

  /** 服务器摘要（含当前在线数缓存） */
  async getServers() {
    const list = await this.servers.list()
    return list.map((s) => {
      const snap = this.snapshots.get(s.id)
      const cache = this.currentCache.get(s.id)
      return {
        id: s.id,
        name: s.name,
        host: s.host,
        port: s.port,
        enabled: s.enabled !== false,
        status: s.status || 'unknown',
        connected: !!s.connected, // 注意：servers.list() sanitize 字段是 connected（非 isConnected）
        playercount: snap ? snap.playercount : (cache ? cache.playercount : null),
        maxplayers: snap ? snap.maxplayers : null,
        fetchedAt: snap ? snap.fetchedAt : (cache ? cache.fetchedAt : 0),
      }
    })
  }

  /** 当前在线：单服或多服聚合。serverId 缺省 = 全部 enabled 服务器合计 */
  async getCurrent(serverId) {
    const list = await this.servers.list()
    const enabled = list.filter((s) => s.enabled !== false)
    const targets = serverId
      ? enabled.filter((s) => s.id === serverId)
      : enabled
    if (serverId && targets.length === 0) {
      const err = new Error('目标服务器不存在或未启用')
      err.status = 404
      throw err
    }

    const now = Date.now()
    const servers = []
    let total = 0
    for (const s of targets) {
      const live = await this._fetchCurrent(s)
      servers.push({
        id: s.id,
        name: live.ok ? live.name : s.name,
        playercount: live.ok ? live.playercount : null,
        maxplayers: live.ok ? live.maxplayers : null,
        status: s.status || 'unknown',
        connected: !!s.connected,
        error: live.ok ? undefined : live.error,
        fetchedAt: live.ok ? live.fetchedAt : 0,
      })
      if (live.ok) total += live.playercount
    }
    return {
      servers,
      total,
      fetchedAt: now,
      serverId: serverId || undefined,
    }
  }

  /** 历史趋势：points 按时间升序。serverId 缺省 = 全部（perServer 逐服序列 + 合计 max/avg） */
  async getTrend(serverId, hours = 24) {
    // 归一化 hours（1h ~ 7d），供其他插件直接调用时也受保护
    hours = Math.min(Math.max(Number(hours) || 24, 1), 168)
    const since = Date.now() - hours * 60 * 60 * 1000
    const list = await this.servers.list()
    const enabled = list.filter((s) => s.enabled !== false)
    const targets = serverId ? enabled.filter((s) => s.id === serverId) : enabled

    if (serverId && targets.length === 0) {
      const err = new Error('目标服务器不存在或未启用')
      err.status = 404
      throw err
    }

    // 单服：直接返回该服序列
    if (targets.length === 1) {
      const series = this._seriesOf(targets[0].id, since)
      return { serverId: targets[0].id, name: targets[0].name, points: series, max: maxOf(series), avg: avgOf(series) }
    }

    // 多服：合计序列（同一轮采集各服 t 完全一致，直接按 t 对齐求和）
    const perServer = {}
    const merged = new Map() // t -> sum
    for (const s of targets) {
      const series = this._seriesOf(s.id, since)
      perServer[s.id] = { name: s.name, points: series }
      for (const p of series) {
        if (p.n === null || p.n === undefined) continue // 断点不参与合计
        merged.set(p.t, (merged.get(p.t) || 0) + p.n)
      }
    }
    const points = [...merged.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([t, sum]) => ({ t, n: sum }))
    return {
      serverId: undefined,
      points,
      max: maxOf(points),
      avg: avgOf(points),
      perServer,
    }
  }

  /** 在线玩家列表（最近一次采集快照；单服或多服聚合） */
  async getPlayers(serverId) {
    const list = await this.servers.list()
    const enabled = list.filter((s) => s.enabled !== false)
    const targets = serverId ? enabled.filter((s) => s.id === serverId) : enabled
    if (serverId && targets.length === 0) {
      const err = new Error('目标服务器不存在或未启用')
      err.status = 404
      throw err
    }

    const players = []
    for (const s of targets) {
      const snap = this.snapshots.get(s.id)
      if (!snap || !Array.isArray(snap.players)) continue
      for (const p of snap.players) {
        players.push({
          nickname: p.nickname || '',
          username: p.username || '',
          group: p.group || '',
          state: p.state,
          team: p.team,
          serverId: s.id,
          serverName: s.name,
        })
      }
    }
    return { players, serverId: serverId || undefined, fetchedAt: Math.max(0, ...targets.map((s) => this.snapshots.get(s.id)?.fetchedAt || 0)) }
  }

  /** 单玩家统计（基于采集快照的近似统计：当前在线 / 最近活跃 / 采集出现次数 / 所在服） */
  async getPlayerStats(username, serverId) {
    if (!username || !String(username).trim()) {
      const err = new Error('username 不能为空')
      err.status = 400
      throw err
    }
    const key = String(username).trim().toLowerCase()
    const list = await this.servers.list()
    const enabled = list.filter((s) => s.enabled !== false)
    const targets = serverId ? enabled.filter((s) => s.id === serverId) : enabled

    const sessions = []
    let online = false
    let currentServer = null
    let currentGroup = null
    let lastSeen = 0
    let totalTicks = 0

    for (const s of targets) {
      const snap = this.snapshots.get(s.id)
      const onlineHere = snap && Array.isArray(snap.players)
        ? snap.players.some((p) => (p.username || '').toLowerCase() === key || (p.nickname || '').toLowerCase() === key)
        : false
      if (onlineHere) {
        online = true
        currentServer = { id: s.id, name: s.name }
        const found = snap.players.find((p) => (p.username || '').toLowerCase() === key || (p.nickname || '').toLowerCase() === key)
        if (found) currentGroup = found.group || null
        lastSeen = Math.max(lastSeen, snap.fetchedAt || 0)
      }
      const sess = this.playerSessions.get(`${s.id}:${key}`)
      if (sess) {
        sessions.push({
          serverId: s.id,
          serverName: s.name,
          firstSeen: sess.firstSeen,
          lastSeen: sess.lastSeen,
          totalTicks: sess.totalTicks,
        })
        lastSeen = Math.max(lastSeen, sess.lastSeen)
        totalTicks += sess.totalTicks
      }
    }

    return {
      username: String(username).trim(),
      online,
      currentServer,
      currentGroup,
      lastSeen: lastSeen || null,
      totalTicks,
      sessions,
    }
  }

  // ═════════════ 采集（内部）═════════════

  /** 采集一轮：轮询全部 enabled 服务器在线数 + 玩家明细，写入缓冲与快照 */
  async _collect() {
    if (this._running) return
    this._running = true
    const at = Date.now()
    this._tickSeq++
    try {
      const list = await this.servers.list()
      const enabled = list.filter((s) => s.enabled !== false)
      const summary = []
      let total = 0
      for (const s of enabled) {
        const prev = this.buffer.get(s.id)?.at(-1)?.n ?? null
        const result = await this._fetchCurrent(s)
        if (result.ok) {
          this._pushPoint(s.id, at, result.playercount)
          total += result.playercount
          summary.push({ id: s.id, name: s.name, playercount: result.playercount })
          if (prev !== null && prev !== result.playercount) {
            this._emit('change', { serverId: s.id, name: s.name, prev, cur: result.playercount, at })
          }
        } else {
          // 服务器无响应：写入一个 null 占位（趋势图上断点），不累计 total
          this._pushPoint(s.id, at, null)
          summary.push({ id: s.id, name: s.name, playercount: null, error: result.error })
        }
        this._prune(s.id)
      }
      this._lastTickAt = at
      this._emit('tick', { tickSeq: this._tickSeq, at, servers: summary, total })
      // 清理已删除服务器的残留缓存/快照/缓冲（防内存累积）
      const alive = new Set(enabled.map((s) => s.id))
      for (const id of [...this.currentCache.keys()]) { if (!alive.has(id)) this.currentCache.delete(id) }
      for (const id of [...this.snapshots.keys()]) { if (!alive.has(id)) this.snapshots.delete(id) }
      for (const id of [...this.buffer.keys()]) { if (!alive.has(id)) this.buffer.delete(id) }
      // 落盘（失败不阻断采集）
      try { await this._persist() } catch (err) { console.error('[online-stats] 趋势落盘失败:', err.message) }
    } catch (err) {
      console.error('[online-stats] 采集失败:', err.message)
    } finally {
      this._running = false
    }
  }

  /** 问询一台服务器当前在线（带 30s 短缓存；失败返回 { ok:false, error } 不抛错） */
  async _fetchCurrent(server) {
    const cached = this.currentCache.get(server.id)
    if (cached && Date.now() - cached.fetchedAt < CURRENT_CACHE_MS) {
      return { ok: true, ...cached }
    }
    try {
      const result = await this.tshock.fetchFor(server, '/v2/server/status', { players: true })
      if (result.ok && result.data && typeof result.data.playercount === 'number') {
        const payload = {
          playercount: result.data.playercount,
          maxplayers: result.data.maxplayers ?? null,
          name: result.data.name || server.name,
          fetchedAt: Date.now(),
        }
        this.currentCache.set(server.id, payload)
        this.snapshots.set(server.id, {
          ...payload,
          players: Array.isArray(result.data.players) ? result.data.players : [],
        })
        // 更新单玩家会话记录
        this._updateSessions(server, result.data.players)
        return { ok: true, ...payload }
      }
      if (result.status === 401 || result.status === 403) {
        return { ok: false, error: `token 无效或权限不足（HTTP ${result.status}）` }
      }
      return { ok: false, error: `TShock REST 返回 ${result.status}`, status: result.status }
    } catch (err) {
      return { ok: false, error: err.message, type: err.type || 'network' }
    }
  }

  /** 按采集快照更新单玩家会话（username 键；累计出现次数/最近活跃） */
  _updateSessions(server, players) {
    if (!Array.isArray(players)) return
    const now = Date.now()
    for (const p of players) {
      const uname = (p.username || p.nickname || '').trim()
      if (!uname) continue
      const key = uname.toLowerCase()
      const mapKey = `${server.id}:${key}`
      const sess = this.playerSessions.get(mapKey)
      if (sess) {
        sess.lastSeen = now
        sess.totalTicks++
        sess.username = uname
      } else {
        this.playerSessions.set(mapKey, { username: uname, firstSeen: now, lastSeen: now, totalTicks: 1 })
      }
    }
    // 清理过期会话（48h 无采集出现）
    if (now % 600_000 < 1000) {
      for (const [k, v] of this.playerSessions) {
        if (now - v.lastSeen > SESSION_KEEP_MS) this.playerSessions.delete(k)
      }
    }
  }

  /** 写入环形缓冲（n 为 null 表示该时刻无数据/断点） */
  _pushPoint(serverId, t, n) {
    let series = this.buffer.get(serverId)
    if (!series) {
      series = []
      this.buffer.set(serverId, series)
    }
    const last = series.at(-1)
    if (last && Math.abs(last.t - t) < this.intervalMs / 2) {
      // 同一采样窗口内重复写入：覆盖（避免抖动产生双点）
      last.n = n
      last.t = t
      return
    }
    series.push({ t, n })
    this._prune(serverId)
  }

  /** 裁剪超出保留窗口的点 */
  _prune(serverId) {
    const series = this.buffer.get(serverId)
    if (!series) return
    const cutoff = Date.now() - this.keepMs
    while (series.length > 0 && series[0].t < cutoff) series.shift()
  }

  /** 取某服某时间段序列（升序；含 null 断点） */
  _seriesOf(serverId, since) {
    const series = this.buffer.get(serverId) || []
    return series.filter((p) => p.t >= since).map((p) => ({ t: p.t, n: p.n }))
  }

  // ═════════════ 持久化 ═════════════

  /** 落盘：缓冲 + 会话（JSON；仅在缓冲非空时写） */
  async _persist() {
    if (!this.dataFile || this.buffer.size === 0) return
    const payload = {
      updatedAt: Date.now(),
      buffers: {},
      sessions: {},
    }
    for (const [id, series] of this.buffer) {
      payload.buffers[id] = series
    }
    for (const [k, v] of this.playerSessions) {
      payload.sessions[k] = v
    }
    await mkdir(path.dirname(this.dataFile), { recursive: true })
    await writeFile(this.dataFile, JSON.stringify(payload), 'utf8')
  }

  /** 启动时回填上次进程的趋势与会话（失败静默） */
  async _restore() {
    if (!this.dataFile) return
    try {
      const raw = await readFile(this.dataFile, 'utf8')
      const parsed = JSON.parse(raw)
      if (parsed && typeof parsed === 'object') {
        if (parsed.buffers) {
          for (const [id, series] of Object.entries(parsed.buffers)) {
            if (Array.isArray(series) && series.length) {
              this.buffer.set(id, series)
              this._prune(id)
            }
          }
        }
        if (parsed.sessions) {
          for (const [k, v] of Object.entries(parsed.sessions)) {
            if (v && typeof v.totalTicks === 'number') this.playerSessions.set(k, v)
          }
        }
        console.log(`[online-stats] 已回填历史趋势（${this.buffer.size} 服）与会话记录`)
      }
    } catch { /* 首次运行/文件损坏：忽略 */ }
  }

  // ═════════════ 生命周期 ═════════════

  start() {
    if (this._timer) return
    this._timer = setInterval(() => { this._collect().catch(() => {}) }, this.intervalMs)
    this._timer.unref?.()
    console.log(`[online-stats] 采集已启动（每 ${Math.round(this.intervalMs / 1000)}s 一轮，保留 ${Math.round(this.keepMs / 3600_000)}h）`)
  }

  stop() {
    if (this._timer) { clearInterval(this._timer); this._timer = null }
  }

  /** 插件卸载清理：停采集 + 落盘 */
  async dispose() {
    this.stop()
    try { await this._persist() } catch { /* ignore */ }
  }
}

// ═════════════ 工具 ═════════════

function maxOf(points) {
  let max = null
  for (const p of points) {
    if (p.n === null || p.n === undefined) continue
    if (max === null || p.n > max) max = p.n
  }
  return max
}

function avgOf(points) {
  let sum = 0
  let count = 0
  for (const p of points) {
    if (p.n === null || p.n === undefined) continue
    sum += p.n
    count++
  }
  return count ? Math.round((sum / count) * 10) / 10 : null
}

// ═════════════ 插件挂载 ═════════════

export async function apply(ctx, options = {}) {
  const service = new OnlineStatsService(ctx, options)
  service.servers = ctx.servers
  service.tshock = ctx.tshock
  service.dataFile = path.join(ctx.paths.dataOf('online-stats'), 'trends.json')

  // 回填上次进程数据 → 立即采集一轮 → 启动定时器
  await service._restore()
  ctx.onlineStats = service
  service._collect().catch(() => {})
  service.start()

  // ══ REST 端点（全部 admin 鉴权）══
  const app = ctx.webServer.app
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]

  // 当前在线
  app.get('/api/online-stats/current', ...admin, async (req, res) => {
    try {
      const serverId = req.headers['x-server-id'] || (req.query && req.query.serverId) || undefined
      res.json(await service.getCurrent(serverId))
    } catch (err) {
      res.status(err.status || 500).json({ error: err.message })
    }
  })

  // 历史趋势
  app.get('/api/online-stats/trend', ...admin, async (req, res) => {
    try {
      const serverId = req.headers['x-server-id'] || (req.query && req.query.serverId) || undefined
      const hours = Math.min(Math.max(Number((req.query || {}).hours) || 24, 1), 168) // 1h ~ 7d
      res.json(await service.getTrend(serverId, hours))
    } catch (err) {
      res.status(err.status || 500).json({ error: err.message })
    }
  })

  // 在线玩家列表
  app.get('/api/online-stats/players', ...admin, async (req, res) => {
    try {
      const serverId = req.headers['x-server-id'] || (req.query && req.query.serverId) || undefined
      res.json(await service.getPlayers(serverId))
    } catch (err) {
      res.status(err.status || 500).json({ error: err.message })
    }
  })

  // 单玩家统计
  app.get('/api/online-stats/player', ...admin, async (req, res) => {
    try {
      const serverId = req.headers['x-server-id'] || (req.query && req.query.serverId) || undefined
      const username = (req.query || {}).username
      res.json(await service.getPlayerStats(username, serverId))
    } catch (err) {
      res.status(err.status || 500).json({ error: err.message })
    }
  })

  // 服务器摘要（含在线数）
  app.get('/api/online-stats/servers', ...admin, async (req, res) => {
    try {
      res.json({ servers: await service.getServers() })
    } catch (err) {
      res.status(500).json({ error: err.message })
    }
  })

  console.log('[online-stats] 在线统计插件已挂载（ctx.onlineStats + /api/online-stats/*）')
  // 返回 dispose effect：cordis 在插件禁用/卸载时调用（停采集定时器 + 落盘）。
  // 注意：不能返回 service 对象（"Invalid effect"），返回函数是合法 effect。
  return () => service.dispose()
}
