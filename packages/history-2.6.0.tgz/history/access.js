const reads = [
  ["status", "GET", "status"],
  ["players", "GET", "players"],
  ["catalog", "GET", "catalog"],
  ["map", "GET", "map"],
  ["map-task", "GET", "map-task"],
  ["map-chunk", "GET", "map-chunk"],
  ["map-tile", "GET", "map-tile"],
  ["query", "POST", "query"],
  ["task", "GET", "task"],
  ["events", "GET", "events"],
].map(([id, method, suffix]) => ({
  id: `history.${id}`,
  method,
  path: `/api/history/${suffix}`,
  module: "history.read",
  scope: "server",
}));
const writes = ["preview", "execute", "cancel", "undo"].map((id) => ({
  id: `history.${id}`,
  method: "POST",
  path: `/api/history/${id}`,
  module: "history.rollback",
  scope: "server",
}));
export default {
  owner: "history",
  version: 2,
  modules: [
    {
      id: "history.read",
      permission: "history.read",
      title: "地图编辑查询",
      roles: ["superadmin", "admin"],
      scope: "server",
      requires: reads.map((a) => a.id),
    },
    {
      id: "history.rollback",
      permission: "history.rollback",
      title: "地图编辑回退",
      roles: ["superadmin", "admin"],
      scope: "server",
      requires: [...reads, ...writes].map((a) => a.id),
    },
  ],
  actions: [...reads, ...writes],
  features: [
    {
      id: "history:browse",
      module: "history.read",
      requires: reads.map((a) => a.id),
    },
    {
      id: "history:rollback",
      module: "history.rollback",
      requires: [...reads, ...writes].map((a) => a.id),
    },
  ],
};
