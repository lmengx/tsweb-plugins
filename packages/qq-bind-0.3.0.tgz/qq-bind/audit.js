/**
 * 本件审计流水（<dataDir>/qq-bind/audit.jsonl，追加写）
 *
 * 事件名与旧版后端 audit 对齐（backend/services/auditEvents.js:187-217）：
 *   qq_account.bind / bind_admin / unbind / rebind / register / change_password / qq_playtime.refresh
 * 新版统一前缀 qqbind.*，并额外记录接入来源（adapter）（旧版没有这个维度）。
 */
import { appendFile, mkdir, readFile, stat, rename } from 'node:fs/promises'
import path from 'node:path'

/** 单文件上限（超过则轮转为 audit.jsonl.1），避免无限增长 */
const MAX_BYTES = 8 * 1024 * 1024

export class AuditLog {
  constructor({ file }) {
    if (!file) throw new Error('AuditLog 需要 file 路径')
    this.file = file
    this.dir = path.dirname(file)
  }

  /**
   * 追加一条审计。
   * @param {string} action  如 qqbind.bind
   * @param {object} entry   { actor, adapter, ...detail }
   */
  async append(action, entry = {}) {
    const line =
      JSON.stringify({
        t: new Date().toISOString(),
        action: String(action),
        actor: entry.actor != null ? String(entry.actor) : '',
        adapter: entry.adapter != null ? String(entry.adapter) : '',
        ...entry,
      }) + '\n'
    await mkdir(this.dir, { recursive: true })
    await this._rotateIfNeeded()
    await appendFile(this.file, line, 'utf8')
    return true
  }

  async _rotateIfNeeded() {
    try {
      const st = await stat(this.file)
      if (st.size >= MAX_BYTES) await rename(this.file, `${this.file}.1`)
    } catch (err) {
      if (err.code !== 'ENOENT') throw err
    }
  }

  /** 读取最近 n 条（新的在前）；文件不存在或损坏行自动跳过 */
  async tail(limit = 100) {
    const n = Math.min(Math.max(1, Number(limit) || 100), 1000)
    let raw
    try {
      raw = await readFile(this.file, 'utf8')
    } catch (err) {
      if (err.code === 'ENOENT') return []
      throw err
    }
    const lines = raw.split('\n').filter((l) => l.trim() !== '')
    const out = []
    for (let i = lines.length - 1; i >= 0 && out.length < n; i--) {
      try {
        out.push(JSON.parse(lines[i]))
      } catch {
        out.push({ t: null, action: 'parse-error', raw: lines[i].slice(0, 200) })
      }
    }
    return out
  }
}
