/**
 * QQ 绑定基础件（qq-bind）—— 宿主侧半
 *
 * 设计：docs/QQ绑定基础件设计.md ｜ 对接：docs/QQ绑定功能对接文档.md
 *
 * 三条硬约束（违反即"看起来成功、实际没生效"）：
 *   1. 台账唯一权威在本件（<dataDir>/qq-bind/bindings.json）；游戏服只持有只读快照
 *   2. 核心不认识任何机器人框架：接入方式是适配器（内置 legacy-http 让旧 Koishi 零改动），
 *      能力注册一次、所有适配器可见（adapters/registry.js）
 *   3. 台账**任何**变更（含改名）都必须下发快照——旧版改名漏推导致"改名后不晋升、不豁免"
 *      （TsWeb/backend/services/userAdminService.js:44-90 对比 :122-131）；
 *      绑定识别与自动晋升均已迁出本件：晋升现由独立插件 qq-promotion 只读本件落盘的快照判断
 *
 * 职责划分：
 *   - 本文件：服务（ctx.qqBind）+ 绑定域/昵称域能力 + 管理 REST + 快照下发
 *   - ledger.js    ：台账（原子落盘、1:1、大小写不敏感 + aliases、导入幂等）
 *   - nicknames.js ：QQ 昵称缓存 + 昵称刷新任务编排（缓存，非权威数据；**不写进台账**）
 *   - gameOps.js   ：游戏服调用（查询/建号/改密/快照）
 *   - adapters/    ：接入层（适配器注册表 + 能力注册表 + 内置 legacy-http）
 *
 * 依赖全部为既有服务：webServer / auth / servers / tshock / paths
 * 约定：禁止 emoji；状态数据走 ctx.paths.dataOf('qq-bind')（不在插件目录内）
 */
import { Service } from '@deepseek-ai/cordis'
import { mkdir } from 'node:fs/promises'
import { randomBytes } from 'node:crypto'
import path from 'node:path'

import { Ledger, httpError, normQq, isValidQq, normKey } from './ledger.js'
import { NicknameStore, NicknameTaskQueue, NICKNAME_REPORT_LIMIT } from './nicknames.js'
import {
  loadConfig,
  saveConfig,
  normalizeConfig,
  setByPath,
  redactConfig,
  serverFlags,
} from './config.js'
import { AuditLog } from './audit.js'
import { CapabilityRegistry, AdapterRegistry } from './adapters/registry.js'
import { createLegacyHttpAdapter } from './adapters/legacy-http.js'
import { createGameOps } from './gameOps.js'

export const name = 'qq-bind'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths']

/** 自助注册时的随机密码长度（用户随后用「改密码」设置自己的密码；免密登录不依赖它） */
const RANDOM_PASSWORD_BYTES = 9

/** 批量操作上限（旧版语义：100 人，userAdminService.js:191） */
const BATCH_LIMIT = 100

/**
 * 单次「批量查 QQ」上限。
 * 500 的取法：前端一页玩家列表远小于此（旧版列表页 pageSize 上限也是 500，
 * ledger.js:272 同值），一次请求最多搬 500 条绑定关系，够用且不至于被拿去整库拉取。
 */
const LOOKUP_LIMIT = 500

/**
 * 重新生成 token 的随机字节数：32 字节 = 256 位熵；
 * base64url 编码后固定 43 个字符（不含 + / =，放进 URL 与 JSON 都不用转义）。
 */
const TOKEN_BYTES = 32

/**
 * 往结果对象上挂一个"原样键"。
 *
 * 不能用 obj[key] = value：键来自用户输入（角色名允许叫 "__proto__"），
 * 直接赋值会去改原型而不是加键，这一项会"凭空消失"（qqMap 同样理由，见其注释）。
 */
function defineKey(obj, key, value) {
  Object.defineProperty(obj, key, {
    value,
    enumerable: true,
    writable: true,
    configurable: true,
  })
}

/**
 * 取"自有键"的值（取不到一律空串）。
 * 必须用 hasOwnProperty 判在不在：角色名允许叫 toString / constructor，
 * 直接读属性会命中原型链上的成员，把一个"没有昵称"的角色显示成一串函数源码。
 */
function ownGet(map, key) {
  if (!map || typeof map !== 'object') return ''
  if (!Object.prototype.hasOwnProperty.call(map, key)) return ''
  const v = map[key]
  return v == null ? '' : String(v)
}

/**
 * 取**可选**服务（软依赖）。
 *
 * 为什么不能直接写 `ctx.onlineStats`：cordis 的 ctx 代理对**没有写进 inject** 的服务
 * 是"访问即抛错"——`@deepseek-ai/cordis/lib/index.js:669-675` 的 Proxy get 陷阱，
 * 在 fiber.inject 里找不到该 prop 就 `throw new Error('cannot get property "x" without inject')`。
 * 前端看到的就是这条报错（列表页加载失败）。
 *
 * 为什么也不能把 onlineStats 写进 inject：inject 的语义是"等这些依赖就绪再 apply"，
 * 而 online-stats 对本件是**软依赖**（时长只是附加信息，缺失时应降级为"时长不可用"）。
 * 写进 inject 会让"没装 online-stats"直接变成"整个 qq-bind 不加载"——
 * 绑定/注册/改密这些核心能力全部不可用，代价远大于少一个时长列。
 *
 * ctx.get() 不会有这个问题：`_getImpl()` 在服务**从未注册**时返回 undefined（不抛），
 * strict 只用于排除"已注册但 fiber 未就绪"的服务——正好是我们想要的口径
 * （只在该服务真正可用时才用它）。
 */
function optionalService(ctx, name) {
  try {
    if (ctx && typeof ctx.get === 'function') {
      const svc = ctx.get(name)
      if (svc) return svc
    }
  } catch {
    /* 取不到就当没有：软依赖失败一律降级，绝不让它冒泡成"插件加载失败" */
  }
  /**
   * 兜底：直接读属性，但**必须包在 try 里**。
   * 真实宿主的 ctx 代理在这里会抛 "cannot get property ... without inject"（未 inject），
   * 被 catch 掉即等价于"该服务不存在"——与上一段的口径一致。
   * 保留这一条是为了兼容"服务以普通属性挂上来"的场景（测试骨架直接调 apply(ctx) 时就是如此，
   * 那里 inject 并不生效），否则终端命令这类可选能力会静默不注册。
   */
  try {
    return ctx?.[name] ?? null
  } catch {
    return null
  }
}

/** 台账变更 → 事件名 */
const EVENT_OF_ACTION = {
  bound: 'qqbind/bound',
  unbound: 'qqbind/unbound',
  rebound: 'qqbind/rebound',
  transferred: 'qqbind/transferred',
  renamed: 'qqbind/renamed',
  'password-changed': 'qqbind/password-changed',
  registered: 'qqbind/registered',
  removed: 'qqbind/removed',
  imported: 'qqbind/imported',
}

class QqBindService extends Service {
  constructor(ctx) {
    super(ctx, 'qqBind')
    /** @type {Ledger} */ this.ledger = null
    /** @type {NicknameStore} */ this.nicknames = null
    /**
     * 昵称刷新任务队列（内存态、单任务）。
     * 在构造时就建好：任务态不依赖磁盘/配置，任何时刻都可安全查询（未初始化时就是"没有任务"）。
     */
    this.nicknameTasks = new NicknameTaskQueue()
    /** @type {AuditLog} */ this.audit = null
    /** @type {object} */ this.config = null
    /** @type {object} */ this.gameOps = null
    /** @type {string} */ this.configFile = ''
    this.capabilities = new CapabilityRegistry()
    this.adapters = new AdapterRegistry()
    /** 快照版本号：每次下发自增，供排障与游戏侧判断新旧 */
    this.snapshotVersion = 0
    /** serverId -> { ok, at, version, count, error, serverHalfMissing } */
    this.pushStatus = new Map()
    /** 快照推送串行链（单一推送者：由 onLedgerChange 排队，业务方法只负责等待结果） */
    this._pushQueue = null
    this._pushResult = null
    /** 台账变更序号与"已排队推送覆盖到的序号"，用于判断本次变更是否已排队 */
    this._mutationSeq = 0
    this._pushSeq = -1
    /** 兜底对账定时器 */
    this._reconcile = null
  }

  // ══════════════════════════════════════════════════════════
  // 查询（其他插件用软依赖 ctx.qqBind?.xxx 调用）
  // ══════════════════════════════════════════════════════════

  getByQq(qq) {
    return this.ledger.getByQq(qq)
  }

  getByUsername(username) {
    return this.ledger.getByUsername(username)
  }

  /** 按 QQ 或角色名解析（大小写不敏感） */
  resolve(identifier) {
    return this.ledger.get(identifier)
  }

  isBound(identifier) {
    return this.ledger.isBound(identifier)
  }

  /**
   * 【对外契约】查某个游戏角色绑定的 QQ 号。
   *
   * 供宿主内其它插件直接调用（软依赖写法：`ctx.qqBind?.qqOf(name)`）。
   * 典型场景：玩家列表页显示"QQ 用户名"——本项目里"QQ 用户名"就是**绑定的 QQ 号本身**
   * （台账只存 qq 与游戏角色名 username，从未存过 QQ 昵称，因此不存在昵称字段，别臆造）。
   *
   * 注意：本方法是同步的纯查询，调用方若在插件加载早期调用，应先 `await ctx.qqBind.ready`
   * （初始化完成前 ledger 为 null，此处返回 null 而不是抛错，避免把调用方插件带崩）。
   *
   * @param {string} username 游戏角色名（大小写不敏感；解析口径与台账 getByUsername 完全一致——
   *   aliases 只用于把"仅大小写不同"的写法归到原名，改名/解绑后的旧名不再解析，同样返回 null）
   * @returns {string|null} QQ 号字符串；未绑定 / 查不到 / 入参为空 → null
   */
  qqOf(username) {
    if (!this.ledger) return null
    const rec = this.ledger.getByUsername(username)
    return rec ? rec.qq : null
  }

  /**
   * 【对外契约】批量查 QQ 号（玩家列表这类一次要几十上百个名字的场景）。
   *
   * 返回值是**普通对象**（便于直接 JSON 序列化、摊进前端行数据）：
   *   - 键 = **传入名字的原文**（不做大小写归一，调用方拿到的键与它传进来的字符串逐字符一致）
   *   - 值 = QQ 号字符串
   *   - 查不到的名字**不出现**在该对象里（调用方以"键是否缺失"判断未绑定，而不是拿到 null）
   *   - 传入数组里的重复名字合并为一个键；空串/非字符串入参按 String() 归一后查找，查不到即不出现
   *
   * 性能：**只读一次台账**。台账的唯一权威是内存里的 records / aliases
   * （Ledger.load() 读盘一次，之后只在变更时改写内存并落盘），这里调用 ledger.qqIndex()
   * 用**一趟遍历**建好「小写名 → QQ」的 Map，之后每个名字只做一次 O(1) 查表；
   * 循环里不逐个调 getByUsername、更不碰任何文件。
   *
   * @param {string[]} names 角色名数组
   * @returns {Object<string, string>} { "<传入名字原文>": "<QQ 号>" }，只含查到的
   */
  qqMap(names) {
    const out = {}
    const list = Array.isArray(names) ? names : []
    if (!this.ledger || list.length === 0) return out
    const index = this.ledger.qqIndex() // 唯一一次台账读取（内存索引，不读盘）
    for (const raw of list) {
      const name = String(raw ?? '')
      const qq = index.get(normKey(name))
      if (!qq) continue
      // 用 defineProperty 而不是 out[name] = qq：角色名若恰好叫 "__proto__"，
      // 直接赋值会去改原型而不是加键，这一项会"凭空消失"（本件不接受静默少数据）
      Object.defineProperty(out, name, {
        value: qq,
        enumerable: true,
        writable: true,
        configurable: true,
      })
    }
    return out
  }

  // ══════════════════════════════════════════════════════════
  // QQ 昵称（缓存；移植自旧版 TsWeb/backend/services/qqNicknameService.js）
  //
  // 昵称与台账是**两套数据**：台账是权威绑定关系，昵称是可能为空的缓存。
  // 对外一律"有昵称用昵称、没有就退回 QQ 号"，绝不用角色名冒充昵称
  // （旧版 voteController.js:16-17 的口径）。
  // ══════════════════════════════════════════════════════════

  /**
   * 【对外契约】查某个 QQ 的昵称（缓存，无则空串）。
   *
   * 供宿主内其它插件直接调用（软依赖写法：`await ctx.qqBind?.nicknameOf(qq)`）。
   * 典型场景：投票明细、玩家列表这类"有昵称就显示昵称"的展示位。
   *
   * 注意：与 qqOf / qqMap（台账内存索引，同步）不同，本方法是 **async**——
   * 昵称缓存沿用旧版"实时读文件、不做内存缓存"的策略（nicknames.js 文件头有说明），
   * 所以每次调用都可能是真实读盘。批量场景请用 nicknameMap()，它只读一次。
   *
   * @param {string} qq QQ 号（格式不合法 → 空串，与旧版 getNickname 一致）
   * @returns {Promise<string>} 昵称；无缓存 / 格式不合法 / 缓存损坏 → 空串（不抛错）
   */
  async nicknameOf(qq) {
    if (!this.nicknames) return ''
    return this.nicknames.getNickname(qq)
  }

  /**
   * 【对外契约】批量查昵称。
   *
   * 返回值是**普通对象**（便于直接 JSON 序列化、摊进前端行数据）：
   *   - 键 = **QQ 号**（与 qqOf/qqMap 的"角色名"键不同：昵称的归属就是 QQ 号）
   *   - 值 = 昵称字符串
   *   - 没有昵称的 QQ **不出现**在该对象里（调用方以"键是否缺失"判断未获取）
   *
   * 性能：**只读一次缓存文件**（nicknames.js 的 getNicknameMap 一趟读盘 + 一趟遍历），
   * 传入的 QQ 只做 O(1) 查表。
   *
   * @param {string[]} [qqs] 省略 / 非数组 → 全部昵称
   * @returns {Promise<Object<string, string>>} { "<QQ号>": "<昵称>" }，只含取到昵称的
   */
  async nicknameMap(qqs) {
    const out = {}
    if (!this.nicknames) return out
    const all = await this.nicknames.getNicknameMap()
    if (!Array.isArray(qqs)) {
      for (const [qq, nick] of Object.entries(all)) defineKey(out, qq, nick)
      return out
    }
    for (const raw of qqs) {
      const qq = normQq(raw)
      if (!qq) continue
      const nick = ownGet(all, qq)
      if (!nick) continue
      defineKey(out, qq, nick)
    }
    return out
  }

  /** QQ → 昵称更新时间（无则空串；排障用） */
  async nicknameUpdatedAt(qq) {
    if (!this.nicknames) return ''
    return this.nicknames.getNicknameUpdatedAt(qq)
  }

  /**
   * 台账里全部**已绑定**的 QQ 号（去重、保序）。
   * 旧版 botController.js:752-760 的登记逻辑原样搬过来：跳过空值、按 QQ 去重。
   * 注意这里**不校验格式**（与旧版一致）——格式校验统一由 requestNicknameTask 负责。
   */
  boundQqs() {
    const out = []
    const seen = new Set()
    if (!this.ledger) return out
    for (const username of this.ledger.usernames()) {
      const rec = this.ledger.getByUsername(username)
      if (!rec) continue
      const qq = normQq(rec.qq)
      if (!qq || seen.has(qq)) continue
      seen.add(qq)
      out.push(qq)
    }
    return out
  }

  /**
   * 登记一次昵称刷新任务（管理页「获取昵称」/ 其它插件调用）。
   * 已有进行中的任务则**原样返回同一个任务**，不重复登记（连点等价于同一件事）。
   * @param {{actor?:string, qqs?:string[]}} p
   */
  requestNicknameTask({ actor = '', qqs = [] } = {}) {
    return this.nicknameTasks.request({ actor, qqs })
  }

  /**
   * 机器人领取任务（旧路径 GET /api/bot/nickname-task）。
   * @returns {{id:string, qqs:string[], total:number}|null} 无待领取任务 → null
   */
  claimNicknameTask() {
    return this.nicknameTasks.claim()
  }

  /** 机器人回报结果（旧路径 POST /api/bot/qq-nickname 内部调用） */
  finishNicknameTask(id, { stored = 0, failed = [] } = {}) {
    return this.nicknameTasks.finish(id, { stored, failed })
  }

  /** 当前任务状态（管理页轮询用，已含惰性超时判定） */
  getNicknameTask() {
    return this.nicknameTasks.view()
  }

  /**
   * 机器人上报昵称（旧版 botController.js:809-829）。
   *
   * 先落缓存，再（有 taskId 时）把任务收尾；逐条失败原因原样回给页面，
   * 让"哪些没取到、为什么"可见。
   *
   * @param {{entries?:Array, taskId?:string, source?:string}} p
   * @returns {Promise<{stored:number, skipped:number, failed:Array, task:object|null}>}
   * @throws 400 entries 不是数组；413 条数超过 NICKNAME_REPORT_LIMIT
   */
  async reportNicknames({ entries, taskId = '', source = 'bot' } = {}) {
    if (!Array.isArray(entries)) throw httpError(400, '缺少参数: entries（数组）')
    if (entries.length > NICKNAME_REPORT_LIMIT) {
      throw httpError(413, `单次上报条数超过上限 ${NICKNAME_REPORT_LIMIT}`)
    }
    const result = await this.nicknameStore().saveNicknames(entries, { source })
    const id = String(taskId || '')
    const task = id ? this.finishNicknameTask(id, { stored: result.stored, failed: result.failed }) : null
    this.ctx.logger?.info?.(
      `[qq-bind] 机器人上报昵称：写入 ${result.stored} 条，未取到 ${result.failed.length} 条${id ? `（任务 ${id}）` : ''}`,
    )
    return { stored: result.stored, skipped: result.skipped, failed: result.failed, task }
  }

  /** 昵称缓存实例（初始化尚未完成时抛 503，而不是静默写不进去） */
  nicknameStore() {
    if (!this.nicknames) {
      throw httpError(503, 'QQ 绑定插件正在初始化（昵称缓存尚未就绪），请稍后重试')
    }
    return this.nicknames
  }

  /** 绑定列表（可选叠加多服时长；时长缺失时如实标注，不假装 0） */
  async list({ keyword = '', page = 1, pageSize = 50 } = {}) {
    const base = this.ledger.list({ keyword, page, pageSize })
    const playtime = await this._playtimeAll()
    /**
     * 昵称是**可能为空的缓存**：按 QQ 取缓存，取不到就是空串——
     * 前端据此显示"未获取"，而不是拿 QQ 号或角色名冒充昵称
     * （旧版 botController.qqList :695-705 同口径；只读一次缓存文件）。
     */
    const nicknames = await this.nicknameMap(base.rows.map((row) => row.qq))
    const rows = base.rows.map((row) => ({
      ...row,
      nickname: ownGet(nicknames, row.qq),
      playtime: playtime && playtime.stats ? playtime.stats[row.username] ?? 0 : null,
      playtimeUnavailable: !(playtime && playtime.stats),
    }))
    // 与旧版一致：按时长降序（旧版由后端排序，botController.js:608）
    if (playtime && playtime.stats) {
      rows.sort((a, b) => (b.playtime || 0) - (a.playtime || 0))
    }
    return { ...base, rows, playtimeSource: playtime && playtime.stats ? 'online-stats' : 'unavailable' }
  }

  /** 统计（供其它插件/前端展示，替代旧版前端全量拉取后自算） */
  stats() {
    return {
      bound: this.ledger.size,
      updatedAt: this.ledger.updatedAt,
      snapshotVersion: this.snapshotVersion,
    }
  }

  /**
   * 身份补全（接入层调用；领域逻辑留在核心，适配器不碰台账）。
   * 依据请求参数里的 qq / player / username 找出台账记录，回填 principal。
   */
  async identify(principal, params = {}) {
    const out = { ...(principal || {}) }
    if (!this.ledger) return out // 初始化尚未完成：不猜测身份
    const qq = params.qq != null && String(params.qq).trim() !== '' ? normQq(params.qq) : ''
    const name = String(params.player || params.username || '').trim()
    if (qq) out.qq = qq
    let rec = null
    if (qq) rec = this.ledger.getByQq(qq)
    if (!rec && name) rec = this.ledger.getByUsername(name)
    if (rec) {
      out.boundUsername = rec.username
      out.qq = rec.qq
    }
    return out
  }

  // ══════════════════════════════════════════════════════════
  // 变更（全部写台账 + 广播事件 + 下发快照）
  // ══════════════════════════════════════════════════════════

  /**
   * 绑定已有角色（机器人「绑定」/ 管理端「手动绑定」）。
   * @returns {Promise<object>} 含 server/uuidSync/snapshot，供调用方回显
   */
  async bind({ qq, player, serverId = '', source = 'bot' }) {
    const q = normQq(qq)
    const target = String(player || '').trim()
    if (!q) throw httpError(400, '缺少参数: qq')
    if (!target) throw httpError(400, '缺少参数: player')
    if (!isValidQq(q)) throw httpError(400, 'QQ 号格式不正确')
    this._assertFree(q, target)

    const { server, info } = await this.gameOps.locateAccount(target, { serverId })
    if (this.config.binding.requireOnlineForBind && !info.online) {
      throw httpError(409, '该角色当前不在线（当前配置要求绑定前角色在线）')
    }

    const rec = await this.ledger.bind({
      qq: q,
      username: target,
      passwordHash: info.passwordHash,
      source,
    })

    const snapshot = await this._ensurePushed()
    let uuidSync = null
    if (info.online && info.onlineUuid) {
      // 旧版语义：角色在线时绑定即全服免密（botController.js:742-749）
      uuidSync = await this.syncUuid(target, info.onlineUuid, { excludeServerId: server.id })
    }

    await this.audit.append('qqbind.bind', {
      username: rec.username,
      qq: q,
      server: server.name,
      source,
      actor: source,
    })
    return {
      player: rec.username,
      username: rec.username,
      qq: q,
      server: server.name,
      servers: [server.name],
      uuidSync,
      snapshot,
    }
  }

  /** 自助注册：逐服建号（TShock 原生 REST）→ 取回哈希 → 写台账 → 下发 */
  async registerPlayer({ qq, player, source = 'bot' }) {
    if (!this.config.binding.allowSelfRegister) throw httpError(403, '当前未开放自助注册')
    const q = normQq(qq)
    const target = String(player || '').trim()
    if (!q) throw httpError(400, '缺少参数: qq')
    if (!target) throw httpError(400, '缺少参数: player')
    if (!isValidQq(q)) throw httpError(400, 'QQ 号格式不正确')
    this._assertFree(q, target)

    const servers = await this.gameOps.enabledServers()
    if (servers.length === 0) throw httpError(400, '尚未配置任何启用服务器')

    // 已存在同名账号 → 引导用「绑定」（旧版语义）
    for (const server of servers) {
      const info = await this.gameOps.findAccount(server, target)
      if (info.found) {
        throw httpError(409, `角色「${target}」在服务器「${server.name}」已存在，请使用「绑定」`, {
          serverId: server.id,
        })
      }
    }

    const password = randomPassword()
    const created = []
    for (const server of servers) {
      await this.gameOps.createUser(server, target, password)
      created.push(server.name)
    }

    // 取回 TShock 自己算的哈希（免密登录与快照同步都用它）
    let passwordHash = ''
    let hashFrom = ''
    for (const server of servers) {
      const info = await this.gameOps.findAccount(server, target)
      if (info.found && info.passwordHash) {
        passwordHash = info.passwordHash
        hashFrom = server.name
        break
      }
    }
    if (!passwordHash) throw httpError(502, '建号成功但未能从服务器取回密码哈希，请稍后重试或联系管理员')

    await this.ledger.bind({ qq: q, username: target, passwordHash, source })
    const snapshot = await this._ensurePushed()
    await this.audit.append('qqbind.register', {
      username: target,
      qq: q,
      servers: created,
      hashFrom,
      source,
    })
    return {
      player: target,
      username: target,
      qq: q,
      servers: created,
      created: true,
      snapshot,
    }
  }

  /** 改密：写台账哈希（免密依据）+ 下发快照；哈希由 TShock 生成后回读，保证与游戏内一致 */
  async changePassword({ username, qq, password, source = 'bot' }) {
    const rec = username ? this.ledger.getByUsername(username) : this.ledger.getByQq(qq)
    if (!rec) throw httpError(404, '该角色未绑定 QQ')
    const pass = String(password ?? '')
    if (!pass) throw httpError(400, '缺少参数: password')
    if (pass.length < 6) throw httpError(400, '密码长度至少 6 位')

    const servers = await this.gameOps.enabledServers()
    if (servers.length === 0) throw httpError(400, '尚未配置任何启用服务器')

    // 让游戏侧按 TShock 自身算法落盘（复用 base 插件既有端点），再回读哈希写台账：
    // 这样台账里的哈希与账户里的 hash 完全一致，避免快照同步时反复重写密码
    const applied = []
    const failed = []
    let passwordHash = ''
    for (const server of servers) {
      try {
        const result = await this.ctx.tshock.fetchFor(server, '/data/base/players/password', {
          player: rec.username,
          password: pass,
        })
        if (!result.ok) {
          failed.push({
            server: server.name,
            error:
              result.status === 404
                ? '该服务器未安装 base 服务端半（Base.dll），无法改密'
                : `HTTP ${result.status}`,
          })
          continue
        }
        applied.push(server.name)
        if (!passwordHash) {
          const info = await this.gameOps.findAccount(server, rec.username)
          if (info.passwordHash) passwordHash = info.passwordHash
        }
      } catch (err) {
        failed.push({ server: server.name, error: err.message })
      }
    }
    if (applied.length === 0) {
      throw httpError(502, '所有服务器改密均失败', { failed })
    }

    if (passwordHash) await this.ledger.setPasswordHash(rec.username, passwordHash)
    const snapshot = await this._ensurePushed()
    await this.audit.append('qqbind.change_password', {
      username: rec.username,
      qq: rec.qq,
      servers: applied,
      failed,
      source,
    })
    return { username: rec.username, qq: rec.qq, servers: applied, failed, snapshot }
  }

  /** 换绑 QQ */
  async rebind({ username, newQq, source = 'admin' }) {
    const rec = await this.ledger.rebind({ username, newQq })
    const snapshot = await this._ensurePushed()
    await this.audit.append('qqbind.rebind', {
      username: rec.username,
      fromQq: rec.fromQq,
      toQq: rec.toQq,
      source,
    })
    return { ...rec, snapshot }
  }

  /** 转移绑定（原角色数据保留，仅解除 QQ 绑定） */
  async transfer({ fromUsername, toUsername, qq, source = 'admin' }) {
    const name = String(toUsername || '').trim()
    if (name) {
      // 新角色的免密哈希从服务器重新获取（旧版语义）
      const { info } = await this.gameOps.locateAccount(name, {})
      const rec = await this.ledger.transfer({
        fromUsername,
        toUsername: name,
        qq,
        passwordHash: info.passwordHash,
      })
      const snapshot = await this._ensurePushed()
      await this.audit.append('qqbind.transfer', {
        from: rec.fromUsername,
        to: rec.toUsername,
        qq: rec.qq,
        source,
      })
      return { ...rec, snapshot }
    }
    const rec = await this.ledger.transfer({ fromUsername, toUsername, qq })
    const snapshot = await this._ensurePushed()
    return { ...rec, snapshot }
  }

  /** 解绑（仅删绑定关系；各服账号与角色数据保留） */
  async unbind({ username, qq, source = 'admin' }) {
    const rec = await this.ledger.unbind({ username, qq })
    const snapshot = await this._ensurePushed()
    await this.audit.append('qqbind.unbind', { username: rec.username, qq: rec.qq, source })
    return { ...rec, snapshot }
  }

  /**
   * 改名联动（供 base 调用；软依赖）。
   * 旧版缺陷 B1 的正解：改名同样触发快照下发。
   */
  async renameAccount(oldName, newName, { source = 'base' } = {}) {
    const rec = await this.ledger.rename(oldName, newName)
    if (rec.skipped) return rec
    const snapshot = await this._ensurePushed()
    await this.audit.append('qqbind.rename', {
      from: rec.from,
      to: rec.to,
      source,
    })
    return { ...rec, snapshot }
  }

  /** 删号级联（供 base 调用；仅删台账记录，账号由 base 删） */
  async deleteAccount(username, { source = 'base' } = {}) {
    const rec = await this.ledger.remove(username)
    if (rec.skipped) return rec
    const snapshot = await this._ensurePushed()
    await this.audit.append('qqbind.delete', { username: rec.username, qq: rec.qq, source })
    return { ...rec, snapshot }
  }

  /** 批量解绑（上限 100，逐条回显失败，旧版语义） */
  async batchUnbind(users, { source = 'admin' } = {}) {
    const list = Array.isArray(users) ? users.map(String).filter(Boolean) : []
    if (list.length === 0) throw httpError(400, '缺少参数: users')
    if (list.length > BATCH_LIMIT) throw httpError(400, `单次批量上限 ${BATCH_LIMIT} 人`)

    const ok = []
    const failed = []
    for (const username of list) {
      try {
        const rec = await this.ledger.unbind({ username })
        ok.push(rec.username)
      } catch (err) {
        failed.push({ username, error: err.message })
      }
    }
    const snapshot = ok.length > 0 ? await this._ensurePushed() : null
    await this.audit.append('qqbind.batch_unbind', { ok: ok.length, total: list.length, source })
    return { ok: ok.length, total: list.length, succeeded: ok, failed, snapshot }
  }

  /**
   * 导入旧台账（幂等；冲突逐条列出）。
   *
   * 本方法**必须保留**：本件已不再提供任何导入入口（原 REST 路由 /api/qq-bind/import
   * 与终端命令 qqbind-import 均已迁至 legacy-import 插件），它是**唯一**的落库入口，
   * 由 legacy-import 通过 ctx.qqBind.importLegacy(source, { dryRun, actor }) 调用。
   * 行为语义（幂等 / 冲突逐条 / dryRun 不落盘）由 ledger.import 保证，勿在此重复实现。
   */
  async importLegacy(source, { dryRun = false, actor = 'admin' } = {}) {
    const result = await this.ledger.import(source, { dryRun })
    const snapshot = result.applied && result.appliedCount > 0 ? await this._ensurePushed() : null
    await this.audit.append('qqbind.import', {
      imported: result.imported.length,
      skipped: result.skipped.length,
      conflicts: result.conflicts.length,
      dryRun,
      actor,
    })
    return { ...result, snapshot }
  }

  // ══════════════════════════════════════════════════════════
  // 快照下发（P4：变更即推 + 连接恢复补推；周期对账为后续项）
  // ══════════════════════════════════════════════════════════

  /**
   * 组装某服的快照载荷（密码哈希只发给开了 syncAccounts 的服，最小暴露）。
   *
   * 载荷只有三类内容：version（单调版本）+ records（绑定记录）+ 两个逐服开关。
   * 历史说明：绑定后自动晋升的配置原在这里随快照下发，已随功能迁出到 qq-promotion 插件，
   * 本件不再下发该字段（见 config.js 顶部说明）。
   */
  _snapshotPayloadFor(server, version) {
    const flags = serverFlags(this.config, server.id)
    const records = []
    for (const username of this.ledger.usernames()) {
      const rec = this.ledger.getByUsername(username)
      if (!rec) continue
      const item = { username: rec.username, qq: rec.qq }
      if (flags.syncAccounts) item.passwordHash = rec.passwordHash
      records.push(item)
    }
    return {
      version,
      records,
      syncAccounts: flags.syncAccounts,
      syncUuid: flags.syncUuid,
    }
  }

  /**
   * 下发快照到启用服（默认全部）。
   * 永不静默失败：逐服状态写进 pushStatus 并发事件，调用方可原样回给用户。
   */
  async pushSnapshot({ serverIds = null } = {}) {
    const servers = await this.gameOps.enabledServers()
    const targets = serverIds && serverIds.length > 0
      ? servers.filter((s) => serverIds.map(String).includes(String(s.id)))
      : servers
    if (targets.length === 0) {
      return { ok: true, version: this.snapshotVersion, total: 0, servers: [], note: '没有启用中的服务器' }
    }

    const version = this.snapshotVersion + 1
    const results = []
    for (const server of targets) {
      const payload = this._snapshotPayloadFor(server, version)
      try {
        const data = await this.gameOps.pushSnapshot(server, payload)
        const entry = {
          id: server.id,
          name: server.name,
          ok: true,
          count: payload.records.length,
          version,
          hashSent: payload.syncAccounts,
          upstreamVersion: data && data.version != null ? data.version : null,
        }
        results.push(entry)
        this.pushStatus.set(server.id, { ...entry, at: new Date().toISOString() })
      } catch (err) {
        const entry = {
          id: server.id,
          name: server.name,
          ok: false,
          version,
          error: err.message,
          serverHalfMissing: err.serverHalfMissing === true,
        }
        results.push(entry)
        this.pushStatus.set(server.id, { ...entry, at: new Date().toISOString() })
      }
    }

    const okCount = results.filter((r) => r.ok).length
    if (okCount > 0) this.snapshotVersion = version
    for (const r of results) {
      try {
        this.ctx.emit('qqbind/snapshot', { serverId: r.id, ok: r.ok, error: r.error, version })
      } catch {
        /* 无监听者忽略 */
      }
    }
    return { ok: okCount === results.length, version, total: results.length, okCount, servers: results }
  }

  /** 各服快照状态（前端状态区与排障用） */
  snapshotStatus() {
    return {
      version: this.snapshotVersion,
      count: this.ledger.size,
      updatedAt: this.ledger.updatedAt,
      servers: [...this.pushStatus.entries()].map(([id, v]) => ({ serverId: id, ...v })),
    }
  }

  /**
   * 兜底对账：周期补推，防"某次推送丢了但无人察觉"（快照失配 → 免密/豁免悄悄不生效）。
   * 配置改动后调用可立即按新周期重启（不依赖重启宿主）。
   */
  startReconcile() {
    this.stopReconcile()
    const ms = Number(this.config && this.config.snapshot && this.config.snapshot.reconcileIntervalMs) || 0
    if (ms <= 0) return false
    this._reconcile = setInterval(() => {
      this.pushSnapshot().catch((err) => {
        this.ctx.logger?.warn?.(`[qq-bind] 兜底对账下发失败：${err.message}`)
      })
    }, ms)
    // 定时器不应阻止宿主退出
    this._reconcile.unref?.()
    return true
  }

  stopReconcile() {
    if (this._reconcile) {
      clearInterval(this._reconcile)
      this._reconcile = null
    }
  }

  /** 插件被禁用/卸载时由 apply 返回的释放钩子调用 */
  shutdown() {
    this.stopReconcile()
  }

  /**
   * 跨服 UUID 同步（免密）。旧版语义：UUID 只转发、不落台账；
   * 目标 = 开启 syncUuid 的服，排除来源服；kick 由逐服 kickDuplicate 决定。
   */
  async syncUuid(username, uuid, { excludeServerId = null } = {}) {
    const value = String(uuid || '')
    if (!value) return { ok: false, error: '缺少 uuid', servers: [] }
    const servers = await this.gameOps.enabledServers()
    const targets = servers.filter(
      (s) => serverFlags(this.config, s.id).syncUuid && String(s.id) !== String(excludeServerId ?? ''),
    )
    const results = []
    for (const server of targets) {
      const kick = serverFlags(this.config, server.id).kickDuplicate
      try {
        const data = await this._pushUuid(server, username, value, kick)
        results.push({ id: server.id, name: server.name, ok: true, kicked: !!data.kicked })
      } catch (err) {
        results.push({ id: server.id, name: server.name, ok: false, error: err.message })
      }
    }
    return { ok: results.every((r) => r.ok), servers: results, targetCount: targets.length }
  }

  async _pushUuid(server, username, uuid, kick) {
    // 复用 base 既有 UUID 端点（不需要本件新增游戏服端点）
    return this.gameOps.syncUuidToServer(server, { name: username, uuid, kick })
  }

  // ══════════════════════════════════════════════════════════
  // 接入层（扩展点）
  // ══════════════════════════════════════════════════════════

  /** 注册接入方式（Koishi/官方 Node 应用/…）：{ name, authenticate, capabilities, mount, send } */
  registerAdapter(adapter) {
    return this.adapters.register(adapter)
  }

  /** 注册能力：registerCapability(name, handler, meta) → 取消函数 */
  registerCapability(name, handler, meta = {}) {
    return this.capabilities.register(name, handler, meta)
  }

  /** 统一调用入口：先做适配器放行检查，再分发到能力处理器 */
  async invoke(capability, { principal = null, params = {} } = {}) {
    const adapterName = principal && principal.adapter
    if (adapterName && !this.adapters.allows(adapterName, capability)) {
      throw httpError(403, `接入方式 ${adapterName} 未放行能力：${capability}`)
    }
    return this.capabilities.invoke(capability, { principal, params })
  }

  /** 宿主 → 用户/群 下发（适配器未实现则 501） */
  async sendNotify(adapterName, target, message) {
    return this.adapters.send(adapterName, target, message)
  }

  // ══════════════════════════════════════════════════════════
  // 台账变更统一出口（事件 + 快照）
  // ══════════════════════════════════════════════════════════

  /** 由 Ledger 的 onChange 调用；保证"台账变 → 事件 + 快照"不被漏掉 */
  onLedgerChange(evt) {
    if (!evt || !evt.action) return
    this._mutationSeq++
    const eventName = EVENT_OF_ACTION[evt.action]
    if (eventName) {
      try {
        this.ctx.emit(eventName, { ...evt, source: evt.source ?? '' })
      } catch {
        /* 无监听者忽略 */
      }
    }
    if (this.config && this.config.snapshot.pushOnChange === false) return
    this._schedulePush()
  }

  /**
   * 排队一次快照推送（串行执行，避免并发变更引发推送洪水）。
   * 单一推送者设计：推送只由"台账变更"这一条通路触发，任何变更都不可能漏推
   * （旧版缺陷 B1 的根因正是"改名走了另一条通路、没人推"）。
   */
  _schedulePush() {
    this._pushSeq = this._mutationSeq
    const run = async () => {
      this._pushResult = await this.pushSnapshot()
      return this._pushResult
    }
    this._pushQueue = (this._pushQueue || Promise.resolve())
      .catch(() => {})
      .then(run)
      .catch((err) => {
        this._pushResult = {
          ok: false,
          version: this.snapshotVersion,
          total: 0,
          okCount: 0,
          servers: [],
          error: err.message,
        }
        this.ctx.logger?.warn?.(`[qq-bind] 下发快照失败：${err.message}`)
        return this._pushResult
      })
    return this._pushQueue
  }

  /**
   * 等待"本次台账变更"引发的推送完成，并返回其结果（业务方法用它回显给调用方）。
   * pushOnChange=false 时改为就地推送一次，保证变更方法永远拿到真实结果。
   */
  async _ensurePushed() {
    if (this._pushQueue && this._pushSeq === this._mutationSeq) return this._pushQueue
    if (!this.config || this.config.snapshot.pushOnChange === false) return this._schedulePush()
    if (!this._pushQueue) return this._schedulePush()
    return this._pushQueue
  }

  // ── 内部工具 ──────────────────────────────────────────────

  /** 1:1 前置校验（旧版文案） */
  _assertFree(qq, player) {
    const byQq = this.ledger.getByQq(qq)
    if (byQq) throw httpError(409, '该 QQ 已绑定角色', { owner: byQq.username })
    const byName = this.ledger.getByUsername(player)
    if (byName) {
      throw httpError(409, `该角色已绑定 QQ：${byName.qq}（如需更换请用「改绑」）`, {
        boundQq: byName.qq,
      })
    }
  }

  /** 时长（软依赖 online-stats；缺失时明确 unavailable，不假装 0） */
  async _playtimeAll() {
    const os = optionalService(this.ctx, 'onlineStats')
    if (!os || typeof os.getAllPlaytime !== 'function') return null
    try {
      const out = await os.getAllPlaytime()
      return out && typeof out === 'object' ? out : null
    } catch {
      return null
    }
  }

  /** 单玩家时长（player-info 用） */
  async _playtimeOf(username) {
    const os = optionalService(this.ctx, 'onlineStats')
    if (!os) return { total: null, servers: {}, unavailable: true, hint: '未安装 online-stats 插件' }
    try {
      if (typeof os.getPlayerStats === 'function') {
        const st = await os.getPlayerStats(username)
        const pt = st && st.playtime
        if (pt && typeof pt === 'object') {
          return {
            total: Number(pt.total ?? 0),
            servers: pt.servers ?? {},
            source: 'online-stats',
          }
        }
        if (typeof pt === 'number') return { total: pt, servers: {}, source: 'online-stats' }
      }
      const all = await this._playtimeAll()
      if (all && all.stats) {
        return { total: Number(all.stats[username] ?? 0), servers: {}, source: 'online-stats' }
      }
    } catch {
      /* 落到 unavailable */
    }
    return { total: null, servers: {}, unavailable: true, hint: '时长数据暂不可用' }
  }

  /** 我的信息（机器人 /api/bot/player-info）：主服游戏数据 + 多服时长 */
  async playerInfo(identifier, { serverId = '' } = {}) {
    const rec = this.ledger.get(identifier)
    if (!rec) throw httpError(404, '该角色未绑定 QQ')

    const servers = await this.gameOps.enabledServers()
    const preferred = serverId || this.config.binding.defaultServerId
    const main =
      (preferred && servers.find((s) => String(s.id) === String(preferred))) || servers[0] || null
    if (!main) throw httpError(400, '尚未配置任何启用服务器')

    const game = await this.gameOps.playerData(main, rec.username)
    const playtime = await this._playtimeOf(rec.username)
    return {
      username: rec.username,
      player: rec.username,
      qq: rec.qq,
      server: main.name,
      boundAt: rec.boundAt,
      game: {
        player: game.player,
        group: game.group,
        registered: game.registered,
        deaths: game.deaths,
        fishing_quests: game.fishing_quests,
        found: game.found,
      },
      playtime,
      onlineMinutes: playtime.total,
    }
  }
}

/** 随机密码（用户随后用「改密码」设置；免密登录不依赖它） */
function randomPassword() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'
  const bytes = randomBytes(RANDOM_PASSWORD_BYTES)
  let out = ''
  for (const b of bytes) out += alphabet[b % alphabet.length]
  return out
}

// ══════════════════════════════════════════════════════════════
// apply
// ══════════════════════════════════════════════════════════════

export function apply(ctx) {
  const dataDir = ctx.paths.dataOf('qq-bind')
  const configFile = path.join(dataDir, 'config.json')
  const ledgerFile = path.join(dataDir, 'bindings.json')
  const auditFile = path.join(dataDir, 'audit.jsonl')
  /** 昵称缓存（独立文件：绝不写进台账，理由见 nicknames.js 文件头） */
  const nicknameFile = path.join(dataDir, 'nicknames.json')

  const service = new QqBindService(ctx)
  service.configFile = configFile

  /** 同步占位服务：让后续同步代码立刻可用 ctx.qqBind（异步初始化在下面补） */
  ctx.qqBind = service

  const ready = (async () => {
    await mkdir(dataDir, { recursive: true })
    const { config, existed } = await loadConfig(configFile)
    service.config = config
    if (!existed) await saveConfig(configFile, config)

    service.audit = new AuditLog({ file: auditFile })
    service.ledger = new Ledger({ file: ledgerFile, onChange: (evt) => service.onLedgerChange(evt) })
    await service.ledger.load()
    service.nicknames = new NicknameStore({ file: nicknameFile })
    service.gameOps = createGameOps({ ctx })

    ctx.logger?.info?.(
      `[qq-bind] 台账就绪：${service.ledger.size} 条绑定（${ledgerFile}）`,
    )
    /**
     * 昵称缓存读一次只为两件事：把条数打进日志（排障时一眼看到缓存是否可用），
     * 以及让"文件损坏"在启动日志里就暴露出来（getNicknameMap 失败只降级 + 警告，绝不抛错）。
     */
    const nicknameCount = Object.keys(await service.nicknames.getNicknameMap()).length
    ctx.logger?.info?.(`[qq-bind] 昵称缓存就绪：${nicknameCount} 条（${nicknameFile}）`)
    return service
  })()
  /** 初始化完成信号：其他插件/适配器可 await ctx.qqBind.ready 后再读台账 */
  service.ready = ready

  // 绑定域能力（本件自己拥有的那一支）
  service.registerCapability(
    'binding.bind',
    async ({ principal, params }) => {
      await ready
      return service.bind({
        qq: params.qq,
        player: params.player,
        serverId: params.serverId || '',
        source: principal?.adapter ? `${principal.adapter}:${principal.kind || 'bot'}` : 'api',
      })
    },
    { legacy: { path: '/api/bot/bind', method: 'post' }, description: '绑定已有角色' },
  )

  service.registerCapability(
    'binding.register',
    async ({ principal, params }) => {
      await ready
      return service.registerPlayer({
        qq: params.qq,
        player: params.player,
        source: principal?.adapter ? `${principal.adapter}:${principal.kind || 'bot'}` : 'api',
      })
    },
    { legacy: { path: '/api/bot/register', method: 'post' }, description: '注册新角色' },
  )

  service.registerCapability(
    'binding.changePassword',
    async ({ principal, params }) => {
      await ready
      return service.changePassword({
        username: principal?.boundUsername || params.username,
        qq: params.qq,
        password: params.password,
        source: principal?.adapter ? `${principal.adapter}:${principal.kind || 'bot'}` : 'api',
      })
    },
    {
      legacy: { path: '/api/bot/change-password', method: 'post' },
      requireBound: true,
      description: '修改密码（全服覆盖免密哈希）',
    },
  )

  service.registerCapability(
    'binding.resolve',
    async ({ principal, params }) => {
      await ready
      return service.playerInfo(params.qq || principal?.qq || params.username || principal?.boundUsername, {
        serverId: params.serverId || '',
      })
    },
    {
      legacy: { path: '/api/bot/player-info', method: 'get' },
      requireBound: true,
      description: '我的信息（身份 + 游戏数据 + 多服时长）',
    },
  )

  service.registerCapability(
    'binding.status',
    async ({ params }) => {
      await ready
      const rec = service.ledger.get(params.qq || params.username || params.player)
      if (!rec) return { bound: false }
      return { bound: true, username: rec.username, qq: rec.qq, boundAt: rec.boundAt }
    },
    { description: '查询绑定状态（新接入方式用，无旧路径）' },
  )

  /**
   * ── 昵称域能力（两条**必须保留旧路径**的机器人接口）──
   *
   * 这两个旧路径是机器人侧（TsWeb/plugin-son/koishi/common/plugins/nickname.ts）已经跑通的接口，
   * 路径与方法一字不改：机器人每 15 秒轮询 GET /api/bot/nickname-task 领取任务，
   * 取完 POST /api/bot/qq-nickname 回报。宿主**没有到机器人的出站通道**，
   * 所以只能是机器人来领任务——不要改成宿主主动请求。
   *
   * 鉴权由 legacy-http 适配器负责（X-Bot-Token 头或 ?token= 查询参数，
   * adapters/legacy-http.js:124-143），能力处理器里**不要**再校验一遍 token。
   */
  service.registerCapability(
    'nickname.claim',
    async () => {
      await ready
      const claimed = service.claimNicknameTask()
      if (!claimed) return { task: null } // 无待领取任务：机器人据此什么都不做，不产生副作用
      service.ctx.logger?.info?.(`[qq-bind] 机器人领取昵称任务：${claimed.id}（${claimed.total} 个 QQ）`)
      return { task: claimed }
    },
    {
      legacy: { path: '/api/bot/nickname-task', method: 'get' },
      description: '领取昵称刷新任务（机器人定时轮询；无任务返回 task:null）',
    },
  )

  service.registerCapability(
    'nickname.report',
    async ({ params }) => {
      await ready
      // source 固定为 bot（旧版 saveNicknames(entries, { source: 'bot' }) 同值）：
      // 这条记录表达的是"昵称来自机器人侧的主动查询"，与经哪个适配器上报无关
      return service.reportNicknames({ entries: params.entries, taskId: params.taskId, source: 'bot' })
    },
    {
      legacy: { path: '/api/bot/qq-nickname', method: 'post' },
      description: '上报 QQ 昵称（机器人取完回报；逐条失败原因原样回给页面）',
    },
  )

  // 内置兼容适配器：让旧版 Koishi 机器人零改动
  service.registerAdapter(
    createLegacyHttpAdapter({
      ctx,
      capabilities: service.capabilities,
      adapters: service.adapters,
      getConfig: () => service.config,
      identify: (principal, params) => service.identify(principal, params),
      audit: service.audit,
    }),
  )

  // ── 管理接口（verifyAuth + requireAdmin；不经适配器）──
  const app = ctx.webServer.app
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]
  const fail = (res, err) => {
    const status = err.status || 500
    const body = { error: err.message }
    for (const key of ['failed', 'conflicts', 'servers', 'owner', 'boundQq', 'serverHalfMissing', 'hint']) {
      if (err[key] !== undefined) body[key] = err[key]
    }
    if (!res.headersSent) res.status(status).json(body)
  }
  const wrap = (handler) => async (req, res) => {
    try {
      await ready
      res.json(await handler(req, res))
    } catch (err) {
      fail(res, err)
    }
  }

  app.get('/api/qq-bind/list', ...admin, wrap(async (req) => {
    const q = req.query || {}
    return service.list({
      keyword: q.keyword || '',
      page: Number(q.page) || 1,
      pageSize: Number(q.pageSize) || 50,
    })
  }))

  /**
   * 批量查 QQ 号 + 昵称（前端半用：其它插件的前端拿不到宿主服务，只能走 HTTP）。
   * 权限与其它 /api/qq-bind/* 管理路由一致。
   * 只做一次台账查询（qqMap）与一次昵称缓存读取（nicknameMap），
   * 不在路由里重复实现查找逻辑。
   *
   * 响应字段：
   *   ok / qq / missing / count —— **语义与取值一字未改**（老调用方按原样读）
   *   nickname                  —— 新增：{ "<传入名字原文>": "<昵称>" }，
   *                                只含"既已绑定、又已取到昵称"的名字；
   *                                没绑定或昵称尚未获取的名字**不出现**（前端据此只显示 QQ 号）
   */
  app.post('/api/qq-bind/lookup', ...admin, wrap(async (req) => {
    const b = req.body || {}
    if (!Array.isArray(b.names)) throw httpError(400, '缺少参数: names（应为字符串数组）')
    if (b.names.length > LOOKUP_LIMIT) {
      throw httpError(400, `单次查询上限 ${LOOKUP_LIMIT} 个名字（本次 ${b.names.length} 个）`)
    }
    const names = b.names.map((n) => String(n ?? ''))
    const qq = service.qqMap(names)
    // missing 与 qq 的键口径一致（名字原文），并去重，便于前端直接提示"这些名字没查到"。
    // 判定用"自有键集合"而不是 qq[name] === undefined：角色名若叫 toString / constructor，
    // 读属性会命中原型链上的成员，未绑定的名字就会被漏报（静默给错答案）。
    const found = new Set(Object.keys(qq))
    const missing = []
    for (const name of names) {
      if (!found.has(name) && !missing.includes(name)) missing.push(name)
    }

    // 昵称：把本批已绑定的 QQ 一次性取出缓存（只读一次昵称文件），再按名字原文回键。
    // 取不到昵称就不回键——"有昵称用昵称、没有退回 QQ 号"的口径由调用方按"键是否存在"实现。
    const nicknames = await service.nicknameMap([...found].map((name) => qq[name]))
    const nickname = {}
    for (const name of found) {
      const nick = ownGet(nicknames, qq[name])
      if (nick) defineKey(nickname, name, nick)
    }
    return { ok: true, qq, nickname, missing, count: found.size }
  }))

  /**
   * 登记一次「获取昵称」任务：POST /api/qq-bind/nickname-refresh（admin）。
   *
   * 旧版是 POST /api/bot/nickname-refresh（admin，botController.js:750-773）；
   * 新版管理面统一在 /api/qq-bind/*，机器人面仍保留旧路径（见 nickname.claim 能力）。
   * 待取 QQ 从**台账**取（全部已绑定、去重），已有进行中的任务则原样返回同一个任务。
   */
  app.post('/api/qq-bind/nickname-refresh', ...admin, wrap(async (req) => {
    const actor = req.user?.username || 'admin'
    const task = service.requestNicknameTask({ actor, qqs: service.boundQqs() })
    await service.audit.append('qqbind.nickname.refresh', {
      actor,
      taskId: (task && task.id) || '',
      total: (task && task.total) || 0,
    })
    ctx.logger?.info?.(`[qq-bind] 登记昵称刷新任务: ${(task && task.id) || ''} 待获取 ${(task && task.total) || 0} 个 QQ`)
    return { ok: true, task }
  }))

  /**
   * 昵称刷新任务状态：GET /api/qq-bind/nickname-status（admin）。
   * 管理页每 2 秒轮询；过期由服务端**惰性判定**，超时会带出 error 说明原因（旧版 botController.js:779-785）。
   */
  app.get('/api/qq-bind/nickname-status', ...admin, wrap(async () => ({
    ok: true,
    task: service.getNicknameTask(),
  })))

  app.get('/api/qq-bind/status', ...admin, wrap(async () => ({
    ledger: {
      file: ledgerFile,
      count: service.ledger.size,
      updatedAt: service.ledger.updatedAt,
      schema: service.ledger.schema,
    },
    snapshot: service.snapshotStatus(),
    adapters: service.adapters.list(),
    capabilities: service.capabilities.list(),
    config: redactConfig(service.config),
    configFile,
  })))

  app.post('/api/qq-bind/bind', ...admin, wrap(async (req) => {
    const b = req.body || {}
    return service.bind({
      qq: b.qq,
      player: b.player || b.username,
      serverId: b.serverId || '',
      source: 'admin',
    })
  }))

  app.post('/api/qq-bind/rebind', ...admin, wrap(async (req) => {
    const b = req.body || {}
    return service.rebind({ username: b.username, newQq: b.qq || b.newQq, source: 'admin' })
  }))

  app.post('/api/qq-bind/transfer', ...admin, wrap(async (req) => {
    const b = req.body || {}
    return service.transfer({
      fromUsername: b.username || b.fromUsername,
      toUsername: b.newPlayer || b.toUsername,
      qq: b.qq,
      source: 'admin',
    })
  }))

  app.post('/api/qq-bind/unbind', ...admin, wrap(async (req) => {
    const b = req.body || {}
    return service.unbind({ username: b.username, qq: b.qq, source: 'admin' })
  }))

  app.post('/api/qq-bind/batch', ...admin, wrap(async (req) => {
    const b = req.body || {}
    const action = String(b.action || '').trim()
    if (action !== 'unbind') throw httpError(400, `不支持的批量动作：${action || '(空)'}`)
    return service.batchUnbind(b.users, { source: 'admin' })
  }))

  // 历史说明：原「导入旧版台账」入口 POST /api/qq-bind/import 已迁至 legacy-import 插件
  // （plugins/legacy-import/），本件只保留落库方法 service.importLegacy（见本文件 723 行注释）。

  app.post('/api/qq-bind/playtime-refresh', ...admin, wrap(async () => {
    const os = optionalService(ctx, 'onlineStats')
    if (!os || typeof os.getAllPlaytime !== 'function') {
      throw httpError(501, '未安装 online-stats 插件，无法刷新时长', {
        missingPlugin: 'online-stats',
      })
    }
    // online-stats 自身按分钟采样；这里主动拉一次全量累计，触发其向各服取数
    const data = await os.getAllPlaytime()
    return { ok: true, refreshed: Object.keys((data && data.stats) || {}).length }
  }))

  app.get('/api/qq-bind/audit', ...admin, wrap(async (req) => ({
    rows: await service.audit.tail(Number((req.query || {}).limit) || 100),
  })))

  app.get('/api/qq-bind/config', ...admin, wrap(async () => ({
    config: redactConfig(service.config),
    configFile,
  })))

  app.post('/api/qq-bind/config', ...admin, wrap(async (req) => {
    const b = req.body || {}
    const updates = b.updates && typeof b.updates === 'object' ? b.updates : null
    if (updates) {
      for (const [key, value] of Object.entries(updates)) setByPath(service.config, key, value)
    } else if (b.path) {
      setByPath(service.config, b.path, b.value)
    } else {
      throw httpError(400, '缺少参数: path/value 或 updates')
    }
    service.config = normalizeConfig(service.config)
    await saveConfig(configFile, service.config)
    service.startReconcile() // 周期改动即时生效（0 = 关闭）
    await service.audit.append('qqbind.config.set', { actor: 'admin', keys: Object.keys(updates || { [b.path]: true }) })
    // 配置变更必须立刻下发：快照载荷里带着 syncAccounts / syncUuid 等逐服开关，
    // 不推的话管理员的改动要等"下一次台账变更 / 服务器重连 / 对账周期"才生效，
    // 而 reconcileIntervalMs=0（关闭周期对账）时可能**永远不生效**——这正是
    // "界面显示已启用、实际没生效"那类静默失效。结果如实回显，不假装成功。
    const snapshot = await service._schedulePush()
    return { ok: true, config: redactConfig(service.config), snapshot }
  }))

  /**
   * bot token 的轮换（前端「一键重新生成」/「手动设置新值」）。
   *
   * 权限与其它 /api/qq-bind/* 管理路由一致。
   * 请求体：{ token?: string }
   *   - 不传（或缺省为 null/undefined）→ 服务端生成：32 字节 CSPRNG 随机 → base64url，
   *     固定 43 个字符（256 位熵，不可暴力猜）
   *   - 传了 → 用它作为新 token（必须是**非空字符串**，否则 400；不把空串悄悄当"生成模式"，
   *     否则前端把用户误清空的值当成"重新生成"，用户拿到的 token 与预期不符）
   *
   * 保存走的是**与 POST /api/qq-bind/config 完全相同的路径**
   * （setByPath 白名单校验 → normalizeConfig 归一 → saveConfig 原子落盘 + .bak），
   * 不自己拼文件写入：否则会绕开归一逻辑，写出"形似合法、实际缺字段"的配置。
   */
  app.post('/api/qq-bind/token/rotate', ...admin, wrap(async (req) => {
    const b = req.body || {}
    let token = ''
    if (b.token === undefined || b.token === null) {
      token = randomBytes(TOKEN_BYTES).toString('base64url')
    } else if (typeof b.token === 'string' && b.token.trim() !== '') {
      token = b.token
    } else {
      throw httpError(400, 'token 必须是非空字符串（不传该字段则由服务端随机生成）')
    }

    // 环境变量优先：applyEnv（config.js:66-74）在**加载时**用 TSWEB_QQBIND_TOKEN 覆盖
    // adapters['legacy-http'].token。进程环境里存在且非空时，写进配置的新值下一次加载
    // 又会被环境变量盖掉，也就是"现在改了、重启后等于没改"。
    // 这种情况必须如实告知，不能返回一个看起来成功的 200 让管理员以为已经换掉。
    const envToken = String(process.env.TSWEB_QQBIND_TOKEN ?? '')
    const tokenFromEnv = envToken.trim() !== ''

    const tokenRotatedAt = new Date().toISOString()
    setByPath(service.config, 'adapters.legacy-http.token', token)
    // tokenRotatedAt 不在 EDITABLE_PATHS 白名单里（它不是管理员可任意编辑的项，
    // 而是轮换动作的时间戳），所以在归一前直接写入内存配置
    service.config.adapters['legacy-http'].tokenRotatedAt = tokenRotatedAt
    service.config = normalizeConfig(service.config)
    await saveConfig(configFile, service.config)
    // 审计只记长度与来源，**不记明文**（审计文件会被读出来给人看）
    await service.audit.append('qqbind.token.rotate', {
      actor: 'admin',
      tokenFromEnv,
      length: token.length,
      generated: b.token === undefined || b.token === null,
    })

    // 明文 token **只在这一条响应里**返回，这是刻意的：
    // 前端需要一次性把新 token 交给机器人配置，之后 GET /api/qq-bind/config（以及 /status）
    // 永远只回 redactConfig 的掩码（abc***xy（已设置，长度 N）），不提供任何明文回读通道。
    //
    // tokenFromEnv / effective 的确切语义（别让调用方误读）：
    //   - 适配器是**每请求实时读内存配置**（adapters/legacy-http.js:125、:131 的 getConfig()），
    //     所以新 token 在本进程内立即能通过 /api/bot 鉴权；
    //   - 但只要环境变量还在，**下一次加载**时 applyEnv 又会把配置里的 token 覆盖回去
    //     （config.js:66-74），也就是"重启后又变回环境变量的 token"。
    //   - effective=false 说的就是这件事：这个新 token 不会被长期采用（不是"当前一秒无效"）。
    //     本件宁可把话说全，也不报一个看着成功的 200。
    return {
      ok: true,
      token,
      tokenSet: true,
      tokenRotatedAt,
      tokenFromEnv,
      effective: !tokenFromEnv,
      ...(tokenFromEnv
        ? {
            warning:
              '环境变量 TSWEB_QQBIND_TOKEN 优先于配置文件：新 token 已写入配置文件，' +
              '但只要该环境变量还在，下次启动时配置里的值又会被它覆盖（重启后新 token 不生效）；' +
              '要让新 token 长期生效，请先移除该环境变量再重启宿主',
          }
        : {}),
    }
  }))

  // ── 连接恢复 / 服务器加载完成后补推快照（P4）──
  const repush = (why) => {
    if (service.config && service.config.snapshot.pushOnServerConnect === false) return
    ready
      .then(() => service.pushSnapshot())
      .then((r) => ctx.logger?.info?.(`[qq-bind] ${why}后补推快照：成功 ${r.okCount ?? 0}/${r.total ?? 0}`))
      .catch((err) => ctx.logger?.warn?.(`[qq-bind] ${why}后补推快照失败：${err.message}`))
  }
  ctx.on('push/connected', () => repush('服务器连接建立'))
  ctx.on('servers/loaded', () => repush('服务器列表加载'))

  // 初始化完成后按配置启动兜底对账
  ready.then(() => service.startReconcile()).catch(() => {})

  // 历史说明：原终端命令 qqbind-import 已迁至 legacy-import 插件（plugins/legacy-import/，
  // 终端命令名 legacy-import）；本件只保留落库方法 service.importLegacy，不再注册任何导入入口。

  ctx.logger?.info?.(`[qq-bind] 已挂载：接入适配器 ${service.adapters.list().map((a) => a.name).join(', ') || '(无)'}；数据目录 ${dataDir}`)

  // cordis 释放钩子（宿主在插件禁用/卸载时调用，见 plugins/online-stats/index.js:916-918 同款约定）
  return () => service.shutdown()
}
