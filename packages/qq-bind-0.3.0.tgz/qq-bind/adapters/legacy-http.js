/**
 * 内置"旧版兼容"接入适配器（legacy-http）
 *
 * 作用：把承载能力的旧路径投影出来，使**旧版 Koishi 机器人零改动**继续工作。
 * 依据：docs/QQ绑定功能对接文档.md §3.1-3.3（字段契约逐条对着 plugin-son/koishi 的读法核过）
 *
 * 实现要点：
 *   1. 只挂一个中间件 `app.use('/api/bot', ...)`，**请求时**按能力注册表的 meta.legacy 动态查表
 *      → 别的插件晚注册能力也无需再挂路由（设计 D10：旧路径是数据不是代码）
 *   2. 鉴权：X-Bot-Token 头或 ?token= 查询参数（旧版 backend/routes/botRoutes.js:14）；
 *      token 为空 → 503（只关闭本适配器，不影响其它接入方式）
 *   3. 限流与审计按适配器分桶（旧版是单一全局 token，没有这一层）
 *   4. 响应统一 `{ success:true, status:'ok', ...payload }`，错误统一 `{ error, ...extra }`，
 *      与旧版 botController 的形状兼容（机器人只读 payload 里的字段）
 *
 * 注意：本文件只能出现"HTTP/路径/令牌"概念，不得出现任何机器人框架概念。
 */
import { httpError } from '../ledger.js'

/** 挂载前缀 */
const MOUNT = '/api/bot'

/** body 兜底解析的体积上限（机器人命令都是小 JSON；越大越容易被滥用） */
const MAX_BODY_BYTES = 1024 * 1024

/**
 * 读取请求 body（仅在需要时）。
 *
 * 为什么必须兜底：宿主里挂 `express.json()` 的是 market 插件（`plugins/market/index.js:88`），
 * 那是**全局中间件**，是否先生效取决于插件加载顺序——若本件先加载，`/api/bot` 的处理函数
 * 会在解析器之前执行，`req.body` 为空，机器人发来的 `qq/player/serverId` 全部丢失，
 * 报出"缺少参数: qq"这种把责任指向机器人的误导错误。
 *
 * 这里不 import express：宿主约定只有 `web` 插件（webServer 的拥有者）import 它，
 * 其余插件只用 `ctx.webServer.app`。自行按流读取即可，且对加载顺序免疫。
 */
async function readJsonBody(req) {
  if (req.body && typeof req.body === 'object' && !Array.isArray(req.body)) return req.body
  const method = String(req.method || 'GET').toUpperCase()
  if (method === 'GET' || method === 'HEAD') return null
  const ctype = String((req.headers && req.headers['content-type']) || '')
  if (!ctype.includes('json')) return null

  const chunks = []
  let size = 0
  for await (const chunk of req) {
    size += chunk.length
    if (size > MAX_BODY_BYTES) return null
    chunks.push(chunk)
  }
  if (chunks.length === 0) return null
  try {
    const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'))
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null
  } catch {
    return null
  }
}

/** 失败响应里一并透传的附加字段（机器人据此给出更准确的提示） */
const PASSTHROUGH = [
  'conflict',
  'servers',
  'candidates',
  'owner',
  'boundQq',
  'needBind',
  'missingPlugin',
  'missingCapability',
  'hint',
  'serverId',
  'serverHalfMissing',
  'retryAfter',
]

export function createLegacyHttpAdapter({ ctx, capabilities, adapters, getConfig, identify, audit }) {
  /** 滑动窗口限流（本适配器独立分桶） */
  const hits = []
  function takeSlot(perMinute) {
    const limit = Number(perMinute) || 0
    if (limit <= 0) return false
    const now = Date.now()
    while (hits.length > 0 && now - hits[0] > 60_000) hits.shift()
    if (hits.length >= limit) return true
    hits.push(now)
    return false
  }

  function reject(req, res, err) {
    const status = err.status || 500
    const body = { error: err.message }
    for (const key of PASSTHROUGH) {
      if (err[key] !== undefined) body[key] = err[key]
    }
    if (status === 401 || status === 429 || status === 503) {
      // 鉴权/限流类拒绝要留痕（旧版这类事件只在进程日志里）
      audit
        ?.append('qqbind.bot.reject', {
          adapter: 'legacy-http',
          status,
          path: `${req.method} ${req.baseUrl || ''}${req.path || ''}`,
          reason: err.message,
        })
        .catch(() => {})
    }
    if (!res.headersSent) res.status(status).json(body)
  }

  function wrap(result) {
    if (result === undefined || result === null) return { success: true, status: 'ok' }
    if (typeof result === 'object' && !Array.isArray(result)) {
      return { success: true, status: 'ok', ...result }
    }
    return { success: true, status: 'ok', data: result }
  }

  return {
    name: 'legacy-http',
    description: '内置兼容适配器：/api/bot/* + 机器人令牌（旧版 Koishi 机器人零改动）',
    /** 兼容层需要放行全部能力（旧版路径横跨绑定/在线/进度/投票） */
    capabilities: ['*'],

    /** 鉴权：返回 principal 或抛错（401/429/503） */
    async authenticate(req) {
      const cfg = getConfig()
      if (!cfg || !cfg.adapters) {
        throw httpError(503, 'QQ 绑定插件正在初始化（配置尚未就绪），请稍后重试')
      }
      const lh = cfg.adapters['legacy-http'] || {}
      if (lh.enabled === false) throw httpError(503, '机器人接口已关闭（legacy-http 适配器未启用）')
      const expected = String(lh.token || '')
      if (!expected) throw httpError(503, '机器人接口未配置令牌（请在 QQ 绑定页设置机器人密钥）')

      const provided = String(
        (req.get && req.get('x-bot-token')) || (req.query && req.query.token) || '',
      )
      if (provided !== expected) throw httpError(401, '机器人密钥不正确')

      if (takeSlot(lh.rateLimit && lh.rateLimit.perMinute)) {
        throw httpError(429, '操作过于频繁，请稍后再试', { retryAfter: 60 })
      }
      return { kind: 'bot', adapter: 'legacy-http', authenticatedAt: Date.now() }
    },

    mount() {
      const app = ctx.webServer.app

      app.use(MOUNT, async (req, res) => {
        const fullPath = `${req.baseUrl || ''}${req.path || ''}`

        // 先鉴权、后查路径：否则未鉴权者可从 404/401 的差别枚举出"哪些能力已注册"（指纹信息）
        let principal
        try {
          principal = await adapters.authenticate('legacy-http', req)
          if (!principal) throw httpError(401, '机器人密钥不正确')
        } catch (err) {
          return reject(req, res, err)
        }

        const capability = capabilities.findByLegacy(req.method, fullPath)
        if (!capability) {
          // 三种情形必须分开（混同会让管理员无从判断该修哪里）：
          //   在旧版命令目录里但没人注册 → 501 + 指明装哪个插件（P6 验收要求）
          //   目录里也没有               → 404（命令拼错，或伪造请求）
          const known = capabilities.catalogFor(req.method, fullPath)
          if (known) {
            return reject(
              req,
              res,
              httpError(
                501,
                `该命令需要「${known.provider}」提供的能力 ${known.capability}（当前未注册）`,
                {
                  missingCapability: known.capability,
                  missingPlugin: known.provider,
                  hint: `请安装/启用提供 ${known.capability} 的插件（推测：${known.provider}）`,
                },
              ),
            )
          }
          return reject(req, res, httpError(404, `未知的机器人命令：${req.method} ${fullPath}`))
        }
        if (!adapters.allows('legacy-http', capability.name)) {
          return reject(req, res, httpError(403, `该接入方式未放行能力：${capability.name}`))
        }

        // 参数：query 与 JSON body 合并；token 不进入业务参数（避免泄漏进审计与日志）
        const params = {}
        if (req.query && typeof req.query === 'object') Object.assign(params, req.query)
        const body = await readJsonBody(req)
        if (body) Object.assign(params, body)
        delete params.token

        try {
          // 身份补全属于领域逻辑，放在核心（适配器不碰台账）
          const enriched = identify ? await identify(principal, params) : principal
          const result = await capabilities.invoke(capability.name, { principal: enriched, params })
          if (!res.headersSent) res.json(wrap(result))
        } catch (err) {
          reject(req, res, err)
        }
      })

      // 路由由宿主按 apply 记账并在卸载时摘除（src/loader.js:54-62），此处无需手工反注册
      return null
    },
  }
}
