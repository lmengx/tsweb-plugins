/**
 * 接入层：适配器注册表 + 能力注册表（设计 §3.5）
 *
 * 硬约束：本文件不得出现任何机器人框架概念（不认 Koishi / 群消息 / 卡片 / 指令前缀）。
 *   - 能力注册表：插件按"能力名"注册处理器，核心按名分发
 *   - 适配器注册表：接入方式（Koishi/官方 Node 应用/…）负责鉴权与协议投影
 *
 * 两条必须遵守的工程约束（违反即"看起来成功、实际没生效"）：
 *   1. mount 必须**同步**完成路由注册——宿主用 AsyncLocalStorage 在 apply 作用域内给新增
 *      Express layer 记账（src/loader.js:54-62、:229），异步注册的 layer 不会归属本插件，
 *      disable 时摘不掉。故 mount 返回 thenable 直接抛错。
 *   2. 能力"注册一次，所有适配器可见"：旧路径不做硬编码表，而是由能力自带的
 *      meta.legacy 描述，适配器在**请求时**动态查表 → 别的插件晚注册能力也无需再挂路由。
 */
import { httpError } from '../ledger.js'

/**
 * 能力名：<域>.<动作>
 *   - 域：小写字母开头，允许小写字母/数字/连字符（binding、online、vote）
 *   - 动作：字母开头，允许大小写字母/数字/连字符（bind、changePassword、vote-cast）
 */
const CAPABILITY_NAME_RE = /^[a-z][a-z0-9-]*\.[a-zA-Z][a-zA-Z0-9-]*$/

/** 缺能力时提示该装哪个插件（旧版把一切都塞在 botController，没有这个维度） */
const PROVIDER_HINTS = {
  online: 'online-stats',
  boss: '进度类插件',
  vote: '投票类插件',
  server: 'servers',
  binding: 'qq-bind',
  nickname: 'qq-bind',
}

function providerHint(name) {
  const domain = String(name).split('.')[0]
  return PROVIDER_HINTS[domain] || '对应域插件'
}

/**
 * 旧版机器人**全部**命令目录（路径 + 方法 → 能力名 + 提供方）。
 *
 * 为什么需要它（而不是只靠"已注册的能力"反查）：
 * 未注册的路径如果直接回 404「未知的机器人命令」，机器人只能报一句含糊的话，
 * 管理员无从知道是"命令写错了"还是"插件没装"。有了目录就能区分三种情形：
 *   - 已注册            → 正常分发
 *   - 在目录但未注册    → 501 + 指明该装哪个插件（P6 验收要求）
 *   - 不在目录          → 404（真拼错/伪造请求）
 * 数据来源：旧 Koishi 客户端实际发出的请求（`TsWeb/plugin-son/koishi/common/plugins/{group,private}.ts`），
 * 逐条核对过方法，不是照文档猜的。
 * 其中两条昵称路径不来自命令处理器，而来自**定时轮询插件**
 * （`TsWeb/plugin-son/koishi/common/plugins/nickname.ts`：每 15 秒领任务、取完回报），
 * 方法与路径同样对着该文件核过。
 */
export const LEGACY_CATALOG = [
  { path: '/api/bot/servers', method: 'GET', capability: 'server.list', provider: 'servers' },
  { path: '/api/bot/online', method: 'GET', capability: 'online.list', provider: 'online-stats' },
  { path: '/api/bot/boss-progress', method: 'GET', capability: 'boss.progress', provider: '进度类插件（尚未实现）' },
  { path: '/api/bot/votes', method: 'GET', capability: 'vote.list', provider: '投票类插件（尚未实现）' },
  { path: '/api/bot/vote-cast', method: 'POST', capability: 'vote.cast', provider: '投票类插件（尚未实现）' },
  { path: '/api/bot/vote-propose', method: 'POST', capability: 'vote.propose', provider: '投票类插件（尚未实现）' },
  { path: '/api/bot/bind', method: 'POST', capability: 'binding.bind', provider: 'qq-bind' },
  { path: '/api/bot/register', method: 'POST', capability: 'binding.register', provider: 'qq-bind' },
  { path: '/api/bot/change-password', method: 'POST', capability: 'binding.changePassword', provider: 'qq-bind' },
  { path: '/api/bot/player-info', method: 'GET', capability: 'binding.resolve', provider: 'qq-bind' },
  { path: '/api/bot/nickname-task', method: 'GET', capability: 'nickname.claim', provider: 'qq-bind' },
  { path: '/api/bot/qq-nickname', method: 'POST', capability: 'nickname.report', provider: 'qq-bind' },
]

/** 统一入口错误：带 status，路由层直接据此回状态码 */
function notImplemented(capability) {
  return httpError(501, `能力未注册：${capability}`, {
    missingCapability: capability,
    missingPlugin: providerHint(capability),
    hint: `请安装/启用提供 ${capability} 的插件（推测：${providerHint(capability)}）`,
  })
}

export class CapabilityRegistry {
  constructor() {
    /** @type {Map<string, {name:string, handler:Function, meta:object}>} */
    this._caps = new Map()
  }

  /**
   * 注册能力。
   * @param {string} name                能力名，如 online.list
   * @param {Function} handler           async ({ principal, params }) => payload
   * @param {object} [meta]              { legacy:{path,method}, requireBound, description, owner }
   * @returns {Function} 取消注册函数（disable 时调用）
   */
  register(name, handler, meta = {}) {
    const key = String(name || '').trim()
    if (!CAPABILITY_NAME_RE.test(key)) {
      throw new Error(`能力名不合法：${name}（应形如 <域>.<动作>，如 online.list）`)
    }
    if (typeof handler !== 'function') throw new Error(`能力 ${key} 缺少 handler 函数`)
    if (this._caps.has(key)) throw new Error(`能力已注册：${key}`)

    const normalized = { ...meta }
    if (meta.legacy) {
      const p = String(meta.legacy.path || '').trim()
      if (!p.startsWith('/')) throw new Error(`能力 ${key} 的 legacy.path 必须以 / 开头`)
      normalized.legacy = {
        path: p.length > 1 && p.endsWith('/') ? p.slice(0, -1) : p,
        method: String(meta.legacy.method || 'get').toUpperCase(),
      }
    }
    this._caps.set(key, { name: key, handler, meta: normalized })
    return () => this._caps.delete(key)
  }

  unregister(name) {
    return this._caps.delete(String(name))
  }

  has(name) {
    return this._caps.has(String(name))
  }

  get(name) {
    return this._caps.get(String(name)) || null
  }

  list() {
    return [...this._caps.values()].map((c) => ({
      name: c.name,
      description: c.meta.description || '',
      owner: c.meta.owner || '',
      requireBound: c.meta.requireBound === true,
      legacy: c.meta.legacy ? { ...c.meta.legacy } : null,
    }))
  }

  /** 旧路径 → 能力名 的索引（请求时动态构建，容忍运行期增删） */
  _legacyIndex() {
    const index = new Map()
    for (const cap of this._caps.values()) {
      if (!cap.meta.legacy) continue
      index.set(`${cap.meta.legacy.method} ${cap.meta.legacy.path}`, cap.name)
    }
    return index
  }

  /** 按旧版路径查能力（method 大小写不敏感；path 需含挂载前缀，如 /api/bot/online） */
  findByLegacy(method, requestPath) {
    const key = `${String(method || 'get').toUpperCase()} ${String(requestPath || '')}`
    const name = this._legacyIndex().get(key)
    return name ? this.get(name) : null
  }

  /**
   * 在"旧版命令目录"里查该路径应有的能力与提供方（不看是否已注册）。
   * 供适配器区分"已知但未装插件（501）"与"真未知（404）"。
   * @returns {{path:string,method:string,capability:string,provider:string}|null}
   */
  catalogFor(method, requestPath) {
    const key = `${String(method || 'get').toUpperCase()} ${String(requestPath || '')}`
    return LEGACY_CATALOG.find((e) => `${e.method} ${e.path}` === key) || null
  }

  /**
   * 调用能力（适配器之外的统一入口）。
   * @throws 501 能力未注册 / 500 handler 抛错（保留原 status）
   */
  async invoke(name, { principal = null, params = {} } = {}) {
    const cap = this.get(name)
    if (!cap) throw notImplemented(name)
    const requireBound = cap.meta.requireBound === true
    if (requireBound && !principal?.boundUsername) {
      throw httpError(403, '该 QQ 未绑定角色（可发送「绑定 角色名」）', { needBind: true })
    }
    return cap.handler({ principal, params: params || {} })
  }
}

export class AdapterRegistry {
  constructor() {
    /** @type {Map<string, object>} */
    this._adapters = new Map()
  }

  /**
   * 注册接入适配器。
   * @param {object} adapter
   * @param {string} adapter.name            唯一标识（配置键、审计来源、限流分桶都用它）
   * @param {Function} [adapter.authenticate] (req) => principal | null
   * @param {string[]} [adapter.capabilities] 放行的能力名（['*'] = 全部）
   * @param {Function} [adapter.mount]        (registry) => 卸载函数（必须同步）
   * @param {Function} [adapter.send]         (target, message) => void（可选，宿主 → 用户/群）
   * @returns {Function} 取消注册函数
   */
  register(adapter) {
    const name = String(adapter?.name || '').trim()
    if (!name) throw new Error('适配器缺少 name')
    if (this._adapters.has(name)) throw new Error(`适配器已注册：${name}`)
    if (adapter.mount != null && typeof adapter.mount !== 'function') {
      throw new Error(`适配器 ${name} 的 mount 必须是函数`)
    }

    const record = {
      name,
      description: String(adapter.description || ''),
      authenticate: typeof adapter.authenticate === 'function' ? adapter.authenticate : null,
      capabilities: Array.isArray(adapter.capabilities) ? adapter.capabilities.map(String) : ['*'],
      send: typeof adapter.send === 'function' ? adapter.send : null,
      dispose: null,
      mounted: false,
    }

    if (typeof adapter.mount === 'function') {
      const off = adapter.mount(this)
      if (off && typeof off.then === 'function') {
        throw new Error(
          `适配器 ${name} 的 mount 必须同步完成路由注册（返回了 Promise）；` +
            '异步注册的路由不会归属本插件，disable 时无法摘除',
        )
      }
      record.dispose = typeof off === 'function' ? off : null
      record.mounted = true
    }

    this._adapters.set(name, record)
    return () => this.unregister(name)
  }

  unregister(name) {
    const record = this._adapters.get(String(name))
    if (!record) return false
    try {
      record.dispose?.()
    } catch {
      /* 卸载失败不阻断，交由宿主兜底摘除 layer */
    }
    this._adapters.delete(String(name))
    return true
  }

  get(name) {
    return this._adapters.get(String(name)) || null
  }

  has(name) {
    return this._adapters.has(String(name))
  }

  list() {
    return [...this._adapters.values()].map((a) => ({
      name: a.name,
      description: a.description,
      capabilities: [...a.capabilities],
      mounted: a.mounted,
      hasSend: a.send !== null,
    }))
  }

  /** 鉴权：返回 principal 或 null */
  async authenticate(name, req) {
    const adapter = this.get(name)
    if (!adapter) throw httpError(500, `适配器未注册：${name}`)
    if (!adapter.authenticate) return null
    return adapter.authenticate(req)
  }

  /** 该适配器是否放行某能力 */
  allows(name, capability) {
    const adapter = this.get(name)
    if (!adapter) return false
    return adapter.capabilities.includes('*') || adapter.capabilities.includes(String(capability))
  }

  /** 宿主 → 用户/群 下发（适配器未实现 → 501，不假装成功） */
  async send(name, target, message) {
    const adapter = this.get(name)
    if (!adapter) throw httpError(500, `适配器未注册：${name}`)
    if (!adapter.send) {
      throw httpError(501, `适配器 ${name} 未实现消息下发`, { missingPlugin: name })
    }
    return adapter.send(target, message)
  }
}
