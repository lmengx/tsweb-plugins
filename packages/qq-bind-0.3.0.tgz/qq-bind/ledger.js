/**
 * QQ 绑定台账（bindings.json）—— 唯一权威数据
 *
 * 语义对齐旧版后端台账（TsWeb/backend/services/qqAccountService.js）：
 *   - 严格 1:1：一个 QQ 只能绑一个角色，一个角色只能绑一个 QQ
 *   - 一切键按规范名定位、比较时大小写不敏感；aliases 保留大小写历史
 *   - 不产生"仅大小写不同"的重复账号
 *   - 原子落盘（.tmp + rename），保留一份 .bak
 *   - 导入幂等，冲突逐条列出
 *
 * 本模块只认"绑定事实"，不认识任何机器人框架，也不做游戏服调用。
 */
import { readFile, writeFile, rename, mkdir, copyFile, unlink } from 'node:fs/promises'
import path from 'node:path'

/** 台账 schema 版本 */
export const LEDGER_SCHEMA = 1

/** 规范化：去首尾空白；比较键用小写 */
export function normKey(name) {
  return String(name ?? '').trim().toLowerCase()
}

/** QQ 号规范化：字符串化并去空白（避免大整数与前后空格） */
export function normQq(qq) {
  return String(qq ?? '').trim()
}

/** QQ 号格式（收敛为单一常量，旧版散落 7 处） */
export const QQ_PATTERN = /^\d{5,15}$/

export function isValidQq(qq) {
  return QQ_PATTERN.test(normQq(qq))
}

/** 带 HTTP 语义的错误：路由层据 err.status 直接回状态码 */
export function httpError(status, message, extra = {}) {
  const err = new Error(message)
  err.status = status
  Object.assign(err, extra)
  return err
}

/**
 * 台账记录形状：
 *   records: { [原始用户名]: { qq, passwordHash, updatedAt, boundAt, source } }
 *   aliases: { [小写名]: 原始用户名 }   // 大小写历史，仅用于解析
 */
export class Ledger {
  /**
   * @param {object} opts
   * @param {string} opts.file        bindings.json 路径
   * @param {(entry: object) => void} [opts.onChange] 每次落盘后的回调（用于下发快照/审计）
   */
  constructor({ file, onChange } = {}) {
    if (!file) throw new Error('Ledger 需要 file 路径')
    this.file = file
    this.bakFile = `${file}.bak`
    this.onChange = onChange ?? null
    this.schema = LEDGER_SCHEMA
    this.records = Object.create(null)
    this.aliases = Object.create(null)
    this.updatedAt = null
    this.loaded = false
    /** 串行化写操作，避免并发写互相覆盖 */
    this._writeChain = Promise.resolve()
  }

  // ── 读盘 / 落盘 ──────────────────────────────────────────────

  /**
   * 读入台账。文件不存在 → 视为空台账（可信空），不报错。
   * 形状非法 → 抛错（宁可显式失败，也不静默把数据吃掉）。
   */
  async load() {
    let raw
    try {
      raw = await readFile(this.file, 'utf8')
    } catch (err) {
      if (err.code === 'ENOENT') {
        this.records = Object.create(null)
        this.aliases = Object.create(null)
        this.loaded = true
        return this.snapshot()
      }
      throw err
    }

    let parsed
    try {
      parsed = JSON.parse(raw)
    } catch (err) {
      throw new Error(`台账文件不是合法 JSON：${this.file}（${err.message}）`)
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      throw new Error(`台账文件形状非法（应为对象）：${this.file}`)
    }
    const records = parsed.records
    if (records != null && (typeof records !== 'object' || Array.isArray(records))) {
      throw new Error(`台账 records 形状非法（应为对象）：${this.file}`)
    }

    this.schema = Number(parsed.schema) || LEDGER_SCHEMA
    this.records = Object.create(null)
    for (const [username, rec] of Object.entries(records ?? {})) {
      const name = String(username).trim()
      if (!name) continue
      if (!rec || typeof rec !== 'object') continue
      this.records[name] = {
        qq: normQq(rec.qq),
        passwordHash: String(rec.passwordHash ?? ''),
        updatedAt: rec.updatedAt ?? parsed.updatedAt ?? null,
        boundAt: rec.boundAt ?? rec.updatedAt ?? null,
        source: rec.source ?? '',
      }
    }
    // 别名：优先用文件里的，其次按现有记录重建（保证解析可用）
    this.aliases = Object.create(null)
    for (const [key, value] of Object.entries(parsed.aliases ?? {})) {
      const k = normKey(key)
      if (k) this.aliases[k] = String(value)
    }
    for (const name of Object.keys(this.records)) {
      if (!this.aliases[normKey(name)]) this.aliases[normKey(name)] = name
    }
    this.updatedAt = parsed.updatedAt ?? null
    this.loaded = true
    return this.snapshot()
  }

  /** 落盘（原子：写 .tmp → 备份 .bak → rename） */
  async save() {
    this.updatedAt = new Date().toISOString()
    const payload = JSON.stringify(
      { schema: this.schema, updatedAt: this.updatedAt, records: this.records, aliases: this.aliases },
      null,
      2,
    )
    const dir = path.dirname(this.file)
    await mkdir(dir, { recursive: true })
    const tmp = `${this.file}.tmp`
    await writeFile(tmp, payload, 'utf8')
    // 备份上一版（存在才备份）
    try {
      await copyFile(this.file, this.bakFile)
    } catch (err) {
      if (err.code !== 'ENOENT') throw err
    }
    await rename(tmp, this.file)
    try {
      await unlink(tmp)
    } catch {
      /* rename 后 tmp 已不存在，忽略 */
    }
    return this.snapshot()
  }

  /** 串行执行写入动作并落盘 */
  _mutate(fn) {
    const run = async () => {
      const result = fn()
      await this.save()
      if (this.onChange) {
        try {
          this.onChange(result)
        } catch {
          /* 回调失败不影响台账 */
        }
      }
      return result
    }
    const next = this._writeChain.then(run, run)
    // 保持链条不因单次失败而中断
    this._writeChain = next.catch(() => {})
    return next
  }

  snapshot() {
    return {
      schema: this.schema,
      updatedAt: this.updatedAt,
      records: { ...this.records },
    }
  }

  /** 记录数 */
  get size() {
    return Object.keys(this.records).length
  }

  // ── 解析 ────────────────────────────────────────────────────

  /**
   * 按角色名或 QQ 解析记录（大小写不敏感）。
   * @returns {{ username: string, qq: string, passwordHash: string, updatedAt: string|null, boundAt: string|null, source: string } | null}
   */
  get(identifier) {
    const key = normKey(identifier)
    if (!key) return null
    // 1) 用户名字典
    const canonical = this.aliases[key]
    if (canonical && this.records[canonical]) return this._view(canonical)
    // 2) 直接命中原名（aliases 缺失时的兜底）
    for (const name of Object.keys(this.records)) {
      if (normKey(name) === key) return this._view(name)
    }
    // 3) 按 QQ
    const qq = normQq(identifier)
    if (qq) {
      for (const [name, rec] of Object.entries(this.records)) {
        if (rec.qq === qq) return this._view(name)
      }
    }
    return null
  }

  /** 按 QQ 精确查 */
  getByQq(qq) {
    const target = normQq(qq)
    if (!target) return null
    for (const [name, rec] of Object.entries(this.records)) {
      if (rec.qq === target) return this._view(name)
    }
    return null
  }

  /** 按角色名查（大小写不敏感） */
  getByUsername(username) {
    const key = normKey(username)
    if (!key) return null
    const canonical = this.aliases[key]
    if (canonical && this.records[canonical]) return this._view(canonical)
    for (const name of Object.keys(this.records)) {
      if (normKey(name) === key) return this._view(name)
    }
    return null
  }

  /**
   * 一次性建立「小写名 → QQ」内存索引（供批量查询复用）。
   *
   * 为什么放在台账里：records / aliases 是台账自己的内存索引（load() 读盘一次，
   * 之后只在变更时改写内存并落盘），解析口径（大小写不敏感 + aliases）也只在这里定义。
   * 调用方拿到 Map 后每个名字都是一次 O(1) 查表，**不必**在循环里反复查台账。
   *
   * 口径与 getByUsername 一致：
   *   - 按记录原名建表（键一律 normKey）
   *   - aliases 补别名（别名指向的名字若已不在册——解绑/删号后的历史名——不收录，
   *     与 getByUsername 返回 null 的行为一致）
   * 本方法不读盘、不落盘，纯内存（一趟遍历）。
   *
   * @returns {Map<string, string>} 小写角色名 → QQ 号
   */
  qqIndex() {
    const index = new Map()
    for (const [name, rec] of Object.entries(this.records)) {
      const key = normKey(name)
      if (key) index.set(key, rec.qq)
    }
    for (const [key, canonical] of Object.entries(this.aliases)) {
      if (index.has(key)) continue
      const rec = this.records[canonical]
      if (rec) index.set(key, rec.qq)
    }
    return index
  }

  isBound(identifier) {
    return this.get(identifier) !== null
  }

  _view(name) {
    const rec = this.records[name]
    return {
      username: name,
      qq: rec.qq,
      passwordHash: rec.passwordHash,
      updatedAt: rec.updatedAt ?? null,
      boundAt: rec.boundAt ?? null,
      source: rec.source ?? '',
    }
  }

  /** 列表（默认按绑定时间倒序；keyword 过滤角色名与 QQ） */
  list({ keyword = '', page = 1, pageSize = 50, sort = 'boundAt' } = {}) {
    const kw = String(keyword ?? '').trim().toLowerCase()
    let rows = Object.keys(this.records).map((name) => this._view(name))
    if (kw) {
      rows = rows.filter(
        (r) => r.username.toLowerCase().includes(kw) || r.qq.toLowerCase().includes(kw),
      )
    }
    rows.sort((a, b) => {
      const av = String(a[sort] ?? '')
      const bv = String(b[sort] ?? '')
      if (av === bv) return a.username.localeCompare(b.username)
      return bv.localeCompare(av)
    })
    const total = rows.length
    const p = Math.max(1, Number(page) || 1)
    const ps = Math.min(Math.max(1, Number(pageSize) || 50), 500)
    return { total, page: p, pageSize: ps, rows: rows.slice((p - 1) * ps, p * ps) }
  }

  /** 台账内所有用户名（供快照下发） */
  usernames() {
    return Object.keys(this.records)
  }

  // ── 变更 ────────────────────────────────────────────────────

  /**
   * 建立绑定（1:1 双向校验）。
   * @throws 409 冲突（QQ 已绑 / 角色已绑）
   */
  bind({ qq, username, passwordHash = '', source = '' }) {
    return this._mutate(() => {
      const q = normQq(qq)
      const name = String(username ?? '').trim()
      if (!q) throw httpError(400, '缺少参数: qq')
      if (!name) throw httpError(400, '缺少参数: player')
      if (!isValidQq(q)) throw httpError(400, 'QQ 号格式不正确')

      const byQq = this.getByQq(q)
      if (byQq) {
        throw httpError(409, '该 QQ 已绑定角色', { owner: byQq.username })
      }
      const byName = this.getByUsername(name)
      if (byName) {
        throw httpError(409, `该角色已绑定 QQ：${byName.qq}（如需更换请用「改绑」）`, {
          boundQq: byName.qq,
        })
      }

      const now = new Date().toISOString()
      this.records[name] = {
        qq: q,
        passwordHash: String(passwordHash ?? ''),
        updatedAt: now,
        boundAt: now,
        source: String(source ?? ''),
      }
      this.aliases[normKey(name)] = name
      return { action: 'bound', username: name, qq: q, source: String(source ?? '') }
    })
  }

  /** 解绑（仅删绑定关系；账号与角色数据由游戏侧保留，本模块不碰） */
  unbind({ username, qq }) {
    return this._mutate(() => {
      let name = ''
      let q = ''
      if (username != null && String(username).trim()) {
        const rec = this.getByUsername(username)
        if (!rec) throw httpError(404, '该角色未绑定 QQ')
        name = rec.username
        q = rec.qq
      } else if (qq != null && String(qq).trim()) {
        const rec = this.getByQq(qq)
        if (!rec) throw httpError(404, '该角色未绑定 QQ')
        name = rec.username
        q = rec.qq
      } else {
        throw httpError(400, '缺少参数: username 或 qq')
      }
      delete this.records[name]
      this.aliases[normKey(name)] = name // 保留别名，便于改名历史解析
      return { action: 'unbound', username: name, qq: q }
    })
  }

  /** 换绑 QQ */
  rebind({ username, newQq }) {
    return this._mutate(() => {
      const rec = this.getByUsername(username)
      if (!rec) throw httpError(404, '该角色未绑定 QQ')
      const q = normQq(newQq)
      if (!isValidQq(q)) throw httpError(400, 'QQ 号格式不正确')
      if (q === rec.qq) throw httpError(400, 'QQ 号与绑定玩家均未变化')
      const owner = this.getByQq(q)
      if (owner) throw httpError(409, `该 QQ 已绑定角色：${owner.username}`, { owner: owner.username })
      const fromQq = rec.qq
      this.records[rec.username] = { ...this.records[rec.username], qq: q, updatedAt: new Date().toISOString() }
      return { action: 'rebound', username: rec.username, fromQq, toQq: q }
    })
  }

  /**
   * 转移绑定：把 QQ 从 fromUsername 移到 toUsername（原角色数据保留，仅解除绑定）。
   * 语义与旧版"改绑模态的 newPlayer"一致，这里拆成显式操作。
   */
  transfer({ fromUsername, toUsername, qq, passwordHash = '' }) {
    return this._mutate(() => {
      const from = this.getByUsername(fromUsername)
      if (!from) throw httpError(404, '该角色未绑定 QQ')
      const target = String(toUsername ?? '').trim()
      if (!target) throw httpError(400, '缺少参数: 新绑定玩家')
      const tq = qq != null && String(qq).trim() ? normQq(qq) : from.qq
      if (!isValidQq(tq)) throw httpError(400, 'QQ 号格式不正确')

      const targetRec = this.getByUsername(target)
      if (targetRec) {
        throw httpError(409, `角色「${targetRec.username}」已绑定 QQ：${targetRec.qq}（需先解绑）`)
      }
      const owner = this.getByQq(tq)
      if (owner && normKey(owner.username) !== normKey(from.username)) {
        throw httpError(409, `该 QQ 已绑定角色：${owner.username}`, { owner: owner.username })
      }

      const now = new Date().toISOString()
      delete this.records[from.username]
      this.aliases[normKey(from.username)] = from.username
      this.records[target] = {
        qq: tq,
        passwordHash: String(passwordHash || from.passwordHash || ''),
        updatedAt: now,
        boundAt: now,
        source: from.source,
      }
      this.aliases[normKey(target)] = target
      return { action: 'transferred', fromUsername: from.username, toUsername: target, qq: tq }
    })
  }

  /**
   * 改名联动：迁移台账 key（保留 qq/密码哈希/绑定时间）。
   * 旧版缺陷 B1 的正解：改名也必须触发快照下发（由调用方在 onChange 里统一处理）。
   */
  rename(oldName, newName) {
    return this._mutate(() => {
      const rec = this.getByUsername(oldName)
      const target = String(newName ?? '').trim()
      if (!target) throw httpError(400, '缺少参数: newName')
      if (!rec) return { action: 'renamed', from: String(oldName ?? ''), to: target, skipped: 'not-bound' }
      if (normKey(rec.username) === normKey(target)) {
        // 仅大小写变化：更新原始大小写，保持唯一
        delete this.records[rec.username]
        this.records[target] = { ...this.records[rec.username], updatedAt: new Date().toISOString() }
        this.aliases[normKey(target)] = target
        return { action: 'renamed', from: rec.username, to: target }
      }
      const exist = this.getByUsername(target)
      if (exist) throw httpError(409, `目标用户名已存在绑定：${exist.username}`)
      const entry = this.records[rec.username]
      delete this.records[rec.username]
      this.records[target] = { ...entry, updatedAt: new Date().toISOString() }
      this.aliases[normKey(rec.username)] = rec.username
      this.aliases[normKey(target)] = target
      return { action: 'renamed', from: rec.username, to: target }
    })
  }

  /** 覆盖免密哈希（改密/绑定后同步用） */
  setPasswordHash(username, passwordHash) {
    return this._mutate(() => {
      const rec = this.getByUsername(username)
      if (!rec) throw httpError(404, '该角色未绑定 QQ')
      this.records[rec.username] = {
        ...this.records[rec.username],
        passwordHash: String(passwordHash ?? ''),
        updatedAt: new Date().toISOString(),
      }
      return { action: 'password-changed', username: rec.username, qq: rec.qq }
    })
  }

  /** 删号级联：删台账记录（账号由 base 负责删） */
  remove(username) {
    return this._mutate(() => {
      const rec = this.getByUsername(username)
      if (!rec) return { action: 'removed', username: String(username ?? ''), skipped: 'not-bound' }
      delete this.records[rec.username]
      this.aliases[normKey(rec.username)] = rec.username
      return { action: 'removed', username: rec.username, qq: rec.qq }
    })
  }

  /**
   * 导入旧台账（幂等；冲突逐条列出，不覆盖既有绑定）。
   * @param {object} source 旧文件内容 { records: { 名: { qq, passwordHash, updatedAt } } }
   */
  import(source, { dryRun = false } = {}) {
    const records = (source && source.records) || {}
    const plan = { imported: [], skipped: [], conflicts: [] }
    const staged = { ...this.records }
    const stagedAliases = { ...this.aliases }
    const stagedQq = new Map()
    for (const [name, rec] of Object.entries(staged)) stagedQq.set(normQq(rec.qq), name)

    for (const [rawName, rec] of Object.entries(records)) {
      const name = String(rawName ?? '').trim()
      const qq = normQq(rec && rec.qq)
      if (!name || !qq) {
        plan.skipped.push({ username: name, reason: '缺少用户名或 QQ' })
        continue
      }
      if (!isValidQq(qq)) {
        plan.skipped.push({ username: name, qq, reason: 'QQ 号格式不正确' })
        continue
      }
      const existing = staged[name] || staged[stagedAliases[normKey(name)]]
      if (existing) {
        if (normQq(existing.qq) === qq) {
          plan.skipped.push({ username: name, qq, reason: '已存在且一致（幂等跳过）' })
        } else {
          plan.conflicts.push({ username: name, existingQq: existing.qq, incomingQq: qq })
        }
        continue
      }
      const qqOwner = stagedQq.get(qq)
      if (qqOwner) {
        plan.conflicts.push({ username: name, qq, reason: `该 QQ 已属于 ${qqOwner}` })
        continue
      }
      staged[name] = {
        qq,
        passwordHash: String((rec && rec.passwordHash) ?? ''),
        updatedAt: (rec && rec.updatedAt) ?? new Date().toISOString(),
        boundAt: (rec && rec.updatedAt) ?? new Date().toISOString(),
        source: 'import',
      }
      stagedAliases[normKey(name)] = name
      stagedQq.set(qq, name)
      plan.imported.push({ username: name, qq })
    }

    if (dryRun || plan.imported.length === 0) {
      return { ...plan, applied: false }
    }
    return this._mutate(() => {
      for (const item of plan.imported) {
        this.records[item.username] = staged[item.username]
        this.aliases[normKey(item.username)] = item.username
      }
      return { action: 'imported', count: plan.imported.length, usernames: plan.imported.map((i) => i.username) }
    }).then((res) => ({ ...plan, applied: true, appliedCount: res.count }))
  }
}
