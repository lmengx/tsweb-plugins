/**
 * 接入层（adapters/registry.js）单元测试
 *
 * 重点验证设计 §3.5 的硬约束：
 *   - 能力名规范 + 重复注册拒绝 + 缺能力 501（带 missingPlugin/hint）
 *   - requireBound 由注册表统一拦截（handler 不必自己判）
 *   - 旧路径映射是"数据"：meta.legacy 决定，动态查表
 *   - mount 必须同步（异步 mount 直接抛错，否则路由摘不掉）
 *   - 适配器能力白名单（最小权限）与 send 未实现的 501
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'

import { CapabilityRegistry, AdapterRegistry } from '../adapters/registry.js'

test('能力注册：命名规范、重复拒绝、取消注册', () => {
  const caps = new CapabilityRegistry()
  const off = caps.register('online.list', async () => ({ ok: 1 }), {
    legacy: { path: '/api/bot/online/', method: 'get' },
  })
  assert.equal(caps.has('online.list'), true)
  assert.deepEqual(caps.get('online.list').meta.legacy, { path: '/api/bot/online', method: 'GET' })

  assert.throws(() => caps.register('badname', async () => {}), /能力名不合法/)
  assert.throws(() => caps.register('online.list', async () => {}), /能力已注册/)
  assert.throws(() => caps.register('online.list', 'not-a-function'), /能力已注册|缺少 handler/)

  off()
  assert.equal(caps.has('online.list'), false)
})

test('meta.legacy 校验：必须以 / 开头', () => {
  const caps = new CapabilityRegistry()
  assert.throws(
    () => caps.register('a.b', async () => {}, { legacy: { path: 'api/bot/x' } }),
    /必须以 \/ 开头/,
  )
})

test('缺能力 → 501 且带 missingPlugin/hint（不返回空数据冒充成功）', async () => {
  const caps = new CapabilityRegistry()
  await assert.rejects(
    () => caps.invoke('online.list', {}),
    (err) =>
      err.status === 501 &&
      err.missingCapability === 'online.list' &&
      err.missingPlugin === 'online-stats' &&
      /online-stats/.test(err.hint),
  )
  await assert.rejects(
    () => caps.invoke('vote.cast', {}),
    (err) => err.status === 501 && err.missingPlugin === '投票类插件',
  )
})

test('requireBound：注册表统一拦截未绑定调用', async () => {
  const caps = new CapabilityRegistry()
  caps.register('binding.changePassword', async () => ({ done: true }), { requireBound: true })

  await assert.rejects(
    () => caps.invoke('binding.changePassword', { principal: { adapter: 'legacy-http' } }),
    (err) => err.status === 403 && err.needBind === true && /未绑定角色/.test(err.message),
  )
  const out = await caps.invoke('binding.changePassword', {
    principal: { adapter: 'legacy-http', boundUsername: 'Steve' },
  })
  assert.deepEqual(out, { done: true })
})

test('旧路径查表：动态生效（晚注册的能力无需重挂路由）', () => {
  const caps = new CapabilityRegistry()
  assert.equal(caps.findByLegacy('GET', '/api/bot/online'), null)
  caps.register('online.list', async () => ({}), { legacy: { path: '/api/bot/online', method: 'get' } })
  assert.equal(caps.findByLegacy('get', '/api/bot/online').name, 'online.list', 'method 大小写不敏感')
  assert.equal(caps.findByLegacy('POST', '/api/bot/online'), null, 'method 必须匹配')
})

test('适配器注册：mount 必须同步，异步 mount 直接抛错', () => {
  const adapters = new AdapterRegistry()
  const off = adapters.register({ name: 'ok-adapter', mount: () => null })
  assert.equal(adapters.has('ok-adapter'), true)
  assert.equal(adapters.list()[0].mounted, true)
  off()
  assert.equal(adapters.has('ok-adapter'), false)

  assert.throws(
    () => adapters.register({ name: 'async-adapter', mount: async () => null }),
    /必须同步完成路由注册/,
  )
  assert.throws(() => adapters.register({ name: '' }), /缺少 name/)
  adapters.register({ name: 'dup' })
  assert.throws(() => adapters.register({ name: 'dup' }), /适配器已注册/)
})

test('适配器能力白名单：最小权限', () => {
  const adapters = new AdapterRegistry()
  adapters.register({ name: 'official-node', capabilities: ['binding.bind'] })
  adapters.register({ name: 'legacy-http', capabilities: ['*'] })

  assert.equal(adapters.allows('official-node', 'binding.bind'), true)
  assert.equal(adapters.allows('official-node', 'vote.cast'), false)
  assert.equal(adapters.allows('legacy-http', 'vote.cast'), true)
  assert.equal(adapters.allows('unknown', 'binding.bind'), false, '未注册适配器一律不放行')
})

test('适配器注销时调用卸载函数', () => {
  const adapters = new AdapterRegistry()
  let disposed = false
  const off = adapters.register({
    name: 'with-dispose',
    mount: () => () => {
      disposed = true
    },
  })
  off()
  assert.equal(disposed, true)
})

test('send：未实现消息下发的适配器返回 501 而不是假装成功', async () => {
  const adapters = new AdapterRegistry()
  adapters.register({ name: 'no-send' })
  await assert.rejects(
    () => adapters.send('no-send', { groupId: '1' }, { text: 'hi' }),
    (err) => err.status === 501 && err.missingPlugin === 'no-send',
  )

  const sent = []
  adapters.register({ name: 'with-send', send: async (target, msg) => sent.push([target, msg]) })
  await adapters.send('with-send', { groupId: '1' }, { text: 'hi' })
  assert.deepEqual(sent, [[{ groupId: '1' }, { text: 'hi' }]])
})

test('鉴权：未注册适配器调用 authenticate 报 500（配置/装配错误要显式暴露）', async () => {
  const adapters = new AdapterRegistry()
  await assert.rejects(
    () => adapters.authenticate('ghost', {}),
    (err) => err.status === 500 && /适配器未注册/.test(err.message),
  )
})
