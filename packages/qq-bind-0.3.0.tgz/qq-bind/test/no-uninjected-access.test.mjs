/**
 * 回归测试：禁止「直接属性访问未 inject 的服务」
 *
 * 真实故障（前端「QQ 绑定」页加载失败：cannot get property "onlineStats" without inject）：
 *   cordis 的 ctx 代理对**没有写进 inject** 的服务是"访问即抛错"——
 *   node_modules/@deepseek-ai/cordis/lib/index.js:669-675 的 Proxy get 陷阱：
 *     get: (target, prop, ctx) => { ...; throw new Error(`cannot get property "${prop}" without inject`) }
 * 本插件曾用 `this.ctx.onlineStats` / `ctx.onlineStats` 取时长（软依赖），
 * 于是在真实宿主里整条请求 500；而 online-stats 不在 inject 里（软依赖不该写进 inject，
 * 否则"没装 online-stats"会变成"整个 qq-bind 不加载"）。
 *
 * 为什么只能静态检查（本文件存在的理由）：
 *   本目录其它测试都是**直接调用 apply(ctx)**（见 apply.test.mjs 的 before），
 *   注入的 webServer/auth/servers/tshock/paths 是普通属性赋值，`inject` 并不生效；
 *   而代理抛错需要经 ctx.plugin() 挂载（宿主 loader.js:250 就是这么做的）。
 *   所以"直接读 ctx.onlineStats"在行为测试里只会得到 undefined 并静默降级，
 *   64 个测试全绿也照样漏掉这个线上故障。这条断言补的就是这个盲区。
 *
 * 运行：node test/no-uninjected-access.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const SRC = path.resolve(here, '..', 'index.js')

/**
 * 项目里出现过的 cordis 服务名（由全仓 super(ctx,'x') 与 ctx.x = service 汇总而来）。
 * 只对这些名字做检查，避免把 ctx.logger / ctx.on / ctx.get 之类误判成服务。
 */
const KNOWN_SERVICES = [
  'auth', 'connection', 'itemData', 'market', 'onlineStats',
  'projectileData', 'qqBind', 'servers', 'terminal', 'tshock', 'webServer', 'paths',
]

/** 本插件自己的服务（读取自身服务是合法的，代理为它建了 accessor） */
const OWN_SERVICES = ['qqBind']

/** 去掉行内注释与整行注释后的"代码部分"（朴素实现：不处理字符串里的 //，够用且不会漏报） */
function codePart(rawLine) {
  const line = rawLine.trim()
  if (line.startsWith('//') || line.startsWith('*') || line.startsWith('/*')) return ''
  const idx = rawLine.indexOf('//')
  return idx >= 0 ? rawLine.slice(0, idx) : rawLine
}

test('index.js 不直接属性访问未 inject 的服务（软依赖必须走 ctx.get）', async () => {
  const src = await readFile(SRC, 'utf8')
  const lines = src.split(/\r?\n/)

  // 解析本插件的 inject 列表
  const m = src.match(/export const inject\s*=\s*\[([^\]]*)\]/)
  assert.ok(m, 'index.js 应导出 inject 数组')
  const injected = [...m[1].matchAll(/'([^']+)'/g)].map((x) => x[1])

  const allowed = new Set([...injected, ...OWN_SERVICES])
  const violations = []

  for (let i = 0; i < lines.length; i++) {
    const code = codePart(lines[i])
    if (!code) continue
    // 匹配 ctx.<name> 与 this.ctx.<name>
    for (const hit of code.matchAll(/(?:this\.)?ctx\.([A-Za-z][A-Za-z0-9]*)/g)) {
      const name = hit[1]
      if (!KNOWN_SERVICES.includes(name)) continue   // 不是服务（get/on/logger/effect/...）
      if (allowed.has(name)) continue                // 已 inject 或自身服务
      violations.push(`index.js:${i + 1} 直接访问了未 inject 的服务 ctx.${name}`)
    }
  }

  assert.deepEqual(
    violations,
    [],
    '软依赖服务必须用 ctx.get(name)（缺失返回 undefined 不抛错），不能直接读属性：\n' + violations.join('\n')
  )
})

test('inject 列表本身是预期的那 5 个（避免有人为了让检查通过而乱加依赖）', async () => {
  const src = await readFile(SRC, 'utf8')
  const m = src.match(/export const inject\s*=\s*\[([^\]]*)\]/)
  const injected = [...m[1].matchAll(/'([^']+)'/g)].map((x) => x[1]).sort()
  assert.deepEqual(injected, ['auth', 'paths', 'servers', 'tshock', 'webServer'])
  // onlineStats 是**软依赖**，刻意不写进来：写进来会让"没装 online-stats"直接变成"qq-bind 不加载"
  assert.equal(injected.includes('onlineStats'), false)
})
