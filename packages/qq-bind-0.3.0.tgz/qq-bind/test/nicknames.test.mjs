/**
 * QQ 昵称缓存 + 昵称刷新任务（nicknames.js）单元测试
 *
 * 覆盖旧版语义里最容易写错的几条（对齐 TsWeb/backend/services/qqNicknameService.js）：
 *   缓存：控制字符剔除与 64 上限 / 空值与报错条目**不写入**且不覆盖已有昵称 /
 *         文件损坏或形状非法 → 降级为空缓存且**不抛错** / QQ 号格式校验 / 无 TTL /
 *         原子落盘（.tmp + rename）与文件结构
 *   任务：幂等（进行中重复请求返回同一任务）/ 领取一次后不再被领取 /
 *         无绑定 QQ → 领取即 done 并带说明 / 120 秒与 300 秒**惰性**超时文案与边界 /
 *         finish 只认当前任务 id、failed 视图只回前 50 条
 *
 * 运行：node test/nicknames.test.mjs
 * （本机 `node --test test/` 会因 spawn EPERM 失败，所以每个测试文件都必须能单独跑）
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import {
  NicknameStore,
  NicknameTaskQueue,
  cleanNickname,
  NICKNAME_MAX,
  NICKNAME_REPORT_LIMIT,
  PENDING_TIMEOUT_MS,
  PENDING_TIMEOUT_TEXT,
  RUNNING_TIMEOUT_MS,
  RUNNING_TIMEOUT_TEXT,
  NO_BOUND_QQ_TEXT,
  TASK_FAILED_KEEP_LIMIT,
  TASK_FAILED_VIEW_LIMIT,
} from '../nicknames.js'

let dir

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), 'qqbind-nicknames-'))
})

after(async () => {
  await rm(dir, { recursive: true, force: true })
})

/** 每次用一个新文件，避免用例之间互相干扰 */
function freshStore(name) {
  return new NicknameStore({ file: path.join(dir, `${name}.json`) })
}

// ══════════════════════════════════════════════════════════════
// 昵称清洗
// ══════════════════════════════════════════════════════════════

test('cleanNickname：控制字符剔成空格、去首尾空白、上限 64（顺序与旧版一致）', () => {
  assert.equal(cleanNickname('  Alice  '), 'Alice')
  assert.equal(cleanNickname('A\u0000B\nC\td'), 'A B C d', '控制字符与换行替换为空格，防止撑坏日志/表格')
  assert.equal(cleanNickname('\u007f'), '')
  assert.equal(cleanNickname(123), '123', '非字符串按 String() 归一')
  assert.equal(cleanNickname(null), '')
  assert.equal(cleanNickname(undefined), '')
  assert.equal(cleanNickname(''), '')

  assert.equal(cleanNickname('x'.repeat(100)).length, NICKNAME_MAX)
  assert.equal(cleanNickname('x'.repeat(100)), 'x'.repeat(64))
  // 截断在 trim **之后**：先去掉首尾空白再数长度，不会把空白算进 64 里
  assert.equal(cleanNickname('  ' + 'y'.repeat(70) + '  ').length, NICKNAME_MAX)
  assert.equal(cleanNickname('  ' + 'y'.repeat(70) + '  '), 'y'.repeat(64))
  assert.equal(NICKNAME_MAX, 64)
})

// ══════════════════════════════════════════════════════════════
// 缓存：写入与分类
// ══════════════════════════════════════════════════════════════

test('缓存：QQ 号格式校验（5-15 位数字），非法 QQ 既不读也不写', async () => {
  const store = freshStore('qq-format')
  assert.equal(await store.getNickname('1234'), '', '不足 5 位 → 空串')
  assert.equal(await store.getNickname('1234567890123456'), '', '超过 15 位 → 空串')
  assert.equal(await store.getNickname('abcde'), '', '非数字 → 空串')
  assert.equal(await store.getNickname(''), '')
  assert.equal(await store.getNickname(null), '')

  const r = await store.saveNicknames([
    { qq: '1234', nickname: '太短' },
    { qq: 'abcdef', nickname: '非数字' },
    { qq: '', nickname: '空' },
  ])
  assert.equal(r.stored, 0, '非法 QQ 一律不写入')
  assert.equal(r.skipped, 3)
  assert.deepEqual(r.failed.map((f) => f.error), [
    'QQ 号格式不正确',
    'QQ 号格式不正确',
    'QQ 号格式不正确',
  ])
  assert.deepEqual(await store.getNicknameMap(), {}, '文件里不应有任何记录')
})

test('缓存：空值与报错条目不写入，且**不覆盖**已有昵称（无 TTL，只有下次成功才覆盖）', async () => {
  const store = freshStore('no-overwrite')

  const first = await store.saveNicknames([{ qq: '10001', nickname: '  小明  ' }])
  assert.equal(first.stored, 1)
  assert.equal(first.skipped, 0)
  assert.equal(await store.getNickname('10001'), '小明', '写入时应 trim')
  const wroteAt = await store.getNicknameUpdatedAt('10001')
  assert.ok(wroteAt, '应记录 updatedAt')

  // 三种"没有结果"的条目：空昵称 / 纯空白 / 机器人明确报错
  const second = await store.saveNicknames([
    { qq: '10001', nickname: '' },
    { qq: '10001', nickname: '   ' },
    { qq: '10001', error: '平台未返回昵称' },
  ])
  assert.equal(second.stored, 0, '没有结果的条目一律不写')
  assert.equal(second.skipped, 3)
  assert.deepEqual(second.failed, [
    { qq: '10001', error: '未取到昵称' },
    { qq: '10001', error: '未取到昵称' },
    { qq: '10001', error: '平台未返回昵称' },
  ])
  assert.equal(await store.getNickname('10001'), '小明', '**绝不用空值覆盖已有昵称**')
  assert.equal(await store.getNicknameUpdatedAt('10001'), wroteAt, '未写入就不该动 updatedAt')

  // 只有下一次成功获取才覆盖
  await store.saveNicknames([{ qq: '10001', nickname: '小明改名了' }])
  assert.equal(await store.getNickname('10001'), '小明改名了')
})

test('缓存：逐条失败原因（格式不对 / 条目自带 error 原样带出并截断 200 字 / 未取到昵称）', async () => {
  const store = freshStore('failed-reasons')
  const longError = 'e'.repeat(300)
  const r = await store.saveNicknames([
    { qq: '20001', nickname: '正常' },
    { qq: 'not-a-qq', nickname: '格式不对' },
    { qq: '20002', error: longError },
    { qq: '20003', nickname: '   ' },
    { qq: '20004' },
  ])
  assert.equal(r.stored, 1)
  assert.equal(r.skipped, 4)
  assert.deepEqual(r.failed.map((f) => f.qq), ['not-a-qq', '20002', '20003', '20004'])
  assert.equal(r.failed[0].error, 'QQ 号格式不正确')
  assert.equal(r.failed[1].error.length, 200, '条目自带 error 截断 200 字')
  assert.equal(r.failed[1].error, longError.slice(0, 200))
  assert.equal(r.failed[2].error, '未取到昵称')
  assert.equal(r.failed[3].error, '未取到昵称', '完全没给昵称也算"未取到"')
  assert.equal(await store.getNickname('20004'), '')
})

test('缓存：落盘结构沿用 { schema:1, updatedAt, records:{ qq:{nickname,updatedAt,source} } } 且不留 .tmp', async () => {
  const store = freshStore('shape')
  await store.saveNicknames([{ qq: '30001', nickname: '甲' }], { source: 'bot' })
  await store.saveNicknames([{ qq: '30002', nickname: '乙' }], { source: 'admin' })

  const raw = JSON.parse(await readFile(store.file, 'utf8'))
  assert.equal(raw.schema, 1)
  assert.equal(Number.isNaN(Date.parse(raw.updatedAt)), false, 'updatedAt 应是 ISO 时间')
  assert.equal(raw.records['30001'].nickname, '甲')
  assert.equal(raw.records['30001'].source, 'bot', 'source 缺省 bot（旧版 saveNicknames 的默认值）')
  assert.equal(raw.records['30002'].source, 'admin', 'source 可由调用方指定')
  assert.equal(Number.isNaN(Date.parse(raw.records['30001'].updatedAt)), false)

  // 原子落盘：rename 之后 .tmp 不该残留
  await assert.rejects(() => readFile(`${store.file}.tmp`, 'utf8'), (err) => err.code === 'ENOENT')
})

test('缓存：文件不存在 = 空缓存（首次使用不报错）', async () => {
  const store = freshStore('missing')
  assert.deepEqual(await store.getNicknameMap(), {})
  assert.equal(await store.getNickname('40001'), '')
  assert.equal(await store.getNicknameUpdatedAt('40001'), '')
})

test('缓存：文件损坏 / 形状非法 → 降级为空缓存且**不抛错**（昵称不该拖垮 QQ 页面）', async () => {
  const cases = {
    'not-json.json': '{ not json ',
    'array.json': '[1,2,3]',
    'null.json': 'null',
    'string.json': '"hello"',
    'records-array.json': JSON.stringify({ schema: 1, records: [] }),
  }
  for (const [name, content] of Object.entries(cases)) {
    const file = path.join(dir, name)
    await writeFile(file, content, 'utf8')
    const store = new NicknameStore({ file })
    const warnings = []
    const origWarn = console.warn
    console.warn = (...a) => warnings.push(a.join(' '))
    try {
      assert.deepEqual(await store.getNicknameMap(), {}, `${name} 应降级为空缓存`)
      assert.equal(await store.getNickname('50001'), '', `${name}：单个查询也应返回空串而不是抛错`)
      assert.equal(await store.getNicknameUpdatedAt('50001'), '')
    } finally {
      console.warn = origWarn
    }
    if (name === 'not-json.json') {
      assert.equal(warnings.length, 3, '每次读盘失败都要有警告（不是静默吞掉）')
      assert.match(warnings[0], /昵称缓存读取失败/)
      assert.match(warnings[0], /已按空缓存处理/)
    } else {
      assert.deepEqual(warnings, [], `${name}：形状非法只降级，不该刷警告`)
    }

    // 降级之后仍可正常写入（覆盖坏文件）
    const saved = await store.saveNicknames([{ qq: '50001', nickname: '修复后' }])
    assert.equal(saved.stored, 1)
    assert.equal(await store.getNickname('50001'), '修复后')
  }
})

test('缓存：键名撞 Object.prototype 时仍如实返回（__proto__ 不会被静默吞掉）', async () => {
  const file = path.join(dir, 'proto.json')
  // 注意：**不能用对象字面量**写 __proto__（那会去设原型而不是建键），
  // 必须用 JSON 文本让 JSON.parse 建出自有键——这也正是"外部可写文件"的真实形状
  await writeFile(
    file,
    '{"schema":1,"records":{"__proto__":{"nickname":"污染"},"toString":{"nickname":"T"}}}',
    'utf8',
  )
  const store = new NicknameStore({ file })
  const map = await store.getNicknameMap()
  assert.equal(Object.prototype.hasOwnProperty.call(map, '__proto__'), true)
  assert.equal(map['__proto__'], '污染')
  assert.equal(map.toString, 'T')
  assert.equal({}.nickname, undefined, '不得污染 Object.prototype')
  assert.equal(Object.getPrototypeOf(map), Object.prototype, '返回的仍是普通对象（可直接 JSON 序列化）')
})

test('removeNickname：方法本身可用，但**生产路径从不调用**（旧版既有行为，解绑/改绑不清缓存）', async () => {
  const store = freshStore('remove')
  await store.saveNicknames([{ qq: '60001', nickname: '甲' }])
  assert.equal(await store.removeNickname('60001'), true)
  assert.equal(await store.getNickname('60001'), '')
  assert.equal(await store.removeNickname('60001'), false, '已不存在 → false')
  assert.equal(await store.removeNickname('abc'), false, '非法 QQ → false')
  // 这一条只保证方法可用：旧版定义了它却从未调用，本件也保持"不调用"
  // （昵称归属是 QQ 号，解绑/改绑后重新绑回同一 QQ 时旧昵称仍然有效）。
})

// ══════════════════════════════════════════════════════════════
// 任务编排
// ══════════════════════════════════════════════════════════════

test('任务：登记时过滤非法 QQ 与重复项，视图形状与旧版一致（不含 qqs 明细）', () => {
  const q = new NicknameTaskQueue()
  const t = q.request({ actor: 'admin', qqs: ['10001', '10002', '10002', ' 10003 ', 'abc', '1234', '', null] })
  assert.equal(t.total, 3, '去重 + 过滤非法 QQ')
  assert.equal(t.state, 'pending')
  assert.equal(t.requestedBy, 'admin')
  assert.equal(t.claimedAt, null)
  assert.equal(t.completedAt, null)
  assert.equal(t.stored, 0)
  assert.equal(t.failedCount, 0)
  assert.deepEqual(t.failed, [])
  assert.equal(t.error, '')
  assert.equal(typeof t.id, 'string')
  assert.ok(t.id.length > 0)
  assert.equal(Number.isNaN(Date.parse(new Date(t.requestedAt).toISOString())), false)
  assert.equal('qqs' in t, false, '任务视图不得带 qqs 明细（那是给机器人领取时取的）')
})

test('任务：幂等 —— 进行中的重复请求原样返回**同一个**任务，不重复登记', () => {
  const q = new NicknameTaskQueue()
  const first = q.request({ actor: 'admin', qqs: ['10001'] })
  const again = q.request({ actor: 'admin', qqs: ['10001', '10002'] })
  assert.equal(again.id, first.id, '已有 pending 任务 → 返回同一个任务')
  assert.equal(again.total, 1, '连点不会把新 QQ 塞进已有任务')
  assert.equal(again.requestedAt, first.requestedAt)

  q.claim()
  const whileClaimed = q.request({ actor: 'admin', qqs: ['10009'] })
  assert.equal(whileClaimed.id, first.id, 'claimed 期间同样返回同一个任务')
  assert.equal(whileClaimed.state, 'claimed')

  q.finish(first.id, { stored: 1, failed: [] })
  const afterDone = q.request({ actor: 'admin', qqs: ['10009'] })
  assert.notEqual(afterDone.id, first.id, '上一个任务到终态后，新请求是一个新任务')
  assert.equal(afterDone.state, 'pending')
  assert.equal(afterDone.total, 1)
})

test('任务：领取一次后不再被重复领取（含被领取后 request 不改状态）', () => {
  const q = new NicknameTaskQueue()
  const t = q.request({ actor: 'admin', qqs: ['10001', '10002'] })
  const claimed = q.claim()
  assert.equal(claimed.id, t.id)
  assert.deepEqual(claimed.qqs, ['10001', '10002'])
  assert.equal(claimed.total, 2)
  assert.equal(q.claim(), null, '第二次领取必须返回 null')
  assert.equal(q.view().state, 'claimed')
  assert.ok(q.view().claimedAt, '领取时间要记下来（300 秒超时以它为起点）')
})

test('任务：没有任何已绑定 QQ → 领取时直接 done 并带说明（不让机器人空转、页面不转圈）', () => {
  const q = new NicknameTaskQueue()
  const t = q.request({ actor: 'admin', qqs: [] })
  assert.equal(t.total, 0)
  const claimed = q.claim()
  assert.deepEqual(claimed, { id: t.id, qqs: [], total: 0 })
  const view = q.view()
  assert.equal(view.state, 'done', '领取时没有 QQ → 直接判定完成')
  assert.equal(view.error, NO_BOUND_QQ_TEXT)
  assert.equal(view.stored, 0)
  assert.equal(view.failedCount, 0)
  assert.ok(view.completedAt)
  assert.equal(q.claim(), null, '已到终态，不再可领取')
})

test('任务：只过滤非法 QQ，全部非法时与"没有绑定 QQ"同一条路', () => {
  const q = new NicknameTaskQueue()
  const t = q.request({ actor: 'admin', qqs: ['abc', '1234', ''] })
  assert.equal(t.total, 0)
  assert.equal(q.claim().qqs.length, 0)
  assert.equal(q.view().error, NO_BOUND_QQ_TEXT)
})

test('任务：finish 只认当前任务的 id（对不上的回报不误改任务）', () => {
  const q = new NicknameTaskQueue()
  const t = q.request({ actor: 'admin', qqs: ['10001'] })
  q.claim()

  assert.equal(q.finish('ghost-id', { stored: 99, failed: [] }), null, 'id 不匹配 → null 且不动任务')
  assert.equal(q.view().state, 'claimed')
  assert.equal(q.view().stored, 0)

  const done = q.finish(t.id, { stored: 1, failed: [{ qq: '10001', error: '未取到昵称' }] })
  assert.equal(done.state, 'done')
  assert.equal(done.stored, 1)
  assert.equal(done.failedCount, 1)
  assert.deepEqual(done.failed, [{ qq: '10001', error: '未取到昵称' }])
  assert.equal(q.finish('ghost-id', {}), null)
  assert.equal(q.view().state, 'done')

  // 没有任务时回报也是 null（而不是抛错）
  q.reset()
  assert.equal(q.view(), null)
  assert.equal(q.finish(t.id, { stored: 1 }), null)
})

test('任务：failed 明细入库截断 200 条、对外视图只回前 50 条（failedCount 随入库值，最多 200）', () => {
  const q = new NicknameTaskQueue()
  const t = q.request({ actor: 'admin', qqs: ['10001'] })
  q.claim()

  // 60 条失败：failedCount 是真实条数，视图只给前 50 条
  const sixty = Array.from({ length: 60 }, (_, i) => ({ qq: '10' + String(i).padStart(3, '0'), error: '未取到昵称' }))
  const done = q.finish(t.id, { stored: 0, failed: sixty })
  assert.equal(done.failedCount, 60, 'failedCount 是真实条数')
  assert.equal(done.failed.length, TASK_FAILED_VIEW_LIMIT, '视图只回前 50 条')
  assert.equal(TASK_FAILED_VIEW_LIMIT, 50)
  assert.deepEqual(done.failed, sixty.slice(0, 50))

  // 260 条失败：入库先按 200 截断（旧版 t.failed.slice(0, 200)），所以 failedCount 是 200 而不是 260
  const t2 = q.request({ actor: 'admin', qqs: ['10002'] })
  q.claim()
  const many = Array.from({ length: 260 }, (_, i) => ({ qq: '20' + String(i).padStart(3, '0'), error: '未取到昵称' }))
  const done2 = q.finish(t2.id, { stored: 0, failed: many })
  assert.equal(done2.failedCount, TASK_FAILED_KEEP_LIMIT, '入库上限 200：失败数超过 200 时回执封顶（旧版既有行为）')
  assert.equal(TASK_FAILED_KEEP_LIMIT, 200)
  assert.equal(done2.failed.length, 50)
  assert.deepEqual(done2.failed, many.slice(0, 50))

  // 非数组的 failed 当成没有（旧版 saveNicknames 的口径），不抛错
  const t3 = q.request({ actor: 'admin', qqs: ['10003'] })
  q.claim()
  const done3 = q.finish(t3.id, { stored: 3, failed: 'not-an-array' })
  assert.equal(done3.failedCount, 0)
  assert.deepEqual(done3.failed, [])
  assert.equal(done3.stored, 3)
})

test('任务：惰性超时 —— 登记后 120 秒无人领取 → timeout 与指定文案', () => {
  let now = 1_000_000
  const q = new NicknameTaskQueue({ now: () => now })
  const t = q.request({ actor: 'admin', qqs: ['10001'] })

  now += PENDING_TIMEOUT_MS
  assert.equal(q.view().state, 'pending', '正好 120 秒还不算超时（判定是 >，与旧版一致）')
  assert.equal(q.claim().id, t.id, '边界上仍可领取')

  // 超过 120 秒仍是 pending → 超时
  const q2 = new NicknameTaskQueue({ now: () => now })
  q2.request({ actor: 'admin', qqs: ['10001'] })
  now += PENDING_TIMEOUT_MS + 1
  const view = q2.view()
  assert.equal(view.state, 'timeout')
  assert.equal(view.error, PENDING_TIMEOUT_TEXT)
  assert.equal(PENDING_TIMEOUT_TEXT, '机器人未在 120 秒内响应：请确认机器人已启用「昵称刷新」并正在运行')
  assert.equal(view.completedAt, now)
  assert.equal(q2.claim(), null, '已超时的任务不能再被领取')

  // 超时之后重新登记 → 新任务（旧版同口径）
  const next = q2.request({ actor: 'admin', qqs: ['10001', '10002'] })
  assert.notEqual(next.id, view.id)
  assert.equal(next.state, 'pending')
})

test('任务：惰性超时 —— 领取后 300 秒无回报 → timeout 与指定文案（与 120 秒那条互斥）', () => {
  let now = 5_000_000
  const q = new NicknameTaskQueue({ now: () => now })
  const t = q.request({ actor: 'admin', qqs: ['10001'] })
  q.claim()

  // 领取后即使远超 120 秒，也走"未回报"那条而不是"未响应"那条
  now += PENDING_TIMEOUT_MS * 2
  assert.equal(q.view().state, 'claimed', '已领取的任务不受 120 秒未领取判定影响')

  now += RUNNING_TIMEOUT_MS - PENDING_TIMEOUT_MS * 2
  assert.equal(q.view().state, 'claimed', '正好 300 秒不算超时（判定是 >）')

  now += 1
  const view = q.view()
  assert.equal(view.state, 'timeout')
  assert.equal(view.error, RUNNING_TIMEOUT_TEXT)
  assert.equal(RUNNING_TIMEOUT_TEXT, '机器人已开始获取昵称，但 300 秒内未回报结果')
  assert.equal(view.claimedAt != null, true)

  /**
   * 旧版既有行为（刻意保留，不"顺手修"）：超时后**迟到的回报仍会被接受**——
   * finishNicknameTask 只校验 id 匹配，不校验状态，所以 timeout 会被改写成 done。
   * 这样机器人慢一步到达的结果不会被丢弃（页面看到的是真实拿到的东西）。
   */
  const late = q.finish(t.id, { stored: 1, failed: [] })
  assert.equal(late.state, 'done')
  assert.equal(late.stored, 1)
  // 而 id 对不上的回报依旧是 null（没任务时 / 换了任务时都不误改）
  q.reset()
  assert.equal(q.finish(t.id, { stored: 1 }), null)
})

test('任务：终态不会被后续读取改回去（done 不会被反复 touch 覆盖）', () => {
  let now = 1_000
  const q = new NicknameTaskQueue({ now: () => now })
  const t = q.request({ actor: 'admin', qqs: ['10001'] })
  q.claim()
  const done = q.finish(t.id, { stored: 1, failed: [] })
  now += RUNNING_TIMEOUT_MS * 2
  const view = q.view()
  assert.equal(view.state, 'done', 'done 是终态，不会被惰性超时改写成 timeout')
  assert.equal(view.stored, 1)
  assert.equal(view.completedAt, done.completedAt)
})

test('上报条数上限常量与旧版一致（HTTP 层据此回 413）', () => {
  assert.equal(NICKNAME_REPORT_LIMIT, 2000)
  assert.equal(TASK_FAILED_KEEP_LIMIT, 200)
})
