/**
 * 内置 legacy-http 适配器 —— 真实 HTTP 集成测试
 *
 * 目的：用**真实 Express + 真实请求**证明"旧版 Koishi 机器人零改动"这条验收，
 * 并覆盖错误语义（旧版机器人靠 `err.response.data.error` 取提示，见
 * TsWeb/plugin-son/koishi/common/utils/config.ts:46）。
 *
 * 运行：node --test test/
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { once } from 'node:events'
import express from 'express'

import { CapabilityRegistry, AdapterRegistry } from '../adapters/registry.js'
import { createLegacyHttpAdapter } from '../adapters/legacy-http.js'

const TOKEN = 'test-bot-token'

let app
let server
let base
let caps
let adapters
let config
let audits
/** 供测试控制"台账里有哪些绑定" */
let bindings

function makeAdapter() {
  return createLegacyHttpAdapter({
    ctx: { webServer: { app } },
    capabilities: caps,
    adapters,
    getConfig: () => config,
    identify: async (principal, params) => {
      const out = { ...principal }
      const key = String(params.qq || params.player || params.username || '')
      const hit = bindings[key.toLowerCase()]
      if (hit) {
        out.boundUsername = hit.username
        out.qq = hit.qq
      }
      return out
    },
    audit: { append: async (action, entry) => audits.push({ action, ...entry }) },
  })
}

before(async () => {
  app = express()
  app.use(express.json({ limit: '100mb' }))
  caps = new CapabilityRegistry()
  adapters = new AdapterRegistry()
  audits = []
  bindings = {}
  config = { adapters: { 'legacy-http': { enabled: true, token: TOKEN, rateLimit: { perMinute: 0 } } } }

  // 绑定域能力（带旧路径元信息）
  caps.register(
    'binding.bind',
    async ({ principal, params }) => ({
      player: params.player,
      username: params.player,
      qq: params.qq,
      server: '主服',
      uuidSync: null,
      source: principal.adapter,
    }),
    { legacy: { path: '/api/bot/bind', method: 'post' } },
  )
  caps.register(
    'binding.changePassword',
    async ({ principal }) => ({ username: principal.boundUsername }),
    { legacy: { path: '/api/bot/change-password', method: 'post' }, requireBound: true },
  )
  caps.register(
    'binding.resolve',
    async ({ principal, params }) => ({
      username: principal.boundUsername,
      qq: principal.qq,
      playtime: { total: 1234 },
      game: { player: principal.boundUsername, group: 'vip', deaths: 3, fishing_quests: 5, registered: '2026-01-01' },
      serverId: params.serverId || null,
    }),
    { legacy: { path: '/api/bot/player-info', method: 'get' }, requireBound: true },
  )
  // 故意不注册 online.list —— 用于验证"缺能力必须 501"

  adapters.register(makeAdapter())

  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', resolve)
  })
  const { port } = server.address()
  base = `http://127.0.0.1:${port}`
})

after(async () => {
  await new Promise((resolve) => server.close(resolve))
})

/** 与机器人一致：令牌走 query 参数（TsWeb/plugin-son/koishi/common/utils/config.ts:57 把 token 放 params） */
function withToken(pathname, token) {
  if (token === null) return `${base}${pathname}`
  const sep = pathname.includes('?') ? '&' : '?'
  return `${base}${pathname}${sep}token=${encodeURIComponent(token)}`
}

function post(pathname, body, { token = TOKEN } = {}) {
  return fetch(withToken(pathname, token), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  })
}

function get(pathname, { token = TOKEN, header = false } = {}) {
  if (header) return fetch(`${base}${pathname}`, { headers: { 'X-Bot-Token': TOKEN } })
  return fetch(withToken(pathname, token))
}

test('鉴权：token 正确（query 或 X-Bot-Token 头）都能通过', async () => {
  const viaQuery = await post('/api/bot/bind', { qq: '10001', player: 'Steve' })
  assert.equal(viaQuery.status, 200)
  const viaHeader = await get('/api/bot/player-info?qq=10001', { header: true })
  assert.ok([200, 403].includes(viaHeader.status), '头部令牌也应被接受（未绑定时 403 属正常）')
})

test('鉴权：token 不正确 → 401 且错误体是 error 字段（机器人靠它取提示）', async () => {
  const res = await post('/api/bot/bind', { qq: '10001', player: 'Steve' }, { token: 'wrong' })
  assert.equal(res.status, 401)
  const body = await res.json()
  assert.equal(body.error, '机器人密钥不正确')
  assert.ok(audits.some((a) => a.action === 'qqbind.bot.reject' && a.status === 401), '鉴权失败应留审计')
})

test('鉴权：未配置 token → 503（只关闭本适配器）', async () => {
  const saved = config.adapters['legacy-http'].token
  config.adapters['legacy-http'].token = ''
  const res = await post('/api/bot/bind', { qq: '1', player: 'x' })
  assert.equal(res.status, 503)
  assert.match((await res.json()).error, /未配置令牌/)
  config.adapters['legacy-http'].token = saved
})

test('鉴权：适配器关闭 → 503', async () => {
  config.adapters['legacy-http'].enabled = false
  const res = await post('/api/bot/bind', { qq: '10001', player: 'Steve' })
  assert.equal(res.status, 503)
  assert.match((await res.json()).error, /已关闭/)
  config.adapters['legacy-http'].enabled = true
})

test('成功响应形状：{ success, status, ...payload }，机器人读 res.data.player 等字段', async () => {
  const res = await post('/api/bot/bind', { qq: '10001', player: 'Steve', serverId: 's1' })
  assert.equal(res.status, 200)
  const data = await res.json()
  assert.equal(data.success, true)
  assert.equal(data.status, 'ok')
  assert.equal(data.player, 'Steve')
  assert.equal(data.qq, '10001')
  assert.equal(data.server, '主服')
  assert.equal(data.source, 'legacy-http', 'principal 应带接入来源，供审计')
})

test('旧版命令目录：已知但未注册 → 501 并指明该装哪个插件；真未知 → 404', async () => {
  // /api/bot/online 在旧版命令目录里（对应能力 online.list，提供方 online-stats）。
  // 若这里回 404，管理员无从分辨"命令拼错了"还是"插件没装"——这正是 P6 要修的点。
  const known = await get('/api/bot/online')
  assert.equal(known.status, 501, '已知路径但能力未注册 → 501（未装插件要给明确提示）')
  const knownBody = await known.json()
  assert.equal(knownBody.missingCapability, 'online.list')
  assert.equal(knownBody.missingPlugin, 'online-stats')
  assert.match(knownBody.error, /online-stats/)
  assert.ok(knownBody.hint, '要给出"该装哪个插件"的 hint')

  // 完全未知的路径仍是 404，否则两种情形就分不出来了
  const unknown = await get('/api/bot/nonexistent')
  assert.equal(unknown.status, 404)
  assert.match((await unknown.json()).error, /未知的机器人命令/)
})

test('动态查表：适配器挂载后再注册的能力立刻可用（新增能力不必改适配器）', async () => {
  // 注册前：路径已知 → 501（而不是 404），说明是"能力缺席"而非"命令不存在"
  const before = await get('/api/bot/servers')
  assert.equal(before.status, 501)

  caps.register(
    'server.list',
    async () => ({ servers: [{ id: 's1', name: '主服', enabled: true, note: '' }] }),
    { legacy: { path: '/api/bot/servers', method: 'get' } },
  )

  const res = await get('/api/bot/servers')
  assert.equal(res.status, 200)
  const data = await res.json()
  assert.equal(data.servers[0].name, '主服')
})

test('requireBound：未绑定的 QQ 调「我的信息」→ 403，绑定后放行并返回卡片所需字段', async () => {
  const denied = await get('/api/bot/player-info?qq=99999')
  assert.equal(denied.status, 403)
  assert.equal((await denied.json()).needBind, true)

  bindings['10001'] = { username: 'Steve', qq: '10001' }
  const res = await get('/api/bot/player-info?qq=10001')
  assert.equal(res.status, 200)
  const data = await res.json()
  assert.equal(data.username, 'Steve')
  assert.equal(data.playtime.total, 1234, '卡片读 d.playtime.total')
  assert.equal(data.game.group, 'vip', '卡片读 d.game.group')
  assert.equal(data.game.fishing_quests, 5)
})

test('能力抛出的错误透传 status 与附加字段（冲突时机器人要看到冲突服列表）', async () => {
  const off = caps.register(
    'online.list',
    async () => {
      const err = new Error('该角色名在多个服务器存在，请指定服务器后重试')
      err.status = 409
      err.conflict = true
      err.servers = [{ id: 's1', name: '一服' }, { id: 's2', name: '二服' }]
      throw err
    },
    { legacy: { path: '/api/bot/online', method: 'get' } },
  )
  const res = await get('/api/bot/online')
  assert.equal(res.status, 409)
  const body = await res.json()
  assert.equal(body.conflict, true)
  assert.deepEqual(body.servers, [{ id: 's1', name: '一服' }, { id: 's2', name: '二服' }])
  off()
})

test('能力被摘除后：路径回到 501 并指明插件，不返回空数据也不谎报 404', async () => {
  caps.register('vote.list', async () => ({}), { legacy: { path: '/api/bot/votes', method: 'get' } })
  caps.unregister('vote.list')

  const res = await get('/api/bot/votes')
  assert.equal(res.status, 501, '能力被摘除后仍应说明"该路径需要哪个插件"，而不是 404 或空数据')
  const body = await res.json()
  assert.equal(body.missingCapability, 'vote.list')
  assert.match(String(body.missingPlugin), /投票/)
})

test('限流：超过 perMinute 后返回 429 且带 retryAfter', async () => {
  config.adapters['legacy-http'].rateLimit.perMinute = 2
  config.adapters['legacy-http'].rateLimit = { perMinute: 2 }
  const results = []
  for (let i = 0; i < 3; i++) {
    results.push((await post('/api/bot/bind', { qq: '10001', player: 'Steve' })).status)
  }
  assert.equal(results[0], 200)
  assert.equal(results[1], 200)
  assert.equal(results[2], 429)
  assert.ok(audits.some((a) => a.action === 'qqbind.bot.reject' && a.status === 429))
  config.adapters['legacy-http'].rateLimit.perMinute = 0
})

test('参数：token 不进入业务参数（避免泄漏进审计与 handler）', async () => {
  let seen = null
  const off = caps.register(
    'binding.status',
    async ({ params }) => {
      seen = params
      return { bound: false }
    },
    { legacy: { path: '/api/bot/status-check', method: 'post' } },
  )
  await post('/api/bot/status-check', { qq: '10001' })
  assert.equal(seen.token, undefined, 'token 必须被剥掉')
  assert.equal(seen.qq, '10001')
  off()
})

test('未知方法/路径：POST 到只声明 GET 的路径 → 404（不误匹配）', async () => {
  const res = await post('/api/bot/player-info', { qq: '10001' })
  assert.equal(res.status, 404)
})

test('不依赖外部 body 解析中间件：应用未挂 express.json 时 POST 参数仍能到达能力', async () => {
  // 为什么单独测：宿主里挂 express.json() 的是 market 插件（全局中间件），能否先生效
  // 取决于插件加载顺序。适配器必须自带兜底，否则绑定会报"缺少参数: qq"这类把责任
  // 指向机器人的误导错误。这里刻意**不挂任何 json 中间件**，模拟最坏顺序。
  const bare = express()
  const bareCaps = new CapabilityRegistry()
  const bareAdapters = new AdapterRegistry()
  let seen = null

  bareCaps.register(
    'binding.bind',
    async ({ params }) => {
      seen = params
      return { player: params.player, qq: params.qq, serverId: params.serverId }
    },
    { legacy: { path: '/api/bot/bind', method: 'post' } },
  )

  const adapter = createLegacyHttpAdapter({
    ctx: { webServer: { app: bare } },
    capabilities: bareCaps,
    adapters: bareAdapters,
    getConfig: () => ({ adapters: { 'legacy-http': { enabled: true, token: TOKEN, rateLimit: { perMinute: 0 } } } }),
    audit: { append: async () => {} },
  })
  bareAdapters.register(adapter) // register 内部负责 mount 与鉴权登记

  const srv = bare.listen(0, '127.0.0.1')
  await once(srv, 'listening')
  try {
    const res = await fetch(`http://127.0.0.1:${srv.address().port}/api/bot/bind?token=${TOKEN}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ qq: '10001', player: 'Steve', serverId: 's1' }),
    })
    assert.equal(res.status, 200, '不带 json 中间件时也必须能读懂机器人发来的 JSON body')
    const data = await res.json()
    assert.equal(data.qq, '10001')
    assert.equal(data.player, 'Steve')
    assert.equal(data.serverId, 's1')
    assert.equal(seen.token, undefined, 'token 仍必须被剥掉')
  } finally {
    await new Promise((resolve) => srv.close(resolve))
  }
})
