/**
 * 昵称功能的装配级集成测试（真实 cordis Context + 真实 apply + 真实 HTTP）
 *
 * 验证"旧版机器人接得上"这件事到底成不成立：
 *   1. 两条**必须保留**的旧路径经能力注册表注册后 meta.legacy 与旧版一字不差
 *      （GET /api/bot/nickname-task、POST /api/bot/qq-nickname），
 *      且不覆盖、不撞车已有机器的其它能力（含旧路径唯一性）
 *   2. 旧路径走真实 HTTP 的全链路：登记任务 → 机器人领取 → 上报 → 落盘 → 任务 done
 *   3. 上报参数校验（400 / 413 / 2000 边界）与逐条失败语义、failed 视图只回前 50 条
 *   4. 管理侧新路径：POST /api/qq-bind/nickname-refresh、GET /api/qq-bind/nickname-status
 *      （权限与其它管理路由一致，登记写审计）
 *   5. GET /api/qq-bind/list 每行带 nickname；POST /api/qq-bind/lookup 扩展出 nickname 且旧字段不变
 *   6. 解绑/改绑**不清**昵称缓存（旧版既有行为）
 *
 * 注意：本测试**不启动任何服务器进程**，只在测试进程内挂一个 express 实例
 * （与 apply.test.mjs / lookup.test.mjs 同款做法，也不碰任何真实的 TShock 服务器）。
 * 运行：node test/nickname-http.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import express from 'express'
import { Context } from '@deepseek-ai/cordis'

import { NO_BOUND_QQ_TEXT, NICKNAME_REPORT_LIMIT, TASK_FAILED_VIEW_LIMIT } from '../nicknames.js'

const TOKEN = 'nickname-http-bot-token'

let dataDir
let nickFile
let app
let server
let base
let ctx
let svc
let dispose

before(async () => {
  dataDir = await mkdtemp(path.join(tmpdir(), 'qqbind-nickhttp-'))
  nickFile = path.join(dataDir, 'qq-bind', 'nicknames.json')
  process.env.TSWEB_QQBIND_TOKEN = TOKEN

  app = express()
  app.use(express.json({ limit: '100mb' }))

  ctx = new Context()
  ctx.webServer = { app }
  // 鉴权做成**可观测行为**：不带 x-test-auth 头即 401 → "新路由是否真抄了 ...admin"是被行为验证的
  ctx.auth = {
    verifyAuth: () => (req, res, next) =>
      String(req.get('x-test-auth') || '') === 'ok' ? next() : res.status(401).json({ error: '未登录' }),
    requireAdmin: () => (req, res, next) => next(),
  }
  ctx.paths = { dataOf: (n) => path.join(dataDir, n) }
  ctx.logger = { info() {}, warn() {}, error() {} }
  ctx.servers = { list: async () => [], getRaw: () => null }
  ctx.tshock = {
    fetchFor: async () => ({ ok: false, status: 404, data: {} }),
    postFor: async () => ({ ok: false, status: 404, data: {} }),
  }

  const mod = await import('../index.js')
  dispose = mod.apply(ctx)
  await ctx.qqBind.ready
  svc = ctx.qqBind

  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', resolve)
  })
  base = `http://127.0.0.1:${server.address().port}`
})

after(async () => {
  delete process.env.TSWEB_QQBIND_TOKEN
  if (dispose) dispose()
  if (server) await new Promise((resolve) => server.close(resolve))
  await rm(dataDir, { recursive: true, force: true })
})

// ── 请求封装 ────────────────────────────────────────────────

async function readJson(res) {
  const text = await res.text()
  let data = null
  try {
    data = JSON.parse(text)
  } catch {
    data = null
  }
  return { status: res.status, data, text }
}

/** 管理路由 GET（默认带头通过测试鉴权） */
function adminGet(pathname, { auth = 'ok' } = {}) {
  return fetch(`${base}${pathname}`, { headers: auth ? { 'x-test-auth': auth } : {} })
}

/** 管理路由 POST */
function adminPost(pathname, body, { auth = 'ok' } = {}) {
  return fetch(`${base}${pathname}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(auth ? { 'x-test-auth': auth } : {}) },
    body: JSON.stringify(body === undefined ? {} : body),
  })
}

/** 机器人侧请求（令牌走 query 参数，与旧版 Koishi 的 safeHttpGet/safeHttpPost 一致） */
function botGet(pathname) {
  const sep = pathname.includes('?') ? '&' : '?'
  return fetch(`${base}${pathname}${sep}token=${encodeURIComponent(TOKEN)}`)
}

function botPost(pathname, body) {
  const sep = pathname.includes('?') ? '&' : '?'
  return fetch(`${base}${pathname}${sep}token=${encodeURIComponent(TOKEN)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  })
}

/** 造一个干净的起点：空的台账 + 空的昵称缓存 + 空的任务态 */
async function resetWorld(bindings = []) {
  for (const username of svc.ledger.usernames().slice()) {
    try {
      await svc.ledger.unbind({ username })
    } catch {
      /* 已经不在了就算了 */
    }
  }
  for (const [qq, username] of bindings) {
    await svc.ledger.bind({ qq, username, passwordHash: 'h', source: 'test' })
  }
  svc.nicknameTasks.reset()
  await rm(nickFile, { force: true })
}

// ══════════════════════════════════════════════════════════════
// 1. 能力注册表：两条旧路径
// ══════════════════════════════════════════════════════════════

test('能力注册：两条旧路径的 meta.legacy 与旧版一字不差（方法大小写也照旧）', () => {
  const claim = svc.capabilities.get('nickname.claim')
  const report = svc.capabilities.get('nickname.report')
  assert.ok(claim && report, '两条昵称能力都应注册')

  assert.deepEqual(claim.meta.legacy, { path: '/api/bot/nickname-task', method: 'GET' })
  assert.deepEqual(report.meta.legacy, { path: '/api/bot/qq-nickname', method: 'POST' })

  // 适配器就是靠这张表动态投影旧路径的（请求时查表，见 adapters/legacy-http.js:160）
  assert.equal(svc.capabilities.findByLegacy('GET', '/api/bot/nickname-task').name, 'nickname.claim')
  assert.equal(svc.capabilities.findByLegacy('POST', '/api/bot/qq-nickname').name, 'nickname.report')
  assert.equal(svc.capabilities.findByLegacy('get', '/api/bot/nickname-task').name, 'nickname.claim', 'method 大小写不敏感')
  // 方法与路径都必须严格匹配，写错方法不该命中（否则机器人会拿到 404 而不是能力）
  assert.equal(svc.capabilities.findByLegacy('POST', '/api/bot/nickname-task'), null)
  assert.equal(svc.capabilities.findByLegacy('GET', '/api/bot/qq-nickname'), null)
  assert.equal(svc.capabilities.findByLegacy('GET', '/api/bot/nickname-task/'), null, '路径不做模糊匹配')

  // 旧版命令目录里登记了这两条，提供方是 qq-bind
  // （未装本件时，适配器会回 501 + "该装哪个插件"，而不是含混的 404）
  assert.deepEqual(svc.capabilities.catalogFor('GET', '/api/bot/nickname-task'), {
    path: '/api/bot/nickname-task',
    method: 'GET',
    capability: 'nickname.claim',
    provider: 'qq-bind',
  })
  assert.equal(svc.capabilities.catalogFor('POST', '/api/bot/qq-nickname').capability, 'nickname.report')
})

test('能力注册：新增昵称能力**不覆盖**已有机器的其它能力（旧路径唯一、重名注册被拒）', () => {
  // 已有机器的四条绑定路径仍在，且各自指向自己的能力
  const expected = {
    'POST /api/bot/bind': 'binding.bind',
    'POST /api/bot/register': 'binding.register',
    'POST /api/bot/change-password': 'binding.changePassword',
    'GET /api/bot/player-info': 'binding.resolve',
  }
  for (const [key, name] of Object.entries(expected)) {
    const [method, p] = key.split(' ')
    const cap = svc.capabilities.findByLegacy(method, p)
    assert.ok(cap, `${key} 应仍可解析到能力`)
    assert.equal(cap.name, name, `${key} 的能力被改动了`)
  }

  // 全部能力（含昵称域）——列出全部而不是只挑两条，避免"多注册了什么"没人发现
  assert.deepEqual(svc.capabilities.list().map((c) => c.name).sort(), [
    'binding.bind',
    'binding.changePassword',
    'binding.register',
    'binding.resolve',
    'binding.status',
    'nickname.claim',
    'nickname.report',
  ])

  // 旧路径不能重复：重复会让后注册的静默盖掉前一个（适配器的查表是 Map.set）
  const legacyKeys = svc.capabilities.list().filter((c) => c.legacy).map((c) => `${c.legacy.method} ${c.legacy.path}`)
  assert.equal(new Set(legacyKeys).size, legacyKeys.length, '旧路径必须唯一')
  assert.deepEqual(legacyKeys.sort(), [
    'GET /api/bot/nickname-task',
    'GET /api/bot/player-info',
    'POST /api/bot/bind',
    'POST /api/bot/change-password',
    'POST /api/bot/qq-nickname',
    'POST /api/bot/register',
  ])

  // 重名注册一律被拒绝（不是"静默覆盖"）
  assert.throws(() => svc.registerCapability('nickname.claim', async () => ({})), /能力已注册/)
  assert.throws(() => svc.registerCapability('binding.bind', async () => ({})), /能力已注册/)

  // 别的插件晚注册的能力照样能挂上，且不动本件的能力
  const off = svc.registerCapability('online.list', async () => ({ players: [] }), {
    legacy: { path: '/api/bot/online', method: 'get' },
  })
  assert.equal(svc.capabilities.findByLegacy('GET', '/api/bot/online').name, 'online.list')
  assert.equal(svc.capabilities.findByLegacy('GET', '/api/bot/nickname-task').name, 'nickname.claim')
  off()
  assert.equal(svc.capabilities.findByLegacy('GET', '/api/bot/online'), null)
  assert.equal(svc.capabilities.findByLegacy('GET', '/api/bot/nickname-task').name, 'nickname.claim', '摘除别家能力不得影响本件')
})

// ══════════════════════════════════════════════════════════════
// 2. 旧路径端到端
// ══════════════════════════════════════════════════════════════

test('旧路径端到端：登记 → 机器人领取 → 上报 → 落盘 → 任务 done（页面拿到的就是新昵称）', async () => {
  await resetWorld([
    ['10001', 'Steve'],
    ['10002', 'Alex'],
  ])

  // 鉴权由 legacy-http 适配器负责（能力里不再校验一遍）：不带 token → 401
  const noToken = await fetch(`${base}/api/bot/nickname-task`)
  const noTokenBody = await readJson(noToken)
  assert.equal(noTokenBody.status, 401)
  assert.equal(noTokenBody.data.error, '机器人密钥不正确')

  // 管理页点「获取昵称」：登记任务（旧版 POST /api/bot/nickname-refresh 的管理面新路径）
  const refresh = await readJson(await adminPost('/api/qq-bind/nickname-refresh', {}))
  assert.equal(refresh.status, 200, refresh.text)
  assert.equal(refresh.data.ok, true)
  assert.equal(refresh.data.task.total, 2, '待取 QQ 来自台账且去重')
  assert.equal(refresh.data.task.state, 'pending')
  const taskId = refresh.data.task.id

  // 登记要写审计（沿用本插件 qqbind.* 事件名风格；旧版是 qq_nickname.refresh）
  const audit = await svc.audit.tail(20)
  const rec = audit.find((a) => a.action === 'qqbind.nickname.refresh')
  assert.ok(rec, '登记任务应留审计')
  assert.equal(rec.taskId, taskId)
  assert.equal(rec.total, 2)
  assert.equal(rec.actor, 'admin', '测试请求没有 req.user，actor 回落到 admin（旧版同口径）')

  // 连点第二次：返回同一个任务，不重复登记
  const refresh2 = await readJson(await adminPost('/api/qq-bind/nickname-refresh', {}))
  assert.equal(refresh2.data.task.id, taskId, '已有进行中的任务 → 原样返回')

  // 机器人轮询领取（GET /api/bot/nickname-task?token=…）
  const claim = await readJson(await botGet('/api/bot/nickname-task'))
  assert.equal(claim.status, 200, claim.text)
  assert.equal(claim.data.success, true)
  assert.equal(claim.data.status, 'ok')
  assert.equal(claim.data.task.id, taskId)
  assert.deepEqual(claim.data.task.qqs.slice().sort(), ['10001', '10002'])
  assert.equal(claim.data.task.total, 2)

  // 领取一次后不再被领取（机器人每 15 秒轮询一次，不能重复干活）
  const claimAgain = await readJson(await botGet('/api/bot/nickname-task'))
  assert.equal(claimAgain.status, 200)
  assert.equal(claimAgain.data.task, null, '没有待领取任务时 task 必须是 null')

  // 上报（POST /api/bot/qq-nickname）：一条成功、一条机器人明确报错
  const report = await readJson(
    await botPost('/api/bot/qq-nickname', {
      taskId,
      entries: [
        { qq: '10001', nickname: '小明' },
        { qq: '10002', error: '平台未返回昵称' },
      ],
    }),
  )
  assert.equal(report.status, 200, report.text)
  assert.equal(report.data.success, true)
  assert.equal(report.data.stored, 1)
  assert.equal(report.data.skipped, 1)
  assert.deepEqual(report.data.failed, [{ qq: '10002', error: '平台未返回昵称' }])
  assert.equal(report.data.task.state, 'done', '带 taskId 的回报应把任务收尾')

  // 落盘（结构沿用旧版 { schema, updatedAt, records }）
  const raw = JSON.parse(await readFile(nickFile, 'utf8'))
  assert.equal(raw.schema, 1)
  assert.equal(raw.records['10001'].nickname, '小明')
  assert.equal(raw.records['10001'].source, 'bot', '旧版上报固定写 source:bot')
  assert.equal(raw.records['10002'], undefined, '失败条目不写入')

  // 管理页轮询任务状态
  const status = await readJson(await adminGet('/api/qq-bind/nickname-status'))
  assert.equal(status.status, 200, status.text)
  assert.equal(status.data.ok, true)
  assert.equal(status.data.task.state, 'done')
  assert.equal(status.data.task.stored, 1)
  assert.equal(status.data.task.failedCount, 1)
  assert.deepEqual(status.data.task.failed, [{ qq: '10002', error: '平台未返回昵称' }])

  // 绑定列表按 QQ 带出昵称：有昵称的给昵称，没取到的给空串
  const list = await readJson(await adminGet('/api/qq-bind/list?page=1&pageSize=50'))
  assert.equal(list.status, 200, list.text)
  const byName = {}
  for (const row of list.data.rows) byName[row.username] = row
  assert.equal(byName.Steve.nickname, '小明')
  assert.equal(byName.Alex.nickname, '', '未取到昵称 → 空串（不是 undefined，也不拿 QQ 号冒充）')
})

test('旧路径：没有任何已绑定 QQ → 领取直接 done 并带说明（不让机器人空转、页面不转圈）', async () => {
  await resetWorld([])

  const refresh = await readJson(await adminPost('/api/qq-bind/nickname-refresh', {}))
  assert.equal(refresh.status, 200, refresh.text)
  assert.equal(refresh.data.task.total, 0)
  assert.equal(refresh.data.task.state, 'pending')

  const claim = await readJson(await botGet('/api/bot/nickname-task'))
  assert.equal(claim.status, 200)
  assert.deepEqual(claim.data.task.qqs, [], '没有 QQ 要取，机器人据此什么都不做')

  const status = await readJson(await adminGet('/api/qq-bind/nickname-status'))
  assert.equal(status.data.task.state, 'done')
  assert.equal(status.data.task.error, NO_BOUND_QQ_TEXT)
  assert.equal(status.data.task.stored, 0)
})

// ══════════════════════════════════════════════════════════════
// 3. 上报参数校验与逐条语义
// ══════════════════════════════════════════════════════════════

test('上报：entries 非数组 → 400「缺少参数: entries（数组）」', async () => {
  for (const body of [{}, { entries: null }, { entries: 'x' }, { entries: { 0: { qq: '10001' } } }]) {
    const res = await readJson(await botPost('/api/bot/qq-nickname', body))
    assert.equal(res.status, 400, JSON.stringify(body) + ' → ' + res.text)
    assert.equal(res.data.error, '缺少参数: entries（数组）')
  }
})

test('上报：超过 2000 条 → 413；恰好 2000 条仍接受（边界与文案照旧版）', async () => {
  const over = Array.from({ length: NICKNAME_REPORT_LIMIT + 1 }, (_, i) => ({
    qq: String(70000 + i),
    error: '未取到昵称',
  }))
  const res = await readJson(await botPost('/api/bot/qq-nickname', { entries: over }))
  assert.equal(res.status, 413, res.text)
  assert.equal(res.data.error, `单次上报条数超过上限 ${NICKNAME_REPORT_LIMIT}`)
  assert.equal(NICKNAME_REPORT_LIMIT, 2000)

  // 恰好 2000 条：全部是"未取到"（不写入任何昵称），所以只是把计数与逐条原因回出来
  const edge = await readJson(await botPost('/api/bot/qq-nickname', { entries: over.slice(0, NICKNAME_REPORT_LIMIT) }))
  assert.equal(edge.status, 200, edge.text)
  assert.equal(edge.data.stored, 0)
  assert.equal(edge.data.skipped, NICKNAME_REPORT_LIMIT)
  assert.equal(edge.data.failed.length, NICKNAME_REPORT_LIMIT, '回报里的逐条原因不截断（页面要显示哪些没取到）')
  assert.equal(edge.data.task, null, '没带 taskId → 不动任何任务')
})

test('上报：逐条状态语义（格式不对 / 条目自带 error 原样带出 / 未取到昵称），且空值不覆盖已有昵称', async () => {
  await resetWorld([['10001', 'Steve']])

  // 先取到一次昵称
  await svc.nicknameStore().saveNicknames([{ qq: '10001', nickname: '小明' }])
  assert.equal(await svc.nicknameOf('10001'), '小明')

  const longError = 'x'.repeat(300)
  const res = await readJson(
    await botPost('/api/bot/qq-nickname', {
      entries: [
        { qq: 'abc', nickname: '格式不对' },
        { qq: '10002', error: longError },
        { qq: '10003', nickname: '   ' },
        { qq: '10004' },
        { qq: '10001', nickname: '' },
      ],
    }),
  )
  assert.equal(res.status, 200, res.text)
  assert.equal(res.data.stored, 0)
  assert.equal(res.data.skipped, 5)
  assert.deepEqual(
    res.data.failed.map((f) => f.error),
    ['QQ 号格式不正确', longError.slice(0, 200), '未取到昵称', '未取到昵称', '未取到昵称'],
  )
  assert.equal(res.data.failed[1].error.length, 200, '条目自带 error 截断 200 字')
  assert.equal(await svc.nicknameOf('10001'), '小明', '空值绝不覆盖已有昵称（无 TTL，只有下次成功才覆盖）')
})

test('上报：任务视图 failed 只回前 50 条，failedCount 才是真实条数', async () => {
  await resetWorld([['10001', 'Steve']])
  const qqs = Array.from({ length: 60 }, (_, i) => String(80000 + i))
  const task = svc.requestNicknameTask({ actor: 'test', qqs })
  assert.equal(task.total, 60)

  const claim = await readJson(await botGet('/api/bot/nickname-task'))
  assert.deepEqual(claim.data.task.qqs, qqs)

  const entries = claim.data.task.qqs.map((qq) => ({ qq, error: '平台未返回昵称' }))
  const report = await readJson(await botPost('/api/bot/qq-nickname', { taskId: task.id, entries }))
  assert.equal(report.status, 200, report.text)
  assert.equal(report.data.failed.length, 60, '回报本身给全量逐条原因')
  assert.equal(report.data.task.failedCount, 60)
  assert.equal(report.data.task.failed.length, TASK_FAILED_VIEW_LIMIT, '任务视图只回前 50 条')
  assert.equal(TASK_FAILED_VIEW_LIMIT, 50)

  const status = await readJson(await adminGet('/api/qq-bind/nickname-status'))
  assert.equal(status.data.task.failedCount, 60)
  assert.equal(status.data.task.failed.length, 50)
  assert.equal(status.data.task.state, 'done')
})

// ══════════════════════════════════════════════════════════════
// 4. 管理侧新路径的权限
// ══════════════════════════════════════════════════════════════

test('管理侧新路径与其它管理路由同权限（未鉴权 → 401，不返回任务数据）', async () => {
  const status = await readJson(await adminGet('/api/qq-bind/nickname-status', { auth: '' }))
  assert.equal(status.status, 401, status.text)
  assert.equal(status.data.task, undefined)

  const refresh = await readJson(await adminPost('/api/qq-bind/nickname-refresh', {}, { auth: '' }))
  assert.equal(refresh.status, 401, refresh.text)
  assert.equal(refresh.data.task, undefined)
})

// ══════════════════════════════════════════════════════════════
// 5. lookup 扩展（向后兼容）
// ══════════════════════════════════════════════════════════════

test('lookup：新增 nickname 字段但 qq / missing / count 语义一字未改（老调用方不受影响）', async () => {
  await resetWorld([
    ['10001', 'Steve'],
    ['10002', 'Alex'],
  ])
  await svc.nicknameStore().saveNicknames([{ qq: '10001', nickname: '小明' }])

  const res = await readJson(await adminPost('/api/qq-bind/lookup', { names: ['Steve', 'Alex', 'Nobody'] }))
  assert.equal(res.status, 200, res.text)
  assert.deepEqual(res.data, {
    ok: true,
    qq: { Steve: '10001', Alex: '10002' },
    nickname: { Steve: '小明' },
    missing: ['Nobody'],
    count: 2,
  })
  assert.equal(res.data.nickname.Alex, undefined, '已绑定但没取到昵称 → 不回键（前端据此只显示 QQ 号）')

  // 大小写不同的名字：qq 与 nickname 的键都按"传入原文"回（老口径不变）
  const ci = await readJson(await adminPost('/api/qq-bind/lookup', { names: ['STEVE', 'alex'] }))
  assert.equal(ci.data.qq.STEVE, '10001')
  assert.equal(ci.data.nickname.STEVE, '小明')
  assert.equal(ci.data.qq.alex, '10002')
  assert.equal(Object.prototype.hasOwnProperty.call(ci.data.nickname, 'alex'), false)
})

test('lookup：名字叫 __proto__ 时昵称也如实回键（不被原型链吞掉）', async () => {
  await resetWorld([['10009', '__proto__']])
  await svc.nicknameStore().saveNicknames([{ qq: '10009', nickname: '原型' }])

  const res = await readJson(await adminPost('/api/qq-bind/lookup', { names: ['__proto__', 'toString'] }))
  assert.equal(res.status, 200, res.text)
  assert.equal(Object.prototype.hasOwnProperty.call(res.data.qq, '__proto__'), true)
  assert.equal(res.data.qq['__proto__'], '10009')
  assert.equal(Object.prototype.hasOwnProperty.call(res.data.nickname, '__proto__'), true)
  assert.equal(res.data.nickname['__proto__'], '原型')
  assert.equal({}.nickname, undefined, '不得污染 Object.prototype')
  assert.deepEqual(res.data.missing, ['toString'])
})

// ══════════════════════════════════════════════════════════════
// 6. 缓存与绑定关系解耦
// ══════════════════════════════════════════════════════════════

test('解绑 / 改绑**不清**昵称缓存（旧版既有行为：昵称归属是 QQ 号）', async () => {
  await resetWorld([['10001', 'Steve'], ['10002', 'Alex']])
  await svc.nicknameStore().saveNicknames([
    { qq: '10001', nickname: '小明' },
    { qq: '10002', nickname: '小红' },
  ])

  // 解绑后昵称还在（旧版定义了 removeNickname 却从不调用，这里把该行为钉死）
  await svc.ledger.unbind({ username: 'Steve' })
  assert.equal(svc.qqOf('Steve'), null)
  assert.equal(await svc.nicknameOf('10001'), '小明', '解绑不清缓存')

  // 重新绑回同一 QQ：昵称立刻可用（不必再等机器人取一次）
  await svc.ledger.bind({ qq: '10001', username: 'Steve', passwordHash: 'h', source: 'test' })
  const list = await readJson(await adminGet('/api/qq-bind/list?page=1&pageSize=50'))
  const steve = list.data.rows.find((r) => r.username === 'Steve')
  assert.equal(steve.nickname, '小明')

  // 昵称按 QQ 建键：解绑后重新绑到**另一个** QQ，不会串到别人身上
  await svc.ledger.unbind({ username: 'Steve' })
  await svc.ledger.bind({ qq: '10003', username: 'Steve', passwordHash: 'h', source: 'test' })
  const list2 = await readJson(await adminGet('/api/qq-bind/list?page=1&pageSize=50'))
  const steve2 = list2.data.rows.find((r) => r.username === 'Steve')
  assert.equal(steve2.nickname, '', '新 QQ 还没取过昵称 → 空串（不会显示上一个 QQ 的昵称）')
  assert.equal(await svc.nicknameOf('10001'), '小明', '旧 QQ 的昵称仍然留着')
})
