/**
 * 台账（ledger.js）单元测试
 *
 * 覆盖旧版语义中最容易写错的几条：
 *   1:1 双向约束 / 大小写不敏感 + aliases / 原子落盘与备份 /
 *   改名迁移（含仅大小写变化）/ 转移 / 解绑保留其他记录 / 导入幂等与冲突
 *
 * 运行：node --test test/
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { Ledger, isValidQq, normKey } from '../ledger.js'

let dir
let file

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), 'qqbind-ledger-'))
  file = path.join(dir, 'bindings.json')
})

after(async () => {
  await rm(dir, { recursive: true, force: true })
})

function freshLedger(name, onChange) {
  return new Ledger({ file: path.join(dir, `${name}.json`), onChange })
}

test('QQ 号格式校验：5-15 位数字，其余一律拒绝', () => {
  assert.equal(isValidQq('12345'), true)
  assert.equal(isValidQq('123456789012345'), true)
  assert.equal(isValidQq('1234'), false)
  assert.equal(isValidQq('1234567890123456'), false)
  assert.equal(isValidQq('abcde'), false)
  assert.equal(isValidQq(' 12345 '), true, '首尾空白应先规范化')
  assert.equal(normKey('  Steve  '), 'steve')
})

test('新建台账：文件不存在视为可信空台账', async () => {
  const led = freshLedger('empty')
  const snap = await led.load()
  assert.equal(led.size, 0)
  assert.equal(snap.schema, 1)
})

test('绑定：双向 1:1 约束与旧版文案', async () => {
  const led = freshLedger('one-to-one')
  await led.load()
  await led.bind({ qq: '10001', username: 'Steve', passwordHash: 'h1', source: 'test' })

  assert.equal(led.getByQq('10001').username, 'Steve')
  assert.equal(led.getByUsername('steve').username, 'Steve', '按名查应大小写不敏感')
  assert.equal(led.isBound('Steve'), true)

  await assert.rejects(
    () => led.bind({ qq: '10001', username: 'Alex', passwordHash: 'h2' }),
    (err) => err.status === 409 && /该 QQ 已绑定角色/.test(err.message) && err.owner === 'Steve',
  )
  await assert.rejects(
    () => led.bind({ qq: '10002', username: 'sTeVe', passwordHash: 'h3' }),
    (err) => err.status === 409 && /该角色已绑定 QQ：10001/.test(err.message),
  )
  await assert.rejects(
    () => led.bind({ qq: 'abc', username: 'Alex' }),
    (err) => err.status === 400 && /QQ 号格式不正确/.test(err.message),
  )
  assert.equal(led.size, 1)
})

test('落盘：原子写 + 备份 + 可重新载入', async () => {
  const led = freshLedger('persist')
  await led.load()
  await led.bind({ qq: '20001', username: 'Hero', passwordHash: 'hash-x' })
  const raw = JSON.parse(await readFile(led.file, 'utf8'))
  assert.equal(raw.schema, 1)
  assert.equal(raw.records.Hero.qq, '20001')
  assert.equal(raw.aliases.hero, 'Hero')

  await led.bind({ qq: '20002', username: 'Hero2' })
  const bak = JSON.parse(await readFile(led.bakFile, 'utf8'))
  assert.equal(Object.keys(bak.records).length, 1, '第二次落盘应留下上一版备份')

  const reloaded = freshLedger('persist')
  await reloaded.load()
  assert.equal(reloaded.size, 2)
  assert.equal(reloaded.getByUsername('HERO').passwordHash, 'hash-x')
})

test('解绑：只删绑定关系并保留别名', async () => {
  const led = freshLedger('unbind')
  await led.load()
  await led.bind({ qq: '30001', username: 'Bob' })
  await led.bind({ qq: '30002', username: 'Carol' })

  const rec = await led.unbind({ username: 'bob' })
  assert.equal(rec.username, 'Bob')
  assert.equal(led.getByUsername('Bob'), null)
  assert.equal(led.size, 1, '其它记录不受影响')
  assert.equal(led.aliases.bob, 'Bob', '别名保留，便于改名历史解析')

  await assert.rejects(
    () => led.unbind({ username: 'Bob' }),
    (err) => err.status === 404 && /未绑定 QQ/.test(err.message),
  )
  await assert.rejects(
    () => led.unbind({}),
    (err) => err.status === 400 && /缺少参数/.test(err.message),
  )
})

test('改名：迁移 key 并保留 qq/哈希/绑定时间；仅大小写变化也支持', async () => {
  const led = freshLedger('rename')
  await led.load()
  await led.bind({ qq: '40001', username: 'Dave', passwordHash: 'hash-d' })
  const before = led.getByUsername('Dave')

  await led.rename('dave', 'David')
  assert.equal(led.getByUsername('David').qq, '40001')
  assert.equal(led.getByUsername('David').passwordHash, 'hash-d')
  assert.equal(led.getByUsername('David').boundAt, before.boundAt, '绑定时间应保留')
  assert.equal(led.getByUsername('Dave'), null)

  await led.rename('David', 'david')
  assert.equal(led.getByUsername('DAVID').username, 'david', '仅大小写变化：更新原始大小写且不产生重复')

  await led.bind({ qq: '40002', username: 'Erin' })
  await assert.rejects(
    () => led.rename('Erin', 'david'),
    (err) => err.status === 409,
  )
})

test('改名：未绑定角色不报错而是跳过（改名叫 base 联动时常见）', async () => {
  const led = freshLedger('rename-skip')
  await led.load()
  const rec = await led.rename('Nobody', 'Somebody')
  assert.equal(rec.skipped, 'not-bound')
})

test('换绑与转移：1:1 约束贯穿', async () => {
  const led = freshLedger('rebind')
  await led.load()
  await led.bind({ qq: '50001', username: 'Frank', passwordHash: 'h-f' })
  await led.bind({ qq: '50002', username: 'Grace' })

  await led.rebind({ username: 'frank', newQq: '50009' })
  assert.equal(led.getByQq('50009').username, 'Frank')
  assert.equal(led.getByQq('50001'), null)

  await assert.rejects(
    () => led.rebind({ username: 'Frank', newQq: '50002' }),
    (err) => err.status === 409 && /该 QQ 已绑定角色：Grace/.test(err.message),
  )
  await assert.rejects(
    () => led.rebind({ username: 'Frank', newQq: '50009' }),
    (err) => err.status === 400 && /均未变化/.test(err.message),
  )

  const moved = await led.transfer({ fromUsername: 'Frank', toUsername: 'Heidi', passwordHash: 'h-h' })
  assert.equal(moved.toUsername, 'Heidi')
  assert.equal(led.getByUsername('Frank'), null, '原角色不再绑定')
  assert.equal(led.getByUsername('Heidi').qq, '50009')
  assert.equal(led.getByUsername('Heidi').passwordHash, 'h-h', '新角色用新哈希')
})

test('导入：幂等 + 冲突逐条列出 + dryRun 不落盘', async () => {
  const legacy = {
    records: {
      Ivan: { qq: '60001', passwordHash: 'h-i', updatedAt: '2026-01-01T00:00:00.000Z' },
      Judy: { qq: '60002', passwordHash: 'h-j' },
      Broken: { qq: 'abc' },
    },
  }
  const led = freshLedger('import')
  await led.load()

  const dry = await led.import(legacy, { dryRun: true })
  assert.equal(dry.applied, false)
  assert.equal(led.size, 0, 'dryRun 不落盘')
  assert.equal(dry.imported.length, 2)
  assert.equal(dry.skipped.length, 1, 'QQ 格式不合法应被跳过')

  const first = await led.import(legacy)
  assert.equal(first.imported.length, 2)
  assert.equal(led.size, 2)
  assert.equal(led.getByUsername('Ivan').source, 'import')

  const second = await led.import(legacy)
  assert.equal(second.imported.length, 0, '重复导入必须幂等')
  assert.equal(second.skipped.length, 3, '已存在且一致 → 跳过；非法 QQ → 跳过')

  const conflict = await led.import({ records: { Ivan: { qq: '60099' }, Zoe: { qq: '60002' } } })
  assert.equal(conflict.conflicts.length, 2, '改号与 QQ 占用都应报冲突')
  assert.equal(led.getByUsername('Ivan').qq, '60001', '冲突不得覆盖既有绑定')
})

test('列表：关键字过滤（角色名与 QQ）+ 分页', async () => {
  const led = freshLedger('list')
  await led.load()
  await led.bind({ qq: '70001', username: 'Alpha' })
  await led.bind({ qq: '78901', username: 'Beta' })
  await led.bind({ qq: '70003', username: 'Gamma' })

  assert.equal(led.list({}).total, 3)
  assert.deepEqual(led.list({ keyword: 'alph' }).rows.map((r) => r.username), ['Alpha'])
  assert.deepEqual(led.list({ keyword: '789' }).rows.map((r) => r.username), ['Beta'])
  const paged = led.list({ page: 2, pageSize: 2 })
  assert.equal(paged.rows.length, 1)
  assert.equal(paged.total, 3)
})

test('变更回调：每次落盘都上报动作（改名事件是修旧版 B1 缺陷的抓手）', async () => {
  const seen = []
  const led = freshLedger('onchange', (evt) => seen.push(evt.action))
  await led.load()
  await led.bind({ qq: '80001', username: 'Ken' })
  await led.rename('Ken', 'Kenny')
  await led.setPasswordHash('Kenny', 'new-hash')
  await led.remove('Kenny')
  assert.deepEqual(seen, ['bound', 'renamed', 'password-changed', 'removed'])
})

test('落盘失败不产生半写入文件（.tmp 不残留）', async () => {
  const led = freshLedger('atomic')
  await led.load()
  await led.bind({ qq: '90001', username: 'Mia' })
  const raw = await readFile(led.file, 'utf8')
  assert.ok(raw.trim().endsWith('}'))
  await assert.rejects(() => readFile(`${led.file}.tmp`, 'utf8'), (err) => err.code === 'ENOENT')
})

test('损坏台账：显式报错而不是静默清空', async () => {
  const broken = path.join(dir, 'broken.json')
  await writeFile(broken, '{ not json ', 'utf8')
  const led = new Ledger({ file: broken })
  await assert.rejects(() => led.load(), (err) => /不是合法 JSON/.test(err.message))

  const badShape = path.join(dir, 'badshape.json')
  await writeFile(badShape, JSON.stringify({ records: [] }), 'utf8')
  const led2 = new Ledger({ file: badShape })
  await assert.rejects(() => led2.load(), (err) => /records 形状非法/.test(err.message))
})
