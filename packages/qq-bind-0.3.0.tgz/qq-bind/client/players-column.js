/**
 * qq-bind 前端半 —— 玩家列表「QQ 号」列
 *
 * 用宿主新增的列注册表 window.tsweb.registerPlayerListColumn（plugins/web/public/app.js:61-90）：
 * 玩家列表是 **base 插件的页面**，本件不改它一行代码，只往里注册一列。
 *
 * 接口（已冻结）：
 *   registerPlayerListColumn({ id, title, order, width, align, prepare(accounts), render(account, data) })
 *   - prepare 整页只调一次，收本页行对象数组；行字段是 TShock 原样字段（首字母大写，
 *     Username / Usergroup / IsOnline / HasCharacter / Registered / LastAccessed，
 *     见 plugins/base/plugin/PlayerList.cs:145-177），所以取 account.Username。
 *   - render 返回**该单元格的 HTML 字符串**，必须自己转义。
 *   - prepare 的返回值作为第二个参数传给每一行的 render；单列抛错只降级该列为空单元格。
 *
 * 单元格展示口径（**旧版 TsWeb/frontend/src/components/PlayerList.vue:499-505 对齐**）：
 *   - 有昵称 → 「昵称（QQ号）」（昵称是主文本，QQ 号退成次要的括号内容）
 *   - 无昵称 → 只显示 QQ 号
 *   - 昵称与 QQ 号相同 → 只显示一次（旧版 VoteSettingsView.vue:297-305 的 voterQq 同口径）
 *   - 未绑定 → 「-」
 *   绝不用角色名冒充昵称：昵称只来自缓存，取不到就是取不到。
 *
 * 数据来源（POST /api/qq-bind/lookup，见 plugins/qq-bind/index.js 的该路由）：
 *   请求 { names:[角色名] } → 响应 { ok, qq:{名字:QQ号}, nickname:{名字:昵称}, missing, count }
 *   两个映射的键口径一致（**传入名字原文**），值缺失时不回键 —— 所以两个 pick 用同一套判断。
 *   nickname 是**后加字段**：旧版宿主（或尚未升级的后端半）不回它时，
 *   本列只降级"昵称那一半"，QQ 号照常显示（不能因为一个可选字段把整列变成「-」）。
 *
 * 健壮性（硬要求）：本列挂在**别的插件**的页面上，qq-bind 挂掉绝不能连带玩家列表报错或空白。
 * 所以 prepare 永不抛错，任何失败都降级成"整列显示 -"，并且只 console.warn 一次。
 *
 * 注意（超时是必需的，不是优化）：宿主的 prepareListColumns（players.js:157-171）对每个列**串行 await**，
 * 而 renderRows 在它之后才执行 —— prepare 只要不 resolve，玩家列表就"表头在、表体永远空白"。
 * 浏览器 fetch 默认无超时，所以下面用 raceTimeout 给整次 prepare 一个硬预算，到点即降级。
 */
import { esc, req, pickQq, pickNick, warnOnce, errText, raceTimeout } from './shared.js'

/** 单次 lookup 的条数上限，与后端一致（plugins/qq-bind/index.js LOOKUP_LIMIT = 500；超出返回 400） */
var LOOKUP_LIMIT = 500

/**
 * 整次 prepare 的总时间预算（毫秒）。超预算就当失败降级，绝不继续等。
 * 取 5 秒：正常情况下这一页最多两个分片请求（几百毫秒），5 秒足够宽松；再久用户已经在看空表了。
 */
var PREPARE_TIMEOUT_MS = 5000

var tsw = window.tsweb

if (tsw && typeof tsw.registerPlayerListColumn === 'function') {
  try {
    tsw.registerPlayerListColumn({
      id: 'qq-bind-qq',
      title: 'QQ 号',
      // 排在「最后访问」之后、「角色」之前（宿主按 order 升序插入）
      order: 100,
      width: '110px',
      align: '',

      /**
       * 整页只调一次：把本页所有角色名一次性批量查掉（QQ 号与昵称在同一个响应里）。
       * 任何失败（超时 / 网络错误 / 非 2xx / 响应体缺 qq 字段）都走同一条降级路径：
       * 返回空映射 { qq: {}, nickname: {} }，render 就把每行都渲染成 "-"，页面本身完全不受影响。
       */
      prepare: async function (accounts) {
        var list = Array.isArray(accounts) ? accounts : []
        var names = []
        /**
         * 去重表必须用 null 原型对象：角色名允许叫 toString / constructor / hasOwnProperty，
         * 用普通 {} 时 `seen['toString']` 读到的是 Object.prototype.toString（真值），
         * 这个角色名会被当成"已见过"而**静默漏查**，那一行的 QQ 号就永远是「-」。
         */
        var seen = Object.create(null)
        var i
        for (i = 0; i < list.length; i++) {
          var raw = list[i] && list[i].Username
          var name = raw == null ? '' : String(raw)
          if (!name || seen[name]) continue
          seen[name] = true
          names.push(name)
        }
        if (!names.length) return { qq: {}, nickname: {} }

        /** 唯一的降级出口：只 warn 一次，一律返回空映射（=> 整列显示 -） */
        function degrade(reason) {
          warnOnce('players-column',
            '[qq-bind] 玩家列表「QQ 号」列查询失败，本列暂时全部显示为「-」：' + reason)
          return { qq: {}, nickname: {}, failed: true }
        }

        // 总预算：不是"每个请求各给 5 秒"，否则分片多时总时长会成倍放大，照样能拖住表体
        var deadline = Date.now() + PREPARE_TIMEOUT_MS

        // 同样用 null 原型：合并时若键叫 __proto__，写进普通对象会去改原型而不是存键
        var merged = Object.create(null)
        var mergedNick = Object.create(null)
        // 分片：后端单次上限 500，一页超过 500 行时不能把整页请求丢成 400
        for (var from = 0; from < names.length; from += LOOKUP_LIMIT) {
          var left = deadline - Date.now()
          if (left <= 0) return degrade('已超过 ' + PREPARE_TIMEOUT_MS + ' 毫秒预算（未开始本批查询）')

          var chunk = names.slice(from, from + LOOKUP_LIMIT)
          // AbortController 只是顺手取消连接（宿主目前不透传 signal，见 shared.js raceTimeout 注释），
          // 真正保证不挂住的是 raceTimeout 的硬超时
          var ctrl = (typeof AbortController === 'function') ? new AbortController() : null
          var raced = await raceTimeout(
            req('/api/qq-bind/lookup', {
              method: 'POST',
              json: { names: chunk },
              signal: ctrl ? ctrl.signal : undefined,
            }),
            left)
          if (raced.timedOut) {
            if (ctrl) { try { ctrl.abort() } catch (e) { /* 忽略 */ } }
            return degrade('请求超过 ' + PREPARE_TIMEOUT_MS + ' 毫秒未返回（已放弃等待）')
          }

          var res = raced.value
          if (!res || res.ok !== true || !res.data || res.data.ok === false) {
            return degrade(errText(res))
          }
          // 2xx 但缺 qq 字段 = 契约被破坏，不能当成"谁都没绑定"静默放过，否则后端回归时
          // 整列显示 - 却不报错，没人能发现
          var part = res.data.qq
          if (!part || typeof part !== 'object' || Array.isArray(part)) {
            return degrade('响应缺少 qq 字段（HTTP ' + (res.status || 200) + '）')
          }
          for (var k in part) {
            if (Object.prototype.hasOwnProperty.call(part, k)) merged[k] = part[k]
          }
          /**
           * 昵称是**后加的可选字段**，与 qq 字段的契约强度刻意不同：
           * 缺失或形状不对时只让"昵称那一半"为空（该行退回只显示 QQ 号），
           * 而不是把整列降级成「-」。理由：老后端半不会回 nickname，
           * 若按 qq 字段的标准报"契约被破坏"，升级不同步时整列 QQ 号都会消失——
           * 一个可选展示字段不该有这种杀伤力。
           */
          var npart = res.data.nickname
          if (npart && typeof npart === 'object' && !Array.isArray(npart)) {
            for (var nk in npart) {
              if (Object.prototype.hasOwnProperty.call(npart, nk)) mergedNick[nk] = npart[nk]
            }
          }
        }
        return { qq: merged, nickname: mergedNick }
      },

      /**
       * 单行渲染。任何意外（data 缺失、账号对象形状变了）都返回 "-"，
       * 绝不抛错——宿主对单列抛错的兜底是"该列为空单元格"，但那个行为不该由我们来触发。
       */
      render: function (account, data) {
        try {
          var name = account && account.Username
          var qq = (data && data.qq) ? pickQq(data.qq, name) : ''
          if (!qq) return '<span class="muted">-</span>'
          var nick = (data && data.nickname) ? pickNick(data.nickname, name) : ''
          // 昵称与 QQ 号相同时不重复显示（旧版 voterQq 口径）；昵称缺失时只显示 QQ 号
          if (!nick || nick === qq) return esc(qq)
          return esc(nick) + '<span class="muted">（' + esc(qq) + '）</span>'
        } catch (e) {
          return '<span class="muted">-</span>'
        }
      },
    })
  } catch (err) {
    console.warn('[qq-bind] 注册玩家列表「QQ 号」列失败：' + ((err && err.message) || err))
  }
} else {
  // 宿主版本过旧（app.js 还没有列注册表）：安静跳过，不影响其它模块注册
  console.warn('[qq-bind] 宿主未提供 window.tsweb.registerPlayerListColumn，玩家列表「QQ 号」列未注册')
}
