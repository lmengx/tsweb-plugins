/**
 * qq-bind 前端半 —— 客户端入口
 *
 * 宿主（plugins/web）每个插件只加载**一个** client 文件（package.json 的 tsweb.client 字段，
 * 见 src/loader.js:186-216：默认 ./client/client.js，本件显式声明 ./client/qq-bind.js），
 * 所以这里作为入口，引入本件的三个功能模块；三者各自在顶层调用注册 API：
 *   - admin.js           管理页「QQ 绑定」（#/b/qq-bind：绑定列表 / 设置 / 审计）
 *   - players-column.js  往玩家列表加一列「QQ 号」（registerPlayerListColumn）
 *   - players-section.js 往玩家详情页加一个「QQ 绑定」区块（registerPlayerDetailSection）
 *
 * 加载顺序说明：
 *   1) 三者彼此**没有**依赖，只共用 shared.js 里的纯函数（转义 / 请求封装 / 时间格式化）。
 *      顺序只影响同分区插件菜单项的先后；management 页是唯一注册菜单项的模块，放最后无影响。
 *   2) ESM 的 import 会被提升并顺序求值：任一模块在顶层抛错都会中断其后模块的求值，
 *      从而"静默少注册一个页面/列/区块"。所以每个模块都在顶层用 try/catch 包住注册，
 *      并在宿主没提供对应注册 API 时只 console.warn —— 保证后一个模块永远还能注册。
 *   3) 注册 API 都不存在时（宿主版本过旧）本文件不会报错，只是什么都没注册。
 */
import './players-column.js'
import './players-section.js'
import './admin.js'
