/**
 * qq-bind 前端半 —— 公共工具
 *
 * 为什么单独一个文件：三个功能模块（管理页 / 玩家列表列 / 玩家详情区块）都要转义、都要发请求。
 * 各自复制一份迟早会在某一处漏掉转义（XSS），或者出现"这个模块认得 401、那个模块不认得"的分歧。
 *
 * 本文件**顶层零副作用**：只有函数与常量定义，不注册任何东西、不碰 DOM。
 * （ESM 的 import 会被提升并顺序求值，工具模块若在顶层抛错，会让它后面所有模块静默不注册。）
 */

/** HTML 转义。所有插入 HTML 的用户数据（角色名 / QQ 号 / 错误信息 / 后端回显）都必须过这里 */
export function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  })
}

/** 内联 SVG 图标（项目硬性约定：禁止 emoji，图标只用内联 SVG 或纯文字） */
export function svg(inner, size) {
  var s = size || 14
  return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
    'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ' +
    'style="flex:0 0 auto;vertical-align:-2px">' + inner + '</svg>'
}

export var ICON = {
  list: '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3"/><path d="M12 19v3"/><path d="M2 12h3"/><path d="M19 12h3"/><path d="M4.9 4.9l2.1 2.1"/><path d="M17 17l2.1 2.1"/><path d="M19.1 4.9L17 7"/><path d="M7 17l-2.1 2.1"/>',
  scroll: '<path d="M8 3h9a2 2 0 0 1 2 2v14a1 1 0 0 0 1 1H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M5 19V7"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 3v6h-6"/>',
  plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
  trash: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M6 6l1 14h10l1-14"/>',
  key: '<path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/>',
  swap: '<path d="M7 16H3l4 4"/><path d="M3 16h13a4 4 0 0 0 0-8h-1"/><path d="M17 8h4l-4-4"/>',
  alert: '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
}

/**
 * 安全请求封装：任何异常（网络断了 / 宿主没提供 api / 返回不是对象）都归一成
 * `{ ok:false, status:0, data:null, error:'...' }`，**永不抛错**。
 *
 * 为什么不直接用 window.tsweb.api：它是 async 函数，fetch 失败会 reject。
 * 玩家列表那一列是挂在**别人页面**上的，一次未捕获的 reject 就可能让整张表渲染不出来。
 */
export async function req(path, opts) {
  var tsw = window.tsweb
  if (!tsw || typeof tsw.api !== 'function') {
    return { ok: false, status: 0, data: null, error: '宿主未提供 window.tsweb.api' }
  }
  try {
    var res = await tsw.api(path, opts)
    if (!res || typeof res !== 'object') {
      return { ok: false, status: 0, data: null, error: '请求未返回结果' }
    }
    return res
  } catch (err) {
    return {
      ok: false,
      status: 0,
      data: null,
      error: (err && err.message) ? String(err.message) : String(err),
    }
  }
}

/**
 * 给 promise 套一个**硬超时**：到点就立刻返回 { timedOut:true }，不再等原 promise。
 *
 * 为什么必须有：宿主新加的列表列扩展点（app.js:61-90）是**串行 await** 每个列的 prepare 的，
 * 只要 prepare 不 resolve，整张玩家列表的表体就永远不渲染（表头在、表体空白）。而浏览器里
 * fetch 默认**没有超时**，所以这个 race 是"绝不允许挂住"的唯一保证。
 *
 * 注意 AbortController：宿主的 window.tsweb.api（app.js:222-244）自己拼 fetch 参数，
 * **不透传 options.signal**，所以信号在宿主这一层会被丢掉。真正的兜底是这里的 race；
 * 信号只是"将来宿主透传了就顺便取消掉连接"，不能当成超时保证。
 *
 * 原 promise 之后即使 reject 也不会冒泡成 unhandledrejection —— 这里已经挂了一个拒绝处理。
 */
export function raceTimeout(promise, ms) {
  return new Promise(function (resolve, reject) {
    var settled = false
    var timer = setTimeout(function () {
      if (settled) return
      settled = true
      resolve({ timedOut: true, value: null })
    }, ms)
    Promise.resolve(promise).then(function (v) {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve({ timedOut: false, value: v })
    }, function (err) {
      if (settled) return
      settled = true
      clearTimeout(timer)
      reject(err)
    })
  })
}

/**
 * 从 { ok, status, data, error } 里取一句给人看的错误原因。
 * 顺序：服务端 error 文本 > 鉴权类状态码的中文说明 > 网络层 error > HTTP 状态码。
 * 返回**纯文本**（调用方用 textContent 写入，不要拼进 HTML）。
 */
export function errText(res, fallback) {
  if (res && res.data && res.data.error) return String(res.data.error)
  if (res && res.status === 401) return '登录状态已失效（HTTP 401），请重新登录后再试'
  if (res && res.status === 403) return '当前账号没有管理权限（HTTP 403）'
  if (res && res.status === 404) return '接口不存在（HTTP 404）：宿主里的 qq-bind 后端半可能未启用或版本过旧'
  if (res && res.error) return String(res.error)
  if (res && res.status) return 'HTTP ' + res.status
  return fallback || '未知错误'
}

function pad2(n) {
  return (n < 10 ? '0' : '') + n
}

/**
 * 时间显示：ISO 字符串（台账的 boundAt/updatedAt、审计的 t）或 unix 秒/毫秒（TShock 的 Registered）。
 * 无法解析时**原样返回**输入，不显示 "Invalid Date"，也不假装是有效时间。
 */
export function fmtTime(v) {
  if (v == null || v === '') return ''
  var d
  var s = String(v)
  if (/^\d+$/.test(s)) {
    var n = Number(s)
    if (!isFinite(n) || n <= 0) return s
    d = new Date(n < 1e12 ? n * 1000 : n) // 10 位按秒、13 位按毫秒
  } else {
    d = new Date(s)
  }
  if (isNaN(d.getTime())) return s
  return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) +
    ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds())
}

/**
 * 分钟数 → 可读时长。
 * 单位依据：online-stats 的 getAllPlaytime() 明确返回「分钟」
 * （plugins/online-stats/index.js:37 `getAllPlaytime(serverId?) → { stats: { 玩家名: 分钟 } }`），
 * qq-bind 的 service.list 把它原样塞进 row.playtime。
 */
export function fmtMinutes(min) {
  var n = Number(min)
  if (!isFinite(n) || n < 0) return ''
  if (n < 60) return n + ' 分钟'
  var h = Math.floor(n / 60)
  var m = n % 60
  return h + ' 小时' + (m ? ' ' + m + ' 分钟' : '')
}

/**
 * 从"名字 → 值"的映射里取某个名字对应的字符串值（pickQq / pickNick 共用的实现）。
 *
 * 必须用 Object.prototype.hasOwnProperty 判在不在，**不能**写 `map[name] != null`：
 * 角色名允许叫 toString / constructor / hasOwnProperty（TShock 不拦），
 * 那样读属性会命中原型链上的成员，把一个"未绑定"的角色显示成一串函数源码。
 * 后端正是为了这个原因才用自有键集合判 missing（test/lookup.test.mjs:249-272）。
 *
 * 键的口径是**传入名字原文**；这里再补一层大小写不敏感的兜底，只扫自有键，不会误命中。
 */
function pickOwn(map, name) {
  if (!map || typeof map !== 'object') return ''
  var key = String(name == null ? '' : name)
  if (!key) return ''
  var has = Object.prototype.hasOwnProperty
  if (has.call(map, key)) {
    var v = map[key]
    return v == null ? '' : String(v)
  }
  var lower = key.toLowerCase()
  for (var k in map) {
    if (!has.call(map, k)) continue
    if (String(k).toLowerCase() === lower) {
      var v2 = map[k]
      return v2 == null ? '' : String(v2)
    }
  }
  return ''
}

/**
 * 从 lookup 响应里的 qq 映射里取某个名字的 QQ 号。
 * 口径见 pickOwn（自有键判断 + 大小写不敏感兜底）。
 */
export function pickQq(map, name) {
  return pickOwn(map, name)
}

/**
 * 从 lookup 响应里的 nickname 映射里取某个名字的 QQ 昵称（无则空串）。
 *
 * 键与 qq 映射完全同口径（**传入名字原文**），所以两个 pick 用同一个实现。
 * 昵称是可能为空的缓存：后端对"没绑定"和"昵称尚未获取"的名字都不回键，
 * 调用方据此退回只显示 QQ 号，绝不用角色名冒充昵称（旧版 voteController.js:16-17 的口径）。
 */
export function pickNick(map, name) {
  return pickOwn(map, name)
}

/**
 * 同一个失败原因只 warn 一次（玩家列表列挂在别人页面上，每翻一页 warn 一次会刷屏）。
 */
var warned = {}
export function warnOnce(key, msg) {
  if (warned[key]) return
  warned[key] = true
  console.warn(msg)
}

/**
 * 复制文本到剪贴板。navigator.clipboard 在非安全上下文（http + 非 localhost）下不存在，
 * 所以必须留一条 execCommand 的老路，最后还要能如实报"复制失败，请手动选中"。
 * @returns {Promise<boolean>}
 */
export async function copyText(text) {
  var val = String(text == null ? '' : text)
  if (!val) return false
  try {
    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      await navigator.clipboard.writeText(val)
      return true
    }
  } catch (e) {
    /* 落到下面的兜底 */
  }
  try {
    var ta = document.createElement('textarea')
    ta.value = val
    ta.setAttribute('readonly', 'readonly')
    ta.style.position = 'fixed'
    ta.style.top = '-1000px'
    ta.style.opacity = '0'
    document.body.appendChild(ta)
    ta.select()
    var ok = document.execCommand('copy')
    document.body.removeChild(ta)
    return ok === true
  } catch (e2) {
    return false
  }
}

/**
 * 后端快照下发结果 → 一句人话（结果如实回显，不假装成功）。
 * 形状依据 plugins/qq-bind/index.js pushSnapshot()：{ ok, version, total, okCount, servers:[{id,name,ok,error,count,hashSent,upstreamVersion,serverHalfMissing}] }，
 * 没有启用中的服务器时是 { ok:true, total:0, servers:[], note }。
 */
export function snapshotText(sn) {
  if (!sn || typeof sn !== 'object') return ''
  var list = Array.isArray(sn.servers) ? sn.servers : []
  if (!list.length) {
    return sn.note ? '；快照未下发（' + String(sn.note) + '）' : ''
  }
  var okList = list.filter(function (s) { return s && s.ok })
  var badList = list.filter(function (s) { return !s || !s.ok })
  var text = '；快照下发 ' + okList.length + '/' + list.length + ' 台'
  if (badList.length) {
    text += '，失败：' + badList.map(function (s) {
      var who = (s && (s.name || s.id)) || '未知服务器'
      var why = (s && s.error) ? s.error : '未知原因'
      if (s && s.serverHalfMissing) why += '（该服未安装 QqBind.dll）'
      return who + '（' + why + '）'
    }).join('；')
  }
  return text
}
