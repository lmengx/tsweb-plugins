/**
 * qq-bind 前端半 —— 玩家详情页「QQ 绑定」区块
 *
 * 用宿主已有的详情区块注册表 window.tsweb.registerPlayerDetailSection
 * （plugins/web/public/app.js:40-59），players.js 在详情页渲染完成后读取它
 * （plugins/base/client/players.js:335-386）：
 *
 *   sec.render(body, doc.account, doc)
 *     - body    已建好的 <div>（外层 .panel + 标题 h3 由 players.js 负责），本区块只管往里填内容
 *     - account 就是 doc.account，**camelCase** 字段（id/username/group/registered/lastAccess/uuid/knownIPs），
 *               由游戏服半构造：plugins/base/plugin/PlayerDocument.cs:55-64 `["username"] = account.Name`
 *               （注意与玩家**列表**行的 PascalCase Username 不同，两者出自不同的 C# 端点）
 *     - doc     整个文档 { account, stats, inventory, online, source }
 *     返回函数会被当作清理函数，在详情页重建/离开时调用（用于取消在途请求）。
 *
 * 本区块**只读**：改名 / 改绑 / 解绑一律去「后端设置 → QQ 绑定」页做。
 */
import { esc, req, errText, fmtTime, pickQq } from './shared.js'

/** 详情页展示需要的字段：service.list 的 rows（见 plugins/qq-bind/index.js 的 service.list + ledger.js 的 list()） */
function findRow(rows, name) {
  if (!Array.isArray(rows) || !name) return null
  var lower = String(name).toLowerCase()
  for (var i = 0; i < rows.length; i++) {
    var r = rows[i]
    if (r && String(r.username || '').toLowerCase() === lower) return r
  }
  return null
}

/**
 * 从详情页给的两个参数里取角色名。
 * account.username 是权威字段；其余候选是"形状变了也别整块炸掉"的兜底。
 */
function accountName(account, doc) {
  var cands = [
    account && account.username,
    account && account.Username,
    doc && doc.account && doc.account.username,
    doc && doc.username,
  ]
  for (var i = 0; i < cands.length; i++) {
    var v = cands[i]
    if (v != null && String(v).trim() !== '') return String(v).trim()
  }
  return ''
}

/**
 * 取该角色的绑定情况。两条路都试，各自失败互不影响：
 *   A) GET /api/qq-bind/list?keyword=<名> —— 台账完整字段（来源 / 绑定时间 / 更新时间）
 *      keyword 是**子串**匹配 + 分页，所以要精确比对、并要一页尽量多的条数（pageSize 上限 500）
 *   B) POST /api/qq-bind/lookup —— 精确查（后端按传入名字原文回键），
 *      防止 A 因为匹配行太多被翻页截断而误判"未绑定"
 */
async function loadBinding(name) {
  var out = { anyOk: false, found: false, qq: '', row: null, errors: [] }

  var lres = await req('/api/qq-bind/list?keyword=' + encodeURIComponent(name) + '&page=1&pageSize=500')
  if (lres.ok && lres.data) {
    out.anyOk = true
    out.row = findRow(lres.data.rows, name)
  } else {
    out.errors.push('台账查询：' + errText(lres))
  }

  var qres = await req('/api/qq-bind/lookup', { method: 'POST', json: { names: [name] } })
  if (qres.ok && qres.data && qres.data.ok !== false) {
    out.anyOk = true
    out.qq = pickQq(qres.data.qq, name)
  } else {
    out.errors.push('精确查询：' + errText(qres))
  }

  if (out.row) {
    out.found = true
    if (!out.qq) out.qq = String(out.row.qq == null ? '' : out.row.qq)
  } else if (out.qq) {
    out.found = true
  }
  return out
}

/** 一行「标签 + 值」（内联样式：不依赖任何插件注入的 CSS 类） */
function kvHtml(label, valueHtml, opts) {
  var o = opts || {}
  return '<div style="display:flex;align-items:baseline;gap:10px;justify-content:space-between">' +
    '<span class="muted" style="font-size:12px;flex:0 0 auto">' + esc(label) + '</span>' +
    '<span style="font-size:13px;text-align:right;word-break:break-all' + (o.mono ? ';font-variant-numeric:tabular-nums' : '') + '">' +
    valueHtml + '</span>' +
    '</div>'
}

/** 区块内容：已绑定 / 未绑定 / 查询失败 三种结果，外加一句指向管理页的提示 */
function bodyHtml(name, res) {
  var html = '<div style="display:flex;flex-direction:column;gap:8px">'

  if (!res.anyOk) {
    // 两条路都失败：如实说"查询失败"，不要显示成"未绑定"（那会让人以为数据被清了）
    html += '<p class="error" style="margin:0">查询失败</p>'
    html += '<p class="muted" style="margin:0;font-size:12px;line-height:1.7">' +
      esc(res.errors.join('；') || '未知原因') + '</p>'
    html += '</div>' + hintHtml()
    return html
  }

  if (!res.found) {
    html += kvHtml('绑定状态', '<span class="badge">未绑定</span>')
    html += kvHtml('QQ 号', '<span class="muted">-</span>')
    html += '</div>' + hintHtml()
    return html
  }

  html += kvHtml('绑定状态', '<span class="badge ok">已绑定</span>')
  html += kvHtml('QQ 号', esc(res.qq || '-'), { mono: true })

  var row = res.row
  if (row) {
    if (row.source) html += kvHtml('绑定来源', esc(row.source))
    if (row.boundAt) html += kvHtml('绑定时间', esc(fmtTime(row.boundAt)))
    if (row.updatedAt) html += kvHtml('最近更新', esc(fmtTime(row.updatedAt)))
  } else if (res.qq) {
    // 精确查询命中了，但台账列表里没取到那一条（同名匹配过多被翻页截断等）
    html += '<p class="muted" style="margin:0;font-size:12px;line-height:1.6">' +
      '绑定详情（来源 / 时间）本次未取到，仅显示 QQ 号。</p>'
  }
  html += '</div>' + hintHtml()
  return html
}

function hintHtml() {
  return '<p class="muted" style="font-size:12px;margin:10px 0 0;line-height:1.7">' +
    '改名、改绑 QQ、解绑、批量操作请到「后端设置 → ' +
    '<a href="#/b/qq-bind">QQ 绑定</a>」页。</p>'
}

var tsw = window.tsweb

if (tsw && typeof tsw.registerPlayerDetailSection === 'function') {
  try {
    tsw.registerPlayerDetailSection({
      id: 'qq-bind',
      title: 'QQ 绑定',
      // 排在默认 order(100) 之前，落在右栏靠上位置
      order: 60,
      render: function (container, account, doc) {
        if (!container) return function () {}

        var name = accountName(account, doc)
        if (!name) {
          container.innerHTML = '<p class="muted" style="margin:0;font-size:12px">未取到角色名，无法查询绑定。</p>'
          return function () {}
        }

        container.innerHTML = '<div style="display:flex;flex-direction:column;gap:8px">' +
          kvHtml('绑定状态', '<span class="muted">查询中...</span>') + '</div>'

        // 详情页会被重建（改名、改密等操作后），此时上一次的请求可能还在路上；
        // 用 cancelled 标记丢弃过期结果，避免旧角色的数据盖掉新角色的区块。
        var cancelled = false
        loadBinding(name).then(function (res) {
          if (cancelled) return
          container.innerHTML = bodyHtml(name, res)
        }).catch(function (err) {
          // loadBinding 内部已把所有失败归一化，这里只是最后一道保险：绝不把异常抛给详情页
          if (cancelled) return
          container.innerHTML = '<p class="error" style="margin:0">查询失败：' +
            esc((err && err.message) || err) + '</p>'
        })

        return function () { cancelled = true }
      },
    })
  } catch (err) {
    console.warn('[qq-bind] 注册玩家详情「QQ 绑定」区块失败：' + ((err && err.message) || err))
  }
} else {
  console.warn('[qq-bind] 宿主未提供 window.tsweb.registerPlayerDetailSection，玩家详情区块未注册')
}
