/**
 * QQ 昵称缓存（nicknames.json）+ 昵称刷新任务编排 —— 纯逻辑，不依赖 cordis
 *
 * 移植自旧版 TsWeb/backend/services/qqNicknameService.js（语义逐条对齐，差异见下方"与旧版的差别"）。
 * 数据位置改为宿主传入的路径（本插件是 <dataDir>/qq-bind/nicknames.json）；
 * 文件结构沿用旧版：{ schema: 1, updatedAt, records: { "<QQ号>": { nickname, updatedAt, source } } }
 *
 * 为什么昵称独立存放、**绝不写进台账**（旧版 qqNicknameService.js:21-27 的三条理由，原样保留）：
 *   1. 台账的 upsert / rename 都会**重建整条记录**，塞进去的字段下一次注册/改密/改名就被抹掉，
 *      症状是"昵称莫名其妙没了"；
 *   2. 台账会原样推给各游戏服（快照下发），昵称是 QQ 侧的展示信息，
 *      没理由混进账号同步负载（徒增一份要跟着改的游戏服端解析）；
 *   3. 昵称的归属是 QQ 号（QQ:账号 = 1:1），按 QQ 建键天然对得上改绑/改名，
 *      不会出现"改绑后昵称串到别人身上"。
 *
 * 定位：**缓存**，非权威数据。绑定数量、QQ 号、绑定关系一律以 bindings.json 为准。
 * 因此读盘失败 / 文件损坏时降级为空缓存并告警，**绝不抛错**——昵称是附加展示信息，
 * 不该让 QQ 页面整页加载失败（旧版 qqNicknameService.js:64-69 同口径）。
 *
 * 分工：
 *   - ledger.js ：台账（唯一权威数据）
 *   - 本文件    ：昵称缓存 + 任务态（不认识 cordis、不认识 HTTP、不认识任何机器人框架）
 *   - index.js  ：把两者接成服务方法 / 能力 / 管理路由
 *
 * 与旧版的两点差别（都不改变对外语义，仅实现方式）：
 *   1. 旧版把缓存路径与任务态放在**模块级**（storePath() / let task），
 *      新版收进两个类（NicknameStore / NicknameTaskQueue），由插件实例持有：
 *      这样测试可以并存多个实例、插件重载后状态自然归零，也不会与别的插件共享模块级状态。
 *   2. 旧版任务过期判定直接调 Date.now()；新版把它抽成可注入的 now()（缺省仍是 Date.now），
 *      只为让"120 秒 / 300 秒惰性超时"这两条语义能被测试**真实**覆盖，
 *      不必真的等两分钟，也不必去改全局 Date.now。判定逻辑本身一字未改。
 *
 * 约定：禁止 emoji；注释用中文；引用旧版代码位置写 文件:行号。
 */
import { mkdir, readFile, rename, unlink, writeFile } from 'node:fs/promises'
import { randomUUID } from 'node:crypto'
import path from 'node:path'

import { isValidQq, normQq } from './ledger.js'

/** 缓存文件 schema 版本（与旧版一致） */
export const NICKNAME_SCHEMA = 1

/** 昵称最大长度（QQ 昵称可能很长，截断避免撑爆界面与文件） */
export const NICKNAME_MAX = 64

/** 单次上报条数上限（旧版 botController.js:744 同值；防御异常大包，正常绑定数远小于此） */
export const NICKNAME_REPORT_LIMIT = 2000

/** 任务登记后，机器人多久没来领取就算超时（毫秒） */
export const PENDING_TIMEOUT_MS = 120 * 1000

/** 机器人领取后，多久没回报结果就算超时（毫秒） */
export const RUNNING_TIMEOUT_MS = 300 * 1000

/** 超时文案（旧版 qqNicknameService.js:199、:203 原文，一字不改：机器人侧据此排查） */
export const PENDING_TIMEOUT_TEXT = '机器人未在 120 秒内响应：请确认机器人已启用「昵称刷新」并正在运行'
export const RUNNING_TIMEOUT_TEXT = '机器人已开始获取昵称，但 300 秒内未回报结果'

/** 领取时一个已绑定 QQ 都没有的说明（旧版 qqNicknameService.js:272） */
export const NO_BOUND_QQ_TEXT = '当前没有任何已绑定的 QQ 号，无需获取'

/** 任务视图里 failed 明细只回前 N 条（页面只需展示"哪些没取到"，不必搬全量） */
export const TASK_FAILED_VIEW_LIMIT = 50

/** 任务内部保存的 failed 上限（防止异常大回报把内存撑住） */
export const TASK_FAILED_KEEP_LIMIT = 200

/** 逐条失败原因截断长度（旧版 qqNicknameService.js:137） */
export const FAILED_ERROR_MAX = 200

/**
 * 清理昵称：去首尾空白、剔除控制字符与换行（防止日志 / 表格被撑坏）。
 * 顺序与旧版一致（qqNicknameService.js:45-51）：先替换控制字符 → trim → 再截断。
 */
export function cleanNickname(input) {
  let s = String(input ?? '')
  s = s.replace(/[\u0000-\u001f\u007f]/g, ' ')
  s = s.trim()
  if (s.length > NICKNAME_MAX) s = s.slice(0, NICKNAME_MAX)
  return s
}

/** 空缓存（读盘失败、文件不存在、形状非法都归到这里） */
function emptyData() {
  return { schema: NICKNAME_SCHEMA, updatedAt: null, records: {} }
}

/**
 * 昵称缓存。
 *
 * 读盘策略与旧版一致：**实时读文件，不做内存缓存**（qqNicknameService.js:32），
 * 文件规模极小，换来"外部写入立即可见"与"不会读到进程内的陈旧副本"。
 * 写盘则串行化（_mutate），避免同一进程内两次上报并发读改写互相覆盖
 * （旧版没有这一步，属实现加固，不改变任何可观测语义）。
 */
export class NicknameStore {
  /**
   * @param {object} opts
   * @param {string} opts.file nicknames.json 路径（由宿主传入，本文件不拼任何全局路径）
   */
  constructor({ file } = {}) {
    if (!file) throw new Error('NicknameStore 需要 file 路径')
    this.file = file
    /** 串行化写操作，避免并发上报互相覆盖 */
    this._writeChain = Promise.resolve()
  }

  /**
   * 读盘。**任何失败都降级为空缓存 + 警告，绝不抛错**：
   * 文件不存在是正常情形（还没获取过昵称）；JSON 损坏 / 形状非法也只降级
   * （旧版 qqNicknameService.js:57-70 同口径）。
   */
  async _read() {
    let parsed
    try {
      parsed = JSON.parse(await readFile(this.file, 'utf8'))
    } catch (err) {
      if (err && err.code === 'ENOENT') return emptyData()
      console.warn(`[qq-bind] 昵称缓存读取失败（已按空缓存处理）: ${err.message}`)
      return emptyData()
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return emptyData()
    if (!parsed.records || typeof parsed.records !== 'object' || Array.isArray(parsed.records)) {
      parsed.records = {}
    }
    return parsed
  }

  /**
   * 原子落盘（.tmp + rename），避免写到一半留下坏文件。
   *
   * 失败只记日志、**不抛错**：这是旧版既有行为（qqNicknameService.js:82-85 的 catch），
   * 上报接口据此仍回"已写入 N 条"。保持现状是为了与旧版一致；
   * 若将来要改成"保存失败即回执失败"，请连同上报能力的响应契约一起改。
   */
  async _persist(data) {
    const tmp = `${this.file}.tmp`
    data.schema = NICKNAME_SCHEMA
    data.updatedAt = new Date().toISOString()
    try {
      await mkdir(path.dirname(this.file), { recursive: true })
      await writeFile(tmp, JSON.stringify(data, null, 2), 'utf8')
      await rename(tmp, this.file)
    } catch (err) {
      console.error(`[qq-bind] 昵称缓存保存失败: ${err.message}`)
      try {
        await unlink(tmp)
      } catch {
        /* 清理失败无所谓 */
      }
    }
  }

  /** 串行执行"读 → 改 → 写"（与 ledger.js 的 _mutate 同一套约定） */
  _mutate(fn) {
    const run = () => fn()
    const next = this._writeChain.then(run, run)
    // 保持链条不因单次失败而中断
    this._writeChain = next.then(
      () => {},
      () => {},
    )
    return next
  }

  /**
   * 全部昵称映射 { QQ号: 昵称 }（只含取到昵称的条目）。
   * 旧版 qqNicknameService.js:89-97。
   */
  async getNicknameMap() {
    const data = await this._read()
    const map = {}
    for (const [qq, rec] of Object.entries(data.records)) {
      const nick = cleanNickname(rec && rec.nickname)
      if (!nick) continue
      // 用 defineProperty 而不是 map[qq] = nick：文件是外部可写的，键若恰好是 "__proto__"，
      // 直接赋值会去改原型而不是加键，这一项会"凭空消失"（本件不接受静默少数据）
      Object.defineProperty(map, String(qq), {
        value: nick,
        enumerable: true,
        writable: true,
        configurable: true,
      })
    }
    return map
  }

  /** 单个 QQ 的昵称（无则空串）。旧版 qqNicknameService.js:100-105。 */
  async getNickname(qq) {
    if (!isValidQq(qq)) return ''
    const data = await this._read()
    const rec = data.records[normQq(qq)]
    return cleanNickname(rec && rec.nickname)
  }

  /** QQ → 昵称更新时间（无则空串）。旧版 qqNicknameService.js:108-113。 */
  async getNicknameUpdatedAt(qq) {
    if (!isValidQq(qq)) return ''
    const data = await this._read()
    const rec = data.records[normQq(qq)]
    return rec && rec.updatedAt ? String(rec.updatedAt) : ''
  }

  /**
   * 批量写入昵称（机器人上报入口）。旧版 qqNicknameService.js:125-159。
   *
   * 空值与报错条目**一律不写入**——即"绝不用空值覆盖已有昵称"：
   * 某次查询失败不该把上一次取到的昵称抹掉。
   *
   * @param {Array<{qq:string, nickname?:string, error?:string}>} entries
   * @param {{source?:string}} [opts]
   * @returns {Promise<{stored:number, skipped:number, failed:Array<{qq:string,error:string}>}>}
   *   stored  实际写入条数
   *   skipped 机器人明确报错或昵称为空的条数（= failed.length，旧版同口径）
   *   failed  逐条失败原因（回给页面，让"哪些没取到"可见）
   */
  async saveNicknames(entries, opts = {}) {
    const list = Array.isArray(entries) ? entries : []
    const failed = []
    const toWrite = []

    for (const item of list) {
      const qq = normQq(item && item.qq)
      if (!isValidQq(qq)) {
        failed.push({ qq, error: 'QQ 号格式不正确' })
        continue
      }
      // 条目自带 error（机器人逐条记录的失败原因）：原样带出，截断 200 字
      if (item && item.error) {
        failed.push({ qq, error: String(item.error).slice(0, FAILED_ERROR_MAX) })
        continue
      }
      const nick = cleanNickname(item && item.nickname)
      if (!nick) {
        failed.push({ qq, error: '未取到昵称' })
        continue
      }
      toWrite.push({ qq, nickname: nick })
    }

    if (toWrite.length === 0) {
      return { stored: 0, skipped: failed.length, failed }
    }

    return this._mutate(async () => {
      const data = await this._read()
      const now = new Date().toISOString()
      for (const it of toWrite) {
        data.records[it.qq] = {
          nickname: it.nickname,
          updatedAt: now,
          source: String(opts.source || 'bot'),
        }
      }
      await this._persist(data)
      return { stored: toWrite.length, skipped: failed.length, failed }
    })
  }

  /**
   * 移除某 QQ 的昵称缓存。旧版 qqNicknameService.js:162-170。
   *
   * 注意（**旧版既有行为，刻意的，不是漏写**）：旧版定义了这个方法，
   * 但**从未被任何代码调用**——解绑 / 改绑都**不清缓存**，昵称只在"下次成功获取"时才被覆盖。
   * 这么做的理由是：昵称的归属是 QQ 号，不是绑定关系；解绑后重新绑回同一 QQ 时，
   * 旧的昵称仍然有效，没有理由让它变成"未获取"。本次移植**保持该行为**（依旧不调用本方法）。
   * 若要改成解绑即清缓存，请先确认产品口径，别把它当成 bug 顺手修掉。
   */
  async removeNickname(qq) {
    if (!isValidQq(qq)) return false
    const key = normQq(qq)
    const data = await this._read()
    if (!data.records[key]) return false
    return this._mutate(async () => {
      const cur = await this._read()
      if (!cur.records[key]) return false
      delete cur.records[key]
      await this._persist(cur)
      return true
    })
  }
}

// ═══════════════════════════════════════════════════════════
// 昵称刷新任务（页面「获取昵称」→ 机器人轮询领取 → 回报）
//
// 为什么需要任务态：宿主**没有任何到机器人的出站通道**（机器人只持 bot token 调宿主，
// 反过来不可达），所以"页面点一下主动拉取"只能做成
// 「宿主登记任务 → 机器人定时轮询领取 → 拉完回报」。
//
// 内存态、**无定时器**：进程重启任务即丢（页面再点一次即可），
// 过期一律**惰性判定**（每次读取时按时间戳判断）——避免为一次性任务常驻 timer，
// 契合本项目"定时器 / 监听器泄漏"的历史教训（旧版 qqNicknameService.js:172-182 同口径）。
// ═══════════════════════════════════════════════════════════

/**
 * 昵称刷新任务队列（同一时刻只允许一个任务）。
 * 状态机：pending --claim--> claimed --finish--> done；pending/claimed --超时--> timeout。
 */
export class NicknameTaskQueue {
  /**
   * @param {object} [opts]
   * @param {() => number} [opts.now] 时钟（缺省 Date.now；仅供测试注入，见文件头说明）
   */
  constructor({ now } = {}) {
    /** 当前任务（同一时刻只允许一个，避免连点造成多份重复拉取） */
    this._task = null
    this._now = typeof now === 'function' ? now : Date.now
  }

  /** 惰性过期：按时间戳把 pending/claimed 推进到 timeout（旧版 qqNicknameService.js:193-206） */
  _touch() {
    const t = this._task
    if (!t) return null
    const now = this._now()
    if (t.state === 'pending' && now - t.requestedAt > PENDING_TIMEOUT_MS) {
      t.state = 'timeout'
      t.completedAt = now
      t.error = PENDING_TIMEOUT_TEXT
    } else if (t.state === 'claimed' && now - t.claimedAt > RUNNING_TIMEOUT_MS) {
      t.state = 'timeout'
      t.completedAt = now
      t.error = RUNNING_TIMEOUT_TEXT
    }
    return t
  }

  /** 任务对外视图（**不含 qqs 明细**，那是给机器人领取时取的）。旧版 :209-224 */
  _view(t) {
    if (!t) return null
    return {
      id: t.id,
      state: t.state,
      requestedAt: t.requestedAt,
      requestedBy: t.requestedBy || '',
      claimedAt: t.claimedAt || null,
      completedAt: t.completedAt || null,
      total: t.total,
      stored: t.stored,
      failedCount: Array.isArray(t.failed) ? t.failed.length : 0,
      failed: Array.isArray(t.failed) ? t.failed.slice(0, TASK_FAILED_VIEW_LIMIT) : [],
      error: t.error || '',
    }
  }

  /**
   * 登记一次刷新（页面按钮）。
   * 已有**进行中**的任务（pending/claimed）则原样返回，不重复登记——连点等价于同一件事。
   * 已到终态（done/timeout）则开一个新任务。
   * @param {{actor?:string, qqs?:string[]}} p
   */
  request({ actor = '', qqs = [] } = {}) {
    const current = this._touch()
    if (current && (current.state === 'pending' || current.state === 'claimed')) {
      return this._view(current)
    }
    const unique = []
    const seen = new Set()
    for (const raw of Array.isArray(qqs) ? qqs : []) {
      const qq = normQq(raw)
      if (!isValidQq(qq) || seen.has(qq)) continue
      seen.add(qq)
      unique.push(qq)
    }
    this._task = {
      id: randomUUID(),
      state: 'pending',
      requestedAt: this._now(),
      requestedBy: String(actor || ''),
      claimedAt: null,
      completedAt: null,
      total: unique.length,
      stored: 0,
      failed: [],
      error: '',
      qqs: unique,
    }
    return this._view(this._task)
  }

  /**
   * 机器人领取任务。
   * @returns {{id:string, qqs:string[], total:number}|null} 无待领取任务时返回 null（机器人据此什么都不做）
   */
  claim() {
    const t = this._touch()
    if (!t || t.state !== 'pending') return null
    if (t.qqs.length === 0) {
      // 没有任何已绑定 QQ：直接判定完成，别让机器人做空转，也别让页面一直转圈
      t.state = 'done'
      t.completedAt = this._now()
      t.stored = 0
      t.error = NO_BOUND_QQ_TEXT
      return { id: t.id, qqs: [], total: 0 }
    }
    t.state = 'claimed'
    t.claimedAt = this._now()
    return { id: t.id, qqs: t.qqs.slice(), total: t.qqs.length }
  }

  /**
   * 机器人回报结果。
   * 只认**当前**任务的 id（id 不匹配 → 返回 null，不误改别的任务）。
   * @returns {object|null} 任务视图
   */
  finish(id, { stored = 0, failed = [] } = {}) {
    const t = this._touch()
    if (!t || t.id !== String(id)) return null
    t.state = 'done'
    t.completedAt = this._now()
    t.stored = Number(stored) || 0
    t.failed = Array.isArray(failed) ? failed.slice(0, TASK_FAILED_KEEP_LIMIT) : []
    return this._view(t)
  }

  /** 当前任务状态（管理页轮询用） */
  view() {
    return this._view(this._touch())
  }

  /** 仅供测试：清空任务态（旧版 _resetNicknameTaskForTest 的对应物） */
  reset() {
    this._task = null
  }
}
