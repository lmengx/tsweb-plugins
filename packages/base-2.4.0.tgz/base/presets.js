/**
 * 玩家属性/背包「预设」落盘（宿主侧状态数据，位置由 ctx.paths.dataOf('base') 决定）
 *
 * 为什么预设放在宿主而不是游戏服：
 *   预设就是一坨 JSON 模板（`{ exportedAt, stats, inventory }`），与服务器运行状态无关，
 *   放宿主才能"一台面板管多台服时共用同一份预设"，也不必为它给游戏服加下发协议。
 *   旧版把它放在后端（`backend/routes/presetRoutes.js`），本件延续这个位置。
 *
 * 为什么不能放插件目录：`docs/插件开发约定.md:154-161` 规定状态数据一律走 `ctx.paths.dataOf()`——
 *   插件目录在更新/卸载时会被整体替换删除，放那里的预设等于"更新一次就没了"。
 *
 * 读写语义：
 *   - 文件不存在 → 空库（不是错误）
 *   - 非法 JSON / 结构不对 → **也返回空库**，原因放进 `error`（绝不抛错，否则预设页打不开）
 *   - 落盘原子（.tmp + rename，并留 .bak）：写到一半中断不会被下次读取当成有效预设
 *   - 读改写（保存/删除）**串行化**：两处并发保存各自"读→改→写"会互相覆盖，
 *     用一个 promise 链把落盘排成队（`withLock`）
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import { copyFile, mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import path from 'node:path'

/** 预设名长度上限（够用且避免畸形 key） */
export const MAX_NAME_LEN = 64
/** 单个预设的体积上限：预设只是属性 + 背包槽位，正常几十 KB；5MB 是防御性上限 */
export const MAX_DATA_BYTES = 5 * 1024 * 1024
/** 预设条数上限：防止无限增长把列表接口拖垮 */
export const MAX_PRESETS = 200

/** 带 HTTP 状态码的错误：路由层据此回 400/404，而不是一律 500 */
export class PresetError extends Error {
  constructor(message, status = 400) {
    super(message)
    this.status = status
  }
}

/** 落盘串行化用的队列尾巴（模块级即可：预设只有这一个文件） */
let writeChain = Promise.resolve()

function withLock(fn) {
  const run = writeChain.then(fn, fn)
  // 让链条不因单次失败而断掉；真实错误仍通过 run 抛给调用方
  writeChain = run.then(() => undefined, () => undefined)
  return run
}

/** 预设库存放文件 */
export function presetsFile(dataDir) {
  return path.join(dataDir, 'presets.json')
}

/** 校验预设名；不合法抛 PresetError(400) */
export function normalizeName(name) {
  const s = String(name == null ? '' : name).trim()
  if (!s) throw new PresetError('预设名不能为空')
  if (s.length > MAX_NAME_LEN) throw new PresetError(`预设名过长（最多 ${MAX_NAME_LEN} 字）`)
  // 控制字符在 JSON 里合法但在界面上会显示成空白/换行，直接拒绝
  if (/[\u0000-\u001f\u007f]/.test(s)) throw new PresetError('预设名不能包含控制字符')
  return s
}

/** 读取整个库；**永不抛错**，返回 `{ presets, error }` */
export async function loadStore(file) {
  let raw
  try {
    raw = await readFile(file, 'utf8')
  } catch (err) {
    if (err.code === 'ENOENT') return { presets: [], error: '' }
    return { presets: [], error: `预设库读取失败（${file}）：${err.message}` }
  }
  let parsed
  try {
    parsed = JSON.parse(raw)
  } catch (err) {
    return { presets: [], error: `预设库不是合法 JSON（${file}）：${err.message}` }
  }
  const list = Array.isArray(parsed) ? parsed : parsed && parsed.presets
  if (!Array.isArray(list)) return { presets: [], error: `预设库结构不对（${file}）：缺少 presets 数组` }
  const presets = list
    .filter((one) => one && typeof one === 'object' && typeof one.name === 'string')
    .map((one) => ({ name: one.name, savedAt: one.savedAt || '', data: one.data }))
  return { presets, error: '' }
}

/** 原子落盘（先 .tmp 再 rename，并保留一份 .bak） */
async function writeStore(file, presets) {
  await mkdir(path.dirname(file), { recursive: true })
  const payload = JSON.stringify({ version: 1, presets }, null, 2)
  const tmp = `${file}.tmp`
  await writeFile(tmp, payload, 'utf8')
  try {
    await copyFile(file, `${file}.bak`)
  } catch (err) {
    if (err.code !== 'ENOENT') throw err
  }
  await rename(tmp, file)
  return file
}

/**
 * 预设列表（不含 data 本体，只给界面显示需要的摘要）。
 * 旧版列表只回 `{ presets: [...] }`（`UserDetailView.vue:1939`），这里多带 savedAt/统计信息，
 * 界面上"这个名字存了多少件装备"能直接看出来，不必点开才知道。
 */
export async function listPresets(file) {
  const { presets, error } = await loadStore(file)
  return {
    error,
    presets: presets.map((one) => ({
      name: one.name,
      savedAt: one.savedAt,
      hasStats: !!(one.data && one.data.stats),
      itemCount: one.data && Array.isArray(one.data.inventory) ? one.data.inventory.length : 0,
    })),
  }
}

/** 读取单个预设的数据本体；不存在抛 PresetError(404) */
export async function readPreset(file, name) {
  const want = normalizeName(name)
  const { presets, error } = await loadStore(file)
  const hit = presets.find((one) => one.name === want)
  if (!hit) throw new PresetError(error ? `预设库不可用：${error}` : `预设不存在：${want}`, 404)
  return hit.data
}

/** 保存（同名覆盖）；返回 `{ name, savedAt, replaced }` */
export async function savePreset(file, name, data) {
  const key = normalizeName(name)
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    throw new PresetError('预设内容必须是对象（含 stats / inventory）')
  }
  const size = Buffer.byteLength(JSON.stringify(data), 'utf8')
  if (size > MAX_DATA_BYTES) {
    throw new PresetError(`预设内容过大（${Math.round(size / 1024)}KB，上限 ${MAX_DATA_BYTES / 1024 / 1024}MB）`)
  }

  return withLock(async () => {
    const { presets } = await loadStore(file)
    const savedAt = new Date().toISOString()
    const idx = presets.findIndex((one) => one.name === key)
    const replaced = idx >= 0
    if (replaced) presets[idx] = { name: key, savedAt, data }
    else {
      if (presets.length >= MAX_PRESETS) throw new PresetError(`预设数量已达上限（${MAX_PRESETS} 条）`)
      presets.push({ name: key, savedAt, data })
    }
    await writeStore(file, presets)
    return { name: key, savedAt, replaced }
  })
}

/** 删除；返回是否删掉了（不存在返回 false，不报错——与旧版"删了不报错"一致） */
export async function deletePreset(file, name) {
  const key = normalizeName(name)
  return withLock(async () => {
    const { presets } = await loadStore(file)
    const next = presets.filter((one) => one.name !== key)
    if (next.length === presets.length) return false
    await writeStore(file, next)
    return true
  })
}
