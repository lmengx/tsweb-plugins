/** TShock may report REST failures in JSON while HTTP still returns 200. */
export function readBanResponse(result) {
  const data = result.data;
  const restStatus = Number(data?.status);
  if (!result.ok || restStatus >= 400 || data?.error || data?.ok === false || data?.success === false) {
    const error = new Error(data?.error || data?.message || data?.response || '读取封禁列表失败');
    const upstreamStatus = restStatus >= 400 && restStatus <= 599 ? restStatus
      : result.status >= 400 && result.status <= 599 ? result.status : 502;
    // HTTP 401 is reserved for the panel session, not the game server token.
    error.status = upstreamStatus === 401 ? 502 : upstreamStatus;
    throw error;
  }
  const bans = data?.bans ?? data?.Bans;
  if (!Array.isArray(bans)) {
    const error = new Error('读取封禁列表失败：上游缺少有效的 bans 数组');
    error.status = 502;
    throw error;
  }
  return bans;
}
