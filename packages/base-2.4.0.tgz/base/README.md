# Base

内置 Cordis 插件和 `Base.dll`，提供玩家、用户组管理与世界启动。世界预览（地图贴图资产、前端渲染器、建筑预览解码、游戏服地图采集 `WorldPreview.dll`）已拆分为独立插件 `world-preview`，按需安装。

> 2.4.0 起 Base 不再包含世界预览：`/api/base/world/map*`、`ui/world/`、`assets/world-v1/`、`world-map.js`、`building-preview.js`、`WorldMap.cs`/`Png.cs` 全部迁走；`history` 与 `house` 通过 `tsweb.requires` 声明依赖 `world-preview`。

## SSC 即时切换（2.2.4）

Base 的 `GET/POST /api/base/ssc` 对应游戏服 `/data/base/ssc` 和 `/data/base/ssc/save`，不依赖文件管理。保存使用文件版本校验，只修改 `sscconfig.json` 的 `Settings.Enabled`，保留其他字段。

保存成功后同时更新 TShock 配置对象与 `Main.ServerSideCharacter`，无需重启，世界选择前也能应用。有世界时在游戏线程执行；线程超时的请求不会在之后补执行。开启时在线已登录玩家载入服务器角色（不把客户端物品导入 SSC），未登录玩家需先登录，尊重 `tshock.ignore.ssc`。关闭前保存符合 TShock 保存条件的在线角色，再同步客户端世界信息。角色保存失败会阻止关闭；角色同步失败明确报错并可重试，读回不能将未完成的同步误判成功。

## 覆盖世界预览的旧实现

2.4.0 之前 Base 内含世界预览的完整实现（`ui/world/`、`assets/world-v1/`、`building-preview.js`、`world-map.js` 与 `WorldMap.cs`/`Png.cs`）。这部分已整体迁到独立插件 `world-preview`：

- 资产与渲染器地址：`/plugins/world-preview/assets/world-v1/`
- Node 服务仍叫 `worldMap`，`history` / `house` 的 `inject` 不变，但提供方换成 world-preview
- 游戏服端点改为 `/data/world-preview/map*`（`WorldPreview.dll`，按哈希自动同步）
- 市场安装 `history` / `house` 时若本机缺 `world-preview`，会先弹窗确认再下载安装依赖

## 世界启动向导（2.3.0）
控制台在游戏尚未选择世界时显示 B 版三步向导：选择世界、连接设置、确认启动。世界启动后自动切换实时日志。世界控制完全属于 Base，初始化插件只负责建立连接。

- 默认目录在请求时通过目标游戏进程的 `Main.GetWorldPathFromName(..., false)` 读取，与 TShock 原生 `n` 新建世界的目录解析一致；不提前缓存，也不使用面板账户的文档目录猜测。接口显式返回 `defaultDirectory`，即使该目录为空也默认选中它。第二个选项是目标 TShock 程序目录下的 `world`，仅在手动选择时使用。
- 世界列表与输入都在游戏端 Base.dll 内执行，支持远程面板连接 Windows 游戏服，不要求用户再次选择 PID；不会重启游戏进程。
- `GET /api/base/worlds` 代理 `/data/base/worlds`，返回游戏会话、可选目录、实际准备状态和操作进度。
- `POST /api/base/world-start` 代理游戏端同名接口。必须携带当前游戏会话及幂等请求 ID；指定目录之外的路径、控制字符、无效参数与占用端口都会在发送输入前拒绝。
- 使用原生世界菜单生成/加载世界，确认菜单阶段后才写输入；生成完成后选择刚生成的文件，继续设置端口、人数和密码。不以“发送成功”当成“游戏已就绪”。
- 新建世界的文件名按游戏同一套规则预测：`Main.GetWorldPathFromName` 会把非法文件名字符换成 `-`、空格与点换成 `_`（`我的 世界` → `我的_世界.wld`）。存在性检查与生成轮询都基于这个预测名，名称含空格或句点也能正常进入下一步，不会停在“世界生成超时”。
- 面板侧请求 ID 统一走 `client/core/ids.js` 的 `randomId()`：`crypto.randomUUID` 只在 HTTPS / localhost 存在，局域网普通 HTTP 下退化为 `crypto.getRandomValues` 生成的 v4，缺安全随机数时明确报错而不降级。启动按钮的 ID 取值位于 `try` 内，异常不会把界面锁在“正在启动世界”。
- 9 种特殊世界标志与参考页面的 36 个秘密效果共用 `world-seeds.json`，采用游戏复制种子格式 `尺寸.难度.邪恶.标志.效果|基础种子`；搜索、分类、多选、手动编辑、复制均作用于最终请求。目标游戏不支持的别名禁用并解释。
- 启动参数应用到 Terraria 菜单和 TShock 内存设置（含清空密码），不改写其他配置。菜单控制目前要求 Windows 独立游戏控制台。

验证：`node --test plugins/base/test/world-start-ui.test.mjs`；实机检查 `node scripts/verify-world-start.mjs --allow-game-processes --tshock-dir <纯净目录> --release-dir <完整发行目录> --world <测试wld> [--create-world]`。测试使用独立副本与空闲端口，结束只清理自己启动的进程。

## 从市场更新 Base（2.3.1）

Base 随发行包自带、不可卸载，但**可以从插件市场更新**：`tsweb.publish: true` 让它可以上架，`src/plugin-gates.js` 的 `UPDATABLE_BUILTIN` 放开它的更新通道（`accounts`/`servers`/`web`/`data-items`/`data-projectiles` 仍然只能随发行包升级）。更新只替换 `plugins/base/` 目录并重算 version/packageHash/dlls，登记来源保持 `builtin`，因此卸载保护不变。

更新后的生效范围：面板半刷新页面后生效；游戏服上的 `Base.dll` 由宿主按哈希自动同步（`deploy: all`，接收端对声明了 `TsWeb.BeforeWorld` 的插件允许在世界运行中热替换）；接收端 `TsWebHost.dll` 不随插件更新提升，落后时按发行包升级。市场页对 base 使用单独的确认与结果横幅（见 `plugins/market/README.md`「市场自身与核心件的更新」）。
