/**
 * 玩家角色文件（.plr）的**宿主侧目录**：旧版界面上的「后端目录」
 *
 * 旧版有三处能放 .plr：浏览器下载、后端目录、游戏服 `PlayerExports/<世界名>/`。
 * 本件保留三处，其中"后端目录"落在宿主：`<dataDir>/plr/<serverId>/`。
 *
 * 为什么**按服务器分目录**（旧版是单服，目录只有一层）：
 *   .plr 里是某个账号在**某台服务器**上的角色存档，跨服混放会让人误把 A 服的角色导进 B 服。
 *   面板的详情页本来就带 `x-server-id`，按服分开既贴合语义，也不会让用户多操作一步。
 *
 * 安全性：文件名一律取 basename 并强制 `.plr` 后缀（与 DLL 侧 `import-from-server` 的
 * 防穿越规则一致，见旧 `plugin/PlayerTransfer.cs:273-276`），写入用 .tmp + rename 原子落地。
 *
 * 约定：禁止 emoji；中文注释。
 */
import { mkdir, readFile, readdir, rename, stat, unlink, writeFile } from 'node:fs/promises'
import path from 'node:path'

/** 与 DLL 侧一致的体积上限（旧 `PlayerTransfer.cs:241`：0 或 >50MB 视为非法） */
export const MAX_PLR_BYTES = 50 * 1024 * 1024

/** 带 HTTP 状态码的错误 */
export class PlrStoreError extends Error {
  constructor(message, status = 400) {
    super(message)
    this.status = status
  }
}

/** 单台服务器的 .plr 目录 */
export function plrDir(dataDir, serverId) {
  // serverId 来自服务器注册表（UUID），这里仍然做一次净化：它会被拼进路径
  const safe = String(serverId == null ? '' : serverId).replace(/[^A-Za-z0-9_-]/g, '')
  if (!safe) throw new PlrStoreError('缺少目标服务器标识')
  return path.join(dataDir, 'plr', safe)
}

/**
 * 校验 .plr 文件名：**只取文件名本身**（目录部分一律剥掉），并要求以 .plr 结尾。
 *
 * 与 DLL 侧 `import-from-server` 的规则一致（旧 `plugin/PlayerTransfer.cs:273-276` 先区分隔符再 GetFileName）。
 * 注意语义是"净化"而不是"拒绝"：`../evil.plr` 会被存成 `evil.plr`（落在目标目录**内**），
 * 因为用户从本机选文件时拿到的就是带路径的名字，报错拒绝反而难用；
 * 真正要守住的性质是"无论传什么，文件都不可能写到目录之外"。
 * 控制字符、空名、非 .plr 后缀仍然直接拒绝。
 */
export function safePlrName(filename) {
  const raw = String(filename == null ? '' : filename).trim()
  if (!raw) throw new PlrStoreError('缺少文件名')
  // 取 basename（同时把反斜杠当分隔符，兼容从 Windows 路径里粘过来的值）。
  // 注意：这一步之后结果里**不可能**再含 '/' 或 '\'——先把 '\' 归一成 '/'，再取 basename，
  // 无论宿主跑在 Windows 还是 Linux 都只剩最后一段，所以不需要再判一次分隔符。
  let base = path.basename(raw.replace(/\\/g, '/'))
  // Windows 保留字符统一换成 '_'（旧版宿主就是这么做的：旧 backend/controllers/playerTransferController.js:20-22）。
  // 不换会出两个真问题：`a:b.plr` 在 NTFS 上是"备用数据流"（写进文件流而不是普通文件），
  // 而 `a<b.plr`、`a?b.plr` 之类直接 EINVAL 写失败；`/` `\` 已由上面的 basename 去掉。
  // 平台差异：Windows 的 path.basename 会把"字母 + 冒号"当盘符前缀切掉（`a:b.plr` → `b.plr`），
  // Linux 不会（→ `a_b.plr`）；两条路径都不会留下冒号，安全性质一致。
  // （DLL 侧的 FormatFileName 用的是 '-'，那边处理的是账号名/世界名，两者各自沿用旧版口径。）
  base = base.replace(/[:*?"<>|]/g, '_')
  if (/[\u0000-\u001f\u007f]/.test(base)) throw new PlrStoreError('文件名不能包含控制字符')
  if (!/\.plr$/i.test(base)) throw new PlrStoreError('只接受 .plr 文件')
  if (base.length > 128) throw new PlrStoreError('文件名过长')
  return base
}

/** 严格校验 Base64（DLL 侧用 Convert.FromBase64String，非法会直接抛错，这里提前挡掉） */
export function decodePlrBase64(base64) {
  const s = String(base64 == null ? '' : base64).replace(/\s+/g, '')
  if (!s) throw new PlrStoreError('缺少 plrBase64 内容')
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(s) || s.length % 4 !== 0) {
    throw new PlrStoreError('plrBase64 不是有效的 Base64')
  }
  const buf = Buffer.from(s, 'base64')
  if (buf.length === 0) throw new PlrStoreError('plr 文件内容为空')
  if (buf.length > MAX_PLR_BYTES) {
    throw new PlrStoreError(`plr 文件超过 ${MAX_PLR_BYTES / 1024 / 1024}MB`)
  }
  return buf
}

/** 列出目录里的 .plr（按修改时间倒序，与旧版 export-list 一致） */
export async function listPlr(dir) {
  let names
  try {
    names = await readdir(dir)
  } catch (err) {
    if (err.code === 'ENOENT') return []
    throw new PlrStoreError(`目录读取失败：${err.message}`, 500)
  }
  const out = []
  for (const name of names) {
    if (!/\.plr$/i.test(name)) continue
    try {
      const st = await stat(path.join(dir, name))
      if (!st.isFile()) continue
      out.push({ filename: name, size: st.size, lastModified: fmtTime(st.mtime) })
    } catch {
      // 单个文件读不到（权限/并发删除）不该让整个列表失败
    }
  }
  out.sort((a, b) => String(b.lastModified).localeCompare(String(a.lastModified)))
  return out
}

/** `yyyy-MM-dd HH:mm:ss`（本地时区），与旧版 export-list 的格式一致 */
function fmtTime(d) {
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} `
    + `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
}

/** 保存一份 .plr（同名覆盖），返回 `{ filename, size }` */
export async function savePlr(dir, filename, base64) {
  const name = safePlrName(filename)
  const buf = decodePlrBase64(base64)
  await mkdir(dir, { recursive: true })
  const dst = path.join(dir, name)
  const tmp = `${dst}.tmp`
  await writeFile(tmp, buf)
  await rename(tmp, dst)
  return { filename: name, size: buf.length }
}

/** 读取一份 .plr（供"从后端目录导入"用），返回 `{ filename, size, base64 }` */
export async function readPlr(dir, filename) {
  const name = safePlrName(filename)
  const full = path.join(dir, name)
  let buf
  try {
    buf = await readFile(full)
  } catch (err) {
    if (err.code === 'ENOENT') throw new PlrStoreError(`文件不存在：${name}`, 404)
    throw new PlrStoreError(`文件读取失败：${err.message}`, 500)
  }
  return { filename: name, size: buf.length, base64: buf.toString('base64') }
}

/** 删除；不存在返回 false（界面上"删一个已经不存在的文件"不该报错） */
export async function deletePlr(dir, filename) {
  const name = safePlrName(filename)
  try {
    await unlink(path.join(dir, name))
    return true
  } catch (err) {
    if (err.code === 'ENOENT') return false
    throw new PlrStoreError(`文件删除失败：${err.message}`, 500)
  }
}
