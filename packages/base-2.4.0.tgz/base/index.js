import accessContract from './access.js?v=2.1.0'
/**
 * 基础功能插件（cordis）—— 后端代理层
 *
 * 职责：
 *   - 玩家管理：把前端 /api/base/players/* 代理到目标服务器 TShock REST /data/base/players/*
 *     （由同包 Base.dll 提供，经 TsWebHost 下发热加载）
 *   - 组管理：把前端 /api/base/groups/* 代理到 /data/base/groups/*（同样由 Base.dll 提供）。
 *     不直接用 TShock 原生 /v2/groups/*：原生没有「单条权限增删」，且完全不暴露 prefix/suffix，
 *     详见 plugins/base/plugin/Groups.cs 头部说明。
 *   - PATCH 语义：JSON Patch（RFC 6902）ops 数组经 query 透传，自由编辑任意字段
 *   - 玩家角色文件（.plr）导入导出：导出/批量导出/服务端列表/导入转 Base.dll；
 *     「后端目录」（宿主侧暂存）与「预设」由本插件自己落盘，见 plrStore.js / presets.js
 *   - 全部路由 admin 鉴权（verifyAuth + requireAdmin），复用 ctx.tshock.fetchFor 多服代理
 *   - 控制台界面见 client/console.js（日志流走 servers 插件的 /api/events SSE，本插件不重复建通道）
 *
 * 依赖：webServer / auth / servers / tshock / paths
 */
import { readFileSync } from 'node:fs'
import fs from 'node:fs/promises'
import path from 'node:path'




import { lookupIp } from './ipLookup.js'
import { readBanResponse } from './ban-response.js'
import { deletePlr, listPlr, plrDir, readPlr, savePlr } from './plrStore.js'
import { deletePreset, listPresets, presetsFile, readPreset, savePreset } from './presets.js'

export const name = 'base'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths']

/** 包内版本号：随包发布的 package.json 为准，便于日志/排障确认实际运行的版本 */
const PKG_VERSION = JSON.parse(
  readFileSync(new URL('./package.json', import.meta.url), 'utf8')
).version
// ── TShock 封禁时间字段换算（/v3/bans/list 的 start_date_ticks / end_date_ticks）──
// .NET Ticks = 100ns 粒度、自 0001-01-01 起算。
const TICKS_TO_MS = 1 / 10000
const TICKS_EPOCH_OFFSET_MS = 62135596800000 // 0001-01-01 → 1970-01-01
const MAX_VALUE_TICKS = 3155378975999999999 // DateTime.MaxValue.Ticks

/** Ticks → Unix 毫秒；缺失/非法返回 null */
function ticksToMs(t) {
  const n = Number(t)
  if (!Number.isFinite(n) || n <= 0) return null
  return Math.round(n * TICKS_TO_MS - TICKS_EPOCH_OFFSET_MS)
}

/**
 * 该到期 Ticks 是否表示"永久"。
 *
 * TShock 的永久封禁用 DateTime.MaxValue 表示（TShockAPI/DB/BanManager.cs:134，
 * 判断处 :204/:714），而它不是"空值"：换算成毫秒是公元 9999 年。
 * 所以只判断 endMs == null 会把永久封禁显示成 9999 年的到期时间。
 * JS 双精度在 3.15e18 量级的分辨率约 512，故留 1e4（≈1ms）容差。
 */
function isPermanentTicks(t) {
  const n = Number(t)
  return Number.isFinite(n) && n >= MAX_VALUE_TICKS - 10000
}

export function apply(ctx) {
  // 世界预览（地图资产 / worldMap 服务 / 游戏服 WorldMap.dll）已迁到独立插件 world-preview。
  const app = ctx.auth.access.policyApp(ctx.webServer.app, accessContract, ctx)
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireServerManager()]
  const backend = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]

  // Base.dll reads the target game's actual WorldPath and owns pre-world input.
  app.get('/api/base/worlds', ...admin, async (req, res) => {
    try {
      if (!req.headers['x-server-id'] && !req.query.serverId) return res.status(400).json({ error: '请先选择目标服务器' })
      await proxy(res, await resolveServer(req), '/data/base/worlds')
    } catch (err) { res.status(err.status || 502).json({ error: err.message }) }
  })
  app.post('/api/base/world-start', ...admin, async (req, res) => {
    try {
      if (!req.headers['x-server-id'] && !req.query.serverId) return res.status(400).json({ error: '请先选择目标服务器' })
      const server = await resolveServer(req)
      const result = await ctx.tshock.postFor(server, '/data/base/world-start', { payload: JSON.stringify(req.body || {}) })
      res.status(result.status || (result.ok ? 200 : 500)).json(result.data || { error: '游戏服未返回启动状态' })
    } catch (err) { res.status(err.status || 502).json({ error: err.message }) }
  })
  /** 解析目标服务器：优先 x-server-id 头，其次 query serverId，缺省取第一台 */
  /**
   * 决定本次请求作用于哪台服务器（返回**含 token 的原始记录**，代理要用它拼 REST 地址）。
   *
   * 注意两个坑（原来都踩了，表现为一句莫名的 "Cannot read properties of undefined (reading 'host')"）：
   *   1) ctx.servers.list() 是 async 的，必须 await；漏掉 await 拿到的是 Promise，
   *      Promise.length 是 undefined（所以 length === 0 判断不成立），Promise[0] 更是 undefined。
   *   2) list() 返回的是 sanitize 过的记录（不含 token），不能直接拿去代理；
   *      必须再用 getRaw(id) 换回原始记录。
   * 调用方必须 await：所有路由处理器都是 async。
   */
  async function resolveServer(req) {
    const id = req.headers['x-server-id'] || (req.query && req.query.serverId)
    if (id) {
      const raw = ctx.servers.getRaw(String(id))
      if (raw) return raw
      const err = new Error('目标服务器不存在')
      err.status = 404
      throw err
    }
    // 未指定服务器：退化为列表第一台（与旧的 players 插件行为一致）
    const list = await ctx.servers.list()
    if (!list || list.length === 0) {
      const err = new Error('尚未配置任何服务器')
      err.status = 400
      throw err
    }
    const raw = ctx.servers.getRaw(list[0].id)
    if (!raw) {
      const err = new Error('尚未配置任何服务器')
      err.status = 400
      throw err
    }
    return raw
  }

  /** 统一代理：转发到 TShock REST，透传其状态码与 JSON 数据 */
  async function proxy(res, server, pathname, params) {
    try {
      const result = await ctx.tshock.fetchFor(server, pathname, params)
      res.status(result.status || (result.ok ? 200 : 500)).json(result.data || { error: '空响应' })
    } catch (err) {
      res.status(err.status || (err.type === 'timeout' ? 504 : 502)).json({ error: err.message })
    }
  }

  /**
   * 组写操作专用代理：自带查询串，保留空字符串值。
   *
   * 为什么不能直接用上面的 proxy：ctx.tshock.fetchFor 会跳过值为 '' 的参数，
   * 而组管理中「把父组改成根组（parent 置空）」「清空前缀/后缀/颜色」恰恰要传空值，
   * 传不过去就会变成「沿用旧值」，用户改不回去。
   * fetchFor 内部用 new URL(pathname, base)，因此预先拼好的查询串会被保留。
   * 约定：值为 undefined/null 的参数表示「不修改」（DLL 侧沿用当前值）；空串表示「清空」。
   */
  async function proxyKeepEmpty(res, server, pathname, params) {
    const search = new URLSearchParams()
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null) search.set(k, String(v))
    }
    const qs = search.toString()
    try {
      const result = await ctx.tshock.fetchFor(server, qs ? `${pathname}?${qs}` : pathname)
      res.status(result.status || (result.ok ? 200 : 500)).json(result.data || { error: '空响应' })
    } catch (err) {
      res.status(err.status || (err.type === 'timeout' ? 504 : 502)).json({ error: err.message })
    }
  }

  // SSC has a dedicated Base API, independent of file-manager and local filesystem access.
  app.get('/api/base/ssc', ...admin, async (req, res) => {
    try { await proxy(res, await resolveServer(req), '/data/base/ssc') }
    catch (err) { res.status(err.status || 400).json({ error: err.message }) }
  })
  app.post('/api/base/ssc', ...admin, async (req, res) => {
    if (typeof req.body?.enabled !== 'boolean' || typeof req.body?.version !== 'string' || !/^[a-f0-9]{64}$/.test(req.body.version))
      return res.status(400).json({ error: '需要布尔 enabled 和读取配置时返回的 version' })
    try {
      await proxy(res, await resolveServer(req), '/data/base/ssc/save', { enabled: String(req.body.enabled), version: req.body.version })
    } catch (err) { res.status(err.status || 400).json({ error: err.message }) }
  })

  // 玩家账号列表 / 搜索 / 筛选 / 分页
  app.get('/api/base/players/list', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/base/players/list', {
        page: q.page, pageSize: q.pageSize,
        keyword: q.keyword, username: q.username,
        onlineOnly: q.onlineOnly, hasCharacter: q.hasCharacter,
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // ★ 玩家详情（完整文档：account + stats + inventory）必须注册在**所有**
  //   `/api/base/players/<具体动作>` 路由之后 —— 见本段末尾的说明。

  // JSON Patch 自由编辑（body: { ops: [...] }，转 query ops 透传）
  app.patch('/api/base/players/:username', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const ops = (req.body && req.body.ops) || []
      await proxy(res, server, '/data/base/players/patch', {
        player: req.params.username,
        ops: JSON.stringify(ops),
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 单账号重复 IP 检测
  app.get('/api/base/players/duplicateips', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      await proxy(res, server, '/data/base/players/duplicateips', { username: (req.query || {}).username })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 全量重复 IP 聚类
  app.get('/api/base/players/allduplicateips', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      await proxy(res, server, '/data/base/players/allduplicateips', {})
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // ── 玩家封禁状态（读 TShock 原生 /v3/bans/list，按该玩家的 acc/uuid/ip 三重标识筛选）──
  //
  // 为什么需要它：面板里原先**没有任何**读封禁列表的接口（Base.dll 只写封禁、不读列表），
  // 所以玩家详情页无法显示「已封禁 + 原因/时间/操作者」。
  //
  // 为什么要在这里筛：/v3/bans/list 返回**全服**封禁列表，条目形如
  //   { identifier, reason, banning_user, start_date_ticks, end_date_ticks, ticket_number }
  // identifier 前缀语义（TShockAPI/DB/BanManager.cs:627/631/639）：
  //   'acc:<账号名>' / 'uuid:<uuid>' / 'ip:<ip>'，正是本面板封禁时写入的三种
  //   （plugins/base/plugin/AdminActions.cs:93-99）。
  // 这里按 账号名 / uuid / 该玩家的已知 IP 三类全部匹配，任一条未过期即视为已封禁。
  //
  // 需要 token 所在组有 rest.viewbans 权限；没有权限时 TShock 会回 4xx，
  // 这里如实透传错误（前端把它当成"封禁状态未知"，不显示封禁徽标）。
  app.get('/api/base/players/bans', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      const username = String(q.player || '').trim()
      const uuid = String(q.uuid || '').trim()
      // knownIPs 由前端传（逗号分隔）；后端只做拆分，不去查库
      const ips = String(q.knownIPs || '').split(/[,，;；\t\n\s]+/).map((s) => s.trim()).filter(Boolean)

      const result = await ctx.tshock.fetchFor(server, '/v3/bans/list')
      const all = readBanResponse(result)
      const want = new Set()
      if (username) want.add('acc:' + username)
      if (uuid) want.add('uuid:' + uuid)
      for (const ip of ips) want.add('ip:' + ip)

      // .NET Ticks（100ns，自 0001-01-01）→ 毫秒；永久封禁用 DateTime.MaxValue.Ticks
      const now = Date.now()
      const hits = []
      for (const b of all) {
        const ident = String((b && (b.identifier || b.Identifier)) || '')
        if (!want.has(ident)) continue
        const startMs = ticksToMs(b.start_date_ticks != null ? b.start_date_ticks : b.StartDateTicks)
        const endTicks = b.end_date_ticks != null ? b.end_date_ticks : b.EndDateTicks
        const endMsRaw = ticksToMs(endTicks)
        // 永久封禁有两个来源：DateTime.MaxValue.Ticks（正常写入的永久封禁），
        // 以及字段缺失/非法（endMsRaw 为 null）。两种情况都不能当成"已过期"。
        const permanent = isPermanentTicks(endTicks) || endMsRaw == null
        const endMs = permanent ? null : endMsRaw
        const expired = !permanent && endMs <= now
        hits.push({
          identifier: ident,
          reason: (b && (b.reason || b.Reason)) || '',
          operator: (b && (b.banning_user || b.BanningUser)) || '',
          startMs,
          endMs,
          permanent,
          expired,
          ticket: b && (b.ticket_number != null ? b.ticket_number : b.TicketNumber),
        })
      }
      const active = hits.filter((h) => !h.expired)
      res.json({
        ok: true,
        banned: active.length > 0,
        bans: hits,
        activeBans: active,
        // 让排查更省事：告诉调用方这次是拿哪些标识去匹配的
        matchedIdentifiers: Array.from(want),
      })
    } catch (err) {
      res.status(err.status || (err.type === 'timeout' ? 504 : 502)).json({ error: err.message })
    }
  })

  // ── 全量封禁列表（总览「封禁记录」卡 + 封禁列表弹窗）──
  //
  // 与上面 /players/bans 的分工：那条按某个玩家的 acc/uuid/ip 三重标识筛过，只回答
  // "这个人被封了吗"；这条不过滤，回答"全服共有多少条封禁、最近几条是谁"，
  // 供总览卡片与「封禁列表」弹窗（逐条解封）使用。
  //
  // 这里同时修掉旧版的两个问题（旧版 = TsWeb/frontend/src/views/console/OnlineStatsView.vue
  // + BanListView.vue，表现为"主页那张封禁小卡一直不显示内容"）：
  //   1. 旧版前端把失败静默吞掉（OnlineStatsView.vue:76-109 用 Promise.allSettled 且空 catch、
  //      不检查响应状态），token 缺 rest.viewbans 权限时卡片恒为「暂无封禁记录」，看不出原因；
  //      本端点失败时如实回状态码 + error，由前端显示可操作提示。
  //   2. 旧版"最近 3 条"取 TShock 字典序的前 3 条（OnlineStatsView.vue:107 直接 slice），
  //      并不是时间上最近的；这里按封禁开始时间倒序返回，前端取前 3 条即真正的最近 3 条。
  app.get('/api/base/bans/list', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const result = await ctx.tshock.fetchFor(server, '/v3/bans/list')
      const all = readBanResponse(result)
      const now = Date.now()
      const bans = all.map((b) => {
        const startMs = ticksToMs(b.start_date_ticks != null ? b.start_date_ticks : b.StartDateTicks)
        const endTicks = b.end_date_ticks != null ? b.end_date_ticks : b.EndDateTicks
        const endMsRaw = ticksToMs(endTicks)
        const permanent = isPermanentTicks(endTicks) || endMsRaw == null
        const endMs = permanent ? null : endMsRaw
        return {
          identifier: String((b && (b.identifier || b.Identifier)) || ''),
          reason: (b && (b.reason || b.Reason)) || '',
          operator: (b && (b.banning_user || b.BanningUser)) || '',
          startMs,
          endMs,
          permanent,
          expired: !permanent && endMs <= now,
          ticket: b && (b.ticket_number != null ? b.ticket_number : b.TicketNumber),
        }
      })
      // 开始时间倒序（缺失的排最后）：卡片直接取前 3 条 = 最近 3 条
      bans.sort((a, b) => (b.startMs || 0) - (a.startMs || 0))
      res.json({
        ok: true,
        total: bans.length,
        activeCount: bans.filter((x) => !x.expired).length,
        nowMs: now,
        bans,
      })
    } catch (err) {
      res.status(err.status || (err.type === 'timeout' ? 504 : 502)).json({ error: err.message })
    }
  })

  // ── P0 管理操作（转 Base.dll 的 AdminActions 端点，不走 rawcmd）──

  // 踢出在线玩家
  app.get('/api/base/players/kick', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/base/players/kick', { player: q.player, reason: q.reason })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 封禁（acc+uuid+ip 三重 + 踢在线）
  app.get('/api/base/players/ban', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/base/players/ban', { player: q.player, reason: q.reason })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 解封
  app.get('/api/base/players/unban', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/base/players/unban', {
        ticket: q.ticket, fullDelete: q.fullDelete,
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 清角色（删 SSC + 在线重建初始）
  app.get('/api/base/players/clearcharacter', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/base/players/clearcharacter', { player: q.player })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 改密码
  app.get('/api/base/players/password', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/base/players/password', {
        player: q.player, password: q.password,
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 改组
  app.get('/api/base/players/group', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/base/players/group', { player: q.player, group: q.group })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 全部用户组名（用户组切换下拉）
  app.get('/api/base/players/groups', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      await proxy(res, server, '/data/base/players/groups', {})
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 互动操作命令（私聊/传送/给物品）：转 TShock /v3/server/rawcmd
  app.post('/api/base/players/command', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const cmd = (req.body || {}).cmd
      if (!cmd || !String(cmd).trim()) return res.status(400).json({ error: '命令不能为空' })
      const result = await ctx.tshock.fetchFor(server, '/v3/server/rawcmd', { cmd: String(cmd) })
      if (result.ok) return res.json(result.data)
      res.status(result.status || 502).json({ error: `TShock REST 返回 ${result.status}`, detail: result.data })
    } catch (err) {
      res.status(err.status || 502).json({ error: err.message, type: err.type || 'network' })
    }
  })

  // 改名
  app.get('/api/base/players/rename', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/base/players/rename', { player: q.player, newName: q.newName })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // UUID 管理（uuid 空 = 清除）
  app.get('/api/base/players/uuid', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/base/players/uuid', { player: q.player, uuid: q.uuid || '' })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 删除账号
  app.get('/api/base/players/delete', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/base/players/delete', { player: q.player, deleteCharacter: q.deleteCharacter })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // ═══════════ 玩家角色文件（.plr）导入导出 ═══════════
  //
  // 移植自旧版 `TsWeb/plugin/PlayerTransfer.cs`（旧版界面在玩家详情页的「PLR 存档」弹窗，
  // 另有列表页的「批量导出 PLR」按钮）。
  //
  // ★ 这一组全是 GET 的 `/players/<具体动作>`，**必须排在下文 `:username` 详情路由之前** ——
  //   理由与下面那段长注释完全相同（Express 5 的 `:username` 会吃掉任意单段路径）。
  // 导入用 POST + form：一份 .plr 常有几十 KB ~ 几 MB，base64 塞进 query 会撞 URL 长度上限，
  //   故走 `ctx.tshock.postFor`（TShock 的 REST 把 form body 并入 Request.Parameters，
  //   见 plugins/servers/index.js:213-238 的实测说明）。

  /** 玩家名：本组统一用 player，同时兼容旧前端的 username */
  function ioPlayer(src) {
    return (src && (src.player || src.username)) || ''
  }

  /** 写操作代理：POST + form，状态码与错误语义与 proxy 完全一致 */
  async function proxyPost(res, server, pathname, body) {
    try {
      const result = await ctx.tshock.postFor(server, pathname, body)
      res.status(result.status || (result.ok ? 200 : 500)).json(result.data || { error: '空响应' })
    } catch (err) {
      res.status(err.status || (err.type === 'timeout' ? 504 : 502)).json({ error: err.message })
    }
  }

  // 导出角色：to=download 回 base64（供浏览器下载或转存后端目录）；to=server 存到游戏服 PlayerExports/<世界名>/
  app.get('/api/base/players/export', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/base/players/export', {
        player: ioPlayer(q), to: q.to || 'download',
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 批量导出：所有有角色数据的账号 → 游戏服 PlayerExports/<世界名>/
  app.get('/api/base/players/export-all', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      await proxy(res, server, '/data/base/players/export-all', {})
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 游戏服 PlayerExports/<世界名>/ 下已有的 .plr 列表（导入时选文件用）
  app.get('/api/base/players/export-list', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      await proxy(res, server, '/data/base/players/export-list', {})
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 导入角色（浏览器上传的 .plr，base64 走 form body）
  app.post('/api/base/players/import', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const b = req.body || {}
      const player = ioPlayer(b) || ioPlayer(req.query)
      if (!player) return res.status(400).json({ error: '参数 player 为必填' })
      await proxyPost(res, server, '/data/base/players/import', { player, plrBase64: b.plrBase64 })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 从游戏服 PlayerExports 里已有的 .plr 导入（path 只接受文件名，DLL 侧防穿越）
  app.get('/api/base/players/import-from-server', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const q = req.query || {}
      await proxy(res, server, '/data/base/players/import-from-server', {
        player: ioPlayer(q), path: q.path,
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 是否有角色数据（批量导出前的筛选、以及"这个账号能不能导出"的即时反馈）
  app.get('/api/base/players/has-character', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      await proxy(res, server, '/data/base/players/has-character', { player: ioPlayer(req.query) })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // ═══════════ 后端目录（宿主侧 .plr 暂存）═══════════
  //
  // 旧版界面上的「保存到后端目录 / 从后端目录导入」：文件放在**宿主**而不是游戏服，
  // 好处是"换服/换世界也不用担心导出目录跟着变"，也不占用游戏服的磁盘。
  // 按目标服务器分目录（`<dataDir>/plr/<serverId>/`）：.plr 是"某账号在某服"的存档，
  // 跨服混放很容易把 A 服的角色导进 B 服；面板本来就带 x-server-id，分目录对用户是透明的。
  const baseDataDir = ctx.paths.dataOf('base')

  async function plrDirFor(req) {
    const server = await resolveServer(req)
    return plrDir(baseDataDir, server.id)
  }

  // 后端目录列表
  app.get('/api/base/plr/list', ...backend, async (req, res) => {
    try {
      res.json({ success: true, files: await listPlr(await plrDirFor(req)) })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 存一份到后端目录（body: { filename, base64 }）
  app.post('/api/base/plr/save', ...backend, async (req, res) => {
    try {
      const b = req.body || {}
      const saved = await savePlr(await plrDirFor(req), b.filename, b.base64)
      res.json({ success: true, ...saved })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 读后端目录里的一份（供"从后端目录导入"取内容后转给游戏服）
  app.get('/api/base/plr/file', ...backend, async (req, res) => {
    try {
      const file = await readPlr(await plrDirFor(req), (req.query || {}).filename)
      res.json({ success: true, ...file })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 删除后端目录里的一份
  app.post('/api/base/plr/delete', ...backend, async (req, res) => {
    try {
      const deleted = await deletePlr(await plrDirFor(req), (req.body || {}).filename)
      res.json({ success: true, deleted })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // ═══════════ 玩家属性/背包预设（宿主侧 JSON 模板）═══════════
  //
  // 与旧版同名能力（旧 `backend/routes/presetRoutes.js` → `/api/presets/*`）。
  // 预设是"属性 + 背包"的 JSON 模板，与游戏服运行状态无关，因此**不按服务器分**：
  // 一台面板管多台服时共用一份预设（存档导出/导入按服走 PLR 那条链路）。
  const presetFile = presetsFile(baseDataDir)

  app.get('/api/base/presets/list', ...backend, async (_req, res) => {
    const { presets, error } = await listPresets(presetFile)
    res.json({ success: true, presets, error })
  })

  app.post('/api/base/presets/save', ...backend, async (req, res) => {
    try {
      const b = req.body || {}
      const saved = await savePreset(presetFile, b.name, b.data)
      res.json({ success: true, ...saved })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  app.get('/api/base/presets/read', ...backend, async (req, res) => {
    try {
      const data = await readPreset(presetFile, (req.query || {}).name)
      res.json({ success: true, data })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  app.post('/api/base/presets/delete', ...backend, async (req, res) => {
    try {
      const deleted = await deletePreset(presetFile, (req.body || {}).name)
      res.json({ success: true, deleted })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // ═══════════ IP 归属地查询（详情页「已知 IP」用）═══════════
  //
  // 浏览器不能直连归属地服务（CORS + 对方返回 GBK，前端按 UTF-8 解会乱码），
  // 故由宿主代理，理由与实现见 ipLookup.js 头部注释。旧版在 backend/server.js:241-258。
  // 查不到不是错误：接口回 200 + `err` 字段，前端据此显示"查询失败"，不让详情页渲染中断。
  app.get('/api/base/ip-lookup', ...admin, async (req, res) => {
    const ip = (req.query || {}).ip
    if (!ip) return res.status(400).json({ error: '缺少 ip 参数' })
    res.json(await lookupIp(ip))
  })

  // ── 玩家详情（完整文档：account + stats + inventory）──
  //
  // ★ 必须放在**所有** `/api/base/players/<具体动作>` 的 GET 路由之后，不能放在前面。
  //   Express 5 的 `:username` 会匹配任意单段路径，所以只要它还排在前面，
  //   `/api/base/players/kick`、`/ban`、`/allduplicateips` 等**全部**会被它抢先接走，
  //   以 username='kick' 之类的值落进详情处理器，再转发成
  //   `/data/base/players/detail?player=kick` → DLL 找不到该账号 → 404「找不到玩家」。
  //   实测后果：踢出/封禁/解封/改密码/改用户组/改名/改 UUID/删号/清角色/重复 IP 检测
  //   这 12 个 P0 动作在发布版里全部失效，且报错文案一律是「找不到玩家」。
  //   （PATCH 的 `:username` 不受影响：动作路由里没有 PATCH，`/command` 是 POST。）
  app.get('/api/base/players/:username', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      await proxy(res, server, '/data/base/players/detail', { player: req.params.username })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // ── 组管理（代理到 Base.dll 的 /data/base/groups/*）──
  // 读取用 GET，写操作用 POST + JSON body；DLL 侧是 TShock REST 风格的 GET + query，
  // 故此处负责 body → query 的翻译，前端只管发 JSON。
  // 这些端点没有用 TShock 原生 /v2/groups/*，原因见 plugins/base/plugin/Groups.cs 头部说明。

  /** 组字段统一取值：只把前端确实提供的键放进参数表（undefined = 不修改） */
  function groupFields(body) {
    const b = body || {}
    const out = {}
    for (const k of ['groupName', 'parent', 'commands', 'chatColor', 'prefix', 'suffix', 'permission']) {
      if (Object.prototype.hasOwnProperty.call(b, k)) out[k] = b[k] === null ? '' : b[k]
    }
    return out
  }

  // 组列表（含 prefix/suffix 与原始权限串，TShock 原生 /v2/groups/list 只返回 3 个字段）
  app.get('/api/base/groups/list', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      await proxy(res, server, '/data/base/groups/list', {})
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 组详情
  app.get('/api/base/groups/read', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      await proxy(res, server, '/data/base/groups/get', { groupName: (req.query || {}).groupName })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 创建组
  app.post('/api/base/groups/create', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const f = groupFields(req.body)
      await proxyKeepEmpty(res, server, '/data/base/groups/create', {
        groupName: f.groupName,
        parent: f.parent,
        commands: f.commands,
        chatColor: f.chatColor,
        prefix: f.prefix,
        suffix: f.suffix,
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 更新组（不传 commands：权限一律走 permission/add|remove，避免整表覆盖丢权限）
  app.post('/api/base/groups/update', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const f = groupFields(req.body)
      await proxyKeepEmpty(res, server, '/data/base/groups/update', {
        groupName: f.groupName,
        parent: f.parent,
        chatColor: f.chatColor,
        prefix: f.prefix,
        suffix: f.suffix,
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 删除组
  app.post('/api/base/groups/delete', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const f = groupFields(req.body)
      await proxy(res, server, '/data/base/groups/delete', { groupName: f.groupName })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 单条加权限（原生 REST 无此能力，必须经 DLL 封装 TShock.Groups.AddPermissions）
  app.post('/api/base/groups/permission/add', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const f = groupFields(req.body)
      await proxy(res, server, '/data/base/groups/permission/add', {
        groupName: f.groupName, permission: f.permission,
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 单条删权限
  app.post('/api/base/groups/permission/remove', ...admin, async (req, res) => {
    try {
      const server = await resolveServer(req)
      const f = groupFields(req.body)
      await proxy(res, server, '/data/base/groups/permission/remove', {
        groupName: f.groupName, permission: f.permission,
      })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  console.log(`[base] 基础功能后端 v${PKG_VERSION} 已挂载（玩家 /api/base/players/*、组 /api/base/groups/*、`
    + `角色文件 /api/base/plr/*、预设 /api/base/presets/*、IP 归属地 /api/base/ip-lookup）`)
}
