// World startup is owned by Base; setup only establishes the connection.
export default {
  "owner": "init",
  "version": 2,
  "modules": [
    {
      "id": "init.setup",
      "permission": "init.module.setup",
      "title": "服务器接入配置",
      "roles": [
        "superadmin"
      ],
      "scope": "global",
      "requires": [
        "init.get.setup.platform",
        "init.get.setup.probe",
        "init.post.setup.auto.read",
        "init.post.setup.local.restart",
        "init.post.setup.auto.remote",
        "init.post.setup.auto.verify"
      ]
    }
  ],
  "actions": [
    {
      "id": "init.post.setup.local.restart",
      "method": "POST",
      "path": "/api/setup/local-restart",
      "scope": "global",
      "module": "init.setup"
    },
    {
      "id": "init.get.setup.platform",
      "method": "GET",
      "path": "/api/setup/platform",
      "scope": "global",
      "module": "init.setup"
    },
    {
      "id": "init.get.setup.probe",
      "method": "GET",
      "path": "/api/setup/probe",
      "scope": "global",
      "module": "init.setup"
    },
    {
      "id": "init.post.setup.auto.read",
      "method": "POST",
      "path": "/api/setup/auto-read",
      "scope": "global",
      "module": "init.setup"
    },
    {
      "id": "init.post.setup.auto.remote",
      "method": "POST",
      "path": "/api/setup/auto-remote",
      "scope": "global",
      "module": "init.setup"
    },
    {
      "id": "init.post.setup.auto.verify",
      "method": "POST",
      "path": "/api/setup/auto-verify",
      "scope": "global",
      "module": "init.setup"
    }
  ],
  "features": []
}
