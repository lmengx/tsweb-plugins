import fs from 'node:fs/promises'
import path from 'node:path'
import { randomUUID, createHash } from 'node:crypto'

// Read the ECMA-335 Assembly and Module identities without loading a game DLL
// or requiring a .NET SDK on the panel machine. Native/invalid images return null.
export function assemblyIdentity(b) {
  try {
    if (b.readUInt16LE(0) !== 0x5a4d) return null
    const pe = b.readUInt32LE(0x3c)
    if (b.readUInt32LE(pe) !== 0x4550) return null
    const optional = pe + 24, magic = b.readUInt16LE(optional)
    if (![0x10b, 0x20b].includes(magic)) return null
    const sections = optional + b.readUInt16LE(pe + 20)
    const offset = rva => {
      for (let i = 0; i < b.readUInt16LE(pe + 6); i++) {
        const s = sections + i * 40, start = b.readUInt32LE(s + 12)
        if (rva >= start && rva < start + Math.max(b.readUInt32LE(s + 8), b.readUInt32LE(s + 16))) return b.readUInt32LE(s + 20) + rva - start
      }
      throw new Error('RVA outside sections')
    }
    const cliRva = b.readUInt32LE(optional + (magic === 0x10b ? 96 : 112) + 14 * 8)
    if (!cliRva) return null
    const md = offset(b.readUInt32LE(offset(cliRva) + 8))
    if (b.readUInt32LE(md) !== 0x424a5342) return null
    const align = n => Math.ceil(n / 4) * 4
    let p = align(md + 16 + b.readUInt32LE(md + 12))
    const streams = b.readUInt16LE(p + 2), heaps = {}
    p += 4
    for (let i = 0; i < streams; i++) {
      const start = b.readUInt32LE(p), end = b.indexOf(0, p + 8)
      if (end < 0 || end > p + 40) return null
      heaps[b.toString('ascii', p + 8, end)] = md + start
      p = align(end + 1)
    }
    const tables = heaps['#~'] ?? heaps['#-']
    const sizes = b[tables + 6], valid = b.readBigUInt64LE(tables + 8), rows = Array(64).fill(0)
    p = tables + 24
    for (let i = 0; i < 64; i++) if (valid & (1n << BigInt(i))) { rows[i] = b.readUInt32LE(p); p += 4 }
    if (rows[32] !== 1 || rows[0] !== 1) return null
    const str = sizes & 1 ? 4 : 2, guid = sizes & 2 ? 4 : 2, blob = sizes & 4 ? 4 : 2
    const t = i => rows[i] >= 65536 ? 4 : 2
    const c = (bits, ...ids) => Math.max(...ids.map(i => rows[i])) >= 2 ** (16 - bits) ? 4 : 2
    const td = c(2, 2, 1, 27), mr = c(1, 6, 10)
    const widths = [
      2 + str + 3 * guid, c(2, 0, 26, 35, 1) + 2 * str, 4 + 2 * str + td + t(4) + t(6), t(4), 2 + str + blob, t(6),
      8 + str + blob + t(8), t(8), 4 + str, t(2) + td, c(3, 2, 1, 26, 6, 27) + str + blob, 2 + c(2, 4, 8, 23) + blob,
      c(5, 6, 4, 1, 2, 8, 9, 10, 0, 14, 23, 20, 17, 26, 27, 32, 35, 38, 39, 40, 42, 44, 43) + c(3, 6, 10) + blob,
      c(1, 4, 8) + blob, 2 + c(2, 2, 6, 32) + blob, 6 + t(2), 4 + t(4), blob, t(2) + t(20), t(20), 2 + str + td,
      t(2) + t(23), t(23), 2 + str + blob, 2 + t(6) + c(1, 20, 23), t(2) + 2 * mr, str, blob,
      2 + c(1, 4, 6) + str + t(26), 4 + t(4), 8, 4,
    ]
    const index = (at, size) => size === 4 ? b.readUInt32LE(at) : b.readUInt16LE(at)
    const moduleGuid = index(p + 2 + str, guid)
    let a = p
    for (let i = 0; i < 32; i++) a += rows[i] * widths[i]
    const nameAt = heaps['#Strings'] + index(a + 16 + blob, str)
    const nameEnd = b.indexOf(0, nameAt)
    if (nameEnd < nameAt || nameEnd > nameAt + 512 || !moduleGuid) return null
    const g = heaps['#GUID'] + (moduleGuid - 1) * 16
    const hex = (n, length) => n.toString(16).padStart(length, '0')
    const moduleId = `${hex(b.readUInt32LE(g), 8)}-${hex(b.readUInt16LE(g + 4), 4)}-${hex(b.readUInt16LE(g + 6), 4)}-${b.subarray(g + 8, g + 10).toString('hex')}-${b.subarray(g + 10, g + 16).toString('hex')}`
    return { name: b.toString('utf8', nameAt, nameEnd), version: [4, 6, 8, 10].map(n => b.readUInt16LE(a + n)).join('.'), moduleId }
  } catch { return null }
}

export async function prepareReceiverFiles(pluginDir, source, io = fs) {
  const bytes = await io.readFile(source), identity = assemblyIdentity(bytes)
  if (identity?.name !== 'TsWebHost') throw new Error('接收端来源不是有效的 TsWebHost 程序集')
  await io.mkdir(pluginDir, { recursive: true })
  if ((await io.lstat(pluginDir)).isSymbolicLink()) throw new Error('ServerPlugins 不能是符号链接，请使用实际游戏服目录')
  const target = path.join(pluginDir, 'TsWebHost.dll'), existing = []
  async function scan(dir) {
    for (const item of await io.readdir(dir, { withFileTypes: true })) {
      const file = path.join(dir, item.name)
      if (item.isSymbolicLink()) {
        if (file.toLowerCase() === target.toLowerCase()) throw new Error('接收端目标不能是符号链接')
        continue
      }
      if (item.isDirectory()) await scan(file)
      else if (item.name.toLowerCase().endsWith('.dll')) {
        const content = await io.readFile(file), found = assemblyIdentity(content)
        if (found?.name === 'TsWebHost') existing.push({ file, content, identity: found })
        else if (file.toLowerCase() === target.toLowerCase()) throw new Error('TsWebHost.dll 目标不是可识别的接收端，拒绝覆盖')
      }
    }
  }
  await scan(pluginDir)
  const canonical = existing.find(item => item.file.toLowerCase() === target.toLowerCase())
  if (existing.length === 1 && canonical?.content.equals(bytes)) return { status: 'exists', path: target, from: source, identity, retired: [] }
  const id = randomUUID(), backup = path.join(path.dirname(pluginDir), '.tsweb-backups', 'receiver', id)
  const pending = path.join(pluginDir, `.tswebhost-${id}.pending`), moved = []
  try {
    await io.writeFile(pending, bytes, { flag: 'wx' })
    if (existing.length) {
      await io.mkdir(backup, { recursive: true })
      await io.writeFile(path.join(backup, 'manifest.json'), JSON.stringify({ createdAt: new Date().toISOString(), replacement: identity, files: existing.map(item => ({ path: path.relative(pluginDir, item.file), ...item.identity, sha256: createHash('sha256').update(item.content).digest('hex') })) }, null, 2))
    }
    for (const item of existing) {
      const archived = path.join(backup, path.relative(pluginDir, item.file))
      await io.mkdir(path.dirname(archived), { recursive: true })
      await io.rename(item.file, archived)
      moved.push({ file: item.file, archived })
    }
    await io.rename(pending, target)
    return { status: existing.length ? 'replaced' : 'copied', from: source, path: target, identity, backup: existing.length ? backup : null, retired: moved.map(item => item.file) }
  } catch (error) {
    const failures = []
    for (const item of moved.reverse()) { try { await io.rename(item.archived, item.file) } catch (e) { failures.push(e.message) } }
    throw new Error(`接收端替换失败，${failures.length ? `回滚未完整完成，请从 ${backup} 恢复：${failures.join('; ')}` : '原文件已保留或恢复'}。请停服后重试：${error.message}`)
  } finally { await io.rm(pending, { force: true }).catch(() => {}) }
}
