import fs from 'node:fs/promises'
import path from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { assemblyIdentity } from './receiver-files.js'

// 本机扫描：进程、监听端口、实例配置、接收端版本一次性取齐。
//
// 性能约束（历史问题：扫描慢）：调用次数固定，不随实例数增长。
//   - Windows：一次 Get-Process（进程号 + EXE 路径）与一次 netstat（全量监听端口）并行，
//     本机实测合计约 350 ms；
//   - 过去是 tasklist 取 PID（约 1000 ms）之后再对每个 PID 各起一次 PowerShell 取路径
//     （失败还要再起两次兜底），实例越多越慢，这正是"扫描太慢"的来源。
// 端口约束（历史问题：已监听 REST 的实例仍被改成最小空闲端口）：
//   - 每个实例都会尝试读它自己的 tshock/config.json（与进程同目录），拿到真实
//     RestApiPort 并判断该端口是否已由该实例监听；能读到就以此为准，
//     绝不再用"从 7878 开始的最小空闲端口"顶替它的配置值。

const execFileAsync = promisify(execFile)
const DEFAULT_TIMEOUT = 15000
const RECEIVER_NAME = 'TsWebHost'

// 执行器返回 { ok, stdout }：ok=false 表示"命令本身没跑成"（PowerShell 被策略拦住、
// 超时、程序不存在），与"跑成了但没有匹配结果"是两件事，不能都折叠成"未找到进程"。
async function defaultRun(file, args, timeout = DEFAULT_TIMEOUT) {
  try {
    const { stdout } = await execFileAsync(file, args, { windowsHide: true, timeout, maxBuffer: 8 * 1024 * 1024 })
    return { ok: true, stdout: stdout || '' }
  } catch (error) {
    return { ok: false, stdout: typeof error?.stdout === 'string' ? error.stdout : '' }
  }
}

/** 允许注入的执行器直接返回字符串（测试便利），统一成 { ok, stdout } */
function normalizeRun(result) {
  if (typeof result === 'string') return { ok: true, stdout: result }
  return { ok: result?.ok !== false, stdout: result?.stdout ?? '' }
}

const failure = (message, status = 400) => Object.assign(new Error(message), { status })

/** 校验扫描用的程序名：只允许常规可执行文件名，不允许引号/换行 */
function safeName(name) {
  const value = String(name || '').trim()
  if (!value) throw failure('请填写要扫描的程序名')
  if (value.length > 128 || /["\r\n\t]/.test(value)) throw failure('程序名包含不支持的字符')
  return value
}

function safePort(port) {
  const value = Number(String(port ?? '').trim())
  if (!Number.isInteger(value) || value < 1 || value > 65535) throw failure('端口需为 1-65535 的整数')
  return value
}

function smallestFreePort(occupied, from = 7878) {
  let port = from
  while (occupied.has(port) && port < 65535) port++
  return port
}

// ── Windows ────────────────────────────────────────────────

// 一次 PowerShell 同时拿到 PID 与 EXE 路径（Get-Process，不依赖 WMI，同账户无需提权）。
// 刻意不用 tasklist：它只给 PID 不给路径，还要再补一次取路径；本机实测 tasklist 约
// 1000 ms，而 Get-Process 批量只要约 300 ms，所以名字模式只起这一个进程。
// 进程名作为 base64 JSON 传入 -EncodedCommand，既不受引号影响，也不会被当成通配符。
async function winProcessesByName(name, run) {
  const program = safeName(name).replace(/\.exe$/i, '')
  const input = Buffer.from(JSON.stringify({ program }), 'utf8').toString('base64')
  const script = `$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[System.Text.Encoding]::UTF8
$data=([System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${input}')) | ConvertFrom-Json)
@(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -eq $data.program } |
  ForEach-Object { [pscustomobject]@{ id = $_.Id; path = $_.Path } }) | ConvertTo-Json -Compress
`
  const result = normalizeRun(await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')]))
  return { ok: result.ok, processes: parseProcesses(result.stdout) }
}

function parseProcesses(out) {
  let parsed
  try { parsed = JSON.parse(String(out || '').trim() || 'null') } catch { return [] }
  const rows = Array.isArray(parsed) ? parsed : parsed ? [parsed] : []
  return rows
    .filter(row => row && Number.isInteger(row.id) && row.id > 0)
    .map(row => ({ pid: String(row.id), path: typeof row.path === 'string' ? row.path : '' }))
}

async function winPathsByPid(pids, run) {
  // 端口模式只对命中的 PID 取一次路径：同样是单次 Get-Process，不逐 PID 起进程。
  const ids = pids.filter(pid => /^\d+$/.test(pid)).join(',')
  if (!ids) return { ok: true, paths: new Map() }
  const script = `[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; `
    + `Get-Process -Id ${ids} -ErrorAction SilentlyContinue | Select-Object Id, Path | ConvertTo-Json -Compress`
  const result = normalizeRun(await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script]))
  let parsed
  try { parsed = JSON.parse(result.stdout.trim() || 'null') } catch { return { ok: result.ok, paths: new Map() } }
  const rows = Array.isArray(parsed) ? parsed : parsed ? [parsed] : []
  return { ok: result.ok, paths: new Map(rows
    .filter(row => row && row.Id)
    .map(row => [String(row.Id), typeof row.Path === 'string' ? row.Path : ''])) }
}

async function winPortsByPid(run) {
  // netstat 一次全量，按 PID 分组；只认 LISTENING。
  const result = normalizeRun(await run('netstat.exe', ['-ano']))
  const map = new Map()
  for (const line of result.stdout.split(/\r?\n/)) {
    const parts = line.trim().split(/\s+/)
    if (parts.length < 5 || !/^LISTENING$/i.test(parts[parts.length - 2] || '')) continue
    const pid = parts[parts.length - 1]
    const local = parts[1] || ''
    const index = local.lastIndexOf(':')
    const port = index >= 0 ? local.slice(index + 1) : ''
    if (!/^\d+$/.test(pid) || !/^\d+$/.test(port) || port === '0') continue
    if (!map.has(pid)) map.set(pid, [])
    const ports = map.get(pid)
    if (!ports.includes(port)) ports.push(port)
  }
  return { ok: result.ok, portsByPid: map }
}

// ── Linux / macOS（纯 /proc，零外部依赖、免 root）─────────────

async function linuxListPids(io) {
  const pids = []
  try {
    for (const entry of await io.readdir('/proc')) if (/^\d+$/.test(entry)) pids.push(entry)
  } catch { /* 非 Linux */ }
  return pids
}

async function linuxPidsByName(name, io) {
  const variants = [name]
  if (name.toLowerCase().endsWith('.exe')) variants.push(name.slice(0, -4))
  const pids = []
  for (const pid of await linuxListPids(io)) {
    let cmd = ''
    try { cmd = (await io.readFile(`/proc/${pid}/cmdline`)).toString('utf8').split('\0').filter(Boolean).join(' ') } catch { /* 进程已退出 */ }
    if (variants.some(variant => cmd.includes(variant))) pids.push(pid)
  }
  return pids
}

async function linuxPathOf(pid, io) {
  try { return await io.readlink(`/proc/${pid}/exe`) } catch { return '' }
}

async function linuxPortsByPid(io) {
  const inodeToPort = new Map()
  for (const file of ['/proc/net/tcp', '/proc/net/tcp6']) {
    let text = ''
    try { text = await io.readFile(file, 'utf8') } catch { continue }
    for (const line of text.split('\n').slice(1)) {
      const parts = line.trim().split(/\s+/)
      if (parts.length < 10 || parts[3] !== '0A') continue // 0A = LISTEN
      const local = parts[1]
      const index = local.lastIndexOf(':')
      const port = parseInt(index >= 0 ? local.slice(index + 1) : '', 16)
      if (port && /^\d+$/.test(parts[9])) inodeToPort.set(parts[9], port)
    }
  }
  const result = new Map()
  for (const pid of await linuxListPids(io)) {
    let fds
    try { fds = await io.readdir(`/proc/${pid}/fd`) } catch { continue }
    for (const fd of fds) {
      try {
        const match = (await io.readlink(`/proc/${pid}/fd/${fd}`)).match(/^socket:\[(\d+)\]$/)
        if (!match || !inodeToPort.has(match[1])) continue
        if (!result.has(pid)) result.set(pid, [])
        const ports = result.get(pid), port = String(inodeToPort.get(match[1]))
        if (!ports.includes(port)) ports.push(port)
      } catch { /* 句柄不可读 */ }
    }
  }
  return result
}

// ── 实例详情：配置文件 + 接收端（两者都只读，失败就如实留空）────────

async function findReceiverCopies(pluginDir, io, p) {
  const found = []
  async function scan(current) {
    let items
    try { items = await io.readdir(current, { withFileTypes: true }) } catch { return }
    for (const item of items) {
      const file = p.join(current, item.name)
      if (item.isDirectory()) { await scan(file); continue }
      if (!item.name.toLowerCase().endsWith('.dll')) continue
      // 接收端只有几十 KB；超大文件直接跳过，避免为扫描去读整个磁盘上的大 DLL
      if (typeof io.stat === 'function') {
        try { if ((await io.stat(file)).size > 64 * 1024 * 1024) continue } catch { continue }
      }
      let bytes
      try { bytes = await io.readFile(file) } catch { continue }
      const identity = assemblyIdentity(bytes)
      if (identity?.name === RECEIVER_NAME) found.push({ file, version: identity.version, moduleId: identity.moduleId })
    }
  }
  await scan(pluginDir)
  return found
}

async function decorate({ pid, executablePath, ports }, context) {
  const { io, bundled, portsByPid, p } = context
  const instance = { pid: Number(pid), path: executablePath || '', ports: ports || [] }
  const directory = executablePath && p.isAbsolute(executablePath) ? p.dirname(executablePath) : null

  // 配置文件：与进程同目录的 tshock/config.json。这里是"只读候选"，
  // 真正的配置路径由热接入在游戏进程内核对（不一致会明确报错，不会写错文件）。
  const configPath = directory ? p.join(directory, 'tshock', 'config.json') : null
  let settings = null
  if (configPath) {
    try {
      const config = JSON.parse(await io.readFile(configPath, 'utf8'))
      settings = config?.Settings || config
    } catch { /* 没装 TShock / 没权限 / JSON 损坏：留空 */ }
  }
  const configuredPort = Number.isInteger(settings?.RestApiPort) ? settings.RestApiPort : null
  const ownedPorts = new Set(instance.ports.map(String))
  // 该端口是否已被"别的进程"占住，决定是复用还是必须换端口
  let occupiedByOther = false
  if (configuredPort) {
    for (const [otherPid, otherPorts] of portsByPid) {
      if (otherPid !== String(pid) && otherPorts.map(String).includes(String(configuredPort))) { occupiedByOther = true; break }
    }
  }
  const restListening = configuredPort ? ownedPorts.has(String(configuredPort)) : false
  instance.configPath = configPath && settings ? configPath : null
  instance.restPort = configuredPort
  instance.restEnabled = settings?.RestApiEnabled === true
  instance.restListening = restListening
  instance.restConflict = occupiedByOther
  instance.restSource = configuredPort ? (restListening ? 'listening' : occupiedByOther ? 'conflict' : 'config') : null
  instance.tokenPresent = !!settings?.ApplicationRestTokens && Object.values(settings.ApplicationRestTokens)
    .some(value => value && value.Username === 'TSWeb' && value.UserGroupName === 'superadmin')

  // 磁盘上的接收端：用于在"动手之前"就告诉用户版本是否配套、是否需要重启。
  // 路径读不到（异账户/提权进程）时 known=false，界面上不能断言"还没安装"。
  const pluginDir = directory ? p.join(directory, 'ServerPlugins') : null
  const copies = pluginDir ? await findReceiverCopies(pluginDir, io, p) : []
  const single = copies.length === 1 ? copies[0] : null
  instance.receiver = {
    pluginDir,
    known: !!pluginDir,
    copies: copies.length,
    files: copies.map(copy => copy.file),
    version: single?.version ?? null,
    moduleId: single?.moduleId ?? null,
    matches: !!(single && bundled && single.moduleId.toLowerCase() === String(bundled.moduleId).toLowerCase()),
  }
  return instance
}

/**
 * 扫描本机 TShock 实例。
 * @param {object} options
 * @param {'name'|'port'} [options.mode] 按程序名或按游戏端口
 * @param {string} [options.name] 程序名（name 模式）
 * @param {string|number} [options.port] 游戏端口（port 模式）
 * @param {{version?:string,moduleId:string}|null} [options.bundled] 宿主自带接收端身份
 * @param {string} [options.platform] 平台，测试可注入
 * @param {Function} [options.run] 命令执行器，测试可注入
 * @param {object} [options.io] fs 门面，测试可注入
 */
export async function probeLocal({ mode = 'name', name = '', port = '', bundled = null, platform = process.platform, run = defaultRun, io = fs } = {}) {
  const windows = platform === 'win32'
  const p = windows ? path.win32 : path
  const bundledReceiver = bundled ? { version: bundled.version ?? null, moduleId: bundled.moduleId, path: bundled.path ?? null } : null

  // 端口表先发出去，与进程枚举并行，避免串行叠加
  const portsPromise = windows
    ? winPortsByPid(run)
    : linuxPortsByPid(io).then(portsByPid => ({ ok: true, portsByPid }))

  if (mode === 'port') {
    const gamePort = safePort(port)
    const ports = await portsPromise
    if (!ports.ok) {
      return { found: false, mode: 'port', port: gamePort, processes: [], portsUnavailable: true, bundledReceiver,
        error: '无法读取本机监听端口（netstat 未执行成功）：请检查面板运行权限，或把 TShock 进程列表手动填写后重试' }
    }
    const pids = []
    for (const [pid, listening] of ports.portsByPid) if (listening.map(String).includes(String(gamePort))) pids.push(pid)
    if (!pids.length) {
      return { found: false, mode: 'port', port: gamePort, processes: [],
        suggestedRestPort: gamePort >= 7878 ? Math.min(gamePort + 1, 65535) : 7878, bundledReceiver }
    }
    const paths = windows
      ? (await winPathsByPid(pids, run)).paths
      : new Map(await Promise.all(pids.map(async pid => [pid, await linuxPathOf(pid, io)])))
    const occupied = new Set([...ports.portsByPid.values()].flat().map(Number))
    const processes = await Promise.all(pids.map(async pid => decorate(
      { pid, executablePath: paths.get(pid) || '', ports: ports.portsByPid.get(pid) || [] },
      { io, bundled, portsByPid: ports.portsByPid, p })))
    return { found: true, mode: 'port', port: gamePort, processes,
      suggestedRestPort: smallestFreePort(occupied), bundledReceiver }
  }

  const programName = safeName(name)
  if (!windows) {
    const pids = await linuxPidsByName(programName, io)
    if (!pids.length) return { found: false, mode: 'name', name: programName, instances: [], bundledReceiver }
    const [ports, paths] = await Promise.all([
      portsPromise,
      Promise.all(pids.map(async pid => [pid, await linuxPathOf(pid, io)])).then(rows => new Map(rows)),
    ])
    const occupied = new Set([...ports.portsByPid.values()].flat().map(Number))
    const instances = await Promise.all(pids.map(async pid => decorate(
      { pid, executablePath: paths.get(pid) || '', ports: ports.portsByPid.get(pid) || [] },
      { io, bundled, portsByPid: ports.portsByPid, p })))
    return { found: instances.length > 0, mode: 'name', name: programName, instances,
      suggestedRestPort: smallestFreePort(occupied), bundledReceiver }
  }

  // Windows：进程枚举与端口表并行，两次进程调用，与实例数无关
  const [enumerated, ports] = await Promise.all([winProcessesByName(programName, run), portsPromise])
  // PowerShell 是唯一发现通道：它没跑成时不能回报"没有这个进程"
  if (!enumerated.ok) {
    return { found: false, mode: 'name', name: programName, instances: [], bundledReceiver,
      error: '无法枚举本机进程（PowerShell 未执行成功或超时）：请确认面板能运行 powershell.exe，或改用按端口扫描' }
  }
  if (!enumerated.processes.length) {
    return { found: false, mode: 'name', name: programName, instances: [], bundledReceiver,
      portsUnavailable: !ports.ok }
  }
  const portsByPid = ports.portsByPid
  const occupied = new Set([...portsByPid.values()].flat().map(Number))
  const instances = await Promise.all(enumerated.processes.map(async entry => decorate(
    { pid: entry.pid, executablePath: entry.path, ports: portsByPid.get(String(entry.pid)) || [] },
    { io, bundled, portsByPid, p })))
  return { found: true, mode: 'name', name: programName, instances,
    suggestedRestPort: smallestFreePort(occupied), bundledReceiver, portsUnavailable: !ports.ok }
}

/**
 * 向导默认使用的 REST 端口：
 *   实例配置可读 → 用它自己的 RestApiPort（已在监听就原样复用，不改配置）；
 *   配置端口被别的进程占住 → 才回退到最小空闲端口；
 *   配置不可读 → 回退到最小空闲端口。
 */
export function preferredRestPort(instance, suggestedRestPort) {
  const valid = port => Number.isInteger(port) && port >= 1 && port <= 65535
  const fallback = valid(suggestedRestPort) ? suggestedRestPort : null
  if (!instance) return fallback
  if (valid(instance.restPort) && !instance.restConflict) return instance.restPort
  return fallback ?? (valid(instance.restPort) ? instance.restPort : null)
}
