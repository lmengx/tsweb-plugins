import crypto from 'node:crypto'
import path from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'

const execFileAsync = promisify(execFile)
const failure = (message, status = 409) => Object.assign(new Error(message), { status })
const samePath = (a, b) => path.win32.resolve(a).toLowerCase() === path.win32.resolve(b).toLowerCase()

// Values are transported as JSON/base64, never interpolated as shell code.
async function powershell(source, input, timeout = 15000) {
  const encodedInput = Buffer.from(JSON.stringify(input), 'utf8').toString('base64')
  const script = `$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[System.Text.Encoding]::UTF8
$inputData=([System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${encodedInput}')) | ConvertFrom-Json)
try { ${source} } catch { @{success=$false;error=$_.Exception.Message} | ConvertTo-Json -Compress -Depth 8 }`
  let stdout
  try {
    ({ stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')], {
      windowsHide: true, timeout, maxBuffer: 1024 * 1024,
    }))
  } catch {
    throw failure('无法完成本机进程操作，请检查面板运行账户的权限，并确认游戏服窗口仍可用', 503)
  }
  let result
  try { result = JSON.parse(stdout.trim()) }
  catch { throw failure('本机进程操作未返回有效结果，请重新扫描实例', 502) }
  if (result.success === false) throw failure(result.error || '本机重启失败')
  return result
}

// Win32_Process does not expose a process's working directory. Read only the
// Windows x64 PEB process-parameters prefix. These offsets are OS internals;
// unsupported bitness, unreadable memory and invalid paths fail closed.
// Never infer CWD from the executable directory or from launch arguments.
const workingDirectoryScript = `
Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
public static class TsWebProcessDirectory {
  [StructLayout(LayoutKind.Sequential)] struct BasicInfo { public IntPtr reserved1,peb,reserved2,reserved3,pid,reserved4; }
  public sealed class Snapshot {
    public int pid { get; set; }
    public string executablePath { get; set; }
    public string commandLine { get; set; }
    public string startedAt { get; set; }
    public string workingDirectory { get; set; }
  }
  [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int pid);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool CloseHandle(IntPtr handle);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageNameW(IntPtr process,uint flags,StringBuilder path,ref int length);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(IntPtr process,out long creation,out long exit,out long kernel,out long user);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool IsWow64Process(IntPtr process,out bool wow64);
  [DllImport("ntdll.dll")] static extern int NtQueryInformationProcess(IntPtr process,int kind,out BasicInfo info,int size,out int returned);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool ReadProcessMemory(IntPtr process,IntPtr address,byte[] data,IntPtr size,out IntPtr read);
  static byte[] Read(IntPtr process,IntPtr address,int size) {
    var bytes=new byte[size]; IntPtr read;
    if (!ReadProcessMemory(process,address,bytes,(IntPtr)size,out read) || read.ToInt64()!=size)
      throw NativeError("读取进程参数");
    return bytes;
  }
  static Exception NativeError(string stage) {
    int code=Marshal.GetLastWin32Error();
    string reason=code==5 ? "访问被拒绝；请核对面板与游戏服的运行权限" :
      code==87 || code==1168 ? "进程已退出或扫描结果已过期，请重新扫描" : new Win32Exception(code).Message;
    return new InvalidOperationException(stage+"失败（Win32 "+code+"）："+reason);
  }
  static IntPtr Parameters(IntPtr process) {
    bool wow64;
    if (IntPtr.Size!=8 || !IsWow64Process(process,out wow64) || wow64)
      throw new InvalidOperationException("进程读取需要 Windows x64 面板与 x64 游戏服");
    BasicInfo info; int returned;
    int status=NtQueryInformationProcess(process,0,out info,Marshal.SizeOf(typeof(BasicInfo)),out returned);
    if (status!=0) throw new InvalidOperationException("读取进程 PEB 失败（NTSTATUS 0x"+status.ToString("x8")+"）");
    return new IntPtr(BitConverter.ToInt64(Read(process,IntPtr.Add(info.peb,0x20),8),0));
  }
  static string UnicodeParameter(IntPtr process,IntPtr parameters,int offset) {
    var descriptor=Read(process,IntPtr.Add(parameters,offset),16);
    int length=BitConverter.ToUInt16(descriptor,0), maximum=BitConverter.ToUInt16(descriptor,2);
    if (length==0 || length%2!=0 || length>maximum || length>65532)
      throw new InvalidOperationException("目标进程参数为空或无效（offset 0x"+offset.ToString("x")+"），请重新扫描");
    return Encoding.Unicode.GetString(Read(process,new IntPtr(BitConverter.ToInt64(descriptor,8)),length));
  }
  public static Snapshot ReadSnapshot(int pid) {
    if (pid<=0) throw new InvalidOperationException("无效的目标 PID，请重新扫描");
    // QUERY_INFORMATION | VM_READ only. Do not use Process.Handle, which can
    // request PROCESS_ALL_ACCESS, or depend on CIM's optional path/cmd fields.
    IntPtr process=OpenProcess(0x0410,false,pid);
    if (process==IntPtr.Zero) throw NativeError("打开目标进程 PID "+pid);
    try {
      var path=new StringBuilder(32768); int length=path.Capacity;
      if (!QueryFullProcessImageNameW(process,0,path,ref length)) throw NativeError("读取目标 EXE");
      long creation,exit,kernel,user;
      if (!GetProcessTimes(process,out creation,out exit,out kernel,out user)) throw NativeError("读取启动时间");
      var parameters=Parameters(process);
      return new Snapshot { pid=pid,executablePath=path.ToString(),
        commandLine=UnicodeParameter(process,parameters,0x70),
        startedAt=DateTime.FromFileTimeUtc(creation).Ticks.ToString(),workingDirectory=ReadDirectory(process) };
    } finally { CloseHandle(process); }
  }
  public static string ReadDirectory(IntPtr process) {
    bool wow64;
    if (IntPtr.Size!=8 || !IsWow64Process(process,out wow64) || wow64)
      throw new InvalidOperationException("自动重启仅支持可核验工作目录的 Windows x64 实例，请使用原启动器");
    BasicInfo info; int returned;
    if (NtQueryInformationProcess(process,0,out info,Marshal.SizeOf(typeof(BasicInfo)),out returned)!=0)
      throw new InvalidOperationException("无法核验原工作目录，请使用原启动器");
    var parameters=new IntPtr(BitConverter.ToInt64(Read(process,IntPtr.Add(info.peb,0x20),8),0));
    var directory=Read(process,IntPtr.Add(parameters,0x38),16);
    int length=BitConverter.ToUInt16(directory,0), maximum=BitConverter.ToUInt16(directory,2);
    if (length==0 || length%2!=0 || length>maximum || length>65532)
      throw new InvalidOperationException("原工作目录信息无效，请使用原启动器");
    var buffer=new IntPtr(BitConverter.ToInt64(directory,8));
    var value=Encoding.Unicode.GetString(Read(process,buffer,length));
    if (!System.IO.Path.IsPathRooted(value) || !System.IO.Directory.Exists(value))
      throw new InvalidOperationException("原工作目录不可访问，请使用原启动器");
    return value;
  }
}
'@
`

const snapshotScript = workingDirectoryScript + `
[TsWebProcessDirectory]::ReadSnapshot([int]$inputData.pid) | ConvertTo-Json -Compress
`
export const inspectLocalProcess = pid => powershell(snapshotScript, { pid })

// Send verified line input to an isolated TShock console while it is waiting
// for world selection. The helper deliberately refuses shared consoles.
const worldInputScript = workingDirectoryScript + `
Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices; using Microsoft.Win32.SafeHandles;
public static class TsWebWorldInput {
 [StructLayout(LayoutKind.Explicit, CharSet=CharSet.Unicode, Size=20)] public struct Input { [FieldOffset(0)] public short type; [FieldOffset(4)] public int down; [FieldOffset(8)] public short repeat; [FieldOffset(10)] public short key; [FieldOffset(14)] public char character; }
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool FreeConsole();
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool AttachConsole(uint pid);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetConsoleProcessList([Out] uint[] p,uint n);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern SafeFileHandle CreateFileW(string n,uint a,uint s,IntPtr sec,uint c,uint f,IntPtr t);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool WriteConsoleInputW(SafeFileHandle h,Input[] b,uint n,out uint w);
 public static void Send(int pid,string[] lines) { FreeConsole(); if(!AttachConsole((uint)pid)) throw new InvalidOperationException("无法连接游戏服控制台"); try { var m=new uint[16]; var c=GetConsoleProcessList(m,16); var self=(uint)System.Diagnostics.Process.GetCurrentProcess().Id; if(c!=2 || !((m[0]==(uint)pid&&m[1]==self)||(m[0]==self&&m[1]==(uint)pid))) throw new InvalidOperationException("所选实例使用共享或无法核验的控制台"); using(var h=CreateFileW("CONIN$",0xC0000000,3,IntPtr.Zero,3,0,IntPtr.Zero)){ if(h.IsInvalid) throw new InvalidOperationException("游戏服没有可操作的控制台"); foreach(var line in lines){ var s=(line??"")+"\\r"; var r=new Input[s.Length*2]; for(int i=0;i<s.Length;i++){ short k=(short)(s[i]=='\\r'?13:(s[i]>=32&&s[i]<=126?s[i]:32)); r[i*2]=new Input{type=1,down=1,repeat=1,key=k,character=s[i]}; r[i*2+1]=r[i*2]; r[i*2+1].down=0; } uint w; if(!WriteConsoleInputW(h,r,(uint)r.Length,out w)||w!=r.Length) throw new InvalidOperationException("无法向游戏服控制台发送世界选择输入"); System.Threading.Thread.Sleep(120); } } } finally { FreeConsole(); } }
}
'@
[TsWebWorldInput]::Send([int]$inputData.pid,[string[]]$inputData.lines)
@{success=$true} | ConvertTo-Json -Compress
`
export const sendWorldSelection = (pid, lines) => powershell(worldInputScript, { pid, lines }, 30000)

// The helper detaches from its own console before attaching to the selected
// server. Console output cannot establish the selected process's world state.
// Never kill a process, and never send input to a shared console.
const restartScript = workingDirectoryScript + `
$target=Get-CimInstance Win32_Process -Filter ("ProcessId="+[int]$inputData.pid)
$process=[Diagnostics.Process]::GetProcessById([int]$inputData.pid)
if (!$target -or $target.ExecutablePath -ine $inputData.executablePath -or $target.CommandLine -cne $inputData.commandLine -or $process.StartTime.ToUniversalTime().Ticks.ToString() -ne $inputData.startedAt) { throw '所选进程已经变化，请重新扫描，未执行重启' }
$originalDirectory=[TsWebProcessDirectory]::ReadDirectory($process.Handle)
if (!$inputData.workingDirectory -or $originalDirectory -ine $inputData.workingDirectory) { throw '原工作目录已经变化或无法核验，请使用原启动器；未发送退出命令' }
$before=@(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -and $_.ExecutablePath -ieq $inputData.executablePath } | Select-Object -ExpandProperty ProcessId)
$line=$target.CommandLine.TrimStart()
if ($line.StartsWith('"')) {
  $end=$line.IndexOf('"',1)
  if ($end -lt 1) { throw '无法保留原启动参数，请使用原启动器重启' }
  $program=$line.Substring(1,$end-1)
  $arguments=$line.Substring($end+1).TrimStart()
} elseif ($line.StartsWith($target.ExecutablePath,[StringComparison]::OrdinalIgnoreCase) -and ($line.Length -eq $target.ExecutablePath.Length -or [char]::IsWhiteSpace($line[$target.ExecutablePath.Length]))) {
  $program=$target.ExecutablePath
  $arguments=$line.Substring($target.ExecutablePath.Length).TrimStart()
} else {
  $parts=$line -split '\\s+',2
  $program=$parts[0]
  $arguments=if ($parts.Length -gt 1) { $parts[1] } else { '' }
}
if ($program -ine $target.ExecutablePath -and $program -ine [IO.Path]::GetFileName($target.ExecutablePath)) { throw '无法识别原启动参数，请使用原启动器重启' }
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Microsoft.Win32.SafeHandles;
public static class TsWebRestartConsole {
  [StructLayout(LayoutKind.Explicit, CharSet=CharSet.Unicode, Size=20)]
  public struct Input {
    [FieldOffset(0)] public short type;
    [FieldOffset(4)] public int down;
    [FieldOffset(8)] public short repeat;
    [FieldOffset(10)] public short key;
    [FieldOffset(12)] public short scan;
    [FieldOffset(14)] public char character;
  }
  [StructLayout(LayoutKind.Sequential)] public struct Coord { public short x,y; }
  [StructLayout(LayoutKind.Sequential)] public struct Rect { public short left,top,right,bottom; }
  [StructLayout(LayoutKind.Sequential)] public struct Screen { public Coord size,cursor; public short attributes; public Rect window; public Coord maximum; }
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool FreeConsole();
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool AttachConsole(uint pid);
  [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetConsoleProcessList([Out] uint[] processes,uint count);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern SafeFileHandle CreateFileW(string name,uint access,uint share,IntPtr security,uint creation,uint flags,IntPtr template);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool WriteConsoleInputW(SafeFileHandle input,Input[] buffer,uint count,out uint written);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetConsoleScreenBufferInfo(SafeFileHandle output,out Screen screen);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool ReadConsoleOutputCharacterW(SafeFileHandle output,[Out] char[] text,uint count,Coord start,out uint read);
  [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern short VkKeyScanW(char character);
  [DllImport("user32.dll")] static extern uint MapVirtualKeyW(uint code,uint map);
  static bool AtWorldSelection(SafeFileHandle output) {
    Screen screen;
    if (output.IsInvalid || !GetConsoleScreenBufferInfo(output,out screen) || screen.cursor.x <= 0) return false;
    var text=new char[screen.cursor.x];
    uint read;
    // The cursor counts screen columns; wide Chinese/Japanese characters use
    // two columns while the API returns one UTF-16 character. It adds no NUL.
    if (!ReadConsoleOutputCharacterW(output,text,(uint)screen.cursor.x,new Coord { x=0,y=screen.cursor.y },out read) || read==0 || read>text.Length) return false;
    // Match only the current input prompt, never old output or log files.
    return Regex.IsMatch(new string(text,0,(int)read).Trim(),@"^(?:Choose World|选择世界|選擇世界|Welt wählen|Elegir mundo|Choisissez le monde|Scegli mondo|Wybierz świat|Escolher Mundo|Выберите мир|ワールドを選択|세계 선택)\\s*[:：]$",RegexOptions.IgnoreCase);
  }
  public static string SaveAndExit(uint pid,string startedAt) {
    FreeConsole();
    if (!AttachConsole(pid)) throw new InvalidOperationException("无法连接游戏服控制台，请在原窗口保存世界并重启");
    try {
      var members=new uint[16];
      uint count=GetConsoleProcessList(members,(uint)members.Length);
      uint self=(uint)System.Diagnostics.Process.GetCurrentProcess().Id;
      if (count!=2 || !((members[0]==pid && members[1]==self) || (members[0]==self && members[1]==pid)))
        throw new InvalidOperationException("所选实例使用共享或无法核验的控制台，请使用原启动器；未发送退出命令");
      using (var handle=CreateFileW("CONIN$",0xC0000000,3,IntPtr.Zero,3,0,IntPtr.Zero)) {
        if (handle.IsInvalid) throw new InvalidOperationException("游戏服没有可操作的控制台，请使用原启动器重启");
        using (var output=CreateFileW("CONOUT$",0x80000000,3,IntPtr.Zero,3,0,IntPtr.Zero)) {
          if (AtWorldSelection(output)) {
            throw new InvalidOperationException("选世界界面不支持保存退出命令，请使用原启动器；面板不会强制结束进程");
          }
        }
        string command="exit\\r";
        var records=new Input[command.Length*2];
        for (int i=0;i<command.Length;i++) {
          short key=(short)(command[i]=='\\r'?13:VkKeyScanW(command[i])&255);
          records[i*2]=new Input { type=1, down=1, repeat=1, key=key, scan=(short)MapVirtualKeyW((uint)key,0), character=command[i] };
          records[i*2+1]=records[i*2]; records[i*2+1].down=0;
        }
        uint written;
        if (!WriteConsoleInputW(handle,records,(uint)records.Length,out written) || written!=records.Length)
          throw new InvalidOperationException("无法向游戏服控制台发送保存退出命令");
        return "save-and-exit";
      }
    } finally { FreeConsole(); }
  }
}
'@
$restartMode=[TsWebRestartConsole]::SaveAndExit([uint32]$inputData.pid,[string]$inputData.startedAt)
if (!$process.WaitForExit(120000)) { throw '等待保存退出超时，未强制结束进程，也未启动重复实例。请检查原游戏服窗口后重新扫描' }
# An external launcher may already have restarted this executable.
$other=@(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -and $_.ExecutablePath -ieq $inputData.executablePath -and $_.ProcessId -notin $before -and $_.CommandLine -ceq $inputData.commandLine })
if ($other.Count -gt 0) {
  if ($other.Count -ne 1) { throw '检测到多个同路径实例，请重新扫描确认；未启动额外实例' }
  $newProcess=[Diagnostics.Process]::GetProcessById([int]$other[0].ProcessId)
} else {
  try {
    $start=New-Object Diagnostics.ProcessStartInfo
    $start.FileName=$inputData.executablePath
    $start.Arguments=$arguments
    $start.WorkingDirectory=$inputData.workingDirectory
    $start.UseShellExecute=$true
    $start.WindowStyle=[Diagnostics.ProcessWindowStyle]::Normal
    $newProcess=[Diagnostics.Process]::Start($start)
  } catch { throw '原游戏服已保存退出，但新进程启动失败，请通过原启动器重新启动' }
}
if (!$newProcess) { throw '原游戏服已退出，但未取得新实例，请检查游戏服窗口' }
@{success=$true;pid=$newProcess.Id;mode=$restartMode} | ConvertTo-Json -Compress
`
export const restartLocalProcess = process => powershell(restartScript, process, 150000)

export function createLocalRestart({ platform = process.platform, inspect = inspectLocalProcess, restart = restartLocalProcess, now = Date.now, ttl = 30 * 60 * 1000 } = {}) {
  const tickets = new Map()
  const operations = new Map()
  const processKey = target => JSON.stringify([target.pid, target.startedAt, path.win32.resolve(target.executablePath).toLowerCase()])
  function prune() {
    for (const [id, record] of tickets) if (!record.running && record.expires <= now()) tickets.delete(id)
    for (const [key, operation] of operations) {
      if (!operation.running && operation.expires <= now()
        && ![...tickets.values()].some(record => record.key === key)) operations.delete(key)
    }
  }
  function issue(process, owner) {
    prune()
    const id = crypto.randomBytes(24).toString('base64url')
    tickets.set(id, { process, key: processKey(process), owner, expires: now() + ttl, running: false, operation: null })
    return id
  }
  async function prepare({ pid, processPath }, owner) {
    if (platform !== 'win32') return { available: false, reason: '当前一键重启支持 Windows 本机控制台实例；其他环境请使用原启动器重启' }
    if (!Number.isSafeInteger(pid) || pid <= 0) return { available: false, reason: '未取得所选实例的进程编号，请重新扫描后选择实例' }
    try {
      const process = await inspect(pid)
      if (!samePath(process.executablePath, processPath) || !/^TShock\.Server\.exe$/i.test(path.win32.basename(process.executablePath)))
        throw failure('所选进程与 TShock 路径不一致，请重新扫描')
      if (!process.commandLine || !process.startedAt) throw failure('无法保留原进程的启动信息，请使用原启动器重启')
      if (!process.workingDirectory || !path.win32.isAbsolute(process.workingDirectory))
        throw failure('无法核验原工作目录，请使用原启动器；面板不会自动停止实例')
      return { available: true, id: issue(process, owner) }
    } catch (error) { return { available: false, reason: error.message } }
  }
  async function run(id, owner) {
    prune()
    const record = tickets.get(id)
    if (!record || record.owner !== owner) throw failure('本机重启凭据无效或已过期，请重新扫描所选实例', 403)
    if (!record.operation) {
      record.running = true
      let shared = operations.get(record.key)
      if (!shared) {
        shared = { running: true, expires: now() + ttl, operation: null }
        operations.set(record.key, shared)
        shared.operation = (async () => {
          const latest = await inspect(record.process.pid)
          if (!samePath(latest.executablePath, record.process.executablePath) || latest.startedAt !== record.process.startedAt || latest.commandLine !== record.process.commandLine
            || !latest.workingDirectory || !samePath(latest.workingDirectory, record.process.workingDirectory))
            throw failure('所选进程已经变化，请重新扫描，未执行重启')
          const result = await restart(record.process)
          const next = await inspect(result.pid)
          if (!samePath(next.executablePath, record.process.executablePath)) throw failure('重启后的实例路径不一致，请重新扫描')
          return { next, mode: result.mode }
        })().finally(() => { shared.running = false; shared.expires = now() + ttl })
      }
      // Share the side effect across every ticket/account, while issuing the
      // successor ticket separately for each authorized requester.
      record.operation = shared.operation.then(({ next, mode }) => ({
        success: true, pid: next.pid, mode, restartId: issue(next, owner),
        message: '已保存并重新启动游戏服；如新窗口提示选择世界，请在该窗口继续，面板会自动检查就绪状态',
      })).finally(() => { record.running = false; record.expires = now() + ttl })
    }
    return record.operation
  }
  return { prepare, run }
}
