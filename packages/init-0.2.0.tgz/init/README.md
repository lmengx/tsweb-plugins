# 初始化向导

`init` 提供服务器接入，以及通用的插件初始化编排界面。不维护业务插件名单，不读取业务配置，不依赖文件管理、注册登录或反作弊插件。

插件在自己的 Vue 客户端入口调用 `ctx.initStep(definition)` 注册流程。步骤随所属插件加载、卸载、更新自动注册或移除。向导针对目标服务器请求 `/api/ui/context`，按步骤声明的 `requires` 过滤，再按 `order` 排序。没有注册的插件不会被探测；无权限的已注册步骤明确跳过。运行中贡献变更会取消当前会话，要求重新检查，防止执行过期回调。

## 扩展契约

- `id`、`title`、`order`：插件内步骤标识、标题、顺序，宿主生成 `owner:id` 唯一键。
- `requires`：本插件契约中的 action ID，必须同时获目标服务器授权；不能借其他插件的 action 注册流程。
- `component`：插件自己的 Vue 组件。接收 `modelValue`、`data`、`context`、`disabled`、`run`，发出 `update:modelValue` 与 `next`。
- `load({request,context,signal})`、`initial(data,context)`：只读预检与初始草稿。
- `validate(draft,data)`：提交前检查。任何步骤无效则不开始写入。
- `save({request,draft,data,context,signal})`：所属插件保存自己的配置，返回 `{needsRestart}`。成功步骤重试时不再重复写入；真实失败会保留并展示。
- 有 `load` 的保存失败步骤可单独“重新读取并确认”：更新该步骤的数据和初始草稿，由用户重新选择后再提交；其他步骤的草稿和成功记录保持不变。重读本身不保存配置，失败或取消不会替换原读取数据。
- `context.values`：本次会话按 `owner:id` 保存的草稿。插件应避免依赖其他可选插件的草稿。
- `request(url,json?)` 自动固定目标服务器、继承取消信号并检查业务错误；提供 json 时为 POST。
- 需即时操作的组件使用 `run(async ({request}) => ...)`，宿主在操作中锁住退出与提交；插件需明确告知即时保存语义，自行记录逐项成功以支持重试。

示例见 `plugins/base/ui/init-steps.js`、`plugins/registration/ui/init-steps.js`、`plugins/anti-cheat/ui/init-steps.js`。可复用 SDK 的 `UiInitChoices` 双击确认选项组件。

## 基础包

Base 自行声明玩家群体、SSC 和玩家组权限三个步骤。SSC 使用 Base 的专用 GET/POST `/api/base/ssc` 与游戏端 `/data/base/ssc`、`/data/base/ssc/save`，与文件管理无依赖。只修改 SSC 开关，保留其他字段；提交需携带读取时的 SHA-256 version。保存响应丢失、服务器错误或 409 时，Base 只读回查目标开关：若已经达到用户选择的状态，则确认完成并保留 needsRestart；否则继续显示原错误，用户可单独重新读取 SSC、重新选择并确认，使用新 version 保存，绝不自动覆盖冲突配置。不自动重启游戏服。

注册登录与反作弊插件各自声明自己的步骤，基础发行包不安装它们时也不会展示或请求它们。

## 本机扫描的首次热接入

Windows x64、配套 TShock 6.1 / .NET 9 的扫描实例默认使用“热接入并添加”。后端复核 PID、启动时间、可执行文件、真实工作目录及配置路径，调用发行包内与 Host 哈希配套的注入工具，在现有 CLR 内加载 Host，并在游戏线程初始化。随后校验原生 REST 授权、接收端身份与 Base 部署回执；只有就绪验证通过才算添加完成。无需初始 REST 接口，也无需 .NET SDK。

选世界阶段也支持首次注入。确认 TShock 已完成插件初始化后，通过启动前安全路径注册 Host REST/钩子，部署经过审查的 Base；进入世界后的第一个 tick 接管游戏线程事务。已有世界运行时仍在游戏线程初始化。TShock 本身尚未初始化完毕或游戏线程无响应时，20 秒后取消任务，不会稍后意外执行；可在状态稳定后明确重试。并发点击共享一次操作；结果不明确或有副作用的失败禁止自动重试。运行中的是不同版本的 Host 时，一键接入会把它整体退役（停 REST 传输、注销钩子、排空动作、移出插件容器）后装载本发行包的配套新版，并把旧 DLL 移出 `ServerPlugins`；只有新版没起来时才报告需重启。失败不自动停止或重启游戏服。成功后持久化接收端及配置供下次正常启动使用。

进程快照直接使用 Win32 `OpenProcess(QUERY_INFORMATION | VM_READ)`、进程启动时间及 PEB 参数读取，不依赖 CIM 的可选 `ExecutablePath` / `CommandLine` 字段，也不使用请求全访问权限的 `Process.Handle`。失败保留步骤和 Win32/NTSTATUS；只有实际 access denied 才建议核对运行权限，进程已退出则要求重新扫描。

### 扫描的耗时与端口取值

扫描（`GET /api/setup/probe`，实现见 `probe-local.js`）的调用次数固定，不随实例数增长：Windows 下**一次** `Get-Process`（经 `-EncodedCommand` 传入进程名，同时拿到 PID 与 EXE 路径）与**一次** `netstat -ano`（全量监听端口）并行执行，合计约 350 ms；不再用 `tasklist`（它只给 PID、本机实测约 1000 ms），也不再为每个 PID 各起一次 PowerShell。同一次扫描还会读取每个实例同目录的 `tshock/config.json` 与 `ServerPlugins`，因此列表里就能看到该实例的 REST 端口、是否已在监听、以及磁盘接收端版本是否与宿主配套。

PowerShell 或 netstat 没跑成时，接口返回 `error`（例如「无法枚举本机进程…」），不会把"命令失败"报成"没有这个进程"；命令跑成但没有匹配进程时才返回 `found: false`。

REST 端口的取值顺序是**实例自己的配置优先**：配置里读到 `RestApiPort` 就沿用它（已在监听则原样复用，完全不改配置）；只有该端口被别的进程占住、或配置读不到时，才退回到“从 7878 起的最小空闲端口”。这样已经开着 REST 的实例不会被平白改到另一个端口。

**已监听、但监听端口与配置不一致**（实例用 `-rest-port` 起服）时：适配器会报「现有 REST 已监听端口 X，无法在运行中切换到 Y」，后端读出 X 后**自动再注入一次**复用现有监听器，不再要求用户"把端口填成 X 再点一次"；这一次**不写配置**，并回一条 `note` 说明实际用的哪个端口、配置没有改动。同理，"没下发端口、直接复用运行端口"那条路上也不会把运行端口写回配置。

热接入的失败结论**不会滞留在内存缓存里**：`operations` 只挡并发重复提交，一旦落定就移除，因此用户腾出端口、换好接收端 DLL 之后用同一参数再点一次会真的重跑（此前 `retryable: false` 的失败会永久缓存，表现成"点了没反应、还是同一个错"）。

运行中的接收端与宿主配套版本不一致时，适配器会先卸载旧实例、再装载配套新版（回执带 `replaced: true` 与 `retiredReceivers`），接入直接完成、不要求重启；只有新版没起来（回执仍是别的 MVID，或替换过程报错）才返回 `receiverMismatch` / `ready: false`，向导据此给出“一键重启游戏服”或“我已重启，继续验证”，重启前不把它当成接入完成。程序集本身无法真正卸载，退役只到插件级：旧 Host 的 DLL 会留在进程内存里，但不再持有 REST、钩子或插件容器。详见 [一键接入接收端热替换与连接收敛](../../docs/一键接入接收端热替换与连接收敛-2026-10-31.md)。

发行包必须整体解压，`resources/TsWebHost.dll` 与 `resources/hotload/` 不可混搭。隔离真实验收使用 `node scripts/verify-local-hotload.mjs --allow-game-processes --tshock-dir ABS_PURE_TSHOCK --release-dir ABS_FULL_RELEASE --world ABS_TEST_WORLD`；附加 `--rest-conflict` 验证端口冲突不退出游戏。它只清理自己创建的进程，不操作已有 3000 面板或游戏服。

### 开发树与发行包的区别（重要）

`resources/TsWebHost.dll` 与 `resources/hotload/` 都是**发行构建产物，不入库**（见仓库根 `.gitignore`）。接收端的候选顺序是 `resources/` → `data/resources/` → `plugins/tsweb-host/bin/Release/net9.0/` → `plugins/tsweb-host/`，因此：

- 拿到发行包的用户：直接用包内 `resources/`，无需任何构建。
- 只有源码的开发树：必须先构建接收端，否则本机接入会报“TsWebHost.dll 未就绪”。

```powershell
dotnet build plugins/tsweb-host/TsWebHost.csproj -c Release -p:TsWebApiDir=<TShock API 目录>
node scripts/build-local-hotload.mjs --source plugins/init/hotload-src `
  --host-dll plugins/tsweb-host/bin/Release/net9.0/TsWebHost.dll --api-dir <TShock API 目录> --out resources/hotload
```

热接入组件的源码在 `plugins/init/hotload-src/`（`Bootstrap` / `Adapter` / `Injector` / `native/bootstrap.cpp`），发行构建按 `resources/hotload/manifest.json` 的 SHA-256 与接收端 MVID 成对校验，重编后必须整套一起更新。

## 明确需要时的一键重启

Windows 本机扫描模式仅在配置需要重启时提供“一键重启游戏服”按钮；插件初始化完成页也只在插件明确返回 `needsRestart` 时显示。无需重启时直接完成。只有用户点击后才重启；最后一步也可选择“稍后重启，完成”。手动接入与远程接入不显示本机重启按钮。

后端使用当前管理员账号绑定的短期凭据，重新核对所选 PID、启动时间、可执行文件、启动参数和原工作目录。选世界界面拒绝自动重启，不再强制结束进程。共享控制台或无法核验控制台成员时拒绝发送命令；独立控制台接收保存退出命令 `exit`，等待正常退出，再按原参数及原工作目录启动。无法读取原工作目录时拒绝准备重启，绝不使用 exe 所在目录代替；当前读取仅支持 Windows x64，系统内部结构不可读取时回退原启动器。保存等待超时不会强制结束进程。同一进程身份的不同扫描凭据、不同管理员共享一次操作，成功与失败都在凭据有效期内复用；后继凭据仍分别绑定各自账号。连接向导重启后继续接收端与 Base 就绪验证；最终完成页只确认进程已重新启动。

安静验证（仅读取 Node 测试进程及编译辅助类型，不操作游戏进程）：`node --test plugins/init/test/local-restart*.test.mjs`。原生窗口回归默认拒绝运行，需显式 `node scripts/verify-local-restart.mjs --allow-game-processes`；它会启动隔离控制台窗口，不应在日常测试或构建中自动调用。本轮未运行。首次运行中加载 Host 的可行性与边界见 [运行中加载评估](../../docs/运行中加载TsWebHost与重启安全修复-2026-10-26.md)。

## 验证命令

`node --test --test-concurrency=1 plugins/init/test/flow.test.mjs plugins/init/test/ui.test.mjs plugins/init/test/providers.test.mjs client/test/plugin-manager.test.mjs plugins/base/test/ssc-settings.test.mjs plugins/base/test/host-routes.test.mjs`

真实游戏端隔离测试：`node scripts/verify-preworld-deployment.mjs ABS_TSHOCK_DIR ABS_BASE_DLL --early-base --receiver ABS_RECEIVER_DLL --verify-ssc`。测试在独立目录和端口运行，不更改现有游戏服配置。
