// Share the persistent SSE connection and synchronizer. A separate probe would
// replace the receiver session and interrupt an in-flight DLL deployment.
const operations = new Map()
export function serialize(key, operation) {
  const previous = operations.get(key) || Promise.resolve()
  const pending = previous.catch(() => {}).then(operation)
  operations.set(key, pending)
  return pending.finally(() => { if (operations.get(key) === pending) operations.delete(key) })
}

export async function verifySetup(ctx, input, expected, { timeout = 7000, interval = 200 } = {}) {
  const host = String(input.host).trim(), port = Number(input.port), token = String(input.apiKey).trim()
  if (!host || !token || !Number.isInteger(port) || port < 1 || port > 65535)
    return { success: false, error: '主机、密钥或端口无效' }
  const key = `setup:${host.toLowerCase()}:${port}`
  // Serialize only registration, not the readiness wait. Concurrent retries
  // reuse one record while the connection and deployment proceed independently.
  const server = await serialize(key, async () => {
    const listed = await ctx.servers.list()
    const existing = listed.find(s => String(s.host).toLowerCase() === host.toLowerCase() && Number(s.port) === port)
    if (existing) {
      const raw = ctx.servers.getRaw(existing.id)
      if (raw.token !== token || raw.enabled === false) {
        const result = await ctx.tshock.testConnectionWith(host, port, token)
        if (!result.success) throw new Error(result.error || 'REST 验证失败')
        return ctx.servers.update(existing.id, { token, enabled: true })
      }
      return existing
    }
    const result = await ctx.tshock.testConnectionWith(host, port, token)
    if (!result.success) throw new Error(result.error || 'REST 验证失败')
    return ctx.servers.add({ name: String(input.name || '').trim() || `${host}:${port}`, host, port, token, note: input.note })
  })
  let error = '等待配套 TsWebHost 接收端上线；本机热接入成功后无需重启，若持续等待请检查热接入状态与游戏日志'
  const deadline = Date.now() + timeout
  do {
    const inst = ctx.tshock.getServerInstance(server.id)
    const receiver = inst?.receiverIdentity
    if (inst?.receiverSession && receiver) {
      if (receiver.moduleId !== expected.moduleId)
        return { success: false, pending: true, serverId: server.id, error: '运行中的 TsWebHost 与宿主配套 DLL 不一致：请重新走一次一键接入（会卸载旧版接收端并装载配套新版）；替换失败时再重启一次 TShock' }
      if (receiver.instances !== 1)
        return { success: false, pending: true, serverId: server.id, error: '检测到多个运行中的 TsWebHost，请清理旧副本；一键接入会退役旧实例，仍报多个时重启一次 TShock' }
      const base = ctx.plugins.get('base'), sync = base?.sync?.[server.id]
      const report = ctx.plugins.sync?.reports?.get(server.id)
      if (base?.enabled && sync?.phase === 'synced' && sync.desiredHash &&
          sync.runningHash === sync.desiredHash && sync.installedHash === sync.desiredHash &&
          report?.sessionId === inst.receiverSession && report.plugins.get('base')?.runningHash === sync.desiredHash &&
          report.plugins.get('base')?.installedHash === sync.desiredHash)
        return { success: true, serverId: server.id, name: server.name, ready: true }
      const installed = report?.sessionId === inst.receiverSession && report.plugins.get('base')
      if (base?.enabled && sync?.phase === 'staged' && sync.desiredHash && !sync.runningHash &&
          sync.installedHash === sync.desiredHash && installed?.installedHash === sync.desiredHash &&
          !installed.runningHash && installed.activation === 'waiting-for-world')
        return { success: true, serverId: server.id, name: server.name, ready: false, deployed: true,
          activation: 'waiting-for-world', message: '基础插件已下发并校验，世界启动后自动启用，无需再次重启' }
      const status = inst.cache?.status
      if (status && typeof status.world === 'string' && !status.world.trim()) {
        error = '接收端已连接，等待基础插件部署回执；世界未启动不应阻止插件下发。若持续等待，请更新支持启动前部署的配套 TsWebHost 接收端'
      } else if (!base?.enabled) {
        error = '基础插件 base 未启用，请先启用基础插件'
      } else if (!report || report.sessionId !== inst.receiverSession) {
        error = '接收端已连接，等待游戏服返回插件清单；若长时间无响应，请检查 TShock 是否已启动世界、游戏线程是否正常运行'
      } else {
        error = `接收端已连接，正在热加载基础插件 base${sync?.error ? `：${sync.error}` : ''}；无需为基础插件再次重启 TShock`
      }
      ctx.plugins.sync?.poke()
    } else if (inst?.receiverSession) {
      error = '当前 TsWebHost 未提供运行版本标识，请重新走一次一键接入升级接收端；仍无版本标识时再重启一次 TShock'
    } else if (inst?.deploymentError || inst?.lastError) {
      error = `${inst.deploymentError || inst.lastError}。尚未完成接收端与基础插件验证`
    }
    if (Date.now() >= deadline) break
    await new Promise(resolve => setTimeout(resolve, interval))
  } while (true)
  return { success: false, pending: true, serverId: server.id, error }
}
