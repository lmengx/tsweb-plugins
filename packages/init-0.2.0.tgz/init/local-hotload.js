import crypto from 'node:crypto'
import fs from 'node:fs/promises'
import path from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { fileURLToPath } from 'node:url'
import { inspectLocalProcess } from './local-restart.js'
import { assemblyIdentity, prepareReceiverFiles } from './receiver-files.js'

const exec = promisify(execFile)
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..')
const sha = data => crypto.createHash('sha256').update(data).digest('hex')
const same = (a, b) => path.win32.resolve(a).toLowerCase() === path.win32.resolve(b).toLowerCase()
const error = message => Object.assign(new Error(message), { status: 409 })

function readableActivationMessage(message, restPort) {
  const text = String(message || '')
  if (/套接字地址|socket|address already in use|10048|仅允许使用一次/i.test(text)) {
    return `REST 端口 ${restPort} 已被其他进程占用，无法热接入。请修改所选 TShock 实例的 RestApiPort，或停止占用该端口的其他 REST 服务后重新扫描。游戏服未重启，配置未作为运行成功处理。`
  }
  // 实例用命令行 -rest-port 起服时，运行中的 REST 端口可能不等于配置文件里的值。
  // 这种情况下应当"复用正在监听的那个端口"，而不是改配置去凑——正常路径已在
  // perform() 里自动重试过一次（见 autoReuse），这里只兜底提示。
  const listening = /现有 REST 已监听端口\s*(\d+)/i.exec(text)
  if (listening) {
    return `该实例运行中的 REST 已在监听端口 ${listening[1]}（多半来自启动参数 -rest-port）。热接入会复用这个端口、不改动配置：请把端口填成 ${listening[1]} 后重试；若要换端口，请重启游戏服后再扫描。`
  }
  // 运行中的旧接收端可能没有适配器期望的字段，会以"Host 未接入 listener"之类失败；
  // 这类失败的真实含义仍是"已加载的接收端不是配套版本"，要给出可执行的下一步。
  // 运行中的旧接收端与宿主配套版本不一致时，适配器会先卸载旧实例再装载新版；
  // 只有新版真的没起来（或回执仍是旧 MVID）才要求重启一次。
  if (/Host 未接入当前 TShock REST listener|Host 实例数校验失败|Host 类型身份不匹配|现有 Host 尚未完成初始化|检测到多个 Host 实例/i.test(text)) {
    return `${text}。一键接入会先卸载运行中的旧版接收端、再装载宿主配套新版；若这里仍报同类错误，说明替换未完成，请重启一次 TShock 后重新接入。`
  }
  return text
}

export function localConfigPath(snapshot) {
  const argument = /(?:^|\s)-configpath\s+(?:"([^"]+)"|([^\s"]+))/i.exec(snapshot.commandLine || '')
  if (!snapshot.workingDirectory || !path.win32.isAbsolute(snapshot.workingDirectory)) throw error('无法核验原工作目录，未执行热接入')
  return path.win32.resolve(snapshot.workingDirectory, argument ? argument[1] || argument[2] : 'tshock', 'config.json')
}

async function executeHelper(bundle, file) {
  try {
    const { stdout } = await exec(path.join(bundle, 'TsWeb.LocalHotload.Injector.exe'), [file], { windowsHide: true, timeout: 45000, maxBuffer: 1024 * 1024 })
    return JSON.parse(stdout.trim())
  } catch {
    // Only the helper can time out; never stop/restart the game, or retry an
    // operation whose target-side outcome is not yet known.
    return { success: false, phase: 'helper-unavailable', retryable: false,
      message: '热接入工具未返回有效结果；请确认 Windows x64/.NET 9、运行账户权限及组件完整性。未重启游戏服，也不会自动重试' }
  }
}

export function createLocalHotload({ platform = process.platform, inspect = inspectLocalProcess, run = executeHelper,
  bundle = process.env.TSWEB_HOTLOAD_DIR || path.join(root, 'resources/hotload'),
  dataDir = process.env.TSWEB_DATA_DIR || path.join(root, 'data'), io = fs, persistReceiver = prepareReceiverFiles } = {}) {
  const operations = new Map()
  async function configure(input, receiver) {
    if (platform !== 'win32') throw error('当前首次热接入仅支持 Windows x64；未重启游戏服')
    if (!Number.isSafeInteger(input.pid) || input.pid <= 0) throw error('请重新扫描并选择具体的 TShock 进程')
    const snapshot = await inspect(input.pid)
    if (snapshot.pid !== input.pid || !same(snapshot.executablePath, input.processPath)
        || !/^TShock\.Server\.exe$/i.test(path.win32.basename(snapshot.executablePath)) || !/^\d+$/.test(snapshot.startedAt || ''))
      throw error('进程路径或启动身份不一致，请重新扫描；未执行热接入')
    // 端口只在"该实例确实已在监听它"（向导确认过）或用户明确指定时才下发；
    // 仅从 <exeDir>/tshock/config.json 试探到的值不下发——那个文件可能来自
    // -configpath 或另一个工作目录，把它写进权威配置等于凭空改端口。
    const requestedPort = input.restPort === undefined || input.restPort === ''
      || input.restPortConfirmed === false ? null : Number(input.restPort)
    const key = JSON.stringify([snapshot.pid, snapshot.startedAt, path.win32.resolve(snapshot.executablePath).toLowerCase(), requestedPort])
    if (!operations.has(key)) {
      const pending = perform(snapshot, receiver, requestedPort ?? undefined).catch(cause => ({ success: false, warning: cause.message, error: cause.message,
        needsRestart: false, hotload: { success: false, phase: 'preflight-failed', message: cause.message, retryable: false } }))
      operations.set(key, pending)
      /**
       * 只在**进行中**去重：一旦落定就移除这条。
       *
       * 原来只在 retryable 为真时移除，于是"端口不一致 / 端口被占用 / 接收端不配套"
       * 这类 retryable=false 的失败会永久留在表里——用户照着提示改好环境（腾出端口、
       * 换掉接收端 DLL）后用**同一个端口**再点一次，拿到的是缓存里的旧结论，
       * 表现就是"点了没反应、还是同一个错"。去重的目的只是挡住并发重复提交，
       * 不该顺带否掉用户的下一次主动重试。
       */
      pending.then(() => {}, () => {}).finally(() => {
        if (operations.get(key) === pending) operations.delete(key)
      })
    }
    return operations.get(key)
  }

  /**
   * 真正执行一次热接入。
   *
   * `options.writePort === false`：**只把端口用于本次注入请求，不写进 tshock/config.json**。
   * 用在"自动复用运行中监听端口"那条路上——运行中的端口来自启动参数 -rest-port 时，
   * 把它固化进配置属于替用户改端口，不是他要求的。
   */
  async function perform(snapshot, receiver, requestedRestPort, options = {}) {
    const writePort = options.writePort !== false
    if (!receiver?.source) throw error('未找到配套 Host，请修复发行包 resources/TsWebHost.dll')
    const host = await io.readFile(receiver.source), identity = assemblyIdentity(host), hostSha256 = sha(host)
    const manifest = JSON.parse(await io.readFile(path.join(bundle, 'manifest.json'), 'utf8'))
    if (manifest.schema !== 1 || manifest.platform !== 'win32' || manifest.arch !== 'x64'
        || identity?.name !== 'TsWebHost' || manifest.receiver?.sha256 !== hostSha256 || manifest.receiver?.moduleId !== identity.moduleId)
      throw error('Host 与热接入组件不配套，请使用完整的新发行包；未执行注入')
    for (const file of ['TsWeb.LocalHotload.Injector.exe', 'TsWeb.LocalHotload.Injector.dll', 'TsWeb.LocalHotload.Injector.runtimeconfig.json', 'TsWeb.LocalHotload.Native.dll', 'TsWeb.LocalHotload.Bootstrap.dll', 'TsWeb.LocalHotload.Adapter.dll']) {
      if (!manifest.files?.[file]) throw error('热接入发行组件缺失：' + file)
    }
    for (const [file, hash] of Object.entries(manifest.files || {})) {
      if (path.basename(file) !== file || sha(await io.readFile(path.join(bundle, file))) !== hash) throw error('热接入组件校验失败：' + file)
    }
    const configPath = localConfigPath(snapshot)
    const original = await io.readFile(configPath, 'utf8'), config = JSON.parse(original), settings = config.Settings || config
    if (!Number.isInteger(settings.RestApiPort) || settings.RestApiPort < 1 || settings.RestApiPort > 65535) throw error('RestApiPort 无效')
    if (requestedRestPort !== undefined && (!Number.isInteger(Number(requestedRestPort)) || Number(requestedRestPort) < 1 || Number(requestedRestPort) > 65535)) throw error('REST 端口需为 1-65535 的整数')
    let tokenKey = Object.entries(settings.ApplicationRestTokens || {}).find(([, v]) => v.Username === 'TSWeb' && v.UserGroupName === 'superadmin')?.[0]
    const reused = !!tokenKey
    tokenKey ||= crypto.randomBytes(32).toString('hex')
    settings.RestApiEnabled = true
    // 端口只在"用户/向导确认过要这个端口"时才落进配置；自动复用的那次注入不写。
    if (requestedRestPort !== undefined && writePort) settings.RestApiPort = Number(requestedRestPort)
    settings.ApplicationRestTokens ||= {}
    settings.ApplicationRestTokens[tokenKey] = { Username: 'TSWeb', UserGroupName: 'superadmin' }
    const changed = JSON.stringify(JSON.parse(original)) !== JSON.stringify(config)
    const directory = path.join(dataDir, 'init/hotload', crypto.randomUUID())
    await io.mkdir(directory, { recursive: true })
    // Preserve a private original before persisting startup configuration. It is
    // not a claim that the running process has adopted this configuration.
    await io.writeFile(path.join(directory, 'config.before.json'), original, { mode: 0o600, flag: 'wx' })
    if (await io.readFile(configPath, 'utf8') !== original) throw error('配置已被其他程序修改，未执行注入；请重新扫描')
    let written = original
    if (changed) {
      written = JSON.stringify(config, null, 2)
      await io.writeFile(configPath, written, 'utf8')
    }
    const requestFile = path.join(directory, 'request.private.json')
    const request = { operationId: crypto.randomUUID(), pid: snapshot.pid, startedAt: snapshot.startedAt,
      executablePath: snapshot.executablePath, configPath, hostPath: path.resolve(receiver.source), restPort: requestedRestPort === undefined ? undefined : Number(requestedRestPort),
      hostModuleId: identity.moduleId, hostSha256, bundleDirectory: path.resolve(bundle),
      receiptPath: path.join(directory, 'activation.json'), token: tokenKey }
    await io.writeFile(requestFile, JSON.stringify(request), { mode: 0o600, flag: 'wx' })
    let hotload = await run(bundle, requestFile)
    await io.writeFile(path.join(directory, 'result.json'), JSON.stringify(hotload, null, 2))
    await io.rm(requestFile, { force: true }) // Do not retain a second plaintext token copy.
    // 原始文案要在改写成人话之前留一份：自动复用要从中读"现有 REST 已监听端口 X"，
    // 改写后的中文里已经没有这句原文了。
    const rawMessage = String(hotload.message || '')
    const actualMessage = hotload.success ? null : readableActivationMessage(hotload.message, hotload.restPort || settings.RestApiPort)
    if (actualMessage) {
      hotload = { ...hotload, message: actualMessage }
    }
    // 运行中的接收端是否就是宿主配套的那一份。一键接入会先卸载旧实例、再装载配套新版；
    // 只有新版真的没起来（回执仍是别的 MVID）才要求重启一次。
    const runningModuleId = typeof hotload.receiverModuleId === 'string' ? hotload.receiverModuleId.toLowerCase() : null
    const receiverMismatch = hotload.success === true && !!runningModuleId && runningModuleId !== identity.moduleId.toLowerCase()
    const replaced = hotload.success === true && hotload.replaced === true
    const retiredReceivers = Array.isArray(hotload.retiredReceivers)
      ? hotload.retiredReceivers.filter(id => typeof id === 'string') : []
    const pluginDir = hotload.pluginDirectory && path.win32.isAbsolute(hotload.pluginDirectory)
      ? hotload.pluginDirectory : path.win32.join(path.win32.dirname(snapshot.executablePath), 'ServerPlugins')
    const mismatchMessage = receiverMismatch
      ? `运行中的接收端与宿主配套版本不一致（已加载 ${runningModuleId}，宿主配套 ${identity.moduleId}）。已把配套 DLL 写入 ${pluginDir}；替换未完成，请重启一次 TShock 后重新接入。`
      : null
    const replaceNote = replaced
      ? `已卸载运行中的旧版接收端${retiredReceivers.length ? `（${retiredReceivers.join('、')}）` : ''}并装载宿主配套新版 ${identity.moduleId}，游戏服未重启。`
      : null
    // success 表示"本次请求已完成且没有出错"；能否真正接入另用 ready 表达
    // （与 auto-verify 的 ready/deployed 同一套语义：文件已就位、待重启不算失败）。
    const result = { success: hotload.success === true, ready: hotload.success === true && !receiverMismatch,
      restPort: hotload.restPort || settings.RestApiPort,
      connectHost: hotload.connectHost || '127.0.0.1', tokenKey, configPath, reused, configChanged: changed,
      needsRestart: receiverMismatch, receiverMismatch, replaced, retiredReceivers, replaceNote,
      runsReceiverModuleId: runningModuleId,
      restart: receiverMismatch
        ? { available: false, reason: '运行中的接收端版本与宿主不配套，需重启游戏服后才能加载配套 DLL' }
        : { available: false, reason: '本次接入使用热注入，不自动重启游戏服' },
      hotload, diagnosticsPath: directory,
      warning: receiverMismatch ? mismatchMessage : hotload.success ? null : hotload.message,
      error: receiverMismatch ? undefined : hotload.success ? undefined : hotload.message }
    if (!hotload.success) {
      // Keep staged credentials for a retryable pre-world wait; roll back a
      // failed listener bind so a rejected port never remains configured.
      if (!hotload.retryable && changed && await io.readFile(configPath, 'utf8') === written) await io.writeFile(configPath, original, 'utf8')
      /**
       * 已监听其它端口 → 自动复用，不再让用户"填回端口再点一次"。
       *
       * 适配器只在"显式给了端口、且运行中监听器在别的端口"时才抛这句错误
       * （Activation.cs ConfigureRest：现有 REST 已监听端口 X，无法在运行中切换到 Y）。
       * 现有端口就在错误消息里，直接拿它再注入一次即可——而且这次**不写配置**：
       * 那个端口来自启动参数 -rest-port 或者别处的临时改动，不该被固化。
       */
      const liveMatch = /现有 REST 已监听端口\s*(\d+)/i.exec(rawMessage)
      const livePort = liveMatch ? Number(liveMatch[1]) : null
      if (options.autoReusedFrom === undefined && livePort && requestedRestPort !== undefined
          && livePort !== Number(requestedRestPort) && livePort >= 1 && livePort <= 65535) {
        const retried = await perform(snapshot, receiver, livePort, { writePort: false, autoReusedFrom: Number(requestedRestPort) })
        if (retried.success) {
          retried.autoReusedPort = livePort
          retried.note = `该实例运行中的 REST 监听在 ${livePort}，配置里写的是 ${Number(requestedRestPort)}（多半来自启动参数 -rest-port）。`
            + `已按 ${livePort} 复用现有监听器接入，未改动配置文件。注意：下次不带 -rest-port 重启游戏服后它会回到 ${Number(requestedRestPort)}，`
            + `届时需要重新扫描接入；想长期固定在 ${livePort}，请把 config.json 的 Settings.RestApiPort 改成 ${livePort} 再重启。`
        }
        return retried
      }
      return result
    }
    // 端口回写：**只**在"用户明确要求了某个端口"（显式下发且允许写入）时才把运行口径写进配置。
    // 复用运行中监听端口那条路上，运行端口可能来自 -rest-port，固化它等于替用户改端口，
    // 所以只回报给调用方用于连接，配置保持原样并给出说明。
    const explicitPortWrite = writePort && requestedRestPort !== undefined
    if (hotload.restPort && hotload.restPort !== settings.RestApiPort) {
      if (!explicitPortWrite) {
        result.restPortDiffersFromConfig = true
        result.note = `运行中的 REST 监听在 ${hotload.restPort}，配置里的 RestApiPort 是 ${settings.RestApiPort}（多半来自启动参数 -rest-port）。本次按运行端口接入，未改动配置。`
      } else {
        if (await io.readFile(configPath, 'utf8') !== written) return { ...result, success: false, warning: 'Host 已热接入，但配置在过程中发生变化，未覆盖端口；请检查配置后重试' }
        settings.RestApiPort = hotload.restPort
        await io.writeFile(configPath, JSON.stringify(config, null, 2), 'utf8')
      }
    }
    // 版本不一致时同样要落盘：下一次启动加载的才是配套接收端。
    try { result.copyNote = await persistReceiver(pluginDir, receiver.source) }
    catch (cause) {
      result.success = false
      result.warning = (mismatchMessage ? mismatchMessage + ' ' : '') + '下次启动所需 DLL 未能持久化：' + cause.message
      result.copyNote = { status: 'failed', note: cause.message }
    }
    return result
  }
  return { configure }
}
