// Module permissions authorize both UI features and their backend routes.
export default {
  "owner": "anti-cheat",
  "version": 2,
  "modules": [
    {
      "id": "anti-cheat.items",
      "permission": "anti-cheat.ui.items",
      "title": "反作弊配置",
      "roles": [
        "superadmin",
        "admin",
        "subadmin"
      ],
      "scope": "server",
      "requires": [
        "anti-cheat.post.anticheat.enable",
        "anti-cheat.post.anticheat.apply.defaults",
        "anti-cheat.post.anticheat.reset.defaults",
        "anti-cheat.get.anticheat.config",
        "anti-cheat.get.anticheat.proj.config",
        "anti-cheat.post.anticheat.proj.config",
        "anti-cheat.get.anticheat.item.config",
        "anti-cheat.post.anticheat.item.config",
        "anti-cheat.get.anticheat.item.abuse",
        "anti-cheat.post.anticheat.item.abuse.set",
        "anti-cheat.get.anticheat.bugfix",
        "anti-cheat.post.anticheat.bugfix.set",
        "anti-cheat.post.anticheat.check.anomaly",
        "anti-cheat.post.tshock.itemscan",
        "anti-cheat.post.tshock.itemscan.by.id",
        "anti-cheat.get.anticheat.presets",
        "anti-cheat.post.anticheat.presets.create",
        "anti-cheat.post.anticheat.presets.apply"
      ]
    },
    {
      "id": "anti-cheat.logs",
      "permission": "anti-cheat.ui.logs",
      "title": "反作弊日志",
      "roles": [
        "superadmin",
        "admin",
        "subadmin"
      ],
      "scope": "server",
      "requires": [
        "anti-cheat.get.anticheat.logs",
        "anti-cheat.get.anticheat.logs.stats"
      ]
    }
  ],
  "actions": [
    {
      "id": "anti-cheat.post.anticheat.enable",
      "method": "POST",
      "path": "/api/anticheat/enable",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.post.anticheat.apply.defaults",
      "method": "POST",
      "path": "/api/anticheat/apply-defaults",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.post.anticheat.reset.defaults",
      "method": "POST",
      "path": "/api/anticheat/reset-defaults",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.get.anticheat.config",
      "method": "GET",
      "path": "/api/anticheat/config",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.get.anticheat.proj.config",
      "method": "GET",
      "path": "/api/anticheat/proj-config",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.post.anticheat.proj.config",
      "method": "POST",
      "path": "/api/anticheat/proj-config",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.get.anticheat.item.config",
      "method": "GET",
      "path": "/api/anticheat/item-config",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.post.anticheat.item.config",
      "method": "POST",
      "path": "/api/anticheat/item-config",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.get.anticheat.item.abuse",
      "method": "GET",
      "path": "/api/anticheat/item-abuse",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.post.anticheat.item.abuse.set",
      "method": "POST",
      "path": "/api/anticheat/item-abuse/set",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.get.anticheat.bugfix",
      "method": "GET",
      "path": "/api/anticheat/bugfix",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.post.anticheat.bugfix.set",
      "method": "POST",
      "path": "/api/anticheat/bugfix/set",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.post.anticheat.check.anomaly",
      "method": "POST",
      "path": "/api/anticheat/check-anomaly",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.get.anticheat.logs",
      "method": "GET",
      "path": "/api/anticheat/logs",
      "scope": "server",
      "module": "anti-cheat.logs"
    },
    {
      "id": "anti-cheat.get.anticheat.logs.stats",
      "method": "GET",
      "path": "/api/anticheat/logs/stats",
      "scope": "server",
      "module": "anti-cheat.logs"
    },
    {
      "id": "anti-cheat.post.tshock.itemscan",
      "method": "POST",
      "path": "/api/tshock/itemscan",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.post.tshock.itemscan.by.id",
      "method": "POST",
      "path": "/api/tshock/itemscan-by-id",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.get.anticheat.presets",
      "method": "GET",
      "path": "/api/anticheat/presets",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.post.anticheat.presets.create",
      "method": "POST",
      "path": "/api/anticheat/presets/create",
      "scope": "server",
      "module": "anti-cheat.items"
    },
    {
      "id": "anti-cheat.post.anticheat.presets.apply",
      "method": "POST",
      "path": "/api/anticheat/presets/apply",
      "scope": "server",
      "module": "anti-cheat.items"
    }
  ],
  "features": [
    {
      "id": "anti-cheat:items",
      "module": "anti-cheat.items",
      "requires": [
        "anti-cheat.post.anticheat.enable",
        "anti-cheat.post.anticheat.apply.defaults",
        "anti-cheat.post.anticheat.reset.defaults",
        "anti-cheat.get.anticheat.config",
        "anti-cheat.get.anticheat.proj.config",
        "anti-cheat.post.anticheat.proj.config",
        "anti-cheat.get.anticheat.item.config",
        "anti-cheat.post.anticheat.item.config",
        "anti-cheat.get.anticheat.item.abuse",
        "anti-cheat.post.anticheat.item.abuse.set",
        "anti-cheat.get.anticheat.bugfix",
        "anti-cheat.post.anticheat.bugfix.set",
        "anti-cheat.post.anticheat.check.anomaly",
        "anti-cheat.post.tshock.itemscan",
        "anti-cheat.post.tshock.itemscan.by.id",
        "anti-cheat.get.anticheat.presets",
        "anti-cheat.post.anticheat.presets.create",
        "anti-cheat.post.anticheat.presets.apply"
      ]
    },
    {
      "id": "anti-cheat:projectiles",
      "module": "anti-cheat.items",
      "requires": [
        "anti-cheat.post.anticheat.enable",
        "anti-cheat.post.anticheat.apply.defaults",
        "anti-cheat.post.anticheat.reset.defaults",
        "anti-cheat.get.anticheat.config",
        "anti-cheat.get.anticheat.proj.config",
        "anti-cheat.post.anticheat.proj.config",
        "anti-cheat.get.anticheat.item.config",
        "anti-cheat.post.anticheat.item.config",
        "anti-cheat.get.anticheat.item.abuse",
        "anti-cheat.post.anticheat.item.abuse.set",
        "anti-cheat.get.anticheat.bugfix",
        "anti-cheat.post.anticheat.bugfix.set",
        "anti-cheat.post.anticheat.check.anomaly",
        "anti-cheat.post.tshock.itemscan",
        "anti-cheat.post.tshock.itemscan.by.id",
        "anti-cheat.get.anticheat.presets",
        "anti-cheat.post.anticheat.presets.create",
        "anti-cheat.post.anticheat.presets.apply"
      ]
    },
    {
      "id": "anti-cheat:bugfix",
      "module": "anti-cheat.items",
      "requires": [
        "anti-cheat.post.anticheat.enable",
        "anti-cheat.post.anticheat.apply.defaults",
        "anti-cheat.post.anticheat.reset.defaults",
        "anti-cheat.get.anticheat.config",
        "anti-cheat.get.anticheat.proj.config",
        "anti-cheat.post.anticheat.proj.config",
        "anti-cheat.get.anticheat.item.config",
        "anti-cheat.post.anticheat.item.config",
        "anti-cheat.get.anticheat.item.abuse",
        "anti-cheat.post.anticheat.item.abuse.set",
        "anti-cheat.get.anticheat.bugfix",
        "anti-cheat.post.anticheat.bugfix.set",
        "anti-cheat.post.anticheat.check.anomaly",
        "anti-cheat.post.tshock.itemscan",
        "anti-cheat.post.tshock.itemscan.by.id"
      ]
    },
    {
      "id": "anti-cheat:logs",
      "module": "anti-cheat.logs",
      "requires": [
        "anti-cheat.get.anticheat.logs",
        "anti-cheat.get.anticheat.logs.stats"
      ]
    }
  ]
}
