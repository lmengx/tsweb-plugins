import { mkdir, readFile, writeFile, rename, rm } from 'node:fs/promises'
import { randomUUID, createHash } from 'node:crypto'
import path from 'node:path'

const fail = (status, message) => Object.assign(new Error(message), { status })
export function presetConfig(kind, input) {
  if (!['item', 'proj'].includes(kind)) throw fail(400, '无效的预设类型')
  if (!input || typeof input !== 'object' || Array.isArray(input) || typeof input.启用 !== 'boolean' || !Array.isArray(input.限制列表))
    throw fail(400, '预设配置格式无效')
  const field = kind === 'item' ? '限制物品' : '限制弹幕'
  const result = { 启用: input.启用, 限制列表: input.限制列表.map(group => {
    if (!group || typeof group.进度 !== 'string' || !group.进度.trim() || !Array.isArray(group[field])) throw fail(400, '进度规则格式无效')
    return { 进度: group.进度, [field]: group[field].map(rule => {
      if (!rule || !Number.isInteger(rule.id) || rule.id < 1 || typeof rule.method !== 'string' || !rule.method.trim() || rule.method === 'command')
        throw fail(400, '规则 ID 或处理命令无效')
      if (kind === 'item' && (!Number.isInteger(rule.stack) || rule.stack < 1)) throw fail(400, '物品数量必须为正整数')
      return { id: rule.id, ...(kind === 'item' ? { stack: rule.stack } : {}), method: rule.method }
    }) }
  }) }
  if (kind === 'item') {
    for (const key of ['自动扫描', '实时审查手持物品', '没收违禁物品']) {
      if (typeof input[key] !== 'boolean') throw fail(400, '物品检测开关须为布尔值')
      result[key] = input[key]
    }
    if (!Number.isInteger(input.扫描间隔) || input.扫描间隔 < 1 || input.扫描间隔 > 3600) throw fail(400, '扫描间隔须为 1–3600 秒的整数')
    result.扫描间隔 = input.扫描间隔
  }
  // 弹幕预设只管理启用状态与规则，不接管杂项页的伤害上限等配置。
  return result
}

export class AntiCheatPresets {
  constructor(dir) { this.dir = dir; this.tail = Promise.resolve() }
  serial(work) {
    const job = this.tail.then(work)
    this.tail = job.catch(() => {})
    return job
  }
  file(serverId, kind) {
    if (!serverId || !['item', 'proj'].includes(kind)) throw fail(400, '无效的服务器或预设类型')
    const key = createHash('sha256').update(String(serverId)).digest('hex')
    return path.join(this.dir, key, `${kind}.json`)
  }
  async read(serverId, kind) {
    try {
      const state = JSON.parse(await readFile(this.file(serverId, kind), 'utf8'))
      if (state.version !== 1 || !Array.isArray(state.presets) || typeof state.selectedId !== 'string' ||
          state.presets.some(p => !p.id || !p.name || !Number.isInteger(p.revision)) ||
          (state.selectedId && !state.presets.some(p => p.id === state.selectedId))) throw new Error('预设库格式损坏')
      for (const preset of state.presets) presetConfig(kind, preset.config)
      return state
    } catch (error) {
      if (error.code === 'ENOENT') return { version: 1, selectedId: '', presets: [] }
      throw error
    }
  }
  async write(serverId, kind, state) {
    const file = this.file(serverId, kind), temporary = `${file}.${randomUUID()}.tmp`
    await mkdir(path.dirname(file), { recursive: true })
    try {
      await writeFile(temporary, JSON.stringify(state, null, 2) + '\n', { flag: 'wx' })
      await rename(temporary, file)
    } finally { await rm(temporary, { force: true }).catch(() => {}) }
  }
  create(serverId, kind, { name, source, sourceId, config }, defaults) {
    return this.serial(async () => {
      const state = await this.read(serverId, kind)
      if (typeof name !== 'string' || !name.trim() || name.trim().length > 60) throw fail(400, '名称须为 1–60 个字符')
      if (state.presets.some(p => p.name === name.trim())) throw fail(409, '该名称已存在，请更换名称')
      if (state.presets.length >= 100) throw fail(400, '每类最多创建 100 个预设')
      let value
      if (source === 'default') value = { 没收违禁物品: false, ...defaults(kind) }
      else if (source === 'blank') value = { 没收违禁物品: false, ...defaults(kind), 启用: false, 限制列表: [] }
      else if (source === 'copy') {
        const original = state.presets.find(p => p.id === sourceId)
        if (sourceId && !original) throw fail(404, '要复制的预设不存在')
        // config 允许复制界面中的未保存草稿。
        value = config ?? original?.config
      } else throw fail(400, '无效的新建方式')
      const preset = { id: randomUUID(), name: name.trim(), revision: 1, config: presetConfig(kind, value) }
      state.presets.push(preset)
      await this.write(serverId, kind, state)
      return { ...state, createdId: preset.id }
    })
  }
  apply(serverId, kind, { id, revision, config }, publish) {
    return this.serial(async () => {
      const state = await this.read(serverId, kind)
      const value = presetConfig(kind, config)
      if (id === '') {
        await publish(value)
        state.selectedId = ''
        await this.write(serverId, kind, state)
        return state
      }
      const preset = state.presets.find(p => p.id === id)
      if (!preset) throw fail(404, '预设不存在，请重新加载')
      if (revision !== preset.revision) throw fail(409, '该预设已被其他窗口修改，请重新加载后重试')
      // 先保存预设，游戏服不可用时仍保留配置；只有下发成功才修改应用标记。
      preset.config = value
      preset.revision++
      await this.write(serverId, kind, state)
      try { await publish(value) }
      catch (error) {
        error.message = `预设已保存，但应用到游戏服失败：${error.message}`
        error.presetState = state
        throw error
      }
      state.selectedId = preset.id
      try { await this.write(serverId, kind, state) }
      catch (error) { throw fail(500, `游戏服已应用，但应用标记保存失败，请刷新核对：${error.message}`) }
      return state
    })
  }
}
