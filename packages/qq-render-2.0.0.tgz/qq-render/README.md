# 通用图片渲染引擎（2.0.0）

仅提供通用模板注册、SVG/PNG 转换、并发和资源控制。任意 Cordis 插件均可通过可选服务 `qqRenderer` 注册自己的模板，无需修改引擎。依赖宿主 `paths` 与 `sharp`，不再依赖 QQ 服务、服务器清单或 TShock。

QQ 主页、账号、服务器和玩家模板及三套风格移至 `qq-serve/render-templates`；投票卡片位于 `vote/render.js`。引擎中不含业务查询、固定消息种类或配色方案。

配置仍在 `data/qq-render/config.json`，文件位置和格式不变，没有旧目录扫描或自动迁移。接入插件在关闭图片、引擎缺失或生成失败时回退文字。停用或更新插件时注销模板，渲染器重新启用后按 Cordis 可选依赖自动注册。

开发接口、示例和限制见 [API.md](./API.md)。首次切换需要一起更新 qq-render 2.0.0、qq-serve 2.4.0、vote 2.1.0；后续模板改动通常只更新所属业务插件。引擎本身可以独立安装。

验证：`node --test plugins/qq-render/test/*.test.mjs plugins/qq-serve/test/render-templates.test.mjs plugins/qq-serve/onebot/test/*.test.mjs plugins/vote/test/render.test.mjs`。本地模拟 OneBot，不向真实 QQ 发送消息。
