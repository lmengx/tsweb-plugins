# 通用渲染接口（API 1，qq-render 2.0.0）

引擎只依赖宿主 `paths` 和已随宿主提供的 `sharp`。服务名为 `qqRenderer`，不依赖 QQ 服务或游戏服。模板、数据查询、文案、排版和分页由调用插件实现。引擎不加载其他插件的文件，不扫描模板目录或导入旧配置。

## 可选注册与热更新

```js
// 在业务插件 apply(ctx) 中注册。不要将 qqRenderer 放进必需 inject。
ctx.inject(['qqRenderer'], c => {
  if (c.qqRenderer.apiVersion !== 1) return
  return c.qqRenderer.registerTemplate('example/status', {
    owner: 'example',
    async build({ data, signal }, { config, limits }) {
      // 由本插件查询数据并转义动态 SVG 文本。
      return {
        pages: ['<svg xmlns="http://www.w3.org/2000/svg" width="320" height="160"><text x="20" y="80">示例卡片</text></svg>'],
        text: '状态卡片',
      }
    },
  })
})
```

`registerTemplate(name, {owner, build})` 返回注销函数。名称全局唯一，推荐 `插件名/模板名`；重复注册返回 409。将注销函数作为 `ctx.inject` 回调的返回值，插件停用或渲染器更新时自动注销，渲染器重新出现时自动注册。旧注销函数不能删除同名的新模板。多模板注册部分失败时，调用方应撤销已完成的注册。

`listTemplates()` 返回 `{name, owner}[]`，`apiVersion` 为 1。

## 渲染与回退

```js
let renderer
try { renderer = ctx.get('qqRenderer') } catch {}
let reply
if (renderer?.config?.enabled) {
  try { reply = await renderer.render('example/status', { data, signal }) }
  catch (error) { if (signal?.aborted) throw error }
}
// reply 为 {images: Buffer[], text: string, data?: any}。
// 缺失或失败时使用完整文字，业务操作只执行一次。
// 发送图片放在渲染的 catch 外，避免发送结果未知时自动重试。
```

`build(options, tools)` 返回 `{pages: (SVG文本 | PNG Buffer)[], text?, data?}`，可异步执行。SVG 必须内嵌，不接受文件路径、外部资源、DTD、脚本或 foreignObject。引擎统一输出 PNG。`rasterize(source, {signal})` 为底层转换接口；常规业务使用 `render()` 以获得并发、页数和总体积控制。`preview: true` 可在图片开关关闭时预览，不保存配置。

同时最多 3 个任务；每任务最多 20 页，每页宽高不超过 4096、像素不超过 800 万、输入不超过 4 MiB、输出不超过 8 MiB、总输出不超过 32 MiB。模板生成最长 15 秒；传给模板的 signal 包含调用者取消、模板注销和引擎停用。模板应将 signal 传给自己的异步查询。任一页失败则整体失败，不返回部分结果。

## 配置归属

保留现有 `data/qq-render/config.json` 及 `{config, revision}` 格式，不搬移、不自动转换文件。引擎只解释 `enabled`，其余键是业务方的不透明选项；`save(input, expectedRevision)` 校验版本，合并未修改键并串行原子保存。业务方必须校验自己的选项，不能让用户输入直接成为 SVG 或文件路径。配置副本传给 build 的 tools，不允许模板修改引擎配置。

QQ 服务负责已有风格、公开游戏地址、四类卡片、快照与预览管理；投票插件负责投票卡片。未来新插件不需要修改引擎即可注册自己的模板。

## QQ 能力可选图片呈现

新版 qq-serve 的 OneBot 投票接入在能力执行一次后调用能力元数据的可选 `present(result, {signal})`，接收 `{images: PNG Buffer[], text?}`。业务插件注册此函数；缺失、失败或返回空值时保留完整文字。此回调不在 `invoke()` 内执行，旧 HTTP API 保持业务 JSON，不生成图片。其他命令适配器可复用 `onebot/presentation.js` 的协议。引擎本身不发送消息。

首次一起更新 qq-render 2.0.0、qq-serve 2.4.0、vote 2.1.0。投票网页与业务不强制依赖渲染器。
