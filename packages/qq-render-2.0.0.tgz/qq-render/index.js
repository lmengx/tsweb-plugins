import { Service } from '@deepseek-ai/cordis'
import { mkdir, readFile, writeFile, rename, rm } from 'node:fs/promises'
import path from 'node:path'
import { randomUUID } from 'node:crypto'
import sharp from 'sharp'

export const name = 'qq-render'
export const inject = ['paths']
const fail = (status, message) => Object.assign(new Error(message), { status })
const png = Buffer.from('89504e470d0a1a0a', 'hex')
const limits = Object.freeze({ concurrency: 3, pages: 20, inputBytes: 4 * 1024 * 1024, imageBytes: 8 * 1024 * 1024, totalBytes: 32 * 1024 * 1024, pixels: 8_000_000 })
function abortable(work, signal) {
  if (signal.aborted) return Promise.reject(signal.reason)
  return new Promise((resolve, reject) => {
    const abort = () => reject(signal.reason)
    signal.addEventListener('abort', abort, { once: true })
    Promise.resolve(work).then(resolve, reject).finally(() => signal.removeEventListener('abort', abort))
  })
}
function config(value, base = { enabled: true }) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || JSON.stringify(value).length > 128 * 1024) throw fail(400, '渲染配置格式无效')
  if (value.enabled !== undefined && typeof value.enabled !== 'boolean') throw fail(400, '启用状态必须为布尔值')
  // Provider options are opaque to the engine: no business data or theme definitions.
  return JSON.parse(JSON.stringify({ ...base, ...value }))
}

export class Renderer extends Service {
  constructor(ctx) {
    super(ctx, 'qqRenderer')
    this.apiVersion = 1
    this.file = path.join(ctx.paths.dataOf(name), 'config.json')
    this.config = { enabled: true }; this.revision = randomUUID()
    this.templates = new Map(); this.tail = Promise.resolve(); this.active = 0; this.disposed = false; this.abort = new AbortController()
  }
  async load() {
    await mkdir(path.dirname(this.file), { recursive: true })
    try {
      const stored = JSON.parse(await readFile(this.file, 'utf8'))
      this.config = config(stored.config); this.revision = stored.revision || randomUUID()
    } catch (error) { if (error.code !== 'ENOENT') throw error }
  }
  publicConfig() { return { ...structuredClone(this.config), revision: this.revision, templates: this.listTemplates() } }
  async save(input, revision) {
    await this.ready
    const job = this.tail.then(async () => {
      if (this.disposed) throw fail(503, '渲染器已停用')
      if (revision !== this.revision) throw fail(409, '配置已变化，请刷新后重试')
      const next = config(input, this.config), nextRevision = randomUUID(), temporary = this.file + '.' + randomUUID() + '.tmp'
      try {
        await writeFile(temporary, JSON.stringify({ config: next, revision: nextRevision }, null, 2) + '\n', { mode: 0o600, flag: 'wx' })
        await rename(temporary, this.file)
      } finally { await rm(temporary, { force: true }).catch(() => {}) }
      this.config = next; this.revision = nextRevision
      return this.publicConfig()
    })
    this.tail = job.catch(() => {})
    return job
  }
  registerTemplate(name, { owner, build } = {}) {
    if (this.disposed) throw fail(503, '渲染器已停用')
    if (!/^[a-z][a-z0-9_./-]{0,95}$/.test(name) || !owner || typeof build !== 'function') throw fail(400, '模板必须提供名称、owner 和 build 函数')
    if (this.templates.has(name)) throw fail(409, '渲染模板已注册：' + name)
    const entry = { owner: String(owner), build, abort: new AbortController() }
    this.templates.set(name, entry)
    return () => {
      if (this.templates.get(name) === entry) this.templates.delete(name)
      entry.abort.abort(fail(503, '渲染模板已停用'))
    }
  }
  listTemplates() { return [...this.templates].map(([name, entry]) => ({ name, owner: entry.owner })) }
  check(signal, name, entry) {
    if (signal?.aborted) throw signal.reason || fail(499, '渲染已取消')
    if (this.disposed || (name && this.templates.get(name) !== entry)) throw fail(503, '渲染器或模板已停用')
  }
  async rasterize(source, { signal } = {}) {
    this.check(signal)
    if (typeof source !== 'string' && !Buffer.isBuffer(source)) throw fail(400, '页面必须为 SVG 文本或 PNG Buffer，不能使用文件路径')
    const input = Buffer.isBuffer(source) ? source : Buffer.from(source)
    if (!input.length || input.length > limits.inputBytes) throw fail(413, '渲染页面输入过大或为空')
    const isPng = input.subarray(0, 8).equals(png)
    if (!isPng) {
      const svg = input.toString('utf8')
      if (!/^\s*(?:<\?xml[^>]*>\s*)?<svg\b/i.test(svg) || /<!DOCTYPE|<!ENTITY|<script\b|<foreignObject\b|(?:href\s*=\s*["']\s*(?!#|data:image\/)|url\(\s*["']?(?!#|data:image\/))/i.test(svg)) throw fail(400, '只接受内嵌 SVG 或 PNG，不允许外部资源')
    }
    const pipeline = sharp(input, { limitInputPixels: limits.pixels })
    const metadata = await pipeline.metadata()
    if (!metadata.width || !metadata.height || metadata.width > 4096 || metadata.height > 4096 || metadata.width * metadata.height > limits.pixels) throw fail(413, '渲染页面尺寸超限')
    this.check(signal)
    const output = await pipeline.png().toBuffer()
    this.check(signal)
    if (output.length > limits.imageBytes) throw fail(413, '渲染图片超过 8 MiB')
    return output
  }
  async render(name, options = {}) {
    await this.ready
    this.check(options.signal)
    if (!this.config.enabled && !options.preview) throw fail(503, '图片渲染已关闭')
    const entry = this.templates.get(name)
    if (!entry) throw fail(404, '渲染模板未注册：' + name)
    if (this.active >= limits.concurrency) throw fail(429, '渲染任务较多，请稍后重试')
    const signal = AbortSignal.any([this.abort.signal, entry.abort.signal, AbortSignal.timeout(15_000), ...(options.signal ? [options.signal] : [])])
    this.active++
    try {
      const result = await abortable(entry.build({ ...options, signal }, { config: structuredClone(this.config), limits }), signal)
      this.check(signal, name, entry)
      if (!Array.isArray(result?.pages) || !result.pages.length || result.pages.length > limits.pages) throw fail(413, '模板必须返回 1–' + limits.pages + ' 页')
      const images = []; let total = 0
      for (const source of result.pages) {
        const buffer = await this.rasterize(source, { signal })
        this.check(signal, name, entry)
        total += buffer.length
        if (total > limits.totalBytes) throw fail(413, '渲染图片总大小超限')
        images.push(buffer)
      }
      return { images, text: String(result.text || ''), ...(result.data === undefined ? {} : { data: result.data }) }
    } finally { this.active-- }
  }
  dispose() { this.disposed = true; this.abort.abort(fail(503, '渲染器已停用')); this.templates.clear() }
}
export async function apply(ctx) {
  const service = new Renderer(ctx)
  ctx.effect(() => () => service.dispose(), 'qq-render:dispose')
  service.ready = service.load(); ctx.qqRenderer = service
  await service.ready
}
