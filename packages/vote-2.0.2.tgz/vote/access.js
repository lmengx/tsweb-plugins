const admin = [
  ['list', 'GET', '/api/vote/admin/rounds'],
  ['detail', 'GET', '/api/vote/admin/rounds/:id/detail'],
  ['create', 'POST', '/api/vote/rounds'],
  ['update', 'PATCH', '/api/vote/rounds/:id'],
  ['addOption', 'POST', '/api/vote/rounds/:id/options'],
  ['removeOption', 'DELETE', '/api/vote/rounds/:id/options/:optionId'],
  ['close', 'POST', '/api/vote/rounds/:id/close'],
  ['archive', 'POST', '/api/vote/rounds/:id/archive'],
  ['unarchive', 'POST', '/api/vote/rounds/:id/unarchive'],
  ['delete', 'DELETE', '/api/vote/rounds/:id'],
  ['import', 'POST', '/api/vote/admin/import'],
  ['audit', 'GET', '/api/vote/admin/audit'],
]
const player = [
  ['rounds', 'GET', '/api/vote/rounds'],
  ['mine', 'GET', '/api/vote/rounds/mine'],
  ['cast', 'POST', '/api/vote/rounds/:id/cast'],
  ['propose', 'POST', '/api/vote/rounds/:id/propose'],
  ['key', 'GET', '/api/vote/player/key'],
  ['login', 'POST', '/api/vote/player/login'],
  ['me', 'GET', '/api/vote/player/me'],
  ['logout', 'POST', '/api/vote/player/logout'],
]
const requires = admin.map(([id]) => `vote.admin.${id}`)
export default {
  owner: 'vote', version: 2,
  modules: [{ id: 'vote.manage', permission: 'vote.manage', title: '投票管理', roles: ['superadmin', 'admin'], scope: 'global', requires }],
  actions: [
    ...admin.map(([id, method, path]) => ({ id: `vote.admin.${id}`, method, path, scope: 'global', module: 'vote.manage' })),
    // Public transport only: handlers authenticate separate player cookies, never panel JWTs.
    ...player.map(([id, method, path]) => ({ id: `vote.player.${id}`, method, path, public: true })),
  ],
  features: [{ id: 'vote:manage', module: 'vote.manage', requires }],
}
