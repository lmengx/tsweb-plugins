# 投票管理交互提案

三个独立方案使用相同的模拟数据，可在顶部切换。无需登录，不请求生产投票接口。操作仅保存在当前页面内存中，刷新或点击“重置示例”后恢复。

- A 清爽列表：多轮次表格、状态筛选与搜索，抽屉查看结果、参与记录、提案和编辑。
- B 深色工作台：左侧轮次导航，右侧集中查看结果、参与记录和设置。
- C 引导发布：三步创建投票，实时展示玩家预览，并提供已有轮次管理。

在项目根目录构建：

```sh
node plugins/vote/demo/build.mjs
```

构建产物位于 `dist/`（被 Git 忽略），使用宿主提供的 `/vendor/vue.js`。
启动面板并加载 vote 插件后访问：

```text
http://localhost:3000/plugins/vote/demo/index.html#list
http://localhost:3000/plugins/vote/demo/index.html#studio
http://localhost:3000/plugins/vote/demo/index.html#guide
```

这些页面用于选择管理界面的设计方向，尚未替换正式后台。页面中的人数、选票和参与记录均为演示内容。
