<script setup>
import Icon from './Icon.vue'
defineProps({ model: Object, section: { default: 'all' }, locked: Boolean })
</script>
<template>
  <section v-if="section === 'all' || section === 'basic'" class="form-section">
    <div class="section-heading"><span class="section-no">01</span><div><h3>先说说，这次投什么？</h3><p>一个清楚的标题，能让更多玩家愿意参与。</p></div></div>
    <label class="field"><span>投票标题 <b>*</b><small>{{ model.title.length }}/60</small></span><input v-model="model.title" maxlength="60" placeholder="例如：下一次冒险，去哪个世界？" aria-label="投票标题"></label>
    <label class="field"><span>说明 <em>选填</em></span><textarea v-model="model.description" rows="3" maxlength="300" placeholder="告诉玩家背景、规则，或你想说的话。" aria-label="投票说明"></textarea></label>
    <label class="field"><span>截止时间</span><input v-model="model.end" type="datetime-local" aria-label="截止时间"><small>留空即长期开放，你随时可以手动结束。</small></label>
  </section>
  <fieldset v-if="section === 'all' || section === 'options'" class="form-section" :disabled="locked">
    <div class="section-heading"><span class="section-no">02</span><div><h3>给玩家哪些选择？</h3><p>选项尽量简短，发布后也能继续补充。</p></div></div>
    <label v-for="(option,index) in model.options" :key="index" class="option-input"><span>{{ String(index + 1).padStart(2,'0') }}</span><input v-model="option.text" :aria-label="'选项 ' + (index+1)" :placeholder="'选项 ' + (index+1)" maxlength="50"><button class="icon-button" :aria-label="'删除选项 ' + (index+1)" :disabled="model.options.length < 2" @click="model.options.splice(index,1)"><Icon name="close" :size="15" /></button></label>
    <button class="add-option" :disabled="model.options.length >= 100" @click="model.options.push({text:''})"><Icon name="plus" :size="16" /> 添加一个选项</button>
    <div class="field"><span>每人可以选几项？</span><div class="choice-row"><button :class="{chosen:model.maxVotes===1}" @click="model.maxVotes=1">单选 <small>只能选 1 项</small></button><button :class="{chosen:model.maxVotes>1}" @click="model.maxVotes=2">多选 <small>可选多个不同选项</small></button></div><label v-if="model.maxVotes>1" class="inline-field">最多选择 <input v-model.number="model.maxVotes" type="number" min="2" max="100" aria-label="最多可选数量"> 项</label></div>
    <div class="toggle-row"><div><strong>允许玩家提出新选项</strong><small>提案直接加入投票，支持匿名展示。</small></div><button class="toggle" :class="{on:model.proposals}" role="switch" :aria-checked="model.proposals" aria-label="允许玩家提案" @click="model.proposals=!model.proposals"><span /></button></div>
    <label v-if="model.proposals" class="inline-field inset-field">每位玩家最多提案 <input v-model.number="model.quota" type="number" min="1" max="100" aria-label="提案额度"> 个</label>
  </fieldset>
  <fieldset v-if="section === 'all' || section === 'rules'" class="form-section" :disabled="locked">
    <div class="section-heading"><span class="section-no">03</span><div><h3>最后，定好参与规则</h3><p>默认一人一票一分，有需要时再增加加权。</p></div></div>
    <div class="toggle-row"><div><strong>允许未绑定的 QQ 玩家参与</strong><small>未绑定玩家只计算基础分值。</small></div><button class="toggle" :class="{on:model.unbound}" role="switch" :aria-checked="model.unbound" aria-label="允许未绑定玩家" @click="model.unbound=!model.unbound"><span /></button></div>
    <label class="inline-field base-field">每票基础分值 <input v-model.number="model.base" type="number" min="0.01" step="0.5" aria-label="基础分值"> 分</label>
    <div class="toggle-row"><div><strong>为长期活跃玩家加权</strong><small>按累计游玩时长增加分值，不改变可选数量。</small></div><button class="toggle" :class="{on:model.weighted}" role="switch" :aria-checked="model.weighted" aria-label="启用时长加权" @click="model.weighted=!model.weighted"><span /></button></div>
    <div v-if="model.weighted" class="weight-builder"><span class="tiny-eyebrow">条件 01</span><div class="inline-field">游玩时长 ≥ <input v-model.number="model.threshold" type="number" min="0" aria-label="加权时长"> 小时</div><div class="inline-field">每票额外加 <input v-model.number="model.bonus" type="number" min="0" step="0.5" aria-label="附加分值"> 分</div><p><Icon name="check" :size="14" /> 满足条件的玩家，每票 {{ Number(model.base||0) + Number(model.bonus||0) }} 分</p></div>
    <p class="form-note"><Icon name="file" :size="15" /> 规则修改只影响新投出的票，历史票的分值保留。</p>
  </fieldset>
</template>
