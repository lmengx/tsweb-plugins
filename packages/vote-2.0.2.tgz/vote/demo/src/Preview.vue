<script setup>
import { computed } from 'vue'
import Icon from './Icon.vue'
const props = defineProps({ round: Object, compact: Boolean })
const options = computed(() => props.round?.options?.filter(o => o.text.trim()) || [])
</script>
<template><div class="player-preview" :class="{compact}"><div class="preview-paper"><div class="preview-top"><span class="preview-badge">进行中</span><span v-if="round.proposals">可提案 {{ round.quota }} 个 / 人</span></div><div class="preview-countdown"><span>距投票结束</span><b>02 <small>天</small> 06 : 42 : 18</b></div><p class="preview-date">截止时间 <strong>{{ round.end?.replace('T',' ') || round.date || '长期有效' }}</strong></p><h3>{{ round.title || '你的投票标题' }}</h3><p v-if="round.description" class="preview-description">{{ round.description }}</p><div v-for="(o,i) in options" :key="i" class="preview-option"><span>{{ o.text }}</span><div><i :style="{width:(o.votes ? Math.max(12, 80-i*17):0)+'%'}"></i></div></div><div v-if="!options.length" class="preview-placeholder">添加选项后，会在这里展示。</div><p class="preview-rule">每人最多选择 {{ round.maxVotes }} 项{{ round.weighted ? ' · 满足时长可获得额外分值' : '' }}</p><button class="preview-login" disabled>登录以参加投票 <Icon name="arrow" :size="15" /></button></div></div></template>
