<script setup>
defineProps({ name: String, size: { default: 18 } })
const paths = {
  plus: 'M12 5v14M5 12h14', arrow: 'M5 12h14m-5-5 5 5-5 5', back: 'm14 6-6 6 6 6', close: 'm6 6 12 12M6 18 18 6',
  search: 'm21 21-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0', chevron: 'm8 10 4 4 4-4', check: 'm5 12 4 4L19 6',
  chart: 'M4 19h16M7 15V9m5 6V5m5 10v-4', ballot: 'm4 10 4-6h8l4 6v10H4ZM4 10h16M9 14h6',
  clock: 'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0M12 7v5l3 2', people: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M16 3a4 4 0 0 1 0 8m6 10v-2a4 4 0 0 0-3-3.9M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
  archive: 'M3 3h18v5H3Zm2 5v13h14V8M10 12h4', edit: 'm16 3 5 5-12 12-6 1 1-6ZM14 5l5 5', eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12ZM15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0',
  link: 'm9 15 6-6m-2-3 2-2a4.2 4.2 0 0 1 6 6l-2 2m-8 6-2 2a4.2 4.2 0 0 1-6-6l2-2',
  more: 'M5 12h.01M12 12h.01M19 12h.01', reset: 'M3 11a9 9 0 1 1 2 7M3 4v7h7', globe: 'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0M3 12h18M12 3c4 5 4 13 0 18-4-5-4-13 0-18',
  stop: 'M7 7h10v10H7Z', trash: 'M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7',
  wand: 'm4 20 12-12 4 4L8 24ZM14 10l4 4M6 3v4M4 5h4m12-3v4m-2-2h4M4 12v4m-2-2h4',
  settings: 'M4 7h16M4 17h16M8 4v6m8 4v6', file: 'M14 2H4v20h16V8ZM14 2v6h6M8 13h8m-8 4h5',
}
</script>
<template><svg :width="size" :height="size" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path :d="paths[name] || paths.ballot" /></svg></template>
