export const variants = [
  { id: 'list', letter: 'A', title: '清爽列表', subtitle: '所有轮次，一目了然', description: '把轮次、状态、参与人数放进一张清晰的表格。低频配置收进抽屉，日常操作留在手边。', best: '适合同时管理多个轮次' },
  { id: 'studio', letter: 'B', title: '深色工作台', subtitle: '选中一轮，专注处理', description: '左侧切换投票，右侧直接查看实时结果、参与记录与规则，减少来回打开弹窗。', best: '适合经常查看和调整投票' },
  { id: 'guide', letter: 'C', title: '引导发布', subtitle: '一步一步，把投票做好', description: '将发起投票拆成三个短步骤，并同步展示玩家预览。复杂加权规则用自然语言解释。', best: '适合新建投票和不熟悉规则的管理员' },
]
const option = (text, votes, score = votes, custom = false) => ({ id: Math.random().toString(36).slice(2), text, votes, score, custom })
export function seed() {
  return [
    { id: 'world', title: '下一次冒险，去哪个世界？', description: '新一轮服务器即将开启。选出你最期待的地图，一起决定下一次冒险。', status: 'open', participants: 128, end: '2026-10-20T20:00', date: '10 月 20 日 20:00', remaining: '还剩 2 天', maxVotes: 2, proposals: true, quota: 1, unbound: false, weighted: true, threshold: 50, bonus: .5, base: 1, options: [option('经典生存世界', 62, 93), option('专家挑战地图', 48, 72), option('大师模式', 37, 55.5), option('社区自建活动图', 17, 25.5, true)] },
    { id: 'time', title: '周末活动，什么时候见？', description: '找一个大家都有空的时间，来一场全服 Boss 挑战。', status: 'open', participants: 86, end: '2026-10-19T18:00', date: '10 月 19 日 18:00', remaining: '还剩 1 天', maxVotes: 1, proposals: false, quota: 1, unbound: true, weighted: false, threshold: 50, bonus: .5, base: 1, options: [option('周六 20:00', 46), option('周日 15:00', 30), option('周五 21:00', 10)] },
    { id: 'name', title: '给新服务器取个名字', description: '一个新的世界，需要一个值得记住的名字。你也可以提出自己的创意。', status: 'open', participants: 42, end: '2026-10-22T22:00', date: '10 月 22 日 22:00', remaining: '还剩 4 天', maxVotes: 1, proposals: true, quota: 2, unbound: true, weighted: false, threshold: 50, bonus: .5, base: 1, options: [option('星海', 22), option('远山', 13), option('逐光', 7, 7, true)] },
    { id: 'build', title: '九月建筑大赛 · 最佳作品', description: '感谢每一位建筑师的奇思妙想。', status: 'closed', participants: 96, end: '2026-10-12T20:00', date: '10 月 12 日 20:00', remaining: '已结束', maxVotes: 1, proposals: false, quota: 1, unbound: false, weighted: false, threshold: 50, bonus: .5, base: 1, options: [option('天空之城', 52), option('海底图书馆', 31), option('森林小屋', 13)] },
    { id: 'rules', title: '社区公共仓库使用规则', description: '一起制定更友善的公共仓库规则。', status: 'archived', participants: 73, end: '2026-09-30T18:00', date: '09 月 30 日 18:00', remaining: '已归档', maxVotes: 1, proposals: false, quota: 1, unbound: true, weighted: false, threshold: 50, bonus: .5, base: 1, options: [option('按需取用，及时补充', 58), option('仅限活动物资', 15)] },
  ]
}
export const blank = () => ({ title: '', description: '', maxVotes: 1, proposals: false, quota: 1, unbound: true, weighted: false, threshold: 50, bonus: .5, base: 1, end: '2026-10-24T20:00', options: [{ text: '' }, { text: '' }] })
export const sampleDraft = () => ({ ...blank(), title: '下一次冒险，去哪个世界？', description: '新一轮服务器即将开启。选出你最期待的地图，一起决定下一次冒险。', maxVotes: 2, proposals: true, unbound: false, weighted: true, options: [{text:'经典生存世界'},{text:'专家挑战地图'},{text:'大师模式'}] })
export const statusName = status => ({ open: '进行中', closed: '已结束', archived: '已归档' })[status]
export const total = r => r.options.reduce((n, o) => n + o.votes, 0)
export const percentage = (r, o) => Math.round(o.score / (r.options.reduce((n, v) => n + v.score, 0) || 1) * 100)
export const records = [
  { name: '星河', qq: '1024***601', option: '经典生存世界', weight: 1.5, source: 'QQ 群', time: '今天 16:42', initials: '星', color: '#6483d5' },
  { name: '林间旅人', qq: '2386***092', option: '专家挑战地图', weight: 1.5, source: '网页', time: '今天 16:38', initials: '林', color: '#629788' },
  { name: 'Moonlight', qq: '3571***428', option: '经典生存世界', weight: 1, source: '网页', time: '今天 16:31', initials: 'M', color: '#b58b61' },
  { name: '小岛', qq: '1689***083', option: '大师模式', weight: 1.5, source: 'QQ 群', time: '今天 16:24', initials: '岛', color: '#9b83ba' },
  { name: '南风', qq: '2648***719', option: '社区自建活动图', weight: 1, source: 'QQ 群', time: '今天 16:17', initials: '南', color: '#698eaa' },
]
