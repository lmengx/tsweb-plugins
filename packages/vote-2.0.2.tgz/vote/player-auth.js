import { createHash, randomBytes } from 'node:crypto'
import { fail } from './service.js'

const COOKIE = 'tsweb_vote_session'
const TTL = 7 * 86400000
const fingerprint = record => createHash('sha256').update(JSON.stringify([record.username, record.qq, record.passwordHash, record.boundAt])).digest('hex')
export class PlayerSessions {
  constructor({ auth, resolve, now = Date.now }) {
    this.auth = auth
    this.resolve = resolve
    this.now = now
    this.sessions = new Map()
    this.rates = new Map()
  }
  take(ip, kind = 'login', max = 10) {
    const now = this.now()
    for (const [key, slot] of this.rates) if (slot.until <= now) this.rates.delete(key)
    const key = `${kind}:${ip}`
    const slot = this.rates.get(key) || { count: 0, until: now + 60000 }
    if (slot.count >= max || this.rates.size >= 10000 && !this.rates.has(key)) throw fail(429, '操作过于频繁，请稍后重试')
    slot.count++; this.rates.set(key, slot)
  }
  sameOrigin(req) {
    if (req.get('Sec-Fetch-Site') === 'cross-site') throw fail(403, '请从投票页面提交操作')
    const origin = req.get('Origin')
    if (origin && origin !== `${req.protocol}://${req.get('host')}`) throw fail(403, '请从投票页面提交操作')
    if (!req.is('application/json')) throw fail(415, '请使用 JSON 提交操作')
  }
  cookie(req) {
    const part = String(req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith(`${COOKIE}=`))
    return part?.slice(COOKIE.length + 1) || ''
  }
  setCookie(req, res, token, maxAge) {
    res.cookie(COOKIE, token, { httpOnly: true, sameSite: 'strict', secure: req.secure, path: '/api/vote', maxAge })
  }
  async login(req, res) {
    this.sameOrigin(req)
    this.take(req.ip)
    const { account, keyId, encryptedPassword } = req.body || {}
    if (typeof account !== 'string' || account.length > 200 || typeof keyId !== 'string' || typeof encryptedPassword !== 'string' || encryptedPassword.length > 2048) throw fail(400, '登录参数无效')
    let password
    try { password = this.auth.decryptPassword(keyId, encryptedPassword) } catch { throw fail(400, '登录验证已失效，请重试') }
    const record = await this.resolve(account.trim(), true)
    const provider = this.auth.identityProvider
    if (!record || !provider?.verify || !record.passwordHash || !await provider.verify(password, record.passwordHash)) throw fail(401, '账号或密码错误')
    const now = this.now()
    for (const [key, session] of this.sessions) if (session.expires <= now) this.sessions.delete(key)
    if (this.sessions.size >= 5000) throw fail(503, '登录人数较多，请稍后重试')
    this.sessions.delete(this.cookie(req))
    const token = randomBytes(32).toString('base64url')
    this.sessions.set(token, { qq: record.qq, fingerprint: fingerprint(record), expires: now + TTL })
    this.setCookie(req, res, token, TTL)
    return { success: true, player: { username: record.username, qq: record.qq } }
  }
  async require(req) {
    const token = this.cookie(req), session = this.sessions.get(token)
    if (!session || session.expires <= this.now()) { this.sessions.delete(token); throw fail(401, '请先登录玩家账户') }
    const record = await this.resolve(session.qq, true)
    if (!record || fingerprint(record) !== session.fingerprint) {
      this.sessions.delete(token)
      throw fail(401, '登录已失效，请重新登录')
    }
    return { username: record.username, qq: record.qq, bound: true }
  }
  logout(req, res) {
    this.sameOrigin(req)
    this.sessions.delete(this.cookie(req)); this.setCookie(req, res, '', 0)
    return { success: true }
  }
  dispose() { this.sessions.clear(); this.rates.clear() }
}
