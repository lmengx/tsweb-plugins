import { mkdir, readFile, writeFile, rename, unlink } from 'node:fs/promises'
import path from 'node:path'
import { randomUUID } from 'node:crypto'

export const fail = (status, message) => Object.assign(new Error(message), { status })
const norm = value => String(value ?? '').trim().toLowerCase()
const id = prefix => `${prefix}-${randomUUID()}`
const stamp = () => new Date().toISOString()
const number = (value, min, max, label, integer = false) => {
  const n = Number(value)
  if (!Number.isFinite(n) || n < min || n > max || (integer && !Number.isInteger(n))) throw fail(400, `${label}必须在 ${min} 至 ${max} 之间${integer ? '且为整数' : ''}`)
  return n
}
const text = (value, max, label, required = false) => {
  const s = String(value ?? '').trim()
  if ((required && !s) || s.length > max) throw fail(400, `${label}${required ? '不能为空，且' : ''}最多 ${max} 字`)
  return s
}
const date = value => {
  if (!value) return null
  if (!Number.isFinite(new Date(value).getTime())) throw fail(400, '截止时间无效')
  return new Date(value).toISOString()
}
export const roundStatus = (round, now = Date.now()) => round.closedAt || (round.endAt && now >= new Date(round.endAt).getTime()) ? 'closed' : 'open'
const ruleFields = ['maxVotesPerUser', 'baseWeight', 'weightRules', 'allowProposals', 'maxProposalsPerUser', 'allowUnbound']
function rules(value) {
  if (!Array.isArray(value) || value.length > 30) throw fail(400, '加权规则最多 30 条')
  return value.map(r => {
    if (!r || r.field !== 'playtime_hours' || !['>', '>='].includes(r.op)) throw fail(400, '加权规则仅支持游玩时长与 >、>= 比较')
    return { field: 'playtime_hours', op: r.op, threshold: number(r.threshold, 0, 1e8, '时长'), weight: number(r.weight, 0, 1e6, '附加分值') }
  })
}
function normalizeRules(p, base = {}) {
  const out = { ...base }
  for (const key of ['allowProposals', 'allowUnbound']) if (p[key] !== undefined) {
    if (typeof p[key] !== 'boolean') throw fail(400, '开关值必须是布尔值')
    out[key] = p[key]
  }
  for (const [key, label] of [['maxVotesPerUser', '可投选项数'], ['maxProposalsPerUser', '提案数']]) if (p[key] !== undefined) out[key] = number(p[key], 1, 100, label, true)
  if (p.baseWeight !== undefined) out.baseWeight = number(p.baseWeight, 0.01, 1e6, '基础分值')
  if (p.weightRules !== undefined) out.weightRules = rules(p.weightRules)
  return out
}
function belongs(record, identity) {
  // QQ is canonical across web/bot and binding transitions; name fallback imports old votes lacking QQ.
  if (record.qq) return String(record.qq) === identity.qq
  return norm(record.username) === norm(identity.username) || norm(record.username) === `qq:${identity.qq}`
}
function proposalBelongs(option, identity) {
  return belongs({ qq: option.proposerQq, username: option.proposer }, identity)
}
export class VoteStore {
  constructor({ dir, playtime, identity, nicknames, fs = {} }) {
    this.file = path.join(dir, 'votes.json')
    this.dir = dir
    this.playtime = playtime
    this.identity = identity
    this.nicknames = nicknames
    this.fs = { mkdir, readFile, writeFile, rename, unlink, ...fs }
    this.queue = Promise.resolve()
    this.active = true
  }
  async read() {
    let data
    try { data = JSON.parse(await this.fs.readFile(this.file, 'utf8')) }
    catch (e) { if (e.code === 'ENOENT') return { schema: 2, rounds: [], votes: [], audit: [] }; throw fail(503, '投票数据无法读取，请检查数据文件后重试') }
    if (!data || !Array.isArray(data.rounds) || !Array.isArray(data.votes)) throw fail(503, '投票数据格式错误，原文件已保留')
    return { ...data, audit: Array.isArray(data.audit) ? data.audit : [] }
  }
  mutate(action, actor, fn) {
    const result = this.queue.then(async () => {
      if (!this.active) throw fail(503, '投票插件已停用')
      const data = await this.read()
      const output = await fn(data)
      data.schema = 2
      data.audit.push({ action: `vote.${action}`, actor, at: stamp(), roundId: output?.roundId || output?.vote?.roundId || output?.round?.id || output?.id || null })
      data.audit = data.audit.slice(-5000)
      await this.fs.mkdir(this.dir, { recursive: true })
      const tmp = `${this.file}.${randomUUID()}.tmp`
      try {
        await this.fs.writeFile(tmp, JSON.stringify(data, null, 2), 'utf8')
        await this.fs.rename(tmp, this.file)
      } catch (e) {
        await this.fs.unlink(tmp).catch(() => {})
        throw fail(503, '投票数据保存失败，本次操作未生效')
      }
      return output
    })
    this.queue = result.catch(() => {})
    return result
  }
  find(data, roundId, open = false) {
    const round = data.rounds.find(r => r.id === roundId)
    if (!round) throw fail(404, '投票轮次不存在')
    if (open && (roundStatus(round) !== 'open' || round.archived)) throw fail(400, '该轮投票已结束或归档')
    return round
  }
  create(p, actor) {
    return this.mutate('round.create', actor, data => {
      if (data.rounds.length >= 1000) throw fail(400, '投票轮次已达上限')
      if (!Array.isArray(p.options) || !p.options.length || p.options.length > 100) throw fail(400, '初始选项须为 1 至 100 个')
      const options = p.options.map(s => ({ id: id('o'), text: text(s, 50, '选项', true), type: 'preset' }))
      if (new Set(options.map(o => norm(o.text))).size !== options.length) throw fail(400, '初始选项不能重复')
      const round = { id: id('r'), title: text(p.title, 60, '标题', true), description: text(p.description, 300, '说明'), createdAt: stamp(), endAt: date(p.endAt), closedAt: null, archived: false,
        ...normalizeRules(p, { maxVotesPerUser: 1, baseWeight: 1, allowProposals: false, maxProposalsPerUser: 1, allowUnbound: true, weightRules: [] }), options }
      data.rounds.push(round)
      return round
    })
  }
  update(roundId, patch, actor) {
    return this.mutate('round.update', actor, data => {
      const round = this.find(data, roundId)
      // Evaluate original status before editing endAt: changing a date cannot bypass rule locks.
      if (roundStatus(round) !== 'open' && ruleFields.some(k => patch[k] !== undefined)) throw fail(400, '轮次已结束，仅可修改标题、说明和截止时间')
      if (patch.title !== undefined) round.title = text(patch.title, 60, '标题', true)
      if (patch.description !== undefined) round.description = text(patch.description, 300, '说明')
      if (patch.endAt !== undefined) round.endAt = date(patch.endAt)
      const next = normalizeRules(patch, round)
      const counts = new Map()
      for (const vote of data.votes.filter(v => v.roundId === roundId)) {
        const owner = vote.qq || norm(vote.username)
        if (!counts.has(owner)) counts.set(owner, new Set())
        counts.get(owner).add(vote.optionId)
      }
      if ([...counts.values()].some(set => set.size > next.maxVotesPerUser)) throw fail(400, '可投选项数不能低于已投数量')
      Object.assign(round, next)
      return round
    })
  }
  manage(roundId, operation, actor, value) {
    return this.mutate(`round.${operation}`, actor, data => {
      const round = this.find(data, roundId)
      if (operation === 'close') { round.closedAt ||= stamp(); round.endedBy = actor }
      else if (operation === 'archive') { round.archived = true; round.archivedAt = stamp(); round.archivedBy = actor }
      else if (operation === 'unarchive') { round.archived = false; round.archivedAt = null; round.archivedBy = null }
      else if (operation === 'delete') { data.rounds = data.rounds.filter(r => r !== round); data.votes = data.votes.filter(v => v.roundId !== roundId) }
      else if (operation === 'addOption') {
        if (roundStatus(round) !== 'open') throw fail(400, '轮次已结束，选项已锁定')
        const clean = text(value, 50, '选项', true)
        if (round.options.length >= 100) throw fail(400, '本轮选项已达 100 个')
        if (round.options.some(o => norm(o.text) === norm(clean))) throw fail(400, '选项已存在')
        const option = { id: id('o'), text: clean, type: 'preset', addedBy: actor }
        round.options.push(option)
        return { roundId, option }
      } else if (operation === 'removeOption') {
        if (roundStatus(round) !== 'open') throw fail(400, '轮次已结束，选项已锁定')
        if (round.options.length <= 1) throw fail(400, '至少保留一个选项')
        const option = round.options.find(o => o.id === value)
        if (!option) throw fail(404, '选项不存在')
        round.options = round.options.filter(o => o !== option)
        const before = data.votes.length
        data.votes = data.votes.filter(v => v.roundId !== roundId || v.optionId !== value)
        return { roundId, option, removedVotes: before - data.votes.length }
      } else throw fail(400, '不支持的操作')
      return { roundId, round }
    })
  }
  async weight(round, identity) {
    if (!round.weightRules?.length || !identity.bound) return { weight: Number(round.baseWeight ?? 1), playtimeHours: null }
    const hours = await this.playtime(identity.username)
    if (!Number.isFinite(hours) || hours < 0) throw fail(503, '游玩时长暂不可用，请稍后投票')
    const weight = round.weightRules.reduce((sum, r) => sum + ((r.op === '>=' ? hours >= r.threshold : hours > r.threshold) ? r.weight : 0), Number(round.baseWeight ?? 1))
    return { weight: Math.round(weight * 100) / 100, playtimeHours: hours }
  }
  state(round, votes, identity) {
    const mine = votes.filter(v => v.roundId === round.id && belongs(v, identity))
    const options = [...new Set(mine.map(v => v.optionId))]
    const proposals = round.options.filter(o => o.type === 'custom' && proposalBelongs(o, identity))
    return { votedOptions: options, votesLeft: Math.max(0, round.maxVotesPerUser - options.length), myProposals: proposals.length, proposalsLeft: Math.max(0, round.maxProposalsPerUser - proposals.length), baseWeight: round.baseWeight, weightRules: round.weightRules || [] }
  }
  cast(roundId, identity, optionId) {
    return this.mutate('cast', identity.username, async data => {
      const round = this.find(data, roundId, true)
      if (!identity.bound && !round.allowUnbound) throw fail(403, '本轮仅限已绑定玩家参与，请先绑定角色')
      const option = round.options.find(o => o.id === optionId)
      if (!option) throw fail(404, '选项不存在')
      const state = this.state(round, data.votes, identity)
      if (state.votedOptions.includes(optionId)) throw fail(400, '不能重复投同一个选项')
      if (!state.votesLeft) throw fail(400, '本轮可投次数已用完')
      const { weight } = await this.weight(round, identity)
      const vote = { roundId, username: identity.username, qq: identity.qq, optionId, weight, at: stamp() }
      data.votes.push(vote)
      return { vote, option: this.publicOption(option), state: this.state(round, data.votes, identity) }
    })
  }
  propose(roundId, identity, value, anonymous = false) {
    return this.mutate('propose', identity.username, data => {
      const round = this.find(data, roundId, true)
      if (!identity.bound && !round.allowUnbound) throw fail(403, '本轮仅限已绑定玩家参与，请先绑定角色')
      if (!round.allowProposals) throw fail(400, '本轮不允许自主提案')
      const clean = text(value, 50, '提案', true)
      const existing = round.options.find(o => norm(o.text) === norm(clean))
      if (existing) return { roundId, option: this.publicOption(existing), existing: true }
      if (!this.state(round, data.votes, identity).proposalsLeft) throw fail(400, '本轮提案额度已用完')
      if (round.options.length >= 100) throw fail(400, '本轮选项已达 100 个')
      const option = { id: id('o'), text: clean, type: 'custom', proposer: identity.username, proposerQq: identity.qq, anonymous: !!anonymous }
      round.options.push(option)
      return { roundId, option: this.publicOption(option), existing: false }
    })
  }
  publicOption(option) {
    // Whitelist fields: raw proposer must never leak in anonymous responses or bot payloads.
    return { id: option.id, text: option.text, type: option.type, anonymous: !!option.anonymous,
      ...(!option.anonymous && option.type === 'custom' ? { proposer: option.proposer || '', proposerQq: option.proposerQq || '', proposerDisplay: option.proposer || '' } : {}) }
  }
  async list({ identity = null, admin = false, detail = null } = {}) {
    const data = await this.read()
    const rounds = []
    const nicknames = admin && this.nicknames ? await this.nicknames() : {}
    for (const round of data.rounds) {
      if ((!admin && round.archived) || (detail && round.id !== detail)) continue
      const item = { ...round, status: roundStatus(round), options: [] }
      if (admin) item.participants = new Set(data.votes.filter(v => v.roundId === round.id).map(v => v.qq ? `qq:${v.qq}` : `user:${norm(v.username)}`)).size
      for (const option of round.options) {
        const votes = data.votes.filter(v => v.roundId === round.id && v.optionId === option.id)
        const row = { ...(admin ? option : this.publicOption(option)), votes: votes.length, score: Math.round(votes.reduce((n, v) => n + v.weight, 0) * 100) / 100 }
        if (admin && detail) row.voters = await Promise.all(votes.map(async v => ({ ...v, nickname: Object.hasOwn(nicknames, v.qq) ? nicknames[v.qq] : '', player: (await this.identity?.(v.qq))?.username || '' })))
        item.options.push(row)
      }
      if (identity) {
        item.my = this.state(round, data.votes, identity)
        try { Object.assign(item.my, await this.weight(round, identity)) } catch (e) { item.my.weight = null; item.my.weightError = e.message }
      }
      rounds.push(item)
    }
    rounds.sort((a, b) => (a.status === b.status ? 0 : a.status === 'open' ? -1 : 1) || (new Date(a.endAt || '9999-01-01') - new Date(b.endAt || '9999-01-01')) || a.createdAt.localeCompare(b.createdAt))
    if (detail && !rounds.length) throw fail(404, '轮次不存在')
    return detail ? rounds[0] : rounds
  }
  importLegacy(source, actor) {
    return this.mutate('import', actor, data => {
      if (data.rounds.length || data.votes.length) throw fail(409, '仅空投票库可导入旧数据，现有数据不会被覆盖')
      if (!source || !Array.isArray(source.rounds) || !Array.isArray(source.votes) || source.rounds.length > 1000 || source.votes.length > 100000) throw fail(400, '旧投票文件格式或数量无效')
      const roundIds = new Set(), optionIds = new Map()
      const imported = source.rounds.map(r => {
        if (!r || typeof r.id !== 'string' || !r.id || roundIds.has(r.id)) throw fail(400, '轮次 ID 缺失或重复')
        roundIds.add(r.id)
        if (!Array.isArray(r.options) || !r.options.length || r.options.length > 100) throw fail(400, '旧选项无效')
        const ids = new Set()
        const options = r.options.map(o => {
          if (!o || typeof o.id !== 'string' || !o.id || ids.has(o.id)) throw fail(400, '选项 ID 缺失或重复')
          ids.add(o.id)
          return { id: o.id, text: text(o.text, 50, '选项', true), type: o.type === 'custom' ? 'custom' : 'preset', ...(o.type === 'custom' ? { proposer: text(o.proposer, 200, '提案人', true), proposerQq: String(o.proposerQq || (/^qq:\d+$/.test(o.proposer) ? o.proposer.slice(3) : '')), anonymous: !!o.anonymous } : {}) }
        })
        optionIds.set(r.id, ids)
        return { id: r.id, title: text(r.title, 60, '标题', true), description: text(r.description, 300, '说明'), createdAt: date(r.createdAt) || stamp(), endAt: date(r.endAt), closedAt: date(r.closedAt), endedBy: text(r.endedBy, 200, '结束操作人'), archived: !!r.archived, archivedAt: date(r.archivedAt), archivedBy: text(r.archivedBy, 200, '归档操作人'), ...normalizeRules(r, { baseWeight: 1, maxVotesPerUser: 1, allowProposals: false, maxProposalsPerUser: 1, allowUnbound: true, weightRules: [] }), options }
      })
      const votes = source.votes.map(v => {
        if (!v || !optionIds.get(v.roundId)?.has(v.optionId)) throw fail(400, '旧选票引用了不存在的轮次或选项')
        const qq = String(v.qq || '')
        if (qq && !/^\d{5,15}$/.test(qq)) throw fail(400, '旧选票 QQ 格式错误')
        return { roundId: v.roundId, optionId: v.optionId, username: text(v.username, 200, '投票人', true), qq, weight: number(v.weight, 0, 1e9, '历史票权重'), at: date(v.at) || stamp() }
      })
      data.rounds = imported; data.votes = votes
      return { rounds: imported.length, votes: votes.length }
    })
  }
  async dispose() { this.active = false; await this.queue }
}
