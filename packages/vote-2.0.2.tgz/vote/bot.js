import { fail } from './service.js'

function findRound(rounds, keyword) {
  if (!keyword) return rounds.find(r => r.status === 'open')
  const exact = rounds.filter(r => r.title === keyword)
  if (exact.length === 1) return exact[0]
  const matches = rounds.filter(r => r.title.includes(keyword) || keyword.includes(r.title))
  return matches.length === 1 ? matches[0] : null
}
function findOption(round, value) {
  if (/^\d+$/.test(value)) return round.options[Number(value) - 1]
  const exact = round.options.find(o => o.text === value)
  if (exact) return exact
  const matches = round.options.filter(o => o.text.includes(value) || value.includes(o.text))
  return matches.length === 1 ? matches[0] : null
}
export function parseTarget(rounds, value, propose = false) {
  const clean = String(value || '').trim()
  if (!clean || clean.length > 250) throw fail(400, propose ? '请输入提案内容' : '请输入选项名称或编号')
  const first = findRound(rounds, '')
  if (!propose && first) {
    const option = findOption(first, clean)
    if (option) return { round: first, option }
  }
  const space = clean.search(/\s/)
  if (space > 0) {
    const round = findRound(rounds, clean.slice(0, space))
    if (round) {
      const rest = clean.slice(space).trim()
      if (propose) return { round, text: rest }
      const option = findOption(round, rest)
      if (option) return { round, option }
      throw fail(400, `轮次「${round.title}」中未找到选项`)
    }
  }
  if (propose && first) return { round: first, text: clean }
  throw fail(400, first ? '未找到选项，请发送「投票」查看' : '当前没有进行中的投票')
}
export function registerBot(qqBind, store, resolve) {
  const unregister = []
  const meta = (path, method) => ({ owner: 'vote', legacy: { path: `/api/bot/${path}`, method }, requireBound: false })
  try {
    unregister.push(qqBind.registerCapability('vote.list', async ({ params }) => {
      const rounds = await store.list()
      const keyword = String(params.name || '').trim()
      if (!keyword) return { mode: 'list', rounds }
      const round = findRound(rounds, keyword)
      if (round) return { mode: 'single', round }
      const matches = rounds.filter(r => r.title.includes(keyword) || keyword.includes(r.title))
      if (matches.length) return { mode: 'list', rounds: matches }
      throw fail(404, `未找到投票「${keyword}」`)
    }, meta('votes', 'GET')))
    for (const action of ['cast', 'propose']) unregister.push(qqBind.registerCapability(`vote.${action}`, async ({ principal, params }) => {
      const qq = String(principal?.qq || params.qq || '').trim()
      if (!/^\d{5,15}$/.test(qq)) throw fail(400, 'QQ 号格式不正确')
      const record = await resolve(qq)
      const identity = record ? { username: record.username, qq, bound: true } : { username: `qq:${qq}`, qq, bound: false }
      const { round, option, text } = parseTarget(await store.list(), action === 'cast' ? params.option : params.text, action === 'propose')
      const result = action === 'cast' ? await store.cast(round.id, identity, option.id) : await store.propose(round.id, identity, text, false)
      const state = (await store.list({ identity })).find(r => r.id === round.id)
      return { status: 'ok', mode: action === 'cast' ? 'voted' : 'proposed', qq, username: identity.username, unbound: !identity.bound,
        ...(action === 'cast' ? { weight: result.vote.weight } : { option: result.option, existing: result.existing }), round: state }
    }, meta(`vote-${action}`, 'POST')))
  } catch (error) { unregister.reverse().forEach(off => off()); throw error }
  return () => unregister.reverse().forEach(off => off())
}
