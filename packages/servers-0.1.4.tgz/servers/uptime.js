// TShock returns a .NET TimeSpan, rather than a timestamp or world creation date.
export function serverStartedAt(uptime, now = Date.now()) {
  if (typeof uptime !== 'string') return null
  const match = /^(?:(\d+)\.)?(\d{1,2}):([0-5]\d):([0-5]\d)(?:\.(\d{1,7}))?$/.exec(uptime.trim())
  if (!match || Number(match[2]) > 23) return null
  const seconds = Number(match[1] || 0) * 86400 + Number(match[2]) * 3600 + Number(match[3]) * 60 + Number(match[4])
  const milliseconds = seconds * 1000 + Number(`0.${match[5] || 0}`) * 1000
  const startedAt = Math.round(now - milliseconds)
  return Number.isSafeInteger(startedAt) && startedAt >= 0 ? startedAt : null
}
