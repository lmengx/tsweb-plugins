import { serverStartedAt } from './uptime.js'

// This route can be registered independently while existing SSE connections stay open.
export function registerServerDetails(app, auth, servers, tshock) {
  app.get('/api/servers/:id/details', auth.verifyAuth(), auth.requireServerManager(), async (req, res) => {
    const raw = servers.getRaw(req.params.id)
    if (!raw) return res.status(404).json({ error: '服务器不存在' })
    const result = { status: null, registeredCount: null, errors: [] }
    await Promise.all([
      ['status', '/v2/server/status', {}],
      ['registeredCount', '/data/base/players/list', { page: 1, pageSize: 1 }],
    ].map(async ([key, endpoint, params]) => {
      try {
        const response = await tshock.fetchFor(raw, endpoint, params)
        const data = response.data
        if (!response.ok || !data || data.error || Number(data.status) >= 400) {
          throw new Error(data?.error || data?.response || `请求失败 (${response.status})`)
        }
        if (key === 'registeredCount') {
          if (typeof data.total !== 'number' || !Number.isSafeInteger(data.total) || data.total < 0) throw new Error('未返回有效的注册人数')
          result.registeredCount = data.total
        } else {
          if (typeof data.playercount !== 'number') throw new Error('未返回有效的服务器状态')
          result.status = Object.fromEntries(['name', 'world', 'serverversion', 'tshockversion', 'playercount', 'maxplayers'].map(field => [field, data[field]]))
          result.status.startedAt = serverStartedAt(data.uptime)
        }
      } catch (err) {
        result.errors.push(`${key === 'status' ? '服务器概况' : '注册人数'}读取失败：${err.message}`)
      }
    }))
    res.json(result)
  })
}
