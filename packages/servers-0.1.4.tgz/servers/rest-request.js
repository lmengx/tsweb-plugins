/** The deadline covers both response headers and the complete JSON body. */
export async function requestJson(url, options = {}, timeoutMs = 5000) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, { ...options, signal: controller.signal })
    let data
    try { data = await response.json() }
    catch (error) {
      if (controller.signal.aborted) throw error
      const invalid = new Error(`TShock REST 返回无效 JSON（HTTP ${response.status}）`)
      invalid.type = 'protocol'
      throw invalid
    }
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      const invalid = new Error('TShock REST 返回无效 JSON 对象')
      invalid.type = 'protocol'
      throw invalid
    }
    const logicalStatus = Number(data.status)
    const status = logicalStatus >= 400 && logicalStatus <= 599 ? logicalStatus : response.status
    return { ok: response.ok && status < 400, status, data }
  } catch (error) {
    if (controller.signal.aborted) {
      const timeout = new Error(`请求超时（${timeoutMs / 1000}秒）`)
      timeout.type = 'timeout'
      throw timeout
    }
    if (error.type) throw error
    const code = error.cause?.code || error.code
    const failure = new Error(code === 'ECONNREFUSED' ? '连接被拒绝（ECONNREFUSED）' : code === 'ENOTFOUND' ? `无法解析主机名（${code}）` : `连接失败: ${error.message}`)
    failure.type = code === 'ECONNREFUSED' ? 'refused' : code === 'ENOTFOUND' ? 'dns' : 'network'
    throw failure
  } finally { clearTimeout(timer) }
}
