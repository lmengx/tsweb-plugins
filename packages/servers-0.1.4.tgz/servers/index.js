import accessContract from './access.js'
/**
 * TShock 服务器注册表 + REST token 代理 + 初始化连接完整流程（ctx.servers / ctx.tshock）
 *
 * 三个 cordis 服务：
 *   - ctx.servers  服务器注册表：JSON 持久化（data/servers.json），增删改查。
 *                   脱敏：列表/单个只返回 hasToken（是否已配置），TShock REST token 永不出后端。
 *   - ctx.tshock   多服代理：实例注册表（连接状态）+ tokentest 连接测试 + 带 token 的
 *                   REST 请求转发（TShock REST 为 GET + query string 参数风格，5s 超时，错误分类）。
 *   - ctx.connection 初始化连接流程（本插件新增）：
 *                   状态机 disconnected → connecting → connected / degraded → reconnecting → failed
 *                   - connected : tokentest 通过 + /tsweb/stream Host SSE 长连接已建立（接收端连接；不代表业务日志可用）
 *                   - degraded  : tokentest 通过但 /tsweb/stream 不存在（目标服未装 TSWeb 插件）→ 纯 REST 轮询
 *                   - 心跳 + 指数退避重连（1s→30s，参照旧版 sseConnection.js）
 *                   - 连接事件审计（环形缓冲，每服 100 条）+ 后端→前端 SSE 广播（GET /api/events）
 *
 * HTTP API（前缀 /api，服务器管理全部 admin：verifyAuth + requireAdmin）：
 *   GET    /servers                 服务器列表（脱敏 + 连接状态）
 *   POST   /servers                 添加服务器 { name, host, port, token, note? }（保存后立即连接）
 *   PUT    /servers/:id             更新 { name?, host?, port?, token?, note?, enabled? }（token 留空=不变，保存后重连）
 *   DELETE /servers/:id             删除（断开连接）
 *   POST   /servers/test            仅测试连接（不落库）{ host, port, token }
 *   POST   /servers/:id/test        测试指定服务器
 *   GET    /servers/:id/status      代理 GET /v2/server/status?players=true
 *   GET    /servers/:id/details     服务器概况与分页查询的注册总人数，逐项报告读取失败
 *   GET    /servers/:id/players     代理 GET /v2/players/list
 *   POST   /servers/:id/command     代理 GET /v3/server/rawcmd?cmd=<命令>
 *   POST   /servers/:id/broadcast   代理 GET /v2/server/broadcast?msg=<消息>
 *   ── 连接流程（新增）──
 *   POST   /servers/:id/connect     手动建立连接（tokentest + SSE 建连）
 *   POST   /servers/:id/disconnect  手动断开（取消重连）
 *   GET    /servers/:id/connection  连接详情（状态/错误/重连次数/最近快照/事件历史）
 *   GET    /events                  后端→前端 SSE 流（?token=<JWT>[&serverId=<id>]；
 *                                   事件 connected/ping/server.status/server.log/server.log.replay/server.snapshot/server.event；
 *                                   带 serverId 时补发该服最近 200 条历史日志，供控制台重连后看到历史）
 *
 * 终端命令：
 *   servers           列出服务器（含连接状态）
 *   server-test <id>  测试指定服务器连接
 *   connect <id>      手动连接指定服务器
 *   disconnect <id>   手动断开指定服务器
 */
import { Service } from '@deepseek-ai/cordis'
import crypto from 'node:crypto'
import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { registerServerDetails } from './details.js'
import { registerConsoleRoutes } from './console.js'
import { requestJson } from './rest-request.js'


export const name = 'servers'
export const inject = ['webServer', 'auth', 'terminal', 'paths']

const __dirname = path.dirname(fileURLToPath(import.meta.url))

/** 遗留数据位置（重构前写在插件目录内）；现迁到宿主 <dataDir>/servers */

const FETCH_TIMEOUT = 5000        // REST 代理请求超时
const TOKENTEST_TIMEOUT = 3000    // tokentest 连接测试超时
const SSE_CONNECT_TIMEOUT = 15000 // SSE 建连超时（照抄旧版 sseConnection.js）
const HEARTBEAT_INTERVAL = 30000  // REST 轮询心跳间隔（degraded 模式）
const SSE_STALE_MS = 90000        // SSE 模式：超过该时长无任何帧视为断线
const EVENT_LIMIT = 100           // 每服连接事件环形缓冲上限
const LOG_BUFFER_LIMIT = 2000     // 每服控制台日志环形缓冲上限（照旧版 logBroadcast.js 的 MaxQueueLines=2000）
const LOG_REPLAY_LIMIT = 200      // 新 SSE 连接重放的历史日志条数（照旧版 getRecentLines(serverId, 200)）
const RECONNECT_BASE_MS = 1000    // 重连指数退避基数

// ── 连接状态 ──
export const CONN_STATUS = {
  DISCONNECTED: 'disconnected', // 初始 / 手动断开
  CONNECTING: 'connecting',     // 正在 tokentest / SSE 建连
  CONNECTED: 'connected',       // tokentest 通过 + SSE 长连接已建立
  DEGRADED: 'degraded',         // tokentest 通过但无 SSE（未装插件）→ REST 轮询
  RECONNECTING: 'reconnecting', // 连接中断，等待指数退避重连
  FAILED: 'failed'              // tokentest 失败（token 无效/连接拒绝等）
}

/** 指数退避：1s → 2s → 4s → ... → 30s 封顶（照抄旧版 sseConnection.js delay） */
function delay(retry) {
  return Math.min(RECONNECT_BASE_MS * 2 ** Math.min(retry, 5), 30000)
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

// ═══════════════════════════════════════════════════════════
// TShock 多服代理服务（ctx.tshock）
// ═══════════════════════════════════════════════════════════

export class TshockService extends Service {
  constructor(ctx, options = {}) {
    super(ctx, 'tshock')
    this.instances = new Map() // id -> 实例（含连接状态机）
  }

  /** 登记/更新实例（保留连接状态与运行时字段；地址/token 变化时由上层触发重连） */
  registerServer(server) {
    const existing = this.instances.get(server.id)
    // SSE callbacks retain this object. Metadata edits must not detach them
    // from the instance used by readiness checks and deployment uploads.
    this.instances.set(server.id, Object.assign(existing || {}, {
      id: server.id,
      host: server.host || 'localhost',
      port: server.port || 7878,
      token: server.token || '',
      // 连接状态机（沿用旧字段 isConnected/lastError 兼容）
      status: existing?.status ?? CONN_STATUS.DISCONNECTED,
      isConnected: existing?.isConnected ?? false,
      lastError: existing?.lastError ?? null,
      connectedAt: existing?.connectedAt ?? null,
      retryCount: existing?.retryCount ?? 0,
      // 运行时（不持久化）
      generation: existing?.generation ?? 0, // 代际号：防止旧异步回调改新状态
      reconnectTimer: existing?.reconnectTimer ?? null,
      heartbeatTimer: existing?.heartbeatTimer ?? null,
      sseAbort: existing?.sseAbort ?? null,
      lastSeen: existing?.lastSeen ?? 0,     // SSE 最后收到帧的时间
      clientId: existing?.clientId ?? null,  // SSE connected 事件下发的 clientId
      receiverSession: existing?.receiverSession ?? null,
      receiverIdentity: existing?.receiverIdentity ?? null,
      deploymentError: existing?.deploymentError ?? null,
      cache: existing?.cache ?? { status: null, players: null, fetchedAt: 0 },
      events: existing?.events ?? []
    }))
    return this.instances.get(server.id)
  }

  unregisterServer(id) {
    this.instances.delete(id)
  }

  getServerInstance(id) {
    return this.instances.get(id) || null
  }

  /** 构造 TShock REST 基础地址（host 可带 http(s):// 前缀，端口拼在末尾） */
  baseUrl(server, portOverride) {
    const host = server.host || 'localhost'
    const prefix = /^https?:\/\//i.test(host) ? host : `http://${host}`
    return `${prefix}:${portOverride || server.port || 7878}`
  }

  /** 连接测试（/tokentest），返回 { success, type?, status?, error?, data? } */
  async testConnectionWith(host, port, token) {
    const url = `${this.baseUrl({ host, port })}/tokentest?token=${encodeURIComponent(token || '')}`
    try {
      const result = await requestJson(url, { headers: { Accept: 'application/json' } }, TOKENTEST_TIMEOUT)
      const response = { status: result.status }, data = result.data

      if (response.status === 200) {
        return { success: true, data }
      }
      if (response.status === 401 || response.status === 403) {
        return { success: false, type: 'auth', status: response.status, error: `TShock REST 返回 ${response.status}，token 无效或权限不足` }
      }
      if (response.status === 404) {
        return { success: false, type: 'notfound', status: response.status, error: 'TShock REST 返回 404，接口路径可能不正确' }
      }
      return { success: false, type: 'unknown', status: response.status, error: `TShock REST 返回 ${response.status}` }
    } catch (error) {
      if (error.type === 'timeout') {
        return { success: false, type: 'timeout', status: 0, error: '连接超时（3秒），目标服务器无响应' }
      }
      const code = error.cause?.code || error.code
      if (code === 'ECONNREFUSED') return { success: false, type: 'refused', status: 0, error: '连接被拒绝（ECONNREFUSED），服务器未启动或端口错误' }
      if (code === 'ENOTFOUND' || code === 'EAI_AGAIN') return { success: false, type: 'dns', status: 0, error: `无法解析主机名（${code}）` }
      return { success: false, type: error.type || 'error', status: 0, error: `连接失败: ${error.message}` }
    }
  }

  /** 测试指定实例（更新连接状态） */
  async testConnection(id) {
    const inst = this.instances.get(id)
    if (!inst) return { success: false, type: 'missing', error: '服务器实例不存在' }
    const result = await this.testConnectionWith(inst.host, inst.port, inst.token)
    inst.isConnected = !!result.success
    inst.lastError = result.success ? null : result.error
    return result
  }

  /**
   * 向指定服务器发 TShock REST 请求（GET + query string 参数）。
   * 返回 { ok, status, data }；连接/超时错误抛错并归类。
   * opts.timeoutMs 可为全量查询延长时限，默认仍为 5 秒。
   */
  async fetchFor(server, pathname, params = {}, opts = {}) {
    const url = new URL(pathname, this.baseUrl(server))
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, String(v))
    }
    url.searchParams.set('token', server.token || '')

    return requestJson(url, { headers: { Accept: 'application/json' } }, Number(opts.timeoutMs) > 0 ? Number(opts.timeoutMs) : FETCH_TIMEOUT)
  }

  /**
   * 向指定服务器发 TShock REST **POST** 请求。
   *
   * 为什么需要它：fetchFor 是 GET + query，既承载不了"整份台账快照"这类大载荷，
   * 也满足不了旧版就以 POST 暴露的插件端点（/data/promotion/config/set、
   * /data/riskcontrol/config/set，见 TsWeb/backend/services/tshockService.js:1849-1868）。
   * 参数与错误语义刻意与 fetchFor 完全一致（token 仍走 query、同样的错误分类），
   * 便于调用方在两者之间无脑切换。
   *
   * **编码选择（实证结论，勿想当然）**：TShock 的 `SecureRestCommand` 是"带 token 的 GET"
   * （`/v2/users/create` 在 TShockAPI/Rest/RestManager.cs:258 用 SecureRestCommand 注册，
   * 而旧版后端在 tshockService.js:986-996 用 **GET** 调它）；REST 处理只读
   * `Request.Parameters`（RestAPI/Rest/Rest.cs:406），该集合由 query 与 form body 合并而来。
   * 因此：
   *   - `encoding: 'form'`（默认，推荐）→ `application/x-www-form-urlencoded` + `token` 在 query，
   *     与旧版"复杂载荷塞进 query"的既有做法同源（tshockService.js:1178 把 JSON 编码进 query），
   *     但没有 URL 长度上限，是跨服下发的稳妥选择。
   *   - `encoding: 'json'` → 仅用于明确知道自己解析 JSON body 的自建端点。
   *
   * @param {object} server  含 host/port/token 的原始服务器记录
   * @param {string} pathname
   * @param {object} body    载荷（默认 {}）
   * @param {{method?:string, timeoutMs?:number, encoding?:'form'|'json'}} [opts]
   * @returns {Promise<{ok:boolean, status:number, data:any}>}
   */
  async postFor(server, pathname, body = {}, opts = {}) {
    const url = new URL(pathname, this.baseUrl(server))
    url.searchParams.set('token', server.token || '')

    const encoding = opts.encoding === 'json' ? 'json' : 'form'
    const fields = body ?? {}
    let payload
    let contentType
    if (encoding === 'json') {
      payload = JSON.stringify(fields)
      contentType = 'application/json'
    } else {
      const form = new URLSearchParams()
      for (const [key, value] of Object.entries(fields)) {
        form.set(key, typeof value === 'string' ? value : JSON.stringify(value))
      }
      payload = form.toString()
      contentType = 'application/x-www-form-urlencoded'
    }

    return requestJson(url, {
      method: String(opts.method || 'POST').toUpperCase(),
      headers: { Accept: 'application/json', 'Content-Type': contentType },
      body: payload,
    }, Number(opts.timeoutMs) > 0 ? Number(opts.timeoutMs) : FETCH_TIMEOUT)
  }
}

// ═══════════════════════════════════════════════════════════
// 初始化连接流程服务（ctx.connection）
// ═══════════════════════════════════════════════════════════

export class ConnectionService extends Service {
  constructor(ctx, options = {}) {
    super(ctx, 'connection')
    this.tshock = null          // 由 apply 注入
    this.servers = null         // 由 apply 注入
    this.emit = null            // (eventName, payload) 广播给前端 SSE（由 apply 注入）
    this.ctx = ctx
    // 每服控制台日志环形缓冲：<serverId, string[]>，元素为插件端包装好的日志 JSON 原文
    // 照旧版 logBroadcast.js 的 _logQueues（Map<serverId, string[]>，每服 2000 条）
    this.logBuffers = new Map()
  }

  // ── 控制台日志缓冲（后端 → 前端 SSE 的历史重放）──

  /** 追加一条日志到该服环形缓冲（超出 LOG_BUFFER_LIMIT 从队首淘汰） */
  pushLog(serverId, raw) {
    const key = String(serverId || 'default')
    let queue = this.logBuffers.get(key)
    if (!queue) { queue = []; this.logBuffers.set(key, queue) }
    queue.push(raw)
    if (queue.length > LOG_BUFFER_LIMIT) queue.splice(0, queue.length - LOG_BUFFER_LIMIT)
  }

  /** 取该服最近 limit 条日志（不足则全给），供新 SSE 连接重放 */
  getRecentLogs(serverId, limit = LOG_REPLAY_LIMIT) {
    const queue = this.logBuffers.get(String(serverId || 'default'))
    if (!queue || queue.length === 0) return []
    return queue.slice(-limit)
  }

  /**
   * 取该服环形缓冲里的「一页」历史日志，供控制台上翻查看更早记录。
   *
   * 偏移语义：offset 是「从最新一条往前数已经看过多少条」，也就是说
   * offset=0 拿到的就是最新的一页。这样前端只要累加 offset 就能一直往前翻，
   * 且新日志不断追加时已翻页的内容不会错位（新日志只会让 total 变大）。
   *
   * @returns {{logs: string[], total: number, nextOffset: number, hasMore: boolean}}
   */
  getLogPage(serverId, offset = 0, limit = LOG_REPLAY_LIMIT) {
    const queue = this.logBuffers.get(String(serverId || 'default'))
    const total = queue ? queue.length : 0
    if (total === 0) return { logs: [], total: 0, nextOffset: offset, hasMore: false }
    const end = Math.max(0, total - offset) // 本页最后一条（不含）在缓冲里的下标
    const start = Math.max(0, end - limit)
    const logs = queue.slice(start, end)
    const nextOffset = offset + logs.length
    return { logs, total, nextOffset, hasMore: start > 0 }
  }

  /** 丢弃该服缓冲（内存态，随进程退出自然消失，不持久化） */
  clearLogs(serverId) {
    this.logBuffers.delete(String(serverId || 'default'))
  }

  // ── 审计 ──

  /** 记录一条连接事件（环形缓冲 + 控制台 + 广播） */
  recordEvent(inst, type, message) {
    const ev = { time: Date.now(), type, message }
    inst.events.push(ev)
    if (inst.events.length > EVENT_LIMIT) inst.events.splice(0, inst.events.length - EVENT_LIMIT)
    console.log(`[conn:${inst.id.slice(0, 8)}] ${type}: ${message}`)
    try {
      this.emit?.('server.event', { id: inst.id, event: ev })
    } catch { /* 广播失败不阻断 */ }
  }

  /** 状态变更统一入口：更新状态 + isConnected 同步 + 审计 + 广播 */
  setStatus(inst, status, message) {
    const prev = inst.status
    if (prev === status) return
    inst.status = status
    inst.isConnected = status === CONN_STATUS.CONNECTED || status === CONN_STATUS.DEGRADED
    inst.lastError = status === CONN_STATUS.CONNECTED || status === CONN_STATUS.DEGRADED ? null : inst.lastError
    if (status === CONN_STATUS.CONNECTED || status === CONN_STATUS.DEGRADED) {
      inst.connectedAt = Date.now()
      inst.retryCount = 0
    }
    this.recordEvent(inst, 'status', `${prev} → ${status}${message ? `: ${message}` : ''}`)
    try {
      this.emit?.('server.status', { id: inst.id, status, lastError: inst.lastError, connectedAt: inst.connectedAt })
    } catch { /* ignore */ }
  }

  // ── 生命周期 ──

  /** 手动/自动连接：tokentest → SSE 建连（404 降级 REST）
   *  @param {object} [opts] - { resetRetry: true } 手动触发时重置重连计数（自动重连不重置，保持指数退避）
   */
  async connect(id, opts = {}) {
    const inst = this.tshock.getServerInstance(id)
    if (!inst) return { success: false, error: '服务器实例不存在' }
    const raw = this.servers.getRaw(id)
    if (!raw) return { success: false, error: '服务器不存在' }

    // 代际号：本次连接持有 gen，旧异步回调（gen 不匹配）不得再改状态
    const gen = ++inst.generation
    this._teardownTimers(inst)

    inst.lastError = null
    if (opts.resetRetry) inst.retryCount = 0
    this.setStatus(inst, CONN_STATUS.CONNECTING, '开始连接')

    // ① tokentest
    const test = await this.tshock.testConnectionWith(inst.host, inst.port, inst.token)
    if (gen !== inst.generation) return { success: false, error: '连接已被新的操作取代' }
    if (!test.success) {
      inst.lastError = test.error || 'token 校验失败'
      this.setStatus(inst, CONN_STATUS.FAILED, inst.lastError)
      this._scheduleReconnect(inst, gen)
      return { success: false, status: CONN_STATUS.FAILED, error: inst.lastError, type: test.type }
    }

    // ② SSE 建连（探测 /tsweb/stream；目标服未装 TSWeb 插件则降级 REST）
    const sseResult = await this._openSse(inst, gen)
    if (gen !== inst.generation) return { success: false, error: '连接已被新的操作取代' }
    if (sseResult.ok) {
      this.setStatus(inst, CONN_STATUS.CONNECTED, 'SSE 长连接已建立')
    } else if (sseResult.mode === 'degraded') {
      inst.deploymentError = sseResult.error || '目标服未提供 REST SSE 插件部署接口，请更新 TsWebHost'
      this.setStatus(inst, CONN_STATUS.DEGRADED, `${inst.deploymentError}；REST 功能继续可用`)
    } else {
      inst.lastError = sseResult.error || 'SSE 建连失败'
      this.setStatus(inst, CONN_STATUS.FAILED, inst.lastError)
      this._scheduleReconnect(inst, gen)
      return { success: false, status: CONN_STATUS.FAILED, error: inst.lastError, type: sseResult.type }
    }

    // ③ 连接成功后拉取基础数据快照（状态 + 玩家），失败不阻断
    this._pullSnapshot(inst, gen).catch(() => {})
    // ④ 心跳（SSE 模式查存活 / REST 模式拉状态）
    this._startHeartbeat(inst, gen)
    return { success: true, status: inst.status }
  }

  /** 手动断开：清定时器 + 中断 SSE + 状态置 disconnected（不自动重连） */
  async disconnect(id) {
    const inst = this.tshock.getServerInstance(id)
    if (!inst) return { success: false, error: '服务器实例不存在' }
    inst.generation++ // 使所有在途异步回调失效
    this._teardownTimers(inst)
    this._abortSse(inst)
    inst.lastError = null
    inst.retryCount = 0
    this.setStatus(inst, CONN_STATUS.DISCONNECTED, '手动断开')
    return { success: true, status: inst.status }
  }

  // ── SSE 客户端（后端 → 游戏服 /tsweb/stream）──

  /**
   * 建立 SSE 长连接（照抄旧版 sseConnection.js 的 URL 约定）。
   * 返回 { ok, mode }：
   *   { ok:true }                      → 连接成功，读循环已挂起
   *   { ok:false, mode:'degraded' }    → HTTP 404/非 2xx（目标服无该端点）→ 降级 REST
   *   { ok:false, mode:'error', ... }  → 网络/超时等错误
   */
  async _openSse(inst, gen) {
    const raw = this.servers.getRaw(inst.id)
    const base = this.tshock.baseUrl(raw)
    const url = `${base}/tsweb/stream?token=${encodeURIComponent(inst.token || '')}`

    const ac = new AbortController()
    inst.sseAbort = ac
    // 仅连接阶段 15s 超时；连接建立后移除，避免切断长连接（照抄旧版）
    const timer = setTimeout(() => ac.abort(), SSE_CONNECT_TIMEOUT)
    let res
    try {
      res = await fetch(url, { signal: ac.signal })
    } catch (error) {
      clearTimeout(timer)
      if (gen !== inst.generation) return { ok: false, mode: 'stale' }
      if (error.name === 'AbortError') {
        return { ok: false, mode: 'error', type: 'timeout', error: `SSE 建连超时（${SSE_CONNECT_TIMEOUT / 1000}秒）` }
      }
      const code = error.cause?.code || error.code
      return { ok: false, mode: 'error', type: code || 'network', error: `SSE 连接失败: ${error.message}` }
    }
    clearTimeout(timer)

    if (!res.ok || !res.body) {
      await res.body?.cancel().catch(() => {})
      if (gen !== inst.generation) return { ok: false, mode: 'stale' }
      if (res.status === 404) {
        return { ok: false, mode: 'degraded' }
      }
      if (res.status === 401 || res.status === 403) {
        return { ok: false, mode: 'degraded', type: 'auth', error: `插件部署接口返回 ${res.status}，REST token 需要 tshock.rest.manage 权限` }
      }
      return { ok: false, mode: 'error', type: 'http', error: `SSE 端点返回 HTTP ${res.status}` }
    }

    if (!res.headers.get('content-type')?.toLowerCase().startsWith('text/event-stream')) {
      // Headers already prove this is not SSE. Do not wait for an unbounded
      // error body after clearing the connection timeout.
      ac.abort()
      await res.body.cancel().catch(() => {})
      return { ok: false, mode: 'degraded', error: '目标服未提供 REST SSE 插件部署接口，请更新 TsWebHost' }
    }

    // 连接成功 → 挂起读循环（不 await，断线回调里处理）
    inst.lastSeen = Date.now()
    this._readSseLoop(inst, gen, res.body).catch(() => {})
    return { ok: true }
  }

  /** SSE 读循环：解析 \n\n 帧，处理 connected/ping/log/online；断线触发重连 */
  async _readSseLoop(inst, gen, body) {
    const reader = body.getReader()
    const decoder = new TextDecoder()
    let buffer = ''
    try {
      while (gen === inst.generation) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })
        let idx
        while ((idx = buffer.indexOf('\n\n')) >= 0) {
          const frame = buffer.slice(0, idx)
          buffer = buffer.slice(idx + 2)
          this._handleSseFrame(inst, gen, frame)
        }
      }
    } catch { /* 读流异常 → 走断线处理 */ }
    if (gen !== inst.generation) return

    // 断线（读流结束/异常）
    inst.sseAbort = null
    inst.clientId = null
    inst.receiverSession = null
    this.ctx.emit('host/disconnected', { serverId: inst.id })
    if (inst.status === CONN_STATUS.CONNECTED) {
      inst.lastError = 'SSE 连接断开'
      this.recordEvent(inst, 'sse-drop', 'SSE 连接断开，进入重连')
      this.setStatus(inst, CONN_STATUS.RECONNECTING, inst.lastError)
      this._scheduleReconnect(inst, gen)
    }
  }

  /** 解析单帧 SSE（event:/data: 行） */
  _handleSseFrame(inst, gen, frame) {
    if (gen !== inst.generation) return
    let event = 'message'
    let data = ''
    for (const line of frame.split('\n')) {
      if (line.startsWith('event:')) event = line.slice(6).trim()
      else if (line.startsWith('data:')) data += line.slice(5).replace(/^\s+/, '') + '\n'
    }
    data = data.replace(/\n$/, '')
    if (!data) return
    let parsed
    try { parsed = JSON.parse(data) } catch { return }

    inst.lastSeen = Date.now()
    switch (event) {
      case 'connected':
        inst.clientId = parsed.sessionId || parsed.clientId || null
        inst.receiverIdentity = typeof parsed.receiverModuleId === 'string' ? {
          moduleId: parsed.receiverModuleId, version: parsed.receiverVersion,
          instances: parsed.receiverInstances,
        } : null
        if (parsed.protocol === 2 && typeof parsed.sessionId === 'string') {
          inst.receiverSession = parsed.sessionId
          inst.deploymentError = null
          this.ctx.emit('host/connected', { serverId: inst.id, sessionId: parsed.sessionId })
        } else {
          inst.receiverSession = null
          inst.deploymentError = '游戏服部署协议不兼容，请更新配套的 TsWebHost 2.3.0'
          this.ctx.emit('host/disconnected', { serverId: inst.id })
        }
        this.recordEvent(inst, 'sse-connected', `SSE clientId=${inst.clientId}`)
        break
      case 'plugin.report':
      case 'plugin.ack':
        if (inst.receiverSession && parsed.sessionId === inst.receiverSession)
          this.ctx.emit(event === 'plugin.report' ? 'host/report' : 'host/ack', { ...parsed, serverId: inst.id })
        break
      case 'ping':
        break
      case 'log':
        // 插件端包装的日志 JSON（{ id, time, segments, serverId }），先入环形缓冲再转发前端。
        // 缓冲用于新 SSE 连接的历史重放（照旧版：每服 2000 条、连接时补发最近 200 条）
        this.pushLog(inst.id, typeof data === 'string' ? data : parsed)
        try { this.emit?.('server.log', { id: inst.id, log: typeof data === 'string' ? data : parsed }) } catch { /* ignore */ }
        break
      case 'online':
        // 插件上报本服在线数 → 更新快照 → 广播
        if (parsed.online != null) {
          inst.cache.status = { ...(inst.cache.status || {}), playercount: parsed.online }
          inst.cache.fetchedAt = Date.now()
          try { this.emit?.('server.snapshot', { id: inst.id, cache: inst.cache }) } catch { /* ignore */ }
        }
        break
      default:
        // qq-uuid / cross-chat / file.* 等本插件不处理，忽略
        break
    }
  }

  // ── 心跳 / 快照 / 重连 ──

  /** 心跳：检查 SSE 存活、拉取 REST 状态；降级时重新探测 SSE。 */
  _startHeartbeat(inst, gen) {
    this._clearHeartbeat(inst)
    let probingSse = false
    inst.heartbeatTimer = setInterval(async () => {
      if (gen !== inst.generation) { this._clearHeartbeat(inst); return }
      if (inst.status === CONN_STATUS.CONNECTED) {
        // SSE 模式：超过 SSE_STALE_MS 无任何帧（含 ping）视为断线
        if (Date.now() - inst.lastSeen > SSE_STALE_MS) {
          inst.lastError = 'SSE 心跳超时（无数据帧）'
          this.recordEvent(inst, 'heartbeat-timeout', inst.lastError)
          this.setStatus(inst, CONN_STATUS.RECONNECTING, inst.lastError)
          this._abortSse(inst)
          this._scheduleReconnect(inst, gen)
          return
        }
      }
      if (inst.status === CONN_STATUS.CONNECTED || inst.status === CONN_STATUS.DEGRADED) {
        // Deployment SSE carries no gameplay snapshots; poll REST in both modes.
        try {
          const result = await this.tshock.fetchFor(inst, '/v2/server/status', { players: true })
          if (gen !== inst.generation) return
          if (result.ok) {
            inst.cache.status = result.data
            inst.cache.fetchedAt = Date.now()
            try { this.emit?.('server.snapshot', { id: inst.id, cache: inst.cache }) } catch { /* ignore */ }
            // REST can start before Host attaches its SSE dispatcher. A single
            // JSON/404 response during startup must not disable deployment forever.
            // Probe in place so a server without Host retains usable REST status.
            if (inst.status === CONN_STATUS.DEGRADED && !probingSse) {
              probingSse = true
              try {
                const sse = await this._openSse(inst, gen)
                if (gen !== inst.generation) return
                if (sse.ok) {
                  this.setStatus(inst, CONN_STATUS.CONNECTED, 'SSE 接口恢复，长连接已重新建立')
                } else if (sse.error && inst.deploymentError !== sse.error) {
                  inst.deploymentError = sse.error
                  this.recordEvent(inst, 'sse-probe-fail', sse.error)
                }
              } finally { probingSse = false }
            }
          } else {
            inst.lastError = `心跳失败: TShock REST 返回 ${result.status}`
            this.recordEvent(inst, 'heartbeat-fail', inst.lastError)
            this.setStatus(inst, CONN_STATUS.RECONNECTING, inst.lastError)
            this._scheduleReconnect(inst, gen)
          }
        } catch (err) {
          if (gen !== inst.generation) return
          inst.lastError = `心跳失败: ${err.message}`
          this.recordEvent(inst, 'heartbeat-fail', inst.lastError)
          this.setStatus(inst, CONN_STATUS.RECONNECTING, inst.lastError)
          this._scheduleReconnect(inst, gen)
        }
      }
    }, HEARTBEAT_INTERVAL)
  }

  /** 连接成功后拉取基础数据快照（状态 + 玩家） */
  async _pullSnapshot(inst, gen) {
    try {
      const st = await this.tshock.fetchFor(inst, '/v2/server/status', { players: true })
      if (gen !== inst.generation) return
      if (st.ok) {
        inst.cache.status = st.data
        inst.cache.fetchedAt = Date.now()
        try { this.emit?.('server.snapshot', { id: inst.id, cache: inst.cache }) } catch { /* ignore */ }
      }
      const pl = await this.tshock.fetchFor(inst, '/v2/players/list')
      if (gen !== inst.generation) return
      if (pl.ok && Array.isArray(pl.data?.players)) {
        inst.cache.players = pl.data.players
        inst.cache.fetchedAt = Date.now()
        try { this.emit?.('server.snapshot', { id: inst.id, cache: inst.cache }) } catch { /* ignore */ }
      }
    } catch (err) {
      if (gen !== inst.generation) return
      this.recordEvent(inst, 'snapshot-fail', `快照拉取失败: ${err.message}`)
    }
  }

  /** 指数退避重连：到点后若仍是待重连状态则重新 connect */
  _scheduleReconnect(inst, gen) {
    this._clearReconnect(inst)
    const wait = delay(inst.retryCount)
    inst.retryCount++
    this.recordEvent(inst, 'schedule-reconnect', `${wait / 1000}s 后重连（第 ${inst.retryCount} 次）`)
    inst.reconnectTimer = setTimeout(() => {
      if (gen !== inst.generation) return
      if (inst.status === CONN_STATUS.RECONNECTING || inst.status === CONN_STATUS.FAILED) {
        this.connect(inst.id).catch(() => {})
      }
    }, wait)
  }

  // ── 清理 ──

  _clearTimers(inst) {
    this._clearReconnect(inst)
    this._clearHeartbeat(inst)
  }

  _clearReconnect(inst) {
    if (inst.reconnectTimer) { clearTimeout(inst.reconnectTimer); inst.reconnectTimer = null }
  }

  _clearHeartbeat(inst) {
    if (inst.heartbeatTimer) { clearInterval(inst.heartbeatTimer); inst.heartbeatTimer = null }
  }

  _abortSse(inst) {
    inst.receiverSession = null
    this.ctx.emit('host/disconnected', { serverId: inst.id })
    if (inst.sseAbort) { try { inst.sseAbort.abort() } catch { /* ignore */ } inst.sseAbort = null }
  }

  _teardownTimers(inst) {
    this._clearReconnect(inst)
    this._clearHeartbeat(inst)
    this._abortSse(inst)
  }

  /** 获取连接详情（供 GET /servers/:id/connection） */
  getConnectionInfo(inst) {
    return {
      id: inst.id,
      status: inst.status,
      isConnected: inst.isConnected,
      lastError: inst.lastError,
      connectedAt: inst.connectedAt,
      retryCount: inst.retryCount,
      reconnecting: !!inst.reconnectTimer, // 是否处于等待重连中
      hasSse: inst.status === CONN_STATUS.CONNECTED,
      deploymentError: inst.deploymentError || null,
      clientId: inst.clientId,
      cache: {
        status: inst.cache.status,
        players: inst.cache.players,
        fetchedAt: inst.cache.fetchedAt
      },
      events: inst.events.slice(-20).reverse()
    }
  }
}

// ═══════════════════════════════════════════════════════════
// 服务器注册表服务（ctx.servers）
// ═══════════════════════════════════════════════════════════

function sanitize(server, tshock) {
  if (!server) return null
  const inst = tshock.getServerInstance(server.id)
  return {
    id: server.id,
    name: server.name,
    host: server.host,
    port: server.port,
    enabled: server.enabled,
    note: server.note || '',
    hasToken: !!(server.token && server.token.length > 0),
    status: inst?.status || CONN_STATUS.DISCONNECTED,
    connected: inst?.status === CONN_STATUS.CONNECTED || inst?.status === CONN_STATUS.DEGRADED,
    lastError: inst?.lastError || null,
    connectedAt: inst?.connectedAt || null,
    retryCount: inst?.retryCount || 0,
    createdAt: server.createdAt,
    updatedAt: server.updatedAt
  }
}

export class ServerRegistryService extends Service {
  constructor(ctx, options = {}) {
    super(ctx, 'servers')
    // 数据目录：显式 options > 宿主 ctx.paths（<dataDir>/servers）> 遗留插件内 data/
    this.dataDir = options.dataDir
      ?? ctx.paths?.dataOf('servers')
      ?? path.join(__dirname, 'data')
    this.file = path.join(this.dataDir, 'servers.json')
    this.servers = null // [{ id, name, host, port, token, enabled, note, createdAt, updatedAt }]
    /**
     * 清单是否**可信地**读出来了。
     * 供下游对账逻辑区分"确实一台服务器都没有"与"还没读到 / 读取失败"——
     * 后者被当成空清单会清掉别的插件里全部下发记录（registry._reconcileServerStates）。
     */
    this.loaded = false
    this.loadError = null
    this.tshock = null  // 由 apply 注入
    this._persistTail = Promise.resolve()
    this._mutationTail = Promise.resolve()
    this.connection = null // 由 apply 注入
  }

  async load() {
    this.loaded = false
    this.loadError = null
    try {
      const content = await fs.readFile(this.file, 'utf8')
      const parsed = JSON.parse(content)
      /**
       * 合法 JSON 但结构不对（{}、顶层数组、旧格式）时必须当作**读取失败**：
       * 若退化成"可信的空清单"，下游对账会把所有插件的下发记录当陈旧记录删光
       * （那正是本次守门想防的丢数据）。只有 ENOENT（文件不存在 = 全新安装）
       * 才是真正可信的空。
       */
      if (!Array.isArray(parsed?.servers)) {
        const e = new Error(`servers.json 结构异常：缺少 servers 数组（顶层类型 ${Array.isArray(parsed) ? 'array' : typeof parsed}）`)
        e.code = 'EBADSHAPE'
        throw e
      }
      this.servers = parsed.servers.map(({ hostPort, pushSecret, ...server }) => server)
      this.loaded = true
    } catch (err) {
      this.servers = []
      if (err.code === 'ENOENT') {
        // 文件不存在 = 还没登记过任何服务器（全新安装），这是**可信的空**
        this.loaded = true
      } else {
        // 读取/解析失败：不能当成"没有服务器"。loaded 保持 false，
        // 下游据此跳过下发状态对账，宁可不清理也不误删。
        this.loadError = err
        console.error(`[servers] 读取 ${this.file} 失败: ${err.message}；本次不参与下发状态对账`)
      }
    }
    return this.servers
  }

  async persist(servers = this.servers) {
    this.assertHealthy()
    const content = JSON.stringify({ servers }, null, 2)
    const write = this._persistTail.catch(() => {}).then(async () => {
      await fs.mkdir(this.dataDir, { recursive: true })
      const temporary = this.file + '.' + crypto.randomUUID() + '.tmp'
      try {
        await fs.writeFile(temporary, content, 'utf8')
        await fs.rename(temporary, this.file)
      } finally { await fs.rm(temporary, { force: true }).catch(() => {}) }
    })
    this._persistTail = write
    await write
  }

  assertHealthy() {
    if (this.loadError) {
      const error = new Error(`服务器清单读取失败，已停止写入，请恢复 ${this.file}: ${this.loadError.message}`)
      error.status = 503
      throw error
    }
  }

  async list() {
    this.assertHealthy()
    return this.servers.map((s) => sanitize(s, this.tshock))
  }

  async get(id) {
    const server = this.servers.find((s) => s.id === id)
    return sanitize(server, this.tshock)
  }

  /** 取含 token 的原始记录（仅供代理/测试内部使用，勿直接暴露给前端） */
  getRaw(id) {
    return this.servers.find((s) => s.id === id) || null
  }

  validate(data, { partial = false } = {}) {
    const err = (msg) => { const e = new Error(msg); e.status = 400; throw e }
    if (!partial || data.name !== undefined) {
      if (!data.name || !String(data.name).trim()) err('服务器名称不能为空')
    }
    if (!partial || data.host !== undefined) {
      if (!data.host || !String(data.host).trim()) err('主机地址不能为空')
    }
    if (!partial || data.port !== undefined) {
      const port = Number(data.port)
      if (!Number.isInteger(port) || port < 1 || port > 65535) err('端口必须是 1-65535 的整数')
    }
    // token：新增时必填；更新时留空/缺省表示不变（由 update 处理）
    if (!partial && (!data.token || String(data.token).trim() === '')) {
      err('TShock REST token 不能为空')
    }
    return data
  }

  async add(data) {
    const pending = this._mutationTail.catch(() => {}).then(() => this._add(data))
    this._mutationTail = pending
    return pending
  }

  async _add(data) {
    this.assertHealthy()
    this.validate(data)
    const now = new Date().toISOString()
    const server = {
      id: crypto.randomUUID(),
      name: String(data.name).trim(),
      host: String(data.host).trim(),
      port: Number(data.port),
      token: String(data.token || '').trim(),
      enabled: data.enabled !== false,
      note: String(data.note || '').trim(),
      createdAt: now,
      updatedAt: now
    }
    const next = [...this.servers, server]
    await this.persist(next)
    this.servers = next
    this.tshock.registerServer(server)
    // 添加即测试 + 自动连接（完整流程入口）
    this.connection.connect(server.id, { resetRetry: true }).catch(() => {})
    return sanitize(server, this.tshock)
  }

  async update(id, patch) {
    const pending = this._mutationTail.catch(() => {}).then(() => this._update(id, patch))
    this._mutationTail = pending
    return pending
  }

  async _update(id, patch) {
    this.assertHealthy()
    const next = structuredClone(this.servers)
    const server = next.find((s) => s.id === id)
    if (!server) { const e = new Error('服务器不存在'); e.status = 404; throw e }
    this.validate(patch, { partial: true })

    const changed = {}
    if (patch.name !== undefined) { server.name = String(patch.name).trim(); changed.name = true }
    if (patch.host !== undefined) { server.host = String(patch.host).trim(); changed.host = true }
    if (patch.port !== undefined) { server.port = Number(patch.port); changed.port = true }
    // token：非空则更新；空/未提供则保持原值（避免误清）
    if (patch.token !== undefined && patch.token !== null && String(patch.token).trim() !== '') {
      server.token = String(patch.token).trim(); changed.token = true
    }
    const enabledChanged = patch.enabled !== undefined && !!patch.enabled !== server.enabled
    if (patch.enabled !== undefined) server.enabled = !!patch.enabled
    if (patch.note !== undefined) server.note = String(patch.note || '').trim()
    server.updatedAt = new Date().toISOString()

    await this.persist(next)
    this.servers = next
    this.tshock.registerServer(server)
    // 连接参数变化 → 重新连接；enabled 开关 → 连接/断开；仅 note 变化 → 保持原连接
    if (enabledChanged) {
      if (server.enabled) {
        this.connection.connect(server.id, { resetRetry: true }).catch(() => {})
      } else {
        this.connection.disconnect(server.id).catch(() => {})
      }
    } else if (changed.host || changed.port || changed.token) {
      this.connection.connect(server.id, { resetRetry: true }).catch(() => {})
    } else if (changed.name) {
      this.tshock.testConnection(server.id).catch(() => {})
    }
    return sanitize(server, this.tshock)
  }

  async reorder(ids) {
    const pending = this._mutationTail.catch(() => {}).then(async () => {
      this.assertHealthy()
      if (!Array.isArray(ids) || ids.some(id => typeof id !== 'string' || !id) || new Set(ids).size !== ids.length) {
        const error = new Error('服务器顺序必须是不重复的服务器 ID 列表')
        error.status = 400
        throw error
      }
      const byId = new Map(this.servers.map(server => [server.id, server]))
      if (ids.some(id => !byId.has(id))) {
        const error = new Error('服务器列表已变化，请刷新后重试')
        error.status = 409
        throw error
      }
      // Only move the supplied records. Servers outside the caller's scope
      // retain their positions and all connection instances stay intact.
      const selected = new Set(ids)
      let index = 0
      const next = this.servers.map(server => selected.has(server.id) ? byId.get(ids[index++]) : server)
      await this.persist(next)
      this.servers = next
      return this.list()
    })
    this._mutationTail = pending
    return pending
  }

  async remove(id) {
    const pending = this._mutationTail.catch(() => {}).then(() => this._remove(id))
    this._mutationTail = pending
    return pending
  }

  async _remove(id) {
    this.assertHealthy()
    const idx = this.servers.findIndex((s) => s.id === id)
    if (idx < 0) { const e = new Error('服务器不存在'); e.status = 404; throw e }
    const next = [...this.servers]
    const [removed] = next.splice(idx, 1)
    await this.persist(next)
    this.servers = next
    this.connection.disconnect(id).catch(() => {})
    this.tshock.unregisterServer(id)
    return { id: removed.id }
  }

  /** 启动时注册全部实例并自动连接（enabled 的服务器） */
  activateAll() {
    for (const s of this.servers) {
      this.tshock.registerServer(s)
    }
    for (const s of this.servers) {
      if (s.enabled !== false) {
        this.connection.connect(s.id, { resetRetry: true }).catch(() => {})
      }
    }
  }
}

// ═══════════════════════════════════════════════════════════
// 插件挂载
// ═══════════════════════════════════════════════════════════

export async function apply(ctx, options = {}) {
  const tshock = new TshockService(ctx, options)
  const connection = new ConnectionService(ctx, options)
  const servers = new ServerRegistryService(ctx, options)
  servers.tshock = tshock
  servers.connection = connection
  connection.tshock = tshock
  connection.servers = servers
  ctx.tshock = tshock
  ctx.connection = connection
  ctx.servers = servers
  ctx.auth.serverExists = id => !!servers.getRaw(id)

  // ═══ 后端 → 前端 SSE 广播器（连接状态/日志/快照实时推送）═══
  const sseClients = new Set() // res 集合
  const broadcast = (eventName, payload) => {
    const data = `event: ${eventName}\ndata: ${JSON.stringify(payload)}\n\n`
    for (const res of sseClients) {
      // writableEnded/destroyed 也要当成已断开：仅在 write 抛错时才删的话，
      // 半关闭的连接会一直留在集合里被反复重试。
      if (res.writableEnded || res.destroyed) { sseClients.delete(res); continue }
      // 每次发送前重新校验账户、角色、有效期和 QQ 密码，撤权立即停止推送。
      ctx.auth.authenticateToken(res.authToken).then(user => {
        if (res.writableEnded || res.destroyed) return
        const actionId = eventName.startsWith('server.log') ? 'servers.get.servers.id.console.history' : eventName === 'server.status' ? 'servers.get.servers.id.connection' : 'servers.get.servers.id.status'
        if (ctx.auth.access.authorize(user, ctx.auth.access.action(actionId), payload.id ?? payload.serverId)) res.write(data)
      }).catch(() => { sseClients.delete(res); res.end() })
    }
  }
  connection.emit = broadcast

  // 心跳：每 25s 给前端 SSE 连接发 ping（保持代理/浏览器连接存活）
  const ssePing = setInterval(() => {
    for (const res of sseClients) {
      if (res.writableEnded || res.destroyed) { sseClients.delete(res); continue }
      ctx.auth.authenticateToken(res.authToken).then(() => { if (!res.writableEnded && !res.destroyed) res.write('event: ping\ndata: {}\n\n') }).catch(() => { sseClients.delete(res); res.end() })
    }
  }, 25000)

  await servers.load()
  servers.activateAll()
  /**
   * 清单读完后再广播一次：registry 的对账依赖本清单，但它在 ctx.servers 提供时
   * 就可能开跑（早于这里的 load 完成），那时只能保守跳过。这里给它第二次机会，
   * 否则"面板显示幽灵下发"这个老问题会在这次竞争输掉后长期留存。
   */
  try {
    ctx.emit('servers/loaded', { count: servers.servers.length, trusted: servers.loaded === true })
  } catch (err) {
    // 纯通知：没有监听者、或监听者出错，都不该影响插件启动（与 push.js 的 emit 同风格）
    console.warn(`[servers] 广播 servers/loaded 失败（不影响启动）: ${err.message}`)
  }

  // ══ HTTP API（全部 admin）══
  const app = ctx.auth.access.policyApp(ctx.webServer.app, accessContract, ctx)
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]
  const manager = [ctx.auth.verifyAuth(), ctx.auth.requireServerManager()]

  // 列表（脱敏 + 连接状态）
  app.get('/api/servers', ctx.auth.verifyAuth(), ctx.auth.requireServerManager({ scope: false }), async (req, res) => {
    res.json({ servers: ctx.auth.filterServers(req.user, await servers.list()) })
  })

  // 添加（保存后自动连接）
  app.post('/api/servers', ...admin, async (req, res) => {
    try {
      const server = await servers.add(req.body || {})
      res.json({ success: true, server })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 仅测试连接（不落库）
  app.post('/api/servers/test', ...admin, async (req, res) => {
    const { host, port, token } = req.body || {}
    if (!host || !port) return res.status(400).json({ error: 'host、port 均为必填' })
    const result = await tshock.testConnectionWith(host, port, token || '')
    res.json(result)
  })

  // Reordering changes presentation only; never reconnect game servers.
  app.post('/api/servers/order', ...admin, async (req, res) => {
    try {
      const ids = req.body?.ids
      if (Array.isArray(ids)) {
        const visible = new Set(ctx.auth.filterServers(req.user, await servers.list()).map(server => server.id))
        if (ids.some(id => typeof id === 'string' && servers.getRaw(id) && !visible.has(id)))
          return res.status(403).json({ error: '无权调整该服务器的顺序' })
      }
      const list = await servers.reorder(ids)
      res.json({ success: true, servers: ctx.auth.filterServers(req.user, list) })
    } catch (err) {
      res.status(err.status || 500).json({ error: err.message })
    }
  })

  // 更新（连接参数变化自动重连）
  app.put('/api/servers/:id', ...admin, async (req, res) => {
    try {
      const server = await servers.update(req.params.id, req.body || {})
      res.json({ success: true, server })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 删除（断开连接）
  app.delete('/api/servers/:id', ...admin, async (req, res) => {
    try {
      const result = await servers.remove(req.params.id)
      res.json({ success: true, ...result })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 测试指定服务器
  app.post('/api/servers/:id/test', ...manager, async (req, res) => {
    const raw = servers.getRaw(req.params.id)
    if (!raw) return res.status(404).json({ error: '服务器不存在' })
    const result = await tshock.testConnection(req.params.id)
    res.json(result)
  })

  // ── 连接流程 API ──

  // 手动连接
  app.post('/api/servers/:id/connect', ...manager, async (req, res) => {
    const raw = servers.getRaw(req.params.id)
    if (!raw) return res.status(404).json({ error: '服务器不存在' })
    const result = await connection.connect(req.params.id, { resetRetry: true })
    res.json(result.success ? { success: true, status: result.status } : result)
  })

  // 手动断开
  app.post('/api/servers/:id/disconnect', ...manager, async (req, res) => {
    const raw = servers.getRaw(req.params.id)
    if (!raw) return res.status(404).json({ error: '服务器不存在' })
    const result = await connection.disconnect(req.params.id)
    res.json(result)
  })

  // 连接详情（状态/错误/重连/快照/事件历史）
  app.get('/api/servers/:id/connection', ...manager, async (req, res) => {
    const raw = servers.getRaw(req.params.id)
    if (!raw) return res.status(404).json({ error: '服务器不存在' })
    const inst = tshock.getServerInstance(req.params.id)
    res.json({ connection: connection.getConnectionInfo(inst) })
  })

  // ── 后端 → 前端 SSE 流（连接状态/日志/快照实时推送）──
  // EventSource 无法带 Authorization header，JWT 走 ?token= 查询参数校验
  app.get('/api/events', async (req, res) => {
    const token = (req.query && req.query.token) || ''
    if (!token) return res.status(401).json({ error: 'Missing token' })
    try {
      const user = await ctx.auth.authenticateToken(token)
      req.user = user
    } catch {
      return res.status(401).json({ error: 'Invalid token' })
    }
    if (req.query?.serverId && !ctx.auth.canAccessServer(req.user, req.query.serverId)) return res.status(403).json({ error: '无权访问该服务器' })
    res.authToken = token
    res.authUser = req.user

    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no'
    })
    res.write('event: connected\ndata: {"connected":true}\n\n')

    /**
     * 先注册 close 监听，**再**把 res 放进 sseClients——顺序不能反。
     *
     * 反过来的老写法是 `sseClients.add(res)` 之后才挂 close，中间还夹着
     * `await servers.list()` 与日志重放（都要让出事件循环）。浏览器若在这个窗口里断开，
     * close 事件**无人监听**，该 res 就永久留在 sseClients 里：随后每 25s 的
     * ssePing（见下方 setInterval）都会往一个死连接 write，集合只增不减。
     * 刷新页面几次、或反复切服，泄漏就会累积。
     *
     * 现在 close 在 join 之前就位：任何时刻断开都能被移除。写入前的
     * `res.writableEnded` 检查则挡住"已断开但仍在集合里"的少数残余窗口。
     */
    let closed = false
    const onClose = () => {
      closed = true
      sseClients.delete(res)
    }
    req.on('close', onClose)
    // 兜底：res 自身结束（服务端主动 end）也要摘掉，否则同样只增不减
    res.on('close', onClose)
    sseClients.add(res)

    // 连接建立即推送一次全量状态（前端无需再轮询）
    const list = ctx.auth.filterServers(req.user, await servers.list()).filter(server => ctx.auth.access.authorize(req.user, ctx.auth.access.action('servers.get.servers.id.connection'), server.id))
    for (const s of list) {
      // await 之后客户端可能已断开：此处必须复查，且不能再往已结束的 res 写
      if (closed || res.writableEnded) break
      res.write(`event: server.status\ndata: ${JSON.stringify({ id: s.id, status: s.status, lastError: s.lastError, connectedAt: s.connectedAt })}\n\n`)
    }
    // 带 ?serverId= 时补发该服最近日志：控制台新连接 / 切服 / 断线重连后都能看到历史
    // （照旧版语义：只重放该服、只重放最近 200 条；一次性批量下发，前端按批整体替换而非追加）
    // 同时带上 total/hasMore，前端才知道后面还有没有更早的可以上翻（见 console.js 的「加载更早」）。
    const replayId = req.query && req.query.serverId
    if (replayId && ctx.auth.access.authorize(req.user, ctx.auth.access.action('servers.get.servers.id.console.history'), replayId) && !closed && !res.writableEnded) {
      const page = connection.getLogPage(String(replayId), 0, LOG_REPLAY_LIMIT)
      if (page.logs.length) {
        res.write(`event: server.log.replay\ndata: ${JSON.stringify({
          id: String(replayId), logs: page.logs, total: page.total, hasMore: page.hasMore
        })}\n\n`)
      }
    }
  })

  // ── 控制台历史分页 ──
  // SSE 只在建连时重放最近 LOG_REPLAY_LIMIT(200) 条，更早的记录靠本接口按需翻页取。
  // 缓冲本身是每服 LOG_BUFFER_LIMIT(2000) 条，所以最多能往前翻 2000 条。
  app.get('/api/servers/:id/console/history', ...manager, (req, res) => {
    const offset = Math.max(0, Number.parseInt(req.query.offset, 10) || 0)
    const rawLimit = Number.parseInt(req.query.limit, 10) || LOG_REPLAY_LIMIT
    const limit = Math.min(500, Math.max(1, rawLimit))
    res.json(connection.getLogPage(req.params.id, offset, limit))
  })

  // Server-scoped details never depend on the browser's currently selected server.
  registerServerDetails(app, ctx.auth, servers, tshock)

  // 代理：状态（含玩家列表）
  app.get('/api/servers/:id/status', ...manager, async (req, res) => {
    const raw = servers.getRaw(req.params.id)
    if (!raw) return res.status(404).json({ error: '服务器不存在' })
    try {
      const result = await tshock.fetchFor(raw, '/v2/server/status', { players: true })
      if (result.ok) {
        tshock.getServerInstance(req.params.id) && (tshock.getServerInstance(req.params.id).isConnected = true)
        return res.json(result.data)
      }
      return res.status(result.status || 502).json({ error: `TShock REST 返回 ${result.status}`, detail: result.data })
    } catch (err) {
      const inst = tshock.getServerInstance(req.params.id)
      if (inst) { inst.isConnected = false; inst.lastError = err.message }
      res.status(502).json({ error: err.message, type: err.type || 'network' })
    }
  })

  // 世界信息的 Boss 顺序和击败标记原样保留；上游鉴权失败不使面板退出登录。
  app.get('/api/servers/:id/progress', ...manager, async (req, res) => {
    const raw = servers.getRaw(req.params.id)
    if (!raw) return res.status(404).json({ error: '服务器不存在' })
    try {
      const result = await tshock.fetchFor(raw, '/data/base/world/progress')
      const data = result.data
      if (!result.ok || data?.error || Number(data?.status) >= 400) {
        return res.status(502).json({ error: data?.error || data?.response || `读取服务器进度失败 (${data?.status || result.status})` })
      }
      if (!Array.isArray(data?.Bosses) || data.Bosses.some(boss => !boss || typeof boss.Name !== 'string' || typeof boss.Downed !== 'boolean')) {
        return res.status(502).json({ error: '服务器未返回有效的 Boss 进度，请检查游戏服插件' })
      }
      res.json(data)
    } catch (err) {
      res.status(502).json({ error: err.message })
    }
  })

  // 代理：玩家列表
  app.get('/api/servers/:id/players', ...manager, async (req, res) => {
    const raw = servers.getRaw(req.params.id)
    if (!raw) return res.status(404).json({ error: '服务器不存在' })
    try {
      const result = await tshock.fetchFor(raw, '/v2/players/list')
      if (result.ok) return res.json(result.data)
      return res.status(result.status || 502).json({ error: `TShock REST 返回 ${result.status}`, detail: result.data })
    } catch (err) {
      res.status(502).json({ error: err.message, type: err.type || 'network' })
    }
  })

  registerConsoleRoutes(app, manager, servers, tshock)

  // 代理：广播消息（TShock /v2/server/broadcast）
  app.post('/api/servers/:id/broadcast', ...manager, async (req, res) => {
    const raw = servers.getRaw(req.params.id)
    if (!raw) return res.status(404).json({ error: '服务器不存在' })
    const msg = (req.body || {}).msg
    if (!msg || !String(msg).trim()) return res.status(400).json({ error: '消息不能为空' })
    try {
      const result = await tshock.fetchFor(raw, '/v2/server/broadcast', { msg: String(msg) })
      if (result.ok) return res.json(result.data)
      return res.status(result.status || 502).json({ error: `TShock REST 返回 ${result.status}`, detail: result.data })
    } catch (err) {
      res.status(502).json({ error: err.message, type: err.type || 'network' })
    }
  })

  // ══ 终端命令 ══
  const terminal = ctx.terminal

  terminal.register('servers', '列出全部服务器（含连接状态）', async () => {
    const list = await servers.list()
    if (list.length === 0) {
      console.log('（无服务器，可用 HTTP POST /api/servers 添加）')
      return
    }
    for (const s of list) {
      const token = s.hasToken ? 'token=已配置' : 'token=未配置'
      const conn = s.status === 'connected' ? '已连接(SSE)'
        : s.status === 'degraded' ? '已连接(REST)'
        : s.status === 'connecting' ? '连接中'
        : s.status === 'reconnecting' ? `重连中(第${s.retryCount}次)`
        : s.status === 'failed' ? `失败(${s.lastError || '未知错误'})`
        : '未连接'
      console.log(`  ${s.id.slice(0, 8)}  ${s.name}  ${s.host}:${s.port}  ${token}  ${conn}`)
    }
  })

  terminal.register('server-test', '测试服务器连接（用法: server-test <id>）', async (args) => {
    const id = args && args[0]
    if (!id) {
      console.log('用法: server-test <id>（id 可用 servers 命令查看）')
      return
    }
    let raw = servers.getRaw(id)
    if (!raw) {
      // 支持短 id 前缀匹配
      const match = servers.servers.find((s) => s.id.startsWith(id))
      if (!match) { console.log(`服务器 ${id} 不存在`); return }
      raw = match
    }
    console.log(`正在测试 ${raw.name} (${raw.host}:${raw.port}) ...`)
    const result = await tshock.testConnection(raw.id)
    console.log(result.success ? `连接成功: ${result.data?.associateduser ? `token 关联用户 ${result.data.associateduser}` : 'token 有效'}` : `连接失败: ${result.error}`)
  })

  terminal.register('connect', '连接服务器（用法: connect <id>）', async (args) => {
    const id = args && args[0]
    if (!id) { console.log('用法: connect <id>（id 可用 servers 命令查看）'); return }
    let raw = servers.getRaw(id)
    if (!raw) {
      const match = servers.servers.find((s) => s.id.startsWith(id))
      if (!match) { console.log(`服务器 ${id} 不存在`); return }
      raw = match
    }
    console.log(`正在连接 ${raw.name} ...`)
    const result = await connection.connect(raw.id, { resetRetry: true })
    console.log(result.success ? `已发起连接，当前状态: ${result.status}` : `连接失败: ${result.error}`)
  })

  terminal.register('disconnect', '断开服务器（用法: disconnect <id>）', async (args) => {
    const id = args && args[0]
    if (!id) { console.log('用法: disconnect <id>（id 可用 servers 命令查看）'); return }
    let raw = servers.getRaw(id)
    if (!raw) {
      const match = servers.servers.find((s) => s.id.startsWith(id))
      if (!match) { console.log(`服务器 ${id} 不存在`); return }
      raw = match
    }
    const result = await connection.disconnect(raw.id)
    console.log(result.success ? `已断开，当前状态: ${result.status}` : `断开失败: ${result.error}`)
  })

  // ── 能力注册（P6）：把"服务器列表"作为能力暴露给 qq-bind 的能力注册表 ──
  // 旧路径 /api/bot/servers 由 qq-bind 的 legacy-http 适配器按 meta.legacy 投影，
  // 本件不需要知道自己"暴露成了哪个 URL"（见 qq-bind/docs/QQ绑定基础件设计.md §9.4）。
  //
  // 两个刻意的选择：
  //   1. 用 ctx.inject 而不是直接 ctx.get('qqBind')——插件加载顺序不保证，
  //      inject 会在 qqBind 服务**出现时**才执行回调，晚到也能补注册；
  //      宿主没装 qq-bind 时回调永不执行，本件照常工作（可选依赖，不写进 inject 数组）。
  //   2. 回调返回 off()——cordis 会把非注册器绑定到该 fiber，插件卸载或 qqBind 服务消失时
  //      自动摘除，满足"disable 后路径摘除、不残留死能力"。
  ctx.inject(['qqBind'], (ctx) => {
    const off = ctx.qqBind.registerCapability(
      'server.list',
      async () => {
        // 字段按旧机器人卡片所需给出：列表用 name/enabled/note，绑定流程还要用 id 定位服务器
        const list = await servers.list()
        return {
          servers: list.map((s) => ({
            id: s.id,
            name: s.name,
            enabled: s.enabled !== false,
            note: s.note || '',
          })),
        }
      },
      {
        legacy: { path: '/api/bot/servers', method: 'get' },
        description: '服务器列表',
      },
    )
    return off
  })

  console.log(`[servers] 服务器注册表 + TShock 代理 + 连接流程已挂载（${servers.servers.length} 台已登记，enabled=${servers.servers.filter((s) => s.enabled !== false).length} 台自动连接）`)

  /**
   * cordis 卸载本插件时的清理。
   *
   * 必须**逐台断开服务器**，不能只清 ssePing：每台服务器实例上各自带着
   * reconnectTimer（指数退避重连）、heartbeatTimer（30s REST 心跳）与
   * sseAbort（到游戏服的下行长连接），见 _startHeartbeat / _scheduleReconnect / _openSse。
   * 老写法只 clearInterval(ssePing) + 关前端 SSE，于是禁用/卸载后这些定时器**继续跑**：
   * 后台持续发 REST 请求与重连、日志继续增长，且它们持有旧实例引用无法回收；
   * 反复禁用/启用会累积。
   *
   * disconnect(id) 恰好做了全部这些清理（generation++ 让在途回调失效 + 断电 + 中断 SSE），
   * 所以直接复用，而不是在这里重写一遍（重写必然漏项）。
   */
  return () => {
    clearInterval(ssePing)

    // 先把 sseClients 收成快照：onClose 会在 res.end() 时同步改写这个集合
    const pending = [...sseClients]
    sseClients.clear()
    for (const res of pending) {
      try { res.end() } catch { /* ignore */ }
    }

    // 逐台断开：清定时器 + 中断 SSE + 状态落回 disconnected。
    // 用 allSettled：某台断开失败不该让其余服务器漏清理，也不该让卸载抛错。
    const ids = (servers.servers || []).map((s) => s.id)
    Promise.allSettled(ids.map((id) => connection.disconnect(id)))
      .then((settled) => {
        settled.forEach((r, i) => {
          if (r.status === 'rejected') {
            const why = r.reason?.message || r.reason
            console.error(`[servers] 卸载时断开 ${ids[i]} 失败（不影响卸载）: ${why}`)
          }
        })
      })
      .catch(() => { /* allSettled 不会 reject；纯兜底，清理失败不该让卸载失败 */ })
  }
}
