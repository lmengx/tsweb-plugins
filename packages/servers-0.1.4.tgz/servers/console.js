// Console business data uses authenticated TShock REST, never the Host deployment stream.
export function registerConsoleRoutes(app, manager, servers, tshock) {
  app.get('/api/servers/:id/console/logs', ...manager, async (req, res) => {
    const raw = servers.getRaw(req.params.id)
    if (!raw) return res.status(404).json({ error: '服务器不存在' })
    try {
      const result = await tshock.fetchFor(raw, '/data/base/console/logs', {
        epoch: String(req.query.epoch || ''), after: String(req.query.after || '0'),
      })
      const data = result.data
      if (!result.ok || !data || data.error || Number(data.status) >= 400) {
        const status = Number(data?.status || result.status)
        const hint = status === 404 ? '；Base.dll 日志接口尚未注册，请检查基础插件的运行状态'
          : status === 401 || status === 403 ? '；请检查 REST token 及 data.rest.invsee 权限' : ''
        return res.status(502).json({ error: `读取游戏服日志失败：${data?.error || data?.response || result.status}${hint}` })
      }
      if (!Array.isArray(data.logs) || typeof data.epoch !== 'string' || !Number.isSafeInteger(data.cursor) || data.cursor < 0) {
        return res.status(502).json({ error: '游戏服未返回有效日志，请更新并加载新版 Base.dll' })
      }
      res.json(data)
    } catch (err) { res.status(502).json({ error: `读取游戏服日志失败：${err.message}` }) }
  })

  app.post('/api/servers/:id/command', ...manager, async (req, res) => {
    const raw = servers.getRaw(req.params.id)
    if (!raw) return res.status(404).json({ error: '服务器不存在' })
    const cmd = req.body?.cmd
    if (typeof cmd !== 'string' || !cmd.trim()) return res.status(400).json({ error: '命令不能为空且必须为文本' })
    try {
      // TShock HandleCommand always removes the first character. A terminal-style
      // bare "help" must reach rawcmd as "/help", otherwise it executes "elp".
      const text = cmd.trim()
      const normalized = /^[/.]/.test(text) ? text : '/' + text
      const result = await tshock.fetchFor(raw, '/v3/server/rawcmd', { cmd: normalized })
      const data = result.data
      if (!result.ok || !data || typeof data !== 'object' || Array.isArray(data) || data.error || data.ok === false || data.success === false || Number(data.status) >= 400) {
        return res.status(502).json({ error: String(data?.error || data?.message || data?.response || `TShock 命令请求失败 (${data?.status || result.status})`) })
      }
      if (!(typeof data.response === 'string' || (Array.isArray(data.response) && data.response.every(line => typeof line === 'string')))) {
        return res.status(502).json({ error: 'TShock 未返回有效命令结果，请检查 rawcmd 接口与 REST token 权限' })
      }
      res.json(data)
    } catch (err) { res.status(502).json({ error: err.message, type: err.type || 'network' }) }
  })
}
