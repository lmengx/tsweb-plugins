// Module permissions authorize both UI features and their backend routes.
export default {
  "owner": "servers",
  "version": 2,
  "modules": [
    {
      "id": "servers.common",
      "permission": "servers.module.common",
      "title": "服务器列表与事件通道",
      "roles": [
        "superadmin",
        "admin",
        "subadmin",
        "custom"
      ],
      "scope": "global",
      "requires": [
        "servers.get.servers",
        "servers.get.events"
      ],
      "grantable": false
    },
    {
      "id": "servers.manage",
      "permission": "servers.module.manage",
      "title": "服务器配置管理",
      "roles": [
        "superadmin"
      ],
      "scope": "global",
      "requires": [
        "servers.post.servers",
        "servers.post.servers.test",
        "servers.put.servers.id",
        "servers.delete.servers.id",
        "servers.post.servers.order"
      ]
    },
    {
      "id": "servers.operate",
      "permission": "servers.module.operate",
      "title": "服务器运行管理",
      "roles": [
        "superadmin",
        "admin",
        "subadmin"
      ],
      "scope": "server",
      "requires": [
        "servers.post.servers.id.test",
        "servers.post.servers.id.connect",
        "servers.post.servers.id.disconnect",
        "servers.get.servers.id.connection",
        "servers.get.servers.id.console.history",
        "servers.get.servers.id.console.logs",
        "servers.get.servers.id.status",
        "servers.get.servers.id.progress",
        "servers.get.servers.id.players",
        "servers.post.servers.id.command",
        "servers.post.servers.id.broadcast",
        "servers.get.servers.id.details"
      ]
    }
  ],
  "actions": [
    {
      "id": "servers.post.servers.order",
      "method": "POST",
      "path": "/api/servers/order",
      "scope": "global",
      "module": "servers.manage"
    },
    {
      "id": "servers.get.servers.id.console.logs",
      "method": "GET",
      "path": "/api/servers/:id/console/logs",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.operate"
    },
    {
      "id": "servers.get.servers",
      "method": "GET",
      "path": "/api/servers",
      "scope": "global",
      "module": "servers.common"
    },
    {
      "id": "servers.post.servers",
      "method": "POST",
      "path": "/api/servers",
      "scope": "global",
      "module": "servers.manage"
    },
    {
      "id": "servers.post.servers.test",
      "method": "POST",
      "path": "/api/servers/test",
      "scope": "global",
      "module": "servers.manage"
    },
    {
      "id": "servers.put.servers.id",
      "method": "PUT",
      "path": "/api/servers/:id",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.manage"
    },
    {
      "id": "servers.delete.servers.id",
      "method": "DELETE",
      "path": "/api/servers/:id",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.manage"
    },
    {
      "id": "servers.post.servers.id.test",
      "method": "POST",
      "path": "/api/servers/:id/test",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.operate"
    },
    {
      "id": "servers.post.servers.id.connect",
      "method": "POST",
      "path": "/api/servers/:id/connect",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.operate"
    },
    {
      "id": "servers.post.servers.id.disconnect",
      "method": "POST",
      "path": "/api/servers/:id/disconnect",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.operate"
    },
    {
      "id": "servers.get.servers.id.connection",
      "method": "GET",
      "path": "/api/servers/:id/connection",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.operate"
    },
    {
      "id": "servers.get.events",
      "method": "GET",
      "path": "/api/events",
      "scope": "global",
      "transport": "sse",
      "module": "servers.common"
    },
    {
      "id": "servers.get.servers.id.console.history",
      "method": "GET",
      "path": "/api/servers/:id/console/history",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.operate"
    },
    {
      "id": "servers.get.servers.id.status",
      "method": "GET",
      "path": "/api/servers/:id/status",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.operate"
    },
    {
      "id": "servers.get.servers.id.progress",
      "method": "GET",
      "path": "/api/servers/:id/progress",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.operate"
    },
    {
      "id": "servers.get.servers.id.players",
      "method": "GET",
      "path": "/api/servers/:id/players",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.operate"
    },
    {
      "id": "servers.post.servers.id.command",
      "method": "POST",
      "path": "/api/servers/:id/command",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.operate"
    },
    {
      "id": "servers.post.servers.id.broadcast",
      "method": "POST",
      "path": "/api/servers/:id/broadcast",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.operate"
    },
    {
      "id": "servers.get.servers.id.details",
      "method": "GET",
      "path": "/api/servers/:id/details",
      "scope": "server",
      "serverParam": "id",
      "module": "servers.operate"
    }
  ],
  "features": []
}
