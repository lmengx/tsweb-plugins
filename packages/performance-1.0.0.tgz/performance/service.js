import { performance } from 'node:perf_hooks';
const error = (status, message) => Object.assign(new Error(message), { status });
const reads = new Set(['status', 'history', 'events', 'event', 'probe']);
const writes = new Set(['capture', 'marker', 'profile']);
export function parameters(operation, input = {}) {
  if (operation === 'history') {
    const after = Number(input.after ?? 0);
    if (!Number.isSafeInteger(after) || after < 0) throw error(400, '采样序号无效');
    return { after };
  }
  if (operation === 'event') {
    if (!/^[a-f0-9]{32}$/i.test(input.id || '')) throw error(400, '记录编号无效');
    return { id: input.id };
  }
  if (operation === 'capture' || operation === 'marker') {
    const key = operation === 'capture' ? 'label' : 'text';
    const text = input[key] ?? (operation === 'capture' ? '手动采集' : '');
    if (typeof text !== 'string' || !text.trim() || text.length > 160) throw error(400, '请填写 1 至 160 个字符');
    return { [key]: text.trim() };
  }
  if (operation === 'profile') {
    if (input.stop === true) return { stop: 'true' };
    const seconds = input.seconds ?? 30;
    if (!Number.isInteger(seconds) || seconds < 5 || seconds > 120) throw error(400, '采集时间为 5 至 120 秒');
    return { seconds };
  }
  return {};
}
export class PerformanceService {
  constructor(ctx) { this.ctx = ctx; this.disposed = false; this.active = new Map(); }
  dispose() { this.disposed = true; this.active.clear(); }
  async call(id, operation, input, signal) {
    if (this.disposed) throw error(503, '性能诊断已停用');
    signal?.throwIfAborted();
    if (!reads.has(operation) && !writes.has(operation)) throw error(404, '操作不存在');
    if (typeof id !== 'string' || !id) throw error(400, '请先选择服务器');
    const server = this.ctx.servers.getRaw(id);
    if (!server) throw error(404, '服务器不存在');
    const params = parameters(operation, input);
    const pending = this.active.get(id) || 0;
    if (pending >= 4) throw error(429, '诊断请求较多，请稍后重试');
    this.active.set(id, pending + 1);
    const started = performance.now();
    try {
      const result = await this.ctx.tshock[writes.has(operation) ? 'postFor' : 'fetchFor'](
        server, '/data/performance/' + operation, params, { timeoutMs: 5000 });
      signal?.throwIfAborted();
      if (this.disposed) throw error(503, '性能诊断已停用');
      const data = result.data, status = Number(data?.status || result.status);
      if (status === 404) throw error(operation === 'event' ? 404 : 501,
        operation === 'event' ? '记录不存在或已过期' : '游戏服尚未启用性能诊断，请检查插件同步状态');
      if (status === 401 || status === 403) throw error(502, '游戏服令牌缺少 tsweb.performance.read 或 tsweb.performance.capture 权限');
      if (!result.ok || status >= 400 || !data || data.error) throw error([400, 409, 429, 503, 504].includes(status) ? status : 502, data?.error || '读取性能数据失败');
      if (operation === 'status' && (data.schema !== 1 || !Array.isArray(data.capabilities))) throw error(502, '游戏服性能数据格式不兼容');
      if (operation === 'history' && (!Array.isArray(data.samples) || data.samples.length > 600)) throw error(502, '历史数据格式无效');
      if (operation === 'events' && (!Array.isArray(data.events) || data.events.length > 121)) throw error(502, '记录列表格式无效');
      return { ...data, transport: { backendRoundTripMs: performance.now() - started,
        source: 'cordis-game-rest', measuredAt: Date.now(), includesQueue: operation === 'probe' } };
    } catch (err) {
      signal?.throwIfAborted();
      if (err.status) throw err;
      throw error(502, '连接游戏服失败：' + err.message);
    } finally {
      const count = (this.active.get(id) || 1) - 1;
      if (count <= 0) this.active.delete(id); else this.active.set(id, count);
    }
  }
}
