<script setup>
import { computed, ref } from 'vue';
const props=defineProps({samples:Array,field:{type:String,default:'frame'},label:String,unit:{type:String,default:'ms'},color:{type:String,default:'var(--accent)'},ceiling:Number,threshold:Number,compact:Boolean,annotation:Boolean,hoverIndex:Number,minutes:{type:Number,default:5},eventTime:{type:String,default:'14:32:18'},annotationText:{type:String,default:'更新异常'}});
const emit=defineEmits(['hover','inspect']);
const own=ref(null),index=computed(()=>props.hoverIndex??own.value),w=800,h=computed(()=>props.compact?108:185),pad=8;
const max=computed(()=>props.ceiling||Math.max(1,...props.samples.map(s=>s[props.field]))*1.2);
const point=(s,i)=>[pad+i/(props.samples.length-1)*(w-pad*2),h.value-pad-(s[props.field]/max.value)*(h.value-pad*2)];
const line=computed(()=>props.samples.map((s,i)=>point(s,i).join(',')).join(' '));
const fill=computed(()=>`${pad},${h.value} ${line.value} ${w-pad},${h.value}`);
const picked=computed(()=>index.value==null?null:props.samples[Math.min(props.samples.length-1,Math.max(0,index.value))]);
const ticks=computed(()=>{const parts=props.eventTime.split(':').map(Number),end=parts[0]*3600+parts[1]*60+parts[2]+42;return Array.from({length:6},(_,i)=>{const t=((end-props.minutes*60*(1-i/5))%86400+86400)%86400;return `${String(Math.floor(t/3600)).padStart(2,'0')}:${String(Math.floor(t%3600/60)).padStart(2,'0')}`;});});
function move(e){const box=e.currentTarget.getBoundingClientRect();const i=Math.round((e.clientX-box.left)/box.width*(props.samples.length-1));own.value=Math.max(0,Math.min(props.samples.length-1,i));emit('hover',own.value);}
function leave(){own.value=null;emit('hover',null);}
</script>
<template><div class="chart" :class="{compact}">
  <div class="chart-y"><span>{{ max.toFixed(0) }}</span><span>{{ (max/2).toFixed(0) }}</span><span>0</span></div>
  <div class="chart-canvas" @pointermove="move" @pointerleave="leave" @click="emit('inspect')">
    <svg :viewBox="`0 0 ${w} ${h}`" preserveAspectRatio="none" role="img" :aria-label="`${label}趋势，${unit}`">
      <path v-for="n in [0,1,2]" :key="n" :d="`M0 ${pad+n*(h-pad*2)/2}H${w}`" class="chart-grid"/>
      <rect v-if="annotation" :x="pad+(1-.95/minutes)*(w-pad*2)" y="0" :width="(w-pad*2)*.5/minutes" :height="h" fill="var(--danger)" opacity=".055"/>
      <polyline :points="fill" :fill="color" fill-opacity=".065" stroke="none"/>
      <line v-if="threshold&&threshold<=max" :x1="0" :x2="w" :y1="h-pad-threshold/max*(h-pad*2)" :y2="h-pad-threshold/max*(h-pad*2)" stroke="var(--warning)" stroke-width="1" stroke-dasharray="4 6" vector-effect="non-scaling-stroke"/>
      <polyline :points="line" :stroke="color" fill="none" stroke-width="1.8" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>
      <template v-if="picked"><line :x1="point(picked,index)[0]" :x2="point(picked,index)[0]" y1="0" :y2="h" stroke="var(--muted)" stroke-width="1" stroke-dasharray="3 4"/><circle :cx="point(picked,index)[0]" :cy="point(picked,index)[1]" r="3.5" :fill="color"/></template>
    </svg>
    <span v-if="annotation&&!compact" class="chart-annotation" @click.stop="emit('inspect')">{{ eventTime }} · {{ annotationText }}</span>
    <div v-if="picked" class="chart-tooltip" :style="{left:`${Math.max(8,Math.min(72,index/(samples.length-1)*100))}%`}"><b>{{ label }}</b><span>{{ picked[field].toFixed(1) }} {{ unit }}</span></div>
    <div class="chart-x"><span v-for="(tick,i) in ticks" :key="i">{{ tick }}</span></div>
  </div>
</div></template>
