<script setup>
import { callbacks } from './data.js';
import Icon from './Icon.vue';
defineProps({compact:Boolean});defineEmits(['select']);
</script>
<template><div class="callback-list"><div class="table-labels"><span>插件 / 回调</span><span>累计耗时</span></div><button v-for="(p,i) in callbacks" :key="p.name" class="callback-row" @click="$emit('select',p)"><span class="rank">{{ String(i+1).padStart(2,'0') }}</span><span class="callback-name"><b>{{ p.name }}</b><small>{{ p.op }} · {{ p.calls.toLocaleString() }} 次</small></span><span class="callback-meter"><i :style="{width:p.ms/184.2*100+'%'}"></i></span><span class="callback-value">{{ p.ms }} <small>ms</small></span><Icon name="chevron" :size="14"/></button><p class="footnote">经过时间包含嵌套调用；不代表 CPU 占用，不能直接相加。</p></div></template>
