# 性能诊断：三种界面提案

三个可以直接操作的 Vue 原型，使用相同的模拟场景比较布局与排查方式。没有替换正式性能页，也不会调用生产 API、启动真实采集、读取账户信息或重启游戏服。

## 本机预览

- A 清爽总览：`http://localhost:3000/plugins/performance/demo/index.html#pulse`
- B 实时监控台：`http://localhost:3000/plugins/performance/demo/index.html#signal`
- C 事件调查室：`http://localhost:3000/plugins/performance/demo/index.html#lens`

顶部可随时切换三个方向。可操作时间范围、正常/卡顿/网络场景、暂停刷新、手动留档、详情弹窗、JSON 导出和短时分析倒计时。手机有独立功能导航和事件选择器。

| 方向 | 布局 | 适合用途 |
| --- | --- | --- |
| A 清爽总览 | 浅色紫色强调；四项健康指标、主图、近期事件、回调和网络排行 | 默认入口、日常巡检 |
| B 实时监控台 | 石墨深色橙色强调；高密度指标、四图对齐、事件带、运行时统计 | 连续观察、复现卡顿、对照多个信号 |
| C 事件调查室 | 蓝色强调；事件收件箱、同步时间线、右侧证据和下一步 | 从一次异常展开调查 |

建议最终以 A 做日常入口，采用 C 的事件详情组织方式；B 可作为密集监控模式。

## 参考来源

2026-10-19 检查了以下开源项目的官方 README / 文档，并参考本项目现有 `plugins/apm/ui/Browser.vue`、`client/theme.css` 和投票插件 demo 的宿主集成方式。

- [Grafana](https://github.com/grafana/grafana)：参考仪表盘的统一时间范围、指标面板和图表并置。官方 README 的 Visualizations / Dynamic Dashboards 为设计依据。
- [SigNoz](https://github.com/SigNoz/signoz)：参考将指标、日志和追踪上下文用于排障的组织思路，转化为事件列表、上下文图表与调查线索。
- [Netdata](https://github.com/netdata/netdata)：参考逐秒监控、资源健康信息和即时异常入口。其当前 UI 与 agent 许可不同；此处仅借鉴信息组织，没有使用其 UI 源码或素材。

三套界面均为本项目原创实现，未复制外部项目代码、品牌或截图。参考链接也在页面右上角信息按钮内。

## 数据边界

- 全部指标、玩家、事件和回调均为固定演示数据；切换场景仅改变本地展示。
- 图表固定在演示时刻附近，时间范围可变。事件上下文图表与 61 秒原始留档窗口分开标注；原型没有实现真实逐帧回放。
- 暂停只冻结演示同步状态；分析按钮只启动 15 秒倒计时；手动留档只保留在页面内存，刷新后消失。
- 导出 JSON 包含 `demo: true`；图表序列是模拟上下文，不能用于真实故障结论。
- 游戏包发送统计不含 TCP/IP 开销和重传；TCP RTT 不等于游戏处理延迟。
- 插件回调为包含嵌套调用的经过时间，不是 CPU 使用量；相关性不等于根因。

## 构建与检查

在仓库根目录运行：

```powershell
node plugins/performance/demo/build.mjs
node --test plugins/performance/demo/test.mjs
```

`dist/` 为构建产物，沿用仓库忽略规则；部署或重新检出后须构建。本机运行中的面板会直接提供此目录，无需重启服务。

浏览器检查使用 Edge 与 Playwright，默认从本机 Codex runtime 查找 Playwright，也支持 `TSWEB_PLAYWRIGHT_PATH`。检查会起临时本地静态服务器，不依赖生产后台；生成桌面 1440px、手机 390px / 320px 的九张截图到 `tmp/performance-demo/`，验证功能导航、场景、时间轴、弹窗、导出、倒计时，以及没有生产 API 请求。
