import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import express from 'express';

test('three performance design demos: responsive layouts and local interactions',{timeout:90000},async t=>{
  const modulePath=process.env.TSWEB_PLAYWRIGHT_PATH||path.join(process.env.USERPROFILE||'','.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs');
  let chromium;try{({chromium}=await import(pathToFileURL(modulePath).href));}catch{t.skip('Set TSWEB_PLAYWRIGHT_PATH to enable browser QA');return;}
  await import('./build.mjs');
  const app=express();app.get('/vendor/vue.js',(_,res)=>res.sendFile(path.resolve('node_modules/vue/dist/vue.esm-browser.prod.js')));app.use('/plugins/performance/demo',express.static(path.resolve('plugins/performance/demo')));
  const server=await new Promise(resolve=>{const s=app.listen(0,'127.0.0.1',()=>resolve(s));});
  const browser=await chromium.launch({channel:'msedge',headless:true});
  t.after(async()=>{await browser.close();await new Promise(resolve=>server.close(resolve));});
  const out=path.resolve('tmp/performance-demo');await mkdir(out,{recursive:true});
  const errors=[],requests=[];
  for(const width of [1440,390,320])for(const design of ['pulse','signal','lens']){
    const page=await browser.newPage({viewport:{width,height:1000},acceptDownloads:true});
    page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(new URL(r.url()).pathname.startsWith('/api/'))requests.push(r.url());});
    await page.goto(`http://127.0.0.1:${server.address().port}/plugins/performance/demo/index.html#${design}`);
    await page.locator(`.demo-app.${design}`).waitFor();
    const navigate=async name=>page.locator(width<800?'.mobile-nav':'.sidebar').getByRole('button',{name,exact:true}).click();
    const overflow=async label=>assert.ok(await page.evaluate(()=>document.body.scrollWidth<=innerWidth+1),`${design}/${width}/${label} horizontal overflow`);
    await overflow('overview');await page.screenshot({path:path.join(out,`${design}-${width}.png`),fullPage:true});
    for(const name of ['网络与玩家','卡顿记录','深度诊断','性能概览']){await navigate(name);await overflow(name);}
    if(width===1440){
      await page.getByRole('combobox',{name:'时间范围',exact:true}).selectOption('15');assert.equal(await page.locator('.chart-x').first().innerText(),'14:18\n14:21\n14:24\n14:27\n14:30\n14:33');
      await page.getByRole('combobox',{name:'时间范围',exact:true}).selectOption('60');assert.match(await page.locator('.chart-x').first().innerText(),/^13:33/);
      await page.getByRole('combobox',{name:'时间范围',exact:true}).selectOption('5');
      await page.getByRole('combobox',{name:'演示场景',exact:true}).selectOption('network');await page.waitForTimeout(30);assert.match(await page.locator('.scenario-toolbar').innerText(),/连接延迟上升/);
      if(design==='lens'){assert.match(await page.locator('.case-detail-heading').innerText(),/发送流量突增/);await page.getByRole('button',{name:'插件回调',exact:true}).click();await page.locator('.case-tab-panel .callback-row').first().click();}
      else await page.locator('.callback-row').first().click();
      await page.getByRole('dialog').waitFor();assert.match(await page.getByRole('dialog').innerText(),/WorldTools/);await page.keyboard.press('Escape');assert.equal(await page.getByRole('dialog').count(),0);
      await page.getByRole('button',{name:'查看设计参考',exact:true}).click();await page.getByRole('dialog').waitFor();assert.equal(await page.locator('.modal a').count(),3);await page.keyboard.press('Escape');
      await page.getByRole('button',{name:'暂停刷新',exact:true}).click();assert.match(await page.locator('.scenario-toolbar').innerText(),/已暂停/);await page.getByRole('button',{name:'继续刷新',exact:true}).click();
      await page.getByRole('button',{name:'保留现场',exact:true}).click();await navigate('卡顿记录');assert.equal(await page.locator('.event-card').count(),4);await page.locator('.event-card').first().click();
      const download=page.waitForEvent('download');await page.getByRole('button',{name:'导出 JSON',exact:true}).click();const downloaded=await download;const report=JSON.parse(await readFile(await downloaded.path(),'utf8'));assert.equal(report.demo,true);assert.equal(report.incident.id,'DEMO-001');await page.keyboard.press('Escape');
      await navigate('深度诊断');await page.getByRole('button',{name:'开始 15 秒演示分析',exact:true}).click();await page.getByRole('button',{name:/剩余 \d+s · 停止/}).waitFor();await page.getByRole('button',{name:/剩余 \d+s · 停止/}).click();await page.getByRole('button',{name:'开始 15 秒演示分析',exact:true}).waitFor();
      await page.locator('.reviewbar nav button').filter({hasText:'事件调查室'}).click();await page.locator('.demo-app.lens .case-rail').waitFor();
    }else if(design==='lens'){
      await page.getByRole('combobox',{name:'选择事件',exact:true}).selectOption('INC-023');assert.match(await page.locator('.case-detail-heading').innerText(),/发送流量突增/);
    }
    await page.close();
  }
  assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
  await writeFile(path.join(out,'verification.json'),JSON.stringify({layouts:9,widths:[1440,390,320],pageErrors:errors,productionApiCalls:requests,interactions:'passed'},null,2));
  console.log('9 layouts passed; navigation, time ranges, scenarios, focus/escape, capture/export, profile, design switching and zero production API calls.');
});
