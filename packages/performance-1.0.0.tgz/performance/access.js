const groups = {
  read: ["status", "history", "events", "event", "probe"],
  capture: ["capture", "marker", "profile"],
};
const actions = Object.entries(groups).flatMap(([group, endpoints]) => endpoints.map(endpoint => ({
  id: `performance.api.${endpoint}`, module: `performance.${group}`, scope: "server",
  method: group === "read" ? "GET" : "POST", path: `/api/performance/${endpoint}`,
})));
export default {
  owner: "performance", version: 2,
  modules: Object.keys(groups).map(group => ({
    id: `performance.${group}`, permission: `performance.${group}`,
    title: group === "read" ? "性能诊断查看" : "性能采集与标记",
    roles: ["superadmin", "admin", "subadmin"], scope: "server",
    requires: actions.filter(a => a.module === `performance.${group}` || group === "capture" && a.module === "performance.read").map(a => a.id),
  })), actions,
  features: Object.keys(groups).map(group => ({
    id: `performance:${group}`, module: `performance.${group}`,
    requires: actions.filter(a => a.module === `performance.${group}` || group === 'capture' && a.module === 'performance.read').map(a => a.id),
  })),
};
