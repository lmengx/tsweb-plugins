const revision = new URL(import.meta.url).search;
const { default: access } = await import(`./access.js${revision}`);
const { PerformanceService } = await import(`./service.js${revision}`);
export const name = 'performance';
export const inject = ['webServer', 'auth', 'servers', 'tshock'];
export function apply(ctx) {
  try {
    const service = new PerformanceService(ctx), controllers = new Set();
    const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx);
    ctx.on('dispose', () => { service.dispose(); for (const c of controllers) c.abort(); });
    const handler = operation => async (req, res) => {
      const controller = new AbortController(); controllers.add(controller);
      const close = () => { if (!res.writableFinished) controller.abort(); };
      res.on('close', close);
      try {
        const id = req.headers['x-server-id'] || req.query?.serverId || req.user?.serverId || req.user?.extraServerIds?.[0];
        const data = await service.call(id, operation, req.method === 'GET' ? req.query : req.body, controller.signal);
        if (!res.destroyed) res.json(data);
      } catch (err) {
        if (!res.headersSent && !res.destroyed) res.status(err.status || 502).json({ error: err.message });
      } finally { controllers.delete(controller); res.off('close', close); }
    };
    app.get('/api/performance/status', handler('status'));
    app.get('/api/performance/history', handler('history'));
    app.get('/api/performance/events', handler('events'));
    app.get('/api/performance/event', handler('event'));
    app.get('/api/performance/probe', handler('probe'));
    app.post('/api/performance/capture', handler('capture'));
    app.post('/api/performance/marker', handler('marker'));
    app.post('/api/performance/profile', handler('profile'));
  } catch (err) { console.error('[performance] 初始化失败：' + err.message); throw err; }
}
