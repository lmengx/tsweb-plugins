// Module permissions authorize both UI features and their backend routes.
export default {
  "owner": "task-scheduler",
  "version": 2,
  "modules": [
    {
      "id": "task-scheduler.tasks",
      "permission": "task-scheduler.ui.tasks",
      "title": "自动任务",
      "roles": [
        "superadmin",
        "admin",
        "subadmin"
      ],
      "scope": "server",
      "requires": [
        "task-scheduler.get.task.scheduler.tasks.list",
        "task-scheduler.get.task.scheduler.tasks.get",
        "task-scheduler.post.task.scheduler.tasks.save",
        "task-scheduler.post.task.scheduler.tasks.delete",
        "task-scheduler.post.task.scheduler.tasks.run",
        "task-scheduler.get.task.scheduler.tasks.log",
        "task-scheduler.get.task.scheduler.tasks.logs",
        "task-scheduler.get.task.scheduler.tasks.log.detail",
        "task-scheduler.get.task.scheduler.tasks.logs.detail",
        "task-scheduler.get.task.scheduler.status",
        "task-scheduler.post.task.scheduler.push",
        "task-scheduler.post.task.scheduler.adopt",
        "task-scheduler.get.task.scheduler.audit"
      ]
    }
  ],
  "actions": [
    {
      "id": "task-scheduler.get.task.scheduler.tasks.list",
      "method": "GET",
      "path": "/api/task-scheduler/tasks/list",
      "scope": "server",
      "module": "task-scheduler.tasks"
    },
    {
      "id": "task-scheduler.get.task.scheduler.tasks.get",
      "method": "GET",
      "path": "/api/task-scheduler/tasks/get",
      "scope": "server",
      "module": "task-scheduler.tasks"
    },
    {
      "id": "task-scheduler.post.task.scheduler.tasks.save",
      "method": "POST",
      "path": "/api/task-scheduler/tasks/save",
      "scope": "server",
      "module": "task-scheduler.tasks"
    },
    {
      "id": "task-scheduler.post.task.scheduler.tasks.delete",
      "method": "POST",
      "path": "/api/task-scheduler/tasks/delete",
      "scope": "server",
      "module": "task-scheduler.tasks"
    },
    {
      "id": "task-scheduler.post.task.scheduler.tasks.run",
      "method": "POST",
      "path": "/api/task-scheduler/tasks/run",
      "scope": "server",
      "module": "task-scheduler.tasks"
    },
    {
      "id": "task-scheduler.get.task.scheduler.tasks.log",
      "method": "GET",
      "path": "/api/task-scheduler/tasks/log",
      "scope": "server",
      "module": "task-scheduler.tasks"
    },
    {
      "id": "task-scheduler.get.task.scheduler.tasks.logs",
      "method": "GET",
      "path": "/api/task-scheduler/tasks/logs",
      "scope": "server",
      "module": "task-scheduler.tasks"
    },
    {
      "id": "task-scheduler.get.task.scheduler.tasks.log.detail",
      "method": "GET",
      "path": "/api/task-scheduler/tasks/log/detail",
      "scope": "server",
      "module": "task-scheduler.tasks"
    },
    {
      "id": "task-scheduler.get.task.scheduler.tasks.logs.detail",
      "method": "GET",
      "path": "/api/task-scheduler/tasks/logs/detail",
      "scope": "server",
      "module": "task-scheduler.tasks"
    },
    {
      "id": "task-scheduler.get.task.scheduler.status",
      "method": "GET",
      "path": "/api/task-scheduler/status",
      "scope": "server",
      "module": "task-scheduler.tasks"
    },
    {
      "id": "task-scheduler.post.task.scheduler.push",
      "method": "POST",
      "path": "/api/task-scheduler/push",
      "scope": "server",
      "module": "task-scheduler.tasks"
    },
    {
      "id": "task-scheduler.post.task.scheduler.adopt",
      "method": "POST",
      "path": "/api/task-scheduler/adopt",
      "scope": "server",
      "module": "task-scheduler.tasks"
    },
    {
      "id": "task-scheduler.get.task.scheduler.audit",
      "method": "GET",
      "path": "/api/task-scheduler/audit",
      "scope": "server",
      "module": "task-scheduler.tasks"
    }
  ],
  "features": [
    {
      "id": "task-scheduler:tasks",
      "module": "task-scheduler.tasks",
      "requires": [
        "task-scheduler.get.task.scheduler.tasks.list",
        "task-scheduler.get.task.scheduler.tasks.get",
        "task-scheduler.post.task.scheduler.tasks.save",
        "task-scheduler.post.task.scheduler.tasks.delete",
        "task-scheduler.post.task.scheduler.tasks.run",
        "task-scheduler.get.task.scheduler.tasks.log",
        "task-scheduler.get.task.scheduler.tasks.logs",
        "task-scheduler.get.task.scheduler.tasks.log.detail",
        "task-scheduler.get.task.scheduler.tasks.logs.detail",
        "task-scheduler.get.task.scheduler.status",
        "task-scheduler.post.task.scheduler.push",
        "task-scheduler.post.task.scheduler.adopt",
        "task-scheduler.get.task.scheduler.audit"
      ]
    }
  ]
}
