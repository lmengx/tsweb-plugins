const actions = [
  ["summary", "GET", "summary"],
  ["list", "GET", "list"],
  ["users", "GET", "users"],
  ["grant", "POST", "grant"],
  ["grant-batch", "POST", "grant-batch"],
  ["revoke", "POST", "revoke"],
  ["revoke-batch", "POST", "revoke-batch"],
  ["cleanup", "POST", "cleanup"],
  ["audit", "GET", "audit"],
].map(([id, method, suffix]) => ({
  id: `personal-permissions.${id}`,
  method,
  path: `/api/personal-permissions/${suffix}`,
  module: "personal-permissions.manage",
  scope: "server",
}));
export default {
  owner: "personal-permissions",
  version: 2,
  modules: [
    {
      id: "personal-permissions.manage",
      permission: "personal-permissions.manage",
      title: "个人权限",
      roles: ["superadmin", "admin"],
      scope: "server",
      requires: actions.map((a) => a.id),
    },
  ],
  actions,
  features: [
    {
      id: "personal-permissions:manage",
      module: "personal-permissions.manage",
      requires: actions.map((a) => a.id),
    },
  ],
};
