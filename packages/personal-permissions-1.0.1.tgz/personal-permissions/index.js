const revision = new URL(import.meta.url).search;
const { default: access } = await import(`./access.js${revision}`);
const {
  PersonalPermissionService,
  playerName,
  permissionName,
  grantParams,
  uniqueList,
  exactPairs,
  fail,
} = await import(`./service.js${revision}`);
export const name = "personal-permissions";
export const inject = ["webServer", "auth", "servers", "tshock", "paths"];
export function apply(ctx) {
  try {
    const service = new PersonalPermissionService(ctx, ctx.paths.dataOf(name));
    const controllers = new Set();
    ctx.on("dispose", () => {
      service.disposed = true;
      for (const c of controllers) c.abort();
    });
    const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx);
    const route = (handler) => async (req, res) => {
      const c = new AbortController();
      controllers.add(c);
      const close = () => {
        if (!res.writableFinished) c.abort();
      };
      res.on("close", close);
      try {
        const data = await handler(req, c.signal);
        if (!res.destroyed) res.json(data);
      } catch (err) {
        if (!res.headersSent && !res.destroyed)
          res.status(err.status || 502).json({ error: err.message });
      } finally {
        controllers.delete(c);
        res.off("close", close);
      }
    };
    const server = (req) => req.headers["x-server-id"];
    const actor = (req) => String(req.user?.username || "面板管理员");
    app.get(
      "/api/personal-permissions/summary",
      route((req, signal) => service.call(server(req), "summary", {}, signal)),
    );
    app.get(
      "/api/personal-permissions/list",
      route((req, signal) => service.call(server(req), "list", {}, signal)),
    );
    app.get(
      "/api/personal-permissions/users",
      route((req, signal) => service.call(server(req), "users", {}, signal)),
    );
    app.get(
      "/api/personal-permissions/audit",
      route((req) => service.audit(server(req))),
    );
    app.post(
      "/api/personal-permissions/grant",
      route((req, signal) =>
        service.mutate(
          server(req),
          "grant",
          {
            ...grantParams(req.body, actor(req)),
            player: playerName(req.body?.player),
            permission: permissionName(req.body?.permission),
          },
          actor(req),
          signal,
        ),
      ),
    );
    app.post(
      "/api/personal-permissions/grant-batch",
      route((req, signal) => {
        const common = grantParams(req.body, actor(req));
        const players = uniqueList(req.body?.players, playerName, 100),
          permissions = uniqueList(req.body?.permissions, permissionName, 100);
        if (players.length * permissions.length > 1000)
          throw fail(400, "一次最多签发 1000 条权限");
        return service.mutate(
          server(req),
          "grant-batch",
          {
            ...common,
            players: JSON.stringify(players),
            permissions: JSON.stringify(permissions),
          },
          actor(req),
          signal,
        );
      }),
    );
    app.post(
      "/api/personal-permissions/revoke",
      route((req, signal) =>
        service.mutate(
          server(req),
          "revoke",
          {
            player: playerName(req.body?.player),
            permission: permissionName(req.body?.permission),
          },
          actor(req),
          signal,
        ),
      ),
    );
    app.post(
      "/api/personal-permissions/revoke-batch",
      route((req, signal) =>
        service.mutate(
          server(req),
          "revoke-batch",
          {
            items: JSON.stringify(exactPairs(req.body?.items)),
          },
          actor(req),
          signal,
        ),
      ),
    );
    app.post(
      "/api/personal-permissions/cleanup",
      route((req, signal) =>
        service.mutate(server(req), "cleanup", {}, actor(req), signal),
      ),
    );
  } catch (err) {
    console.error("[personal-permissions] 初始化失败：" + err.message);
    throw err;
  }
}
