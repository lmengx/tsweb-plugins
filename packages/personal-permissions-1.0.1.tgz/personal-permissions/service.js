import fs from "node:fs/promises";
import path from "node:path";
import { createReadStream } from "node:fs";
import { createInterface } from "node:readline";
export const fail = (status, message) =>
  Object.assign(new Error(message), { status });
const banned = new Set([
  "tshock.su",
  "tshock.superadmin.user",
  "tshock.admin.group",
  "tshock.admin.tempgroup",
]);
function text(value, label, max) {
  if (
    typeof value !== "string" ||
    !value.trim() ||
    value.trim().length > max ||
    /[\x00-\x1f]/.test(value)
  )
    throw fail(400, `${label}为空、过长或包含无效字符`);
  return value.trim();
}
export const playerName = (v) => text(v, "玩家名", 64);
export function permissionName(v) {
  const name = text(v, "权限名", 191);
  if (
    /[*,\s]/.test(name) ||
    name.startsWith("!") ||
    banned.has(name.toLowerCase())
  )
    throw fail(400, "不能签发通配、否定或敏感权限");
  return name;
}
export function expiry(body, now = Date.now()) {
  if (body.expireAt && body.expiresIn !== undefined && body.expiresIn !== "")
    throw fail(400, "到期时间和有效时长不能同时设置");
  if (body.expiresIn !== undefined && body.expiresIn !== "") {
    const seconds = Number(body.expiresIn);
    if (
      !["number", "string"].includes(typeof body.expiresIn) ||
      !Number.isSafeInteger(seconds) ||
      seconds <= 0 ||
      seconds > 315360000
    )
      throw fail(400, "有效时长须大于零且不超过十年");
    return { expiresIn: String(seconds) };
  }
  if (body.expireAt !== undefined && body.expireAt !== "") {
    const value = String(body.expireAt);
    if (
      !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/.test(value) ||
      !Number.isFinite(Date.parse(value)) ||
      Date.parse(value) <= now
    )
      throw fail(400, "到期时间须为有效的未来时间");
    return { expireAt: value };
  }
  return {};
}
export function grantParams(body, actor) {
  if (!body || Array.isArray(body)) throw fail(400, "签发信息无效");
  const note = body.note ?? "";
  if (typeof note !== "string" || note.length > 255)
    throw fail(400, "备注不能超过 255 字符");
  return { note, grantedBy: text(actor, "签发人", 64), ...expiry(body) };
}
export function uniqueList(value, validate, max) {
  if (!Array.isArray(value) || !value.length || value.length > max)
    throw fail(400, `请选择 1–${max} 项`);
  return [...new Set(value.map(validate))];
}
export function exactPairs(items) {
  if (!Array.isArray(items) || !items.length || items.length > 1000)
    throw fail(400, "每次请选择 1–1000 条记录");
  const pairs = items.map((item) => {
    const permission = text(item?.permission, "权限名", 191);
    if (item?.userId !== undefined) {
      if (!Number.isSafeInteger(item.userId) || item.userId <= 0)
        throw fail(400, "账号编号无效");
      return { userId: item.userId, permission };
    }
    return { player: playerName(item?.player), permission };
  });
  return [
    ...new Map(
      pairs.map((p) => [
        JSON.stringify([p.userId ?? p.player, p.permission]),
        p,
      ]),
    ).values(),
  ];
}
export class PersonalPermissionService {
  constructor(ctx, auditDir) {
    this.ctx = ctx;
    this.auditDir = auditDir;
    this.disposed = false;
    this.auditQueue = Promise.resolve();
  }
  async call(id, suffix, params = {}, signal, acknowledgedMutation = false) {
    if (this.disposed) throw fail(503, "个人权限正在停用");
    signal?.throwIfAborted();
    if (typeof id !== "string" || !id) throw fail(400, "请先选择服务器");
    const server = this.ctx.servers.getRaw(id);
    if (!server) throw fail(404, "服务器不存在");
    let response;
    try {
      response = await this.ctx.tshock.fetchFor(
        server,
        `/data/personal-permissions/${suffix}`,
        params,
        { signal, timeoutMs: 15000 },
      );
    } catch (err) {
      signal?.throwIfAborted();
      throw fail(502, "连接游戏服失败：" + err.message);
    }
    // A successful game response remains authoritative after client disconnect or disposal.
    // Mutations must reach their audit write; reads can discard late responses.
    if (!acknowledgedMutation) {
      signal?.throwIfAborted();
      if (this.disposed) throw fail(503, "个人权限正在停用");
    }
    const data = response?.data,
      status = Number(data?.status || response?.status || 502);
    if (status === 404 && !data?.error)
      throw fail(501, "游戏服尚未启用个人权限，请检查插件同步状态");
    if ([401, 403].includes(status))
      throw fail(502, "游戏服令牌需要 tsweb.personal-permissions.manage 权限");
    if (
      !response?.ok ||
      !data ||
      !Number.isFinite(status) ||
      status >= 400 ||
      data.error
    )
      throw fail(
        [400, 404, 409, 429, 503].includes(status) ? status : 502,
        data?.error || "游戏服未返回有效结果",
      );
    return data;
  }
  async mutate(id, action, params, actor, signal) {
    // Once the game acknowledges, audit even if the browser has disconnected.
    const data = await this.call(id, action, params, signal, true);
    const entry = {
      at: new Date().toISOString(),
      serverId: id,
      actor,
      action,
      params,
      result: {
        success: data.success,
        failed: data.failed,
        cleaned: data.cleaned,
        response: data.response,
      },
    };
    const write = this.auditQueue.then(async () => {
      await fs.mkdir(this.auditDir, { recursive: true });
      await fs.appendFile(
        path.join(this.auditDir, "audit.jsonl"),
        JSON.stringify(entry) + "\n",
        "utf8",
      );
    });
    this.auditQueue = write.catch(() => {});
    try {
      await write;
    } catch {
      return {
        ...data,
        warning: "操作已完成，但审计记录保存失败；请勿重复提交。",
      };
    }
    return data;
  }
  async audit(id) {
    const rows = [];
    await this.auditQueue;
    try {
      await fs.access(path.join(this.auditDir, "audit.jsonl"));
      const stream = createReadStream(path.join(this.auditDir, "audit.jsonl"), {
        encoding: "utf8",
      });
      const lines = createInterface({ input: stream, crlfDelay: Infinity });
      try {
        for await (const line of lines) {
          let row;
          try {
            row = JSON.parse(line);
          } catch {
            continue;
          }
          if (row.serverId === id) {
            rows.push(row);
            if (rows.length > 100) rows.shift();
          }
        }
      } finally {
        lines.close();
        stream.destroy();
      }
    } catch (err) {
      if (err.code !== "ENOENT") throw err;
    }
    return { items: rows.reverse() };
  }
}
