/**
 * 打包新鲜度与包内容测试（status-panel）
 *
 * 为什么这些断言重要：
 *   1. 下发给游戏服的 DLL 必须是**本次构建**的产物。本仓实测过"打包器把陈旧副本拷回来覆盖新构建"
 *      （plugins/qq-bind/plugin/QqBind.dll 里没有当次新增的代码，全程无报错），所以 DLL 必须比全部
 *      C# 源码与工程文件都新。这一步由 plugin/TsWebStatusPanel.dll 与 plugin/*.cs、*.csproj 的
 *      mtime 比较来固定。
 *   2. 发行包只放运行所需，不放源码：.cs/.csproj/.pdb/.xml 与 bin/obj 都必须在打包器的排除规则里
 *      （规则写在仓库根的 scripts/pack-plugin.mjs，本文件既断言规则文本、也用它导出的 collectFiles
 *      做一次真实行为验证）。
 *   3. 程序集名必须是 TsWebStatusPanel 而不是 StatusPanel：Windows 文件名不区分大小写，
 *      叫 StatusPanel.dll 会覆盖用户机器上可能仍装着的旧前身插件
 *      （plugin-son/statuspanel/statuspanel.dll），而打包器又是用 **csproj 文件名**推导程序集名的，
 *      所以 csproj 的文件名与 <AssemblyName> 必须同时是 TsWebStatusPanel。
 *
 * 运行：node test/pack-freshness.test.mjs
 * （本机 `node --test test/` 会因 spawn EPERM 整体失败，故逐文件运行）
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync, readdirSync, statSync, mkdirSync, writeFileSync, mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginDir = path.resolve(here, '..')
const csharpDir = path.join(pluginDir, 'plugin')
const dllPath = path.join(csharpDir, 'TsWebStatusPanel.dll')
const csprojName = 'TsWebStatusPanel.csproj'
const csprojPath = path.join(csharpDir, csprojName)

const pkg = JSON.parse(readFileSync(path.join(pluginDir, 'package.json'), 'utf8'))

/** 从插件目录往上找到仓库根的 scripts/pack-plugin.mjs（不写死相对层级，免得目录搬动后测试失效） */
function findPackScript(start) {
  let cur = start
  for (let i = 0; i < 8; i++) {
    const candidate = path.join(cur, 'scripts', 'pack-plugin.mjs')
    if (existsSync(candidate)) return candidate
    const parent = path.dirname(cur)
    if (parent === cur) break
    cur = parent
  }
  return null
}

const packScript = findPackScript(pluginDir)
assert.ok(packScript, `从 ${pluginDir} 往上找不到仓库根的 scripts/pack-plugin.mjs（打包内容断言依赖它）`)
const packSourceRaw = readFileSync(packScript, 'utf8')

/**
 * 打包器源码的"只看可执行代码"版本。
 *
 * 为什么必须剔除注释再扫：本文件对打包器的断言约束的是**行为**
 * （排除哪些扩展名、怎么推导程序集名），而注释里同样会写到这些串
 * （例如"打包时排除 .cs/.pdb"这类说明文字）。不剔注释的话，
 * 一条把 '.cs' 注释掉的 SKIP_EXT 也能让断言通过 —— 那就是误判。
 */
const packSource = packSourceRaw
  .replace(/\/\*[\s\S]*?\*\//g, '')
  .split('\n')
  .map((line) => (line.trim().startsWith('//') ? '' : line))
  .join('\n')

/**
 * 打包器导出 collectFiles 供其它脚本复用（import 时不会执行 main，见其文件末尾的 invokedDirectly 判断）。
 * 用它做真实行为验证，比只看规则文本更硬。
 */
let collectFiles
try {
  ({ collectFiles } = await import(pathToFileURL(packScript).href))
} catch (err) {
  throw new Error(`无法加载打包器 ${packScript}（本文件依赖它导出的 collectFiles）：${err.message}`)
}

/** plugin/ 下的 C# 源码与工程文件（用来判断 DLL 是否新鲜） */
function csharpSources() {
  return readdirSync(csharpDir, { withFileTypes: true })
    .filter((e) => e.isFile() && (e.name.endsWith('.cs') || e.name.endsWith('.csproj')))
    .map((e) => e.name)
    .sort()
}

/** 从打包器源码里抽出某个 `const NAME = [...]` / `new Set([...])` 的字面量成员（已剔注释，注释掉的项不算数） */
function literalEntries(source, pattern, why) {
  const m = source.match(pattern)
  assert.ok(m, `scripts/pack-plugin.mjs 里没匹配到 ${why}（已剔除注释：注释掉的项不算规则）`)
  const entries = [...m[1].matchAll(/'([^']+)'/g)].map((x) => x[1])
  assert.ok(entries.length > 0, `${why} 里抽不到任何条目，说明扫描方式失效了`)
  return entries
}

// ═══════════════════ package.json ═══════════════════

test('package.json：名字、市场标签、下发模式、DLL 声明、前端入口、自动装载都正确', () => {
  assert.equal(pkg.name, 'status-panel', 'package.json 的 name 必须等于目录名（loader 与注册表都以目录名为键，打包器也会硬校验）')
  assert.deepEqual(pkg.tsweb.tags, ['管理工具'], '市场标签必须恰为 ["管理工具"]：标签是市场筛选维度，是闭集，多一个字都会让筛选失效')
  assert.equal(pkg.tsweb.deploy, 'all', 'deploy 必须是 all（本件由宿主按服务器分片下发，装完就该对所有启用服生效）')
  assert.ok(
    Array.isArray(pkg.tsweb.dll) && pkg.tsweb.dll.includes('./plugin/*.dll'),
    `tsweb.dll 必须声明 ./plugin/*.dll（否则 C# 半不会随包下发），实际 ${JSON.stringify(pkg.tsweb.dll)}`,
  )
  assert.equal(pkg.tsweb.client, './client/status-panel.js', 'tsweb.client 必须指向 client/status-panel.js（管理界面就靠它）')
  assert.equal(pkg.tsweb.autoload, true, 'autoload 必须为 true（自带插件随宿主动装载；这正是"独立插件"的交付形态）')

  // 声明了就必须真的存在（打包器第 4 条硬约束：tsweb.client 指向的文件不存在会直接打包失败）
  const clientAbs = path.join(pluginDir, pkg.tsweb.client)
  assert.ok(existsSync(clientAbs), `package.json 声明的前端入口不存在：${pkg.tsweb.client}（打包器会因此拒绝打包）`)
  assert.equal(path.basename(clientAbs), 'status-panel.js')
})

test('tsweb.dll 声明的 glob 真的命中 plugin/ 下的 DLL（不是一条空承诺）', () => {
  const packed = collectFiles(pluginDir).map((f) => f.rel)
  for (const glob of pkg.tsweb.dll) {
    // 打包器的 globMatch 只支持 * 与 **：这里按同样语义把 './plugin/*.dll' 翻成正则
    const re = new RegExp(
      '^' + glob.replace(/^\.\//, '').replace(/\./g, '\\.').replace(/\*\*/g, '\u0000').replace(/\*/g, '[^/]*').replace(/\u0000/g, '.*') + '$',
    )
    const hits = packed.filter((rel) => re.test(rel))
    assert.ok(hits.length > 0, `tsweb.dll 声明的 glob 未命中任何会被打包的文件：${glob}（打包器的第 5 条硬约束会因此失败）`)
    assert.deepEqual(hits, ['plugin/TsWebStatusPanel.dll'], `glob ${glob} 命中的应当是唯一的游戏服半产物`)
  }
})

// ═══════════════════ 构建新鲜度 ═══════════════════

test('plugin/TsWebStatusPanel.dll 存在，且比 plugin/ 下所有 .cs/.csproj 都新（新鲜构建，不是陈旧产物）', () => {
  assert.ok(existsSync(dllPath), `缺少 ${dllPath}：必须先构建（plugin/ 下 dotnet build -c Release）再交付`)
  const dll = statSync(dllPath)
  assert.ok(dll.size > 0, 'DLL 不能是 0 字节')

  const sources = csharpSources()
  assert.ok(sources.length >= 8, `plugin/ 下的 C# 源码文件只有 ${sources.length} 个，明显不对：新鲜度比较必须在"确实看到了全部源码"的前提下做`)

  let newest = 0
  let newestName = ''
  for (const name of sources) {
    const t = statSync(path.join(csharpDir, name)).mtimeMs
    if (t > newest) {
      newest = t
      newestName = name
    }
  }
  assert.ok(
    dll.mtimeMs >= newest,
    `plugin/TsWebStatusPanel.dll 比源码旧：最新源码 ${newestName}（${new Date(newest).toISOString()}）`
    + ` 晚于 DLL（${new Date(dll.mtimeMs).toISOString()}）。这种"分发了旧产物"的情况本仓实测发生过（qq-bind），`
    + '必须重新构建后再交付',
  )
})

// ═══════════════════ 程序集名（避免覆盖用户已装的旧插件） ═══════════════════

test('csproj 的 AssemblyName 与文件名都是 TsWebStatusPanel（不得是 StatusPanel：Windows 下会覆盖用户的旧插件）', () => {
  assert.ok(existsSync(csprojPath), `csproj 文件名必须是 ${csprojName}（打包器用文件名推导程序集名），实际目录下是 ${readdirSync(csharpDir).filter((f) => f.endsWith('.csproj')).join('、') || '（没有 csproj）'}`)

  const csproj = readFileSync(csprojPath, 'utf8')
  assert.match(
    csproj,
    /<AssemblyName>TsWebStatusPanel<\/AssemblyName>/,
    'csproj 必须把程序集名显式定成 TsWebStatusPanel：旧版仓库里存在前身插件 plugin-son/statuspanel/statuspanel.dll，'
    + 'Windows 文件名不区分大小写，叫 StatusPanel.dll 会把用户服务器上那份**覆盖**掉（旧插件与新宿主互不认识，问题极难定位）',
  )
  assert.match(csproj, /<RootNamespace>TsWebStatusPanel<\/RootNamespace>/, 'RootNamespace 也要跟着改，否则类型名会落在旧命名空间下')

  // 产出名：既不能是 StatusPanel.dll，按 Windows 的大小写不敏感规则也不能与 statuspanel.dll 撞名
  const dllBase = path.basename(dllPath)
  assert.equal(dllBase, 'TsWebStatusPanel.dll', '产出文件名必须是 TsWebStatusPanel.dll')
  assert.notEqual(
    dllBase.toLowerCase(),
    'statuspanel.dll',
    '产物名不得与旧前身插件 statuspanel.dll 大小写不敏感地相同（Windows 下会互相覆盖）',
  )
  assert.equal(
    existsSync(path.join(csharpDir, 'StatusPanel.dll')),
    false,
    'plugin/ 下不得残留 StatusPanel.dll（它会与旧插件撞名，也可能被一并下发）',
  )

  // 打包器用 csproj 文件名推导程序集名 —— 两者必须一致，否则打包时会去找一个不存在的产物名
  const projs = readdirSync(csharpDir).filter((f) => f.endsWith('.csproj'))
  assert.deepEqual(projs, [csprojName], `plugin/ 下应当只有 1 个 csproj，且就是 ${csprojName}`)
  assert.equal(projs[0].replace(/\.csproj$/i, ''), 'TsWebStatusPanel', '按打包器的推导方式（去掉 .csproj 后缀）得到的程序集名必须是 TsWebStatusPanel')
  assert.ok(
    packSource.includes("proj.replace(/\\.csproj$/i, '')"),
    '打包器推导程序集名的方式变了（不再是"csproj 文件名去掉后缀"的可执行代码）：这条一致性的前提需要重新确认',
  )
  assert.ok(
    packSource.includes("f.endsWith('.csproj')"),
    '打包器不再是按 .csproj 收集工程文件的（此处只看可执行代码，注释里提到不算）：本用例的前提需要重新确认',
  )
})

// ═══════════════════ 打包排除规则 ═══════════════════

test('打包器排除规则里确实有 .cs/.csproj/.pdb/.xml 与 bin/obj（发行包只放运行所需）', () => {
  const skipDirs = literalEntries(packSource, /const SKIP_DIRS = new Set\(\[([\s\S]*?)\]\)/, 'SKIP_DIRS 定义')
  const skipExt = literalEntries(packSource, /const SKIP_EXT = \[([\s\S]*?)\]/, 'SKIP_EXT 定义')

  for (const dir of ['bin', 'obj']) {
    assert.ok(skipDirs.includes(dir), `SKIP_DIRS 必须排除 ${dir}/：构建中间产物与本地 DLL 副本不该进发行包（本仓实测过 bin/ 里的陈旧产物覆盖新构建）`)
  }
  for (const ext of ['.cs', '.csproj', '.pdb', '.xml']) {
    assert.ok(skipExt.includes(ext), `SKIP_EXT 必须排除 ${ext}：发行包只放运行所需，不放源码/调试符号/文档`)
  }
  // 反向：JS 半与 C# 产物本身就是运行所需，不能被排除
  for (const ext of ['.js', '.dll']) {
    assert.ok(!skipExt.includes(ext), `SKIP_EXT 不得排除 ${ext}：它是本插件的运行产物（JS 半没有构建步骤，DLL 是游戏服半）`)
  }
  assert.ok(!skipDirs.includes('client'), 'SKIP_DIRS 不得排除 client/：前端半必须随包下发')
})

test('排除规则真的生效：真实插件目录里 .cs/.csproj/.pdb/.xml 与 bin/obj 一个都不会进包', () => {
  const packed = collectFiles(pluginDir).map((f) => f.rel)
  assert.ok(packed.length > 0, '插件目录打包结果为空，说明扫描方式失效了')

  const forbiddenExt = ['.cs', '.csproj', '.pdb', '.xml', '.sln', '.props', '.targets']
  for (const rel of packed) {
    assert.ok(
      !forbiddenExt.some((e) => rel.endsWith(e)),
      `发行包里出现了不该有的文件：${rel}（发行包只放运行所需，源码与调试符号不进包）`,
    )
    assert.ok(!/(^|\/)(bin|obj)\//.test(rel), `发行包里出现了构建目录里的文件：${rel}（bin/obj 一律排除）`)
  }
  // 该在的都还在
  for (const rel of ['package.json', 'index.js', 'client/status-panel.js', 'plugin/TsWebStatusPanel.dll']) {
    assert.ok(packed.includes(rel), `发行包里缺少运行必需的文件：${rel}`)
  }
})

test('排除规则的行为验证：合成的构建目录里，只有 DLL 与 JS 会被收进包', () => {
  const root = mkdtempSync(path.join(tmpdir(), 'status-panel-pack-'))
  try {
    const write = (rel, content = 'x') => {
      const abs = path.join(root, rel)
      mkdirSync(path.dirname(abs), { recursive: true })
      writeFileSync(abs, content)
    }
    write('package.json', '{}')
    write('index.js')
    write('client/status-panel.js')
    write('plugin/TsWebStatusPanel.dll', 'DLL')
    // 以下都应当被排除
    write('plugin/StatusPanelRenderer.cs')
    write('plugin/TsWebStatusPanel.csproj')
    write('plugin/TsWebStatusPanel.pdb')
    write('plugin/doc.xml')
    write('plugin/bin/Release/net9.0/TsWebStatusPanel.dll')
    write('plugin/obj/Release/net9.0/TsWebStatusPanel.dll')
    write('node_modules/foo/package.json', '{}')

    const packed = collectFiles(root).map((f) => f.rel).sort()
    assert.deepEqual(
      packed,
      ['client/status-panel.js', 'index.js', 'package.json', 'plugin/TsWebStatusPanel.dll'],
      '打包结果必须只有运行所需的那几个文件：源码/工程/调试符号/文档与 bin、obj、node_modules 都要被排除',
    )
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})
