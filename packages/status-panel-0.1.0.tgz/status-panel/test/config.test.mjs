/**
 * 配置模型测试（宿主半 config.js）—— 纯函数，不需要宿主也不需要 DOM。
 *
 * 覆盖的判据都来自"必须与旧版逐字一致"的那些字段语义（见 config.js 顶部注释与交付报告对照表）：
 *   enabled 默认 false、spacerWidth 默认 60 且夹到 [0,500]、logLevel 默认 INFO、
 *   `default` 面板强制存在、panelSpacers 缺失/负值回退全局、v1 的 statusTextSettings 仅作迁移输入、
 *   行元素 typeName/text/updateInterval 语义、以及"静默兜底 vs 严格驳回"两条路径的分工。
 *
 * 运行：node test/config.test.mjs
 */
import test from 'node:test'
import assert from 'node:assert/strict'

import {
  DEFAULT_INTERVAL_FRAMES,
  DEFAULT_LOG_LEVEL,
  DEFAULT_PANEL_NAME,
  DEFAULT_SPACER_WIDTH,
  INTERPOLATION_REGEX,
  LOG_LEVELS,
  MAX_CONFIGURED_ROWS_PER_PANEL,
  MAX_INTERVAL_FRAMES,
  MAX_PAYLOAD_CHARS,
  MAX_ROWS_PER_PANEL,
  MAX_SPACER_WIDTH,
  PLACEHOLDER_TOKENS,
  RESERVED_PANEL_NAMES,
  ROW_KEYS,
  canonicalConfig,
  canonicalJson,
  changedKeys,
  clampSpacer,
  configWarnings,
  defaultConfig,
  defaultPanelRows,
  emptyStore,
  escapedTokens,
  loadStore,
  normalizeConfig,
  normalizeInterval,
  normalizeRow,
  saveStore,
  toGamePayload,
  toLegacyPayload,
  unknownPlaceholders,
  validateConfig,
} from '../config.js'
import { makeMemoryFs } from './support/fake-host.mjs'

// ═══════════════════ 默认值与常量 ═══════════════════

test('默认配置与旧版逐字一致：未启用 / 60 / INFO / default 面板 4 行模板', () => {
  const cfg = defaultConfig()
  assert.equal(cfg.enabled, false, '旧版 StatusPanel.cs:33 的 enabled 默认是 false（插件默认关闭）')
  assert.equal(cfg.spacerWidth, DEFAULT_SPACER_WIDTH)
  assert.equal(cfg.spacerWidth, 60)
  assert.equal(cfg.logLevel, DEFAULT_LOG_LEVEL)
  assert.equal(cfg.logLevel, 'INFO')
  assert.deepEqual(Object.keys(cfg.panels), ['default'])
  assert.equal(cfg.panels.default.length, 4)
  assert.deepEqual(cfg.panelSpacers, {})
  assert.deepEqual(Object.keys(cfg), ['enabled', 'spacerWidth', 'logLevel', 'panels', 'panelSpacers'])

  // 模板 4 行逐字照搬旧版 StatusPanel.cs:63-75
  assert.deepEqual(defaultPanelRows(), [
    { typeName: 'DynamicText', text: '[i:757][c/f15642:开荒服]', updateInterval: 600 },
    { typeName: 'DynamicText', text: '在线人数：{OnlinePlayersCount}人', updateInterval: 60 },
    { typeName: 'DynamicText', text: '全服在线：{AllOnlineCount}人', updateInterval: 60 },
    { typeName: 'DynamicText', text: '系统时间：{SystemTime}', updateInterval: 60 },
  ])
})

test('常量与旧版/服端对齐：26 个占位符、4 个保留字、5 个日志等级、上限值', () => {
  assert.equal(PLACEHOLDER_TOKENS.length, 26)
  assert.equal(new Set(PLACEHOLDER_TOKENS).size, 26)
  assert.deepEqual(RESERVED_PANEL_NAMES, ['on', 'off', 'show', 'hide'])
  assert.deepEqual(LOG_LEVELS, ['NONE', 'ERROR', 'WARNING', 'INFO', 'DEBUG'])
  assert.equal(MAX_SPACER_WIDTH, 500)
  assert.equal(MAX_ROWS_PER_PANEL, 20)
  assert.equal(MAX_CONFIGURED_ROWS_PER_PANEL, 200)
  assert.equal(DEFAULT_INTERVAL_FRAMES, 60)
  assert.equal(MAX_INTERVAL_FRAMES, 1_000_000)
  assert.deepEqual(ROW_KEYS, ['typeName', 'text', 'updateInterval', 'pluginName', 'enabled', 'overrideInterval'])
  // 每个占位符都要能被插值正则识别（否则模板里写了也不生效）
  for (const t of PLACEHOLDER_TOKENS) {
    assert.ok(new RegExp(INTERPOLATION_REGEX.source).test(t), `${t} 不能被插值正则匹配`)
  }
})

test('插值正则与旧版同源：{{…}} 转义、{ x } 不匹配、未知 {x} 原样', () => {
  const src = INTERPOLATION_REGEX.source
  assert.equal(src, '(?:{{[^{\\s]*?}}|{[^{\\s]*?})')
  const re = new RegExp(src, 'g')
  assert.deepEqual('{{abc}}'.match(re), ['{{abc}}'], '双花括号是转义形式，匹配整个 {{abc}}')
  assert.deepEqual('{PlayerName}'.match(re), ['{PlayerName}'])
  assert.equal('{ x }'.match(re), null, '花括号内有空格不匹配（旧版正则如此）')
  assert.deepEqual('{}'.match(re), ['{}'], '旧版正则的 *? 允许空内容：{} 也会被匹配（替换时按未知 token 原样保留）')
  assert.deepEqual('{Unknown}'.match(re), ['{Unknown}'], '未知占位符也会被正则匹配（替换时原样保留）')
})

// ═══════════════════ 归一（容错路径） ═══════════════════

test('panelSpacers:null 不再致命（旧版会抛 ArgumentNullException 导致配置读不出来）', () => {
  const notes = []
  const cfg = normalizeConfig({ enabled: true, panelSpacers: null }, notes)
  assert.deepEqual(cfg.panelSpacers, {})
  assert.ok(notes.some((n) => n.includes('panelSpacers')), '应记录一条说明：' + JSON.stringify(notes))
})

test('panels 缺失/非对象 → 补默认模板；default 面板强制存在', () => {
  const notes1 = []
  const a = normalizeConfig({}, notes1)
  assert.deepEqual(Object.keys(a.panels), ['default'])
  assert.equal(a.panels.default.length, 4)

  const notes2 = []
  const b = normalizeConfig({ panels: { vip: [{ typeName: 'DynamicText', text: 'x' }] } }, notes2)
  assert.deepEqual(Object.keys(b.panels).sort(), ['default', 'vip'], '没有 default 时必须补上模板')
  assert.ok(notes2.some((n) => n.includes('default 面板')))

  const notes3 = []
  const c = normalizeConfig({ panels: 'x' }, notes3)
  assert.deepEqual(Object.keys(c.panels), ['default'])
})

test('v1 的 statusTextSettings 只作为迁移输入，且仅在 panels 为空时生效', () => {
  const v1 = [{ text: 'v1 行', updateInterval: 30 }]
  const notes = []
  const migrated = normalizeConfig({ statusTextSettings: v1 }, notes)
  assert.equal(migrated.panels.default.length, 1)
  assert.equal(migrated.panels.default[0].text, 'v1 行')
  assert.equal(migrated.panels.default[0].typeName, '')
  assert.equal(migrated.statusTextSettings, undefined, '输出里不该再有 v1 字段')
  assert.ok(notes.some((n) => n.includes('statusTextSettings')))

  // panels 非空时 v1 字段被忽略（旧版 StatusPanel.cs:171-175 的条件）
  const notes2 = []
  const kept = normalizeConfig({ panels: { default: [{ typeName: 'DynamicText', text: '新' }] }, statusTextSettings: v1 }, notes2)
  assert.equal(kept.panels.default.length, 1)
  assert.equal(kept.panels.default[0].text, '新')
})

test('行元素归一：typeName/text 折成字符串、updateInterval 默认 60、未知键往返透传', () => {
  const notes = []
  const row = normalizeRow(
    { pluginName: 'Other.dll', enabled: false, overrideInterval: true, text: 123, updateInterval: 0 },
    notes,
    '第 1 行',
  )
  assert.equal(row.typeName, '', '缺 typeName 时归一成空串（渲染时会丢行，但字段不丢）')
  assert.equal(row.text, '123', '旧版 text?.ToString() → 数字折成字符串')
  assert.equal(row.updateInterval, 1, 'updateInterval<1 按 1 处理')
  assert.equal(row.pluginName, 'Other.dll', 'pluginName 仅往返透传，必须原样保留')
  assert.equal(row.enabled, false)
  assert.equal(row.overrideInterval, true)
  // 输出顺序确定：已知键按 ROW_KEYS 顺序在前，未知键随后
  assert.deepEqual(Object.keys(row), ['typeName', 'text', 'updateInterval', 'pluginName', 'enabled', 'overrideInterval'])
  assert.ok(notes.some((n) => n.includes('updateInterval=0')))

  const row2 = normalizeRow({ typeName: 'StaticText', text: '固定', extra: { a: 1 } })
  assert.deepEqual(Object.keys(row2), ['typeName', 'text', 'updateInterval', 'extra'])
  assert.equal(row2.updateInterval, 60, '缺 updateInterval 默认 60 帧')
  assert.deepEqual(row2.extra, { a: 1 })

  // 非对象行被丢弃并记说明
  const notes3 = []
  assert.equal(normalizeRow('不是对象', notes3, '第 2 行'), null)
  assert.equal(notes3.length, 1)
})

test('updateInterval 归一的全部边界（非数字/负数/超大/字符串数字）', () => {
  assert.equal(normalizeInterval(undefined), 60)
  assert.equal(normalizeInterval(null), 60)
  assert.equal(normalizeInterval('120'), 120, '字符串数字按数字处理（服端 ParseInterval 也是容错的）')
  assert.equal(normalizeInterval(0), 1)
  assert.equal(normalizeInterval(-5), 1)
  assert.equal(normalizeInterval(2.7), 2, '向下取整')
  assert.equal(normalizeInterval(MAX_INTERVAL_FRAMES + 1), MAX_INTERVAL_FRAMES)
  const notes = []
  assert.equal(normalizeInterval('abc', notes), 60)
  assert.equal(notes.length, 1)
  assert.equal(normalizeInterval('', notes), 60, '空串不是数字 → 默认 60')
})

test('spacerWidth 夹取：负数→0、超上限→500、非数字→默认 60（各留一条说明）', () => {
  assert.equal(clampSpacer(-1), 0)
  assert.equal(clampSpacer(999), MAX_SPACER_WIDTH)
  assert.equal(clampSpacer('abc'), null)

  const notes = []
  const cfg = normalizeConfig({ spacerWidth: 999 }, notes)
  assert.equal(cfg.spacerWidth, MAX_SPACER_WIDTH)
  assert.ok(notes.some((n) => n.includes('spacerWidth=999')))

  const notes2 = []
  const cfg2 = normalizeConfig({ spacerWidth: 'abc' }, notes2)
  assert.equal(cfg2.spacerWidth, DEFAULT_SPACER_WIDTH)
  assert.ok(notes2.some((n) => n.includes('不是数字')))
})

test('panelSpacers：负值/非数字按未配置（回退全局）、超上限夹到 500', () => {
  const notes = []
  const cfg = normalizeConfig({
    panelSpacers: { vip: -3, abc: 'x', big: 900, ok: 12 },
  }, notes)
  assert.deepEqual(cfg.panelSpacers, { big: MAX_SPACER_WIDTH, ok: 12 })
  assert.ok(notes.some((n) => n.includes('vip') && n.includes('负')))
  assert.ok(notes.some((n) => n.includes('abc')))
  assert.ok(notes.some((n) => n.includes('big')))
})

test('logLevel 归一：大小写不敏感、未知值回退 INFO 并记说明', () => {
  assert.equal(normalizeConfig({ logLevel: 'debug' }).logLevel, 'DEBUG')
  assert.equal(normalizeConfig({ logLevel: ' NONE ' }).logLevel, 'NONE')
  const notes = []
  assert.equal(normalizeConfig({ logLevel: 'TRACE' }, notes).logLevel, 'INFO')
  assert.ok(notes.some((n) => n.includes('TRACE')))
  assert.equal(normalizeConfig({ logLevel: '' }).logLevel, 'INFO')
  assert.equal(normalizeConfig({ logLevel: null }).logLevel, 'INFO')
})

test('enabled 归一：布尔直通、字符串 true/false 接受、其它回退 false 并记说明', () => {
  assert.equal(normalizeConfig({ enabled: true }).enabled, true)
  assert.equal(normalizeConfig({ enabled: 'true' }).enabled, true)
  assert.equal(normalizeConfig({ enabled: 'false' }).enabled, false)
  const notes = []
  assert.equal(normalizeConfig({ enabled: 1 }, notes).enabled, false)
  assert.ok(notes.some((n) => n.includes('enabled')))
})

test('行数上限：配置超 200 行被截断并记说明（与服端 Sanitize 同一上限，避免 probe 永久不一致）', () => {
  const rows = Array.from({ length: 205 }, (_, i) => ({ typeName: 'DynamicText', text: `行${i}` }))
  const notes = []
  const cfg = normalizeConfig({ panels: { default: rows } }, notes)
  assert.equal(cfg.panels.default.length, MAX_CONFIGURED_ROWS_PER_PANEL)
  assert.ok(notes.some((n) => n.includes('205') && n.includes('截断')))
})

test('归一后的配置是"可比较"的：canonicalJson 与对象书写顺序无关', () => {
  const a = { panels: { default: [{ text: 'x', typeName: 'DynamicText' }], vip: [] }, enabled: true, spacerWidth: 10, logLevel: 'INFO' }
  const b = { logLevel: 'INFO', spacerWidth: 10, enabled: true, panelSpacers: {}, panels: { vip: [], default: [{ typeName: 'DynamicText', text: 'x' }] } }
  assert.equal(canonicalJson(a), canonicalJson(b), '同样的配置换了书写顺序，规范化 JSON 必须完全一致')
  assert.deepEqual(Object.keys(canonicalConfig(a).panels), ['default', 'vip'], '面板名排序稳定')
  assert.deepEqual(changedKeys(a, b), [], '没有实质变化时 changedKeys 应为空')
  assert.deepEqual(changedKeys(a, { ...b, spacerWidth: 11 }), ['spacerWidth'])
})

// ═══════════════════ 严格校验（提交路径） ═══════════════════

test('validateConfig 接受合法配置（含往返透传字段与未知面板）', () => {
  const cfg = {
    enabled: true,
    spacerWidth: 80,
    logLevel: 'DEBUG',
    panels: {
      default: [
        { typeName: 'DynamicText', text: '{PlayerName}', updateInterval: 60 },
        { typeName: 'HandlerInfoOverride', text: '', pluginName: 'X.dll', enabled: false, overrideInterval: true },
      ],
      vip: [],
    },
    panelSpacers: { default: 0, vip: 500 },
  }
  assert.equal(validateConfig(cfg), cfg)
})

test('validateConfig 逐条驳回非法值（400 语义：抛错且消息可读）', () => {
  const bad = [
    [null, /必须是对象/],
    ['x', /必须是对象/],
    [{ enabled: 'yes' }, /enabled 必须是布尔值/],
    [{ spacerWidth: 'x' }, /spacerWidth 必须是整数/],
    [{ spacerWidth: -1 }, /spacerWidth 必须在 0~500/],
    [{ spacerWidth: 501 }, /spacerWidth 必须在 0~500/],
    [{ logLevel: 'TRACE' }, /logLevel 必须是/],
    [{ panels: [] }, /panels 必须是对象/],
    [{ panels: { '': [] } }, /空面板名/],
    [{ panels: { on: [] } }, /保留字/],
    [{ panels: { OFF: [] } }, /保留字/],
    [{ panels: { default: 'x' } }, /必须是数组/],
    [{ panels: { default: [{ text: 'x' }] } }, /缺少 typeName/],
    [{ panels: { default: [{ typeName: '  ' }] } }, /缺少 typeName/],
    [{ panels: { default: [{ typeName: 'DynamicText', text: 1 }] } }, /text 必须是字符串/],
    [{ panels: { default: [{ typeName: 'DynamicText', updateInterval: 'x' }] } }, /必须是整数/],
    [{ panels: { default: [{ typeName: 'DynamicText', updateInterval: 0 }] } }, /必须 ≥1/],
    [{ panels: { default: [{ typeName: 'DynamicText', updateInterval: MAX_INTERVAL_FRAMES + 1 }] } }, /不能超过/],
    [{ panelSpacers: [] }, /panelSpacers 必须是对象/],
    [{ panelSpacers: { a: -1 } }, /必须在 0~500/],
    [{ panelSpacers: { a: 501 } }, /必须在 0~500/],
    [{ panelSpacers: { a: 'x' } }, /必须是整数/],
    [{ statusTextSettings: 'x' }, /必须是数组/],
  ]
  for (const [input, re] of bad) {
    assert.throws(() => validateConfig(input), (err) => {
      assert.equal(err.status, 400, `应带 400 状态：${JSON.stringify(input)}`)
      assert.match(err.message, re)
      return true
    }, `未按预期驳回：${JSON.stringify(input)}`)
  }
})

test('validateConfig 驳回超过 200 行的面板（与归一上限一致，不给出"能存下去但会被截断"的假成功）', () => {
  const rows = Array.from({ length: 201 }, () => ({ typeName: 'DynamicText', text: 'x' }))
  assert.throws(() => validateConfig({ panels: { default: rows } }), /超过上限 200 行/)
})

// ═══════════════════ 生效性警告 ═══════════════════

test('configWarnings：关闭/空面板/超渲染上限/不可渲染行/未知占位符/孤儿面板间距 都要说出来', () => {
  const cfg = normalizeConfig({
    enabled: false,
    spacerWidth: 0,
    logLevel: 'NONE',
    panels: {
      default: Array.from({ length: MAX_ROWS_PER_PANEL + 2 }, (_, i) => ({ typeName: 'DynamicText', text: `行${i}` })),
      empty: [],
      weird: [{ typeName: 'HandlerInfoOverride', text: '不可渲染' }],
      tokens: [{ typeName: 'DynamicText', text: '{NotAToken} 与 {{RealWorldTime}} 与 { 空格 }' }],
    },
    panelSpacers: { ghost: 10 },
  })
  const msgs = configWarnings(cfg).map((w) => w.level + '|' + w.message)
  const has = (s) => msgs.some((m) => m.includes(s))
  assert.ok(has('总开关未启用'))
  assert.ok(has('全局行尾空格为 0'))
  assert.ok(has('日志等级 NONE'))
  assert.ok(has(`只渲染前 ${MAX_ROWS_PER_PANEL} 行`))
  assert.ok(has('没有任何行') && has('清空'))
  assert.ok(has('不会被渲染'))
  assert.ok(has('{NotAToken} 不是已知占位符'))
  assert.ok(has('{{RealWorldTime}} 会显示为字面量'))
  assert.ok(has('ghost'))
  assert.ok(!has('{ 空格 }'), '带空格的写法不匹配插值正则，不该被报为未知占位符')

  // 警告项都要有 level 且分级合理
  for (const w of configWarnings(cfg)) {
    assert.ok(['info', 'warn', 'error'].includes(w.level))
    assert.ok(w.message.length > 4)
  }
})

test('没有问题时不该凭空报警告（默认模板 + 启用 + 正常间距）', () => {
  const warnings = configWarnings({ ...defaultConfig(), enabled: true })
  assert.deepEqual(warnings, [], '默认模板是正常配置，不该有警告：' + JSON.stringify(warnings))
})

test('unknownPlaceholders / escapedTokens 正反例', () => {
  const text = '{PlayerName} {Unknown} {{Escaped}} { BadSpace } [i:757]'
  assert.deepEqual(unknownPlaceholders(text), ['{Unknown}'])
  assert.deepEqual(escapedTokens(text), ['{{Escaped}}'])
  assert.deepEqual(unknownPlaceholders(''), [])
  assert.deepEqual(unknownPlaceholders(null), [])
  assert.deepEqual(unknownPlaceholders('{PlayerName}{AllOnlineCount}'), [])
})

// ═══════════════════ 下发载荷 ═══════════════════

test('toGamePayload 的参数名与服端端点逐个对应，对象值 JSON 字符串化', () => {
  const cfg = { enabled: true, spacerWidth: 30, logLevel: 'DEBUG', panels: { default: [{ typeName: 'DynamicText', text: 'hi' }] }, panelSpacers: { default: 5 } }
  const p = toGamePayload(cfg, { version: 7, allOnlineCount: 42, ts: 'T' })
  assert.deepEqual(Object.keys(p).sort(), ['allOnlineCount', 'enabled', 'logLevel', 'panelSpacers', 'panels', 'spacerWidth', 'ts', 'version'])
  assert.equal(p.version, '7')
  assert.equal(p.enabled, 'true')
  assert.equal(p.spacerWidth, '30')
  assert.equal(p.logLevel, 'DEBUG')
  assert.equal(p.allOnlineCount, '42')
  assert.equal(p.ts, 'T')
  assert.deepEqual(JSON.parse(p.panels), normalizeConfig(cfg).panels)
  assert.deepEqual(JSON.parse(p.panelSpacers), { default: 5 })
})

test('toGamePayload：宿主不知道全服在线数时发 -1（服端据此保持当前值，而不是显示 0）', () => {
  const p = toGamePayload(defaultConfig(), { version: 1 })
  assert.equal(p.allOnlineCount, '-1')
  assert.equal(toGamePayload(defaultConfig(), { version: 1, allOnlineCount: null }).allOnlineCount, '-1')
  assert.equal(toGamePayload(defaultConfig(), { version: 1, allOnlineCount: 0 }).allOnlineCount, '0', '0 是合法在线数，必须原样下发')
})

test('toGamePayload：version 非法或载荷过大时抛 400（而不是发出一个注定失败或超长的请求）', () => {
  assert.throws(() => toGamePayload(defaultConfig(), { version: 0 }), (e) => e.status === 400)
  assert.throws(() => toGamePayload(defaultConfig(), { version: 'x' }), (e) => e.status === 400)
  assert.throws(() => toGamePayload(defaultConfig(), {}), (e) => e.status === 400)

  const bigRow = { typeName: 'DynamicText', text: 'x'.repeat(2000) }
  const rows = Array.from({ length: MAX_CONFIGURED_ROWS_PER_PANEL }, () => ({ ...bigRow }))
  assert.throws(
    () => toGamePayload({ panels: { default: rows }, panelSpacers: {}, enabled: true }, { version: 1 }),
    (e) => {
      assert.equal(e.status, 400)
      assert.match(e.message, new RegExp(String(MAX_PAYLOAD_CHARS)))
      return true
    },
  )
})

test('toLegacyPayload 只有旧版认得的字段（无 version：旧式端点没有版本协议）', () => {
  const p = toLegacyPayload(defaultConfig())
  assert.deepEqual(Object.keys(p).sort(), ['enabled', 'logLevel', 'panelSpacers', 'panels', 'spacerWidth'])
  assert.equal(p.version, undefined)
})

// ═══════════════════ 存储读写 ═══════════════════

test('loadStore：文件不存在 → 空存储且无错误（全新安装不该报错）', async () => {
  const fs = makeMemoryFs()
  const { store, error } = await loadStore('X:/data/status-panel/config.json', fs)
  assert.deepEqual(store, emptyStore())
  assert.equal(error, '')
})

test('loadStore：文件损坏 → 空存储 + 明确错误（绝不静默当成全新安装）', async () => {
  const fs = makeMemoryFs()
  fs.files.set('X:/data/status-panel/config.json', '{ 这不是 JSON')
  const { store, error } = await loadStore('X:/data/status-panel/config.json', fs)
  assert.deepEqual(store.servers, {})
  assert.match(error, /读取配置失败/)
})

test('loadStore/saveStore 往返：按服务器分片、逐服归一、原子写不留 tmp', async () => {
  const fs = makeMemoryFs()
  const file = 'X:/data/status-panel/config.json'
  const store = emptyStore()
  store.servers['1'] = normalizeConfig({ enabled: true, spacerWidth: 999, panels: { default: [], vip: [{ typeName: 'DynamicText', text: 'v' }] } })
  store.servers['2'] = normalizeConfig({ logLevel: 'TRACE' })
  await saveStore(file, store, fs)

  assert.equal(fs.files.has(file + '.tmp'), false, '原子写完成后不该残留 .tmp')
  const raw = JSON.parse(fs.files.get(file))
  assert.equal(raw.version, 1)
  assert.ok(raw.updatedAt, '存储文件要带 updatedAt')
  assert.deepEqual(Object.keys(raw.servers).sort(), ['1', '2'])

  const { store: back, error } = await loadStore(file, fs)
  assert.equal(error, '')
  assert.equal(back.servers['1'].enabled, true)
  assert.equal(back.servers['1'].spacerWidth, MAX_SPACER_WIDTH, '读回时同样夹取')
  assert.deepEqual(Object.keys(back.servers['1'].panels).sort(), ['default', 'vip'])
  assert.equal(back.servers['2'].logLevel, 'INFO', '读回时同样归一（TRACE → INFO）')
})

test('loadStore：servers 字段损坏成数组/字符串时降级为空表而不是崩', async () => {
  const fs = makeMemoryFs()
  fs.files.set('X:/c.json', JSON.stringify({ version: 1, servers: 'x' }))
  const { store, error } = await loadStore('X:/c.json', fs)
  assert.deepEqual(store.servers, {})
  assert.equal(error, '')
})
