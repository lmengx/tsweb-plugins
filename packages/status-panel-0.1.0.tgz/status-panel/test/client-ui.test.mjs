/**
 * 前端半纯函数测试（client/status-panel.js）—— 无浏览器、无 DOM。
 *
 * 前端半把"能脱离 DOM 验证的逻辑"全部做成了具名导出的纯函数，本文件逐个验证它们：
 * 配置归一、面板名与空格语义、预览占位点、插值替换、富文本解析、彩虹字生成/预览、
 * 颜色解析、下发状态文案、以及项目硬规则（禁止 emoji）。
 *
 * 为什么值得测这些：它们是"界面显示的东西"与"游戏里真实生效的东西"之间唯一的换算处，
 * 旧版正是在这里出过一批静默失效（例如手输行尾空格不保存、HEX 非法静默忽略、
 * 非 BMP 字符被拆坏、模板三份副本各自漂移）。详见交付报告的缺陷对照表。
 *
 * 运行：node test/client-ui.test.mjs
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, readdirSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

import {
  ALL_GROUP,
  DEFAULT_ROWS,
  GRADIENT_PRESETS,
  INTERPOLATIONS,
  INTERPOLATION_GROUPS,
  INTERPOLATION_REGEX,
  INTERVAL_UI_MAX,
  LOG_LEVELS,
  MAX_ROWS_PER_PANEL,
  MAX_SPACER_WIDTH,
  NEW_ROW,
  RESERVED_NAMES,
  SAVE_DEBOUNCE_MS,
  clampInterval,
  clampSpacerInput,
  colorToCss,
  colorToHex,
  effectiveSpacer,
  generateGradientCode,
  gradientBarStyle,
  gradientColorAt,
  gradientPreviewChars,
  groupWarnings,
  interpolatePreview,
  interpolationsOf,
  normalizeColorList,
  normalizeConfig,
  onlineDisplay,
  panelNamesOf,
  parseHexColor,
  parseRichText,
  presetByName,
  previewMap,
  previewSpacerDots,
  probeSummary,
  pushClass,
  richTextToPlain,
  serverRows,
  splitChars,
  stepSpacer,
  summarizePush,
  validatePanelName,
} from '../client/status-panel.js'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginDir = path.resolve(here, '..')

// ═══════════════════ 插值字典 ═══════════════════

test('插值字典 26 条：25 条与旧版界面逐字一致 + 补上旧版隐藏的 {RealWorldTime}', () => {
  assert.equal(INTERPOLATIONS.length, 26, '游戏服半支持 26 个占位符，界面必须都能插入')
  const tokens = INTERPOLATIONS.map((i) => i.token)
  assert.equal(new Set(tokens).size, 26, 'token 不能重复')
  for (const it of INTERPOLATIONS) {
    assert.ok(it.label && it.label.length > 0, `${it.token} 缺中文标签`)
    assert.ok(typeof it.preview === 'string', `${it.token} 缺预览示例值`)
    assert.ok(INTERPOLATION_GROUPS.includes(it.group), `${it.token} 的分组「${it.group}」不在分组清单里`)
    assert.ok(new RegExp(INTERPOLATION_REGEX.source).test(it.token), `${it.token} 不能被插值正则匹配`)
  }
  // 旧版刻意隐藏的那一个：必须显示出来，且标签里写明"与 {SystemTime} 相同"
  const real = INTERPOLATIONS.find((i) => i.token === '{RealWorldTime}')
  assert.ok(real, '本件把旧版隐藏的 {RealWorldTime} 显示出来，避免游戏里看到时间却查不到出处')
  assert.match(real.label, /SystemTime/)
  assert.equal(real.group, '时间')
})

test('分组成员数与旧版一致（玩家 13 / 服务器 4 / 渔夫任务 4 / 全服 1 / 时间 2 / BOSS进度 2）', () => {
  assert.deepEqual(INTERPOLATION_GROUPS, ['玩家', '服务器', '渔夫任务', '全服', '时间', 'BOSS进度'])
  assert.equal(interpolationsOf('玩家').length, 13)
  assert.equal(interpolationsOf('服务器').length, 4)
  assert.equal(interpolationsOf('渔夫任务').length, 4)
  assert.equal(interpolationsOf('全服').length, 1)
  assert.equal(interpolationsOf('时间').length, 2, '旧版只展示 1 个（{SystemTime}），本件把 {RealWorldTime} 也展示')
  assert.equal(interpolationsOf('BOSS进度').length, 2)
  assert.equal(interpolationsOf(ALL_GROUP).length, 26)
  assert.deepEqual(interpolationsOf('不存在的分组'), [])
  assert.equal(interpolationsOf().length, 26, '未指定分组时按全部处理')
})

test('预览示例值字典覆盖全部 26 个 token', () => {
  const map = previewMap()
  assert.equal(Object.keys(map).length, 26)
  for (const it of INTERPOLATIONS) assert.equal(map[it.token], it.preview)
})

// ═══════════════════ 默认模板与常量 ═══════════════════

test('默认模板 4 行与游戏服半/宿主逐字一致（旧版是三份手工同步的副本）', () => {
  assert.deepEqual(DEFAULT_ROWS(), [
    { typeName: 'DynamicText', text: '[i:757][c/f15642:开荒服]', updateInterval: 600 },
    { typeName: 'DynamicText', text: '在线人数：{OnlinePlayersCount}人', updateInterval: 60 },
    { typeName: 'DynamicText', text: '全服在线：{AllOnlineCount}人', updateInterval: 60 },
    { typeName: 'DynamicText', text: '系统时间：{SystemTime}', updateInterval: 60 },
  ])
  assert.deepEqual(NEW_ROW(), { typeName: 'DynamicText', text: '', updateInterval: 60 })
  assert.deepEqual(RESERVED_NAMES, ['on', 'off', 'show', 'hide'])
  assert.deepEqual(LOG_LEVELS, ['NONE', 'ERROR', 'WARNING', 'INFO', 'DEBUG'])
  assert.equal(MAX_SPACER_WIDTH, 500)
  assert.equal(MAX_ROWS_PER_PANEL, 20)
  assert.equal(
    INTERVAL_UI_MAX,
    1000000,
    '间隔上限必须与服端 MaxIntervalFrames / 宿主 MAX_INTERVAL_FRAMES 同为 1,000,000：'
    + '旧界面那个 max=6000 只是 HTML 提示属性、旧 JS 保存时不夹上限，'
    + '若本件按 6000 夹紧，就会在管理员下次保存时把旧配置里的 18000 静默改写成 6000',
  )
  assert.equal(SAVE_DEBOUNCE_MS, 500, '旧版自动保存是 500ms 防抖')
})

// ═══════════════════ 配置归一 ═══════════════════

test('配置归一：enabled 缺失按 false（修复旧版界面初值 true 导致"静默开启面板"）', () => {
  assert.equal(normalizeConfig({}).enabled, false)
  assert.equal(normalizeConfig({ enabled: 'true' }).enabled, false, '字符串不是布尔真值')
  assert.equal(normalizeConfig({ enabled: true }).enabled, true)
})

test('配置归一：spacerWidth 夹到 [0,500]、logLevel 非法回退 INFO（界面不再显示服务端不可能存在的值）', () => {
  assert.equal(normalizeConfig({ spacerWidth: 9999 }).spacerWidth, 500)
  assert.equal(normalizeConfig({ spacerWidth: -5 }).spacerWidth, 0)
  assert.equal(normalizeConfig({ spacerWidth: 'abc' }).spacerWidth, 60)
  assert.equal(normalizeConfig({}).spacerWidth, 60)
  assert.equal(normalizeConfig({ spacerWidth: 12.6 }).spacerWidth, 13)
  assert.equal(normalizeConfig({ logLevel: 'debug' }).logLevel, 'DEBUG')
  assert.equal(normalizeConfig({ logLevel: 'TRACE' }).logLevel, 'INFO')
  assert.equal(normalizeConfig({ logLevel: '' }).logLevel, 'INFO')
})

test('配置归一：default 面板强制存在、行字段被规整、panelSpacers 负值/非法被剔除', () => {
  const cfg = normalizeConfig({
    panels: { vip: [{ text: 'x' }, 'not-an-object', { typeName: 'StaticText', text: 5, updateInterval: 0 }] },
    panelSpacers: { vip: -1, ok: 900, bad: 'x' },
  })
  assert.deepEqual(Object.keys(cfg.panels).sort(), ['default', 'vip'])
  assert.equal(cfg.panels.default.length, 4, '没有 default 时补默认模板')
  // 行归一：非对象行被剔除；typeName 缺失变空串（不再被硬编码成 DynamicText）；text 折字符串
  assert.equal(cfg.panels.vip.length, 2)
  assert.equal(cfg.panels.vip[0].typeName, '')
  assert.equal(cfg.panels.vip[0].updateInterval, 60)
  assert.equal(cfg.panels.vip[1].typeName, 'StaticText', 'StaticText 必须保留（旧版会静默改写成 DynamicText）')
  assert.equal(cfg.panels.vip[1].text, '5')
  assert.equal(cfg.panels.vip[1].updateInterval, 1, '<1 按 1')
  assert.deepEqual(cfg.panelSpacers, { ok: 500 })
})

test('配置归一：非对象入参不抛错（宿主返回异常结构时界面仍可用）', () => {
  for (const bad of [null, undefined, 'x', 42, []]) {
    const cfg = normalizeConfig(bad)
    assert.equal(cfg.enabled, false)
    assert.equal(cfg.spacerWidth, 60)
    assert.equal(cfg.logLevel, 'INFO')
    assert.equal(cfg.panels.default.length, 4)
  }
})

test('clampInterval：缺失→60、空串→60、0/负数→1、超大→上限、小数取整、旧版超大值原样保留', () => {
  assert.equal(clampInterval(undefined), 60)
  assert.equal(clampInterval(null), 60)
  assert.equal(clampInterval(''), 60)
  assert.equal(clampInterval('abc'), 60)
  assert.equal(clampInterval(0), 1)
  assert.equal(clampInterval(-9), 1)
  assert.equal(clampInterval(99999999), INTERVAL_UI_MAX)
  assert.equal(clampInterval(60.9), 60)
  assert.equal(clampInterval('120'), 120)
  // 旧版允许存在 >6000 的间隔（JS 不夹上限），本件必须原样保留，不能静默改写用户的配置
  assert.equal(clampInterval(18000), 18000)
  assert.equal(clampInterval('18000'), 18000)
  const cfg = normalizeConfig({ panels: { p: [{ text: 'x', updateInterval: 18000 }] } })
  assert.equal(cfg.panels.p[0].updateInterval, 18000, '加载归一不得把旧的超大间隔改小')
})

// ═══════════════════ 面板与空格 ═══════════════════

test('panelNamesOf：default 永远排最前且不重复', () => {
  assert.deepEqual(panelNamesOf({ vip: [], default: [], abc: [] }), ['default', 'vip', 'abc'])
  assert.deepEqual(panelNamesOf({}), ['default'])
  assert.deepEqual(panelNamesOf(null), ['default'])
})

test('effectiveSpacer：面板覆盖优先，否则全局（与服端 panelSpacers 语义一致）', () => {
  const cfg = { spacerWidth: 60, panelSpacers: { vip: 10 } }
  assert.equal(effectiveSpacer('default', cfg), 60)
  assert.equal(effectiveSpacer('vip', cfg), 10)
  assert.equal(effectiveSpacer('vip', { spacerWidth: 60, panelSpacers: {} }), 60)
  assert.equal(effectiveSpacer('vip', { spacerWidth: 0, panelSpacers: { vip: 5 } }), 5)
})

test('previewSpacerDots：5 空格 1 个点、最多 12 个点（旧版 :415 的近似表达）', () => {
  assert.equal(previewSpacerDots(0), 0)
  assert.equal(previewSpacerDots(4), 0)
  assert.equal(previewSpacerDots(5), 1)
  assert.equal(previewSpacerDots(7), 1)
  assert.equal(previewSpacerDots(60), 12)
  assert.equal(previewSpacerDots(500), 12)
  assert.equal(previewSpacerDots(-3), 0)
  assert.equal(previewSpacerDots(NaN), 0)
})

test('stepSpacer 与 clampSpacerInput：±5 夹在 0..500；空串表示"清除覆盖"', () => {
  assert.equal(stepSpacer(60, 5), 65)
  assert.equal(stepSpacer(60, -5), 55)
  assert.equal(stepSpacer(0, -5), 0)
  assert.equal(stepSpacer(498, 5), MAX_SPACER_WIDTH)
  assert.equal(stepSpacer(undefined, 5), 5, '脏值按 0 起步而不是 NaN')

  assert.equal(clampSpacerInput(''), null, '空串 = 清除面板覆盖')
  assert.equal(clampSpacerInput('   '), 0, '只有空白按 Number("   ")=0 处理（与旧版 setter 完全同判据，不额外"聪明"）')
  assert.equal(clampSpacerInput('x'), null)
  assert.equal(clampSpacerInput('-1'), null)
  assert.equal(clampSpacerInput('9999'), MAX_SPACER_WIDTH)
  assert.equal(clampSpacerInput('12.7'), 13)
  assert.equal(clampSpacerInput(0), 0, '0 是合法值（不是"未设置"）')
})

test('validatePanelName：空名/含空格/保留字/重名（大小写不敏感）都给出可读原因', () => {
  assert.equal(validatePanelName('vip', {}), '')
  assert.match(validatePanelName('', {}), /请输入面板名称/)
  assert.match(validatePanelName('   ', {}), /请输入面板名称/)
  assert.match(validatePanelName('我的 面板', {}), /不能包含空格/)
  assert.match(validatePanelName('on', {}), /保留字/)
  assert.match(validatePanelName('OFF', {}), /保留字/)
  assert.match(validatePanelName('default', { default: [] }), /已存在/)
  assert.match(validatePanelName('Default', { default: [] }), /已存在/, '重名判断必须忽略大小写（服端选面板就是忽略大小写的）')
  assert.equal(validatePanelName(' Default ', { default: [] }), '面板「Default」已存在')
})

// ═══════════════════ 预览插值与富文本 ═══════════════════

test('interpolatePreview：已知 token 换示例值、{{x}} 转成字面量、未知 token 原样保留', () => {
  assert.equal(
    interpolatePreview('在线人数：{OnlinePlayersCount}人', previewMap()),
    '在线人数：12人',
  )
  assert.equal(interpolatePreview('{{PlayerName}}', previewMap()), '{PlayerName}', '双花括号转义（旧版预览没实现）')
  assert.equal(interpolatePreview('{NotAToken}', previewMap()), '{NotAToken}', '未知 token 原样保留（与服端一致）')
  assert.equal(interpolatePreview('{ BadSpace }', previewMap()), '{ BadSpace }', '带空格的写法不匹配插值正则')
  assert.equal(interpolatePreview(null, previewMap()), '')
  assert.equal(
    interpolatePreview('{PlayerName} 在 {WorldName}', previewMap()),
    'Steve 在 开荒服世界',
  )
})

test('parseRichText：颜色写法（3 位展开/6 位/非法当字面量）', () => {
  assert.deepEqual(parseRichText('普通文字'), [{ type: 'text', text: '普通文字' }])
  assert.deepEqual(parseRichText('[c/f00:红]'), [{ type: 'color', color: '#ff0000', text: '红' }])
  assert.deepEqual(parseRichText('[c/F15642:开荒服]'), [{ type: 'color', color: '#f15642', text: '开荒服' }])
  assert.deepEqual(parseRichText('前[c/00ff00:绿]后'), [
    { type: 'text', text: '前' },
    { type: 'color', color: '#00ff00', text: '绿' },
    { type: 'text', text: '后' },
  ])
  // 非法/边界一律当字面量（与旧版 parseRichText 同判据）
  assert.deepEqual(parseRichText('[c/xyz:文字]'), [{ type: 'text', text: '[c/xyz:文字]' }])
  assert.deepEqual(parseRichText('[c/:文字]'), [{ type: 'text', text: '[c/:文字]' }])
  assert.deepEqual(parseRichText('[c/ff00:文字]'), [{ type: 'text', text: '[c/ff00:文字]' }])
  assert.deepEqual(parseRichText('[n/]'), [{ type: 'text', text: '[n/]' }])
})

test('parseRichText：物品写法（i: / i/sX: / i/pX:，ID 必须 >0 整数）', () => {
  assert.deepEqual(parseRichText('[i:757]'), [{ type: 'item', itemId: 757 }])
  assert.deepEqual(parseRichText('[i/s5:757]'), [{ type: 'item', itemId: 757 }])
  assert.deepEqual(parseRichText('[i/p2:560]'), [{ type: 'item', itemId: 560 }])
  assert.deepEqual(parseRichText('[i:757|金鲤]'), [{ type: 'item', itemId: 757 }], 'parseInt 容忍后缀')
  for (const bad of ['[i:0]', '[i:-3]', '[i:abc]', '[i:]']) {
    assert.deepEqual(parseRichText(bad), [{ type: 'text', text: bad }], `${bad} 应作为字面量`)
  }
})

test('parseRichText：默认模板行与整行富文本混合解析', () => {
  const segs = parseRichText(DEFAULT_ROWS()[0].text)
  assert.deepEqual(segs, [
    { type: 'item', itemId: 757 },
    { type: 'color', color: '#f15642', text: '开荒服' },
  ])
  assert.equal(richTextToPlain(segs), '[物品 757]开荒服')
  assert.equal(richTextToPlain(parseRichText('在线人数：12人')), '在线人数：12人')
})

test('预览行端到端：插值 + 富文本（示例值里的 [c/…] 也会被渲染成颜色，与旧版一致）', () => {
  const segs = parseRichText(interpolatePreview('群系：{CurrentBiomes}', previewMap()))
  assert.deepEqual(segs, [
    { type: 'text', text: '群系：' },
    { type: 'color', color: '#008000', text: '森林' },
  ])
})

// ═══════════════════ 彩虹字 ═══════════════════

test('渐变预设 15 个，名称与顺序照旧版', () => {
  assert.equal(GRADIENT_PRESETS.length, 15)
  assert.deepEqual(GRADIENT_PRESETS.map((p) => p.name), [
    '彩虹', '热力', '终端', '灰色渐变', '组合', '日落', '极光', '糖果', '火焰',
    '海洋', '森林', '梦幻紫', '冰霜', '金色', '霓虹',
  ])
  const rainbow = GRADIENT_PRESETS[0]
  assert.deepEqual(rainbow.colors, [[255, 0, 0], [255, 165, 0], [255, 255, 0], [0, 255, 0], [0, 0, 255], [75, 0, 130], [148, 0, 211]])
  const terminal = GRADIENT_PRESETS.find((p) => p.name === '终端')
  assert.deepEqual(terminal.colors, [[0, 0, 0], [0, 128, 0], [0, 255, 0]])
})

test('presetByName：深拷贝（改结果不影响预设本身）、未知名字返回 null', () => {
  const a = presetByName('彩虹')
  assert.deepEqual(a, GRADIENT_PRESETS[0].colors)
  a[0][0] = 1
  assert.equal(GRADIENT_PRESETS[0].colors[0][0], 255, '必须是拷贝，否则界面改色会污染预设常量')
  assert.equal(presetByName('不存在'), null)
})

test('gradientColorAt：与旧版同算法（分段线性插值、末字符取最后一个颜色）', () => {
  const two = [[0, 0, 0], [255, 255, 255]]
  assert.deepEqual(gradientColorAt(two, 0, 1), { r: 0, g: 0, b: 0 })
  assert.deepEqual(gradientColorAt(two, 1, 1), { r: 255, g: 255, b: 255 })
  assert.deepEqual(gradientColorAt(two, 0, 2), { r: 0, g: 0, b: 0 })
  assert.deepEqual(gradientColorAt(two, 2, 2), { r: 255, g: 255, b: 255 })

  // 单色 / 空数组
  assert.deepEqual(gradientColorAt([[1, 2, 3]], 5, 5), { r: 1, g: 2, b: 3 })
  assert.deepEqual(gradientColorAt([], 0, 0), { r: 128, g: 128, b: 128 })

  // 3 字符 + 7 色：旧版会"跳色"（只用第 1、4、7 个颜色），这里如实复刻
  const seven = GRADIENT_PRESETS[0].colors
  assert.deepEqual(gradientColorAt(seven, 0, 2), { r: 255, g: 0, b: 0 })
  assert.deepEqual(gradientColorAt(seven, 1, 2), { r: 0, g: 255, b: 0 })
  assert.deepEqual(gradientColorAt(seven, 2, 2), { r: 148, g: 0, b: 211 })
})

test('colorToHex/colorToCss：6 位小写、补零、夹取', () => {
  assert.equal(colorToHex({ r: 0, g: 0, b: 0 }), '000000')
  assert.equal(colorToHex({ r: 255, g: 255, b: 255 }), 'ffffff')
  assert.equal(colorToHex({ r: 241, g: 86, b: 66 }), 'f15642')
  assert.equal(colorToHex({ r: 1, g: 2, b: 3 }), '010203')
  assert.equal(colorToHex({ r: 300, g: -5, b: 12.6 }), 'ff000d')
  assert.equal(colorToCss({ r: 255, g: 0, b: 0 }), '#ff0000')
})

test('generateGradientCode：逐字符 [c/hex:字]、小写无 #、非 BMP 不拆坏、] 被转义', () => {
  assert.equal(generateGradientCode('', [[255, 0, 0]]), '')
  assert.equal(generateGradientCode('A', [[255, 0, 0]]), '[c/ff0000:A]')
  const code = generateGradientCode('AB', [[0, 0, 0], [255, 255, 255]])
  assert.equal(code, '[c/000000:A][c/ffffff:B]')

  // 中文按码点处理：3 个汉字 = 3 个标签
  const cn = generateGradientCode('开荒服', presetByName('彩虹'))
  assert.equal((cn.match(/\[c\//g) || []).length, 3)

  // 非 BMP（扩展 B 区汉字，占 2 个 UTF-16 码元）：旧版会拆成两个孤立代理项 → 这里必须只出 1 个标签
  const rare = '\u{20BB7}'
  assert.equal(rare.length, 2, '前提：该字符在 UTF-16 里占两个码元')
  const rareCode = generateGradientCode(rare, presetByName('彩虹'))
  assert.equal((rareCode.match(/\[c\//g) || []).length, 1, '不能按码元拆开（旧版缺陷 1）')
  assert.ok(rareCode.includes(rare))

  // 用户输入 ] 不能破坏标签结构（旧版缺陷 2）
  const broken = generateGradientCode('a]b', [[255, 0, 0]])
  assert.equal((broken.match(/\]/g) || []).length, 3, '只有每个标签自己的结束符，用户的 ] 已替换')
  assert.ok(!broken.includes('a]b'))
  assert.ok(broken.includes('］'), '用户的 ] 换成全角 ］')
  // 用户的 [ 也要换掉，否则会被游戏端当成一个新标签的开头
  const bracket = generateGradientCode('[i:1]', [[255, 0, 0]])
  assert.ok(bracket.includes('［') && bracket.includes('］'), '[ 与 ] 都换成全角')
  assert.ok(!bracket.includes('[i:1]'), '原始 [i:1] 序列不能再出现（只剩每字符自己的 [c/…] 标签）')
  assert.equal((bracket.match(/\[c\//g) || []).length, 5, '5 个字符 = 5 个标签')
})

test('gradientPreviewChars 与 generateGradientCode 同源同色（旧版是两处重复实现）', () => {
  const colors = presetByName('日落')
  const text = '开荒服欢迎你'
  const chars = gradientPreviewChars(text, colors)
  const code = generateGradientCode(text, colors)
  assert.equal(chars.length, Array.from(text).length)
  const tags = code.match(/\[c\/([0-9a-f]{6}):/g) || []
  assert.equal(tags.length, chars.length)
  chars.forEach((c, i) => {
    assert.ok(tags[i].includes(c.color.slice(1)), `第 ${i} 个字符的预览色与输出色不一致`)
  })
})

test('gradientBarStyle：空数组退化为灰条，否则按颜色顺序生成 linear-gradient', () => {
  assert.equal(gradientBarStyle([]), 'background:#ccc')
  assert.equal(
    gradientBarStyle([[255, 0, 0], [0, 255, 0]]),
    'background:linear-gradient(to right,#ff0000,#00ff00)',
  )
})

test('parseHexColor：接受 3/6 位、可省 #、非法给出可读原因（旧版是静默忽略）', () => {
  assert.deepEqual(parseHexColor('#ff0000'), { ok: true, color: { r: 255, g: 0, b: 0 } })
  assert.deepEqual(parseHexColor('ff0000'), { ok: true, color: { r: 255, g: 0, b: 0 } })
  assert.deepEqual(parseHexColor('f00'), { ok: true, color: { r: 255, g: 0, b: 0 } })
  assert.deepEqual(parseHexColor('  #F15642 '), { ok: true, color: { r: 241, g: 86, b: 66 } })
  assert.equal(parseHexColor('').ok, false)
  assert.equal(parseHexColor('#').ok, false)
  assert.equal(parseHexColor('xyz').ok, false)
  assert.equal(parseHexColor('ff00').ok, false)
  assert.match(parseHexColor('xyz').error, /不是合法的十六进制/)
  assert.match(parseHexColor('ff00').error, /3 位或 6 位/)
})

test('normalizeColorList：剔除非法项、通道夹取、空列表回退灰色', () => {
  assert.deepEqual(normalizeColorList([[1, 2, 3], 'x', [300, -5, 9.6], [1, 2]]), [[1, 2, 3], [255, 0, 10]])
  assert.deepEqual(normalizeColorList([]), [[128, 128, 128]])
  assert.deepEqual(normalizeColorList(null), [[128, 128, 128]])
})

// ═══════════════════ 下发状态文案 ═══════════════════

test('summarizePush/pushClass：成功、旧式端点、跳过、未装 DLL、失败各有说法', () => {
  assert.equal(summarizePush(null), '尚未下发')
  assert.equal(summarizePush({ ok: true, version: 3 }), '已下发并确认（v3）')
  assert.match(summarizePush({ ok: true, legacy: true }), /旧式端点/)
  assert.match(summarizePush({ ok: false, error: '连接失败' }), /下发失败：连接失败/)
  assert.match(summarizePush({ ok: false, skipped: true, error: 'online-stats 未安装' }), /未下发：online-stats 未安装/)
  assert.match(summarizePush({ ok: false, serverHalfMissing: true, error: '游戏服端未安装' }), /未下发：游戏服端未安装/)
  assert.match(summarizePush({ ok: false }), /原因未知/)

  assert.equal(pushClass(null), 'sp-muted')
  assert.equal(pushClass({ ok: true }), 'sp-ok')
  assert.equal(pushClass({ ok: false, skipped: true }), 'sp-warn')
  assert.equal(pushClass({ ok: false }), 'sp-error')
})

test('serverRows：逐服状态表字段齐全（含未确认标记与全服在线数结论）', () => {
  const rows = serverRows({
    servers: [
      { id: 1, name: '一号服', enabled: true, configEnabled: true, panelCount: 2, hasConfig: true, pending: false, desiredVersion: 4, push: { ok: true, version: 4 }, online: { ok: true, total: 12 } },
      { id: 2, name: '二号服', enabled: true, configEnabled: false, panelCount: 1, hasConfig: false, pending: true, desiredVersion: 2, push: { ok: false, error: '服端落盘失败：磁盘只读' }, online: { ok: false, skipped: true, error: 'online-stats 未安装/未启用' } },
    ],
  })
  assert.equal(rows.length, 2)
  assert.equal(rows[0].pushText, '已下发并确认（v4）')
  assert.equal(rows[0].pushCls, 'sp-ok')
  assert.equal(rows[0].onlineText, '已同步（12）')
  assert.match(rows[1].pushText, /落盘失败/)
  assert.equal(rows[1].pushCls, 'sp-error')
  assert.equal(rows[1].onlineCls, 'sp-warn')
  assert.equal(rows[1].hasConfig, false)
  assert.equal(rows[1].pending, true)
  assert.deepEqual(serverRows(null), [])
  assert.deepEqual(serverRows({}), [])
})

test('probeSummary：一致/不一致/没有服务器', () => {
  assert.equal(probeSummary({ servers: [{ ok: true, match: true }, { ok: true, match: true }] }), '2 台服务器的配置与宿主完全一致')
  assert.equal(probeSummary({ servers: [{ ok: true, match: false }, { ok: true, match: true }] }), '1/2 台服务器与宿主不一致')
  assert.equal(probeSummary({ servers: [{ ok: false }] }), '1/1 台服务器与宿主不一致')
  assert.equal(probeSummary({ servers: [] }), '没有可探测的服务器')
  assert.equal(probeSummary(null), '没有可探测的服务器')
})

test('onlineDisplay：宿主不知道时显示 —（与服端占位符同一表现，而不是 0）', () => {
  assert.equal(onlineDisplay({ available: true, total: 36 }), '36')
  assert.equal(onlineDisplay({ available: true, total: 0 }), '0')
  assert.equal(onlineDisplay({ available: false, total: -1, reason: '未安装 online-stats' }), '—')
  assert.equal(onlineDisplay({ available: true, total: 'x' }), '—')
  assert.equal(onlineDisplay(null), '—')
})

test('groupWarnings：同样内容只显示一次', () => {
  const list = [
    { level: 'warn', message: 'A' },
    { level: 'warn', message: 'A' },
    { level: 'info', message: 'A' },
    { level: 'warn', message: 'B' },
    { message: 'C' },
  ]
  const out = groupWarnings(list)
  assert.equal(out.length, 4)
  assert.equal(out[3].level, 'info', '缺 level 时按 info')
  assert.deepEqual(groupWarnings(null), [])
})

// ═══════════════════ 项目硬规则 ═══════════════════

test('禁止 emoji：本插件全部源码里不含 emoji 字符（界面符号只用排版符号）', () => {
  // emoji 相关区段：杂项符号与图形、装饰符号、交通/地图、补充符号、表情、旗帜、变体选择符。
  // 说明：U+2600-U+27BF 是"杂项符号/装饰符号"块，其中混有大量 emoji（本项目一律不用该块的字符，
  // 排版符号只允许 − × ↑ ↓ · ⠿ ↩ 这类箭头/数学/盲文符号）。
  const EMOJI = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}\u{1F1E6}-\u{1F1FF}]/u
  const files = []
  const walk = (dir) => {
    for (const e of readdirSync(dir, { withFileTypes: true })) {
      if (e.name === 'bin' || e.name === 'obj' || e.name === 'node_modules') continue
      const full = path.join(dir, e.name)
      if (e.isDirectory()) walk(full)
      else if (/\.(js|mjs|json|cs|csproj)$/.test(e.name)) files.push(full)
    }
  }
  walk(pluginDir)
  assert.ok(files.length >= 15, `扫描到的源码文件太少（${files.length}），目录结构可能已经变了`)

  const bad = []
  for (const f of files) {
    const lines = readFileSync(f, 'utf8').split('\n')
    lines.forEach((line, i) => {
      const m = line.match(EMOJI)
      if (m) bad.push(`${path.relative(pluginDir, f)}:${i + 1} -> ${JSON.stringify(m[0])}`)
    })
  }
  assert.deepEqual(bad, [], '项目规则：任何位置禁止 emoji')

  // 旧版用到的排版符号应当仍在（界面文案一致性的前提）
  const src = readFileSync(path.join(pluginDir, 'client', 'status-panel.js'), 'utf8')
  for (const sym of ['−', '×', '↑', '↓', '·', '⠿', '↩']) {
    assert.ok(src.includes(sym), `旧版界面用到的排版符号 ${sym} 应当保留（非 emoji）`)
  }
})

test('前端半源码里不出现旧版的两条已废弃链路（自研路由与 HMAC 签名）', () => {
  const src = readFileSync(path.join(pluginDir, 'client', 'status-panel.js'), 'utf8')
  assert.ok(!src.includes('/tsweb/statuspanel'), '旧版自研下发路由不该在前端出现')
  assert.ok(!src.includes('HMACSHA256'), '旧版 HMAC 签名不该在前端出现')
  // 前端调用的宿主接口清单（与宿主 index.js 注册的路由一一对应）
  for (const api of [
    '/api/status-panel/servers',
    '/api/status-panel/config',
    '/api/status-panel/status',
    '/api/status-panel/push',
    '/api/status-panel/import',
  ]) {
    assert.ok(src.includes(api), `前端应当调用宿主接口 ${api}`)
  }
  assert.ok(src.includes("headers['x-server-id']"), '每台服的请求必须显式带 x-server-id（宿主按它分片配置）')
})
