/**
 * DLL 字节证据测试：证明"真的构建出了 TsWebStatusPanel.dll，且里面真的装着本件要求的东西"。
 *
 * 为什么必须做字节级断言（而不是只看文件大小/存在性）：
 *   本件交付的关键能力大多发生在游戏服侧（渲染、插 26 个占位符、发 9 号 StatusText 包、
 *   注册 5 条带 token 的 REST 路由），宿主侧测试无法执行它们；能在本机拿到的**直接证据**
 *   只有"编译产物里确实存在这些类型名/成员引用/字符串字面量"。
 *
 * 三种编码视图（**必须都扫，缺一不可**）：
 *   1. utf8（文件按 latin1 读，等价于按字节找 ASCII）：CLI 元数据的 `#Strings` 堆 ——
 *      类型名/方法名/字段名（StatusPanelRenderer / RenderPlayer / SendData / Rests …）。
 *   2. utf16le（偶数偏移）：`#US` 用户字符串堆 —— 每个字面量以"压缩长度前缀(1 或 2 字节) + UTF-16LE"
 *      存放，因此**数据起始偏移的奇偶性随前一条字面量的长度变化**。
 *   3. utf16le（奇数偏移，即 subarray(1)）：同上，但覆盖奇数起始的字面量。
 *
 * 要点：这不是理论担忧，而是本机实测：同一次构建里
 *     `/data/statuspanel/snapshot` 只在**偶数对齐**视图里出现（`{PlayerName}` 等则只在奇数对齐），
 *     而 `{AllOnlineCount}`、`开荒服` 等只在**奇数对齐**视图里出现。
 *   只扫单一对齐会得到"字面量缺失"的假阴性 —— 本文件最后一组断言把这件事固定下来。
 *
 * 运行：node test/dll-content.test.mjs
 * （本机 `node --test test/` 会因 spawn EPERM 整体失败，故逐文件运行）
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync, statSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginDir = path.resolve(here, '..')
const pluginSub = path.join(pluginDir, 'plugin')
const dllPath = path.join(pluginSub, 'TsWebStatusPanel.dll')
const binDllPath = path.join(pluginSub, 'bin', 'Release', 'net9.0', 'TsWebStatusPanel.dll')
const csprojPath = path.join(pluginSub, 'TsWebStatusPanel.csproj')

const dll = readFileSync(dllPath)
const sha256 = (buf) => createHash('sha256').update(buf).digest('hex').toUpperCase()

/**
 * 三个编码视图。命名直白：utf8=元数据堆（按字节匹配 ASCII），
 * utf16le@0 / utf16le@1=用户字符串堆的两种对齐。
 */
const VIEWS = {
  utf8: dll.toString('latin1'),
  'utf16le@0': dll.toString('utf16le'),
  'utf16le@1': dll.subarray(1).toString('utf16le'),
}

/** 某个字符串在哪些视图里出现 */
function viewsOf(s) {
  return Object.keys(VIEWS).filter((k) => VIEWS[k].includes(s))
}

function assertPresent(s, why) {
  const v = viewsOf(s)
  assert.ok(v.length > 0, `DLL 里找不到 ${JSON.stringify(s)}（${why}）`)
  return v
}

/** 从 C# 源码里抽字符串字面量（用于让断言跟着源码走，而不是手抄一份清单） */
function literalsIn(file, re) {
  const src = readFileSync(path.join(pluginSub, file), 'utf8')
  const m = src.match(re)
  assert.ok(m, `源码 ${file} 里没匹配到 ${re}`)
  return [...m[0].matchAll(/"([^"\\]*)"/g)].map((x) => x[1])
}

test('两个 DLL 副本都存在，且 plugin/ 里的与构建产物字节完全一致', () => {
  assert.ok(existsSync(dllPath), `缺少 ${dllPath}`)
  assert.ok(existsSync(binDllPath), `缺少构建产物 ${binDllPath}（先在 plugin/ 下执行 dotnet build -c Release）`)
  const a = readFileSync(binDllPath)
  assert.equal(
    sha256(a),
    sha256(dll),
    'plugin/TsWebStatusPanel.dll 与 bin/Release/net9.0/TsWebStatusPanel.dll 不一致：'
    + 'plugin/ 里那份不是这次构建出来的（陈旧产物），必须重新拷贝',
  )
  console.log(
    `[dll-content] 字节数 ${dll.length}  SHA256 ${sha256(dll)}`
    + `  mtime ${statSync(dllPath).mtime.toISOString()}`,
  )
})

test('程序集名是 TsWebStatusPanel（不得退回 StatusPanel.dll，否则会覆盖用户已装的旧插件）', () => {
  const csproj = readFileSync(csprojPath, 'utf8')
  assert.match(csproj, /<AssemblyName>TsWebStatusPanel<\/AssemblyName>/, 'csproj 缺少 <AssemblyName>TsWebStatusPanel</AssemblyName>')
  assert.match(csproj, /<RootNamespace>TsWebStatusPanel<\/RootNamespace>/, 'csproj 缺少 <RootNamespace>TsWebStatusPanel</RootNamespace>')
  assert.equal(path.basename(dllPath), 'TsWebStatusPanel.dll', '产出文件名必须是 TsWebStatusPanel.dll')
  // 元数据里也要有这个名字（类型名 + 命名空间）
  assertPresent('TsWebStatusPanel', '程序集/类型名应出现在 #Strings 堆')
})

test('DLL 比全部 C# 源码与工程文件都新（新鲜构建证据，不是陈旧产物）', () => {
  const dllTime = statSync(dllPath).mtimeMs
  const binTime = statSync(binDllPath).mtimeMs
  const sources = ['StatusPanelPlugin.cs', 'StatusPanelEndpoints.cs', 'StatusPanelConfig.cs', 'StatusPanelPlaceholders.cs',
    'StatusPanelRenderer.cs', 'StatusPanelCommands.cs', 'StatusPanelBoss.cs', 'PanelLog.cs', 'TsWebStatusPanel.csproj']
  let newest = 0
  let newestName = ''
  for (const f of sources) {
    const p = path.join(pluginSub, f)
    assert.ok(existsSync(p), `缺少源码文件 ${f}`)
    const t = statSync(p).mtimeMs
    if (t > newest) {
      newest = t
      newestName = f
    }
  }
  assert.ok(
    dllTime >= newest,
    `DLL 比源码旧：最新源码 ${newestName} (${new Date(newest).toISOString()}) 晚于 DLL (${new Date(dllTime).toISOString()})，`
    + '必须重新构建后再交付',
  )
  assert.equal(dllTime, binTime, 'plugin/ 里的 DLL 与构建产物时间戳不一致（拷贝后被改动过）')
})

test('正向对照：插件骨架与 Terraria/TShock 接口引用确实被编译进去了', () => {
  // 这些是"这确实是一个 TerrariaPlugin 插件"的最小证据；若它们不在，说明构建出了别的东西
  for (const [s, why] of [
    ['TerrariaPlugin', '插件基类（TerrariaPlugin）'],
    ['StatusPanelPlugin', '本件插件类'],
    ['Initialize', '插件初始化方法'],
    ['Dispose', '插件释放方法'],
    ['SecureRestCommand', 'TShock 带 token 的 REST 注册入口'],
    ['GamePostUpdate', 'ServerApi.Hooks.GamePostUpdate（渲染节拍）'],
    ['SendData', 'TSPlayer.SendData（发包方法）'],
    ['PacketTypes', 'Terraria.PacketTypes（协议枚举类型）'],
    ['Rests', 'TShockAPI.Rests（路由反注册用反射）'],
  ]) {
    assertPresent(s, why)
  }
})

test('渲染实现：StatusPanelRenderer.RenderPlayer 与 9 号 StatusText 包相关引用在字节里', () => {
  // 方法名在 #Strings 堆里；"Status" 这个枚举成员名太通用，单独断言没有意义，
  // 因此这里断言的是"类 + 方法 + 发包方法"三者同时存在（源码级断言见 panel-source.test.mjs）
  assertPresent('StatusPanelRenderer', '渲染器类型名')
  assertPresent('RenderPlayer', '逐玩家渲染方法名')
  assertPresent('AppendLine', '追加行方法名')
  assertPresent('ClearScreen', '清屏方法名（修复"关不掉面板"的缺陷）')
  assertPresent('MaxRowsPerPanel', '行数上限字段')
})

test('26 个占位符字面量全部在 DLL 字节里（清单从 C# 源码 AllTokens 抽取，避免手抄漂移）', () => {
  const tokens = literalsIn('StatusPanelPlaceholders.cs', /public static readonly string\[\] AllTokens\s*=[\s\S]*?\};/)
  assert.equal(tokens.length, 26, `AllTokens 应恰好 26 项，实际 ${tokens.length}`)
  assert.equal(new Set(tokens).size, 26, 'AllTokens 里有重复项')
  for (const t of tokens) {
    assert.match(t, /^\{[A-Za-z]+\}$/, `占位符形状不合法：${JSON.stringify(t)}`)
    assertPresent(t, `占位符 ${t}`)
  }
  console.log(`[dll-content] 26 个占位符全部命中：${tokens.join(' ')}`)
})

test('5 条 REST 路由、旧配置文件路径、聊天命令名都在 DLL 字节里', () => {
  // 路由清单与 StatusPanelPlugin.OwnRoutes / StatusPanelEndpoints 逐条对应
  for (const route of [
    '/data/statuspanel/snapshot',
    '/data/statuspanel/online',
    '/data/statuspanel/status',
    '/data/statuspanel/config',
    '/data/statuspanel/config/set',
  ]) {
    assertPresent(route, `端点 ${route}`)
  }
  assertPresent('data.rest.invsee', '端点权限节点')
  assertPresent('statuspanel.json', '旧版配置文件（迁移来源）')
  assertPresent('TSWeb', '旧版配置目录名')
  assertPresent('statustext', '命令名 statustext')
  assertPresent('/st', '命令别名 /st')
  assertPresent('statuspanel-config.json', '本件自己的配置文件')
})

test('中文文案在 DLL 里（命令回显与 BOSS/群系名，证明 UTF-16 字面量确实打进去了）', () => {
  for (const [s, why] of [
    ['已开启状态面板显示', '命令 /st on 的回显'],
    ['已关闭状态面板显示', '命令 /st off 的回显'],
    ['可用面板', '命令用法提示'],
    ['开荒服', '默认模板行的字面量'],
    ['史莱姆王', 'BOSS 进度表里的中文名'],
    ['全服在线', '占位符展示文案'],
  ]) {
    assertPresent(s, why)
  }
})

test('反向对照：旧版路由与旧版自研 HMAC 通道的痕迹**不存在**（证明没有重建旧链路）', () => {
  for (const [s, why] of [
    ['/tsweb/statuspanel', '旧版后端下发全服在线数的自研路由（本件已整体废弃）'],
    ['HMACSHA256', '旧版下行载荷签名算法（本件不再使用）'],
    ['WebRestServer', '旧版 REST 服务器类型（本件不再使用）'],
  ]) {
    assert.equal(viewsOf(s).length, 0, `DLL 里不该出现 ${JSON.stringify(s)}（${why}），但它出现了`)
  }
})

test('双编码/双对齐扫描的必要性（本机实测：不同字面量落在不同奇偶偏移）', () => {
  // 三个视图必须确实互不相同（否则说明扫描方式是假的）
  assert.notEqual(VIEWS['utf16le@0'], VIEWS['utf16le@1'], '两种 UTF-16 对齐视图竟然相同：扫描方式有问题')

  // 统计所有目标字面量的命中视图分布：必须同时存在"只在偶数对齐命中"与"只在奇数对齐命中"的字面量，
  // 只扫一种对齐就会漏。这条断言把"为什么测试要扫三次"固定成可回归的证据。
  const targets = [
    ...literalsIn('StatusPanelPlaceholders.cs', /public static readonly string\[\] AllTokens\s*=[\s\S]*?\};/),
    '/data/statuspanel/snapshot',
    '/data/statuspanel/online',
    '/data/statuspanel/config',
    'statuspanel.json',
    '已开启状态面板显示',
  ]
  const evenOnly = targets.filter((s) => {
    const v = viewsOf(s)
    return v.includes('utf16le@0') && !v.includes('utf16le@1') && !v.includes('utf8')
  })
  const oddOnly = targets.filter((s) => {
    const v = viewsOf(s)
    return v.includes('utf16le@1') && !v.includes('utf16le@0') && !v.includes('utf8')
  })
  assert.ok(
    evenOnly.length > 0,
    '没有"只在偶数对齐命中"的字面量：本机实测应当存在（例如 /data/statuspanel/snapshot），'
    + '若这条失败请检查扫描实现是否把字节读错了',
  )
  assert.ok(oddOnly.length > 0, '没有"只在奇数对齐命中"的字面量：本机实测应当存在（例如 {AllOnlineCount}）')
  console.log(
    `[dll-content] 仅在偶数对齐命中 ${evenOnly.length} 项（例：${evenOnly[0]}）；`
    + `仅在奇数对齐命中 ${oddOnly.length} 项（例：${oddOnly[0]}）`,
  )
})

test('调试目录证明这是 Release 构建的 TsWebStatusPanel（不是 Debug/陈旧产物）', () => {
  /**
   * Roslyn 总会在 PE 的 CodeView 调试目录里写下 **PDB 的绝对路径**（`RSDS` 之后那段）。
   * 本机实测：既有的 plugins/promotion/plugin/Promotion.dll 里同样带着
   * `C:\Users\lyt\Documents\GitHub\TsWeb\tsweb-cordis\plugins\promotion\plugin\obj\Release\...`，
   * 所以这不是本件引入的问题，而是 SDK 工程的既定行为 —— 因此**不能**断言"产物里不含开发机路径"
   * （那种断言对仓库里每个插件都会失败）。这里改为把这段路径当**证据**用：
   * 它必须指向 obj\Release\ 下的 TsWebStatusPanel.pdb。
   */
  const latin = VIEWS.utf8
  const marker = 'Documents'
  const first = latin.indexOf(marker)
  assert.ok(first >= 0, 'PE 里找不到 CodeView 调试目录中的 PDB 路径（RSDS 段）')
  assert.equal(
    latin.indexOf(marker, first + 1),
    -1,
    '开发机路径在产物里出现多次（应只出现在调试目录的 PDB 路径里一处）',
  )
  // 往前找 RSDS 签名，确认这段确实在调试目录里
  const win = latin.slice(Math.max(0, first - 64), first)
  assert.ok(win.includes('RSDS'), 'PDB 路径不在 CodeView 调试目录（RSDS）里')
  // 往后取完整路径
  const tail = latin.slice(first, first + 200)
  const path = tail.split('\u0000')[0]
  assert.ok(path.includes('obj\\Release\\'), `调试目录指向的应当是 Release 构建：${path}`)
  assert.ok(path.endsWith('TsWebStatusPanel.pdb'), `PDB 名应与程序集名一致：${path}`)
  console.log(`[dll-content] 调试目录 PDB 路径：${path}`)

  // 另外：源码文件路径不该被写进产物（只有 PDB 路径会在，源文件清单在 PDB 里）
  for (const src of ['StatusPanelRenderer.cs', 'StatusPanelEndpoints.cs']) {
    assert.equal(viewsOf(src).length, 0, `DLL 里不该出现源码文件名 ${src}（源文件清单属于 PDB）`)
  }
})
