/**
 * 分发镜像一致性测试 —— plugins/status-panel 与 tsweb-dist-lite/plugins/status-panel 必须逐字节一致。
 *
 * 为什么需要这个测试：本仓库有"开发目录 + lite 分发目录"两份拷贝，lite 目录是用户实际拿到的东西。
 * 只改开发目录会让用户拿到的仍是旧插件（而且不会报错，只会行为不一致——最难查的一类问题）。
 * 本插件包含 C# 半（.cs/.csproj）与已编译的 .dll，任何一处漏同步都会导致
 * "源码看着对、跑起来不对"，所以这里用 SHA256 逐文件比对，而不是比文件大小或时间戳。
 *
 * 比对口径（与 tsweb-dist-lite/plugins/promotion 的既有镜像结构一致）：
 *   - 包含：宿主半 .js、前端半 client/、package.json、C# 源码 .cs、.csproj、已编译 .dll、test/ 全部测试
 *   - 排除：bin/、obj/、node_modules/（构建中间产物，不进分发镜像）
 *
 * 运行：node test/dist-sync.test.mjs
 * 同步命令见交付报告；本测试失败即表示"改完没同步"，属于必须修的问题而不是可以放宽的断言。
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
/** 开发目录：.../tsweb-cordis/plugins/status-panel */
const sourceDir = path.resolve(here, '..')
/** 仓库根：.../tsweb-cordis */
const repoRoot = path.resolve(sourceDir, '..', '..')
/** lite 分发镜像：.../tsweb-cordis/tsweb-dist-lite/plugins/status-panel */
const mirrorDir = path.join(repoRoot, 'tsweb-dist-lite', 'plugins', 'status-panel')

const EXCLUDE_DIRS = new Set(['bin', 'obj', 'node_modules', '.vs'])

/** 递归列出相对路径（不含被排除的目录），按路径排序 */
function listFiles(root) {
  const out = []
  const walk = (dir) => {
    for (const e of readdirSync(dir, { withFileTypes: true })) {
      if (e.isDirectory()) {
        if (EXCLUDE_DIRS.has(e.name)) continue
        walk(path.join(dir, e.name))
      } else {
        out.push(path.relative(root, path.join(dir, e.name)).replace(/\\/g, '/'))
      }
    }
  }
  walk(root)
  return out.sort()
}

function sha256(file) {
  return createHash('sha256').update(readFileSync(file)).digest('hex')
}

test('分发镜像存在，且包含源码、前端、C# 源码与已编译 DLL（不是只有打包产物）', () => {
  assert.ok(
    existsSync(mirrorDir),
    `分发镜像不存在：${mirrorDir}\n` +
    '本插件的每个文件都必须同步到 tsweb-dist-lite/plugins/status-panel（用户拿到的就是这个目录）。\n' +
    '同步命令见交付报告；这条断言失败说明"改完没同步"，必须修，不能放宽。',
  )
  const files = listFiles(mirrorDir)
  assert.ok(files.includes('package.json'), '镜像缺 package.json')
  assert.ok(files.includes('index.js'), '镜像缺宿主半 index.js')
  assert.ok(files.includes('client/status-panel.js'), '镜像缺前端半 client/status-panel.js')
  assert.ok(files.includes('plugin/TsWebStatusPanel.csproj'), '镜像必须带 csproj（用户要从源码重建 DLL）')
  assert.ok(files.includes('plugin/TsWebStatusPanel.dll'), '镜像必须带已编译 DLL（用户开箱即用）')
  assert.ok(files.some((f) => f.startsWith('test/')), '镜像要带测试（与 promotion 的镜像结构一致）')
  assert.ok(
    !files.some((f) => f.startsWith('bin/') || f.startsWith('obj/') || f.includes('/bin/') || f.includes('/obj/')),
    '镜像里不该有 bin/obj 构建中间产物',
  )
})

test('开发目录与分发镜像逐文件 SHA256 完全一致（这是本任务最容易被漏掉的一步）', () => {
  const srcFiles = listFiles(sourceDir)
  assert.ok(srcFiles.length >= 15, `开发目录文件太少（${srcFiles.length}），路径解析可能有问题`)

  const missing = []
  const differ = []
  const same = []
  for (const rel of srcFiles) {
    const a = path.join(sourceDir, rel)
    const b = path.join(mirrorDir, rel)
    if (!existsSync(b)) {
      missing.push(rel)
      continue
    }
    const ha = sha256(a)
    const hb = sha256(b)
    if (ha !== hb) differ.push(`${rel}（开发 ${ha.slice(0, 16)}… ≠ 镜像 ${hb.slice(0, 16)}…）`)
    else same.push(`${rel}  ${statSync(a).size}B  ${ha.slice(0, 16)}…`)
  }

  // 镜像里多出来的文件也要报出来（避免删掉的文件在镜像里留成"幽灵"）
  const mirrorOnly = listFiles(mirrorDir).filter((rel) => !srcFiles.includes(rel))

  assert.deepEqual(missing, [], `这些文件只存在于开发目录、没有同步到分发镜像：\n${missing.join('\n')}`)
  assert.deepEqual(differ, [], `这些文件两边内容不一致（同步不完整）：\n${differ.join('\n')}`)
  assert.deepEqual(mirrorOnly, [], `镜像里有开发目录已经不存在/已改名的文件，需要清理：\n${mirrorOnly.join('\n')}`)

  console.log(`[dist-sync] ${same.length} 个文件逐字节一致：`)
  for (const line of same) console.log('  ' + line)
})

test('镜像里的 DLL 与开发目录构建产物（plugin/bin/Release/net9.0）也一致', () => {
  const staged = path.join(sourceDir, 'plugin', 'TsWebStatusPanel.dll')
  const built = path.join(sourceDir, 'plugin', 'bin', 'Release', 'net9.0', 'TsWebStatusPanel.dll')
  const mirrored = path.join(mirrorDir, 'plugin', 'TsWebStatusPanel.dll')
  if (!existsSync(built)) {
    assert.ok(existsSync(staged), '既没有构建产物也没有已就位的 DLL，请先构建')
    return
  }
  const hs = sha256(staged)
  const hb = sha256(built)
  const hm = sha256(mirrored)
  assert.equal(hs, hb, 'plugin/TsWebStatusPanel.dll 与 bin/Release 下的构建产物不一致（说明 DLL 没有重新就位）')
  assert.equal(hm, hs, '分发镜像里的 DLL 与开发目录的 DLL 不一致（DLL 也需要同步）')
  console.log(`[dist-sync] DLL sha256=${hs} bytes=${statSync(staged).size}（开发 / 构建 / 镜像三处一致）`)
})
