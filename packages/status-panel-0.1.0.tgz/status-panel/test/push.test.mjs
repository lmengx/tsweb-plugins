/**
 * 宿主下发链路行为测试（index.js 的路由 + 配置下发 + ack/未确认台数 + 全服在线数 + probe + 鉴权 + 审计）
 *
 * 为什么这个文件最重要：本件要根治的旧版缺陷全都发生在"宿主 -> 游戏服"这一跳上
 *   （旧版 /tsweb/statuspanel 恒回 200，于是"验签失败/参数不符/服端异常"全被当成推送成功，
 *    表现为 {AllOnlineCount} 恒显示 —，而两端日志都不报错）。
 * 所以这里的每个断言都在回答同一个问题：**下发到底有没有真的到达、真的生效、失败了有没有说出来**。
 *
 * 做法：用 test/support/fake-host.mjs 的假宿主 + 假游戏服半，直接调用插件注册在 app.get/app.post 上的
 * 处理函数（不经网络、不启动任何服务进程），并对假宿主记录的每一次游戏服调用（fake.calls）做断言。
 *
 * 运行：node test/push.test.mjs
 * （本机 `node --test test/` 会因 spawn EPERM 整体失败，故逐文件运行）
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { apply } from '../index.js'
import { ACTIONS } from '../audit.js'
import { DEFAULT_LOG_LEVEL, DEFAULT_SPACER_WIDTH, normalizeConfig } from '../config.js'
import { DLL_NAME, REST_PERMISSION, SERVER_HALF_PREFIX } from '../gameOps.js'
import { makeFakeHost, makeGameHalf, makeMemoryFs, makeOnlineStats, waitFor } from './support/fake-host.mjs'

// 游戏服半的端点（与 plugin/StatusPanelPlugin.cs 的 OwnRoutes 逐条对应）
const SNAPSHOT_PATH = `${SERVER_HALF_PREFIX}/snapshot`
const ONLINE_PATH = `${SERVER_HALF_PREFIX}/online`
const STATUS_PATH = `${SERVER_HALF_PREFIX}/status`
const CONFIG_PATH = `${SERVER_HALF_PREFIX}/config`
const LEGACY_SET_PATH = `${SERVER_HALF_PREFIX}/config/set`

/** 宿主侧的全部 9 条路由（鉴权断言要求"每条"都覆盖，所以这份清单必须与 index.js 的注册一一对应） */
const ROUTES = [
  ['get', '/api/status-panel/servers'],
  ['get', '/api/status-panel/config'],
  ['post', '/api/status-panel/config'],
  ['post', '/api/status-panel/import'],
  ['get', '/api/status-panel/status'],
  ['get', '/api/status-panel/online'],
  ['post', '/api/status-panel/push'],
  ['get', '/api/status-panel/audit'],
  ['get', '/api/status-panel/defaults'],
]

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

/** 假宿主记录的全部游戏服调用里，命中某个端点的那些 */
function callsTo(h, pathname) {
  return h.fake.calls.filter((c) => c.pathname === pathname)
}

/** 从内存文件系统里读回落盘的配置存储（证明"确实落盘了"，而不是只改了内存） */
function readStore(h) {
  const raw = h.fs.files.get(String(h.configFile).replace(/\\/g, '/'))
  assert.ok(raw, `内存文件系统里应当已有配置文件 ${h.configFile}（保存配置必须落盘：只改内存的话，宿主重启就丢）`)
  return JSON.parse(raw)
}

/** 读审计文件（AuditLog 直接用 node:fs/promises，所以这里读的是真实临时目录里的文件） */
async function readAudit(h) {
  const raw = await readFile(h.auditFile, 'utf8')
  return raw
    .split('\n')
    .filter((l) => l.trim() !== '')
    .map((l) => JSON.parse(l))
}

/**
 * 记录每个路由注册时的**完整处理函数数组**。
 * 为什么需要：makeFakeHost 只保存最后一个处理函数（业务处理器），而"每条路由都挂了
 * verifyAuth + requireAdmin"这条硬要求只能从整条中间件链上看出来。
 * 转发给原 app，保证 fake.call 仍然按原样工作。
 */
function instrumentApp(fake) {
  const original = fake.ctx.webServer.app
  const registrations = []
  const wrap = (method) => (routePath, ...handlers) => {
    registrations.push({ method, path: routePath, handlers })
    return original[method](routePath, ...handlers)
  }
  fake.ctx.webServer.app = { get: wrap('get'), post: wrap('post') }
  return registrations
}

/**
 * 假鉴权：记录中间件名，并且**读未知属性时记录下来**。
 * 为什么要记未知属性：旧版后端用的是含子管理员的 requireManager，本件改为仅 admin ——
 * 若哪天有人把 requireManager 加回来，这条断言会立刻失败。
 */
function makeAuthSpy() {
  const spy = {
    accessedUnknown: [],
    calls: [],
    deny: false,
    verifyFn: null,
    adminFn: null,
    verifyAuth() {
      spy.verifyFn = function verifyAuth(req, res, next) {
        spy.calls.push('verifyAuth')
        return next()
      }
      return spy.verifyFn
    },
    requireAdmin() {
      spy.adminFn = function requireAdmin(req, res, next) {
        spy.calls.push('requireAdmin')
        if (spy.deny) {
          res.status(403).json({ error: '仅管理员可用' })
          return undefined
        }
        return next()
      }
      return spy.adminFn
    },
  }
  return new Proxy(spy, {
    get(target, prop, receiver) {
      if (typeof prop === 'string' && !(prop in target)) {
        target.accessedUnknown.push(prop)
        return undefined
      }
      return Reflect.get(target, prop, receiver)
    },
  })
}

/**
 * 按 express 的语义依次执行一条中间件链，并如实报告"业务处理器有没有被执行"。
 * 用**下标**判断而不是 res.json 是否被调用：拒绝分支自己也会调用 res.json（403），
 * 那样判断会把"被拦下"误判成"执行了"。
 */
async function runChain(handlers, req) {
  const log = { invoked: [], status: 200, body: null, handlerInvoked: false }
  const res = {
    headersSent: false,
    status(code) {
      log.status = code
      return res
    },
    json(payload) {
      log.body = payload
      return res
    },
  }
  let i = 0
  const next = () => {
    if (i >= handlers.length) return undefined
    const idx = i++
    log.invoked.push(idx)
    return handlers[idx](req, res, next)
  }
  await next()
  log.handlerInvoked = log.invoked.includes(handlers.length - 1)
  return log
}

/** 一份通过严格校验的配置（validateConfig 会驳回任何非法值，所以这里必须是干净的） */
function validConfig(patch = {}) {
  return {
    enabled: true,
    spacerWidth: 70,
    logLevel: 'DEBUG',
    panels: { default: [{ typeName: 'DynamicText', text: '在线人数：{OnlinePlayersCount}人', updateInterval: 60 }] },
    panelSpacers: {},
    ...patch,
  }
}

async function saveConfig(h, config, serverId = h.serverIds[0]) {
  return h.fake.call('post', '/api/status-panel/config', {
    headers: { 'x-server-id': String(serverId) },
    body: { config },
  })
}

/**
 * 装载插件：独立的临时 dataDir + 内存 fs（配置存储）+ 假游戏服半。
 *
 * 两个刻意的取舍（都在"权衡"里说明过）：
 *   1. 配置存储走内存 fs（options.fsApi），但**审计文件走真实临时目录**：audit.js 直接
 *      import node:fs/promises，没有可注入的 fs 入口（见 audit.js:17 与 index.js:95），
 *      所以"审计文件内容"只能读真实文件。临时目录随用例创建/删除，互不干扰。
 *   2. 定时器全部关掉（reconcileIntervalMs / retryIntervalMs / onlineReconcileIntervalMs = 0）：
 *      本文件断言的是"一次操作的真实结果"，不是"等到下一次对账"。退避重试与周期对账会引入
 *      与时间相关的偶发失败，且会让 node:test 因未清理的定时器迟迟不退出。
 *      全服在线数的去抖默认设成 0（立即下发），需要验证去抖本身的用例再显式覆盖它。
 */
async function mount(t, opts = {}) {
  const serverIds = (opts.serverIds || ['1']).map(String)
  const serverDefs = opts.serverDefs || serverIds.map((id) => ({ id, name: `服务器${id}` }))
  const tmp = await mkdtemp(path.join(tmpdir(), 'status-panel-push-'))
  t.after(() => rm(tmp, { recursive: true, force: true }))

  const dataDir = path.join(tmp, 'status-panel')
  const configFile = path.join(dataDir, 'config.json')
  const auditFile = path.join(dataDir, 'audit.jsonl')

  const fs = opts.fsApi || makeMemoryFs()
  const gameHalf = opts.gameHalf || makeGameHalf({ serverIds })
  const onlineStats = opts.onlineStats || null

  const fake = makeFakeHost({
    dataDir,
    servers: serverDefs.map((s) => ({ raw: { enabled: true, token: `token-${s.id}`, ...s } })),
    fetchFor: (server, pathname, params) => gameHalf.fetchFor(server, pathname, params),
    // onlineStats 挂在 ctx.get 上（生产里它是 Service 子类，只能经 ctx.get 取到）
    services: onlineStats ? { onlineStats } : {},
    fsApi: fs,
  })

  const registrations = instrumentApp(fake)
  const auth = makeAuthSpy()
  fake.ctx.auth = auth

  const dispose = await apply(fake.ctx, {
    dataDir,
    configFile,
    auditFile,
    fsApi: fs,
    push: {
      reconcileIntervalMs: 0,
      retryIntervalMs: 0,
      retryMaxIntervalMs: 0,
      onlineReconcileIntervalMs: 0,
      onlineDebounceMs: 0,
      ...(opts.push || {}),
    },
  })
  // 测试结束时必须 dispose：清掉定时器与 online-stats 订阅（否则 node:test 会因活动句柄拖着不退出）
  t.after(() => dispose())

  const h = { fake, gameHalf, onlineStats, auth, registrations, dataDir, configFile, auditFile, fs, dispose, serverIds }

  // init() 里的"启动即读一次全服在线数"是 fire-and-forget（index.js:144），
  // 不先等它落地，后面按 fake.calls 数量做的断言会随微任务时机漂移（偶发失败）。
  const expectedStartupOnline = onlineStats ? serverIds.length : 0
  if (expectedStartupOnline > 0) {
    await waitFor(() => callsTo(h, ONLINE_PATH).length >= expectedStartupOnline, {
      label: '启动时下发全服在线数落地',
    })
  }
  await sleep(15)
  return h
}

// ═══════════════════ 配置下发 ═══════════════════

test('保存配置立即向目标服下发 /data/statuspanel/snapshot，且 query 逐项正确', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })
  const config = validConfig({
    panels: {
      default: [
        { typeName: 'DynamicText', text: '在线人数：{OnlinePlayersCount}人', updateInterval: 60 },
        { typeName: 'StaticText', text: '固定行', updateInterval: 600 },
      ],
      vip: [{ typeName: 'DynamicText', text: 'VIP 面板', updateInterval: 120 }],
    },
    panelSpacers: { vip: 3 },
  })

  const resp = await saveConfig(h, config)
  assert.equal(resp.status, 200, '保存配置是常规成功路径，不该回非 200')
  assert.equal(resp.data.ok, true, '顶层 ok 必须反映下发结果：它就是"改动到底生效了没有"的答案')
  assert.equal(resp.data.push.ok, true, '推送结果必须原样回给界面（旧版恒回成功，本件不允许）')
  assert.equal(resp.data.push.servers.length, 1, '只保存了 1 台服的配置，就该只有 1 条逐服结果')
  assert.equal(resp.data.push.servers[0].ok, true, '服端已确认应用 + 已落盘，这一服才算成功')

  const snaps = callsTo(h, SNAPSHOT_PATH)
  assert.equal(snaps.length, 1, '配置变更必须立即下发一次（这是"界面显示已启用、实际没生效"的解药）')
  assert.equal(snaps[0].serverId, '1', '下发必须发给 x-server-id 指定的那台服')

  const p = snaps[0].params
  assert.ok(/^[1-9]\d*$/.test(p.version), `下发必须带单调正整数 version（服端据此拒绝乱序旧载荷），实际 ${JSON.stringify(p.version)}`)
  assert.equal(p.enabled, 'true', 'enabled 必须是服端认得的 true/false 字符串')
  assert.equal(p.spacerWidth, '70', 'spacerWidth 必须以数字字符串下发（服端 int.TryParse）')
  assert.equal(p.logLevel, 'DEBUG', 'logLevel 必须原样下发（本件让这个旧版死字段真正生效）')
  assert.deepEqual(
    JSON.parse(p.panels),
    normalizeConfig(config).panels,
    'panels 必须是可 JSON.parse 的字符串，且内容等于宿主归一后的面板（两边不同步就等于下发了一份别的配置）',
  )
  assert.deepEqual(JSON.parse(p.panelSpacers), { vip: 3 }, 'panelSpacers 同样要以 JSON 字符串下发')
  assert.equal(p.allOnlineCount, '12', '宿主已经知道全服在线数时，应随配置一起带上（首次下发就不让面板显示 —）')
  assert.ok(typeof p.ts === 'string' && p.ts.length > 0, 'ts 是排障用的下发时刻，必须带上')

  // 不只信宿主的回包：假服端确实把这份配置应用了
  assert.equal(h.gameHalf.applied.get('1').spacerWidth, 70, '服端应用后的 spacerWidth 必须与下发一致')
  assert.equal(h.gameHalf.applied.get('1').logLevel, 'DEBUG')
  assert.deepEqual(Object.keys(h.gameHalf.applied.get('1').panels).sort(), ['default', 'vip'])
  assert.equal(resp.data.push.servers[0].serverAllOnlineCount, 12, '服端回包的运行期快照要原样回显：这是"在线数真的到位"的直接证据')

  // 响应里的配置与变更项
  assert.equal(resp.data.config.enabled, true)
  assert.deepEqual(
    resp.data.changed,
    ['enabled', 'spacerWidth', 'logLevel', 'panels', 'panelSpacers'],
    'changed 要如实列出真的变了的字段（避免"看起来保存了其实没变"）',
  )
})

test('配置按服务器分片：两台服各存一份、每次下发只打目标服', async (t) => {
  const h = await mount(t, {
    serverIds: ['1', '2'],
    serverDefs: [
      { id: '1', name: '一号服' },
      { id: '2', name: '二号服' },
    ],
    onlineStats: makeOnlineStats({
      total: 12,
      servers: [
        { id: '1', name: '一号服', playercount: 5 },
        { id: '2', name: '二号服', playercount: 7 },
      ],
    }),
  })

  const cfgA = validConfig({
    spacerWidth: 70,
    panels: { default: [{ typeName: 'DynamicText', text: 'A 服', updateInterval: 60 }] },
  })
  const cfgB = validConfig({
    enabled: false,
    spacerWidth: 20,
    logLevel: 'WARNING',
    panels: { default: [{ typeName: 'DynamicText', text: 'B 服 {PlayerName}', updateInterval: 30 }] },
    panelSpacers: {},
  })

  const base = callsTo(h, SNAPSHOT_PATH).length
  await saveConfig(h, cfgA, '1')
  const afterA = callsTo(h, SNAPSHOT_PATH)
  assert.equal(afterA.length, base + 1, '保存 A 服配置只该产生一次下发，不得顺带重推别台服')
  assert.equal(afterA[afterA.length - 1].serverId, '1', '这一次下发只打 A 服')

  await saveConfig(h, cfgB, '2')
  const afterB = callsTo(h, SNAPSHOT_PATH)
  assert.equal(afterB.length, afterA.length + 1, '保存 B 服配置同样只该产生一次下发')
  assert.equal(afterB[afterB.length - 1].serverId, '2', '这一次下发只打 B 服')
  assert.equal(afterB[afterB.length - 1].params.spacerWidth, '20', 'B 服拿到的必须是 B 的配置，不能是 A 的')

  // 落盘按服分片，互不覆盖
  const store = readStore(h)
  assert.deepEqual(Object.keys(store.servers).sort(), ['1', '2'], '两台服各存一份（旧版语义就是每台服一份 statuspanel.json）')
  assert.equal(store.servers['1'].spacerWidth, 70, 'A 服的配置不能被 B 服的保存动作覆盖')
  assert.equal(store.servers['1'].panels.default[0].text, 'A 服')
  assert.equal(store.servers['2'].spacerWidth, 20, 'B 服的配置不能被 A 服的保存动作覆盖')
  assert.equal(store.servers['2'].panels.default[0].text, 'B 服 {PlayerName}')

  // 服端各自应用的也是各自那份
  assert.equal(h.gameHalf.applied.get('1').spacerWidth, 70)
  assert.equal(h.gameHalf.applied.get('2').spacerWidth, 20)
  assert.equal(h.gameHalf.applied.get('2').enabled, false, 'B 服被显式保存成未启用，服端就必须是未启用')

  // 界面用的逐服概览必须按服读取
  const ov = await h.fake.call('get', '/api/status-panel/servers')
  const s1 = ov.data.servers.find((s) => s.id === '1')
  const s2 = ov.data.servers.find((s) => s.id === '2')
  assert.equal(s1.spacerWidth, 70, '概览里 A 服的 spacerWidth 必须是 A 的')
  assert.equal(s2.spacerWidth, 20, '概览里 B 服的 spacerWidth 必须是 B 的')
  assert.equal(s1.hasConfig, true)
  assert.equal(s2.hasConfig, true)
})

// ═══════════════════ 失败可见（本任务的核心修复） ═══════════════════

test('失败可见之一：服端收下但落盘失败（saveFail）必须算失败，文案含"落盘"', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })
  h.gameHalf.setBehavior('1', 'saveFail')

  const resp = await saveConfig(h, validConfig())
  assert.equal(resp.data.ok, false, '服端写盘失败就不是成功：只改内存的话，游戏服重启后配置会悄悄退回旧值')
  assert.equal(resp.data.push.ok, false, 'push.ok 必须为 false（旧版把这类失败全当成推送成功）')
  const entry = resp.data.push.servers[0]
  assert.equal(entry.ok, false, '这一服必须被标记为失败')
  assert.match(entry.error, /落盘/, `错误文案要说清是"服端落盘失败"，实际：${entry.error}`)
  assert.equal(entry.saveError, '磁盘只读', '服端原文的 saveError 要原样带回来（管理员据此排障）')
  assert.equal(entry.applied, true, '这一例的服端确实替换了内存里的配置，但"应用了"不等于"成功了"')

  // 未确认的服必须出现在未确认清单里（失败不会被静默当成已生效）
  const st = await h.fake.call('get', '/api/status-panel/status')
  assert.ok(st.data.pendingServerIds.includes('1'), '下发失败的服必须仍是"未确认"状态，否则界面会以为它已经生效')
})

test('失败可见之二：服端已有更新版本（stale）必须算失败，文案含"已有更新版本"', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })
  h.gameHalf.setBehavior('1', 'stale')

  const resp = await saveConfig(h, validConfig())
  const entry = resp.data.push.servers[0]
  assert.equal(resp.data.push.ok, false, '载荷被服端拒绝（stale）等于没生效，绝不能报成功')
  assert.match(entry.error, /已有更新版本/, `必须说清是"服端版本更新"，实际：${entry.error}`)
  assert.equal(entry.stale, true, 'stale 标志要如实透传（排障时它是"乱序/重试"的直接证据）')
  assert.equal(entry.applied, false, 'stale 时服端明确没应用本次载荷')
  assert.equal(entry.version, 99, '回显服端当前版本号，管理员才知道服端跑到哪一版了')
})

test('失败可见之三：目标服未装 DLL（404）要报 501 + serverHalfMissing，而不是含糊的失败', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })
  h.gameHalf.setBehavior('1', 'missing')

  const resp = await saveConfig(h, validConfig())
  const entry = resp.data.push.servers[0]
  assert.equal(resp.data.push.ok, false, '目标服没装 TsWebStatusPanel.dll 就是下发失败')
  assert.equal(entry.serverHalfMissing, true, '必须给出 serverHalfMissing 标记：界面据此提示"请对该服务器启用本插件"，而不是让管理员猜')
  assert.equal(entry.status, 501, `"游戏服缺少本插件的游戏服半"在本仓各插件里统一用 501 表示，实际 ${entry.status}`)
  assert.match(entry.error, new RegExp(DLL_NAME.replace('.', '\\.')), `错误文案要点名缺少的 DLL（${DLL_NAME}），实际：${entry.error}`)
})

test('失败可见之四：token 权限不足（403）映射成 502 语义（不是 400、也不是成功）', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })
  h.gameHalf.setBehavior('1', 'forbidden')

  const resp = await saveConfig(h, validConfig())
  const entry = resp.data.push.servers[0]
  assert.equal(resp.data.push.ok, false, '权限不足时下发并没生效')
  assert.equal(entry.status, 502, `服端 401/403 在本仓约定里映射为 502（宿主的凭据问题，不是请求参数错），实际 ${entry.status}`)
  assert.match(entry.error, /权限不足/, `错误文案要说清是 token 权限问题，实际：${entry.error}`)
  assert.match(entry.error, new RegExp(REST_PERMISSION.replace('.', '\\.')), `要给出所需权限节点 ${REST_PERMISSION}（管理员才知道给 token 加什么权限）`)
})

test('失败可见之五：服端 400 必须把**服端原文**透传给管理员（不许折成"游戏服返回异常"）', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })
  h.gameHalf.setBehavior('1', 'badRequest')

  const resp = await saveConfig(h, validConfig())
  const entry = resp.data.push.servers[0]
  assert.equal(resp.data.push.ok, false, '服端拒绝参数就是下发失败')
  assert.equal(entry.status, 400, `服端参数被拒应保持 400 语义（便于与"服端坏了"区分），实际 ${entry.status}`)
  assert.match(
    entry.error,
    /panels 里存在不是数组的面板/,
    `服端的原文必须透传（否则管理员只知道"失败了"，不知道哪一项参数不对），实际：${entry.error}`,
  )
})

test('失败不吞掉已落盘的配置：宿主存储与服端生效状态必须能被分别看见', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })
  h.gameHalf.setBehavior('1', 'saveFail')

  const resp = await saveConfig(h, validConfig({ spacerWidth: 88 }))
  const store = readStore(h)
  assert.equal(store.servers['1'].spacerWidth, 88, '宿主侧仍要落盘：否则管理员改的配置在宿主重启后就丢了（顺序是"先落盘再下发"）')
  assert.equal(resp.data.push.servers[0].ok, false, '但下发失败这件事必须照实回报，两者不能混为一谈')
})

// ═══════════════════ ack / 未确认台数 ═══════════════════

test('ack 与未确认台数：没推过算未确认、推成功即确认、推失败退回未确认', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })

  const st0 = await h.fake.call('get', '/api/status-panel/status')
  assert.equal(st0.data.pendingCount, 1, '从未下发过的启用服也算未确认（否则界面会误以为"全新安装就已经生效"）')
  assert.deepEqual(st0.data.pendingServerIds, ['1'])

  const resp = await saveConfig(h, validConfig())
  assert.equal(resp.data.push.pendingCount, 0, '下发成功并落盘后，该服的"未确认"计数要立刻清零')

  const st1 = await h.fake.call('get', '/api/status-panel/status')
  assert.equal(st1.data.pendingCount, 0, '下发成功后该服不该再是 pending')
  assert.deepEqual(st1.data.pendingServerIds, [], 'pendingServerIds 必须与 pendingCount 一致（界面直接显示它）')

  // 同一台服改成会失败的行为后再改配置 -> 既有的 ack 记录必须被撤掉
  h.gameHalf.setBehavior('1', 'saveFail')
  const resp2 = await saveConfig(h, validConfig({ spacerWidth: 55 }))
  assert.equal(resp2.data.push.ok, false, '第二次下发是失败的')
  const st2 = await h.fake.call('get', '/api/status-panel/status')
  assert.equal(st2.data.pendingCount, 1, '失败的服必须退回"未确认"：留着旧的 ack 会让界面显示"已是最新"，而服端其实还是旧配置')
  assert.deepEqual(st2.data.pendingServerIds, ['1'])
})

test('改配置后重新变为未确认（pushOnChange=false 时最能看清这个状态）', async (t) => {
  const h = await mount(t, {
    push: { pushOnChange: false },
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })

  const resp = await saveConfig(h, validConfig())
  assert.equal(resp.data.push.total, 0, 'pushOnChange=false 时保存不自动下发（响应里要如实说明）')
  assert.match(resp.data.push.note, /pushOnChange=false/, `响应要写明"本次未自动下发"，实际：${resp.data.push.note}`)
  assert.equal(callsTo(h, SNAPSHOT_PATH).length, 0, '确实没有下发')

  // 手动推一次让它被确认
  const pushed = await h.fake.call('post', '/api/status-panel/push', { body: { onlyPending: true } })
  assert.equal(pushed.data.push.ok, true, '手动重推应当把这台未确认的服推成功')
  const st1 = await h.fake.call('get', '/api/status-panel/status')
  assert.equal(st1.data.pendingCount, 0, '手动推成功后应当已确认')

  // 再改配置（仍然不自动下发）-> 修订号前进，于是重新变成未确认
  await saveConfig(h, validConfig({ spacerWidth: 42 }))
  const st2 = await h.fake.call('get', '/api/status-panel/status')
  assert.equal(st2.data.pendingCount, 1, '配置变了就必须重新变成未确认：否则"改了但没推"这种状态在界面上完全看不见')
  assert.deepEqual(st2.data.pendingServerIds, ['1'])
})

// ═══════════════════ 全服在线数 ═══════════════════

test('GET /online：online-stats 可用时给出 total 与逐服 playercount', async (t) => {
  const h = await mount(t, {
    serverIds: ['1', '2'],
    serverDefs: [
      { id: '1', name: '一号服' },
      { id: '2', name: '二号服' },
    ],
    onlineStats: makeOnlineStats({
      total: 12,
      servers: [
        { id: '1', name: '一号服', playercount: 5 },
        { id: '2', name: '二号服', playercount: 7 },
      ],
    }),
  })

  const resp = await h.fake.call('get', '/api/status-panel/online')
  assert.equal(resp.data.ok, true, '读得到全服在线数时 ok 应为 true')
  assert.equal(resp.data.online.available, true)
  assert.equal(resp.data.online.total, 12, '全服在线数必须来自 ctx.onlineStats.getCurrent()（唯一计算点，不再让各服自己上报）')
  assert.equal(resp.data.online.display, '12')
  assert.deepEqual(
    resp.data.online.perServer,
    [
      { id: '1', name: '一号服', playercount: 5 },
      { id: '2', name: '二号服', playercount: 7 },
    ],
    '逐服在线数要一起给出（界面对照"宿主算的"与"服端显示的"时用它）',
  )
})

test('POST /push：每台服都收到 /data/statuspanel/online，且所有服拿到同一个数字', async (t) => {
  const h = await mount(t, {
    serverIds: ['1', '2'],
    serverDefs: [
      { id: '1', name: '一号服' },
      { id: '2', name: '二号服' },
    ],
    onlineStats: makeOnlineStats({
      total: 12,
      servers: [
        { id: '1', name: '一号服', playercount: 5 },
        { id: '2', name: '二号服', playercount: 7 },
      ],
    }),
  })
  h.onlineStats.setTotal(23)

  const baseOnline = callsTo(h, ONLINE_PATH).length
  const baseSnap = callsTo(h, SNAPSHOT_PATH).length
  const resp = await h.fake.call('post', '/api/status-panel/push', { body: {} })

  assert.equal(resp.status, 200)
  assert.equal(resp.data.online.total, 23, '响应要回显本次下发的全服在线数')

  const onlineCalls = callsTo(h, ONLINE_PATH).slice(baseOnline)
  assert.deepEqual(
    onlineCalls.map((c) => c.serverId).sort(),
    ['1', '2'],
    '手动重推要给每一台启用服都发一次全服在线数（漏一台那台就会一直显示 —）',
  )
  assert.equal(new Set(onlineCalls.map((c) => c.params.total)).size, 1, '所有服必须拿到**同一个**数字：各服自己取值正是旧版"两台服显示不同在线数"的根因')
  assert.equal(onlineCalls[0].params.total, '23', '下发的必须是刚读到的那个数')
  assert.ok(typeof onlineCalls[0].params.ts === 'string' && onlineCalls[0].params.ts.length > 0)

  // 两份独立证据：服端内存里的值，以及服端回包里的显示值
  assert.equal(h.gameHalf.allOnline.get('1'), 23, '一号服服端要真的收到这个数')
  assert.equal(h.gameHalf.allOnline.get('2'), 23, '二号服服端要真的收到同一个数')

  // 配置下发与在线数下发是两回事。注意手动重推的**实际顺序**是"先推配置、后刷在线数"
  // （index.js:1184-1189），所以配置载荷里带的是宿主机**上一次已知**的在线数 12，
  // 刚读到的 23 由紧随其后的 /data/statuspanel/online 下发。
  // 这里断言的是"带的是已知值而不是 -1"：-1 会让服端**保持**它当前的值，等于这条路白走一趟。
  const snapCalls = callsTo(h, SNAPSHOT_PATH).slice(baseSnap)
  assert.ok(snapCalls.length >= 2, '手动重推要覆盖所有启用服的配置下发')
  assert.deepEqual(
    [...new Set(snapCalls.map((c) => c.params.allOnlineCount))],
    ['12'],
    '配置载荷要带上宿主已知的全服在线数（上一轮读到的 12），而不是"未知"哨兵 -1',
  )
})

test('online-stats 不可用：如实报不可用、显示 —、不下发，但把 skipped 与原因记下来', async (t) => {
  // services 里不给 onlineStats：等价于"没装 online-stats 插件"
  const h = await mount(t, {})

  const resp = await h.fake.call('get', '/api/status-panel/online')
  assert.equal(resp.data.ok, false, '读不到全服在线数时不能报 ok')
  assert.equal(resp.data.online.available, false, 'available 必须为 false（界面据此显示 —）')
  assert.equal(resp.data.online.total, -1, '-1 是与游戏服半一致的"未知"哨兵（服端据此保持当前值，而不是被写成 0）')
  assert.equal(resp.data.online.display, '—', '显示必须是全角破折号 —（与旧版 AllOnlineDisplay 逐字一致）')
  assert.match(resp.data.online.reason, /online-stats/, `原因必须写清是 online-stats 不可用，实际：${resp.data.online.reason}`)

  const pushed = resp.data.pushed['1']
  assert.ok(pushed, '逐服记录里应当有这台服的条目（skipped 也是一种必须可见的结果）')
  assert.equal(pushed.skipped, true, '读不到在线数时是"跳过"，不是"推送失败"')
  assert.match(pushed.error, /online-stats/, '跳过原因要原样记下来，管理员才知道 {AllOnlineCount} 为什么是 —')

  // 关键：读不到就**不要下发**（否则会把服端显示的好数字覆盖成 0 或 —）
  assert.equal(callsTo(h, ONLINE_PATH).length, 0, 'online-stats 不可用时不得发出任何 /data/statuspanel/online 请求')

  const resp2 = await h.fake.call('post', '/api/status-panel/push', { body: {} })
  assert.equal(resp2.data.online.available, false, '手动重推同样要如实回答"这一轮没有下发在线数"')
  assert.equal(resp2.data.online.servers[0].skipped, true, '逐服结果里要标明 skipped')
  assert.match(resp2.data.online.servers[0].error, /online-stats/)
  assert.equal(callsTo(h, ONLINE_PATH).length, 0, '手动重推也不得因为读不到就发出无效请求')

  const st = await h.fake.call('get', '/api/status-panel/status')
  assert.equal(st.data.online.available, false, '/status 同样要如实报不可用')
  assert.equal(st.data.online.display, '—')
  assert.deepEqual(st.data.onlineFailures, [], 'skipped 不是"失败"：不该出现在 onlineFailures 里（否则退避重试会永远停不下来）')
})

test('online-stats 事件：change 触发下发、tick 未变不重发、变了才发', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })
  assert.equal(h.onlineStats.listenerCount(), 2, '应当同时订阅 change（变化即推）与 tick（采集节拍）两个事件')

  // change：去抖窗口设为 0 时立即下发
  const base = callsTo(h, ONLINE_PATH).length
  h.onlineStats.fire('change')
  await waitFor(() => callsTo(h, ONLINE_PATH).length >= base + 1, { label: 'change 事件触发的全服在线数下发' })
  assert.equal(callsTo(h, ONLINE_PATH)[base].params.total, '12')

  // tick 且在线数没变：不重复下发（旧版每次聚合变化都推，这里不该每 60s 白推一遍）
  const afterChange = callsTo(h, ONLINE_PATH).length
  h.onlineStats.fire('tick')
  await sleep(50)
  assert.equal(callsTo(h, ONLINE_PATH).length, afterChange, '采集节拍发现在线数没变时不该重复下发（否则每台服每轮都被白推一次）')

  // 改了在线数：tick 触发下发
  h.onlineStats.setTotal(31)
  h.onlineStats.fire('tick')
  await waitFor(() => callsTo(h, ONLINE_PATH).length > afterChange, { label: '在线数变化后由 tick 触发的下发' })
  const last = callsTo(h, ONLINE_PATH).at(-1)
  assert.equal(last.params.total, '31', '在线数变了就必须下发新值')
  assert.equal(h.gameHalf.allOnline.get('1'), 31, '服端要真的收到新值')
})

test('online-stats 的 change 事件会去抖合并：一次上下线风暴只下发一轮', async (t) => {
  const h = await mount(t, {
    push: { onlineDebounceMs: 15 },
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })

  const base = callsTo(h, ONLINE_PATH).length
  h.onlineStats.fire('change')
  h.onlineStats.fire('change')
  h.onlineStats.fire('change')
  await waitFor(() => callsTo(h, ONLINE_PATH).length >= base + 1, { label: '去抖后的一轮下发' })
  await sleep(80)
  assert.equal(
    callsTo(h, ONLINE_PATH).length,
    base + 1,
    '三次连续 change 必须合并成一轮下发（去抖的意义就在这里；否则一轮风暴会把每台服打好几次）',
  )
})

// ═══════════════════ 旧式端点 / 导入 / probe ═══════════════════

test('旧式端点：POST /push { legacy: true } 打到 /config/set，不带版本协议，也不影响 ack', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })
  const config = validConfig({ spacerWidth: 33 })
  await saveConfig(h, config)
  // 先把它推成"已确认"，再验证旧式下发不会把 ack 状态搅坏
  const st0 = await h.fake.call('get', '/api/status-panel/status')
  assert.equal(st0.data.pendingCount, 0, '前置条件：这一台服此刻已确认')

  const baseLegacy = callsTo(h, LEGACY_SET_PATH).length
  const baseSnap = callsTo(h, SNAPSHOT_PATH).length
  const resp = await h.fake.call('post', '/api/status-panel/push', { body: { legacy: true } })

  const legacyCalls = callsTo(h, LEGACY_SET_PATH).slice(baseLegacy)
  assert.equal(legacyCalls.length, 1, 'legacy=true 必须改走旧式端点 /data/statuspanel/config/set（等价旧版能力）')
  assert.equal(legacyCalls[0].serverId, '1')
  assert.equal(
    callsTo(h, SNAPSHOT_PATH).length,
    baseSnap,
    'legacy=true 时不得再走版本化端点 /snapshot（两条链路不能混着发，否则无法判断服端跑的是哪一份）',
  )

  const p = legacyCalls[0].params
  assert.deepEqual(
    Object.keys(p).sort(),
    ['enabled', 'logLevel', 'panelSpacers', 'panels', 'spacerWidth'],
    '旧式载荷只带旧版认得的字段（没有 version/ts/allOnlineCount：旧式端点没有版本协议）',
  )
  assert.equal(p.version, undefined, '旧式端点不得携带 version')
  assert.equal(p.spacerWidth, '33')
  assert.deepEqual(JSON.parse(p.panels), normalizeConfig(config).panels)
  assert.equal(h.gameHalf.localEdits.get('1'), 1, '旧式写入必须被服端记为"绕过宿主的本地改写"（localEdits 自增）')

  const entry = resp.data.push.servers[0]
  assert.equal(entry.legacy, true, '逐服结果要标明这次是旧式下发')
  assert.equal(entry.ok, true, '假服端确认收到并保存了')
  assert.equal(entry.sentVersion, null, '旧式下发没有宿主侧版本号')
  assert.equal(entry.applied, true)

  const st1 = await h.fake.call('get', '/api/status-panel/status')
  assert.equal(st1.data.pendingCount, 0, '旧式下发不该把已确认的服打成未确认（它不参与 ack 协议）')
})

test('旧式端点不会把没确认过的服"顺手确认"掉（ack 只认版本化下发）', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })

  const resp = await h.fake.call('post', '/api/status-panel/push', { body: { legacy: true } })
  assert.equal(resp.data.push.servers[0].ok, true, '旧式端点在假服端上是成功的')
  assert.equal(callsTo(h, LEGACY_SET_PATH).length, 1)

  const st = await h.fake.call('get', '/api/status-panel/status')
  assert.deepEqual(
    st.data.pendingServerIds,
    ['1'],
    '旧式下发没有版本协议，因此不能算"已确认最新配置"：否则界面会显示已生效，而宿主下次对账又推一份，永远说不清',
  )
})

test('导入：把假服端 /config 返回的配置存成宿主配置，并按响应与落盘两处核对', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })

  const serverConfig = {
    enabled: true,
    spacerWidth: 25,
    logLevel: 'DEBUG',
    panels: {
      default: [{ typeName: 'DynamicText', text: '服端原有行 {WorldName}', updateInterval: 300 }],
      开荒: [{ typeName: 'StaticText', text: '开荒提示', updateInterval: 60 }],
    },
    panelSpacers: { 开荒: 7 },
  }
  h.gameHalf.setConfig('1', serverConfig)

  const resp = await h.fake.call('post', '/api/status-panel/import', { headers: { 'x-server-id': '1' } })
  assert.equal(resp.status, 200)
  assert.equal(resp.data.ok, true, '导入后紧接着下发成功')
  assert.equal(resp.data.serverId, '1')

  const expected = normalizeConfig(serverConfig)
  assert.deepEqual(resp.data.config, expected, '响应里的 config 必须等于服端读回并归一后的那份（导入的语义就是"服端现在跑什么，宿主就存什么"）')
  assert.equal(resp.data.config.enabled, true, '服端开启状态要被导入（旧版用户升级上来时，这是保住他原有配置的关键）')
  assert.equal(resp.data.config.panelSpacers.开荒, 7)

  const store = readStore(h)
  assert.deepEqual(store.servers['1'], expected, '落盘内容必须与响应一致（否则重启后宿主会退回另一份配置）')

  // 导入确实是从服端读的
  assert.ok(callsTo(h, CONFIG_PATH).length >= 1, '导入必须真的去读服端的 /data/statuspanel/config')
  assert.equal(callsTo(h, SNAPSHOT_PATH).length, 1, '导入后要推一次：把宿主的版本号盖上去，从此服端受宿主版本协议约束')

  // 导入动作也要进审计（迁移是管理员动作，必须留痕）
  const entries = await readAudit(h)
  assert.ok(
    entries.some((e) => e.action === ACTIONS.configImport && e.serverId === '1'),
    '导入必须在审计里留一条 status-panel.config.import 记录',
  )
})

test('probe：一致时 match=true 且 diff 为空；服端被改动后 diff 要给出可读描述；在线数不同则 onlineMatch=false', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })

  const config = validConfig({
    spacerWidth: 88,
    panels: { default: [{ typeName: 'DynamicText', text: '面板第一行 {PlayerName}', updateInterval: 60 }] },
  })
  await saveConfig(h, config)
  // 再手动推一轮，保证"宿主的全服在线数"与"服端当前显示的"是同一个数
  await h.fake.call('post', '/api/status-panel/push', { body: {} })

  const ok = await h.fake.call('get', '/api/status-panel/status', { query: { probe: '1' } })
  const s0 = ok.data.probe.servers[0]
  assert.equal(s0.ok, true, 'probe 本身要成功')
  assert.deepEqual(s0.diff, [], `两侧一致时 diff 必须为空，实际：${JSON.stringify(s0.diff)}`)
  assert.equal(s0.match, true, 'match 是界面直接显示的那一位（"服端与宿主是否一致"）')
  assert.equal(s0.onlineMatch, true, '宿主算出的全服在线数与服端当前显示的必须是同一个数')
  assert.match(s0.evidence.summary, /一致/, '要给出一行人话结论')
  assert.ok(callsTo(h, STATUS_PATH).length >= 1, 'probe 要问服端 /status（运行期自证）')
  assert.ok(callsTo(h, CONFIG_PATH).length >= 1, 'probe 也要问服端 /config（旧格式配置，正是旧版后端看到的那份视图）')

  // 有人改了服端（或旧式端点写入）-> diff 必须能看出是哪里不一致
  h.gameHalf.setConfig('1', { spacerWidth: 33 })
  const bad = await h.fake.call('get', '/api/status-panel/status', { query: { probe: '1' } })
  const s1 = bad.data.probe.servers[0]
  assert.equal(s1.match, false, '服端配置偏离宿主时必须 match=false（否则"界面显示生效了、服端其实没生效"永远发现不了）')
  assert.ok(s1.diff.length > 0, 'diff 必须非空')
  assert.ok(
    s1.diff.some((d) => d.includes('spacerWidth') && d.includes('33')),
    `diff 要说清是哪个字段、服端是多少、宿主是多少，实际：${JSON.stringify(s1.diff)}`,
  )
  assert.match(s1.evidence.summary, /不一致/, '结论要一眼看出不一致')

  // 恢复一致后再验证在线数不一致的情形
  await h.fake.call('post', '/api/status-panel/push', { body: {} })
  h.gameHalf.setAllOnline('1', 999)
  const online = await h.fake.call('get', '/api/status-panel/status', { query: { probe: '1' } })
  const s2 = online.data.probe.servers[0]
  assert.equal(s2.onlineMatch, false, '服端显示的全服在线数与宿主算出的不同时必须 onlineMatch=false')
  assert.ok(
    s2.diff.some((d) => d.includes('全服在线数') && d.includes('999')),
    `diff 要并排给出"服端是多少、宿主是多少"（旧版正是这里静默失效的），实际：${JSON.stringify(s2.diff)}`,
  )
  assert.equal(s2.host.onlineTotal, 12, 'probe 要回显宿主侧算出的在线数，便于与服端对照')
})

// ═══════════════════ 鉴权 ═══════════════════

test('鉴权：每条路由都挂了 verifyAuth + requireAdmin（且仅 admin，不得沿用 requireManager）', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })

  assert.ok(h.auth.verifyFn, '插件必须经 ctx.auth.verifyAuth() 取登录校验中间件')
  assert.ok(h.auth.adminFn, '插件必须经 ctx.auth.requireAdmin() 取管理员校验中间件')
  assert.ok(
    !h.auth.accessedUnknown.includes('requireManager'),
    '本件的鉴权口径是**仅 admin**（旧版后端用的是含子管理员的 requireManager，属于权限扩大，硬要求里已明确改掉）',
  )

  // 注册的路由集合要与 index.js 实际注册的完全一致（多了/少了都说明这份断言漏了路由）
  assert.deepEqual(
    h.registrations.map((r) => `${r.method} ${r.path}`).sort(),
    ROUTES.map(([m, p]) => `${m} ${p}`).sort(),
    '宿主的每一条路由都必须出现在鉴权断言清单里（新增路由时这里会失败，提醒补上保护）',
  )

  for (const [method, routePath] of ROUTES) {
    const reg = h.registrations.find((r) => r.method === method && r.path === routePath)
    assert.ok(reg, `路由未注册：${method.toUpperCase()} ${routePath}`)
    assert.equal(
      reg.handlers.length,
      3,
      `${method.toUpperCase()} ${routePath} 的处理链应当是 [verifyAuth, requireAdmin, 业务处理器]，实际 ${reg.handlers.length} 个`,
    )
    assert.equal(reg.handlers[0], h.auth.verifyFn, `${method.toUpperCase()} ${routePath} 的第一道必须是 verifyAuth（未登录不得触碰状态面板配置）`)
    assert.equal(reg.handlers[1], h.auth.adminFn, `${method.toUpperCase()} ${routePath} 的第二道必须是 requireAdmin（普通玩家不得改面板配置）`)
    assert.ok(h.fake.hasRoute(method, routePath), `${method.toUpperCase()} ${routePath} 应当已真正注册到宿主`)

    // 拒绝分支：requireAdmin 拦下时业务处理器绝不能被执行
    h.auth.deny = true
    const denied = await runChain(reg.handlers, { headers: { 'x-server-id': '1' }, query: {}, body: {} })
    assert.equal(denied.status, 403, `${method.toUpperCase()} ${routePath} 被拒时必须是 403`)
    assert.equal(denied.handlerInvoked, false, `${method.toUpperCase()} ${routePath} 的鉴权必须在业务处理器之前拦住（否则等于没有保护）`)
  }
  h.auth.deny = false

  // 放行分支：只在只读路由上真跑一遍，证明两道中间件确实在链上生效（POST 路由会改状态，故不跑）
  for (const [method, routePath] of ROUTES.filter(([m]) => m === 'get')) {
    const reg = h.registrations.find((r) => r.method === method && r.path === routePath)
    h.auth.calls.length = 0
    const allowed = await runChain(reg.handlers, { headers: { 'x-server-id': '1' }, query: {}, body: {} })
    assert.deepEqual(
      h.auth.calls,
      ['verifyAuth', 'requireAdmin'],
      `${method.toUpperCase()} ${routePath} 放行路径必须依次经过 verifyAuth 与 requireAdmin`,
    )
    assert.equal(allowed.handlerInvoked, true, `${method.toUpperCase()} ${routePath} 通过鉴权后应当执行到业务处理器`)
  }
})

// ═══════════════════ 审计 ═══════════════════

test('审计：保存配置会往 audit.jsonl 追加一条 status-panel.config.set', async (t) => {
  const h = await mount(t, {
    onlineStats: makeOnlineStats({ total: 12, servers: [{ id: '1', name: '服务器1', playercount: 5 }] }),
  })

  // 说明：audit.js 直接 import node:fs/promises（见其第 17 行），没有可注入的 fs 入口，
  // 所以"内存 fs 里的 audit.jsonl"无法成立；这里读的是本用例专属临时目录里的真实文件。
  await saveConfig(h, validConfig({ spacerWidth: 44 }))

  const entries = await readAudit(h)
  const hit = entries.find((e) => e.action === ACTIONS.configSet)
  assert.ok(hit, `审计里必须有 status-panel.config.set 记录（谁在什么时候把哪台服改成了什么），实际：${JSON.stringify(entries)}`)
  assert.equal(hit.action, 'status-panel.config.set', '动作名必须是这个字面量（界面与文档都按它过滤）')
  assert.equal(hit.actor, 'admin', '要记下是谁改的（管理页与终端走的都是这条路由）')
  assert.equal(hit.serverId, '1', '要记下改的是哪台服（配置是按服务器分片的）')
  assert.equal(hit.enabled, true)
  assert.equal(hit.spacerWidth, 44)
  assert.deepEqual(hit.panels, ['default'], '要记下面板清单，便于事后核对"当时到底有哪些面板"')
  assert.ok(typeof hit.t === 'string' && hit.t.length > 0, '每条审计都要带时间戳')
})
