/**
 * status-panel 前端半 —— **渲染路径**回归测试（client/status-panel.js）
 *
 * 为什么必须有这个文件（补它的直接原因是一次真实事故）：
 *   缺陷 B —— `rowHtml` 引用了常量 `INTERVAL_UI_MIN`，而全仓只有"这一处引用"、没有定义。
 *   它是模块作用域里的未声明标识符，读取必抛 ReferenceError，于是**渲染任意一行卡片**都会抛，
 *   整张「面板内容」卡渲染失败。修复前，本插件的 123 个用例**全绿**依旧：
 *   `test/client-ui.test.mjs` 与 `test/panel-source.test.mjs` 只覆盖**具名导出的纯函数**
 *   （`INTERVAL_UI_MIN` 与 `rowHtml` 在两份测试里各出现 0 次），`rowHtml` 又是**未导出的嵌套
 *   函数**（在 `bootView` 闭包里，外部根本拿不到），所以没有任何用例走过"把视图渲染出来"这条路。
 *
 * 本文件的做法：用最小 DOM 桩把 `client/status-panel.js` **真的跑起来**（不是静态读源码）——
 *   1. 桩 `globalThis.window.tsweb`：`registerView` 捕获视图回调、`api` 按路径回假配置；
 *   2. 桩 `globalThis.document`：`createElement`/`head.appendChild`（`injectStyle` 要用）；
 *   3. 调被捕获的 `render(container)`，断言不抛错，并断言渲染出的 HTML。
 * 这样 `rowHtml` 这条"只有渲染才会走的路径"就被覆盖了：把 `INTERVAL_UI_MIN` 的定义删掉，
 * 本文件会以 ReferenceError 失败（见交付报告的反向验证实测输出）。
 *
 * 边界（如实说明）：这是**桩 DOM**，证明的是"渲染代码能跑通、产出的 HTML 含哪些关键结构"，
 * 不证明真实浏览器里的排版观感与样式生效。观感需要人眼或截图工具。
 *
 * 运行：node test/panel-render.test.mjs
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const clientFile = path.resolve(here, '..', 'client', 'status-panel.js')

// ════════════════════════════════════════════
//  最小假 DOM
// ════════════════════════════════════════════

function makeClassList() {
  const set = new Set()
  return {
    add: (...cs) => cs.forEach((c) => set.add(c)),
    remove: (...cs) => cs.forEach((c) => set.delete(c)),
    contains: (c) => set.has(c),
    toggle: (c, on) => ((on === undefined ? !set.has(c) : on) ? set.add(c) : set.delete(c)),
    _all: () => [...set],
  }
}

/**
 * 一个够用的假节点。要点：
 *   - `querySelector('#id')` 每次返回**同一个**缓存节点：本件 `$()` 会反复取同一个容器并覆写
 *     `innerHTML`，必须让第二次渲染写回同一个对象，断言才读得到"最后一次渲染结果"。
 *   - 非 `#` 选择器一律返回 null：本件只有"只重绘预览区"的优化路径（`renderPreviewOnly`）用
 *     类选择器，返回 null 会让它安全跳过，不影响本文件要验证的 render 主路径。
 */
function makeEl(id) {
  const listeners = new Map()
  const attrs = new Map()
  const kids = new Map()
  const el = {
    id: id || '',
    tagName: 'DIV',
    innerHTML: '',
    textContent: '',
    value: '',
    className: '',
    disabled: false,
    checked: false,
    dataset: {},
    style: {},
    classList: makeClassList(),
    querySelector(sel) {
      const key = String(sel)
      if (!key.startsWith('#')) return null
      if (!kids.has(key)) kids.set(key, makeEl(key.slice(1)))
      return kids.get(key)
    },
    querySelectorAll() { return [] },
    addEventListener(type, fn) {
      if (!listeners.has(type)) listeners.set(type, [])
      listeners.get(type).push(fn)
    },
    removeEventListener(type, fn) {
      const arr = listeners.get(type) || []
      const i = arr.indexOf(fn)
      if (i >= 0) arr.splice(i, 1)
    },
    setAttribute(k, v) { attrs.set(String(k), String(v)) },
    getAttribute(k) { return attrs.has(String(k)) ? attrs.get(String(k)) : null },
    appendChild(child) { return child },
    replaceChild(fresh) { return fresh },
    closest() { return null },
    __count: (type) => (listeners.get(type) || []).length,
    __fire(type, ev) {
      for (const fn of [...(listeners.get(type) || [])]) fn(ev || {})
    },
  }
  return el
}

/**
 * 把抛出的异常格式化成 "名字: 消息"。
 * 必须带**名字**：本文件的重点是"缺陷复现时报的是 ReferenceError"，
 * 只打印 message 会看不出是"未定义标识符"还是别的错。
 */
function fmtErr(e) {
  if (!e) return ''
  return String((e && e.name) || 'Error') + ': ' + String((e && e.message) || e)
}

/** 让已排队的 promise 链跑完（api 桩回的是已 resolve 的 promise，几个 setImmediate 足够） */
async function settle(times = 8) {
  for (let i = 0; i < times; i++) await new Promise((r) => setImmediate(r))
}

/** file:// URL（Node 的 import 在 Windows 上要正斜杠） */
function url(p) {
  return 'file:///' + p.replace(/\\/g, '/')
}

// ════════════════════════════════════════════
//  挂载工具
// ════════════════════════════════════════════

let seq = 0

/**
 * 桩住宿主与 DOM，import 前端半，调被捕获的 `render(container)`。
 *
 * @param {object} config 假的宿主配置（会作为 GET /api/status-panel/config 的 data.config 返回）
 * @returns {Promise<{container, calls, view, thrown, html, contentHtml, restore}>}
 */
async function mount(config) {
  const calls = []
  const container = makeEl('root')
  let view = null

  const tsw = {
    registerView(v) { view = v },
    getServerId: () => 's1',
    api(p, opts) {
      calls.push({ path: String(p), opts: opts || {} })
      let data = { ok: true }
      const callPath = String(p)
      if (callPath.indexOf('/api/status-panel/servers') === 0) {
        data = {
          servers: [{ id: 's1', name: '一服', enabled: true, panelCount: 1, hasConfig: true }],
        }
      } else if (callPath.indexOf('/api/status-panel/config') === 0) {
        data = {
          config,
          defaults: { rows: [], placeholders: [] },
          warnings: [],
          configFile: 'tshock/TSWeb/statuspanel.json',
          push: null,
          online: null,
        }
      } else if (callPath.indexOf('/api/status-panel/status') === 0) {
        data = { servers: [], online: null }
      }
      return Promise.resolve({ ok: true, status: 200, data })
    },
  }

  const prevWindow = globalThis.window
  const prevDocument = globalThis.document
  globalThis.window = {
    tsweb: tsw,
    confirm: () => true,
    addEventListener() {},
    removeEventListener() {},
  }
  globalThis.document = {
    createElement() { return makeEl('') },
    head: { appendChild() {} },
  }

  const restore = () => {
    if (prevWindow === undefined) delete globalThis.window
    else globalThis.window = prevWindow
    if (prevDocument === undefined) delete globalThis.document
    else globalThis.document = prevDocument
  }

  try {
    // 模块级只注册一次，每次都要拿独立实例，所以加 cache-busting query
    const mod = await import(url(clientFile) + '?render=' + (++seq))
    assert.ok(view, '模块加载后必须调用 window.tsweb.registerView 注册视图（否则宿主里根本没有这个页面）')

    // 关键：真的走渲染路径。缺陷 B 的 ReferenceError 就在这里抛出。
    let thrown = null
    try {
      view.render(container)
    } catch (e) {
      thrown = e
    }
    await settle()

    return {
      container,
      calls,
      view,
      mod,
      thrown,
      html: container.innerHTML,
      contentHtml: container.querySelector('#sp-content').innerHTML,
      restore,
    }
  } catch (e) {
    restore()
    throw e
  }
}

/** 造一份宿主配置（只带 normalizeConfig 认识的字段） */
function configWith(rows, extraPanels) {
  const panels = { default: rows }
  if (extraPanels) Object.assign(panels, extraPanels)
  return { enabled: true, spacerWidth: 60, logLevel: 'INFO', panels, panelSpacers: {} }
}

/** 取出渲染结果里所有"更新间隔"输入框的完整标签 */
function intervalTags(html) {
  return html.match(/<input[^>]*data-sp="interval"[^>]*>/g) || []
}

/** 取出某个按钮的标签（up/down 的 disabled 逻辑靠它断言） */
function buttonTag(html, action, idx) {
  const re = new RegExp('<button[^>]*data-sp="' + action + '"[^>]*data-idx="' + idx + '"[^>]*>')
  const m = html.match(re)
  return m ? m[0] : ''
}

const TWO_ROWS = [
  { typeName: 'DynamicText', text: '在线人数：{OnlinePlayersCount}人', updateInterval: 600 },
  { typeName: 'DynamicText', text: '全服在线：{AllOnlineCount}人', updateInterval: 60 },
]

// ════════════════════════════════════════════
//  ① 常量本身（缺陷 B 的直接回归闸门）
// ════════════════════════════════════════════

test('常量：INTERVAL_UI_MIN / INTERVAL_UI_MAX 都必须有定义且取值与服端/宿主语义一致', async () => {
  const { mod, restore } = await mount(configWith(TWO_ROWS))
  restore()
  // rowHtml 里那个 number input 的 min=/max= 就取这两个常量；少一个定义，渲染必抛 ReferenceError
  assert.equal(mod.INTERVAL_UI_MIN, 1, 'INTERVAL_UI_MIN 必须是 1（归一时小于 1 一律按 1 处理）')
  assert.equal(mod.INTERVAL_UI_MAX, 1000000, 'INTERVAL_UI_MAX 必须与服端/宿主一致（1,000,000 帧）')
  assert.equal(mod.clampInterval(0), 1, '夹取下限也必须是 1')
  assert.equal(mod.clampInterval(1e9), 1000000, '夹取上限也必须是 1,000,000')
})

// ════════════════════════════════════════════
//  ② 渲染路径主断言（缺陷 B 的复现点）
// ════════════════════════════════════════════

test('渲染：调 render() 不抛错，且「面板内容」卡渲染出行卡片（缺陷 B 的复现点）', async () => {
  const ctx = await mount(configWith(TWO_ROWS))
  try {
    assert.equal(
      ctx.thrown, null,
      'render() 不得抛错。rowHtml 引用了未定义标识符时这里必报 ReferenceError：' +
      fmtErr(ctx.thrown),
    )
    // 骨架本身渲染出来（证明 render 走到了 renderShell）
    for (const id of ['sp-status', 'sp-overview', 'sp-servers', 'sp-content', 'sp-push', 'sp-warnings']) {
      assert.ok(ctx.html.includes('id="' + id + '"'), '骨架应含 #' + id)
    }
    // 「面板内容」卡真的产出了行卡片（不是空串）
    assert.ok(ctx.contentHtml.length > 0, '#sp-content 不应为空')
    assert.ok(ctx.contentHtml.includes('sp-card'), '#sp-content 应渲染出卡片')
    // 关键文案与数值：这三条就是缺陷 B 会打掉的东西
    assert.ok(ctx.contentHtml.includes('更新间隔'), '行卡片必须含「更新间隔」文案')
    assert.ok(ctx.contentHtml.includes('min="1"'), '更新间隔输入框必须含 min="1"（来自 INTERVAL_UI_MIN）')
    assert.ok(ctx.contentHtml.includes('max="1000000"'), '更新间隔输入框必须含 max="1000000"（来自 INTERVAL_UI_MAX）')
  } finally {
    ctx.restore()
  }
})

test('渲染：每一行的更新间隔输入框都带 min/max，且 value 取该行的 updateInterval', async () => {
  const ctx = await mount(configWith(TWO_ROWS))
  try {
    const tags = intervalTags(ctx.contentHtml)
    assert.equal(tags.length, 2, '两行配置必须渲染出 2 个更新间隔输入框')
    for (const tag of tags) {
      assert.ok(tag.includes('min="1"'), '每个间隔输入框都要有 min="1"：' + tag)
      assert.ok(tag.includes('max="1000000"'), '每个间隔输入框都要有 max="1000000"：' + tag)
      // 上限/下限写成字面量而丢掉常量引用不会让断言变红，但 min/max 的取值本身必须对
      assert.ok(/type="number"/.test(tag), '间隔输入框应是 number 类型：' + tag)
    }
    assert.ok(tags[0].includes('value="600"'), '第 1 行的 value 应取 row.updateInterval=600：' + tags[0])
    assert.ok(tags[1].includes('value="60"'), '第 2 行的 value 应取 row.updateInterval=60：' + tags[1])
  } finally {
    ctx.restore()
  }
})

test('渲染：视图注册元信息与路由一致（渲染挂载点靠它才对得上侧边栏）', async () => {
  const ctx = await mount(configWith(TWO_ROWS))
  try {
    assert.equal(ctx.view.id, 'status-panel')
    assert.equal(ctx.view.title, '状态面板')
    assert.equal(ctx.view.section, '后端设置')
    assert.equal(ctx.view.path, '/b/status-panel')
    assert.equal(typeof ctx.view.render, 'function')
  } finally {
    ctx.restore()
  }
})

// ════════════════════════════════════════════
//  ③ 多行：逐行渲染与 ↑↓ 禁用逻辑
// ════════════════════════════════════════════

test('多行：3 行逐行渲染，序号 1/2/3，且 ↑ 只在首行禁用、↓ 只在末行禁用', async () => {
  const rows = [
    { typeName: 'DynamicText', text: '第一行', updateInterval: 60 },
    { typeName: 'DynamicText', text: '第二行', updateInterval: 120 },
    { typeName: 'DynamicText', text: '第三行', updateInterval: 180 },
  ]
  const ctx = await mount(configWith(rows))
  try {
    assert.equal(ctx.thrown, null, '3 行渲染不得抛错：' + fmtErr(ctx.thrown))
    const html = ctx.contentHtml
    // 逐行渲染：3 个行卡片、3 个把手、3 个文本框
    assert.equal((html.match(/data-sp="line"/g) || []).length, 3, '应有 3 个行卡片')
    assert.equal((html.match(/data-sp="handle"/g) || []).length, 3, '每行一个拖拽把手')
    assert.equal((html.match(/data-sp="row-text"/g) || []).length, 3, '每行一个文本框')
    // 行内序号（1 起）
    assert.ok(html.includes('<span class="sp-idx">1</span>'), '第 1 行序号应为 1')
    assert.ok(html.includes('<span class="sp-idx">2</span>'), '第 2 行序号应为 2')
    assert.ok(html.includes('<span class="sp-idx">3</span>'), '第 3 行序号应为 3')
    // 行文本按 data-idx 落位
    for (const [i, text] of ['第一行', '第二行', '第三行'].entries()) {
      const m = html.match(new RegExp('<textarea[^>]*data-sp="row-text" data-idx="' + i + '"[^>]*>([^<]*)</textarea>'))
      assert.ok(m, '第 ' + (i + 1) + ' 行应有文本框')
      assert.equal(m[1], text, '第 ' + (i + 1) + ' 行文本应回填')
    }
    // ↑：只有首行禁用
    assert.ok(buttonTag(html, 'up', 0).includes('disabled'), '首行的 ↑ 必须禁用')
    assert.ok(!buttonTag(html, 'up', 1).includes('disabled'), '第 2 行的 ↑ 不应禁用')
    assert.ok(!buttonTag(html, 'up', 2).includes('disabled'), '末行的 ↑ 不应禁用')
    // ↓：只有末行禁用
    assert.ok(!buttonTag(html, 'down', 0).includes('disabled'), '首行的 ↓ 不应禁用')
    assert.ok(!buttonTag(html, 'down', 1).includes('disabled'), '第 2 行的 ↓ 不应禁用')
    assert.ok(buttonTag(html, 'down', 2).includes('disabled'), '末行的 ↓ 必须禁用')
  } finally {
    ctx.restore()
  }
})

test('单行：只有一行时 ↑ 与 ↓ 都禁用（count-1 === 0 的边界）', async () => {
  const ctx = await mount(configWith([{ typeName: 'DynamicText', text: '唯一一行', updateInterval: 60 }]))
  try {
    assert.equal(ctx.thrown, null, '单行渲染不得抛错：' + fmtErr(ctx.thrown))
    const html = ctx.contentHtml
    assert.equal((html.match(/data-sp="line"/g) || []).length, 1)
    assert.ok(buttonTag(html, 'up', 0).includes('disabled'), '单行的 ↑ 必须禁用')
    assert.ok(buttonTag(html, 'down', 0).includes('disabled'), '单行的 ↓ 必须禁用')
    assert.ok(html.includes('min="1"') && html.includes('max="1000000"'), '单行同样要渲染出间隔范围')
  } finally {
    ctx.restore()
  }
})

// ════════════════════════════════════════════
//  ④ rowHtml 的分支：typeName 缺失 / 非 DynamicText / 转义
// ════════════════════════════════════════════

test('rowHtml 分支：typeName 缺失时不崩，并标出「缺 typeName（不渲染）」', async () => {
  const ctx = await mount(configWith([
    { text: '没有 typeName 的一行', updateInterval: 60 },
  ]))
  try {
    assert.equal(ctx.thrown, null, 'typeName 缺失不得让渲染抛错：' + fmtErr(ctx.thrown))
    const html = ctx.contentHtml
    assert.ok(html.includes('缺 typeName（不渲染）'), '应给出「缺 typeName（不渲染）」提示')
    assert.ok(html.includes('没有 typeName 的一行'), '行文本仍应渲染出来')
    assert.ok(html.includes('min="1"'), 'typeName 缺失时也必须有 min="1"')
  } finally {
    ctx.restore()
  }
})

test('rowHtml 分支：typeName 非 DynamicText 时标出「（不渲染）」并保留原类型名', async () => {
  const ctx = await mount(configWith([
    { typeName: 'StaticText', text: '静态文本行', updateInterval: 60 },
    { typeName: 'HandlerInfoOverride', text: '处理器行', updateInterval: 60 },
  ]))
  try {
    assert.equal(ctx.thrown, null, '非 DynamicText 行不得让渲染抛错：' + fmtErr(ctx.thrown))
    const html = ctx.contentHtml
    // 旧版缺陷 D 会把非 DynamicText 的类型静默改写成 DynamicText，所以这里必须保留原值并显式提示
    assert.ok(html.includes('StaticText（不渲染）'), 'StaticText 行应显示原类型名 + 不渲染')
    assert.ok(html.includes('HandlerInfoOverride（不渲染）'), 'HandlerInfoOverride 行应显示原类型名 + 不渲染')
    assert.equal((html.match(/（不渲染）/g) || []).length, 2, '两行都应标出不渲染')
  } finally {
    ctx.restore()
  }
})

test('rowHtml 分支：行文本与插值 chips、分组 chips、拖拽把手都渲染出来', async () => {
  const ctx = await mount(configWith([
    { typeName: 'DynamicText', text: '<img src=x onerror=alert(1)>', updateInterval: 60 },
  ]))
  try {
    assert.equal(ctx.thrown, null, '含特殊字符的行不得让渲染抛错：' + fmtErr(ctx.thrown))
    const html = ctx.contentHtml
    // 行文本必须转义（模板文本会进 innerHTML）
    assert.ok(html.includes('&lt;img src=x onerror=alert(1)&gt;'), '行文本必须转义后渲染')
    assert.ok(!html.includes('<img src=x'), '行文本不得以原始标签形式进入 HTML')
    // 插值 chips 与其分组 chips
    assert.ok((html.match(/data-sp="token"/g) || []).length > 0, '应有插值 chips')
    assert.equal((html.match(/data-sp="group"/g) || []).length, 7, '分组 chips = 全部 + 6 个分组')
    assert.ok(html.includes('点击插入插值（光标位置）'), '应有插值区标题')
    // 每行一个拖拽把手（顺序调整的前提）
    assert.ok(html.includes('data-sp="handle"'), '应有拖拽把手')
    // 该行的间隔输入框仍然带上下限
    assert.ok(intervalTags(html)[0].includes('min="1"'))
  } finally {
    ctx.restore()
  }
})

test('空面板：0 行时给出空态提示而不是崩掉（rows.map 的边界）', async () => {
  const ctx = await mount(configWith([]))
  try {
    assert.equal(ctx.thrown, null, '空面板不得让渲染抛错：' + fmtErr(ctx.thrown))
    const html = ctx.contentHtml
    assert.ok(html.includes('该面板暂无内容行'), '空面板应给出空态提示')
    assert.equal((html.match(/data-sp="line"/g) || []).length, 0, '空面板不应有行卡片')
    assert.ok(html.includes('预览'), '空面板仍应渲染出预览卡')
  } finally {
    ctx.restore()
  }
})

// ════════════════════════════════════════════
//  ⑤ 多面板与整体渲染
// ════════════════════════════════════════════

test('多面板：面板 tab 渲染出来，default 带 locked 且不可删除', async () => {
  const ctx = await mount(configWith(
    [{ typeName: 'DynamicText', text: '默认面板行', updateInterval: 60 }],
    { 宣传: [{ typeName: 'DynamicText', text: '宣传行', updateInterval: 120 }] },
  ))
  try {
    assert.equal(ctx.thrown, null, '多面板不得让渲染抛错：' + fmtErr(ctx.thrown))
    const html = ctx.contentHtml
    assert.ok((html.match(/data-sp="panel-tab"/g) || []).length >= 2, '应渲染出至少 2 个面板 tab')
    assert.ok(html.includes('data-panel="default"'), 'default 面板的 tab 必须存在')
    assert.ok(html.includes('data-panel="宣传"'), '自定义面板的 tab 必须存在')
    // 注意类名顺序：活跃的 default 是 class="sp-tab active locked"，不能写死 'sp-tab locked'
    const defTab = html.match(/<span class="([^"]*)" data-sp="panel-tab" data-panel="default"/)
    assert.ok(defTab, 'default 的 tab 标签应可定位')
    assert.ok(defTab[1].split(' ').includes('locked'), 'default 面板的 tab 应带 locked：' + defTab[1])
    const otherTab = html.match(/<span class="([^"]*)" data-sp="panel-tab" data-panel="宣传"/)
    assert.ok(otherTab, '宣传 的 tab 标签应可定位')
    assert.ok(!otherTab[1].split(' ').includes('locked'), '非 default 面板的 tab 不应带 locked：' + otherTab[1])
    assert.ok(html.includes('default 面板强制存在，不可删除'), 'default 的说明文案应在')
    // 当前激活的是 default，所以渲染的是 default 的那一行
    assert.ok(html.includes('默认面板行'), '应渲染当前激活面板的行')
  } finally {
    ctx.restore()
  }
})

test('整体渲染：五块容器都真的产出了内容（renderAll 的每个分支都被走到）', async () => {
  const ctx = await mount(configWith(TWO_ROWS))
  try {
    assert.equal(ctx.thrown, null, '整页渲染不得抛错：' + fmtErr(ctx.thrown))
    // 总览卡
    const overview = ctx.container.querySelector('#sp-overview').innerHTML
    assert.ok(overview.includes('状态面板') && overview.includes('行尾空格宽度'), '总览卡应渲染')
    assert.ok(overview.includes('日志等级'), '总览卡应含日志等级下拉')
    // 服务器卡
    const servers = ctx.container.querySelector('#sp-servers').innerHTML
    assert.ok(servers.includes('目标服务器'), '服务器卡应渲染')
    assert.ok(servers.includes('一服'), '服务器下拉应列出宿主登记的服')
    // 面板内容卡
    assert.ok(ctx.contentHtml.includes('面板内容：default'), '面板内容卡应渲染')
    // 下发状态卡
    const push = ctx.container.querySelector('#sp-push').innerHTML
    assert.ok(push.includes('下发状态'), '下发状态卡应渲染')
    // 首屏请求：servers / config / status 各一次，且都带 x-server-id
    const paths = ctx.calls.map((c) => c.path)
    assert.equal(paths.filter((p) => p.includes('/api/status-panel/servers')).length, 1)
    assert.equal(paths.filter((p) => p.includes('/api/status-panel/config')).length, 1)
    assert.equal(paths.filter((p) => p.includes('/api/status-panel/status')).length, 1)
  } finally {
    ctx.restore()
  }
})

test('渲染可重复调用：同一 container 再次 render 不抛错（宿主每次进入路由都会重调）', async () => {
  const ctx = await mount(configWith(TWO_ROWS))
  try {
    let second = null
    try {
      ctx.view.render(ctx.container)
    } catch (e) {
      second = e
    }
    await settle()
    assert.equal(second, null, '第二次 render 不得抛错：' + fmtErr(second))
    assert.equal(ctx.container.__count('click'), 1, '事件监听必须先解绑再绑（不应累加）')
    assert.equal(ctx.container.__count('change'), 1)
    assert.ok(ctx.container.querySelector('#sp-content').innerHTML.includes('min="1"'), '重渲染后行卡片仍应完整')
  } finally {
    ctx.restore()
  }
})
