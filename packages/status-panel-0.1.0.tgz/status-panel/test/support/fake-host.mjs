/**
 * 测试用的最小宿主（假 ctx）+ 假游戏服半 —— 不启动任何服务进程、不依赖 express / cordis。
 *
 * 为什么自己搓一个：本机 `node --test test/` 会因 `spawn EPERM`（沙箱不允许管道捕获子进程）
 * 而整体失败，测试必须能逐个 `node test/<名>.test.mjs` 跑；同时"不启动/重启任何服务进程"
 * 是本次任务的硬约定，所以**不引入真实 HTTP 监听**，而是直接调用插件注册在 app.get/app.post
 * 上的处理函数（与真实 express 的用法一致：插件只用到 (req,res) 两个参数）。
 *
 * 覆盖到的宿主契约（plugins/status-panel/index.js 依赖的全部服务）：
 *   webServer.app.get/post、auth.verifyAuth/requireAdmin、servers.list/getRaw、
 *   tshock.fetchFor（记录全部调用，供断言"下发确实发生了、参数正确"）、paths.dataOf、
 *   ctx.on/ctx.emit（连接恢复补推靠它触发）、ctx.get（软依赖取服务，见 services 参数）
 *
 * 假游戏服半的端点与参数形态与 plugin/StatusPanelEndpoints.cs 逐字对齐：
 *   /data/statuspanel/snapshot    version / enabled / spacerWidth / logLevel / panels / panelSpacers / allOnlineCount / ts
 *   /data/statuspanel/online      total / ts
 *   /data/statuspanel/status      无参
 *   /data/statuspanel/config      无参（旧格式读）
 *   /data/statuspanel/config/set  enabled / spacerWidth / logLevel / panels / panelSpacers（旧式写，无版本）
 */
import path from 'node:path'

export function makeFakeHost({ dataDir, servers = [], fetchFor, services = {}, fsApi }) {
  const routes = { get: new Map(), post: new Map() }
  const listeners = new Map()
  const events = []
  const calls = []
  const raw = new Map(servers.map((s) => [String(s.raw.id), { ...s.raw }]))

  const app = {
    get(routePath, ...handlers) {
      routes.get.set(routePath, handlers[handlers.length - 1])
    },
    post(routePath, ...handlers) {
      routes.post.set(routePath, handlers[handlers.length - 1])
    },
  }

  const ctx = {
    webServer: { app },
    /**
     * 软依赖取服务：对齐真实 cordis 的 Context.get 语义——**未注册返回 undefined，不抛错**
     * （实测见 plugins/legacy-import/modules/registry.js 的注释）。
     * 用普通属性赋值挂上去的假服务对 get 不可见，这正是生产里"服务没注册就取不到"的形态。
     */
    get: (name) => services[name],
    // 鉴权中间件在测试里直接放行（本件只关心处理逻辑；鉴权链路由宿主插件保证）
    auth: {
      verifyAuth: () => (req, res, next) => next(),
      requireAdmin: () => (req, res, next) => next(),
    },
    paths: { dataOf: (n) => path.join(dataDir, n) },
    logger: { info() {}, warn() {}, error() {} },
    servers: {
      list: async () => [...raw.values()].map((s) => ({ ...s })),
      getRaw: (id) => (raw.has(String(id)) ? { ...raw.get(String(id)) } : null),
    },
    tshock: {
      async fetchFor(server, pathname, params) {
        calls.push({ serverId: server.id, pathname, params })
        return fetchFor(server, pathname, params)
      },
    },
    emit(name, payload) {
      events.push({ name, payload })
    },
    on(name, fn) {
      listeners.set(name, fn)
      return () => listeners.delete(name)
    },
  }
  if (fsApi) ctx.fs = fsApi

  return {
    ctx,
    /** 全部游戏服调用（含参数），供"下发确实发生/参数正确"类断言 */
    calls,
    /** 插件 emit 的事件 */
    events,
    /** 改假服务器记录（例如临时置 enabled=false） */
    setRaw(id, patch) {
      raw.set(String(id), { ...(raw.get(String(id)) || {}), ...patch })
    },
    /** 触发宿主事件（连接恢复补推靠它） */
    fire(name, payload) {
      const fn = listeners.get(name)
      if (!fn) return false
      fn(payload)
      return true
    },
    listenerCount: () => listeners.size,
    /**
     * 直接调用插件注册的某个端点（不经网络）。
     * headers 可传 {'x-server-id': '...'} —— 本件的"按服务器独立配置"正是靠这个头选择的。
     */
    async call(method, url, { query = {}, body = {}, headers = {} } = {}) {
      const u = new URL(url, 'http://localhost')
      const merged = { ...Object.fromEntries(u.searchParams.entries()), ...query }
      const handler = routes[method].get(u.pathname)
      if (!handler) throw new Error(`插件未注册该路由: ${method.toUpperCase()} ${u.pathname}`)
      let data = null
      let status = 200
      const res = {
        headersSent: false,
        status(code) {
          status = code
          return res
        },
        json(payload) {
          data = payload
          return res
        },
      }
      await handler({ query: merged, body, headers }, res)
      return { status, data }
    },
    hasRoute: (method, routePath) => routes[method].has(routePath),
  }
}

/** 轮询等待条件成立（用于等异步下发/重试完成）；超时抛错，不静默通过 */
export async function waitFor(cond, { timeoutMs = 2000, intervalMs = 10, label = '条件' } = {}) {
  const started = Date.now()
  for (;;) {
    const v = await cond()
    if (v) return v
    if (Date.now() - started > timeoutMs) throw new Error(`等待超时：${label}`)
    await new Promise((r) => setTimeout(r, intervalMs))
  }
}

/**
 * 假游戏服半（TsWebStatusPanel.dll 的端点行为）。
 * 逐服可设行为：
 *   ok          正常
 *   missing     未装 DLL（404）
 *   forbidden   token 权限不足（403）
 *   stale       服端已有更新版本（回 applied=false/stale=true）
 *   badRequest  400 参数被拒（回服端原文）
 *   saveFail    收下了但落盘失败（saveError 非空 → 必须算失败）
 *   noApply     收下了但 applied=false（既不是 stale 也不是 saveFail）
 *   onlineFail  /online 端点 500（全服在线数下发失败）
 *   legacyGone  /config/set 端点 404（旧式端点不可用）
 */
export function makeGameHalf({ serverIds = [] } = {}) {
  /** 服端当前生效的配置与版本 */
  const applied = new Map()
  const behavior = new Map(serverIds.map((id) => [String(id), 'ok']))
  /** 服端自己数的本服在线数 */
  const localOnline = new Map(serverIds.map((id) => [String(id), 3]))
  /** 服端当前显示的**全服**在线数（由 /snapshot 与 /online 写入） */
  const allOnline = new Map(serverIds.map((id) => [String(id), -1]))
  /** 服端"绕过宿主"的旧式写入次数（localEdits） */
  const localEdits = new Map(serverIds.map((id) => [String(id), 0]))
  /** 服端落盘错误 */
  const saveError = new Map(serverIds.map((id) => [String(id), '']))
  /** 服端配置来源：default | file | legacy | rest */
  const source = new Map(serverIds.map((id) => [String(id), 'default']))
  /** 服端渲染循环的启用状态（正常等于配置里的 enabled） */
  const runtimeEnabled = new Map(serverIds.map((id) => [String(id), false]))

  /** 服端默认配置（与 StatusPanelDefaults 一致：未启用 + 内置模板） */
  const defaultPanels = () => ({
    default: [
      { typeName: 'DynamicText', text: '[i:757][c/f15642:开荒服]', updateInterval: 600 },
      { typeName: 'DynamicText', text: '在线人数：{OnlinePlayersCount}人', updateInterval: 60 },
      { typeName: 'DynamicText', text: '全服在线：{AllOnlineCount}人', updateInterval: 60 },
      { typeName: 'DynamicText', text: '系统时间：{SystemTime}', updateInterval: 60 },
    ],
  })

  const defaultConfig = () => ({
    enabled: false,
    spacerWidth: 60,
    logLevel: 'INFO',
    panels: defaultPanels(),
    panelSpacers: {},
  })

  return {
    applied,
    behavior,
    localOnline,
    allOnline,
    localEdits,
    runtimeEnabled,
    setBehavior(id, mode) {
      behavior.set(String(id), mode)
    },
    setLocalOnline(id, n) {
      localOnline.set(String(id), Number(n))
    },
    setAllOnline(id, n) {
      allOnline.set(String(id), Number(n))
    },
    setLocalEdits(id, n) {
      localEdits.set(String(id), Number(n))
    },
    setSaveError(id, text) {
      saveError.set(String(id), String(text))
    },
    setSource(id, s) {
      source.set(String(id), String(s))
    },
    setRuntimeEnabled(id, v) {
      runtimeEnabled.set(String(id), v === true)
    },
    /** 让"服端配置"偏离宿主（模拟有人改了服端文件 / 旧式端点写入） */
    setConfig(id, patch) {
      const cur = applied.get(String(id)) || defaultConfig()
      applied.set(String(id), { ...cur, ...patch })
    },
    fetchFor(server, pathname, params) {
      const id = String(server.id)
      const mode = behavior.get(id) || 'ok'
      const configOf = () => applied.get(id) || defaultConfig()

      if (pathname === '/data/statuspanel/online') {
        if (mode === 'missing') return { ok: false, status: 404, data: {} }
        if (mode === 'forbidden') return { ok: false, status: 403, data: {} }
        if (mode === 'onlineFail') return { ok: false, status: 500, data: { error: '服端内部错误' } }
        const total = Number(params.total)
        if (!Number.isFinite(total) || total < 0) {
          // 与 C# 端点同一判据：total<0 表示"宿主还不知道"，必须报 400 而不是静默忽略
          return { ok: false, status: 400, data: { error: 'total 必须是 >=0 的整数' } }
        }
        allOnline.set(id, total)
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            applied: true,
            allOnlineCount: total,
            allOnlineDisplay: String(total),
            localOnlineCount: localOnline.get(id) || 0,
            updatedAt: String(params.ts || ''),
          },
        }
      }

      if (mode === 'missing') return { ok: false, status: 404, data: {} }
      if (mode === 'forbidden') return { ok: false, status: 403, data: {} }

      if (pathname === '/data/statuspanel/snapshot') {
        // 宿主必须发合法 JSON 串（这是"载荷带齐"的一部分）
        let panels
        let panelSpacers
        try {
          panels = JSON.parse(params.panels)
          panelSpacers = JSON.parse(params.panelSpacers)
        } catch (err) {
          return { ok: false, status: 400, data: { error: `载荷不是合法 JSON: ${err.message}` } }
        }
        if (panels === null || typeof panels !== 'object' || Array.isArray(panels)) {
          return { ok: false, status: 400, data: { error: 'panels 必须是对象' } }
        }
        if (panelSpacers === null || typeof panelSpacers !== 'object' || Array.isArray(panelSpacers)) {
          return { ok: false, status: 400, data: { error: 'panelSpacers 必须是对象' } }
        }
        const version = Number(params.version)
        if (!Number.isFinite(version) || version <= 0) {
          return { ok: false, status: 400, data: { error: 'version 必须是正整数' } }
        }
        if (mode === 'badRequest') {
          return { ok: false, status: 400, data: { error: 'panels 里存在不是数组的面板' } }
        }
        if (mode === 'stale') {
          return {
            ok: true,
            status: 200,
            data: {
              ok: true, applied: false, stale: true, version: 99,
              updatedAt: '2026-01-01T00:00:00Z', source: 'file', saveError: '', localEdits: 0,
              notes: ['收到的 version 早于当前 version，已忽略本次下发'],
              ...configOf(),
            },
          }
        }

        const next = {
          enabled: params.enabled === 'true',
          spacerWidth: Number(params.spacerWidth),
          logLevel: String(params.logLevel || ''),
          panels,
          panelSpacers,
        }
        applied.set(id, next)
        source.set(id, 'rest')
        runtimeEnabled.set(id, next.enabled)
        // allOnlineCount：<0 表示宿主还不知道 → 服端保持当前值
        const online = Number(params.allOnlineCount)
        if (Number.isFinite(online) && online >= 0) allOnline.set(id, online)

        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            applied: mode !== 'noApply',
            stale: false,
            version,
            updatedAt: '2026-01-01T00:00:00Z',
            source: 'rest',
            saveError: saveError.get(id) || (mode === 'saveFail' ? '磁盘只读' : ''),
            localEdits: localEdits.get(id) || 0,
            notes: [],
            ...next,
            status: {
              initialized: true,
              enabled: runtimeEnabled.get(id) === true,
              allOnlineCount: allOnline.get(id),
              allOnlineDisplay: allOnline.get(id) < 0 ? '—' : String(allOnline.get(id)),
              localOnlineCount: localOnline.get(id) || 0,
              activePlayers: localOnline.get(id) || 0,
              playersWithPanelOn: localOnline.get(id) || 0,
              playersWithTextOnScreen: runtimeEnabled.get(id) ? (localOnline.get(id) || 0) : 0,
              maxRowsPerPanel: 20,
              placeholderCount: 26,
              panels: Object.fromEntries(Object.entries(panels).map(([n, rows]) => [n, rows.length])),
              packet: 'PacketTypes.Status',
              trigger: 'GameUpdate/GamePostUpdate',
            },
          },
        }
      }

      if (pathname === '/data/statuspanel/status') {
        const cfg = configOf()
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            version: Number(params.version) || 1,
            updatedAt: '2026-01-01T00:00:00Z',
            source: source.get(id) || 'default',
            file: 'X:/tshock/statuspanel-config.json',
            legacyFile: 'X:/tshock/TSWeb/statuspanel.json',
            saveError: saveError.get(id) || '',
            localEdits: localEdits.get(id) || 0,
            notes: [],
            ...cfg,
            runtime: {
              initialized: true,
              enabled: runtimeEnabled.get(id) === true,
              allOnlineCount: allOnline.get(id),
              allOnlineDisplay: allOnline.get(id) < 0 ? '—' : String(allOnline.get(id)),
              localOnlineCount: localOnline.get(id) || 0,
              activePlayers: localOnline.get(id) || 0,
              playersWithPanelOn: localOnline.get(id) || 0,
              playersWithTextOnScreen: runtimeEnabled.get(id) ? (localOnline.get(id) || 0) : 0,
              maxRowsPerPanel: 20,
              placeholderCount: 26,
              panels: Object.fromEntries(Object.entries(cfg.panels).map(([n, rows]) => [n, rows.length])),
              packet: 'PacketTypes.Status',
              trigger: 'GameUpdate/GamePostUpdate',
            },
          },
        }
      }

      if (pathname === '/data/statuspanel/config') {
        const cfg = configOf()
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            version: 1,
            source: source.get(id) || 'default',
            localEdits: localEdits.get(id) || 0,
            ...cfg,
          },
        }
      }

      if (pathname === '/data/statuspanel/config/set') {
        if (mode === 'legacyGone') return { ok: false, status: 404, data: {} }
        const next = {
          enabled: params.enabled === 'true',
          spacerWidth: Number(params.spacerWidth),
          logLevel: String(params.logLevel || ''),
          panels: JSON.parse(params.panels),
          panelSpacers: JSON.parse(params.panelSpacers),
        }
        applied.set(id, next)
        runtimeEnabled.set(id, next.enabled)
        localEdits.set(id, (localEdits.get(id) || 0) + 1)
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            response: '配置已保存',
            version: 1,
            localEdits: localEdits.get(id) || 0,
            saveError: saveError.get(id) || '',
            notes: [],
          },
        }
      }

      return { ok: false, status: 500, data: { error: `未预期的路径 ${pathname}` } }
    },
  }
}

/**
 * 假 online-stats 服务（ctx.get('onlineStats') 的形态）。
 * 与 plugins/online-stats/index.js:145-171 的 getCurrent() 返回结构一致：
 *   { total, servers: [{ id, name, playercount, ... }], fetchedAt }
 * 注意它是 **Service 子类**（super(ctx,'onlineStats')）→ 生产里只能经 ctx.get('onlineStats') 取到，
 * 所以这里也挂在 ctx.get 上（见 makeFakeHost 的 services 参数）。
 */
export function makeOnlineStats({ total = 12, servers = [], available = true, error = '' } = {}) {
  const listeners = new Map()
  const state = {
    total,
    available,
    error,
    servers:
      servers.length > 0
        ? servers.map((s) => ({ id: String(s.id), name: s.name, playercount: Number(s.playercount || 0) }))
        : [{ id: '1', name: '一号服', playercount: total }],
    readCount: 0,
  }
  return {
    state,
    /** 与真实服务一致：getCurrent() 返回 Promise */
    async getCurrent() {
      state.readCount += 1
      if (!state.available) throw new Error(state.error || '服务不可用')
      return {
        total: state.total,
        servers: state.servers,
        fetchedAt: '2026-01-01T00:00:00Z',
      }
    },
    on(name, fn) {
      listeners.set(name, fn)
      return () => listeners.delete(name)
    },
    fire(name, payload) {
      const fn = listeners.get(name)
      if (!fn) return false
      fn(payload)
      return true
    },
    listenerCount: () => listeners.size,
    setTotal(n) {
      state.total = Number(n)
    },
    setAvailable(v, reason = '') {
      state.available = v === true
      state.error = reason
    },
    setServers(list) {
      state.servers = list.map((s) => ({ id: String(s.id), name: s.name, playercount: Number(s.playercount || 0) }))
    },
  }
}

/**
 * 内存文件系统（替换 node:fs/promises，让测试不碰真实磁盘）。
 * 只实现 status-panel 用到的：readFile/writeFile/rename/mkdir/dirname（以及 unpack 时的 stat 不需要）。
 */
export function makeMemoryFs() {
  const files = new Map()
  const dirs = new Set()
  const norm = (p) => String(p).replace(/\\/g, '/')
  return {
    files,
    dirs,
    async readFile(file, enc) {
      const key = norm(file)
      if (!files.has(key)) {
        const err = new Error(`ENOENT: no such file or directory, open '${file}'`)
        err.code = 'ENOENT'
        throw err
      }
      const v = files.get(key)
      return enc ? v : Buffer.from(v, 'utf8')
    },
    async writeFile(file, data) {
      files.set(norm(file), String(data))
    },
    async rename(from, to) {
      const key = norm(from)
      if (!files.has(key)) {
        const err = new Error(`ENOENT: no such file or directory, rename '${from}'`)
        err.code = 'ENOENT'
        throw err
      }
      files.set(norm(to), files.get(key))
      files.delete(key)
    },
    async mkdir(dir) {
      dirs.add(norm(dir))
    },
    dirname(p) {
      return path.dirname(String(p))
    },
  }
}
