/**
 * 源码级一致性断言（游戏服半 C# ↔ 宿主/前端 JS 的镜像）
 *
 * 为什么需要这个文件：本件把"同一件事"写在了三处 ——
 *   游戏服半 plugin/*.cs（权威实现）、宿主 config.js（下发载荷与归一的镜像）、
 *   client/status-panel.js（界面兜底副本）。三处只要有一处漂移，症状都是"静默不一致"：
 *   宿主以为能显示、服端却截断；界面写了占位符、服端原样显示 {XXX}；
 *   界面说 500 实际生效 999。这类问题在运行时几乎不可见，只能在源码层固定住。
 *
 * 本文件**只读文件文本**做断言，不需要 dotnet 编译（编译产物的字节级证据在 test/dll-content.test.mjs）。
 *
 * 要点：扫描口径（本文件的一条硬约定）：
 *   凡是约束**运行时行为**的断言（"必须出现 N 次""不得出现某串""必须用某个 API"），
 *   一律在**剔除注释后的可执行代码**上做。理由：注释既不能重建路由也不能重建签名，
 *   把文档当代码管会产生误报 —— 而本项目**刻意**在注释里保留了旧版链路的溯源引用
 *   （交付报告要求写清"旧版缺陷在哪一行"，用户要能顺着注释查回旧代码）。
 *   只有"文档/文案类"的断言（例如"该文件头部说明了权限节点归属"）才扫全文，并且会明确标注。
 *
 * 运行：node test/panel-source.test.mjs
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, readdirSync, existsSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

import {
  INTERPOLATION_REGEX,
  MAX_CONFIGURED_ROWS_PER_PANEL,
  MAX_INTERVAL_FRAMES,
  MAX_ROWS_PER_PANEL,
  MAX_SPACER_WIDTH,
  PLACEHOLDER_TOKENS,
  defaultPanelRows,
  DEFAULT_INTERVAL_FRAMES,
} from '../config.js'
import { SERVER_HALF_PREFIX } from '../gameOps.js'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginDir = path.resolve(here, '..')
const csharpDir = path.join(pluginDir, 'plugin')

const csharpPath = (name) => path.join(csharpDir, name)
const readCsharp = (name) => readFileSync(csharpPath(name), 'utf8')
const readRel = (rel) => readFileSync(path.join(pluginDir, rel), 'utf8')

/** 去掉注释：整行的 //（含 /// XML 文档）与 块注释 */
function stripComments(src) {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((line) => (line.trim().startsWith('//') ? '' : line))
    .join('\n')
}

const placeholdersCs = readCsharp('StatusPanelPlaceholders.cs')
const configCs = readCsharp('StatusPanelConfig.cs')
const rendererCs = readCsharp('StatusPanelRenderer.cs')
const pluginCs = readCsharp('StatusPanelPlugin.cs')
const commandsCs = readCsharp('StatusPanelCommands.cs')
const endpointsCs = readCsharp('StatusPanelEndpoints.cs')

// 行为断言一律用这几个"去注释后的代码"文本（见文件头的扫描口径）
const placeholdersCode = stripComments(placeholdersCs)
const configCode = stripComments(configCs)
const rendererCode = stripComments(rendererCs)
const pluginCode = stripComments(pluginCs)
const commandsCode = stripComments(commandsCs)
const endpointsCode = stripComments(endpointsCs)
const gameOpsCode = stripComments(readRel('gameOps.js'))

/** 前端半可能尚未落地：不存在时相关断言跳过并在输出里说明（不让缺失文件变成失败） */
const CLIENT_REL = 'client/status-panel.js'
const hasClient = existsSync(path.join(pluginDir, CLIENT_REL))
const clientCode = hasClient ? stripComments(readRel(CLIENT_REL)) : ''
if (!hasClient) console.log(`[panel-source] 说明：${CLIENT_REL} 不存在，涉及前端兜底副本的断言将跳过`)

/** 游戏服半声明的全部 .cs（负面对照必须在"确实扫到了源码"的前提下才有意义） */
function csharpSourceFiles() {
  return readdirSync(csharpDir, { withFileTypes: true })
    .filter((e) => e.isFile() && e.name.endsWith('.cs'))
    .map((e) => e.name)
    .sort()
}

const CSHARP_FILES = csharpSourceFiles()

// ═══════════════════ 解析小工具 ═══════════════════

/** 抽出一段 C# 代码块：从 from 关键字起，到其后的第一个 "};" 结束 */
function csharpBlock(src, from, why) {
  const start = src.indexOf(from)
  assert.ok(start >= 0, `C# 源码里找不到 ${from}（${why}）`)
  const end = src.indexOf('};', start)
  assert.ok(end > start, `C# 源码里 ${from} 之后找不到 "};"（${why}）`)
  return src.slice(start, end)
}

/** 抽出普通（非逐字）C# 字符串字面量，并还原 \" 与 \\ */
function csharpStrings(block) {
  const out = []
  const re = /"((?:[^"\\]|\\.)*)"/g
  let m
  while ((m = re.exec(block)) !== null) out.push(m[1].replace(/\\(.)/g, '$1'))
  return out
}

/** 抽出 `JObject.Parse("…")` 里的 JSON 字面量并解析（本件模板行就是这种写法） */
function csharpJsonLiterals(block, why) {
  const out = []
  const re = /JObject\.Parse\("((?:[^"\\]|\\.)*)"\)/g
  let m
  while ((m = re.exec(block)) !== null) out.push(JSON.parse(m[1].replace(/\\(.)/g, '$1')))
  assert.ok(out.length > 0, `没抽出任何 JObject.Parse 字面量（${why}）`)
  return out
}

/** 统计某个字符串在文本里出现的次数 */
function countOf(text, needle) {
  return text.split(needle).length - 1
}

/** 某个串在**全部源码行**里的出现位置（file:line）。用于说明"注释里的溯源引用在哪" */
function occurrencesInFileText(needle) {
  const hits = []
  for (const name of CSHARP_FILES) {
    readCsharp(name).split('\n').forEach((line, i) => {
      if (line.includes(needle)) hits.push(`${name}:${i + 1}`)
    })
  }
  return hits
}

/** 某个串在**可执行代码**（该行去注释后仍含它）里的出现位置（file:line） */
function occurrencesInCode(needle) {
  const hits = []
  for (const name of CSHARP_FILES) {
    readCsharp(name).split('\n').forEach((line, i) => {
      if (stripComments(line).includes(needle)) hits.push(`${name}:${i + 1}`)
    })
  }
  return hits
}

// ═══════════════════ 26 个占位符 ═══════════════════

test('占位符清单：C# AllTokens 恰好 26 项、无重复，且与 config.js 的 PLACEHOLDER_TOKENS 逐项相同（含顺序）', () => {
  const block = csharpBlock(placeholdersCode, 'public static readonly string[] AllTokens', '占位符权威清单')
  const csTokens = csharpStrings(block)

  assert.equal(csTokens.length, 26, `C# AllTokens 必须恰好 26 项（它由 /status 的 placeholderCount 自证），实际 ${csTokens.length}`)
  assert.equal(new Set(csTokens).size, 26, `C# AllTokens 里有重复项：${csTokens.join(' ')}`)

  assert.equal(
    csTokens.length,
    PLACEHOLDER_TOKENS.length,
    `两侧占位符数量不一致：C# ${csTokens.length} 项，config.js ${PLACEHOLDER_TOKENS.length} 项`,
  )
  for (let i = 0; i < csTokens.length; i++) {
    assert.equal(
      PLACEHOLDER_TOKENS[i],
      csTokens[i],
      `第 ${i + 1} 个占位符两侧不一致（C# 是权威）：C# = ${csTokens[i]}，config.js = ${PLACEHOLDER_TOKENS[i]}`
      + '。这类漂移的后果是"界面以为支持、服端原样显示 {XXX}"。',
    )
  }

  // 每个 token 都必须真的在插值 switch 里有取值分支（只登记在清单里、没有实现的分支等于写了个空头承诺）
  for (const token of csTokens) {
    assert.ok(
      placeholdersCode.includes(`"${token}" =>`),
      `C# 的插值 switch 里没有 ${token} 的取值分支 —— 它会被原样显示给玩家（等于"清单里登记了但没实现"）`,
    )
  }
})

test('客户端插值字典的 token 集合与权威清单一致（顺序刻意不同：界面按旧版分组展示顺序排列）', () => {
  if (!hasClient) return
  const entries = [...clientCode.matchAll(/\{\s*group:\s*'([^']*)',\s*token:\s*'([^']+)'/g)]
    .map((m) => ({ group: m[1], token: m[2] }))
  const tokens = entries.map((e) => e.token)

  assert.equal(tokens.length, 26, `客户端插值字典应当是 26 条（界面按分组展示 26 个占位符），实际 ${tokens.length}`)
  // 这里**只比集合**（排序后相等），刻意不比顺序：
  // C# AllTokens 把 {RealWorldTime} 排在 {CurrentTime} 之后，而客户端把它放在**最后一项**
  // （归到「时间」分组，与旧版界面 25 项的分组展示顺序对齐）。
  // 两边的顺序各有各的用途（服端是自证清单、界面是展示顺序），所以顺序不同是设计，不是漂移。
  assert.deepEqual(
    [...tokens].sort(),
    [...PLACEHOLDER_TOKENS].sort(),
    '客户端字典与权威清单的 token 集合必须相同：否则界面上会出现服端根本不认的占位符，或者漏掉能用的',
  )
  assert.equal(new Set(tokens).size, 26, '客户端字典里不得有重复 token')

  // 把"顺序不同是刻意的"固定成可回归的事实：客户端最后一项是 {RealWorldTime} 且属于「时间」分组，
  // 而 C# 清单的末项是 {CurrentBossSpawnItemId}
  const last = entries[entries.length - 1]
  assert.equal(last.token, '{RealWorldTime}', '客户端字典的最后一项刻意是 {RealWorldTime}（旧版界面刻意不展示的那一个，本件把它显示出来并标注）')
  assert.equal(last.group, '时间', '{RealWorldTime} 属于「时间」分组（与 {SystemTime} 同组，界面上要能看出两者取值相同）')
  const csTokens = csharpStrings(csharpBlock(placeholdersCode, 'public static readonly string[] AllTokens', '占位符权威清单'))
  assert.equal(
    csTokens[csTokens.length - 1],
    '{CurrentBossSpawnItemId}',
    'C# AllTokens 的末项是 {CurrentBossSpawnItemId}，本条用于把两侧顺序的差异固定下来',
  )
  assert.notEqual(
    last.token,
    csTokens[csTokens.length - 1],
    '客户端展示顺序与 C# 清单顺序刻意不同（前者跟旧版界面分组顺序，后者是自证清单），不得断言两者顺序相同',
  )

  // 每个 token 都必须能被动插值正则识别（否则界面上高亮了、服端也匹配不到，两边说法不一致）
  for (const token of tokens) {
    assert.ok(new RegExp(INTERPOLATION_REGEX.source).test(token), `${token} 不能被插值正则匹配：它永远不会被服端替换掉`)
  }
})

// ═══════════════════ 插值正则三处同源 ═══════════════════

test('插值正则三处同源：C# StatusPanelPlaceholders、config.js、client/status-panel.js 逐字相同', () => {
  const m = placeholdersCode.match(/InterpolationRegex\s*=\s*new\(@"((?:[^"]|"")*)"\)/)
  assert.ok(m, 'C# 里没找到 InterpolationRegex = new(@"…") 的写法')
  assert.equal(m[1], INTERPOLATION_REGEX.source, 'C# 的插值正则与 config.js 的 INTERPOLATION_REGEX.source 必须逐字相同')

  if (!hasClient) return
  const cm = clientCode.match(/INTERPOLATION_REGEX\s*=\s*\/(.+?)\/([a-z]*)/)
  assert.ok(cm, `客户端里没找到 INTERPOLATION_REGEX 正则字面量（${CLIENT_REL}）`)
  assert.equal(cm[1], INTERPOLATION_REGEX.source, '客户端预览高亮用的正则必须与宿主/服端逐字相同，否则"界面高亮了的占位符在服端不生效"')
  assert.equal(cm[2], 'g', '客户端要全局匹配（同一行里多个占位符都要高亮）')
})

// ═══════════════════ 默认模板 4 行三处同源 ═══════════════════

test('默认模板 4 行三处同源：C# StatusPanelDefaults.Template()、config.js defaultPanelRows()、client 兜底副本', () => {
  const block = csharpBlock(configCode, 'public static List<JObject> Template()', '默认模板')
  const csRows = csharpJsonLiterals(block, '默认模板 4 行')
  assert.equal(csRows.length, 4, `默认模板必须恰好 4 行（旧版 StatusPanel.cs:63-75），实际 ${csRows.length}`)

  assert.deepEqual(
    defaultPanelRows(),
    csRows,
    '宿主 config.js 的 defaultPanelRows() 必须与 C# StatusPanelDefaults.Template() 逐字一致（typeName/text/updateInterval 三项全等）',
  )

  if (!hasClient) return
  const cblock = clientCode.match(/export const DEFAULT_ROWS = \(\) => \[([\s\S]*?)\n\]/)
  assert.ok(cblock, `客户端里没找到 DEFAULT_ROWS()（${CLIENT_REL}）`)
  const clientRows = [...cblock[1].matchAll(
    /typeName:\s*'([^']*)',\s*text:\s*'([^']*)',\s*updateInterval:\s*(\d+)/g,
  )].map((x) => ({ typeName: x[1], text: x[2], updateInterval: Number(x[3]) }))
  assert.equal(clientRows.length, 4, `客户端兜底模板必须恰好 4 行（否则界面在拿不到宿主默认值时会显示另一份模板），实际 ${clientRows.length}`)
  assert.deepEqual(
    clientRows,
    csRows,
    '客户端兜底副本必须与 C# 权威模板逐字一致：三份副本里任何一份漂移，都会让"界面上看到的"与"服端实际渲染的"不同',
  )
})

// ═══════════════════ 上限常量 ═══════════════════

test('上限常量三处一致：MaxSpacerWidth=500 / MaxRowsPerPanel=20 / MaxConfiguredRowsPerPanel=200', () => {
  const parsed = {}
  const re = /public const (?:int|ulong) (\w+)\s*=\s*([\d_]+)\s*;/g
  let m
  while ((m = re.exec(configCode)) !== null) parsed[m[1]] = Number(m[2].replace(/_/g, ''))

  assert.equal(parsed.MaxSpacerWidth, 500, `C# StatusPanelDefaults.MaxSpacerWidth 必须是 500（旧版 REST 写入时夹到 [0,500]），实际 ${parsed.MaxSpacerWidth}`)
  assert.equal(parsed.MaxRowsPerPanel, 20, `C# MaxRowsPerPanel 必须是 20（客户端固定锚点下的安全行数），实际 ${parsed.MaxRowsPerPanel}`)
  assert.equal(parsed.MaxConfiguredRowsPerPanel, 200, `C# MaxConfiguredRowsPerPanel 必须是 200，实际 ${parsed.MaxConfiguredRowsPerPanel}`)

  assert.equal(MAX_SPACER_WIDTH, parsed.MaxSpacerWidth, 'config.js 的 MAX_SPACER_WIDTH 必须等于 C# 的同名常量：宿主夹到 500 而服端不是（或反之）会让 probe 永远显示不一致')
  assert.equal(MAX_ROWS_PER_PANEL, parsed.MaxRowsPerPanel, 'config.js 的 MAX_ROWS_PER_PANEL 必须等于 C# 的渲染行数上限（否则宿主以为能显示、服端却截断）')
  assert.equal(
    MAX_CONFIGURED_ROWS_PER_PANEL,
    parsed.MaxConfiguredRowsPerPanel,
    'config.js 的 MAX_CONFIGURED_ROWS_PER_PANEL 必须等于服端归一阶段的截断上限（否则宿主保留的行数超过服端能存的数量）',
  )

  // updateInterval 的上下限也是两侧共用的口径
  const rendererNums = {}
  const rre = /public const (?:int|ulong) (\w+)\s*=\s*([\d_]+)\s*;/g
  while ((m = rre.exec(rendererCode)) !== null) rendererNums[m[1]] = Number(m[2].replace(/_/g, ''))
  assert.equal(MAX_INTERVAL_FRAMES, rendererNums.MaxIntervalFrames, 'config.js 的 MAX_INTERVAL_FRAMES 必须等于 StatusPanelRenderer.MaxIntervalFrames')
  assert.equal(DEFAULT_INTERVAL_FRAMES, rendererNums.DefaultIntervalFrames, 'config.js 的 DEFAULT_INTERVAL_FRAMES（60 帧）必须等于服端未配置时的默认间隔')
})

// ═══════════════════ 5 条路由 ═══════════════════

test('5 条路由：C# OwnRoutes 与 gameOps.js 实际调用的路径集合完全一致（含前缀拼接）', () => {
  const block = csharpBlock(pluginCode, 'private static readonly string[] OwnRoutes', '路由清单')
  const ownRoutes = csharpStrings(block)
  assert.equal(ownRoutes.length, 5, `C# OwnRoutes 必须恰好 5 条（注册与反注册共用这份清单），实际 ${ownRoutes.length}`)
  for (const route of ownRoutes) {
    assert.ok(
      route.startsWith(`${SERVER_HALF_PREFIX}/`),
      `路由 ${route} 必须以 ${SERVER_HALF_PREFIX}/ 开头（本件自己的端点前缀，与旧版的自研路由无关）`,
    )
  }

  // 宿主侧真正调用的路径：gameOps.js 里所有 callGet(server, '<suffix>') 拼接 SERVER_HALF_PREFIX
  const suffixes = [...gameOpsCode.matchAll(/callGet\(\s*server\s*,\s*'([^']+)'/g)].map((x) => x[1])
  assert.ok(suffixes.length > 0, 'gameOps.js 里没抽到任何 callGet(server, …) 调用点，说明扫描方式失效了')
  const hostPaths = [...new Set(suffixes.map((s) => `${SERVER_HALF_PREFIX}${s}`))]

  assert.deepEqual(
    [...hostPaths].sort(),
    [...ownRoutes].sort(),
    '宿主实际调用的路径集合必须与服端注册的 5 条路由完全一致：'
    + '宿主调用一条服端没注册的路（或服端注册了没人用的路）都会变成静默失败',
  )
  assert.equal(hostPaths.length, 5, `宿主调用的**不同**路径必须恰好 5 条，实际 ${hostPaths.length}：${hostPaths.join(', ')}`)
})

test('路由的注册与反注册共用同一份 OwnRoutes 清单（热重载先摘再注册，不留残影）', () => {
  // 注册处：5 条 SecureRestCommand 的路径集合必须与 OwnRoutes 完全一致
  const registered = [...pluginCode.matchAll(/new SecureRestCommand\(\s*"([^"]+)"/g)].map((m) => m[1])
  const ownRoutes = csharpStrings(csharpBlock(pluginCode, 'private static readonly string[] OwnRoutes', '路由清单'))
  assert.equal(registered.length, 5, `注册处应当恰好 5 条 SecureRestCommand，实际 ${registered.length}`)
  assert.deepEqual(
    [...registered].sort(),
    [...ownRoutes].sort(),
    '注册的路由必须与 OwnRoutes 清单逐条对应：漏进清单的路由在热重载时**摘不掉**，'
    + '新旧两份路由会同时挂在 TShock 上（谁被命中取决于注册顺序，表现为"改了没生效"）',
  )

  // 反注册处：按同一份清单摘
  assert.match(
    pluginCode,
    /var set = new HashSet<string>\(OwnRoutes, StringComparer\.OrdinalIgnoreCase\);/,
    '反注册必须用 OwnRoutes 建集合（大小写不敏感：TShock 的路由匹配与本件的大小写写法未必一致）',
  )
  assert.match(
    pluginCode,
    /cmdList\.RemoveAll\(c => set\.Contains\(c\.UriTemplate\)\);/,
    '反注册必须按 UriTemplate 命中清单里的路由',
  )
  // Init 与 Dispose 都要动这份清单（先摘再注册 / 卸载时摘掉）
  assert.match(pluginCode, /RemoveOwnRoutes\(\);\s*RemoveOwnCommands\(\);/, 'Initialize 必须先摘同名路由与命令再注册（重复加载不残留）')
  assert.match(pluginCode, /RemoveOwnCommands\(\);[\s\S]{0,200}?RemoveOwnRoutes\(\);/, 'Dispose 必须摘掉自己的路由与命令')
})

// ═══════════════════ 渲染行为（照代码） ═══════════════════

test('渲染发包：用的是 PacketTypes.Status 枚举成员（不是硬编码 9）且带 0x1f 标志', () => {
  assert.match(
    rendererCode,
    /p\.SendData\(PacketTypes\.Status,\s*text,\s*0,\s*0x1f\)/,
    '渲染必须用 p.SendData(PacketTypes.Status, text, 0, 0x1f)（Terraria 原生 9 号 StatusText 包 + 0x1f 标志），'
    + '这是"面板画在客户端屏幕固定锚点"的唯一途径；换成聊天/公告 API 就不是状态面板了',
  )
  assert.match(
    rendererCode,
    /player\.SendData\(PacketTypes\.Status,\s*"",\s*0,\s*0x1f\)/,
    '清屏也必须走 9 号包（发空文本），否则客户端不会重绘、旧文字会永久冻在屏幕上',
  )
  // 用枚举成员而不是魔法数字：9 是 Terraria 自己的协议编号，硬编码会在协议变动时静默错位
  assert.equal(
    /SendData\(\s*9\s*,/.test(rendererCode),
    false,
    '不得用硬编码的包号 9 发包（必须用 PacketTypes.Status 枚举成员，协议含义由 Terraria 自己保证）',
  )
})

test('渲染节流：形状是 (TickCount + playerIndex) % interval，且判定与拼装两遍用同一公式', () => {
  const hits = countOf(rendererCode, '(_tickCount + (ulong)p.Index) % interval == 0')
  assert.equal(
    hits,
    2,
    '节流公式 (_tickCount + (ulong)p.Index) % interval == 0 必须在**代码里**出现两次'
    + '（第一遍判定"是否有行到期"、第二遍决定"这一行要不要重新插值"）；'
    + `两遍不一致会导致"判定为需要更新但拼出来的内容没变"。实际出现 ${hits} 次`,
  )
  assert.match(
    rendererCode,
    /if \(\(_tickCount \+ \(ulong\)p\.Index\) % interval == 0\)/,
    '第一遍：只判定"是否需要发包"（未到期直接返回，旧版每 tick 每玩家都白拼一遍整块文本）',
  )
  assert.match(
    rendererCode,
    /if \(force \|\| \(_tickCount \+ \(ulong\)p\.Index\) % interval == 0\)/,
    '第二遍：只有到期（或被强制刷新）的行才重新插值，其余行用缓存 —— 与第一遍必须是同一个公式',
  )
  assert.match(rendererCode, /\(ulong\)p\.Index/, '节流必须按玩家下标错开相位（"整秒齐发"会在同一个 tick 做几十次拼串 + 发几十个包）')
})

test('行尾空格是"行尾追加"，且已以换行结尾的行不再补空格（照旧版既有语义）', () => {
  assert.match(
    rendererCode,
    /if \(content\.EndsWith\("\\n", StringComparison\.Ordinal\)\)\s*\{\s*sb\.Append\(content\);\s*\}[\s\S]{0,120}?else\s*\{\s*sb\.Append\(content\);\s*sb\.Append\(spacer\);\s*sb\.Append\('\\n'\);\s*\}/,
    'AppendLine 必须这样写：先追加内容；内容已以 \\n 结尾时原样追加（既不补空格也不再补换行），'
    + '否则在原内容之后补 spacer 与换行。顺序写反（先 spacer 再内容）会让"撑宽"落在行首，客户端锚点会明显偏移',
  )
  // 两条渲染路径（静态行/动态行）都必须补 spacer，漏一条就会出现"有的行撑宽、有的行不撑宽"
  assert.match(rendererCode, /AppendLine\(sb,\s*line\["text"\]\?\.ToString\(\) \?\? "",\s*spacer\)/, 'StaticText 行也要补行尾空格')
  assert.match(rendererCode, /AppendLine\(sb,\s*cache\[i\] \?\? "",\s*spacer\)/, 'DynamicText 行也要补行尾空格')
})

test('清屏：ClearScreen 存在，且"关闭面板 / 卸载插件 / 总开关关闭 / 渲染为空"四条路径都会补发空文本', () => {
  assert.match(
    rendererCode,
    /public static bool ClearScreen\(TSPlayer\? player, string reason, bool force = false\)/,
    '必须存在 ClearScreen：它是"关掉面板后屏幕上的旧文字还在"这个旧版缺陷的唯一修法',
  )
  assert.match(
    rendererCode,
    /if \(!visible\)\s*\{\s*ClearScreen\(/,
    'SetVisible 的关闭分支必须立即 ClearScreen（玩家 /st off 后屏幕上不能留着文本）',
  )
  // Dispose 的实际链路是 Dispose -> ClearAllScreens -> ClearScreen（逐个在线玩家），这里照代码写
  assert.match(
    rendererCode,
    /var cleared = ClearAllScreens\("插件卸载"\)/,
    'Dispose 必须清空所有在线玩家的屏幕文本（插件卸载后没人能再纠正残留文本）',
  )
  assert.match(
    rendererCode,
    /public static int ClearAllScreens\(string reason, bool force = true\)[\s\S]*?if \(ClearScreen\(p, reason, force\)\) n\+\+;/,
    'ClearAllScreens 必须逐个在线玩家调用 ClearScreen（Dispose 依赖它；这条链路是本件清屏的兜底）',
  )
  assert.match(rendererCode, /ClearScreen\(p, "总开关关闭"\)/, '总开关关闭的那一次 tick 必须补发空文本（旧版直接 return，文字永久冻住）')
  assert.match(rendererCode, /ClearScreen\(p, "面板渲染为空"\)/, '面板没有可渲染的行时也要清屏，否则会留着上一版配置的文字')
})

// ═══════════════════ 服端配置归一（Sanitize） ═══════════════════

test('Sanitize 对 panelSpacers 的 null / 负值 / 超上限三种情况都有处理', () => {
  assert.match(
    configCode,
    /foreach \(var kv in src\.PanelSpacers \?\? new Dictionary<string, int>\(\)\)/,
    'panelSpacers 为 null 时必须折成空表（旧版 new Dictionary<string,int>(null) 会抛 ArgumentNullException，表现为读配置接口 500）',
  )
  assert.match(
    configCode,
    /if \(kv\.Value < 0\) continue;/,
    'panelSpacers 的负值必须按"未配置"处理（继续回退全局 spacerWidth，与旧版一致）',
  )
  assert.match(
    configCode,
    /if \(kv\.Value > StatusPanelDefaults\.MaxSpacerWidth\)\s*\{[\s\S]{0,200}?spacers\[kv\.Key\] = StatusPanelDefaults\.MaxSpacerWidth;/,
    'panelSpacers 超过上限必须夹到 MaxSpacerWidth 并记一条 note（旧版面板级没有上限，本件刻意收紧）',
  )
  assert.match(
    configCode,
    /var spacerWidth = src\.SpacerWidth;[\s\S]{0,400}?StatusPanelDefaults\.MaxSpacerWidth;/,
    '全局 spacerWidth 也要在冷启动读文件时夹到 [0,500]（不能只在 REST 写入时夹）',
  )
})

// ═══════════════════ 命令注册 ═══════════════════

test('命令注册用的是"无权限"重载 Command(handler, names)，而不是 new Command("", …)', () => {
  assert.match(
    pluginCode,
    /new Command\(\s*StatusPanelCommands\.Toggle,\s*StatusPanelCommands\.Names\s*\)/,
    '注册必须用 TShock 的无权限重载 new Command(handler, names)：'
    + 'Permissions 为空列表 -> CanRun 直接 true，语义是"所有玩家可用"（与旧版一致），'
    + '但不依赖"空权限串即通过"这个隐式约定',
  )
  assert.equal(
    /new Command\(\s*""/.test(pluginCode),
    false,
    'StatusPanelPlugin.cs（唯一的注册处）里不得出现 new Command("", …)：空权限串能不能通取决于 TShock 的隐式行为，'
    + '一旦哪天语义变了，命令会突然"人人不可用"或"人人可用"而无任何提示',
  )
  // 全仓源码的**可执行代码**里也不该有这种写法（StatusPanelCommands.cs 的注释里引用旧版写法是允许的）
  for (const name of CSHARP_FILES) {
    assert.equal(
      /new Command\(\s*""/.test(stripComments(readCsharp(name))),
      false,
      `${name} 的可执行代码里出现了 new Command("", …)：请改用无权限重载`,
    )
  }
  assert.match(commandsCode, /public static readonly string\[\] Names = \{ "statustext", "st" \};/, '命令名清单必须是 /statustext 与 /st 两个（旧版即这两个）')
})

// ═══════════════════ REST 权限与 400 语义 ═══════════════════

test('REST 权限节点是 data.rest.invsee，且 5 条路由全用它注册（代码层绑定）', () => {
  assert.match(
    pluginCode,
    /private const string RoutePermission = "data\.rest\.invsee";/,
    '权限节点必须是 data.rest.invsee（与旧版 StatusPanel 路由一致，见旧版 Main.cs:177-182）',
  )
  const secure = [...pluginCode.matchAll(/new SecureRestCommand\(\s*"([^"]+)",\s*([\w.]+),\s*RoutePermission\s*\)/g)]
  assert.equal(secure.length, 5, `5 条路由都必须用 RoutePermission 常量注册（避免某一条被漏掉权限），实际 ${secure.length} 条`)
  for (const m of secure) {
    assert.ok(
      m[1].startsWith(`${SERVER_HALF_PREFIX}/`),
      `SecureRestCommand 注册的路径 ${m[1]} 必须在 ${SERVER_HALF_PREFIX}/ 前缀下`,
    )
    assert.match(m[2], /^StatusPanelEndpoints\.\w+$/, `路由 ${m[1]} 的处理函数应当来自 StatusPanelEndpoints，实际 ${m[2]}`)
  }
})

test('REST 权限节点的归属说明：Endpoints.cs 头部注明统一用 data.rest.invsee（文档层，故扫全文）', () => {
  // 这条刻意扫**全文**（不剔注释）：它约束的不是行为，而是"该文件说明了权限节点的归属"。
  // 真正决定权限的是上一条断言（Plugin.cs 里的 RoutePermission 与 5 条注册，扫代码）。
  assert.match(
    endpointsCs,
    /data\.rest\.invsee/,
    'StatusPanelEndpoints.cs 头部必须注明本件端点统一使用 data.rest.invsee：'
    + '该文件是端点契约的自述（谁读它都该知道要开哪个权限），这条属于文档口径，因此按全文断言',
  )
})

test('REST 参数校验：version 非法时返回 400（RestObject 的第一个构造参数即 HTTP 状态）', () => {
  assert.match(
    endpointsCode,
    /version 非法[\s\S]{0,400}?new RestObject\("400"\)/,
    'snapshot 端点在 version 非法时必须返回 new RestObject("400") + applied=false + error：'
    + '旧版对失败恒回 200，后端只看 res.ok，于是"没生效"被当成"推送成功"——这正是本件要根治的静默失效',
  )
  assert.match(
    endpointsCode,
    /total 非法[\s\S]{0,400}?new RestObject\("400"\)/,
    'online 端点在 total 非法（缺失/负数）时同样必须返回 400，而不是静默忽略',
  )
})

// ═══════════════════ 反面对照：旧链路不重建 ═══════════════════

test('反面对照（只看可执行代码）：C# 里不得出现 /tsweb/statuspanel、HMACSHA256、WebRestServer', () => {
  assert.ok(
    CSHARP_FILES.length >= 8,
    `扫描到的 C# 源文件只有 ${CSHARP_FILES.length} 个：反面对照必须在"确实扫到了全部源码"的前提下才有意义`,
  )

  // 口径说明（刻意写进断言信息里，避免后人误改）：
  //   这个断言要证明的是"本件没有重建旧链路"，而注释既不能重建路由也不能重建签名 —— 它只是文档。
  //   源码里**刻意**保留了旧版链路的溯源引用（例如说明"旧版那条路由恒回 200"时写出旧路径与旧文件行号），
  //   交付报告要求把"旧版缺陷在哪一行"讲清楚，用户要能顺着注释查回旧代码，删掉它才是真正的损失。
  //   因此这里只看**剔除注释后的可执行代码**：注释里的旧路径是有意保留的溯源引用，不算违规。
  //   （产物层的对应证据在 test/dll-content.test.mjs：DLL 字节里同样不得出现这三个串，因为注释不进元数据。）
  for (const needle of ['/tsweb/statuspanel', 'HMACSHA256', 'WebRestServer']) {
    const hits = occurrencesInCode(needle)
    assert.deepEqual(
      hits,
      [],
      `剔除注释后仍出现 ${needle}：说明有代码在真的使用旧链路（旧版自研下发路由 / HMAC-SHA256 签名 / 旧版 REST 服务器），`
      + '而不是仅仅在注释里作溯源说明。位置：' + (hits.join('、') || '（无）'),
    )
  }
})

test('溯源引用是有意保留的：旧路径只以注释形式存在（文档层，不算重建旧链路）', () => {
  // 与上一条互补：上一条管"代码里不许有"，这一条管"注释里的溯源引用还在、且只在注释里"。
  for (const needle of ['/tsweb/statuspanel', 'WebRestServer']) {
    const inText = occurrencesInFileText(needle)
    assert.ok(
      inText.length > 0,
      `源码里应当保留 ${needle} 的溯源引用（交付报告要求写清"旧版缺陷在哪一行"，读者要能顺着注释查回旧代码）：`
      + '如果这条注释被删了，等于丢掉了唯一的可追溯线索',
    )
    const inCode = occurrencesInCode(needle)
    assert.deepEqual(
      inCode,
      [],
      `${needle} 只允许出现在注释里（作溯源说明），不得出现在可执行代码里。位置：${inCode.join('、') || '（无）'}`,
    )
    console.log(`[panel-source] ${needle} 的溯源引用位置（注释）：${inText.join('、')}`)
  }
})
