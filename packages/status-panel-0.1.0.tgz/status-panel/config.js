/**
 * status-panel 配置模型（宿主半）
 *
 * 一份配置 = 旧版 TsWeb 的**一整个 statuspanel.json**（旧版是"每服一份文件"，见
 * TsWeb/plugin/StatusPanel.cs:29-60）。新宿主把它提升为"**按服务器分片**"：
 *
 *   <dataDir>/status-panel/config.json
 *   {
 *     "version": 1,
 *     "updatedAt": "...",
 *     "servers": {
 *       "<serverId>": { enabled, spacerWidth, logLevel, panels, panelSpacers }
 *     }
 *   }
 *
 * 为什么按服务器分片：旧版前端用 `x-server-id` 请求头选择目标服（frontend/src/utils/api.js:31-33），
 * 后端 `tshockService.setStatusPanelConfig` 把配置**原样转发给那一台游戏服**
 * （backend/services/tshockService.js:1935-1968），所以旧版语义就是"每台服一份独立配置"。
 * 新宿主必须保持这一点：面板是"这台服给玩家看什么"，A 服的开荒模板不该出现在 B 服。
 * 没有配置记录的服务器按 defaultConfig()（未启用 + 内置模板）处理 —— 与旧版"新装一台服，配置文件
 * 尚未生成时 DLL 用默认值"的行为一致（旧版 StatusPanel.cs:181-186）。
 *
 * 字段与默认值**逐字对齐**旧版（见交付报告的语义对照表）：
 *   enabled        bool    默认 **false**（TsWeb/plugin/StatusPanel.cs:33；注意旧版前端组件里的
 *                           `enabled` 初值是 true（StatusPanelSettingsView.vue:57），组件初值不等于插件默认值）
 *   spacerWidth    int     默认 60（StatusPanel.cs:37），REST 写入时夹到 [0,500]（StatusPanel.cs:340）
 *   logLevel       string  默认 "INFO"（StatusPanel.cs:41）——旧版是**死字段**，本件让它在游戏服端真正生效
 *   panels         object  面板名 → 行数组，`default` 强制存在（StatusPanel.cs:177-179）
 *   panelSpacers   object  面板名 → 行尾空格数（面板级覆盖）；缺失/负值回退全局（StatusPanel.cs:243）
 *   （v1 的 statusTextSettings 仅作为**输入**被接受并迁移进 panels.default，输出里不再出现）
 *
 * 行元素（裸对象，字段名照旧版）：
 *   typeName           "StaticText" | "DynamicText"；其它值（含缺失）**渲染时整行丢弃**
 *                      ——照旧版 StatusPanel.cs:480-499 的 switch/default 分支
 *   text               行文本（DynamicText 做插值）
 *   updateInterval     节流间隔（**单位：帧**；默认 60；<1 按 1 处理）（StatusPanel.cs:487-488）
 *   pluginName/enabled/overrideInterval
 *                      仅 REST 往返透传，渲染时**不读**（旧版即如此，本件照旧）
 */

/** 全局行尾空格默认值（旧版 StatusPanel.cs:37） */
export const DEFAULT_SPACER_WIDTH = 60

/** 日志等级默认值（旧版 StatusPanel.cs:41） */
export const DEFAULT_LOG_LEVEL = 'INFO'

/** 日志等级闭集：与旧版前端下拉逐字一致（StatusPanelSettingsView.vue:60） */
export const LOG_LEVELS = ['NONE', 'ERROR', 'WARNING', 'INFO', 'DEBUG']

/** 行尾空格上限（旧版 REST 写入时夹到 [0,500]，前端输入框也是 min=0 max=500） */
export const MAX_SPACER_WIDTH = 500

/**
 * 单个面板最多**渲染**的行数。
 * 与游戏服半 plugin/StatusPanelRenderer.cs 的 MaxRowsPerPanel 必须一致（否则宿主以为能显示、
 * 服端却截断，probe 比对会长期不一致）。取值理由写在 C# 那侧（屏幕锚点在 y=84，行高约 26px）。
 */
export const MAX_ROWS_PER_PANEL = 20

/**
 * 单个面板允许**配置**的行数上限。
 * 与游戏服半 StatusPanelConfigStore.Sanitize 的 MaxConfiguredRowsPerPanel 一致：
 * 服端会在归一阶段截断，宿主若保留更多行，probe 就会永远显示"两侧不一致"。
 */
export const MAX_CONFIGURED_ROWS_PER_PANEL = 200

/** 可渲染的行类型（其余类型只做往返透传，渲染时丢弃） */
export const ROW_TYPES = ['StaticText', 'DynamicText']

/** 行元素里本件认识并归一的字段（顺序即输出顺序；其余键原样透传在后面） */
export const ROW_KEYS = ['typeName', 'text', 'updateInterval', 'pluginName', 'enabled', 'overrideInterval']

/** 面板保留字：与 /st on|off|show|hide 冲突（旧版前端 STATUS 视图 :48 的 RESERVED_NAMES） */
export const RESERVED_PANEL_NAMES = ['on', 'off', 'show', 'hide']

/** updateInterval 默认值（帧）：旧版 StatusPanel.cs:487 + 旧版前端新行默认值 60 */
export const DEFAULT_INTERVAL_FRAMES = 60

/** updateInterval 上限（帧）：与游戏服半 StatusPanelRenderer.MaxIntervalFrames 一致 */
export const MAX_INTERVAL_FRAMES = 1_000_000

/**
 * 插值正则：**必须与游戏服半逐字一致**（旧版 TsWeb/plugin/StatusPanel.cs:105
 * `(?:{{[^{\s]*?}}|{[^{\s]*?})`）。
 * 语义：`{{abc}}` → 字面量 `{abc}`；`{ x }`（带空格）不匹配；未知 `{x}` 原样保留。
 */
export const INTERPOLATION_REGEX = /(?:{{[^{\s]*?}}|{[^{\s]*?})/g

/** default 面板名（强制存在） */
export const DEFAULT_PANEL_NAME = 'default'

/**
 * 全部 26 个占位符（**唯一权威清单的宿主侧镜像**；游戏服半 StatusPanelPlaceholders.AllTokens 是权威，
 * 本清单由 test/placeholder-consistency.test.mjs 与 C# 源码逐个比对，防止两边漂移）。
 */
export const PLACEHOLDER_TOKENS = [
  '{PlayerName}', '{PlayerGroupName}', '{PlayerLife}', '{PlayerMana}',
  '{PlayerLifeMax}', '{PlayerManaMax}', '{PlayerLuck}',
  '{PlayerCoordinateX}', '{PlayerCoordinateY}', '{PlayerCurrentRegion}',
  '{IsPlayerAlive}', '{RespawnTimer}',
  '{OnlinePlayersCount}', '{OnlinePlayersList}',
  '{AnglerQuestFishName}', '{AnglerQuestFishID}', '{AnglerQuestFishingBiome}', '{AnglerQuestCompleted}',
  '{CurrentTime}', '{RealWorldTime}', '{WorldName}', '{CurrentBiomes}',
  '{AllOnlineCount}', '{SystemTime}',
  '{CurrentBossName}', '{CurrentBossSpawnItemId}',
]

/**
 * 默认面板模板（4 行）——**逐字照搬**旧版 TsWeb/plugin/StatusPanel.cs:63-75 的 StatusPanelDefaults.Template()。
 * 旧版前端另有一份等价副本（StatusPanelSettingsView.vue:40-45），属于"双份真相源"；
 * 本件由 test/placeholder-consistency.test.mjs 断言三处（C# / 本文件 / 前端 client）完全一致，
 * 从而在结构上消除漂移。
 */
export function defaultPanelRows() {
  return [
    { typeName: 'DynamicText', text: '[i:757][c/f15642:开荒服]', updateInterval: 600 },
    { typeName: 'DynamicText', text: '在线人数：{OnlinePlayersCount}人', updateInterval: 60 },
    { typeName: 'DynamicText', text: '全服在线：{AllOnlineCount}人', updateInterval: 60 },
    { typeName: 'DynamicText', text: '系统时间：{SystemTime}', updateInterval: 60 },
  ]
}

/**
 * 下发与对账节奏（**不写进配置文件**）。
 * 为什么不做成可写配置项：本件的配置文件要尽量保持旧版字段形态（enabled/spacerWidth/logLevel/
 * panels/panelSpacers），节奏只影响"多快把配置与在线数推到服端"，不影响面板语义，
 * 因此作为模块常量 + apply 时的 options 覆盖入口。
 */
export const PUSH_DEFAULTS = {
  /** 配置变更后立即下发；false 只影响"变更即推"，手动推送与周期对账仍在 */
  pushOnChange: true,
  /** 服务器连接建立 / 服务器列表加载后补推 */
  pushOnServerConnect: true,
  /** 配置对账：无条件重推一遍（配置极小，代价可忽略；能自愈"服端配置被删改/重置"） */
  reconcileIntervalMs: 600_000,
  /** 推送失败后的首次重试间隔 */
  retryIntervalMs: 60_000,
  /** 失败重试的退避上限 */
  retryMaxIntervalMs: 600_000,
  /**
   * 全服在线数的去抖窗口。
   * 旧版后端是 300ms 去抖（backend/services/statusPanelService.js 的 debounce），
   * 保留这个量级：一次玩家上下线风暴只下发一轮，且**这一轮里所有服拿到同一个数字**
   * （旧版曾因每服独立取值导致同一时刻各服显示不同，见交付报告）。
   */
  onlineDebounceMs: 300,
  /** 全服在线数的兜底刷新周期：即使在线数没变也重推一遍（自愈服端重启/丢包） */
  onlineReconcileIntervalMs: 600_000,
  /** on('tick') 里"在线数变了就推"的开关 */
  onlinePushOnTick: true,
}

/** 单次下发时可序列化进 query 的 panels JSON 上限（超出即明确报错，而不是让 HTTP 层给出费解的失败） */
export const MAX_PAYLOAD_CHARS = 8000

/** 构造带 status 的错误（宿主路由按 err.status 回状态码） */
export function httpError(status, message, extra = {}) {
  const err = new Error(message)
  err.status = status
  Object.assign(err, extra)
  return err
}

/** 400 的语法糖 */
export function badRequest(message) {
  return httpError(400, message)
}

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v)
}

/** 默认配置：未启用 + 内置模板（与游戏服半 StatusPanelConfigStore 的默认值一致） */
export function defaultConfig() {
  return {
    enabled: false,
    spacerWidth: DEFAULT_SPACER_WIDTH,
    logLevel: DEFAULT_LOG_LEVEL,
    panels: { [DEFAULT_PANEL_NAME]: defaultPanelRows() },
    panelSpacers: {},
  }
}

export function emptyStore() {
  return { version: 1, updatedAt: '', servers: {} }
}

/** 数字归一：非有限数返回 null（调用方决定兜底） */
function toFiniteNumber(v) {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v)
    return Number.isFinite(n) ? n : null
  }
  return null
}

/** 整数归一：向下取整；非法返回 null */
function toInt(v) {
  const n = toFiniteNumber(v)
  return n === null ? null : Math.floor(n)
}

/** 夹取到 [0, MAX_SPACER_WIDTH] */
export function clampSpacer(value) {
  const n = toInt(value)
  if (n === null) return null
  if (n < 0) return 0
  return n > MAX_SPACER_WIDTH ? MAX_SPACER_WIDTH : n
}

/** 归一 updateInterval（帧）：默认 60，<1 按 1，>MAX 按 MAX（与 C# 的 ParseInterval 同一口径） */
export function normalizeInterval(value, notes = [], where = '') {
  if (value === undefined || value === null) return DEFAULT_INTERVAL_FRAMES
  const n = toInt(value)
  if (n === null) {
    notes.push(`${where} 的 updateInterval=${JSON.stringify(value)} 不是数字，已按默认 ${DEFAULT_INTERVAL_FRAMES} 帧处理`)
    return DEFAULT_INTERVAL_FRAMES
  }
  if (n < 1) {
    notes.push(`${where} 的 updateInterval=${n} 小于 1，已按 1 帧处理`)
    return 1
  }
  if (n > MAX_INTERVAL_FRAMES) {
    notes.push(`${where} 的 updateInterval=${n} 超过上限 ${MAX_INTERVAL_FRAMES} 帧，已按上限处理`)
    return MAX_INTERVAL_FRAMES
  }
  return n
}

/**
 * 归一单个行元素。
 * 保留全部键（已知键先按 ROW_KEYS 顺序输出，未知键原样跟随），从而保证：
 *   1. `pluginName` / `enabled` / `overrideInterval` 等**往返透传字段不丢**（旧版即如此）
 *   2. 输出顺序确定 → canonicalJson 稳定 → probe 逐字段比对可用
 */
export function normalizeRow(row, notes = [], where = '') {
  if (!isPlainObject(row)) {
    notes.push(`${where} 不是对象，已丢弃该行`)
    return null
  }
  // 已知键按 ROW_KEYS 的顺序输出（输出顺序确定 → canonicalJson 稳定 → probe 逐字段比对可用）
  const out = {}
  // typeName：照旧版是字符串比较（"StaticText"/"DynamicText"）；非字符串统一折成字符串
  out.typeName = row.typeName === undefined || row.typeName === null ? '' : String(row.typeName)
  // text：旧版 `line["text"]?.ToString() ?? ""` → 非字符串按字符串处理，缺失即空串
  out.text = row.text === undefined || row.text === null ? '' : String(row.text)
  out.updateInterval = normalizeInterval(row.updateInterval, notes, where)
  for (const key of ROW_KEYS) {
    if (key === 'typeName' || key === 'text' || key === 'updateInterval') continue
    if (Object.prototype.hasOwnProperty.call(row, key)) out[key] = row[key]
  }
  // 其余键原样跟随（往返透传，不丢字段）
  for (const key of Object.keys(row)) {
    if (Object.prototype.hasOwnProperty.call(out, key)) continue
    out[key] = row[key]
  }
  return out
}

/**
 * 归一整份配置（**不抛错**，容错并把每处调整记进 notes）。
 * 与游戏服半 StatusPanelConfigStore.Sanitize 逐条对应，保证"宿主发出去的配置"与
 * "服端归一后的配置"一致（probe 才有意义）。
 */
export function normalizeConfig(raw, notes = []) {
  const src = isPlainObject(raw) ? raw : {}
  if (!isPlainObject(raw)) notes.push('配置不是对象，已按默认值处理')

  // ── panels（含 v1 statusTextSettings 迁移）──
  const panels = {}
  const rawPanels = isPlainObject(src.panels) ? src.panels : {}
  if (src.panels !== undefined && !isPlainObject(src.panels)) notes.push('panels 不是对象，已按空表处理')
  for (const [name, rows] of Object.entries(rawPanels)) {
    const panelName = String(name)
    if (panelName === '') {
      notes.push('panels 里存在空面板名，已忽略该面板')
      continue
    }
    if (!Array.isArray(rows)) {
      notes.push(`面板「${panelName}」的行列表不是数组，已按空面板处理`)
      panels[panelName] = []
      continue
    }
    const out = []
    rows.forEach((row, idx) => {
      const normalized = normalizeRow(row, notes, `面板「${panelName}」第 ${idx + 1} 行`)
      if (normalized) out.push(normalized)
    })
    if (out.length > MAX_CONFIGURED_ROWS_PER_PANEL) {
      notes.push(
        `面板「${panelName}」配置了 ${out.length} 行，超过配置上限 ${MAX_CONFIGURED_ROWS_PER_PANEL} 行，已截断`
        + `（渲染上限为 ${MAX_ROWS_PER_PANEL} 行）`,
      )
      panels[panelName] = out.slice(0, MAX_CONFIGURED_ROWS_PER_PANEL)
    } else {
      panels[panelName] = out
    }
  }

  // v1：仅当 panels 为空时，把 statusTextSettings 迁进 panels.default（旧版 StatusPanel.cs:171-175）
  const legacyRows = Array.isArray(src.statusTextSettings) ? src.statusTextSettings : null
  if (Object.keys(panels).length === 0 && legacyRows && legacyRows.length > 0) {
    const migrated = []
    legacyRows.forEach((row, idx) => {
      const normalized = normalizeRow(row, notes, `statusTextSettings 第 ${idx + 1} 行`)
      if (normalized) migrated.push(normalized)
    })
    panels[DEFAULT_PANEL_NAME] = migrated.slice(0, MAX_CONFIGURED_ROWS_PER_PANEL)
    notes.push('已把 v1 字段 statusTextSettings 迁移为 panels.default')
  }

  // 强制 default 面板存在（旧版 StatusPanel.cs:177-179）
  if (!Object.prototype.hasOwnProperty.call(panels, DEFAULT_PANEL_NAME)) {
    panels[DEFAULT_PANEL_NAME] = defaultPanelRows()
    notes.push('配置里没有 default 面板，已补入内置默认模板')
  }

  // ── panelSpacers ──
  const spacers = {}
  const rawSpacers = isPlainObject(src.panelSpacers) ? src.panelSpacers : {}
  if (src.panelSpacers !== undefined && !isPlainObject(src.panelSpacers)) {
    // 旧版致命缺陷：配置文件里写 "panelSpacers": null 会让 GetConfigJson 抛 ArgumentNullException
    // （StatusPanel.cs:322 直接 new Dictionary<string,int>(null)），接口 500、配置读不出来。
    // 本件把 null 与非对象一并折成空表（注意 null 也要留说明：它正是旧版出事的那一种输入）。
    notes.push(
      src.panelSpacers === null
        ? 'panelSpacers 是 null，已按空表处理（旧版会因此抛 ArgumentNullException）'
        : 'panelSpacers 不是对象，已按空表处理',
    )
  }
  for (const [name, value] of Object.entries(rawSpacers)) {
    const panelName = String(name)
    if (panelName === '') continue
    const n = toInt(value)
    if (n === null) {
      notes.push(`panelSpacers["${panelName}"]=${JSON.stringify(value)} 不是数字，已按未配置处理（回退全局）`)
      continue
    }
    if (n < 0) {
      notes.push(`panelSpacers["${panelName}"]=${n} 为负，已按未配置处理（回退全局）`)
      continue
    }
    if (n > MAX_SPACER_WIDTH) {
      notes.push(`panelSpacers["${panelName}"]=${n} 超过上限，已夹到 ${MAX_SPACER_WIDTH}`)
      spacers[panelName] = MAX_SPACER_WIDTH
      continue
    }
    spacers[panelName] = n
  }

  // ── 全局字段 ──
  let enabled = false
  if (typeof src.enabled === 'boolean') enabled = src.enabled
  else if (src.enabled === 'true' || src.enabled === 'false') enabled = src.enabled === 'true'
  else if (src.enabled !== undefined) notes.push(`enabled=${JSON.stringify(src.enabled)} 不是布尔值，已按 false 处理`)

  let spacerWidth = DEFAULT_SPACER_WIDTH
  if (src.spacerWidth !== undefined && src.spacerWidth !== null) {
    const clamped = clampSpacer(src.spacerWidth)
    if (clamped === null) {
      notes.push(`spacerWidth=${JSON.stringify(src.spacerWidth)} 不是数字，已按默认 ${DEFAULT_SPACER_WIDTH} 处理`)
    } else {
      if (String(clamped) !== String(src.spacerWidth)) notes.push(`spacerWidth=${src.spacerWidth} 已夹到 ${clamped}`)
      spacerWidth = clamped
    }
  }

  let logLevel = DEFAULT_LOG_LEVEL
  const rawLog = src.logLevel === undefined || src.logLevel === null ? '' : String(src.logLevel)
  const upper = rawLog.trim().toUpperCase()
  if (upper === '') {
    logLevel = DEFAULT_LOG_LEVEL
  } else if (LOG_LEVELS.includes(upper)) {
    logLevel = upper
  } else {
    notes.push(`logLevel="${rawLog}" 不是 ${LOG_LEVELS.join('/')} 之一，已按 ${DEFAULT_LOG_LEVEL} 处理`)
  }

  return { enabled, spacerWidth, logLevel, panels, panelSpacers: spacers }
}

/**
 * 严格校验（POST /api/status-panel/config 用）：任何非法值都抛 400，**绝不静默兜底**。
 * 与 normalizeConfig 的分工：
 *   - normalizeConfig 负责"读文件 / 读服端回包 / 兼容旧数据"这种必须容错的路径
 *   - validateConfig 负责"用户刚提交的配置"这种应该直接驳回的路径
 * 为什么不在提交时也容错：静默纠正会让管理员以为"我写的就是生效的"，
 * 而那正是旧版最典型的一类静默失效（改了没生效、还没有任何提示）。
 */
export function validateConfig(raw) {
  if (!isPlainObject(raw)) throw badRequest('config 必须是对象（收到 ' + JSON.stringify(raw) + '）')

  if (raw.enabled !== undefined && typeof raw.enabled !== 'boolean') {
    throw badRequest('enabled 必须是布尔值')
  }
  if (raw.spacerWidth !== undefined) {
    const n = toInt(raw.spacerWidth)
    if (n === null) throw badRequest('spacerWidth 必须是整数')
    if (n < 0 || n > MAX_SPACER_WIDTH) throw badRequest(`spacerWidth 必须在 0~${MAX_SPACER_WIDTH} 之间（收到 ${n}）`)
  }
  if (raw.logLevel !== undefined) {
    const s = String(raw.logLevel).trim().toUpperCase()
    if (!LOG_LEVELS.includes(s)) throw badRequest(`logLevel 必须是 ${LOG_LEVELS.join(' / ')} 之一（收到 ${raw.logLevel}）`)
  }

  if (raw.panels !== undefined) {
    if (!isPlainObject(raw.panels)) throw badRequest('panels 必须是对象（面板名 → 行数组）')
    for (const [name, rows] of Object.entries(raw.panels)) {
      if (String(name).trim() === '') throw badRequest('panels 里存在空面板名')
      if (RESERVED_PANEL_NAMES.includes(String(name).toLowerCase())) {
        throw badRequest(`面板名「${name}」是保留字（${RESERVED_PANEL_NAMES.join('/')}），与 /st on|off|show|hide 冲突`)
      }
      if (!Array.isArray(rows)) throw badRequest(`面板「${name}」的行列表必须是数组`)
      if (rows.length > MAX_CONFIGURED_ROWS_PER_PANEL) {
        throw badRequest(`面板「${name}」配置了 ${rows.length} 行，超过上限 ${MAX_CONFIGURED_ROWS_PER_PANEL} 行`)
      }
      rows.forEach((row, idx) => {
        const where = `面板「${name}」第 ${idx + 1} 行`
        if (!isPlainObject(row)) throw badRequest(`${where} 必须是对象`)
        if (row.typeName === undefined || row.typeName === null || String(row.typeName).trim() === '') {
          // 旧版：typeName 缺失的行在渲染时被静默丢弃（玩家看不到、界面也不知道）→ 这里直接驳回
          throw badRequest(`${where} 缺少 typeName（只能是 ${ROW_TYPES.join(' / ')} 或需要往返透传的类型）`)
        }
        if (row.text !== undefined && typeof row.text !== 'string') {
          throw badRequest(`${where} 的 text 必须是字符串`)
        }
        if (row.updateInterval !== undefined && row.updateInterval !== null) {
          const n = toInt(row.updateInterval)
          if (n === null) throw badRequest(`${where} 的 updateInterval 必须是整数（单位：帧）`)
          if (n < 1) throw badRequest(`${where} 的 updateInterval 必须 ≥1（单位：帧，60 帧 = 1 秒）`)
          if (n > MAX_INTERVAL_FRAMES) throw badRequest(`${where} 的 updateInterval 不能超过 ${MAX_INTERVAL_FRAMES} 帧`)
        }
      })
    }
  }

  if (raw.panelSpacers !== undefined && raw.panelSpacers !== null) {
    if (!isPlainObject(raw.panelSpacers)) throw badRequest('panelSpacers 必须是对象（面板名 → 空格数）')
    for (const [name, value] of Object.entries(raw.panelSpacers)) {
      const n = toInt(value)
      if (n === null) throw badRequest(`panelSpacers["${name}"] 必须是整数`)
      if (n < 0 || n > MAX_SPACER_WIDTH) {
        throw badRequest(`panelSpacers["${name}"] 必须在 0~${MAX_SPACER_WIDTH} 之间（收到 ${n}）`)
      }
    }
  }

  if (raw.statusTextSettings !== undefined && raw.statusTextSettings !== null && !Array.isArray(raw.statusTextSettings)) {
    throw badRequest('statusTextSettings（v1 旧字段）必须是数组')
  }

  return raw
}

/** 模板里出现的、不属于 26 个已知占位符的 token（原样显示的那些） */
export function unknownPlaceholders(text) {
  const out = []
  const re = new RegExp(INTERPOLATION_REGEX.source, 'g')
  let m
  while ((m = re.exec(String(text == null ? '' : text))) !== null) {
    const token = m[0]
    if (token.length >= 2 && token[1] === '{') continue // {{…}} 是转义，不是占位符
    if (!PLACEHOLDER_TOKENS.includes(token) && !out.includes(token)) out.push(token)
  }
  return out
}

/** 模板里出现的转义写法 `{{…}}`（会被输出成字面量 `{…}`） */
export function escapedTokens(text) {
  const out = []
  const re = new RegExp(INTERPOLATION_REGEX.source, 'g')
  let m
  while ((m = re.exec(String(text == null ? '' : text))) !== null) {
    const token = m[0]
    if (token.length >= 2 && token[1] === '{') out.push(token)
  }
  return out
}

/**
 * 生效性警告（配置本身合法，但按现在的值跑起来会与直觉不同）。
 * 全部条目都带上"为什么"和"怎么办"，界面直接显示，不写进日志就算完。
 */
export function configWarnings(config) {
  const cfg = normalizeConfig(config)
  const out = []
  const push = (level, message) => out.push({ level, message })

  if (!cfg.enabled) {
    push('info', '总开关未启用：游戏服不会向任何玩家推送面板文本（/st 也看不到内容）')
  }
  if (cfg.spacerWidth === 0) {
    push('info', '全局行尾空格为 0：文本块不会被撑宽，客户端固定锚点下会明显偏左，可能被裁切')
  }
  if (cfg.logLevel === 'NONE') {
    push('info', '日志等级 NONE：游戏服端本插件的全部日志都会静默（排障时建议改回 INFO）')
  }

  for (const [name, rows] of Object.entries(cfg.panels)) {
    if (rows.length === 0) {
      push('warn', `面板「${name}」没有任何行：渲染结果为空，服端会**清空**玩家屏幕上的面板文本`)
      continue
    }
    if (rows.length > MAX_ROWS_PER_PANEL) {
      push(
        'warn',
        `面板「${name}」配置了 ${rows.length} 行，游戏服只渲染前 ${MAX_ROWS_PER_PANEL} 行`
        + `（其余不会显示，也不会发到客户端）；建议拆成多个面板，用 /st 面板名 切换`,
      )
    }
    rows.forEach((row, idx) => {
      const where = `面板「${name}」第 ${idx + 1} 行`
      if (!ROW_TYPES.includes(row.typeName)) {
        push('warn', `${where} 的 typeName="${row.typeName}" 不是 ${ROW_TYPES.join('/')}，该行**不会被渲染**（仅往返透传）`)
      }
      for (const token of unknownPlaceholders(row.text)) {
        push('info', `${where} 里的 ${token} 不是已知占位符，会原样显示`)
      }
      for (const token of escapedTokens(row.text)) {
        push('info', `${where} 里的 ${token} 会显示为字面量 ${token.slice(1, -1)}`)
      }
    })
  }

  for (const name of Object.keys(cfg.panelSpacers)) {
    if (!Object.prototype.hasOwnProperty.call(cfg.panels, name)) {
      push('info', `panelSpacers 里的「${name}」没有对应的面板，该设置当前不起作用`)
    }
  }

  return out
}

/**
 * 规范化视图（probe 与"配置有没有真的变"的判据都基于它）：
 * 面板名排序、行字段按 ROW_KEYS 顺序、panelSpacers 排序 —— 于是 JSON.stringify 的结果与
 * 对象的书写顺序无关，可以逐字节比较。
 */
export function canonicalConfig(config) {
  const cfg = normalizeConfig(config)
  const panels = {}
  for (const name of Object.keys(cfg.panels).sort()) {
    panels[name] = cfg.panels[name].map((row) => {
      const out = {}
      for (const key of ROW_KEYS) {
        if (Object.prototype.hasOwnProperty.call(row, key)) out[key] = row[key]
      }
      for (const key of Object.keys(row).sort()) {
        if (Object.prototype.hasOwnProperty.call(out, key)) continue
        out[key] = row[key]
      }
      return out
    })
  }
  const spacers = {}
  for (const name of Object.keys(cfg.panelSpacers).sort()) spacers[name] = cfg.panelSpacers[name]
  return { enabled: cfg.enabled, spacerWidth: cfg.spacerWidth, logLevel: cfg.logLevel, panels, panelSpacers: spacers }
}

/** 规范化 JSON（逐字节比较用） */
export function canonicalJson(config) {
  return JSON.stringify(canonicalConfig(config))
}

/** 哪些顶层字段真的变了（保存响应里给前端看，避免"看起来保存了其实没变"） */
export function changedKeys(before, after) {
  const a = canonicalConfig(before)
  const b = canonicalConfig(after)
  return ['enabled', 'spacerWidth', 'logLevel', 'panels', 'panelSpacers'].filter(
    (key) => JSON.stringify(a[key]) !== JSON.stringify(b[key]),
  )
}

/**
 * 组装下发给游戏服的 query 载荷（宿主 gameOps.pushConfig 用）。
 * 参数名与游戏服半 StatusPanelEndpoints.Snapshot 逐个对应；对象值 JSON 字符串化
 * （与旧版 tshockService.setStatusPanelConfig 的做法一致：backend/services/tshockService.js:1951-1955）。
 */
export function toGamePayload(config, { version, allOnlineCount = -1, ts = '' } = {}) {
  const cfg = normalizeConfig(config)
  const panelsJson = JSON.stringify(cfg.panels)
  if (panelsJson.length > MAX_PAYLOAD_CHARS) {
    throw badRequest(
      `panels 序列化后 ${panelsJson.length} 字符，超过单次下发上限 ${MAX_PAYLOAD_CHARS}：`
      + '请减少面板/行数或缩短行文本（TShock 的 REST 走 GET query，过长会被 HTTP 层拒绝）',
    )
  }

  const v = toInt(version)
  if (v === null || v <= 0) throw badRequest(`version 必须是正整数（收到 ${JSON.stringify(version)}）`)

  const online = toInt(allOnlineCount)
  return {
    version: String(v),
    enabled: cfg.enabled ? 'true' : 'false',
    spacerWidth: String(cfg.spacerWidth),
    logLevel: cfg.logLevel,
    panels: panelsJson,
    panelSpacers: JSON.stringify(cfg.panelSpacers),
    // <0 表示"宿主还不知道全服在线数"→ 服端会保持当前值（而不是显示 0）
    allOnlineCount: String(online === null ? -1 : online),
    ts: String(ts || new Date().toISOString()),
  }
}

/** 旧式端点（/data/statuspanel/config/set）的载荷：只有旧版认得的那些 query 参数 */
export function toLegacyPayload(config) {
  const cfg = normalizeConfig(config)
  return {
    enabled: cfg.enabled ? 'true' : 'false',
    spacerWidth: String(cfg.spacerWidth),
    logLevel: cfg.logLevel,
    panels: JSON.stringify(cfg.panels),
    panelSpacers: JSON.stringify(cfg.panelSpacers),
  }
}

/** 读配置存储文件；文件不存在/损坏 → 空存储 + 原因（**绝不抛错**，损坏不该让插件起不来） */
export async function loadStore(file, fsApi) {
  try {
    const raw = await fsApi.readFile(file, 'utf8')
    const parsed = JSON.parse(raw)
    if (!isPlainObject(parsed)) return { store: emptyStore(), error: `配置文件不是对象：${file}` }
    const servers = {}
    for (const [id, cfg] of Object.entries(isPlainObject(parsed.servers) ? parsed.servers : {})) {
      servers[String(id)] = normalizeConfig(cfg)
    }
    return {
      store: { version: toInt(parsed.version) || 1, updatedAt: String(parsed.updatedAt || ''), servers },
      error: '',
    }
  } catch (err) {
    if (err.code === 'ENOENT') return { store: emptyStore(), error: '' }
    return { store: emptyStore(), error: `读取配置失败：${err.message}` }
  }
}

/** 保存配置存储文件（原子写：先写 .tmp 再改名） */
export async function saveStore(file, store, fsApi) {
  const payload = JSON.stringify(
    { version: 1, updatedAt: new Date().toISOString(), servers: store.servers },
    null,
    2,
  )
  const tmp = `${file}.tmp`
  await fsApi.mkdir(fsApi.dirname(file), { recursive: true })
  await fsApi.writeFile(tmp, payload, 'utf8')
  await fsApi.rename(tmp, file)
  return true
}
