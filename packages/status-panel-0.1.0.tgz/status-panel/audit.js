/**
 * 本件审计流水（<dataDir>/status-panel/audit.jsonl，追加写）
 *
 * 事件名：
 *   status-panel.config.set      管理页/终端改了某台服的配置（谁、什么时候、改了哪些字段、下发结果）
 *   status-panel.config.import   把游戏服端**当前生效的配置**导入成宿主配置（旧版用户升级上来的迁移入口）
 *   status-panel.push.manual     手动重推（排障动作，记下推给了哪些服、成败如何）
 *
 * 为什么只需要这几种：
 *   面板的渲染与发包**完全发生在游戏服侧**（每个玩家每 tick 都在发生），宿主拿不到逐次事件，
 *   也没有必要记 —— 那是高频数据，写审计只会把有用的记录淹掉。宿主能也应当审计的是
 *   "谁在什么时候把配置改成了什么、有没有真的下发成功"。
 *
 * 写法上刻意保持极简（JSONL 追加 + 单文件上限轮转），并按插件各存一份：
 * 不依赖其它插件的模块，也不共享文件。
 */
import { appendFile, mkdir, readFile, stat, rename } from 'node:fs/promises'
import path from 'node:path'

/** 单文件上限（超过则轮转为 audit.jsonl.1），避免无限增长 */
const MAX_BYTES = 8 * 1024 * 1024

/** 本件的审计动作名（唯一权威定义，测试与文档都引这里） */
export const ACTIONS = {
  /** 配置变更（对齐旧版 config.statuspanel.set 的语义） */
  configSet: 'status-panel.config.set',
  /** 从游戏服端导入现有配置（旧版用户迁移入口） */
  configImport: 'status-panel.config.import',
  /** 手动重推（排障） */
  manualPush: 'status-panel.push.manual',
}

export class AuditLog {
  constructor({ file }) {
    if (!file) throw new Error('AuditLog 需要 file 路径')
    this.file = file
    this.dir = path.dirname(file)
  }

  /**
   * 追加一条审计。
   * @param {string} action 见 ACTIONS
   * @param {object} entry  { actor, ...detail }
   */
  async append(action, entry = {}) {
    const line = JSON.stringify({
      t: new Date().toISOString(),
      action: String(action),
      actor: entry.actor != null ? String(entry.actor) : '',
      ...entry,
    }) + '\n'
    await mkdir(this.dir, { recursive: true })
    await this._rotateIfNeeded()
    await appendFile(this.file, line, 'utf8')
    return true
  }

  async _rotateIfNeeded() {
    try {
      const st = await stat(this.file)
      if (st.size >= MAX_BYTES) await rename(this.file, `${this.file}.1`)
    } catch (err) {
      if (err.code !== 'ENOENT') throw err
    }
  }

  /** 读取最近 n 条（新的在前）；文件不存在返回空数组，坏行降级为 parse-error 行 */
  async tail(limit = 100) {
    const n = Math.min(Math.max(1, Number(limit) || 100), 1000)
    let raw
    try {
      raw = await readFile(this.file, 'utf8')
    } catch (err) {
      if (err.code === 'ENOENT') return []
      throw err
    }
    const lines = raw.split('\n').filter((l) => l.trim() !== '')
    const out = []
    for (let i = lines.length - 1; i >= 0 && out.length < n; i--) {
      try {
        out.push(JSON.parse(lines[i]))
      } catch {
        out.push({ t: null, action: 'parse-error', raw: lines[i].slice(0, 200) })
      }
    }
    return out
  }
}
