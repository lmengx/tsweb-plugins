/**
 * 游戏服调用层（宿主 → TShock）
 *
 * 本件用自己的端点前缀 `/data/statuspanel/*`（与旧版一致：旧版就是
 * `SecureRestCommand("/data/statuspanel/config", …, "data.rest.invsee")`，见 TsWeb/plugin/Main.cs:179-182）。
 * 前缀的既有先例：plugins/online-stats/index.js 的 `/data/online`、plugins/promotion 的 `/data/promotion`。
 *
 * 传输契约：**GET + query 参数**。理由与既有插件一致：
 *   TShock 的 SecureRestCommand 语义是"带 token 的 GET"，插件侧只读 args.Parameters；
 *   "form body 是否被解析进 Parameters"在本项目没有先例可证，赌它会解析等于把失败做成静默。
 *   对象值（panels / panelSpacers）JSON 字符串化后放进 query —— 旧版后端也是这么干的
 *   （backend/services/tshockService.js:1951-1955）。
 *
 * 错误语义照 online-stats / qq-bind / promotion 的既有约定，保证"服务器半缺失"在各插件里表现一致：
 *   404      → 501 + serverHalfMissing=true（目标服没装 TsWebStatusPanel.dll）
 *   401/403  → 502（token 缺 data.rest.invsee 权限）
 *   400      → 400 + 服端原文（参数被服端拒绝，不要让管理员只看到"游戏服返回异常"）
 *   网络/超时 → 502
 *
 * 要点：旧版最大的缺陷在这里被根治：旧版的 /tsweb/statuspanel 无论验签成功与否**恒回 HTTP 200**
 *   （TsWeb/plugin/WebRestServer.cs:325），后端只看 res.ok（backend/services/statusPanelService.js:63-68），
 *   于是"验签失败/类型不符/异常"全被当成推送成功 —— 表现为 {AllOnlineCount} 恒显示 — 而两端日志都不报错。
 *   本件把每一次下发的真实结果（HTTP 状态、服端回包里的 applied/stale/saveError）**逐服记录下来**，
 *   经 /api/status-panel/status 回给界面，并用 probe 与服端实际生效的配置逐字段比对。
 */
import { httpError } from './config.js'

/** 游戏服半的端点前缀 */
export const SERVER_HALF_PREFIX = '/data/statuspanel'

/**
 * 游戏服半的 DLL 名（报错文案用）。
 * 刻意是 **TsWebStatusPanel.dll** 而不是 StatusPanel.dll：旧版仓库存在前身插件
 * `plugin-son/statuspanel/statuspanel.dll`，Windows 文件名不区分大小写，同名会把它覆盖掉。
 */
export const DLL_NAME = 'TsWebStatusPanel.dll'

/** 本件端点的权限节点（与游戏服侧 SecureRestCommand 注册的权限一致） */
export const REST_PERMISSION = 'data.rest.invsee'

/** 本件自己的端点在 404 时只可能是"游戏服没装 TsWebStatusPanel.dll" */
const DEFAULT_MISSING = {
  status: 501,
  dllName: DLL_NAME,
  message: `游戏服端未安装 ${DLL_NAME}`,
  hint: '请在「插件下发」页对该服务器启用本插件',
}

export { httpError }

/**
 * 归一服端回包里的配置片段（读 /config 或 /status 时用）。
 * 服端可能因为版本较旧/字段不全而少给字段——这里只做**结构归一**，
 * 真正的语义归一由调用方走 config.js:normalizeConfig（那样"宿主配置 vs 服端配置"的比对才有共同基准）。
 */
function toConfigPayload(data) {
  const d = data && typeof data === 'object' ? data : {}
  return {
    enabled: d.enabled === true,
    spacerWidth: Number(d.spacerWidth),
    logLevel: d.logLevel === undefined || d.logLevel === null ? '' : String(d.logLevel),
    panels: d.panels && typeof d.panels === 'object' && !Array.isArray(d.panels) ? d.panels : {},
    panelSpacers: d.panelSpacers && typeof d.panelSpacers === 'object' && !Array.isArray(d.panelSpacers) ? d.panelSpacers : {},
  }
}

function toRuntime(data) {
  const d = data && typeof data === 'object' ? data : {}
  const r = d.runtime && typeof d.runtime === 'object' ? d.runtime : {}
  return {
    initialized: r.initialized === true,
    enabled: r.enabled === true,
    allOnlineCount: Number.isFinite(Number(r.allOnlineCount)) ? Number(r.allOnlineCount) : -1,
    allOnlineDisplay: String(r.allOnlineDisplay || ''),
    localOnlineCount: Number(r.localOnlineCount || 0),
    activePlayers: Number(r.activePlayers || 0),
    playersWithPanelOn: Number(r.playersWithPanelOn || 0),
    playersWithTextOnScreen: Number(r.playersWithTextOnScreen || 0),
    maxRowsPerPanel: Number(r.maxRowsPerPanel || 0),
    placeholderCount: Number(r.placeholderCount || 0),
    panels: r.panels && typeof r.panels === 'object' ? r.panels : {},
    packet: String(r.packet || ''),
    trigger: String(r.trigger || ''),
  }
}

/**
 * 取一个**软依赖**服务（拿不到就返回 null，绝不抛）。
 *
 * 两级取法（照搬 plugins/promotion/seed.js:89-104、plugins/legacy-import/modules/registry.js 的已验证做法）：
 *   1. `ctx.get(name)`：服务由 Service 子类注册（super(ctx, 'name')）时命中；未注册时返回 undefined。
 *      本件要取的 onlineStats 正是这种形态（plugins/online-stats/index.js:65-67 的
 *      `class OnlineStatsService extends Service` + `super(ctx, 'onlineStats')`）。
 *   2. `ctx[name]`：包在 try 里读；未 inject 的 ctx 代理在这里抛错，按"没有该服务"处理。
 *
 * 要点：为什么必须走这里而不能写成 `ctx.onlineStats?.x`：未 inject 的服务是"属性访问即抛错"
 *   （docs/插件开发约定.md §2.3，可选链挡不住），本仓已因此出过一次线上故障。
 *   本件把 onlineStats 明确列为**软依赖**（它可能没装）：没装时全服在线数显示为 —（与旧版
 *   "后端没下发"时的表现一致），其余功能完全不受影响。
 */
export function optionalService(ctx, name) {
  try {
    if (ctx && typeof ctx.get === 'function') {
      const svc = ctx.get(name)
      if (svc) return svc
    }
  } catch {
    /* 取不到就当没有：软依赖失败一律降级，绝不冒泡成"插件加载失败" */
  }
  try {
    return (ctx && ctx[name]) || null
  } catch {
    /* 未 inject 的 ctx 代理在这里抛错：按"没有该服务"处理 */
    return null
  }
}

export function createGameOps({ ctx }) {
  const log = (...args) => {
    try {
      console.log('[status-panel]', ...args)
    } catch {
      /* 忽略 */
    }
  }

  /** 启用中的服务器（拉原始记录，含 token，转发要用） */
  async function enabledServers() {
    const list = await ctx.servers.list()
    const out = []
    for (const s of list) {
      if (s.enabled === false) continue
      const raw = ctx.servers.getRaw(s.id)
      if (raw) out.push(raw)
    }
    return out
  }

  function rawOf(serverId) {
    return ctx.servers.getRaw(String(serverId)) || null
  }

  /** 统一把 fetchFor 的结果翻成数据或抛错 */
  function unwrap(server, result, label, missing = DEFAULT_MISSING) {
    if (result.ok) return result.data || {}
    if (result.status === 404) {
      throw httpError(501, `${missing.message}（${label} 返回 404）：${missing.hint}`, {
        serverHalfMissing: true,
        serverId: server.id,
        missingDll: missing.dllName,
      })
    }
    if (result.status === 401 || result.status === 403) {
      throw httpError(502, `游戏服 token 权限不足（HTTP ${result.status}）：需要 ${REST_PERMISSION} 权限`, {
        serverId: server.id,
      })
    }
    if (result.status === 400) {
      const detail = result.data && result.data.error ? result.data.error : '参数被游戏服拒绝'
      throw httpError(400, `游戏服拒绝该请求：${detail}`, { serverId: server.id })
    }
    const detail = result.data && result.data.error ? `：${result.data.error}` : ''
    throw httpError(502, `游戏服返回异常（HTTP ${result.status}）${detail}`, { serverId: server.id })
  }

  /** 发一次 GET 到游戏服（绝对路径由 absolute 控制） */
  async function callGet(server, suffix, params = {}) {
    const full = `${SERVER_HALF_PREFIX}${suffix}`
    let result
    try {
      result = await ctx.tshock.fetchFor(server, full, params)
    } catch (err) {
      throw httpError(502, `连接游戏服失败：${err.message}`, { serverId: server.id })
    }
    return unwrap(server, result, `GET ${full}`)
  }

  return {
    enabledServers,
    rawOf,

    /** 下发整份配置（版本化；服端会拒绝更旧的 version） */
    async pushConfig(server, payload) {
      const data = await callGet(server, '/snapshot', payload)
      return {
        applied: data.applied === true,
        stale: data.stale === true,
        version: Number(data.version || 0),
        updatedAt: String(data.updatedAt || ''),
        source: String(data.source || ''),
        saveError: String(data.saveError || ''),
        localEdits: Number(data.localEdits || 0),
        notes: Array.isArray(data.notes) ? data.notes.map(String) : [],
        status: data.status && typeof data.status === 'object' ? toRuntime({ runtime: data.status }) : null,
        config: toConfigPayload(data),
      }
    },

    /** 下发全服在线数（无版本、轻量；服端只更新内存里的一个整数） */
    async pushOnline(server, { total, ts = '' } = {}) {
      const data = await callGet(server, '/online', { total: String(total), ts: String(ts) })
      return {
        applied: data.applied === true,
        allOnlineCount: Number(data.allOnlineCount),
        allOnlineDisplay: String(data.allOnlineDisplay || ''),
        localOnlineCount: Number(data.localOnlineCount || 0),
        updatedAt: String(data.updatedAt || ''),
      }
    },

    /**
     * 旧式端点下发（等价旧版 `POST /data/statuspanel/config/set` 的能力）。
     * 语义差异（刻意保留并在界面上说明）：**没有版本号、服端不做 stale 判定、失败无法自愈**，
     * 纯粹用于"旧接口还能用"的兼容验证与排障。
     */
    async pushLegacyConfig(server, payload) {
      const data = await callGet(server, '/config/set', payload)
      return {
        response: String(data.response || ''),
        version: Number(data.version || 0),
        localEdits: Number(data.localEdits || 0),
        saveError: String(data.saveError || ''),
        notes: Array.isArray(data.notes) ? data.notes.map(String) : [],
      }
    },

    /** 读服端旧格式配置（等价旧版 `GET /data/statuspanel/config`） */
    async fetchConfig(server) {
      const data = await callGet(server, '/config', {})
      return {
        config: toConfigPayload(data),
        version: Number(data.version || 0),
        source: String(data.source || ''),
        localEdits: Number(data.localEdits || 0),
      }
    },

    /**
     * 探测某台服的**实际状态**：/status（运行期自证） + /config（旧格式配置）。
     * 为什么要两个端点都问：
     *   /status 给出"服端在跑什么"（版本、来源、落盘错误、渲染统计、服端收到的全服在线数），
     *   /config 给出"按旧版格式读回来的配置"（这正是旧版后端看到的那份视图），
     *   两者一起才能回答"界面写的 / 宿主以为的 / 服端真的在跑的"这三个是不是同一件事。
     */
    async probe(server) {
      const status = await callGet(server, '/status', {})
      const cfg = await callGet(server, '/config', {})
      return {
        version: Number(status.version || 0),
        updatedAt: String(status.updatedAt || ''),
        source: String(status.source || ''),
        file: String(status.file || ''),
        legacyFile: String(status.legacyFile || ''),
        saveError: String(status.saveError || ''),
        localEdits: Number(status.localEdits || 0),
        notes: Array.isArray(status.notes) ? status.notes.map(String) : [],
        config: toConfigPayload(cfg),
        configVersion: Number(cfg.version || 0),
        configSource: String(cfg.source || ''),
        runtime: toRuntime(status),
      }
    },

    log,
  }
}
