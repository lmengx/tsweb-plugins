/**
 * status-panel 前端半 —— 管理页「状态面板」（后端设置 → /b/status-panel）
 *
 * 界面照旧版 TsWeb 的 frontend/src/views/console/settings/StatusPanelSettingsView.vue（913 行）做：
 * **三块卡片 + 右侧彩虹字设计器**，文案与交互逐条对齐，只是从 Vue 换成本仓客户端插件的原生写法：
 *   1. 「状态面板」总览卡  启用开关 + 行尾空格宽度（− / 数字 / +）+ 日志等级下拉
 *   2. 「面板内容」卡      左侧面板标签条 + 每行一张卡片（拖拽把手 ⠿ / 序号 / 更新间隔 / ↑↓× / 文本域 /
 *                          插值 chips），右侧「预览」+ 彩虹字设计器（GradientText 的等价实现）
 *   3. 「下发状态」卡      逐服下发结果 + 全服在线数 + 探测（宿主实际配置 vs 服端实际配置）
 *
 * 与旧版界面的**必要差异**（都是新架构/缺陷修复带来的，交付报告已逐条列出）：
 *   1. **多了目标服务器选择器**。旧版靠前端全局的「当前服务器」（localStorage.tsweb.currentServerId，
 *      由 utils/api.js:20-34 自动加 x-server-id 头）隐式决定改哪台服；本插件把"按服务器独立配置"
 *      显式化：下拉列出宿主里登记的所有服务器，选中哪台就改哪台（请求带 x-server-id）。
 *   2. **token 清单是 26 个**（旧版界面只展示 25 个，`{RealWorldTime}` 被刻意隐藏，
 *      StatusPanelSettingsView.vue:35 注释原文：「与 {SystemTime} 相同……仅保留代码兼容，不再展示」）。
 *      本件把它显示出来并标注"与 {SystemTime} 相同"，避免管理员在游戏里看到 — 却查不到出处。
 *   3. 模板行的「恢复默认模板」会二次确认；旧版无确认直接覆盖整面板（旧版缺陷 M）。
 *   4. **保存结果按"宿主真的下发成功"判定**，而不是旧版那种 `data.status === '200' || data.response`
 *      的弱判定（旧版缺陷 C：插件把 status 序列化成数字，字符串比较形同虚设）。
 *
 * 依赖宿主能力（window.tsweb，由 web 插件提供）：
 *   - window.tsweb.registerView({ id, title, section, path, render })
 *   - window.tsweb.api(path, opts)   带 Bearer 的统一请求：{ ok, status, data }
 *   - window.tsweb.getServerId()     当前选中的服务器（首选项，缺省目标服）
 *
 * 约定：禁止 emoji（界面里的 − × ↑ ↓ · ⠿ 是排版符号，与旧版一致）；不引入第三方 UI 库；
 * 图标用内联 SVG；局部类名统一 sp- 前缀。
 * 本文件是 **ESM 模块**（宿主用 import(url) 加载），同时把纯函数具名导出，
 * 供 test/client-ui.test.mjs 在 Node 里做无浏览器验证。
 */

// ════════════════════════════════════════════
//  常量（与游戏服半 / 宿主半同源；test/panel-source.test.mjs 会断言三处一致）
// ════════════════════════════════════════════

/** 日志等级（旧版 StatusPanelSettingsView.vue:60 逐字） */
export const LOG_LEVELS = ['NONE', 'ERROR', 'WARNING', 'INFO', 'DEBUG']

/** 面板保留字：与 /st on|off|show|hide 冲突（旧版 :48） */
export const RESERVED_NAMES = ['on', 'off', 'show', 'hide']

/** 行尾空格上限（旧版输入框 max=500，服端也夹到 500） */
export const MAX_SPACER_WIDTH = 500

/** 游戏服实际渲染的行数上限（与 StatusPanelRenderer.MaxRowsPerPanel 一致） */
export const MAX_ROWS_PER_PANEL = 20

/**
 * 更新间隔的界面范围（单位：帧，60 帧 = 1 秒）。
 * 上限取 **1,000,000**，与游戏服半 `StatusPanelDefaults.MaxIntervalFrames`
 * 和宿主 `config.js:MAX_INTERVAL_FRAMES` **完全一致**。
 *
 * 为什么不是旧界面的 6000：旧版那个 `max="6000"` 只是 input 的 HTML 提示属性，
 * 旧版 JS 保存时**不夹上限**（`Number(v) >= 1 ? v : 60`）、服端也不夹，
 * 所以旧配置里完全可能存在 18000 这类值（例如 5 分钟轮换一次的提示行）。
 * 如果本件在加载归一阶段按 6000 夹紧，就会在管理员下次任意保存时把它**静默改写成 6000**
 * —— 那正是旧版缺陷 D/E 同一类"静默改写用户配置"的问题，因此这里对齐到真正的语义上限。
 */
export const INTERVAL_UI_MAX = 1000000

/**
 * 更新间隔的界面上限的**下限**（单位：帧）。
 *
 * 取 1：与服端/宿主语义一致 —— 归一时 `updateInterval` 小于 1 一律按 1 处理
 * （旧版 `plugin/StatusPanel.cs` 的 `<1 按 1`，本件 `clampInterval` 同）。
 * 它只用于渲染 `rowHtml` 里那个 number input 的 `min=`，不参与保存归一。
 *
 * 这个常量曾经被漏定义（`rowHtml` 引用它但全仓无定义）：后果是**渲染任意一行卡片时抛
 * ReferenceError**，整张「面板内容」卡渲染失败并冒泡到 render 的 catch，玩家看到的是空卡片。
 * 之所以没被测试发现，是因为 `rowHtml` 是未导出的嵌套函数，而当时的用例只覆盖导出的纯函数、
 * 没有走渲染路径。补上定义的同时已加渲染路径的回归断言（见 `test/panel-render.test.mjs`）。
 */
export const INTERVAL_UI_MIN = 1

/**
 * 插值正则：与游戏服半逐字同源（旧版 plugin/StatusPanel.cs:105
 * `(?:{{[^{\s]*?}}|{[^{\s]*?})`）。语义：`{{abc}}` → 字面量 `{abc}`；`{ x }` 不匹配；未知 `{x}` 原样保留。
 */
export const INTERPOLATION_REGEX = /(?:{{[^{\s]*?}}|{[^{\s]*?})/g

/**
 * 插值字典（26 条）：token + 中文标签 + 预览示例值 + 分组。
 * 前 25 条与旧版 StatusPanelSettingsView.vue:9-34 逐字一致（分组、顺序、label、preview 全部照抄）；
 * 第 26 条 `{RealWorldTime}` 是旧版"代码支持但界面不展示"的那个（见文件头差异 2）。
 */
export const INTERPOLATIONS = [
  { group: '玩家', token: '{PlayerName}', label: '玩家名称', preview: 'Steve' },
  { group: '玩家', token: '{PlayerGroupName}', label: '所在组', preview: 'guest' },
  { group: '玩家', token: '{PlayerLife}', label: '生命值', preview: '500' },
  { group: '玩家', token: '{PlayerMana}', label: '魔力值', preview: '200' },
  { group: '玩家', token: '{PlayerLifeMax}', label: '最大生命', preview: '500' },
  { group: '玩家', token: '{PlayerManaMax}', label: '最大魔力', preview: '200' },
  { group: '玩家', token: '{PlayerLuck}', label: '幸运值', preview: '0.1' },
  { group: '玩家', token: '{PlayerCoordinateX}', label: 'X 坐标', preview: '200' },
  { group: '玩家', token: '{PlayerCoordinateY}', label: 'Y 坐标', preview: '300' },
  { group: '玩家', token: '{PlayerCurrentRegion}', label: '所在区域', preview: '主城' },
  { group: '玩家', token: '{IsPlayerAlive}', label: '存活状态', preview: '存活' },
  { group: '玩家', token: '{RespawnTimer}', label: '重生倒计时', preview: '5' },
  { group: '玩家', token: '{CurrentBiomes}', label: '当前群系', preview: '[c/008000:森林]' },
  { group: '服务器', token: '{OnlinePlayersCount}', label: '本服在线数', preview: '12' },
  { group: '服务器', token: '{OnlinePlayersList}', label: '本服在线列表', preview: 'A,B,C' },
  { group: '服务器', token: '{WorldName}', label: '世界名称', preview: '开荒服世界' },
  { group: '服务器', token: '{CurrentTime}', label: '游戏内时间', preview: '12:00' },
  { group: '渔夫任务', token: '{AnglerQuestFishName}', label: '任务鱼名称', preview: '金鲤' },
  { group: '渔夫任务', token: '{AnglerQuestFishID}', label: '任务鱼 ID', preview: '2611' },
  { group: '渔夫任务', token: '{AnglerQuestFishingBiome}', label: '钓鱼点', preview: '丛林' },
  { group: '渔夫任务', token: '{AnglerQuestCompleted}', label: '任务完成状态', preview: '未完成' },
  { group: '全服', token: '{AllOnlineCount}', label: '全服在线数', preview: '36' },
  { group: '时间', token: '{SystemTime}', label: '系统时间（服务器）', preview: '14:30' },
  { group: 'BOSS进度', token: '{CurrentBossName}', label: '当前进度BOSS名', preview: '史莱姆王' },
  { group: 'BOSS进度', token: '{CurrentBossSpawnItemId}', label: '当前进度BOSS召唤物ID', preview: '560' },
  // 旧版刻意不展示的那一个（注释原文见 StatusPanelSettingsView.vue:35）；本件显示出来并标注
  { group: '时间', token: '{RealWorldTime}', label: '系统时间（与 {SystemTime} 相同）', preview: '14:30' },
]

/** 分组顺序（旧版 :38） */
export const INTERPOLATION_GROUPS = ['玩家', '服务器', '渔夫任务', '全服', '时间', 'BOSS进度']

/** 「全部」分组的显示名（旧版模板里前置的那一项） */
export const ALL_GROUP = '全部'

/**
 * 默认模板 4 行 —— 与游戏服半 StatusPanelDefaults.Template()（旧版 StatusPanel.cs:63-75）、
 * 宿主 config.js:defaultPanelRows() 三处逐字一致。
 * 要点：旧版这里是**第三份**手工同步的副本（旧版缺陷 X）；本件的**权威来源是宿主**
 *   （GET /api/status-panel/config 的 defaults.rows 与 GET /api/status-panel/defaults），
 *   这份常量只作为"界面还没拿到宿主默认值"时的兜底，并且由测试断言三者一致。
 */
export const DEFAULT_ROWS = () => [
  { typeName: 'DynamicText', text: '[i:757][c/f15642:开荒服]', updateInterval: 600 },
  { typeName: 'DynamicText', text: '在线人数：{OnlinePlayersCount}人', updateInterval: 60 },
  { typeName: 'DynamicText', text: '全服在线：{AllOnlineCount}人', updateInterval: 60 },
  { typeName: 'DynamicText', text: '系统时间：{SystemTime}', updateInterval: 60 },
]

/** 新增一行的初值（旧版 :165 的 `{ text:'', updateInterval:60 }`；typeName 补成 DynamicText，与服端可渲染类型一致） */
export const NEW_ROW = () => ({ typeName: 'DynamicText', text: '', updateInterval: 60 })

/** 自动保存去抖（旧版 :102-103 是 500ms） */
export const SAVE_DEBOUNCE_MS = 500

// ════════════════════════════════════════════
//  纯函数：配置归一与展示（无 DOM 依赖，可在 Node 里直接测）
// ════════════════════════════════════════════

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v)
}

/**
 * 界面侧配置归一（与宿主 config.js:normalizeConfig 同口径的**精简版**）。
 * 为什么界面也要归一：旧版直接 `spacerWidth.value = data.spacerWidth`（旧版缺陷 S），
 * 服端/宿主返回字符串或越界值时，界面上会出现 `9999` 而服端实际是 500，
 * 于是"界面数字"与"实际生效数字"长期不一致（旧版缺陷 F/Z）。这里统一在入口夹紧，
 * 让界面**只能显示合法值**；真正的权威仍然是宿主与服端。
 */
export function normalizeConfig(raw) {
  const src = isPlainObject(raw) ? raw : {}
  const panels = {}
  const rawPanels = isPlainObject(src.panels) ? src.panels : {}
  for (const [name, rows] of Object.entries(rawPanels)) {
    panels[String(name)] = (Array.isArray(rows) ? rows : [])
      .filter((r) => isPlainObject(r))
      .map((r) => {
        const out = { ...r }
        out.typeName = r.typeName === undefined || r.typeName === null ? '' : String(r.typeName)
        out.text = r.text === undefined || r.text === null ? '' : String(r.text)
        out.updateInterval = clampInterval(r.updateInterval)
        return out
      })
  }
  if (!Object.prototype.hasOwnProperty.call(panels, 'default')) panels.default = DEFAULT_ROWS()

  const panelSpacers = {}
  if (isPlainObject(src.panelSpacers)) {
    for (const [name, v] of Object.entries(src.panelSpacers)) {
      const n = Number(v)
      if (!Number.isFinite(n) || n < 0) continue
      panelSpacers[String(name)] = Math.min(MAX_SPACER_WIDTH, Math.round(n))
    }
  }

  const spacerRaw = Number(src.spacerWidth)
  const spacerWidth = src.spacerWidth === undefined || src.spacerWidth === null || !Number.isFinite(spacerRaw)
    ? 60
    : Math.min(MAX_SPACER_WIDTH, Math.max(0, Math.round(spacerRaw)))

  const logLevel = String(src.logLevel === undefined || src.logLevel === null ? '' : src.logLevel).trim().toUpperCase()

  return {
    // 旧版界面初值是 true（旧版缺陷 Y），本件严格以配置为准：读不到就是 false（与服端默认一致）
    enabled: src.enabled === true,
    spacerWidth,
    logLevel: LOG_LEVELS.includes(logLevel) ? logLevel : 'INFO',
    panels,
    panelSpacers,
  }
}

/** 更新间隔夹取：非数字/缺失 → 60；<1 → 1；>上限 → 上限（与服端 ParseInterval 与宿主一致） */
export function clampInterval(value) {
  if (value === undefined || value === null || value === '') return 60
  const n = Math.floor(Number(value))
  if (!Number.isFinite(n)) return 60
  if (n < 1) return 1
  return n > INTERVAL_UI_MAX ? INTERVAL_UI_MAX : n
}

/** 面板名列表：default 永远排最前，其余保持原顺序（旧版 :75-79） */
export function panelNamesOf(panels) {
  const names = Object.keys(isPlainObject(panels) ? panels : {})
  return ['default', ...names.filter((n) => n !== 'default')].filter((n, i, a) => a.indexOf(n) === i)
}

/** 某面板实际生效的行尾空格：面板覆盖优先，否则全局（旧版 :97） */
export function effectiveSpacer(panelName, config) {
  const cfg = isPlainObject(config) ? config : {}
  const override = isPlainObject(cfg.panelSpacers) ? cfg.panelSpacers[panelName] : undefined
  if (override !== undefined && override !== null) return Number(override)
  const g = Number(cfg.spacerWidth)
  return Number.isFinite(g) ? g : 0
}

/** 行尾空格占位点的个数（旧版 :415 的近似：5 个空格 = 1 个点，最多 12 个点） */
export function previewSpacerDots(spacer) {
  const n = Number(spacer)
  if (!Number.isFinite(n) || n <= 0) return 0
  return Math.max(0, Math.min(12, Math.floor(n / 5)))
}

/** −/+ 按钮的步进（旧版 ±5，夹在 0..500） */
export function stepSpacer(current, delta) {
  const n = Number(current)
  const base = Number.isFinite(n) ? n : 0
  return Math.min(MAX_SPACER_WIDTH, Math.max(0, Math.round(base + delta)))
}

/** 手输空格数归一：空串/非数字 → null（表示"清除覆盖"） */
export function clampSpacerInput(value) {
  if (value === '' || value === null || value === undefined) return null
  const n = Number(value)
  if (!Number.isFinite(n) || n < 0) return null
  return Math.min(MAX_SPACER_WIDTH, Math.round(n))
}

/**
 * 面板名校验（旧版 :141-151 + 两处修复）。
 * 返回错误文案（空串 = 通过）。修复点：
 *   1. 重名判断改为**大小写不敏感**：服端选面板用 OrdinalIgnoreCase（旧版 StatusPanel.cs:273），
 *      旧界面允许同时存在 `default` 与 `Default`，游戏里 `/st default` 只能命中一个（旧版缺陷 K）。
 *   2. 禁止名字里带空白：游戏内命令只取 args.Parameters[0]（旧版 StatusPanel.cs:398/426/432），
 *      含空格的面板名**永远无法切换**（旧版缺陷 L）。
 */
export function validatePanelName(name, panels) {
  const raw = String(name === undefined || name === null ? '' : name)
  const trimmed = raw.trim()
  if (trimmed === '') return '请输入面板名称'
  if (/\s/.test(trimmed)) return `「${trimmed}」不能包含空格：游戏内 /st <面板名> 只认第一个词，含空格的面板名无法切换`
  if (RESERVED_NAMES.includes(trimmed.toLowerCase())) {
    return `「${trimmed}」为命令保留字，不能用作面板名`
  }
  const lower = trimmed.toLowerCase()
  const exists = Object.keys(isPlainObject(panels) ? panels : {}).some((n) => n.toLowerCase() === lower)
  if (exists) return `面板「${trimmed}」已存在`
  return ''
}

/**
 * 预览用插值替换：**忠实模拟服端**的两条语义（旧版预览没做，旧版缺陷 Q）：
 *   1. `{{abc}}` 转义 → 输出字面量 `{abc}`（服端 StatusPanelPlaceholders 如此）
 *   2. 已知 token → 示例值；未知 token → **原样保留**（服端也原样保留）
 * 示例值里若含富文本（如 `[c/008000:森林]`），后续 parseRichText 会把它渲染成真颜色 —— 与旧版一致。
 */
export function interpolatePreview(text, map) {
  const table = isPlainObject(map) ? map : previewMap()
  const src = String(text === undefined || text === null ? '' : text)
  const re = new RegExp(INTERPOLATION_REGEX.source, 'g')
  return src.replace(re, (token) => {
    if (token.length >= 2 && token[1] === '{') return token.slice(1, -1) // {{x}} → {x}
    return Object.prototype.hasOwnProperty.call(table, token) ? table[token] : token
  })
}

/** token → 示例值（预览用） */
export function previewMap() {
  const map = {}
  for (const it of INTERPOLATIONS) map[it.token] = it.preview
  return map
}

/** 某个分组下的插值项（`全部` 返回全量） */
export function interpolationsOf(group) {
  if (!group || group === ALL_GROUP) return INTERPOLATIONS
  return INTERPOLATIONS.filter((it) => it.group === group)
}

/**
 * 富文本解析（**逐条对齐旧版 :368-405 的 parseRichText**）：
 *   [c/HEX:文字]    HEX 为 3 位或 6 位十六进制（3 位按字符双写展开）；非法 hex 当字面量
 *   [i:ID] / [i/sX:ID] / [i/pX:ID]    ID 必须是 >0 的整数，否则当字面量
 *   其它 [xxx]      一律当字面量
 * 返回片段数组：{type:'text',text} | {type:'color',color,text} | {type:'item',itemId}
 * 说明：这里**刻意不做** HTML 注入（颜色以 style 颜色值输出，文本由调用方用 textContent 写入）。
 */
export function parseRichText(text) {
  const src = String(text === undefined || text === null ? '' : text)
  const out = []
  const TAG_RE = /\[([^\]]*)\]/g
  TAG_RE.lastIndex = 0
  let last = 0
  let m
  while ((m = TAG_RE.exec(src)) !== null) {
    if (m.index > last) out.push({ type: 'text', text: src.slice(last, m.index) })
    const inner = m[1]
    let handled = false

    if (inner.startsWith('c/')) {
      const rest = inner.slice(2)
      const ci = rest.indexOf(':')
      if (ci > 0) {
        const hex = rest.slice(0, ci).trim()
        if (/^[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/.test(hex)) {
          const full = hex.length === 3 ? hex.split('').map((h) => h + h).join('') : hex
          out.push({ type: 'color', color: '#' + full.toLowerCase(), text: rest.slice(ci + 1) })
          handled = true
        }
      }
    } else if (inner.startsWith('i:') || inner.startsWith('i/s') || inner.startsWith('i/p')) {
      const rest = inner.slice(2).trim()
      const mm = rest.match(/^(?:s|p)\d*:(.*)$/)
      const raw = (mm ? mm[1] : rest).trim()
      const id = parseInt(raw, 10)
      if (!Number.isNaN(id) && id > 0) {
        out.push({ type: 'item', itemId: id })
        handled = true
      }
    }

    if (!handled) out.push({ type: 'text', text: m[0] })
    last = TAG_RE.lastIndex
  }
  if (last < src.length) out.push({ type: 'text', text: src.slice(last) })
  return out
}

/** 把解析结果拍平成"可直接显示"的纯文本（测试用；界面另有彩色渲染） */
export function richTextToPlain(segments) {
  return (Array.isArray(segments) ? segments : []).map((seg) => {
    if (seg.type === 'color') return seg.text
    if (seg.type === 'item') return `[物品 ${seg.itemId}]`
    return seg.text
  }).join('')
}

// ════════════════════════════════════════════
//  纯函数：彩虹字设计器（等价旧版 tools/GradientText.vue）
// ════════════════════════════════════════════

/**
 * 15 个渐变预设（**逐条照搬旧版 GradientText.vue:28-136 的颜色数组**）。
 * 注意：所有预设都只是"颜色数组"，共用同一套逐字符分段 RGB 线性插值算法（旧版也是如此）。
 */
export const GRADIENT_PRESETS = [
  { name: '彩虹', colors: [[255, 0, 0], [255, 165, 0], [255, 255, 0], [0, 255, 0], [0, 0, 255], [75, 0, 130], [148, 0, 211]] },
  { name: '热力', colors: [[0, 0, 255], [0, 255, 255], [0, 255, 0], [255, 255, 0], [255, 128, 0], [255, 0, 0]] },
  { name: '终端', colors: [[0, 0, 0], [0, 128, 0], [0, 255, 0]] },
  { name: '灰色渐变', colors: [[255, 255, 255], [200, 200, 200], [150, 150, 150], [100, 100, 100], [50, 50, 50], [0, 0, 0]] },
  { name: '组合', colors: [[255, 0, 128], [128, 0, 255], [0, 128, 255], [0, 255, 128], [128, 255, 0], [255, 128, 0]] },
  { name: '日落', colors: [[255, 81, 39], [255, 119, 69], [255, 179, 71], [255, 107, 149], [142, 84, 233]] },
  { name: '极光', colors: [[0, 242, 96], [100, 245, 168], [43, 210, 255], [123, 104, 238], [155, 89, 182]] },
  { name: '糖果', colors: [[255, 154, 158], [255, 195, 160], [255, 245, 195], [212, 252, 121], [161, 196, 253]] },
  { name: '火焰', colors: [[255, 0, 0], [255, 69, 0], [255, 140, 0], [255, 165, 0], [255, 215, 0]] },
  { name: '海洋', colors: [[0, 4, 40], [0, 78, 146], [0, 180, 219], [72, 201, 176], [127, 255, 212]] },
  { name: '森林', colors: [[19, 78, 94], [30, 132, 73], [39, 174, 96], [125, 206, 160], [169, 223, 191]] },
  { name: '梦幻紫', colors: [[102, 126, 234], [118, 75, 162], [168, 85, 247], [217, 70, 239], [240, 171, 252]] },
  { name: '冰霜', colors: [[224, 234, 252], [207, 222, 243], [161, 196, 253], [118, 178, 254], [59, 130, 246]] },
  { name: '金色', colors: [[255, 215, 0], [255, 193, 7], [255, 160, 0], [245, 124, 0], [230, 81, 0]] },
  { name: '霓虹', colors: [[255, 0, 255], [0, 255, 255], [57, 255, 20], [255, 255, 0], [138, 43, 226]] },
]

/** 按名字取预设（深拷贝颜色数组；取不到返回 null） */
export function presetByName(name) {
  const hit = GRADIENT_PRESETS.find((p) => p.name === name)
  if (!hit) return null
  return hit.colors.map((c) => c.slice())
}

/** RGB 通道插值（旧版 GradientText.vue:178-183） */
export function interpolateChannel(c1, c2, factor) {
  return Math.round(c1 + (c2 - c1) * factor)
}

/**
 * 按位置取渐变颜色（**照旧版 GradientText.vue:185-197 的算法**：按颜色数组分段做 RGB 线性插值）。
 * @param colors 颜色数组 [[r,g,b], ...]
 * @param position 当前字符下标
 * @param total 最后一个字符的下标（chars.length - 1，单字符时为 0）
 */
export function gradientColorAt(colors, position, total) {
  const list = Array.isArray(colors) ? colors : []
  if (list.length === 0) return { r: 128, g: 128, b: 128 }
  if (list.length === 1) return { r: list[0][0], g: list[0][1], b: list[0][2] }
  const span = total > 0 ? total : 1
  const segmentSize = span / (list.length - 1)
  const segmentIndex = Math.floor(position / segmentSize)
  if (segmentIndex >= list.length - 1) {
    const lastColor = list[list.length - 1]
    return { r: lastColor[0], g: lastColor[1], b: lastColor[2] }
  }
  const localPosition = position - segmentIndex * segmentSize
  const factor = localPosition / segmentSize
  const a = list[segmentIndex]
  const b = list[segmentIndex + 1]
  return {
    r: interpolateChannel(a[0], b[0], factor),
    g: interpolateChannel(a[1], b[1], factor),
    b: interpolateChannel(a[2], b[2], factor),
  }
}

/** 颜色 → 6 位小写十六进制（不带 #，旧版输出格式） */
export function colorToHex(c) {
  const clamp = (v) => Math.max(0, Math.min(255, Math.round(Number(v) || 0)))
  return [clamp(c && c.r), clamp(c && c.g), clamp(c && c.b)].map((x) => x.toString(16).padStart(2, '0')).join('')
}

/** 颜色 → `#rrggbb`（预览样式用） */
export function colorToCss(c) {
  return '#' + colorToHex(c)
}

/**
 * 按**码点**切分字符（旧版用 `split('')` 按 UTF-16 码元切，会把 emoji/生僻字拆成两个孤立代理项，
 * 各生成一个标签 → 输出乱码；旧版缺陷 1）。本件用 Array.from 修复，并在界面上给出提示。
 */
export function splitChars(text) {
  return Array.from(String(text === undefined || text === null ? '' : text))
}

/**
 * 生成彩虹字标记（旧版 GradientText.vue:199-213 的等价实现）。
 * 与旧版的差异（均为修复，交付报告已列）：
 *   1. 按码点切分（不再拆坏非 BMP 字符）；
 *   2. `]` 与 `[` 一律替换成全角/等价字符，避免标签结构被用户输入破坏；
 *   3. 空文本返回空串（同旧版）。
 */
export function generateGradientCode(text, colors) {
  const chars = splitChars(text)
  if (chars.length === 0) return ''
  const total = chars.length - 1
  return chars
    .map((ch, i) => {
      const safe = ch === ']' ? '］' : (ch === '[' ? '［' : ch)
      return `[c/${colorToHex(gradientColorAt(colors, i, total))}:${safe}]`
    })
    .join('')
}

/** 预览用的逐字符颜色（与输出完全同源，不再重复实现一份，旧版缺陷 13） */
export function gradientPreviewChars(text, colors) {
  const chars = splitChars(text)
  const total = chars.length - 1
  return chars.map((ch, i) => ({ char: ch, color: colorToCss(gradientColorAt(colors, i, total)) }))
}

/** 渐变预览条的 CSS（旧版 GradientText.vue:169-176） */
export function gradientBarStyle(colors) {
  const list = Array.isArray(colors) ? colors : []
  if (list.length === 0) return 'background:#ccc'
  return 'background:linear-gradient(to right,' + list.map((c) => colorToCss({ r: c[0], g: c[1], b: c[2] })).join(',') + ')'
}

/**
 * 解析 `#RRGGBB` / `RRGGBB`（**修复旧版 HEX 静默失败**：旧版要求长度恰好 7 且以 # 开头，
 * 输入 6 位会被静默忽略、无任何提示，DOM 里还残留错误文本；旧版缺陷 5）。
 * 返回 {ok:true,color:{r,g,b}} 或 {ok:false,error:'…'}
 */
export function parseHexColor(input) {
  const s = String(input === undefined || input === null ? '' : input).trim().replace(/^#/, '')
  if (s === '') return { ok: false, error: '请输入十六进制颜色，例如 #ff0000 或 ff0000' }
  if (!/^[0-9a-fA-F]+$/.test(s)) return { ok: false, error: `「${input}」不是合法的十六进制颜色（只能是 0-9 a-f）` }
  if (s.length !== 6 && s.length !== 3) return { ok: false, error: '颜色需要 3 位或 6 位十六进制，例如 #f00 或 #ff0000' }
  const full = s.length === 3 ? s.split('').map((h) => h + h).join('') : s
  return {
    ok: true,
    color: {
      r: parseInt(full.slice(0, 2), 16),
      g: parseInt(full.slice(2, 4), 16),
      b: parseInt(full.slice(4, 6), 16),
    },
  }
}

/** 颜色数组归一：非法项剔除，至少保留 1 个（默认灰色） */
export function normalizeColorList(list) {
  const out = (Array.isArray(list) ? list : [])
    .filter((c) => Array.isArray(c) && c.length >= 3)
    .map((c) => [
      Math.max(0, Math.min(255, Math.round(Number(c[0]) || 0))),
      Math.max(0, Math.min(255, Math.round(Number(c[1]) || 0))),
      Math.max(0, Math.min(255, Math.round(Number(c[2]) || 0))),
    ])
  return out.length > 0 ? out : [[128, 128, 128]]
}

// ════════════════════════════════════════════
//  纯函数：下发状态展示
// ════════════════════════════════════════════

/** 下发结果 → 一行中文结论（界面与测试共用，避免"成功/失败"两处各写一套判断） */
export function summarizePush(entry) {
  if (!entry) return '尚未下发'
  if (entry.ok === true) {
    return entry.legacy === true ? '已通过旧式端点下发（无版本）' : `已下发并确认（v${entry.version}）`
  }
  const why = entry.error || '原因未知'
  if (entry.serverHalfMissing === true) return `未下发：${why}`
  if (entry.skipped === true) return `未下发：${why}`
  return `下发失败：${why}`
}

/** 下发条目 → 状态样式类 */
export function pushClass(entry) {
  if (!entry) return 'sp-muted'
  if (entry.ok === true) return 'sp-ok'
  if (entry.skipped === true) return 'sp-warn'
  return 'sp-error'
}

/** 逐服转发状态表（GET /api/status-panel/status）→ 可显示的行 */
export function serverRows(status) {
  const servers = status && Array.isArray(status.servers) ? status.servers : []
  return servers.map((s) => ({
    id: String(s.id),
    name: s.name || String(s.id),
    enabled: s.enabled !== false,
    configEnabled: s.configEnabled === true,
    panelCount: Number(s.panelCount || 0),
    hasConfig: s.hasConfig === true,
    pending: s.pending === true,
    desiredVersion: Number(s.desiredVersion || 0),
    pushText: summarizePush(s.push),
    pushCls: pushClass(s.push),
    onlineText: s.online ? (s.online.ok === true ? `已同步（${s.online.total}）` : summarizePush(s.online)) : '尚未下发',
    onlineCls: s.online ? pushClass(s.online) : 'sp-muted',
  }))
}

/** 探测结果 → 一行结论 */
export function probeSummary(probe) {
  const servers = probe && Array.isArray(probe.servers) ? probe.servers : []
  const bad = servers.filter((s) => s.ok !== true || s.match !== true)
  if (servers.length === 0) return '没有可探测的服务器'
  if (bad.length === 0) return `${servers.length} 台服务器的配置与宿主完全一致`
  return `${bad.length}/${servers.length} 台服务器与宿主不一致`
}

/** 全服在线数 → 展示文案（宿主不知道时显示 —，与服端占位符一致） */
export function onlineDisplay(online) {
  if (!online) return '—'
  if (online.available === true && Number.isFinite(Number(online.total))) return String(online.total)
  return '—'
}

/** 警告列表 → 去重后的展示项（同类问题只留一条，避免 200 行配置刷出屏） */
export function groupWarnings(list) {
  const seen = new Set()
  const out = []
  for (const w of Array.isArray(list) ? list : []) {
    const level = w && w.level ? String(w.level) : 'info'
    const message = String((w && w.message) || '')
    const key = level + '|' + message
    if (seen.has(key)) continue
    seen.add(key)
    out.push({ level, message })
  }
  return out
}

// ════════════════════════════════════════════
//  视图（需要 DOM + window.tsweb；没有就整段跳过，便于 Node 侧只测纯函数）
// ════════════════════════════════════════════

const tsw = typeof window !== 'undefined' ? window.tsweb : null

if (tsw && typeof tsw.registerView === 'function') {
  bootView(tsw)
}

function bootView(tsw) {
  let root = null
  let styleDone = false
  /** 只有**成功读到服务器端配置**之后才允许自动保存（修复旧版缺陷 B：加载失败后写回默认值覆盖服务器） */
  let loaded = false
  let saveTimer = null
  /** 本地编辑序号：保存请求发出时快照，响应回来比对（在飞期间的编辑不丢，且只补一次尾保存） */
  let editSeq = 0
  let tailPending = false
  let saving = false

  const state = {
    /** 服务器清单（宿主里登记的所有服） */
    servers: [],
    /** 当前编辑的目标服务器 id（按服务器独立配置） */
    serverId: '',
    config: normalizeConfig({}),
    configFile: '',
    configError: '',
    warnings: [],
    defaults: { rows: DEFAULT_ROWS(), placeholders: INTERPOLATIONS.map((i) => i.token) },
    limits: { maxRowsPerPanel: MAX_ROWS_PER_PANEL, maxSpacerWidth: MAX_SPACER_WIDTH },
    activePanel: 'default',
    activeGroup: '玩家',
    /** 当前选中的行下标（-1 = 未选中） */
    activeRow: -1,
    newPanelName: '',
    push: null,
    online: null,
    status: null,
    probe: null,
    gradient: {
      input: '',
      colors: presetByName('彩虹') || [[255, 0, 0]],
      preset: '彩虹',
      selected: 0,
      hexInput: '',
      hexError: '',
      rowText: '',
      rowName: '',
    },
    statusText: '',
    statusCls: 'sp-muted',
    showPush: true,
  }

  function $(id) {
    return root ? root.querySelector('#' + id) : null
  }

  function setStatus(text, cls) {
    state.statusText = text || ''
    state.statusCls = cls || 'sp-muted'
    const el = $('sp-status')
    if (el) {
      el.className = 'sp-status ' + state.statusCls
      el.textContent = state.statusText
    }
  }

  function esc(s) {
    return String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, (c) => (
      { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ))
  }

  // ═══════════ 样式 ═══════════

  function injectStyle() {
    if (styleDone || typeof document === 'undefined') return
    styleDone = true
    const css = '' +
      '.sp-wrap{display:flex;flex-direction:column;gap:16px;max-width:1180px}' +
      '.sp-card{border:1px solid var(--border,#2a2f3a);border-radius:10px;padding:16px 18px}' +
      '.sp-card-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;gap:12px}' +
      '.sp-card-head h3{margin:0;font-size:15px}' +
      '.sp-desc{margin:4px 0 14px;font-size:12.5px;color:var(--muted,#9aa4b2);line-height:1.7}' +
      '.sp-desc code{background:var(--bg-2,#171b23);padding:1px 5px;border-radius:4px;font-size:12px}' +
      '.sp-row{display:flex;align-items:center;gap:10px;margin:8px 0;flex-wrap:wrap}' +
      '.sp-row>label.sp-label{min-width:110px;color:var(--muted,#9aa4b2);font-size:13px}' +
      '.sp-input,.sp-select{box-sizing:border-box;padding:6px 9px;font-size:13px;' +
      'background:var(--bg-2,#171b23);color:var(--text,#e6e9ef);border:1px solid var(--border,#2a2f3a);border-radius:6px}' +
      '.sp-input:disabled,.sp-select:disabled{opacity:.55;cursor:not-allowed}' +
      '.sp-num{width:72px;text-align:center}' +
      '.sp-btn{padding:6px 12px;font-size:12.5px;border-radius:6px;cursor:pointer;' +
      'background:var(--bg-2,#171b23);color:var(--text,#e6e9ef);border:1px solid var(--border,#2a2f3a)}' +
      '.sp-btn:hover{border-color:var(--accent,#3b82f6)}' +
      '.sp-btn:disabled{opacity:.45;cursor:not-allowed}' +
      '.sp-btn.accent{background:var(--accent,#3b82f6);border-color:var(--accent,#3b82f6);color:#fff}' +
      '.sp-btn.danger{color:#e0533d;border-color:rgba(224,83,61,.5)}' +
      '.sp-num-btn{width:28px;height:28px;padding:0;font-size:14px;line-height:1}' +
      '.sp-switch{position:relative;display:inline-block;width:46px;height:26px;flex-shrink:0}' +
      '.sp-switch input{opacity:0;width:0;height:0}' +
      '.sp-slider{position:absolute;cursor:pointer;inset:0;border:2px solid var(--border,#2a2f3a);border-radius:26px;' +
      'background:var(--bg-2,#171b23);transition:all .25s}' +
      '.sp-slider:before{content:"";position:absolute;height:16px;width:16px;left:3px;bottom:3px;' +
      'background:var(--muted,#9aa4b2);border-radius:50%;transition:all .25s}' +
      '.sp-switch input:checked+.sp-slider{background:var(--accent,#3b82f6);border-color:var(--accent,#3b82f6)}' +
      '.sp-switch input:checked+.sp-slider:before{transform:translateX(20px);background:#fff}' +
      '.sp-layout{display:flex;gap:20px;align-items:flex-start}' +
      '.sp-lines{flex:1;min-width:0}' +
      '.sp-side{width:360px;flex-shrink:0;position:sticky;top:20px;display:flex;flex-direction:column;gap:12px}' +
      '@media (max-width:1180px){.sp-layout{flex-direction:column}.sp-side{width:100%;position:static}}' +
      '.sp-tabs{display:flex;align-items:center;gap:8px;flex-wrap:wrap;justify-content:space-between;margin-bottom:10px}' +
      '.sp-tab{padding:4px 10px;border-radius:6px;border:1px solid var(--border,#2a2f3a);cursor:pointer;font-size:12.5px}' +
      '.sp-tab.active{border-color:var(--accent,#3b82f6);color:var(--accent,#3b82f6)}' +
      '.sp-tab.locked{opacity:.75}' +
      '.sp-tab-del{border:none;background:transparent;color:#e0533d;cursor:pointer;font-size:12px;padding:0 2px}' +
      '.sp-new-panel{display:flex;align-items:center;gap:6px}' +
      '.sp-new-panel input{width:120px;height:28px;font-size:12.5px}' +
      '.sp-line{border:1px solid var(--border,#2a2f3a);border-radius:8px;padding:10px 12px;margin-bottom:10px}' +
      '.sp-line.sel{border-color:var(--accent,#3b82f6)}' +
      '.sp-line.drop-before{border-top:2px solid var(--accent,#3b82f6)}' +
      '.sp-line.drop-after{border-bottom:2px solid var(--accent,#3b82f6)}' +
      '.sp-line-head{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px}' +
      '.sp-handle{cursor:grab;color:var(--muted,#9aa4b2);font-size:14px;user-select:none}' +
      '.sp-idx{width:22px;height:22px;border-radius:50%;background:var(--bg-2,#171b23);color:var(--muted,#9aa4b2);' +
      'display:inline-flex;align-items:center;justify-content:center;font-size:11.5px}' +
      '.sp-badge{font-size:11.5px;padding:1px 7px;border-radius:10px;background:var(--bg-2,#171b23);color:var(--muted,#9aa4b2)}' +
      '.sp-mini{width:24px;height:24px;padding:0;font-size:12px;line-height:1}' +
      '.sp-text{width:100%;box-sizing:border-box;padding:8px 10px;font-size:13px;resize:vertical;' +
      'font-family:inherit;background:var(--bg-2,#171b23);color:var(--text,#e6e9ef);border:1px solid var(--border,#2a2f3a);border-radius:6px}' +
      '.sp-interp{margin-top:8px;border-top:1px dashed var(--border,#2a2f3a);padding-top:8px}' +
      '.sp-interp-title{font-size:11.5px;color:var(--muted,#9aa4b2);margin-bottom:6px}' +
      '.sp-chips{display:flex;flex-wrap:wrap;gap:6px}' +
      '.sp-chip{font-size:11.5px;padding:2px 8px;border-radius:12px;cursor:pointer;' +
      'background:var(--bg-2,#171b23);color:var(--muted,#9aa4b2);border:1px solid var(--border,#2a2f3a)}' +
      '.sp-chip:hover{border-color:var(--accent,#3b82f6);color:var(--accent,#3b82f6)}' +
      '.sp-chip.active{border-color:var(--accent,#3b82f6);color:var(--accent,#3b82f6)}' +
      '.sp-chip code{font-size:11px}' +
      '.sp-chip .sp-chip-label{margin-left:5px;opacity:.8}' +
      '.sp-preview{background:var(--bg-2,#171b23);border:1px solid var(--border,#2a2f3a);border-radius:8px;' +
      'padding:10px 12px;min-height:60px;white-space:pre-wrap;font-size:13px;line-height:1.5}' +
      '.sp-preview-line{min-height:1.4em;margin-bottom:4px}' +
      '.sp-preview-line b{font-weight:600}' +
      '.sp-item{display:inline-flex;align-items:center;vertical-align:middle;gap:3px;opacity:.9}' +
      '.sp-dots{opacity:.55;user-select:none}' +
      '.sp-empty{color:var(--muted,#9aa4b2);font-size:12.5px}' +
      '.sp-hint{font-size:12px;color:var(--muted,#9aa4b2);margin:4px 0 0;line-height:1.6}' +
      '.sp-status{font-size:13px;min-height:20px;margin:2px 0 10px}' +
      '.sp-ok{color:#3fae6a}.sp-error{color:#e0533d}.sp-warn{color:#d9a41a}.sp-muted{color:var(--muted,#9aa4b2)}' +
      '.sp-table{width:100%;border-collapse:collapse;font-size:12.5px}' +
      '.sp-table th,.sp-table td{border-bottom:1px solid var(--border,#2a2f3a);padding:6px 8px;text-align:left;vertical-align:top}' +
      '.sp-table th{color:var(--muted,#9aa4b2);font-weight:500}' +
      '.sp-swatches{display:flex;flex-wrap:wrap;gap:6px}' +
      '.sp-swatch{width:26px;height:26px;border-radius:6px;border:2px solid transparent;cursor:pointer}' +
      '.sp-swatch.sel{border-color:var(--text,#e6e9ef)}' +
      '.sp-bar{height:14px;border-radius:7px;border:1px solid var(--border,#2a2f3a)}' +
      '.sp-grad-preview{white-space:pre-wrap;word-break:break-all;font-size:14px;line-height:1.6;min-height:26px}' +
      '.sp-inline{display:flex;gap:6px;align-items:center;flex-wrap:wrap}'

    const el = document.createElement('style')
    el.textContent = css
    document.head.appendChild(el)
  }

  // ═══════════ 渲染：骨架 ═══════════

  function renderShell(container) {
    container.innerHTML =
      '<h2 style="margin:0 0 4px">状态面板</h2>' +
      '<p class="sp-desc" style="margin-bottom:12px">' +
      '在客户端固定屏幕位置显示持久文本框，纯服务端实现，所有原版客户端可见。' +
      '玩家用 <code>/st</code> 查看面板列表、<code>/st 面板名</code> 切换查看（内存态）、' +
      '<code>/st on|off</code> 开关。<code>default</code> 面板强制存在且不可删除。' +
      '配置按服务器独立保存并即时下发到该服的 TsWebStatusPanel.dll。' +
      '</p>' +
      '<div id="sp-status" class="sp-status ' + esc(state.statusCls) + '"></div>' +
      '<div class="sp-wrap">' +
      '<div id="sp-overview"></div>' +
      '<div id="sp-servers"></div>' +
      '<div id="sp-content"></div>' +
      '<div id="sp-push"></div>' +
      '<div id="sp-warnings"></div>' +
      '</div>'
  }

  // ═══════════ 渲染：总览卡 ═══════════

  function renderOverview() {
    const box = $('sp-overview')
    if (!box) return
    const cfg = state.config
    box.innerHTML = '<div class="sp-card">' +
      '<div class="sp-card-head"><h3>状态面板</h3>' +
      '<div class="sp-inline"><span class="sp-hint">启用面板</span>' +
      '<label class="sp-switch"><input type="checkbox" data-sp="enabled"' + (cfg.enabled ? ' checked' : '') + '>' +
      '<span class="sp-slider"></span></label></div></div>' +
      '<p class="sp-desc">总开关关闭时，游戏服不会向任何玩家推送面板文本（<code>/st</code> 也看不到内容）。</p>' +
      '<div class="sp-row"><label class="sp-label">行尾空格宽度</label>' +
      '<button class="sp-btn sp-num-btn" data-sp="spacer-minus" title="减少 5">−</button>' +
      '<input class="sp-input sp-num" type="number" min="0" max="' + MAX_SPACER_WIDTH + '" step="5" ' +
      'data-sp="spacerWidth" value="' + esc(cfg.spacerWidth) + '" ' +
      'title="每行行尾补空格数：越大文本块越宽，可视文字越靠近屏幕中部；屏幕越宽需越大">' +
      '<button class="sp-btn sp-num-btn" data-sp="spacer-plus" title="增加 5">+</button>' +
      '<span class="sp-hint">文本块撑宽 → 客户端固定锚点居中（屏幕越宽需越大，过大偏出左屏）</span></div>' +
      '<div class="sp-row"><label class="sp-label">日志等级</label>' +
      '<select class="sp-select" data-sp="logLevel">' +
      LOG_LEVELS.map((lv) => '<option value="' + esc(lv) + '"' + (cfg.logLevel === lv ? ' selected' : '') + '>' + esc(lv) + '</option>').join('') +
      '</select><span class="sp-hint">兼容参考插件 LogLevel；NONE 会让游戏服端本插件的日志全部静默</span></div>' +
      '</div>'
  }

  // ═══════════ 渲染：服务器选择 ═══════════

  function renderServers() {
    const box = $('sp-servers')
    if (!box) return
    const list = state.servers
    if (list.length === 0) {
      box.innerHTML = '<div class="sp-card"><h3 style="margin:0 0 8px">目标服务器</h3>' +
        '<p class="sp-hint sp-error">还没有登记任何服务器：请先在「服务器管理」里添加一台，再回来配置状态面板。</p></div>'
      return
    }
    box.innerHTML = '<div class="sp-card"><div class="sp-card-head"><h3>目标服务器</h3>' +
      '<span class="sp-hint">每台服的配置相互独立（与旧版一致：旧版按当前服务器分别保存）</span></div>' +
      '<p class="sp-desc">切换服务器会重新读取该服的配置；未保存的改动会先立即提交。</p>' +
      '<div class="sp-row"><label class="sp-label">当前编辑</label>' +
      '<select class="sp-select" data-sp="serverId" style="min-width:260px">' +
      list.map((s) => '<option value="' + esc(s.id) + '"' + (String(s.id) === String(state.serverId) ? ' selected' : '') + '>' +
        esc(s.name || s.id) + (s.enabled === false ? '（已停用）' : '') + (s.hasConfig ? '' : '（未配置，用默认值）') + '</option>').join('') +
      '</select>' +
      '<span class="sp-hint">' + esc(serverSummary()) + '</span></div>' +
      '<div class="sp-row"><button class="sp-btn" data-sp="import">从该服导入现有配置</button>' +
      '<span class="sp-hint">旧版把配置存在游戏服上（tshock/TSWeb/statuspanel.json）；升级到本插件后用它把原有面板内容搬到宿主</span></div>' +
      '</div>'
  }

  function serverSummary() {
    const s = state.servers.find((x) => String(x.id) === String(state.serverId))
    if (!s) return ''
    const bits = []
    bits.push(s.enabled === false ? '该服已停用（不会下发）' : '该服已启用')
    bits.push(`面板 ${s.panelCount} 个`)
    bits.push(s.hasConfig ? '宿主已有独立配置' : '宿主无配置（当前用默认模板）')
    if (s.pending) bits.push('有未确认的下发')
    return bits.join('；')
  }

  // ═══════════ 渲染：面板内容卡 ═══════════

  function renderContent() {
    const box = $('sp-content')
    if (!box) return
    const cfg = state.config
    const names = panelNamesOf(cfg.panels)
    const active = names.includes(state.activePanel) ? state.activePanel : 'default'
    state.activePanel = active
    const rows = cfg.panels[active] || []
    const override = cfg.panelSpacers[active]

    box.innerHTML = '<div class="sp-card">' +
      '<div class="sp-card-head"><h3>面板内容：' + esc(active) + '</h3>' +
      '<div class="sp-inline">' +
      '<button class="sp-btn" data-sp="reset-template">恢复默认模板</button>' +
      '<button class="sp-btn accent" data-sp="add-row">+ 添加行</button>' +
      '</div></div>' +
      '<p class="sp-desc">每行支持插值并按其更新间隔（帧数，60=1秒）刷新；每行渲染后自动追加行尾空格。' +
      '<b>按住 ⠿ 把手拖动即可调整顺序</b>（文本框内拖动不受影响）。</p>' +
      '<div class="sp-layout">' +
      '<div class="sp-lines">' +
      '<div class="sp-tabs"><div class="sp-chips">' +
      names.map((n) => '<span class="sp-tab' + (n === active ? ' active' : '') + (n === 'default' ? ' locked' : '') + '" ' +
        'data-sp="panel-tab" data-panel="' + esc(n) + '" title="' + esc(n === 'default' ? 'default 面板强制存在，不可删除' : '切换到该面板') + '">' +
        esc(n) + (n === 'default' ? '' : '<button class="sp-tab-del" data-sp="panel-del" data-panel="' + esc(n) + '" title="删除面板">×</button>') +
        '</span>').join('') +
      '</div>' +
      '<div class="sp-new-panel"><input class="sp-input" type="text" data-sp="newPanelName" placeholder="新面板名称" value="' + esc(state.newPanelName) + '">' +
      '<button class="sp-btn accent" data-sp="add-panel">+ 添加面板</button></div>' +
      '</div>' +
      '<div class="sp-row"><label class="sp-label">本面板行尾空格</label>' +
      '<button class="sp-btn sp-num-btn" data-sp="panel-spacer-minus" title="减少 5">−</button>' +
      '<input class="sp-input sp-num" type="number" min="0" max="' + MAX_SPACER_WIDTH + '" step="5" data-sp="panelSpacer" ' +
      'value="' + (override === undefined ? '' : esc(override)) + '" placeholder="全局 ' + esc(cfg.spacerWidth) + '" ' +
      'title="该面板每行行尾补空格数；留空 = 使用全局设置">' +
      '<button class="sp-btn sp-num-btn" data-sp="panel-spacer-plus" title="增加 5">+</button>' +
      '<button class="sp-btn" data-sp="panel-spacer-clear" title="清除本面板的覆盖，改用全局值">使用全局</button>' +
      '<span class="sp-hint">留空/清除 = 使用全局（' + esc(cfg.spacerWidth) + '）；每个面板可独立调整</span></div>' +
      (rows.length === 0 ? '<div class="sp-empty" style="margin:8px 0">该面板暂无内容行，点击「+ 添加行」开始配置</div>' : '') +
      rows.map((row, i) => rowHtml(row, i, rows.length)).join('') +
      '</div>' +
      '<div class="sp-side">' + previewHtml() + gradientHtml() + '</div>' +
      '</div></div>'
  }

  function rowHtml(row, i, count) {
    const sel = state.activeRow === i ? ' sel' : ''
    const badge = row.typeName && row.typeName !== 'DynamicText'
      ? esc(row.typeName) + '（不渲染）'
      : (row.typeName === 'DynamicText' ? '动态文本' : '缺 typeName（不渲染）')
    return '<div class="sp-line' + sel + '" data-sp="line" data-idx="' + i + '" draggable="false">' +
      '<div class="sp-line-head">' +
      '<span class="sp-handle" draggable="true" data-sp="handle" data-idx="' + i + '" title="按住拖动排序">⠿</span>' +
      '<span class="sp-idx">' + (i + 1) + '</span>' +
      '<span class="sp-badge">' + badge + '</span>' +
      '<label class="sp-hint">更新间隔</label>' +
      '<input class="sp-input sp-num" type="number" min="' + INTERVAL_UI_MIN + '" max="' + INTERVAL_UI_MAX + '" ' +
      'data-sp="interval" data-idx="' + i + '" value="' + esc(row.updateInterval) + '" title="帧数，60=1秒">' +
      '<span class="sp-hint">帧</span>' +
      '<button class="sp-btn sp-mini" data-sp="up" data-idx="' + i + '" title="上移"' + (i === 0 ? ' disabled' : '') + '>↑</button>' +
      '<button class="sp-btn sp-mini" data-sp="down" data-idx="' + i + '" title="下移"' + (i === count - 1 ? ' disabled' : '') + '>↓</button>' +
      '<button class="sp-btn sp-mini danger" data-sp="del-row" data-idx="' + i + '" title="删除">×</button>' +
      '</div>' +
      '<textarea class="sp-text" rows="2" data-sp="row-text" data-idx="' + i + '" ' +
      'placeholder="例如：在线人数：{OnlinePlayersCount}人">' + esc(row.text) + '</textarea>' +
      '<div class="sp-interp" data-sp="interp">' +
      '<div class="sp-interp-title">点击插入插值（光标位置）</div>' +
      '<div class="sp-chips">' +
      [ALL_GROUP, ...INTERPOLATION_GROUPS].map((g) => '<span class="sp-chip' + (state.activeGroup === g ? ' active' : '') +
        '" data-sp="group" data-group="' + esc(g) + '">' + esc(g) + '</span>').join('') +
      '</div>' +
      '<div class="sp-chips" style="margin-top:6px">' +
      interpolationsOf(state.activeGroup).map((it) => '<span class="sp-chip" data-sp="token" data-token="' + esc(it.token) + '" ' +
        'title="' + esc(`${it.label}（示例：${it.preview}）`) + '"><code>' + esc(it.token) + '</code>' +
        '<span class="sp-chip-label">' + esc(it.label) + '</span></span>').join('') +
      '</div></div></div>'
  }

  function previewHtml() {
    const cfg = state.config
    const rows = cfg.panels[state.activePanel] || []
    const spacer = effectiveSpacer(state.activePanel, cfg)
    const dots = '·'.repeat(previewSpacerDots(spacer))
    const map = previewMap()
    const body = rows.length === 0
      ? '<div class="sp-empty">（空）</div>'
      : rows.map((row) => {
        const text = interpolatePreview(row.text, map)
        const segs = parseRichText(text)
        const inner = segs.map((seg) => {
          if (seg.type === 'color') return '<b style="color:' + esc(seg.color) + '">' + esc(seg.text) + '</b>'
          if (seg.type === 'item') return '<span class="sp-item" title="物品 ' + seg.itemId + '">[物品 ' + seg.itemId + ']</span>'
          return esc(seg.text)
        }).join('')
        return '<div class="sp-preview-line">' + inner + '<span class="sp-dots">' + esc(dots) + '</span></div>'
      }).join('')
    return '<div class="sp-card"><div class="sp-card-head"><h3>预览（' + esc(state.activePanel) + '）</h3>' +
      '<span class="sp-hint">行尾 ' + esc(spacer) + ' 空格</span></div>' +
      '<p class="sp-desc">插值以示例值展示（真实游戏中动态替换）；「·」示意行尾空格数量（5 空格 = 1 个点，最多 12 个）；' +
      '<code>[c/]</code> 颜色与 <code>[i:]</code> 物品已转义。</p>' +
      '<div class="sp-preview">' + body + '</div>' +
      (rows.length > MAX_ROWS_PER_PANEL
        ? '<p class="sp-hint sp-warn">本面板配置了 ' + rows.length + ' 行，游戏服只渲染前 ' + MAX_ROWS_PER_PANEL + ' 行。</p>'
        : '') +
      '</div>'
  }

  // ═══════════ 渲染：彩虹字设计器 ═══════════

  function gradientHtml() {
    const g = state.gradient
    const chars = gradientPreviewChars(g.input, g.colors)
    const code = generateGradientCode(g.input, g.colors)
    const sel = g.colors[Math.min(g.selected, g.colors.length - 1)] || [0, 0, 0]
    return '<div class="sp-card"><div class="sp-card-head"><h3>彩虹字设计器</h3>' +
      '<span class="sp-hint">' + g.colors.length + ' 个颜色</span></div>' +
      '<p class="sp-desc">生成泰拉瑞亚游戏内可用的彩色渐变文字代码，按「插入当前行」放进正在编辑的行。</p>' +
      '<div class="sp-row"><input class="sp-input" style="flex:1" type="text" data-sp="grad-input" ' +
      'placeholder="输入要转换的文字..." value="' + esc(g.input) + '"></div>' +
      '<div class="sp-row"><span class="sp-hint">渐变预设</span>' +
      '<select class="sp-select" data-sp="grad-preset">' +
      GRADIENT_PRESETS.map((p) => '<option value="' + esc(p.name) + '"' + (g.preset === p.name ? ' selected' : '') + '>' + esc(p.name) + '</option>').join('') +
      '</select></div>' +
      '<div class="sp-bar" style="' + esc(gradientBarStyle(g.colors)) + '"></div>' +
      '<div class="sp-grad-preview" style="margin:8px 0">' +
      (chars.length === 0 ? '<span class="sp-empty">（空）</span>'
        : chars.map((c) => '<span style="color:' + esc(c.color) + '">' + esc(c.char) + '</span>').join('')) +
      '</div>' +
      '<div class="sp-swatches">' +
      g.colors.map((c, i) => '<span class="sp-swatch' + (i === g.selected ? ' sel' : '') + '" data-sp="grad-swatch" data-idx="' + i + '" ' +
        'title="' + esc(colorToCss({ r: c[0], g: c[1], b: c[2] })) + '" style="background:' + esc(colorToCss({ r: c[0], g: c[1], b: c[2] })) + '"></span>').join('') +
      '</div>' +
      '<div class="sp-row" style="margin-top:8px">' +
      '<span class="sp-hint">R</span><input class="sp-input sp-num" type="number" min="0" max="255" data-sp="grad-r" value="' + esc(sel[0]) + '">' +
      '<span class="sp-hint">G</span><input class="sp-input sp-num" type="number" min="0" max="255" data-sp="grad-g" value="' + esc(sel[1]) + '">' +
      '<span class="sp-hint">B</span><input class="sp-input sp-num" type="number" min="0" max="255" data-sp="grad-b" value="' + esc(sel[2]) + '">' +
      '<input class="sp-input" style="width:96px" type="text" maxlength="7" data-sp="grad-hex" ' +
      'value="' + esc(g.hexInput === '' ? colorToCss({ r: sel[0], g: sel[1], b: sel[2] }) : g.hexInput) + '" placeholder="#ff0000">' +
      '</div>' +
      (g.hexError ? '<p class="sp-hint sp-error">' + esc(g.hexError) + '</p>' : '') +
      '<div class="sp-row">' +
      '<button class="sp-btn" data-sp="grad-add">添加颜色</button>' +
      '<button class="sp-btn" data-sp="grad-del"' + (g.colors.length <= 1 ? ' disabled' : '') + '>删除颜色</button>' +
      '<button class="sp-btn" data-sp="grad-random">更换颜色</button>' +
      '<button class="sp-btn" data-sp="grad-reverse">反向渐变</button>' +
      '<button class="sp-btn danger" data-sp="grad-clear">清除所有</button>' +
      '</div>' +
      '<div class="sp-row"><textarea class="sp-text" rows="2" readonly data-sp="grad-code">' + esc(code) + '</textarea></div>' +
      '<div class="sp-row"><button class="sp-btn accent" data-sp="grad-insert"' + (code === '' ? ' disabled' : '') + '>↩ 插入当前行</button>' +
      '<span class="sp-hint">' + chars.length + ' 字符，未选中行时按钮会提示先选中一行</span></div>' +
      '</div>'
  }

  // ═══════════ 渲染：下发状态卡 ═══════════

  function renderPush() {
    const box = $('sp-push')
    if (!box) return
    const st = state.status
    const rows = serverRows(st)
    const online = state.online || (st && st.online) || null
    box.innerHTML = '<div class="sp-card">' +
      '<div class="sp-card-head"><h3>下发状态</h3>' +
      '<div class="sp-inline">' +
      '<button class="sp-btn" data-sp="probe">探测服端实际配置</button>' +
      '<button class="sp-btn" data-sp="push-all">重推全部服务器</button>' +
      '<button class="sp-btn" data-sp="push-legacy" title="改走旧式端点 /data/statuspanel/config/set（无版本协议，仅排障用）">用旧式端点重推</button>' +
      '</div></div>' +
      '<p class="sp-desc">全服在线数来自宿主的 online-stats 服务：' +
      '<b class="' + (online && online.available ? 'sp-ok' : 'sp-warn') + '">' + esc(onlineDisplay(online)) + '</b>' +
      (online && online.available ? '' : '（' + esc((online && online.reason) || 'online-stats 未安装/未启用') + '）') +
      '。下发成功必须同时满足：服端确认应用、没有更新版本、且<b>已成功落盘</b>（只改内存不算成功）。</p>' +
      '<table class="sp-table"><thead><tr>' +
      '<th>服务器</th><th>配置</th><th>面板</th><th>期望版本</th><th>下发结果</th><th>全服在线数</th></tr></thead><tbody>' +
      (rows.length === 0 ? '<tr><td colspan="6" class="sp-empty">没有服务器</td></tr>' : rows.map((r) => '<tr>' +
        '<td>' + esc(r.name) + (r.enabled ? '' : '（已停用）') + '</td>' +
        '<td>' + (r.configEnabled ? '<span class="sp-ok">已启用</span>' : '<span class="sp-muted">未启用</span>') +
        (r.hasConfig ? '' : '<br><span class="sp-hint">无独立配置</span>') + '</td>' +
        '<td>' + r.panelCount + '</td>' +
        '<td>v' + r.desiredVersion + (r.pending ? ' <span class="sp-warn">未确认</span>' : '') + '</td>' +
        '<td class="' + r.pushCls + '">' + esc(r.pushText) + '</td>' +
        '<td class="' + r.onlineCls + '">' + esc(r.onlineText) + '</td>' +
        '</tr>').join('')) +
      '</tbody></table>' +
      (state.probe ? probeHtml() : '') +
      '</div>'
  }

  function probeHtml() {
    const servers = state.probe.servers || []
    const rows = servers.map((s) => '<tr>' +
      '<td>' + esc(s.name || s.id) + '</td>' +
      '<td class="' + (s.ok !== true ? 'sp-error' : (s.match ? 'sp-ok' : 'sp-warn')) + '">' +
      esc(s.ok !== true ? ('探测失败：' + (s.error || '原因未知')) : (s.match ? '一致' : '不一致')) + '</td>' +
      '<td>' + esc(s.ok !== true ? '' : (s.state && s.state.runtime ? `服端渲染${s.state.runtime.enabled ? '已启用' : '未启用'}、本服在线 ${s.state.runtime.localOnlineCount}` : '')) + '</td>' +
      '<td>' + esc(s.ok !== true ? '' : ((s.diff || []).join('；') || '无差异')) + '</td>' +
      '</tr>').join('')
    return '<div style="margin-top:12px">' +
      '<p class="sp-hint"><b>' + esc(probeSummary(state.probe)) + '</b>：' +
      '这是"界面写了什么 / 宿主以为的 / 服端真的在跑的"三者之间的直接证据。</p>' +
      '<table class="sp-table"><thead><tr><th>服务器</th><th>结论</th><th>服端运行状态</th><th>差异</th></tr></thead>' +
      '<tbody>' + rows + '</tbody></table></div>'
  }

  function renderWarnings() {
    const box = $('sp-warnings')
    if (!box) return
    const groups = groupWarnings(state.warnings)
    let html = ''
    if (state.configError) html += '<p class="sp-hint sp-error">宿主配置读取有问题：' + esc(state.configError) + '</p>'
    for (const w of groups) {
      const cls = w.level === 'error' ? 'sp-error' : (w.level === 'warn' ? 'sp-warn' : 'sp-muted')
      html += '<p class="sp-hint ' + cls + '">' + esc(w.message) + '</p>'
    }
    if (state.configFile) html += '<p class="sp-hint">宿主配置文件：' + esc(state.configFile) + '</p>'
    box.innerHTML = html === '' ? '' : '<div class="sp-card">' + html + '</div>'
  }

  function renderAll() {
    renderOverview()
    renderServers()
    renderContent()
    renderPush()
    renderWarnings()
  }

  // ═══════════ 数据读取 ═══════════

  /**
   * 每台服的请求都必须显式带 x-server-id：宿主的 window.tsweb.api 只附加 Bearer，
   * 不会自动带 x-server-id（见 plugins/base/client/groups.js:48-56 的说明）。
   */
  function apiOpts(opts) {
    const o = opts || {}
    const headers = Object.assign({}, o.headers || {})
    if (state.serverId) headers['x-server-id'] = String(state.serverId)
    return Object.assign({}, o, { headers })
  }

  async function loadServers() {
    const res = await tsw.api('/api/status-panel/servers')
    if (!res.ok) {
      setStatus('读取服务器列表失败：' + errText(res.data, res.status), 'sp-error')
      return false
    }
    const d = res.data || {}
    state.servers = Array.isArray(d.servers) ? d.servers : []
    // 目标服：优先宿主给的首选项（当前选中的服务器），否则第一台启用服
    const preferred = typeof tsw.getServerId === 'function' ? tsw.getServerId() : null
    const hit = preferred && state.servers.some((s) => String(s.id) === String(preferred))
    if (!state.serverId || !state.servers.some((s) => String(s.id) === String(state.serverId))) {
      state.serverId = hit ? String(preferred) : String((state.servers[0] || {}).id || '')
    }
    return state.servers.length > 0
  }

  async function loadConfig() {
    const res = await tsw.api('/api/status-panel/config', apiOpts())
    if (!res.ok) {
      loaded = false
      setStatus('读取配置失败：' + errText(res.data, res.status), 'sp-error')
      return false
    }
    const d = res.data || {}
    state.config = normalizeConfig(d.config)
    state.configFile = d.configFile || ''
    state.configError = d.configError || ''
    state.warnings = Array.isArray(d.warnings) ? d.warnings : []
    state.push = d.push || null
    state.online = d.online || null
    if (d.defaults && Array.isArray(d.defaults.rows) && d.defaults.rows.length > 0) {
      state.defaults.rows = d.defaults.rows.map((r) => ({ ...r }))
    }
    if (d.defaults && Array.isArray(d.defaults.placeholders) && d.defaults.placeholders.length > 0) {
      state.defaults.placeholders = d.defaults.placeholders.map(String)
    }
    state.activePanel = panelNamesOf(state.config.panels).includes(state.activePanel) ? state.activePanel : 'default'
    state.activeRow = -1
    // 只有读到配置之后才允许自动保存（修复旧版缺陷 B/Y）
    loaded = true
    return true
  }

  async function loadStatus(withProbe) {
    const res = await tsw.api('/api/status-panel/status' + (withProbe ? '?probe=1' : ''), apiOpts())
    if (!res.ok) return false
    const d = res.data || {}
    state.status = d
    if (d.online) state.online = d.online
    if (withProbe) state.probe = d.probe || null
    return true
  }

  function errText(data, status) {
    if (data && data.serverHalfMissing) {
      return (data.error || '游戏服端未安装 TsWebStatusPanel.dll') +
        ' —— 请到「插件下发」页对该服务器启用 TsWebStatusPanel.dll 后重试'
    }
    return (data && data.error) || ('HTTP ' + status)
  }

  // ═══════════ 保存（改动即自动保存，500ms 防抖） ═══════════

  function armSaveTimer() {
    if (saveTimer) clearTimeout(saveTimer)
    saveTimer = setTimeout(save, SAVE_DEBOUNCE_MS)
  }

  function scheduleSave() {
    if (!loaded) {
      // 没读到配置就编辑：不静默丢弃，也不拿默认值去覆盖服务器（旧版缺陷 B）
      setStatus('还没有成功读取服务器配置，改动暂不保存：请先解决上方的读取错误', 'sp-warn')
      return
    }
    editSeq += 1
    armSaveTimer()
  }

  /** 把待发的保存立刻发出（切服务器/离开页面前用，修复旧版缺陷 W：未落盘的编辑会丢） */
  function flushSave() {
    if (saveTimer) {
      clearTimeout(saveTimer)
      saveTimer = null
    }
    if (!loaded || editSeq === 0) return Promise.resolve(false)
    return save()
  }

  /** 提交给宿主的整份配置（只带宿主认识的字段，避免把界面态写进配置） */
  function payloadConfig() {
    const cfg = state.config
    const panels = {}
    for (const [name, rows] of Object.entries(cfg.panels)) {
      // 保留行上的全部字段（typeName 不再被硬编码成 DynamicText：旧版缺陷 D 会把 StaticText
      // 与 HandlerInfoOverride 行静默改写/丢字段）
      panels[name] = rows.map((r) => {
        const out = Object.assign({}, r)
        out.typeName = r.typeName && String(r.typeName).trim() !== '' ? String(r.typeName) : 'DynamicText'
        out.text = String(r.text === undefined || r.text === null ? '' : r.text)
        out.updateInterval = clampInterval(r.updateInterval)
        return out
      })
    }
    return {
      enabled: cfg.enabled === true,
      spacerWidth: cfg.spacerWidth,
      logLevel: cfg.logLevel,
      panels,
      panelSpacers: Object.assign({}, cfg.panelSpacers),
    }
  }

  async function save() {
    if (saveTimer) {
      clearTimeout(saveTimer)
      saveTimer = null
    }
    if (saving) {
      tailPending = true
      return false
    }
    saving = true
    const seqAtStart = editSeq
    const serverAtStart = state.serverId
    setStatus('正在保存并下发...', 'sp-muted')
    let res
    try {
      res = await tsw.api('/api/status-panel/config', apiOpts({ json: { config: payloadConfig() } }))
    } catch (err) {
      saving = false
      setStatus('保存失败：' + ((err && err.message) || err), 'sp-error')
      return false
    }
    saving = false
    const editedDuringSave = editSeq !== seqAtStart || state.serverId !== serverAtStart

    if (!res.ok) {
      setStatus('保存失败：' + errText(res.data, res.status), 'sp-error')
      runTailIfNeeded()
      return false
    }

    const d = res.data || {}
    const push = d.push || {}
    // 判据用宿主返回的真实下发结果（旧版缺陷 C 是拿 "200" 字符串比较 + response 兜底）
    if (push.total === 0) {
      setStatus('已保存（' + (push.note || '没有启用中的服务器，本次未下发') + '）', 'sp-warn')
    } else if (push.ok === true) {
      setStatus(`已保存并下发到 ${push.okCount}/${push.total} 台服务器`, 'sp-ok')
    } else {
      const failed = (push.servers || []).filter((s) => !s.ok)
      const first = failed[0] || {}
      setStatus(
        `已保存，但下发有 ${failed.length}/${push.total} 台未成功：${(first.name || first.id || '')} ${first.error || ''}`.trim(),
        'sp-error',
      )
    }

    if (editedDuringSave) {
      // 保存期间又有编辑：不用响应覆盖本地（否则"改了又被回退"），改为再补一次
      tailPending = false
      armSaveTimer()
      return true
    }

    state.warnings = Array.isArray(d.warnings) ? d.warnings : []
    state.push = push
    if (d.config) {
      state.config = normalizeConfig(d.config)
      state.activePanel = panelNamesOf(state.config.panels).includes(state.activePanel) ? state.activePanel : 'default'
    }
    await loadStatus(false)
    renderAll()
    runTailIfNeeded()
    return true
  }

  function runTailIfNeeded() {
    if (!tailPending) return
    tailPending = false
    armSaveTimer()
  }

  // ═══════════ 配置变更入口 ═══════════

  function rowsOf(name) {
    const panel = name || state.activePanel
    if (!state.config.panels[panel]) state.config.panels[panel] = []
    return state.config.panels[panel]
  }

  /** 行增删改的唯一入口（保持 state.activeRow 与行数组同步；旧版缺陷 G 就是索引漂移） */
  function removeRow(i) {
    const rows = rowsOf()
    if (i < 0 || i >= rows.length) return
    rows.splice(i, 1)
    if (state.activeRow === i) state.activeRow = -1
    else if (state.activeRow > i) state.activeRow -= 1
    scheduleSave()
    renderContent()
  }

  function moveRow(i, delta) {
    const rows = rowsOf()
    const j = i + delta
    if (i < 0 || i >= rows.length || j < 0 || j >= rows.length) return
    const tmp = rows[i]
    rows[i] = rows[j]
    rows[j] = tmp
    state.activeRow = j
    scheduleSave()
    renderContent()
  }

  function addRow() {
    rowsOf().push(NEW_ROW())
    state.activeRow = rowsOf().length - 1
    scheduleSave()
    renderContent()
  }

  /**
   * 向"当前行"插入文本：替换选区、插入后光标落在插入内容之后。
   * 与旧版的两处差异（修复）：
   *   1. 未选中行时**给提示**（旧版 insertToken 静默 return，旧版缺陷 J）；
   *   2. 以**正在聚焦的文本域**为准（state.activeRow 由 focus/点击同步），并在插入前 focus()，
   *      从而 selectionStart 可靠（旧版缺陷 I：未聚焦的 textarea 选区不可靠，插到行首）。
   */
  function insertIntoActiveRow(text) {
    if (text === '' || text === undefined || text === null) return
    const idx = state.activeRow
    if (idx < 0 || idx >= rowsOf().length) {
      setStatus('请先点击左侧列表中的一行，再插入内容', 'sp-warn')
      return
    }
    const row = rowsOf()[idx]
    const ta = root ? root.querySelector('textarea[data-sp="row-text"][data-idx="' + idx + '"]') : null
    const src = String(row.text === undefined || row.text === null ? '' : row.text)
    let start = src.length
    let end = src.length
    if (ta) {
      try {
        ta.focus()
        if (typeof ta.selectionStart === 'number') start = ta.selectionStart
        if (typeof ta.selectionEnd === 'number') end = ta.selectionEnd
      } catch {
        /* 选区不可读时退回行尾 */
      }
    }
    row.text = src.slice(0, start) + text + src.slice(end)
    const caret = start + text.length
    scheduleSave()
    renderContent()
    const after = root ? root.querySelector('textarea[data-sp="row-text"][data-idx="' + idx + '"]') : null
    if (after) {
      try {
        after.focus()
        after.setSelectionRange(caret, caret)
      } catch {
        /* 聚焦失败不影响文本已插入 */
      }
    }
  }

  function resetTemplate() {
    const name = state.activePanel
    if (typeof window !== 'undefined' && typeof window.confirm === 'function') {
      // 旧版无确认直接覆盖整面板（旧版缺陷 M）；这里补上：覆盖是破坏性的
      if (!window.confirm(`确定把面板「${name}」的内容恢复为默认模板？该面板当前 ${rowsOf(name).length} 行会被覆盖。`)) return
    }
    state.config.panels[name] = state.defaults.rows.map((r) => ({ ...r }))
    state.activeRow = -1
    scheduleSave()
    renderContent()
  }

  function addPanel(name) {
    const err = validatePanelName(name, state.config.panels)
    if (err !== '') {
      setStatus(err, 'sp-error')
      return
    }
    const trimmed = String(name).trim()
    state.config.panels[trimmed] = []
    state.activePanel = trimmed
    state.newPanelName = ''
    state.activeRow = -1
    scheduleSave()
    renderContent()
  }

  function removePanel(name) {
    if (name === 'default') return
    if (typeof window !== 'undefined' && typeof window.confirm === 'function') {
      if (!window.confirm(`确定删除面板「${name}」？`)) return
    }
    delete state.config.panels[name]
    delete state.config.panelSpacers[name]
    if (state.activePanel === name) state.activePanel = 'default'
    state.activeRow = -1
    scheduleSave()
    renderContent()
  }

  function setPanelSpacer(value) {
    const name = state.activePanel
    if (value === null) delete state.config.panelSpacers[name]
    else state.config.panelSpacers[name] = value
    scheduleSave()
    renderContent()
  }

  function stepPanelSpacer(delta) {
    setPanelSpacer(stepSpacer(effectiveSpacer(state.activePanel, state.config), delta))
  }

  // ═══════════ 事件 ═══════════

  async function onClick(ev) {
    const el = ev.target.closest ? ev.target.closest('[data-sp]') : null
    if (!el) return
    const act = el.getAttribute('data-sp')

    if (act === 'panel-tab') return void selectPanel(el.getAttribute('data-panel'))
    if (act === 'panel-del') {
      ev.stopPropagation()
      return void removePanel(el.getAttribute('data-panel'))
    }
    if (act === 'add-panel') return void addPanel(state.newPanelName)
    if (act === 'add-row') return void addRow()
    if (act === 'reset-template') return void resetTemplate()
    if (act === 'del-row') return void removeRow(Number(el.getAttribute('data-idx')))
    if (act === 'up') return void moveRow(Number(el.getAttribute('data-idx')), -1)
    if (act === 'down') return void moveRow(Number(el.getAttribute('data-idx')), 1)
    if (act === 'spacer-minus') return void applySpacerStep(-5)
    if (act === 'spacer-plus') return void applySpacerStep(5)
    if (act === 'panel-spacer-minus') return void stepPanelSpacer(-5)
    if (act === 'panel-spacer-plus') return void stepPanelSpacer(5)
    if (act === 'panel-spacer-clear') return void setPanelSpacer(null)
    if (act === 'group') {
      state.activeGroup = el.getAttribute('data-group')
      return void renderContent()
    }
    if (act === 'token') return void insertIntoActiveRow(el.getAttribute('data-token'))
    if (act === 'line') {
      // 点行卡片即选中该行（并把焦点交给文本域，使后面的光标插入位置可靠）
      const idx = Number(el.getAttribute('data-idx'))
      state.activeRow = idx
      renderContent()
      const ta = root ? root.querySelector('textarea[data-sp="row-text"][data-idx="' + idx + '"]') : null
      if (ta) ta.focus()
      return
    }
    if (act === 'probe') return void doProbe()
    if (act === 'push-all') return void doPush({})
    if (act === 'push-legacy') return void doPush({ legacy: true })
    if (act === 'import') return void doImport()

    // 彩虹字设计器
    if (act === 'grad-swatch') {
      state.gradient.selected = Number(el.getAttribute('data-idx'))
      state.gradient.hexInput = ''
      state.gradient.hexError = ''
      return void renderContent()
    }
    if (act === 'grad-add') return void gradAdd()
    if (act === 'grad-del') return void gradDel()
    if (act === 'grad-random') return void gradRandom()
    if (act === 'grad-reverse') return void gradReverse()
    if (act === 'grad-clear') return void gradClear()
    if (act === 'grad-insert') return void insertIntoActiveRow(generateGradientCode(state.gradient.input, state.gradient.colors))
  }

  function applySpacerStep(delta) {
    state.config.spacerWidth = stepSpacer(state.config.spacerWidth, delta)
    scheduleSave()
    renderOverview()
    renderContent()
  }

  function selectPanel(name) {
    if (!name) return
    flushSave()
    // 切面板时清掉拖拽中间态：旧版 selectPanel 不重置拖拽状态（旧版缺陷 U），
    // 拖拽中途切面板会把"上一次的拖拽源下标"留到下一次拖放。
    dragIndex = -1
    state.activePanel = name
    state.activeRow = -1
    renderContent()
  }

  function onChange(ev) {
    const el = ev.target
    const act = el.getAttribute && el.getAttribute('data-sp')
    if (!act) return
    if (act === 'enabled') {
      state.config.enabled = el.checked === true
      scheduleSave()
      renderOverview()
      return
    }
    if (act === 'logLevel') {
      state.config.logLevel = String(el.value)
      scheduleSave()
      return
    }
    if (act === 'spacerWidth') {
      // 旧版这个输入框**没有** change 处理（旧版缺陷 A：手输不保存）；本件按输入归一后保存
      const v = clampSpacerInput(el.value)
      state.config.spacerWidth = v === null ? 0 : v
      scheduleSave()
      renderOverview()
      renderContent()
      return
    }
    if (act === 'panelSpacer') {
      setPanelSpacer(clampSpacerInput(el.value))
      return
    }
    if (act === 'interval') {
      const idx = Number(el.getAttribute('data-idx'))
      const rows = rowsOf()
      if (rows[idx]) rows[idx].updateInterval = clampInterval(el.value)
      scheduleSave()
      return
    }
    if (act === 'serverId') {
      // 切服务器前先把待保存的改动发出去（修复旧版缺陷 W：切服会丢未落盘编辑）
      flushSave().then(() => {
        state.serverId = String(el.value)
        state.probe = null
        return reloadForServer()
      }).catch((err) => setStatus('切换服务器失败：' + ((err && err.message) || err), 'sp-error'))
      return
    }
    if (act === 'grad-preset') {
      const colors = presetByName(String(el.value))
      if (colors) {
        state.gradient.colors = colors
        state.gradient.preset = String(el.value)
        state.gradient.selected = 0
        state.gradient.hexInput = ''
        state.gradient.hexError = ''
        renderContent()
      } else {
        // 旧版未命中时静默什么都不做（用户以为选了没反应）；这里如实提示
        setStatus(`没有名为「${el.value}」的渐变预设`, 'sp-warn')
      }
      return
    }
    if (act === 'grad-hex') {
      const parsed = parseHexColor(el.value)
      if (!parsed.ok) {
        state.gradient.hexError = parsed.error
        state.gradient.hexInput = String(el.value)
      } else {
        state.gradient.hexError = ''
        state.gradient.hexInput = ''
        const c = state.gradient.colors[state.gradient.selected]
        if (c) {
          c[0] = parsed.color.r
          c[1] = parsed.color.g
          c[2] = parsed.color.b
        }
      }
      renderContent()
      return
    }
    if (act === 'grad-r' || act === 'grad-g' || act === 'grad-b') {
      const c = state.gradient.colors[state.gradient.selected]
      if (c) {
        const n = Math.max(0, Math.min(255, Math.round(Number(el.value) || 0)))
        c[act === 'grad-r' ? 0 : (act === 'grad-g' ? 1 : 2)] = n
        state.gradient.hexInput = ''
        renderContent()
      }
    }
  }

  function onInput(ev) {
    const el = ev.target
    const act = el.getAttribute && el.getAttribute('data-sp')
    if (!act) return
    if (act === 'row-text') {
      const idx = Number(el.getAttribute('data-idx'))
      const rows = rowsOf()
      if (rows[idx]) {
        rows[idx].text = String(el.value)
        state.activeRow = idx
        scheduleSave()
        renderPreviewOnly()
      }
      return
    }
    if (act === 'newPanelName') {
      state.newPanelName = String(el.value)
      return
    }
    if (act === 'grad-input') {
      state.gradient.input = String(el.value)
      gradPreviewOnly()
    }
  }

  function onFocusIn(ev) {
    const el = ev.target
    if (el && el.getAttribute && el.getAttribute('data-sp') === 'row-text') {
      state.activeRow = Number(el.getAttribute('data-idx'))
      const box = $('sp-content')
      if (box) {
        for (const card of box.querySelectorAll('.sp-line')) card.classList.remove('sel')
        const card = el.closest ? el.closest('.sp-line') : null
        if (card) card.classList.add('sel')
      }
    }
  }

  function onKeydown(ev) {
    const el = ev.target
    if (el && el.getAttribute && el.getAttribute('data-sp') === 'newPanelName' && ev.key === 'Enter') {
      ev.preventDefault()
      addPanel(state.newPanelName)
    }
  }

  /** 只重绘预览区（输入行文本时避免整块重绘导致光标跳动） */
  function renderPreviewOnly() {
    const side = root ? root.querySelector('.sp-side') : null
    if (!side) return
    const tmp = document.createElement('div')
    tmp.innerHTML = previewHtml()
    const fresh = tmp.firstChild
    const old = side.querySelector('.sp-card')
    if (old && fresh) side.replaceChild(fresh, old)
  }

  function gradPreviewOnly() {
    renderContent()
  }

  // ═══════════ 拖拽排序（旧版 :233-278 的等价实现） ═══════════

  let dragIndex = -1

  function onDragStart(ev) {
    const handle = ev.target.closest ? ev.target.closest('[data-sp="handle"]') : null
    if (!handle) {
      ev.preventDefault()
      return
    }
    dragIndex = Number(handle.getAttribute('data-idx'))
    if (ev.dataTransfer) {
      ev.dataTransfer.effectAllowed = 'move'
      try {
        ev.dataTransfer.setData('text/plain', String(dragIndex))
      } catch {
        /* 某些浏览器禁止写 dataTransfer：不影响本件的内部状态 */
      }
    }
  }

  function onDragOver(ev) {
    if (dragIndex < 0) return
    const card = ev.target.closest ? ev.target.closest('.sp-line') : null
    if (!card) return
    ev.preventDefault()
    const idx = Number(card.getAttribute('data-idx'))
    const rect = card.getBoundingClientRect()
    const after = ev.clientY > rect.top + rect.height / 2
    const box = $('sp-content')
    if (box) {
      for (const c of box.querySelectorAll('.sp-line')) c.classList.remove('drop-before', 'drop-after')
      card.classList.add(after ? 'drop-after' : 'drop-before')
    }
  }

  function onDrop(ev) {
    if (dragIndex < 0) return
    const card = ev.target.closest ? ev.target.closest('.sp-line') : null
    if (!card) return
    ev.preventDefault()
    const target = Number(card.getAttribute('data-idx'))
    const rect = card.getBoundingClientRect()
    const after = ev.clientY > rect.top + rect.height / 2
    const rows = rowsOf()
    const moved = rows.splice(dragIndex, 1)[0]
    let insertAt = target > dragIndex ? target - 1 : target
    if (after) insertAt += 1
    insertAt = Math.max(0, Math.min(rows.length, insertAt))
    rows.splice(insertAt, 0, moved)
    state.activeRow = insertAt
    dragIndex = -1
    scheduleSave()
    renderContent()
  }

  function onDragEnd() {
    dragIndex = -1
    const box = $('sp-content')
    if (box) for (const c of box.querySelectorAll('.sp-line')) c.classList.remove('drop-before', 'drop-after')
  }

  // ═══════════ 彩虹字操作 ═══════════

  function gradAdd() {
    const g = state.gradient
    const last = g.colors[g.colors.length - 1] || [255, 255, 255]
    g.colors.push([last[0], last[1], last[2]])
    g.selected = g.colors.length - 1
    renderContent()
  }

  function gradDel() {
    const g = state.gradient
    if (g.colors.length <= 1) return
    g.colors.splice(g.selected, 1)
    if (g.selected >= g.colors.length) g.selected = g.colors.length - 1
    renderContent()
  }

  function gradRandom() {
    const g = state.gradient
    const c = g.colors[g.selected]
    if (!c) return
    c[0] = Math.floor(Math.random() * 256)
    c[1] = Math.floor(Math.random() * 256)
    c[2] = Math.floor(Math.random() * 256)
    renderContent()
  }

  function gradReverse() {
    state.gradient.colors.reverse()
    renderContent()
  }

  function gradClear() {
    state.gradient.colors = [[128, 128, 128]]
    state.gradient.selected = 0
    state.gradient.input = ''
    state.gradient.hexInput = ''
    state.gradient.hexError = ''
    renderContent()
  }

  // ═══════════ 下发/探测/导入 ═══════════

  async function doPush(extra) {
    setStatus('正在重推...', 'sp-muted')
    const body = Object.assign({ serverIds: state.serverId ? [state.serverId] : null }, extra || {})
    const res = await tsw.api('/api/status-panel/push', apiOpts({ json: body }))
    if (!res.ok) {
      setStatus('重推失败：' + errText(res.data, res.status), 'sp-error')
      return
    }
    const push = (res.data || {}).push || {}
    setStatus(
      push.ok === true
        ? `重推完成：${push.okCount}/${push.total} 台确认成功`
        : `重推有 ${push.total - push.okCount}/${push.total} 台未成功`,
      push.ok === true ? 'sp-ok' : 'sp-error',
    )
    await loadStatus(true)
    renderPush()
  }

  async function doProbe() {
    setStatus('正在探测服端实际配置...', 'sp-muted')
    await loadStatus(true)
    const probe = state.probe || { servers: [] }
    const failed = (probe.servers || []).filter((s) => s.ok !== true)
    setStatus(
      probeSummary(probe) + (failed.length > 0 ? `（${failed.length} 台探测失败）` : ''),
      failed.length > 0 ? 'sp-warn' : 'sp-ok',
    )
    renderPush()
  }

  async function doImport() {
    if (typeof window !== 'undefined' && typeof window.confirm === 'function') {
      if (!window.confirm('从游戏服导入会把该服当前生效的配置写入宿主，覆盖宿主的这份配置。继续？')) return
    }
    setStatus('正在从游戏服导入配置...', 'sp-muted')
    const res = await tsw.api('/api/status-panel/import', apiOpts({ json: {} }))
    if (!res.ok) {
      setStatus('导入失败：' + errText(res.data, res.status), 'sp-error')
      return
    }
    const d = res.data || {}
    setStatus(
      `已从游戏服导入配置（服端版本 v${(d.source && d.source.version) || 0}，来源 ${(d.source && d.source.source) || '未知'}）`,
      d.ok === true ? 'sp-ok' : 'sp-warn',
    )
    await reloadForServer()
  }

  async function reloadForServer() {
    const ok = await loadConfig()
    await loadStatus(true)
    renderAll()
    if (!ok) {
      setStatus('该服务器的配置读取失败：请检查该服是否已启用本插件并下发 TsWebStatusPanel.dll', 'sp-error')
    } else {
      setStatus('已读取服务器「' + (state.servers.find((s) => String(s.id) === String(state.serverId)) || {}).name + '」的配置', 'sp-ok')
    }
  }

  // ═══════════ 视图挂载 ═══════════

  tsw.registerView({
    id: 'status-panel',
    title: '状态面板',
    section: '后端设置',
    path: '/b/status-panel',
    icon: 'server',
    render: function (container) {
      root = container
      injectStyle()
      loaded = false
      renderShell(container)
      renderAll()

      // 事件委托：先按同一引用解绑再绑（宿主的 route() 每次进入都调 render(container)，
      // 而 container 是常驻节点；无条件下 addEventListener 会让监听器随访问次数累加）。
      const bindings = [
        ['click', 'spClick', onClick],
        ['change', 'spChange', onChange],
        ['input', 'spInput', onInput],
        ['focusin', 'spFocus', onFocusIn],
        ['keydown', 'spKey', onKeydown],
        ['dragstart', 'spDragStart', onDragStart],
        ['dragover', 'spDragOver', onDragOver],
        ['drop', 'spDrop', onDrop],
        ['dragend', 'spDragEnd', onDragEnd],
      ]
      for (const [evt, key, fn] of bindings) {
        if (container['__' + key]) container.removeEventListener(evt, container['__' + key])
        container['__' + key] = (ev) => {
          try {
            fn(ev)
          } catch (err) {
            console.warn('[status-panel] ' + evt + ' 处理异常：' + ((err && err.message) || err))
          }
        }
        container.addEventListener(evt, container['__' + key])
      }

      // 离开页面/切路由前把待保存的改动发出去（旧版缺陷 W：500ms 抖动窗口内的编辑会静默丢失）
      if (typeof window !== 'undefined') {
        if (container.__spHashFlush) window.removeEventListener('hashchange', container.__spHashFlush)
        container.__spHashFlush = () => {
          flushSave().catch(() => { /* 离开页面时的失败只记状态，不阻塞导航 */ })
        }
        window.addEventListener('hashchange', container.__spHashFlush)
      }

      loadServers()
        .then((ok) => (ok ? loadConfig() : false))
        .then(() => loadStatus(true))
        .then(() => {
          renderAll()
          setStatus('已读取服务器配置', loaded ? 'sp-ok' : 'sp-error')
        })
        .catch((err) => {
          setStatus('加载失败：' + ((err && err.message) || err), 'sp-error')
        })
    },
  })

  // ═══════════ HTML 片段渲染（预览/彩虹字区已在上面各自实现） ═══════════

  if (typeof console !== 'undefined') {
    console.log('[tsweb] status-panel 客户端插件已注册: #/b/status-panel')
  }
}
