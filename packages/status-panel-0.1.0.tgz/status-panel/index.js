/**
 * 状态面板（status-panel）—— 宿主半
 *
 * 这是旧版 TsWeb「状态面板 / 服务器信息面板」的独立插件化。旧版的真正形态是：
 *   游戏服侧的插件（TsWeb/plugin/StatusPanel.cs，734 行）负责**渲染与发包**，
 *   后端（backend/services/statusPanelService.js）负责**聚合全服在线数并下发**，
 *   配置存在游戏服上（tshock/TSWeb/statuspanel.json），由后端经 REST 读写。
 * 本件沿这个分工，但把"后端"换成宿主（cordis）插件，并把旧版的一整条链路
 * （插件经 SSE 上报在线数 → 后端 Map 聚合 → 300ms 去抖 → HMAC-SHA256 签名下发到 /tsweb/statuspanel）
 * **整体废掉**：现在全服在线数由宿主一次算出（ctx.onlineStats.getCurrent()），
 * 经 TShock 自带的带 token 通道下发到服端的 /data/statuspanel/online。不重建 HMAC 协议的原因：
 *   1. 那条自研 TCP + HMAC 通道是旧版为了绕过 TShock REST 而自建的，新宿主已经有 tshock 服务；
 *   2. 更关键的是它**无法报告失败**（旧版恒回 200，见下），而"失败可见"是本次的硬要求。
 *
 * 职责分工：
 *   宿主半（本文件）  配置 CRUD / 按服务器分片的持久化 / 下发（变更即推 + ack + 周期对账 + 退避重试
 *                     + 连接恢复补推）/ 全服在线数计算与下发 / probe 自证 / 审计 / 管理界面数据源
 *   前端半            /b/status-panel：面板与行的编辑、静态预览、彩虹字生成、逐服下发状态可见
 *   游戏服半          TsWebStatusPanel.dll：渲染与本地状态（占位符插值、9 号 StatusText 包、
 *                     /st 命令、本服在线数采集、配置接收端点）
 *
 * 四条必须一致的行为（与旧版逐条对齐，见交付报告的语义对照表）：
 *   1. **插件默认关闭**（旧版 StatusPanel.cs:33 `enabled = false`，需管理员显式开启）。
 *      注意旧版设置界面的组件初值是 true（StatusPanelSettingsView.vue:57），那只是"新建表单的初值"，
 *      保存后才会写进插件；本件的界面沿用旧界面的初值观感，但**以服端配置为准**（读到的就是服端现值）。
 *   2. **配置按服务器独立**（旧版前端用 x-server-id 选目标服，后端原样转发给那一台），
 *      因此本件的存储是 `{ servers: { <serverId>: 配置 } }`，下发也只发给目标服。
 *   3. 配置变更必须**立即下发**，并把逐服结果原样回显 —— 这是"界面显示已启用、实际没生效"的解药。
 *   4. 下发失败**永不静默**：逐服状态进 pushStatus，经 /status 与保存响应回给界面，同时按退避重试，
 *      直到该服确认应用；界面还能用 probe 拿到"服端当前真的在按什么配置渲染"。
 *
 * 要点：旧版缺陷的直接修复（旧版 TsWeb/plugin/WebRestServer.cs:325 与 backend/services/statusPanelService.js:63-68）：
 *   旧版的 /tsweb/statuspanel **无论验签成功与否恒回 HTTP 200**，后端只看 res.ok，
 *   于是"验签失败 / 类型不符 / 服端异常"全被当成推送成功：表现为 {AllOnlineCount} 恒显示 —，
 *   而两端日志都不报错。本件全程使用真实 HTTP 状态码 + 服端回包的 applied/stale/saveError，
 *   并且 probe 会把"宿主算出的在线数"与"服端当前显示的在线数"并排显示，一次就能看出有没有到位。
 *
 * 依赖：webServer / auth / servers / tshock / paths（全部由宿主或基础插件提供）
 * 软依赖：online-stats（可能没装 → {AllOnlineCount} 显示 —，其余功能不受影响）
 * 约定：禁止 emoji；状态数据走 ctx.paths.dataOf('status-panel')（不在插件目录内）
 */
import { dirname } from 'node:path'

import { ACTIONS, AuditLog } from './audit.js'
import {
  MAX_ROWS_PER_PANEL,
  PUSH_DEFAULTS,
  canonicalConfig,
  changedKeys,
  configWarnings,
  defaultConfig,
  defaultPanelRows,
  httpError,
  loadStore,
  normalizeConfig,
  saveStore,
  toGamePayload,
  toLegacyPayload,
  validateConfig,
  LOG_LEVELS,
  MAX_SPACER_WIDTH,
  PLACEHOLDER_TOKENS,
} from './config.js'
import { DLL_NAME, REST_PERMISSION, SERVER_HALF_PREFIX, createGameOps, optionalService } from './gameOps.js'

export const name = 'status-panel'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths']

/** 单次手动下发可指定的服务器上限（防止一次请求把几十台服串行打完） */
const PUSH_LIMIT = 50

/** 全服在线数的"未知"哨兵：与游戏服半 StatusPanelPlaceholders.UnknownOnlineSentinel 一致 */
const UNKNOWN_ONLINE = -1

export class StatusPanelService {
  constructor({ ctx, dataDir, configFile, auditFile, push, fsApi }) {
    this.ctx = ctx
    this.dataDir = dataDir
    this.configFile = configFile
    this.auditFile = auditFile
    this.fs = fsApi

    /** 当前生效配置：serverId → 配置（唯一权威；下发内容永远由它派生） */
    this.configs = new Map()
    /** 读配置时发现的问题（文件损坏等），如实回显给管理员 */
    this.configError = ''

    /**
     * 下发/对账节奏。**不写进配置文件**：配置文件的字段要与旧版一字不差
     * （旧版是"每服一份 statuspanel.json"，没有下发节奏这个概念）。
     */
    this.push = { ...PUSH_DEFAULTS, ...(push && typeof push === 'object' ? push : {}) }

    this.gameOps = createGameOps({ ctx })
    this.audit = new AuditLog({ file: this.auditFile })

    /**
     * 每台服的配置修订号：**只在该服配置真的变了（或首次建立配置）时自增**。
     * 为什么不能直接用下发版本号判断"某服是否已是最新配置"（promotion 的注释里记过这个坑）：
     * 一次重试/补推也会把版本号抬高，于是刚刚确认过的服会被误判成"落后"，未确认计数永远清不掉。
     * 所以"版本号"管顺序，"修订号"管是否最新，各司其职。
     */
    this.configRevisions = new Map()
    /** serverId → 宿主侧期望的配置版本（每次下发尝试都自增，单调） */
    this.desiredVersions = new Map()
    /** serverId → { version, revision }（已确认应用的那一次下发） */
    this.acked = new Map()
    /** serverId → 最近一次**配置**下发结果 */
    this.pushStatus = new Map()
    /** serverId → 最近一次**全服在线数**下发结果 */
    this.onlineStatus = new Map()
    /** 最近一次已知的启用服务器 id 集合（用于算"未确认"台数，含从未推过的服） */
    this.knownServerIds = new Set()

    /** 最近一次读到的全服在线快照 */
    this.online = {
      total: UNKNOWN_ONLINE,
      available: false,
      reason: '尚未读取',
      fetchedAt: '',
      source: '',
      servers: [],
      /** 最近一次真正下发给服端的数字（用来判断"有没有变化"） */
      pushedTotal: null,
    }

    this._reconcileTimer = null
    this._retryTimer = null
    this._retryDelay = this.push.retryIntervalMs
    this._onlineDebounceTimer = null
    this._onlineReconcileTimer = null
    this._onlineUnsubscribers = []
    this._disposed = false
  }

  // ═══════════════════════ 生命周期 ═══════════════════════

  async init() {
    await this.loadConfigFile()
    this.startReconcile()
    this.startOnlineReconcile()
    // 启动即读一次全服在线数（best-effort）：让 {AllOnlineCount} 尽快从 — 变成真实数字。
    // 服务器列表可能还没加载完，那一步失败会被下面的 servers/loaded 补推覆盖。
    this.refreshOnline({ reason: '宿主启动初始化' }).catch((err) => {
      console.error(`[status-panel] 启动初始化下发全服在线数失败：${err.message}`)
    })
  }

  dispose() {
    this._disposed = true
    this.stopReconcile()
    this._clearRetry()
    if (this._onlineDebounceTimer) {
      clearTimeout(this._onlineDebounceTimer)
      this._onlineDebounceTimer = null
    }
    if (this._onlineReconcileTimer) {
      clearInterval(this._onlineReconcileTimer)
      this._onlineReconcileTimer = null
    }
    for (const off of this._onlineUnsubscribers) {
      try {
        off()
      } catch {
        /* 取消订阅失败无所谓：进程退出时一并释放 */
      }
    }
    this._onlineUnsubscribers = []
  }

  /** 订阅 online-stats 的采集事件（软依赖：没装就只记一条日志） */
  subscribeOnlineStats() {
    const svc = optionalService(this.ctx, 'onlineStats')
    if (!svc || typeof svc.on !== 'function') {
      console.log('[status-panel] online-stats 未安装/未启用：全服在线数无法取得，{AllOnlineCount} 将显示为 —')
      return false
    }

    try {
      const offChange = svc.on('change', () => this.scheduleOnlinePush('在线数变化'))
      if (typeof offChange === 'function') this._onlineUnsubscribers.push(offChange)
      const offTick = svc.on('tick', () => this.onOnlineTick())
      if (typeof offTick === 'function') this._onlineUnsubscribers.push(offTick)
      return true
    } catch (err) {
      // 事件订阅不可用时退化为"只靠周期对账"，如实记录，不假装成功
      console.error(`[status-panel] 订阅 online-stats 事件失败（全服在线数改为仅靠周期对账刷新）：${err.message}`)
      return false
    }
  }

  /** online-stats 每轮采样完成：在线数变了就立即推（没变不动，避免每 60s 白推一遍） */
  onOnlineTick() {
    if (this._disposed) return
    if (this.push.onlinePushOnTick === false) return
    this._readOnline()
      .then((snap) => {
        if (!snap.available) return
        if (this.online.pushedTotal === snap.total) return
        return this.pushOnline({ reason: '采集节拍发现在线数变化', snapshot: snap })
      })
      .catch((err) => {
        console.error(`[status-panel] 采集节拍下发全服在线数失败：${err.message}`)
      })
  }

  /** 在线数变化 → 去抖后下发（旧版后端是同样的 300ms 去抖思路） */
  scheduleOnlinePush(reason) {
    if (this._disposed) return
    const ms = Number(this.push.onlineDebounceMs)
    if (!(ms > 0)) {
      this.refreshOnline({ reason }).catch((err) => {
        console.error(`[status-panel] 下发全服在线数失败：${err.message}`)
      })
      return
    }
    if (this._onlineDebounceTimer) clearTimeout(this._onlineDebounceTimer)
    this._onlineDebounceTimer = setTimeout(() => {
      this._onlineDebounceTimer = null
      this.refreshOnline({ reason }).catch((err) => {
        console.error(`[status-panel] 下发全服在线数失败：${err.message}`)
      })
    }, ms)
    this._onlineDebounceTimer.unref?.()
  }

  // ═══════════════════════ 配置读写 ═══════════════════════

  /**
   * 读配置文件。损坏/不存在都不抛错：不存在 = 全新安装（每台服都用默认值），
   * 损坏 = 记入 configError 并回显（绝不静默当成"全新安装"，那会把用户的配置悄悄清掉）。
   */
  async loadConfigFile() {
    const { store, error } = await loadStore(this.configFile, this.fs)
    this.store = store
    this.configError = error
    this.configs = new Map()
    for (const [id, cfg] of Object.entries(store.servers || {})) {
      this.configs.set(String(id), normalizeConfig(cfg))
      this.configRevisions.set(String(id), 1)
    }
    if (error) console.error(`[status-panel] 配置读取有问题：${error}`)
  }

  /** 某台服的配置（没有记录 → 默认值：未启用 + 内置模板） */
  configOf(serverId) {
    const id = String(serverId)
    if (this.configs.has(id)) return normalizeConfig(this.configs.get(id))
    return defaultConfig()
  }

  /** 该服是否已有独立配置记录（界面用来区分"没配过"与"配成了默认值"） */
  hasConfig(serverId) {
    return this.configs.has(String(serverId))
  }

  /** 落盘（原子写） */
  async persist() {
    this.store.servers = Object.fromEntries(this.configs)
    await saveStore(this.configFile, this.store, this.fs)
  }

  /**
   * 保存某台服的配置 [+ 立即下发]。
   * 顺序刻意是"先严格校验 → 再落盘 → 再下发"：落盘失败就不该让服端跑一份只存在于内存的配置。
   */
  async setConfig(serverId, rawConfig, { actor = 'admin', reason = '配置变更即时下发', audit = true } = {}) {
    const id = String(serverId)
    validateConfig(rawConfig)
    const next = normalizeConfig(rawConfig)
    const before = this.configOf(id)

    this.configs.set(id, next)
    this.configRevisions.set(id, (this.configRevisions.get(id) || 1) + 1)
    await this.persist()
    this.configError = ''

    // 配置变了 → 退避复位 + 重新排对账（与 promotion 同一处理）
    this._clearRetry()
    this.startReconcile()

    if (audit) {
      await this.audit.append(ACTIONS.configSet, {
        actor,
        serverId: id,
        changed: changedKeys(before, next),
        enabled: next.enabled,
        spacerWidth: next.spacerWidth,
        logLevel: next.logLevel,
        panels: Object.keys(next.panels),
        panelSpacers: next.panelSpacers,
      })
    }

    if (this.push.pushOnChange === false) {
      return {
        ok: true,
        serverId: id,
        config: next,
        warnings: configWarnings(next),
        changed: changedKeys(before, next),
        push: {
          ok: true,
          total: 0,
          okCount: 0,
          pendingCount: this.pendingIds().length,
          servers: [],
          note: 'pushOnChange=false：本次未自动下发（仍有周期对账与手动重推）',
        },
      }
    }

    const push = await this.pushConfig({ serverIds: [id], reason })
    return {
      ok: push.ok,
      serverId: id,
      config: next,
      warnings: configWarnings(next),
      changed: changedKeys(before, next),
      push,
    }
  }

  /**
   * 局部写入（终端/脚本用）：`{ 路径: 值 }`，路径用点号分隔。
   * 支持的路径：enabled / spacerWidth / logLevel / panels / panelSpacers /
   *             panels.<面板名> / panelSpacers.<面板名>
   * 限制：面板名里带点号时无法用路径表达（请改传整份 config）。
   */
  async applyUpdates(serverId, updates, { actor = 'admin', reason = '配置变更即时下发' } = {}) {
    if (!updates || typeof updates !== 'object' || Array.isArray(updates)) {
      throw httpError(400, '缺少参数: updates（应为 { 配置路径: 值 } 对象）')
    }
    const keys = Object.keys(updates)
    if (keys.length === 0) throw httpError(400, 'updates 为空，没有可写入的配置项')

    const draft = JSON.parse(JSON.stringify(this.configOf(serverId)))
    const appliedKeys = []
    for (const key of keys) {
      const parts = String(key).split('.')
      const root = parts[0]
      if (!['enabled', 'spacerWidth', 'logLevel', 'panels', 'panelSpacers'].includes(root)) {
        throw httpError(400, `不可写的配置项：${key}（可写项：enabled/spacerWidth/logLevel/panels/panelSpacers，`
          + '以及 panels.<面板名> / panelSpacers.<面板名>）')
      }
      if (parts.length === 1) {
        draft[root] = updates[key]
        appliedKeys.push(key)
        continue
      }
      if (parts.length !== 2) {
        throw httpError(400, `配置路径最多两级：${key}`)
      }
      const name = parts[1]
      if (root === 'panels') {
        if (!draft.panels || typeof draft.panels !== 'object') draft.panels = {}
        draft.panels[name] = updates[key]
      } else if (root === 'panelSpacers') {
        if (!draft.panelSpacers || typeof draft.panelSpacers !== 'object') draft.panelSpacers = {}
        if (updates[key] === null) delete draft.panelSpacers[name]
        else draft.panelSpacers[name] = updates[key]
      } else {
        // enabled/spacerWidth/logLevel 不接受两级路径
        throw httpError(400, `配置项 ${root} 不能带子路径：${key}`)
      }
      appliedKeys.push(key)
    }

    const result = await this.setConfig(serverId, draft, { actor, reason })
    return { ...result, keys: appliedKeys }
  }

  /**
   * 从游戏服端导入**当前生效的配置**（旧版用户升级上来的迁移入口）。
   *
   * 为什么必须有这条：旧版把配置存在游戏服上（tshock/TSWeb/statuspanel.json），
   * 用户的真实配置在那边。新装本插件时宿主侧没有任何记录，若不做导入，用户原来的面板内容
   * 会"人间蒸发"（宿主用默认模板覆盖下去）。游戏服半在冷启动时已经把旧文件迁移进自己的配置，
   * 因此从服端读回的就是用户原本的那份。
   */
  async importFromServer(serverId, { actor = 'admin' } = {}) {
    const server = await this.resolveServer(serverId)
    if (!server.raw) throw httpError(404, `服务器不存在或已被移除：${serverId}`)
    const fetched = await this.gameOps.fetchConfig(server.raw)
    // 导入路径**刻意不走 validateConfig**：这里读的是"别人写下的文件"（服端的旧配置文件），
    // 必须容错——例如旧配置里可能有缺 typeName 的行（渲染时本来就会被丢弃），
    // 那种行不该让整份导入失败。归一后的偏差经 configWarnings 如实回显给管理员。
    const next = normalizeConfig(fetched.config)
    const importedWarnings = configWarnings(next)

    this.configs.set(String(server.id), next)
    this.configRevisions.set(String(server.id), (this.configRevisions.get(String(server.id)) || 1) + 1)
    await this.persist()

    await this.audit.append(ACTIONS.configImport, {
      actor,
      serverId: String(server.id),
      serverConfigVersion: fetched.version,
      serverConfigSource: fetched.source,
      enabled: next.enabled,
      panels: Object.keys(next.panels),
    })

    // 导入后推一次：把宿主的版本号盖上去，从此进入"宿主权威"的版本化下发
    const push = await this.pushConfig({ serverIds: [String(server.id)], reason: '导入服端配置后下发' })
    return {
      ok: push.ok,
      serverId: String(server.id),
      config: next,
      warnings: importedWarnings,
      source: { version: fetched.version, source: fetched.source, localEdits: fetched.localEdits },
      push,
    }
  }

  // ═══════════════════════ 服务器解析 ═══════════════════════

  /**
   * 解析目标服务器：优先 x-server-id 头，其次 serverId 查询/请求体参数，缺省取第一台启用服。
   * 与 plugins/base/index.js:29-41、plugins/online-stats/index.js:892-893 的既有口径一致。
   */
  async resolveServer(serverId) {
    const list = await this.ctx.servers.list()
    const id = serverId === undefined || serverId === null || serverId === '' ? null : String(serverId)
    if (id) {
      const hit = list.find((s) => String(s.id) === id)
      if (!hit) throw httpError(404, `服务器不存在：${id}`, { serverId: id })
      return { id: String(hit.id), name: hit.name, enabled: hit.enabled !== false, raw: this.ctx.servers.getRaw(hit.id) || null }
    }
    const first = list.find((s) => s.enabled !== false) || list[0]
    if (!first) throw httpError(404, '还没有登记任何服务器：请先在「服务器管理」里添加一台')
    return { id: String(first.id), name: first.name, enabled: first.enabled !== false, raw: this.ctx.servers.getRaw(first.id) || null }
  }

  static serverIdFromRequest(req) {
    const header = req && req.headers ? req.headers['x-server-id'] : undefined
    if (header) return String(header)
    if (req && req.query && req.query.serverId) return String(req.query.serverId)
    if (req && req.body && req.body.serverId) return String(req.body.serverId)
    return null
  }

  // ═══════════════════════ 下发：配置 ═══════════════════════

  /** 某服是否已确认**当前这份配置**（按修订号判断） */
  isAcked(serverId) {
    const entry = this.acked.get(String(serverId))
    return typeof entry === 'object' && entry !== null && entry.revision === this.configRevisions.get(String(serverId))
  }

  /** 未确认的服务器 id（含从未下发过的启用的服） */
  pendingIds() {
    const ids = new Set([...this.knownServerIds, ...this.pushStatus.keys(), ...this.configs.keys()])
    return [...ids].filter((id) => !this.isAcked(id))
  }

  /**
   * 下发到启用服（默认全部；serverIds 显式给出时只发这些）。
   * 逐服独立成败、永不整体抛错，调用方拿到的结果可直接回给用户。
   */
  async pushConfig({ serverIds = null, reason = '', legacy = false } = {}) {
    const servers = await this.gameOps.enabledServers()
    this.knownServerIds = new Set(servers.map((s) => String(s.id)))
    const wanted = Array.isArray(serverIds) && serverIds.length > 0 ? serverIds.map(String) : null
    const targets = wanted ? servers.filter((s) => wanted.includes(String(s.id))) : servers
    if (wanted && targets.length === 0) {
      throw httpError(404, '指定的服务器不存在或未启用', { serverIds: wanted })
    }
    return this._push(targets, { reason, legacy })
  }

  /** 只推"尚未确认当前配置"的服：连接恢复补推与失败重试都走这里，避免无谓流量 */
  async pushPending({ reason = '' } = {}) {
    const servers = await this.gameOps.enabledServers()
    this.knownServerIds = new Set(servers.map((s) => String(s.id)))
    const targets = servers.filter((s) => !this.isAcked(s.id))
    if (targets.length === 0) {
      this._clearRetry()
      return {
        ok: true, reason, total: 0, okCount: 0, pendingCount: 0, servers: [],
        note: '全部启用中的服务器都已确认最新配置',
      }
    }
    return this._push(targets, { reason })
  }

  async _push(targets, { reason = '', legacy = false } = {}) {
    const results = []
    const at = new Date().toISOString()

    for (const server of targets) {
      const id = String(server.id)
      const cfg = this.configOf(id)
      const revision = this.configRevisions.get(id) || 1
      const version = (this.desiredVersions.get(id) || 0) + 1
      this.desiredVersions.set(id, version)

      try {
        if (legacy) {
          // 旧式端点：没有版本协议、宿主不做 ack（它就是"绕过宿主"的那条路），
          // 结果照实记录，界面上会与版本化下发分开显示。
          const data = await this.gameOps.pushLegacyConfig(server, toLegacyPayload(cfg))
          const reasons = []
          if (data.saveError) reasons.push(`服端落盘失败：${data.saveError}`)
          const entry = {
            id, name: server.name, ok: reasons.length === 0, legacy: true, version: data.version,
            sentVersion: null, applied: reasons.length === 0, stale: false, at,
            localEdits: data.localEdits, notes: data.notes, error: reasons.join('；'),
          }
          this.pushStatus.set(id, entry)
          results.push(entry)
          continue
        }

        const payload = toGamePayload(cfg, {
          version,
          allOnlineCount: this.online.available ? this.online.total : UNKNOWN_ONLINE,
        })
        const data = await this.gameOps.pushConfig(server, payload)

        /**
         * 成功的判据必须同时满足三条（与 promotion 同一口径）：
         *   applied=true     服端确实收下并替换了内存里的配置
         *   stale=false      服端没有更新的版本（否则这次载荷被拒，等于没生效）
         *   saveError 为空   服端**写盘成功** —— 只改内存不算成功：游戏服重启后会退回旧值，
         *                    那种"界面显示成功、重启就没了"的静默失效正是本件要杜绝的
         */
        const reasons = []
        if (data.stale === true) reasons.push(`服端已有更新版本（v${data.version}），本次 v${version} 未生效`)
        else if (data.applied !== true) reasons.push('服端未确认应用（applied=false）')
        if (data.saveError) reasons.push(`服端落盘失败：${data.saveError}`)
        const ok = reasons.length === 0

        const entry = {
          id,
          name: server.name,
          ok,
          legacy: false,
          version: Number(data.version || version),
          sentVersion: version,
          applied: data.applied === true,
          stale: data.stale === true,
          saveError: data.saveError,
          source: data.source,
          localEdits: data.localEdits,
          notes: data.notes,
          /** 服端回包里的运行期快照：其中 allOnlineCount 是"服端此刻显示的全服在线数"，最直接的到位证据 */
          serverEnabled: data.status ? data.status.enabled : undefined,
          serverAllOnlineCount: data.status ? data.status.allOnlineCount : undefined,
          at,
          error: reasons.join('；'),
        }
        if (ok) this.acked.set(id, { version, revision })
        else this.acked.delete(id)
        this.pushStatus.set(id, entry)
        results.push(entry)
      } catch (err) {
        // 抛错同样意味着"这一服没有确认新配置"：撤掉旧的确认记录（否则它会被算成"已是最新"）
        this.acked.delete(id)
        const entry = {
          id, name: server.name, ok: false, legacy, version, sentVersion: version, applied: false,
          stale: false, at, error: err.message,
          serverHalfMissing: err.serverHalfMissing === true,
          status: err.status || 502,
        }
        this.pushStatus.set(id, entry)
        results.push(entry)
      }
    }

    const okCount = results.filter((r) => r.ok).length
    const failed = results.filter((r) => !r.ok)
    if (failed.length > 0) this._scheduleRetry()
    else this._clearRetry()

    try {
      this.ctx.emit('status-panel/push', {
        reason,
        total: results.length,
        okCount,
        servers: results.map((r) => ({ id: r.id, ok: r.ok, error: r.error })),
      })
    } catch {
      /* 无监听者/宿主不提供 emit：忽略 */
    }

    return { ok: failed.length === 0, reason, total: results.length, okCount, pendingCount: this.pendingIds().length, servers: results }
  }

  // ═══════════════════════ 下发：全服在线数 ═══════════════════════

  /**
   * 读一次全服在线数（**唯一计算点**）。
   * 走 ctx.onlineStats.getCurrent()（online-stats 插件，plugins/online-stats/index.js:145-171）：
   * 它一次给出每服的 playercount 与全服 total，宿主不再自己聚合、也不再让插件上报。
   * 旧版是"每台服的插件各自上报本服在线 → 后端 Map 聚合"，那是跨进程的二次真相源；
   * 现在只有一处计算，也就不存在"两台服显示不同数字"的窗口。
   */
  async _readOnline() {
    const svc = optionalService(this.ctx, 'onlineStats')
    const fetchedAt = new Date().toISOString()
    if (!svc || typeof svc.getCurrent !== 'function') {
      return {
        total: UNKNOWN_ONLINE,
        available: false,
        reason: 'online-stats 插件未安装/未启用：无法取得全服在线数（{AllOnlineCount} 会显示为 —）',
        fetchedAt,
        source: '',
        servers: [],
      }
    }

    try {
      const res = await svc.getCurrent()
      const servers = res && Array.isArray(res.servers) ? res.servers : []
      let total = Number(res && res.total)
      if (!Number.isFinite(total)) {
        // 退化路径：自己把各服 playercount 加起来（online-stats 未给 total 时）
        const sum = servers.reduce((acc, s) => acc + (Number.isFinite(Number(s.playercount)) ? Number(s.playercount) : 0), 0)
        total = servers.length > 0 ? sum : NaN
      }
      if (!Number.isFinite(total) || total < 0) {
        return {
          total: UNKNOWN_ONLINE,
          available: false,
          reason: 'online-stats 返回的在线总数不可用（total 既不是有效数字，也无法由各服 playercount 求和得到）',
          fetchedAt,
          source: 'ctx.onlineStats.getCurrent()',
          servers,
        }
      }
      return {
        total: Math.floor(total),
        available: true,
        reason: '',
        fetchedAt: res && res.fetchedAt ? String(res.fetchedAt) : fetchedAt,
        source: 'ctx.onlineStats.getCurrent()',
        servers,
      }
    } catch (err) {
      return {
        total: UNKNOWN_ONLINE,
        available: false,
        reason: `读取全服在线数失败：${err.message}`,
        fetchedAt,
        source: 'ctx.onlineStats.getCurrent()',
        servers: [],
      }
    }
  }

  /**
   * 读一次全服在线数并下发给**所有启用服**（每台服拿到的是同一个数字）。
   * snapshot 参数用于"调用方已经读过一次"的场景（例如采集节拍里先读后判），避免重复读。
   */
  async refreshOnline({ reason = '', snapshot = null } = {}) {
    const servers = await this.gameOps.enabledServers()
    this.knownServerIds = new Set(servers.map((s) => String(s.id)))
    const snap = snapshot || (await this._readOnline())
    this.online = { ...this.online, ...snap, pushedTotal: this.online.pushedTotal }
    return this.pushOnline({ reason, snapshot: snap, servers })
  }

  /** 把（已经读好的）全服在线数逐服下发 */
  async pushOnline({ reason = '', snapshot = null, servers = null } = {}) {
    const targets = servers || (await this.gameOps.enabledServers())
    const snap = snapshot || (await this._readOnline())
    const at = new Date().toISOString()
    const results = []

    if (!snap.available) {
      // 读不到全服在线数：**不下发**（服端保持它当前的值，而不是被写成 0/—），
      // 但把"没下发 + 原因"记录下来，界面上能直接看到为什么 {AllOnlineCount} 是 —
      this.online = { ...this.online, ...snap, pushedTotal: this.online.pushedTotal }
      for (const server of targets) {
        const entry = {
          id: String(server.id), name: server.name, ok: false, skipped: true,
          total: UNKNOWN_ONLINE, at, error: snap.reason,
        }
        this.onlineStatus.set(String(server.id), entry)
        results.push(entry)
      }
      return { ok: false, reason, available: false, total: UNKNOWN_ONLINE, error: snap.reason, serverCount: results.length, servers: results }
    }

    for (const server of targets) {
      const id = String(server.id)
      try {
        const data = await this.gameOps.pushOnline(server, { total: snap.total, ts: at })
        const ok = data.applied === true
        const entry = {
          id,
          name: server.name,
          ok,
          skipped: false,
          total: snap.total,
          applied: data.applied === true,
          allOnlineDisplay: data.allOnlineDisplay,
          // 服端自己数的本服在线：与宿主侧的 playercount 互为交叉验证
          serverLocalOnlineCount: data.localOnlineCount,
          at,
          error: ok ? '' : '服端未确认应用（applied=false）',
        }
        this.onlineStatus.set(id, entry)
        results.push(entry)
      } catch (err) {
        const entry = {
          id, name: server.name, ok: false, skipped: false, total: snap.total, at,
          error: err.message, serverHalfMissing: err.serverHalfMissing === true, status: err.status || 502,
        }
        this.onlineStatus.set(id, entry)
        results.push(entry)
      }
    }

    this.online = { ...this.online, ...snap, pushedTotal: snap.total }
    const okCount = results.filter((r) => r.ok).length
    const failed = results.filter((r) => !r.ok && !r.skipped)
    if (failed.length > 0) this._scheduleRetry()

    return { ok: failed.length === 0, reason, available: true, total: snap.total, serverCount: results.length, okCount, servers: results }
  }

  /** 是否有"真正失败（不是跳过）"的在线数下发 —— 重试定时器据此决定要不要带上在线数 */
  hasOnlineFailure() {
    for (const entry of this.onlineStatus.values()) {
      if (!entry.ok && entry.skipped !== true) return true
    }
    return false
  }

  // ═══════════════════════ 定时器 ═══════════════════════

  /**
   * 配置周期对账：无条件重推一遍。
   * 为什么无条件而不是"仅推落后的服"：服端的配置文件可能被人删掉/改坏（它会退回默认），
   * 此时宿主的 acked 记录仍是"已确认"，只有无条件重推才能自愈这种"宿主以为生效了"的状态。
   */
  startReconcile() {
    this.stopReconcile()
    const ms = Number(this.push.reconcileIntervalMs) || 0
    if (ms <= 0) return false
    this._reconcileTimer = setInterval(() => {
      this.pushPending({ reason: '周期对账（配置）' }).catch((err) => {
        console.error(`[status-panel] 周期对账下发配置失败：${err.message}`)
      })
    }, ms)
    this._reconcileTimer.unref?.()
    return true
  }

  stopReconcile() {
    if (this._reconcileTimer) {
      clearInterval(this._reconcileTimer)
      this._reconcileTimer = null
    }
  }

  /**
   * 全服在线数周期兜底：即使在线数没变也重推一遍。
   * 旧版**没有**这条兜底（只在"聚合值变化"时下发），于是"服端重启 / 那一次下发丢了 / 后端与插件
   * 短暂失联"之后，{AllOnlineCount} 会一直停在 — 或旧值 —— 这里补上。
   */
  startOnlineReconcile() {
    if (this._onlineReconcileTimer) {
      clearInterval(this._onlineReconcileTimer)
      this._onlineReconcileTimer = null
    }
    const ms = Number(this.push.onlineReconcileIntervalMs) || 0
    if (ms <= 0) return false
    this._onlineReconcileTimer = setInterval(() => {
      this.refreshOnline({ reason: '周期对账（全服在线数）' }).catch((err) => {
        console.error(`[status-panel] 周期对账下发全服在线数失败：${err.message}`)
      })
    }, ms)
    this._onlineReconcileTimer.unref?.()
    return true
  }

  /** 失败重试（指数退避到 push.retryMaxIntervalMs）；全部确认后由 _clearRetry 停掉 */
  _scheduleRetry() {
    const cfg = this.push
    if (cfg.retryIntervalMs <= 0) return false
    if (this._retryTimer) return true
    const delay = Math.max(cfg.retryIntervalMs, Math.min(this._retryDelay, cfg.retryMaxIntervalMs))
    this._retryTimer = setTimeout(() => {
      this._retryTimer = null
      this._retryDelay = Math.min(Math.max(this._retryDelay, cfg.retryIntervalMs) * 2, cfg.retryMaxIntervalMs)
      this.pushPending({ reason: '失败重试（配置）' }).catch((err) => {
        console.error(`[status-panel] 失败重试下发配置异常：${err.message}`)
      })
      if (this.hasOnlineFailure()) {
        this.refreshOnline({ reason: '失败重试（全服在线数）' }).catch((err) => {
          console.error(`[status-panel] 失败重试下发全服在线数异常：${err.message}`)
        })
      }
    }, delay)
    this._retryTimer.unref?.()
    return true
  }

  _clearRetry() {
    if (this._retryTimer) {
      clearTimeout(this._retryTimer)
      this._retryTimer = null
    }
    this._retryDelay = this.push.retryIntervalMs
  }

  // ═══════════════════════ 状态与排障 ═══════════════════════

  /** 逐服概览（界面左上的服务器选择器与状态表用） */
  async serversOverview() {
    const list = await this.ctx.servers.list()
    return list.map((s) => {
      const id = String(s.id)
      const cfg = this.configOf(id)
      return {
        id,
        name: s.name,
        host: s.host,
        port: s.port,
        enabled: s.enabled !== false,
        hasConfig: this.hasConfig(id),
        configEnabled: cfg.enabled,
        panelCount: Object.keys(cfg.panels).length,
        spacerWidth: cfg.spacerWidth,
        logLevel: cfg.logLevel,
        revision: this.configRevisions.get(id) || 1,
        desiredVersion: this.desiredVersions.get(id) || 0,
        acked: this.isAcked(id),
        pending: !this.isAcked(id),
        push: this.pushStatus.get(id) || null,
        online: this.onlineStatus.get(id) || null,
      }
    })
  }

  /** 宿主侧下发状态汇总（不含探测；探测见 probeServers） */
  status() {
    return {
      configFile: this.configFile,
      auditFile: this.auditFile,
      configError: this.configError,
      intervals: {
        reconcileIntervalMs: this.push.reconcileIntervalMs,
        retryIntervalMs: this.push.retryIntervalMs,
        retryMaxIntervalMs: this.push.retryMaxIntervalMs,
        onlineDebounceMs: this.push.onlineDebounceMs,
        onlineReconcileIntervalMs: this.push.onlineReconcileIntervalMs,
      },
      online: {
        available: this.online.available,
        total: this.online.total,
        display: this.online.available ? String(this.online.total) : '—',
        reason: this.online.reason,
        fetchedAt: this.online.fetchedAt,
        source: this.online.source,
        pushedTotal: this.online.pushedTotal,
        perServer: (this.online.servers || []).map((s) => ({
          id: String(s.id),
          name: s.name,
          playercount: Number(s.playercount || 0),
        })),
      },
      dll: { name: DLL_NAME, prefix: SERVER_HALF_PREFIX, permission: REST_PERMISSION },
      limits: { maxRowsPerPanel: MAX_ROWS_PER_PANEL, maxSpacerWidth: MAX_SPACER_WIDTH },
      pendingCount: this.pendingIds().length,
      pendingServerIds: this.pendingIds(),
      retryScheduled: this._retryTimer != null,
      onlineFailures: [...this.onlineStatus.values()].filter((e) => !e.ok && e.skipped !== true).map((e) => e.id),
    }
  }

  /**
   * 逐服探测"服端实际生效的配置与运行状态"，并与宿主配置逐字段比对。
   * 这是"界面写了什么 / 宿主以为的 / 服端真的在跑的"三者之间的唯一直接证据。
   */
  async probeServers({ serverIds = null } = {}) {
    let servers
    try {
      servers = await this.gameOps.enabledServers()
    } catch (err) {
      return { servers: [], error: `读取服务器列表失败：${err.message}` }
    }
    const wanted = Array.isArray(serverIds) && serverIds.length > 0 ? serverIds.map(String) : null
    const targets = wanted ? servers.filter((s) => wanted.includes(String(s.id))) : servers
    const out = []

    for (const server of targets) {
      const id = String(server.id)
      const hostCfg = this.configOf(id)
      try {
        const state = await this.gameOps.probe(server)
        const serverCfg = normalizeConfig(state.config)
        const diff = diffConfigs(hostCfg, serverCfg)

        // 运行期一致性：服端"配置说启用"与"渲染循环真的在跑"必须一致
        if (state.runtime.enabled !== serverCfg.enabled) {
          diff.push(`服端渲染循环 enabled=${state.runtime.enabled}（配置里是 ${serverCfg.enabled}）`)
        }
        if (state.saveError) diff.push(`服端落盘失败：${state.saveError}`)
        if (state.localEdits > 0) {
          diff.push(`服端有 ${state.localEdits} 次"绕过宿主"的旧式端点改写（服端配置可能已偏离宿主）`)
        }

        // 全服在线数是否真的到位：宿主算出的数字 vs 服端当前显示的数字
        const hostTotal = this.online.available ? this.online.total : UNKNOWN_ONLINE
        const serverTotal = state.runtime.allOnlineCount
        const onlineMatch = hostTotal === serverTotal
        if (!onlineMatch) {
          diff.push(`全服在线数：服端=${serverTotal < 0 ? '—' : serverTotal}，宿主=${hostTotal < 0 ? '—' : hostTotal}`)
        }

        // 本服在线数的交叉验证：宿主（online-stats）与服端自己数的
        const hostServerCount = (this.online.servers || []).find((s) => String(s.id) === id)
        const hostPlayercount = hostServerCount ? Number(hostServerCount.playercount || 0) : null

        out.push({
          id,
          name: server.name,
          ok: true,
          match: diff.length === 0,
          diff,
          onlineMatch,
          state,
          host: {
            config: canonicalConfig(hostCfg),
            onlineTotal: hostTotal,
            playercount: hostPlayercount,
          },
          evidence: {
            // 给界面直接显示的一行结论
            summary: diff.length === 0
              ? '服端配置与宿主一致'
              : `服端配置与宿主有 ${diff.length} 处不一致`,
          },
        })
      } catch (err) {
        out.push({
          id,
          name: server.name,
          ok: false,
          error: err.message,
          serverHalfMissing: err.serverHalfMissing === true,
          status: err.status || 502,
        })
      }
    }
    return { servers: out }
  }
}

/**
 * 逐字段比对两份配置（都先过 normalizeConfig，保证是同一基准）。
 * 只报"能看懂"的差异（面板名、行数、第几行、哪个字段），不输出两份 JSON 让管理员自己找。
 */
export function diffConfigs(hostCfg, serverCfg) {
  const a = normalizeConfig(hostCfg)
  const b = normalizeConfig(serverCfg)
  const out = []

  if (a.enabled !== b.enabled) out.push(`enabled：服端=${b.enabled}，宿主=${a.enabled}`)
  if (a.spacerWidth !== b.spacerWidth) out.push(`spacerWidth：服端=${b.spacerWidth}，宿主=${a.spacerWidth}`)
  if (a.logLevel !== b.logLevel) out.push(`logLevel：服端=${b.logLevel}，宿主=${a.logLevel}`)

  const hostPanels = Object.keys(a.panels).sort()
  const serverPanels = Object.keys(b.panels).sort()
  const onlyHost = hostPanels.filter((n) => !serverPanels.includes(n))
  const onlyServer = serverPanels.filter((n) => !hostPanels.includes(n))
  if (onlyHost.length > 0) out.push(`面板只存在于宿主：${onlyHost.join('、')}`)
  if (onlyServer.length > 0) out.push(`面板只存在于服端：${onlyServer.join('、')}`)

  for (const panelName of hostPanels.filter((n) => serverPanels.includes(n))) {
    const rowsA = a.panels[panelName]
    const rowsB = b.panels[panelName]
    if (rowsA.length !== rowsB.length) {
      out.push(`面板「${panelName}」行数：服端=${rowsB.length}，宿主=${rowsA.length}`)
      continue
    }
    for (let i = 0; i < rowsA.length; i++) {
      const ra = rowsA[i]
      const rb = rowsB[i]
      if (ra.typeName !== rb.typeName) {
        out.push(`面板「${panelName}」第 ${i + 1} 行 typeName：服端=${rb.typeName || '空'}，宿主=${ra.typeName || '空'}`)
      }
      if (ra.text !== rb.text) {
        out.push(`面板「${panelName}」第 ${i + 1} 行文本：服端="${truncate(rb.text)}"，宿主="${truncate(ra.text)}"`)
      }
      if (Number(ra.updateInterval) !== Number(rb.updateInterval)) {
        out.push(`面板「${panelName}」第 ${i + 1} 行 updateInterval：服端=${rb.updateInterval}，宿主=${ra.updateInterval}`)
      }
    }
  }

  const spacersA = a.panelSpacers
  const spacersB = b.panelSpacers
  for (const key of [...new Set([...Object.keys(spacersA), ...Object.keys(spacersB)])].sort()) {
    if (spacersA[key] !== spacersB[key]) {
      out.push(`panelSpacers["${key}"]：服端=${spacersB[key] === undefined ? '未配置' : spacersB[key]}，宿主=${spacersA[key] === undefined ? '未配置' : spacersA[key]}`)
    }
  }

  return out
}

function truncate(text, max = 40) {
  const s = String(text == null ? '' : text)
  return s.length > max ? `${s.slice(0, max)}…` : s
}

// ═══════════════════════ 插件挂载 ═══════════════════════

export async function apply(ctx, options = {}) {
  try {
    return await applyInner(ctx, options)
  } catch (err) {
    // 约定（docs/插件开发约定.md §2.2）：声明 inject 的插件 apply 是延迟执行的，
    // 期间抛出的异常不会被加载器的 try/catch 捕获，表现为"插件加载成功但什么都没注册"，
    // 所以这里自己兜一层并打印。
    console.error('[status-panel] 初始化失败: ' + err.message)
    if (process.env.TSWEB_DEBUG) console.error(err.stack)
    throw err
  }
}

async function applyInner(ctx, options = {}) {
  // 文件 IO 用 node:fs/promises（与 promotion 同一做法；构造函数注入是为了测试能替换成内存实现）
  const fsApi = options.fsApi || (await import('node:fs/promises'))
  const dataDir = options.dataDir || ctx.paths.dataOf('status-panel')
  const service = new StatusPanelService({
    ctx,
    dataDir,
    configFile: options.configFile || `${dataDir}/config.json`,
    auditFile: options.auditFile || `${dataDir}/audit.jsonl`,
    push: options.push,
    fsApi: { ...fsApi, dirname: fsApi.dirname || dirname },
  })
  await service.init()

  const app = ctx.webServer.app
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]
  const fail = (res, err) => {
    const status = err.status || 500
    const body = { error: err.message }
    for (const key of ['serverId', 'serverHalfMissing', 'serverIds', 'missingDll']) {
      if (err[key] !== undefined) body[key] = err[key]
    }
    if (!res.headersSent) res.status(status).json(body)
  }
  const wrap = (handler) => async (req, res) => {
    try {
      res.json(await handler(req, res))
    } catch (err) {
      fail(res, err)
    }
  }

  const serverIdOf = (req) => StatusPanelService.serverIdFromRequest(req)

  /**
   * 服务器清单 + 逐服配置/下发概览（界面顶部的"目标服务器"选择器用它）。
   * 每服独立配置是旧版语义（前端用 x-server-id 选目标服），所以界面必须先知道有哪些服。
   */
  app.get('/api/status-panel/servers', ...admin, wrap(async () => {
    let servers = []
    let error = ''
    try {
      servers = await service.serversOverview()
    } catch (err) {
      error = `读取服务器列表失败：${err.message}`
    }
    return {
      ok: error === '',
      error,
      servers,
      defaults: { enabled: false, spacerWidth: defaultConfig().spacerWidth, logLevel: defaultConfig().logLevel },
      dll: { name: DLL_NAME, prefix: SERVER_HALF_PREFIX, permission: REST_PERMISSION },
    }
  }))

  /** 读某台服的配置（x-server-id 指定；缺省第一台启用服） */
  app.get('/api/status-panel/config', ...admin, wrap(async (req) => {
    const server = await service.resolveServer(serverIdOf(req))
    const cfg = service.configOf(server.id)
    return {
      ok: true,
      serverId: server.id,
      serverName: server.name,
      hasConfig: service.hasConfig(server.id),
      config: cfg,
      warnings: configWarnings(cfg),
      configFile: service.configFile,
      configError: service.configError,
      defaults: { config: defaultConfig(), rows: defaultPanelRows(), placeholders: PLACEHOLDER_TOKENS, logLevels: LOG_LEVELS },
      push: service.pushStatus.get(server.id) || null,
      online: service.onlineStatus.get(server.id) || null,
      pending: !service.isAcked(server.id),
    }
  }))

  /**
   * 保存某台服的配置 [+ 立即下发]。两种请求形态：
   *   { config: {...} }          整份替换（界面"改动即自动保存"用这条；严格校验，非法即 400）
   *   { updates: { 路径: 值 } }   局部写入（终端/脚本用）
   *   { path, value }            单字段（updates 的语法糖）
   * 返回：{ ok, config, warnings, changed, push: { okCount, total, servers:[...] } }
   *   —— push 的结果**原样**回给界面，让"是否真生效"可见，不假装成功。
   */
  app.post('/api/status-panel/config', ...admin, wrap(async (req) => {
    const b = req.body || {}
    const server = await service.resolveServer(serverIdOf(req))
    if (b.config !== undefined) {
      if (b.updates !== undefined) {
        throw httpError(400, 'config 与 updates 不能同时给出（前者整份替换、后者局部写入）')
      }
      return service.setConfig(server.id, b.config, { actor: 'admin' })
    }
    let updates = b.updates && typeof b.updates === 'object' && !Array.isArray(b.updates) ? b.updates : null
    if (!updates) {
      if (b.path === undefined) throw httpError(400, '缺少参数: config 或 updates 或 path/value')
      updates = { [String(b.path)]: b.value }
    }
    return service.applyUpdates(server.id, updates, { actor: 'admin' })
  }))

  /**
   * 从游戏服端导入当前生效的配置（旧版用户升级上来的迁移入口）。
   * body/query：{ serverId? }（也可用 x-server-id 头）
   */
  app.post('/api/status-panel/import', ...admin, wrap(async (req) => {
    const server = await service.resolveServer(serverIdOf(req))
    return service.importFromServer(server.id, { actor: 'admin' })
  }))

  /** 下发状态（probe=1 时逐服探测服端实际生效的配置与运行状态） */
  app.get('/api/status-panel/status', ...admin, wrap(async (req) => {
    const q = req.query || {}
    const out = service.status()
    out.servers = await service.serversOverview()
    if (q.probe === '1' || q.probe === 'true') {
      out.probe = await service.probeServers({ serverIds: serverIdOf(req) ? [serverIdOf(req)] : null })
    }
    return { ok: true, ...out }
  }))

  /** 当前全服在线数快照（含数据来源与"这台服现在显示的是多少"的对照） */
  app.get('/api/status-panel/online', ...admin, wrap(async () => {
    const snap = await service._readOnline()
    service.online = { ...service.online, ...snap }
    return {
      ok: snap.available,
      online: {
        available: snap.available,
        total: snap.total,
        display: snap.available ? String(snap.total) : '—',
        reason: snap.reason,
        fetchedAt: snap.fetchedAt,
        source: snap.source,
        perServer: (snap.servers || []).map((s) => ({
          id: String(s.id), name: s.name, playercount: Number(s.playercount || 0),
        })),
      },
      pushed: Object.fromEntries([...service.onlineStatus.entries()]),
    }
  }))

  /**
   * 手动重推（排障用；也是"某服刚才离线"后的补救入口）。
   * body：{ serverIds?: string[], onlyPending?: boolean, legacy?: boolean, online?: boolean }
   *   legacy=true 时改走**旧式**端点 /data/statuspanel/config/set（等价旧版能力，无版本协议）
   */
  app.post('/api/status-panel/push', ...admin, wrap(async (req) => {
    const b = req.body || {}
    let serverIds = null
    if (Array.isArray(b.serverIds)) {
      if (b.serverIds.length > PUSH_LIMIT) {
        throw httpError(400, `单次下发服务器上限 ${PUSH_LIMIT} 台（本次 ${b.serverIds.length} 台）`)
      }
      serverIds = b.serverIds.map(String).filter((s) => s !== '')
    }
    const legacy = b.legacy === true
    const reason = legacy ? '手动重推（旧式端点）' : '手动重推'
    const push = b.onlyPending === true
      ? await service.pushPending({ reason })
      : await service.pushConfig({ serverIds, reason, legacy })
    const online = b.online === false
      ? { skipped: true, reason: '本次未请求重推全服在线数' }
      : await service.refreshOnline({ reason: '随手动重推同步全服在线数' })
    await service.audit.append(ACTIONS.manualPush, {
      actor: 'admin',
      serverIds: serverIds || 'all',
      onlyPending: b.onlyPending === true,
      legacy,
      okCount: push.okCount,
      total: push.total,
      failed: push.servers.filter((s) => !s.ok).map((s) => ({ id: s.id, error: s.error })),
    })
    return { ok: push.ok, push, online }
  }))

  /** 审计流水 */
  app.get('/api/status-panel/audit', ...admin, wrap(async (req) => ({
    ok: true,
    entries: await service.audit.tail((req.query && req.query.limit) || 100),
  })))

  /**
   * 默认值与常量（前端**单一真相源**：模板行、占位符清单、上限）。
   * 旧版是"插件里一份模板 + 前端里一份模板"的双份真相源（改一处不会同步另一处），
   * 本件由这条接口 + 测试里的三方一致性断言消除漂移。
   */
  app.get('/api/status-panel/defaults', ...admin, wrap(async () => ({
    ok: true,
    config: defaultConfig(),
    rows: defaultPanelRows(),
    placeholders: PLACEHOLDER_TOKENS,
    logLevels: LOG_LEVELS,
    limits: {
      maxRowsPerPanel: MAX_ROWS_PER_PANEL,
      maxSpacerWidth: MAX_SPACER_WIDTH,
      maxConfiguredRowsPerPanel: 200,
    },
  })))

  service.subscribeOnlineStats()

  try {
    ctx.on('push/connected', () => {
      service.pushPending({ reason: '服务器连接建立补推' }).catch((err) => {
        console.error(`[status-panel] 连接恢复补推失败：${err.message}`)
      })
      service.refreshOnline({ reason: '服务器连接建立' }).catch((err) => {
        console.error(`[status-panel] 连接恢复下发全服在线数失败：${err.message}`)
      })
    })
    ctx.on('servers/loaded', () => {
      service.pushPending({ reason: '服务器列表加载补推' }).catch((err) => {
        console.error(`[status-panel] 服务器列表加载补推失败：${err.message}`)
      })
      service.refreshOnline({ reason: '服务器列表加载' }).catch((err) => {
        console.error(`[status-panel] 服务器列表加载下发全服在线数失败：${err.message}`)
      })
    })
  } catch (err) {
    // ctx.on 在个别宿主版本上不可用/不允许：补推少一层兜底但插件照常工作，如实记录
    console.error(`[status-panel] 事件订阅失败（连接恢复补推不可用）：${err.message}`)
  }

  const status = service.status()
  console.log(
    `[status-panel] 已挂载：配置 ${service.configs.size} 台服 / 文件 ${service.configFile}；` +
    `下发端点 ${SERVER_HALF_PREFIX}/snapshot（需要游戏服安装 ${DLL_NAME}）；` +
    `全服在线数来源 ${status.online.available ? `可用（当前 ${status.online.display}）` : `不可用（${status.online.reason}）`}`,
  )

  // 返回 dispose effect：cordis 在插件禁用/卸载时调用（停定时器/退订事件）
  return () => service.dispose()
}
