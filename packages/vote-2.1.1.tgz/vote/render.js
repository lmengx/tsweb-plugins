const xml = value => String(value ?? '').replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[char])
const palettes = {
  pixel: { bg: '#222c32', card: '#303e3e', ink: '#f6efd9', muted: '#bbc7b8', accent: '#f1d496', line: '#4b5d50', radius: 0 },
  space: { bg: '#0b1426', card: '#14233b', ink: '#e9f0ff', muted: '#a0b0cf', accent: '#9cc4ff', line: '#293b58', radius: 16 },
  cream: { bg: '#fcf3e8', card: '#fffaf3', ink: '#4a3930', muted: '#80695b', accent: '#96563b', line: '#e3d2bd', radius: 20 },
}
function wrap(value, columns = 60) {
  const lines = []; let line = '', width = 0
  for (const char of String(value ?? '')) {
    const size = /[^\x00-\xff]/.test(char) ? 2 : 1
    if (char === '\n' || width + size > columns) { lines.push(line); line = ''; width = 0; if (char === '\n') continue }
    line += char; width += size
  }
  if (line || !lines.length) lines.push(line)
  return lines
}
export function voteSummary(result, action) {
  if (action === 'cast') return `投票成功，本次分值 ${result.weight}，剩余可投 ${result.round.my.votesLeft} 项。`
  if (action === 'propose') return result.existing ? '该提案已存在。' : '提案已提交。'
  return '投票结果'
}
export function buildVotePages({ result, action = 'list', theme = 'pixel', accent = '', optionsPerPage = 20, showDescription = true }) {
  const p = { ...(palettes[theme] || palettes.pixel), ...(/^#[0-9a-f]{6}$/i.test(accent) ? { accent } : {}) }
  const rounds = result.round ? [result.round] : result.rounds || [], overview = !result.round && rounds.length > 1
  const pageSize = Number.isInteger(optionsPerPage) ? Math.max(6, Math.min(30, optionsPerPage)) : 20
  const text = (x, y, value, size = 26, color = p.ink, weight = 400, anchor = 'start') => `<text x="${x}" y="${y}" fill="${color}" font-size="${size}" font-weight="${weight}" text-anchor="${anchor}">${xml(value)}</text>`
  const summary = voteSummary(result, action)
  const page = (header, items, footer) => {
    let y = 112
    const body = header.concat(items).map(item => { const value = item.draw(y); y += item.height; return value }).join('')
    const height = Math.max(420, y + 130)
    return `<svg xmlns="http://www.w3.org/2000/svg" width="960" height="${height}" viewBox="0 0 960 ${height}"><title>投票结果</title><rect width="960" height="${height}" fill="${p.bg}"/><g font-family="Microsoft YaHei,Noto Sans CJK SC,WenQuanYi Zen Hei,sans-serif">${text(44, 52, 'TSWEB / 玩家投票', 28, p.muted, 600)}${text(44, 93, summary, 24, p.accent)}${body}<path d="M44 ${height - 106}H916" stroke="${p.line}"/>${text(44, height - 70, footer, 21, p.muted)}${text(44, height - 36, '查看：投票 [轮次名] · 参与：投 轮次名 选项编号', 22)}</g></svg>`
  }
  const lines = (value, size = 25, color = p.muted, weight = 400) => wrap(value, size >= 30 ? 48 : 64).map(line => ({ height: size + 12, draw: y => text(44, y + size, line, size, color, weight) }))
  if (!rounds.length) return { text: summary, pages: [page(lines('当前没有可查看的投票。', 30, p.ink), [], '网页与 QQ 群共享投票额度')] }
  if (overview) {
    const header = lines(`共 ${rounds.length} 轮投票，显示前 ${Math.min(20, rounds.length)} 轮。`, 27, p.ink)
    const items = rounds.slice(0, 20).map((round, i) => {
      const title = wrap(`${i + 1}. ${round.title}`, 60), height = 46 + title.length * 32
      return { height: height + 12, draw: y => `<rect x="44" y="${y}" width="872" height="${height}" rx="${p.radius}" fill="${p.card}"/>` + title.map((line, n) => text(62, y + 33 + n * 32, line, 26, p.ink, 600)).join('') + text(62, y + height - 14, `${round.status === 'open' ? '进行中' : '已结束'} · ${round.options.length} 个选项`, 21, p.accent) + text(896, y + height - 14, `查询：投票 ${round.id}`, 18, p.muted, 400, 'end') }
    })
    return { text: summary, pages: [page(header, items, '发送「投票 完整轮次名」查看该轮全部选项')] }
  }
  const round = rounds[0], max = Math.max(1, ...round.options.map(option => Number(option.score) || 0))
  const header = [...lines(round.title, 32, p.ink, 700), ...lines(`${round.status === 'open' ? '进行中' : '已结束'} · ${round.options.length} 个选项`, 22, p.accent)]
  if (round.endAt) header.push(...lines('截止：' + new Date(round.endAt).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', hour12: false }), 22))
  const description = showDescription && round.description ? lines(round.description, 23) : []
  const options = round.options.map((option, i) => {
    const label = wrap(`${i + 1}. ${option.text}`, 60), height = 52 + label.length * 31
    return { height: height + 10, draw: y => `<rect x="44" y="${y}" width="872" height="${height}" rx="${p.radius}" fill="${p.card}" stroke="${p.line}"/>` + label.map((line, n) => text(64, y + 32 + n * 31, line, 26, p.ink, 600)).join('') + text(896, y + height - 23, `${option.votes} 票 / ${option.score} 分`, 22, p.accent, 400, 'end') + `<rect x="64" y="${y + height - 13}" width="832" height="5" fill="${p.line}"/><rect x="64" y="${y + height - 13}" width="${Math.max(0, Math.min(832, 832 * (Number(option.score) || 0) / max))}" height="5" fill="${p.accent}"/>` }
  })
  const chunks = []; let items = [], used = 0, start = 0
  const headerHeight = header.reduce((sum, item) => sum + item.height, 0)
  const flush = () => { chunks.push({ items, start }); start += items.length; items = []; used = 0 }
  for (const option of options) {
    const descriptionHeight = chunks.length === 0 ? description.reduce((sum, item) => sum + item.height, 0) : 0
    if (items.length && (items.length >= pageSize || 242 + headerHeight + descriptionHeight + used + option.height > 3600)) flush()
    items.push(option); used += option.height
  }
  if (items.length || !chunks.length) flush()
  return { text: summary, pages: chunks.map((chunk, i) => page(header.concat(i === 0 ? description : []), chunk.items, `选项 ${options.length ? chunk.start + 1 : 0}–${chunk.start + chunk.items.length} / ${options.length} · 第 ${i + 1} / ${chunks.length} 页 · 提案：提案 轮次名 内容`)) }
}
export function registerVoteRendering(ctx, settings) {
  return ctx.inject(['qqRenderer'], c => {
    if (!c.qqRenderer.registerTemplate) return
    return c.qqRenderer.registerTemplate('vote/results', { owner: 'vote', build: options => buildVotePages({ ...settings?.config, ...options }) })
  })
}
export async function presentVote(ctx, result, { action, signal } = {}, settings) {
  let renderer
  try { renderer = ctx.get('qqRenderer') } catch {}
  if (settings?.config.enabled === false || !renderer?.config?.enabled || !renderer.registerTemplate) return null
  return renderer.render('vote/results', { result, action, signal })
}
