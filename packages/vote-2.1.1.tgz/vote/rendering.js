import { validateRendering } from './render-config.js'
const fail = (status, message) => Object.assign(new Error(message), { status })
const rendererOf = ctx => { try { return ctx.get('qqRenderer') } catch { return null } }
export function registerRendering(app, ctx, settings, store, wrap) {
  const status = () => {
    const renderer = rendererOf(ctx)
    return { ...settings.publicConfig(), engine: { loaded: !!renderer?.registerTemplate, enabled: renderer?.config?.enabled === true } }
  }
  app.get('/api/vote/admin/rendering', wrap(status))
  app.post('/api/vote/admin/rendering', wrap(async req => {
    await settings.save(req.body?.config, req.body?.revision)
    return status()
  }))
  app.post('/api/vote/admin/rendering/preview', wrap(async req => {
    const renderer = rendererOf(ctx)
    if (!renderer?.registerTemplate) throw fail(409, '请到插件市场安装并启用「QQ 图片渲染」引擎')
    const config = validateRendering(req.body?.config)
    const scenario = req.body?.scenario ?? 'sample'
    if (!['sample', 'long', 'current'].includes(scenario)) throw fail(400, '预览场景无效')
    let round
    if (scenario === 'current') {
      round = (await store.list()).find(row => row.id === req.body?.roundId)
      if (!round) throw fail(404, '当前轮次不存在或已归档')
    } else {
      round = { title: '下期服务器玩法', status: 'open', description: '这是一张投票图片预览。选项、票数与分值都由投票插件绘制。', options: Array.from({ length: scenario === 'long' ? 45 : 6 }, (_, i) => ({ text: scenario === 'long' ? `选项 ${i + 1}：包含较长描述的服务器玩法，完整显示名称与票数` : ['经典生存', '专家挑战', '建筑活动', '大师开荒', '旅途探索', '社区竞赛'][i], votes: (6 - i % 6) * 3, score: (6 - i % 6) * 4.5 })) }
    }
    const result = await renderer.render('vote/results', { ...config, result: { round }, preview: true })
    return { images: result.images.map(buffer => 'data:image/png;base64,' + buffer.toString('base64')), pages: result.images.length, sample: scenario !== 'current' }
  }))
}
