export default {
  owner: 'onebot-bridge',
  version: 2,
  modules: [{ id: 'onebot-bridge.settings', permission: 'onebot-bridge.ui.settings', title: 'OneBot 身份补全', roles: ['superadmin'], scope: 'global', requires: [
    'onebot-bridge.get.config', 'onebot-bridge.post.config', 'onebot-bridge.post.test',
  ] }],
  actions: [
    { id: 'onebot-bridge.get.config', method: 'GET', path: '/api/onebot-bridge/config', scope: 'global', module: 'onebot-bridge.settings' },
    { id: 'onebot-bridge.post.config', method: 'POST', path: '/api/onebot-bridge/config', scope: 'global', module: 'onebot-bridge.settings' },
    { id: 'onebot-bridge.post.test', method: 'POST', path: '/api/onebot-bridge/test', scope: 'global', module: 'onebot-bridge.settings' },
  ],
  /**
   * 合并前 OneBot 是独立插件、有独立页面，页面不存在 = 无权访问；
   * 合并后它成了 qq-serve 控制台里的一个页签，必须补一个 feature 供前端 canFeature 判断，
   * 否则只有 qq-serve:settings 的管理员会看到该页签、点进去全是 403。
   * 新增 feature 是纯增量：既有授权按模块（onebot-bridge.settings）生效，不受影响。
   */
  features: [{ id: 'onebot-bridge:settings', module: 'onebot-bridge.settings', requires: [
    'onebot-bridge.get.config', 'onebot-bridge.post.config', 'onebot-bridge.post.test',
  ] }],
}
