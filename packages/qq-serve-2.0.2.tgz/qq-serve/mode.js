/**
 * QQ 服务模式域：运行模式、凭据、连接测试、消息渲染页签。
 *
 * 合并前这是 qq-serve 插件的全部入口；现在由 index.js 组合根装配，
 * 已按合并契约鉴权的 app 与唯一数据目录由组合根下发（deps）。
 */
import { Service } from '@deepseek-ai/cordis'
import { readFile, writeFile, mkdir } from 'node:fs/promises'
import path from 'node:path'
import { validateMode, testConnection } from './connection.js'
import modeAccess from './mode-access.js'

// 生产由组合根调用 applyMode；name/inject 与 apply 别名仅供单域装配的测试。
export const name = 'qq-serve'
export const inject = ['webServer', 'auth', 'paths']
import { registerRendering } from './rendering.js'

const MODES = ['official', 'onebot', 'hybrid']
const defaults = () => ({
  schema: 2,
  mode: 'official',
  official: { appId: '', appSecret: '' },
  onebot: { endpoint: '', accessToken: '', webhookToken: '', botQq: '', allowTransfer: true, groupMap: {} },
})
const text = (value, max = 512) => String(value ?? '').trim().slice(0, max)
const groupMap = value => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {}
  return Object.fromEntries(Object.entries(value).map(([key, id]) => [text(key, 128), text(id, 64)]).filter(([key, id]) => key && id))
}
const normalize = (value, base = defaults()) => {
  const input = value && typeof value === 'object' && !Array.isArray(value) ? value : {}
  const official = input.official && typeof input.official === 'object' ? input.official : {}
  const onebot = input.onebot && typeof input.onebot === 'object' ? input.onebot : {}
  return {
    schema: 2,
    mode: MODES.includes(input.mode) ? input.mode : (MODES.includes(base.mode) ? base.mode : 'official'),
    official: {
      appId: text(official.appId ?? base.official?.appId, 64),
      appSecret: text(official.appSecret ?? base.official?.appSecret, 512),
    },
    onebot: {
      endpoint: text(onebot.endpoint ?? base.onebot?.endpoint, 512).replace(/\/$/, ''),
      accessToken: text(onebot.accessToken ?? base.onebot?.accessToken, 512),
      webhookToken: text(onebot.webhookToken ?? base.onebot?.webhookToken, 512),
      botQq: text(onebot.botQq ?? base.onebot?.botQq, 32),
      allowTransfer: onebot.allowTransfer === undefined ? base.onebot?.allowTransfer !== false : onebot.allowTransfer !== false,
      groupMap: groupMap(onebot.groupMap ?? base.onebot?.groupMap),
    },
  }
}

class QqServeService extends Service {
  constructor(ctx, file) { super(ctx, 'qqServe'); this.file = file; this.config = defaults(); this.adapters = new Map() }
  async load() {
    await mkdir(path.dirname(this.file), { recursive: true })
    try { this.config = normalize(JSON.parse(await readFile(this.file, 'utf8'))) }
    catch (error) { if (error.code !== 'ENOENT') throw error; await this.save() }
  }
  async save() { await writeFile(this.file, JSON.stringify(this.config, null, 2) + '\n', { mode: 0o600 }) }
  registerAdapter(name, adapter) {
    this.adapters.set(String(name), adapter)
    void this.applyMode().catch(error => this.ctx.logger?.warn?.(`[qq-serve] 适配器启动失败: ${error.message}`))
    return () => { if (this.adapters.get(String(name)) === adapter) this.adapters.delete(String(name)) }
  }
  async applyMode() {
    const official = this.adapters.get('official')
    if (official) {
      if (official.applyCanonicalConfig) await official.applyCanonicalConfig(this.config.official)
      const shouldRun = ['official', 'hybrid'].includes(this.config.mode) && this.config.official.appId && this.config.official.appSecret
      if (shouldRun && !official.status?.().connected && official.start) await official.start()
      if (!shouldRun && official.stop) await official.stop()
    }
    const onebot = this.adapters.get('onebot')
    if (onebot?.configure) onebot.configure({ ...this.config.onebot, mode: this.config.mode, enabled: ['onebot', 'hybrid'].includes(this.config.mode) })
    else if (onebot?.setEnabled) onebot.setEnabled(['onebot', 'hybrid'].includes(this.config.mode))
  }
  status() {
    const out = { mode: this.config.mode, adapters: Object.fromEntries([...this.adapters].map(([name, adapter]) => [name, adapter.status?.() || { loaded: true }])) }
    // 只在真的有接入件没起来时才多带这个字段：正常情况下响应形状保持不变
    if (this.failures && Object.keys(this.failures).length) out.failures = { ...this.failures }
    return out
  }
  publicConfig() {
    return {
      schema: this.config.schema,
      mode: this.config.mode,
      modes: MODES.map(mode => ({ mode, selected: mode === this.config.mode })),
      official: { appId: this.config.official.appId, hasSecret: Boolean(this.config.official.appSecret) },
      onebot: {
        endpoint: this.config.onebot.endpoint,
        hasAccessToken: Boolean(this.config.onebot.accessToken),
        hasWebhookToken: Boolean(this.config.onebot.webhookToken),
        botQq: this.config.onebot.botQq,
        allowTransfer: this.config.onebot.allowTransfer,
        groupMap: this.config.onebot.groupMap,
      },
    }
  }
}

function domainDeps(ctx) {
  return {
    app: ctx.auth.access.policyApp(ctx.webServer.app, modeAccess, ctx),
    dataDir: ctx.paths.dataOf('qq-serve'),
  }
}

export async function applyMode(ctx, deps = domainDeps(ctx)) {
  const { app, dataDir } = deps
  const service = new QqServeService(ctx, path.join(dataDir, 'config.json'))
  ctx.qqServe = service
  await service.load()
  // 合并后两个接入实现同进程常驻：模式只决定谁在跑，不再"按模式去启用另一个插件"。
  deps.serve = service
  const activate = async () => { await service.applyMode() }
  registerRendering(app, ctx)
  const route = handler => async (req, res) => { try { res.json(await handler(req)) } catch (error) { res.status(error.status || 500).json({ error: error.message }) } }
  app.get('/api/qq-serve/config', route(() => service.publicConfig()))
  app.get('/api/qq-serve/status', route(() => service.status()))
  app.post('/api/qq-serve/test', route(req => testConnection(normalize(req.body || {}, service.config), req.body?.provider)))
  app.post('/api/qq-serve/config', route(async req => {
    const body = req.body || {}
    const patch = {
      ...body,
      official: { ...(body.official || {}), appSecret: body.official?.appSecret === '***已设置***' ? service.config.official.appSecret : body.official?.appSecret },
      onebot: {
        ...(body.onebot || {}),
        accessToken: body.onebot?.accessToken === '***已设置***' ? service.config.onebot.accessToken : body.onebot?.accessToken,
        webhookToken: body.onebot?.webhookToken === '***已设置***' ? service.config.onebot.webhookToken : body.onebot?.webhookToken,
      },
    }
    const next = normalize(patch, service.config)
    if (body.mode !== undefined && !MODES.includes(body.mode)) throw Object.assign(new Error('运行模式无效'), { status: 400 })
    // A mode change must be ready before mutating either memory or disk.
    if (next.mode !== service.config.mode) validateMode(next)
    if (next.onebot.endpoint) {
      let endpoint
      try { endpoint = new URL(next.onebot.endpoint) } catch {}
      if (!endpoint || !['http:', 'https:', 'ws:', 'wss:'].includes(endpoint.protocol) || endpoint.username || endpoint.password)
        throw Object.assign(new Error('OneBot Endpoint 必须为 HTTP(S) 或 WS(S) 地址，凭据请填写在 Token 中'), { status: 400 })
    }
    if (next.official.appId && !/^\d{1,32}$/.test(next.official.appId)) throw Object.assign(new Error('官方机器人 AppID 格式无效'), { status: 400 })
    if (next.onebot.botQq && !/^\d{5,15}$/.test(next.onebot.botQq)) throw Object.assign(new Error('OneBot QQ 号格式无效'), { status: 400 })
    if (next.mode !== 'official' && !next.onebot.endpoint) throw Object.assign(new Error('OneBot 模式需要填写 Endpoint'), { status: 400 })
    if (next.mode !== 'onebot' && next.mode !== 'official' && !next.official.appId) throw Object.assign(new Error('混合模式需要填写官方机器人 AppID'), { status: 400 })
    service.config = next; await service.save(); await activate(); await service.applyMode(); return { ...service.publicConfig(), reloadRequired: false, status: service.status() }
  }))
}

/** 单域兼容别名：旧测试用 apply(ctx) 直接装配模式域。 */
export const apply = applyMode
