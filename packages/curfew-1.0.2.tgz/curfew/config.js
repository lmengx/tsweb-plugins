export const error = (status, message) => Object.assign(new Error(message), { status });
export const defaultMessage = '当前为宵禁时段，服务器暂时禁止进服！\n[当前时间] {now}\n[预计恢复] {endTime}（还剩 {timeLeft}）\n[可进服组] {allowedGroups}';
export function groups(value) {
  if (value == null) return [];
  if (!Array.isArray(value) || value.some(x => typeof x !== 'string')) throw error(400, '豁免组须为文本列表');
  const seen = new Set();
  return value.map(x => x.trim()).filter(x => x && !seen.has(x.toLowerCase()) && seen.add(x.toLowerCase()));
}
export function time(value) {
  if (typeof value !== 'string' || !/^\d{1,2}:\d{2}$/.test(value)) throw error(400, '时间须为 HH:mm');
  const [h, m] = value.split(':').map(Number);
  if (h > 23 || m > 59) throw error(400, '时间超出范围');
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}
export function day(value) {
  const parsed = typeof value === 'string' ? new Date(value + 'T00:00:00Z') : new Date(NaN);
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || value < '0001-01-01' || value > '9998-12-31' || !Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value) throw error(400, '日期无效');
  return value;
}
export function validateConfig(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw error(400, '配置须为对象');
  if (value.version != null && value.version !== 1) throw error(400, '不支持此配置版本');
  const text = (x, fallback = '') => { if (x != null && typeof x !== 'string') throw error(400, '名称和消息须为文本'); return x ?? fallback; };
  if (!Array.isArray(value.entries) || value.entries.length > 200) throw error(400, '规则须为列表，最多 200 条');
  const ids = new Set();
  const entries = value.entries.map(e => {
    if (!e || typeof e !== 'object' || Array.isArray(e) || typeof e.id !== 'string' || !e.id.trim() || ids.has(e.id)) throw error(400, '规则 ID 为空或重复');
    ids.add(e.id);
    if (typeof e.enabled !== 'boolean' || typeof e.repeatDaily !== 'boolean') throw error(400, '规则开关须为布尔值');
    const r = { id: e.id, name: text(e.name).trim(), enabled: e.enabled, repeatDaily: e.repeatDaily, startTime: time(e.startTime), endTime: time(e.endTime), startDate: '', endDate: '', message: text(e.message), exemptGroups: groups(e.exemptGroups) };
    if (!r.repeatDaily) {
      r.startDate = day(e.startDate); r.endDate = day(e.endDate);
      if (r.endDate + r.endTime <= r.startDate + r.startTime) throw error(400, '指定日期排期的结束须晚于开始');
    }
    return r;
  });
  return { version: 1, defaultMessage: text(value.defaultMessage, defaultMessage), exemptGroups: groups(value.exemptGroups ?? ['owner', 'superadmin']), entries };
}
