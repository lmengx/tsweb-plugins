const actions = [
  { id: 'curfew.config.read', method: 'GET', path: '/api/curfew/config' },
  { id: 'curfew.config.save', method: 'POST', path: '/api/curfew/config' },
].map(action => ({ ...action, module: 'curfew.manage', scope: 'server' }));
export default {
  owner: 'curfew', version: 2,
  modules: [{ id: 'curfew.manage', permission: 'curfew.manage', title: '宵禁管理',
    roles: ['superadmin', 'admin'], scope: 'server', requires: actions.map(a => a.id) }],
  actions,
  features: [{ id: 'curfew:manage', module: 'curfew.manage', requires: actions.map(a => a.id) }],
};
