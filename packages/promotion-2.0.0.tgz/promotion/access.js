// Module permissions authorize both UI features and their backend routes.
export default {
  "owner": "promotion",
  "version": 2,
  "modules": [
    {
      "id": "promotion.promotion",
      "permission": "promotion.ui.promotion",
      "title": "权限提升",
      "roles": [
        "superadmin"
      ],
      "scope": "global",
      "requires": [
        "promotion.get.promotion.config",
        "promotion.post.promotion.config",
        "promotion.get.promotion.status",
        "promotion.get.promotion.groups",
        "promotion.post.promotion.push",
        "promotion.get.promotion.audit"
      ]
    }
  ],
  "actions": [
    {
      "id": "promotion.get.promotion.config",
      "method": "GET",
      "path": "/api/promotion/config",
      "scope": "global",
      "module": "promotion.promotion"
    },
    {
      "id": "promotion.post.promotion.config",
      "method": "POST",
      "path": "/api/promotion/config",
      "scope": "global",
      "module": "promotion.promotion"
    },
    {
      "id": "promotion.get.promotion.status",
      "method": "GET",
      "path": "/api/promotion/status",
      "scope": "global",
      "module": "promotion.promotion"
    },
    {
      "id": "promotion.get.promotion.groups",
      "method": "GET",
      "path": "/api/promotion/groups",
      "scope": "global",
      "module": "promotion.promotion"
    },
    {
      "id": "promotion.post.promotion.push",
      "method": "POST",
      "path": "/api/promotion/push",
      "scope": "global",
      "module": "promotion.promotion"
    },
    {
      "id": "promotion.get.promotion.audit",
      "method": "GET",
      "path": "/api/promotion/audit",
      "scope": "global",
      "module": "promotion.promotion"
    }
  ],
  "features": [
    {
      "id": "promotion:promotion",
      "module": "promotion.promotion",
      "requires": [
        "promotion.get.promotion.config",
        "promotion.post.promotion.config",
        "promotion.get.promotion.status",
        "promotion.get.promotion.groups",
        "promotion.post.promotion.push",
        "promotion.get.promotion.audit"
      ]
    }
  ]
}
