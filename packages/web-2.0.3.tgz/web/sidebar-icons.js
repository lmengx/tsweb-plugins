import {
  mkdir,
  readFile,
  writeFile,
  rename,
  readdir,
  unlink,
} from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { lookup } from "node:dns/promises";
import { BlockList, isIP } from "node:net";
import http from "node:http";
import https from "node:https";
// sharp's ESM entry uses import attributes absent from Node 20.9.
// Its supported CommonJS export has the same API and preserves our runtime floor.
import { createRequire } from "node:module";
const sharp = createRequire(import.meta.url)("sharp");
import { SaxesParser } from "saxes";

const LIMIT = 1024 * 1024;
const fail = (message) => Object.assign(new Error(message), { status: 400 });
const blocked = new BlockList();
for (const [address, prefix] of [
  ["0.0.0.0", 8],
  ["10.0.0.0", 8],
  ["100.64.0.0", 10],
  ["127.0.0.0", 8],
  ["169.254.0.0", 16],
  ["172.16.0.0", 12],
  ["192.0.0.0", 24],
  ["192.0.2.0", 24],
  ["192.168.0.0", 16],
  ["198.18.0.0", 15],
  ["198.51.100.0", 24],
  ["203.0.113.0", 24],
  ["224.0.0.0", 4],
  ["240.0.0.0", 4],
])
  blocked.addSubnet(address, prefix, "ipv4");
export function publicAddress(address) {
  const family = isIP(address);
  if (family === 4) return !blocked.check(address, "ipv4");
  // Only ordinary global unicast IPv6; reject mapped IPv4 and transition ranges.
  return (
    family === 6 &&
    /^[23][0-9a-f]{0,3}:/i.test(address) &&
    !/^200[12]:/i.test(address) &&
    !/^2001:(?:0*:|db8:)/i.test(address)
  );
}

export async function downloadIcon(input, resolve = lookup) {
  const signal = AbortSignal.timeout(10000);
  let url;
  try {
    url = new URL(input);
  } catch {
    throw fail("请输入有效的图片链接");
  }
  for (let redirects = 0; redirects <= 3; redirects++) {
    if (
      !["http:", "https:"].includes(url.protocol) ||
      url.username ||
      url.password
    )
      throw fail("只支持公开的 HTTP 或 HTTPS 图片链接");
    const hostname = url.hostname.replace(/^\[|\]$/g, "");
    const addresses = isIP(hostname)
      ? [{ address: hostname, family: isIP(hostname) }]
      : await Promise.race([
          resolve(hostname, { all: true, verbatim: true }),
          new Promise((_, reject) => {
            if (signal.aborted) reject(fail("图片下载超时"));
            else
              signal.addEventListener(
                "abort",
                () => reject(fail("图片下载超时")),
                { once: true },
              );
          }),
        ]);
    if (
      !addresses.length ||
      addresses.some((entry) => !publicAddress(entry.address))
    )
      throw fail("图片链接必须指向公开网络地址");
    const chosen = addresses[0];
    const response = await new Promise((resolveResponse, reject) => {
      const request = (url.protocol === "https:" ? https : http).get(
        url,
        {
          signal,
          headers: { Accept: "image/svg+xml,image/png,image/webp,image/jpeg" },
          lookup: (_host, options, callback) =>
            options?.all
              ? callback(null, [chosen])
              : callback(null, chosen.address, chosen.family),
        },
        resolveResponse,
      );
      request.on("error", () =>
        reject(
          fail(signal.aborted ? "图片下载超时" : "图片下载失败，请检查链接"),
        ),
      );
    });
    if ([301, 302, 303, 307, 308].includes(response.statusCode)) {
      response.resume();
      if (!response.headers.location || redirects === 3)
        throw fail("图片链接重定向过多");
      try {
        url = new URL(response.headers.location, url);
      } catch {
        throw fail("图片链接无效");
      }
      continue;
    }
    if (response.statusCode !== 200) {
      response.resume();
      throw fail("图片下载失败，请检查链接");
    }
    if (Number(response.headers["content-length"]) > LIMIT) {
      response.destroy();
      throw fail("图片不能超过 1 MiB");
    }
    const chunks = [];
    let size = 0;
    for await (const chunk of response) {
      size += chunk.length;
      if (size > LIMIT) {
        response.destroy();
        throw fail("图片不能超过 1 MiB");
      }
      chunks.push(chunk);
    }
    return Buffer.concat(chunks);
  }
}

const tags = new Set([
  "svg",
  "g",
  "path",
  "rect",
  "circle",
  "ellipse",
  "line",
  "polyline",
  "polygon",
  "defs",
  "linearGradient",
  "radialGradient",
  "stop",
  "clipPath",
  "mask",
  "title",
  "desc",
]);
const attributes = new Set([
  "xmlns",
  "viewBox",
  "width",
  "height",
  "x",
  "y",
  "x1",
  "x2",
  "y1",
  "y2",
  "cx",
  "cy",
  "r",
  "rx",
  "ry",
  "d",
  "points",
  "fill",
  "stroke",
  "stroke-width",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "fill-rule",
  "clip-rule",
  "opacity",
  "fill-opacity",
  "stroke-opacity",
  "transform",
  "id",
  "offset",
  "stop-color",
  "stop-opacity",
  "gradientUnits",
  "gradientTransform",
  "spreadMethod",
  "fx",
  "fy",
  "clip-path",
  "mask",
  "preserveAspectRatio",
  "version",
]);
const escape = (value) =>
  value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/"/g, "&quot;")
    .replace(/>/g, "&gt;");
export function sanitizeSvg(source) {
  if (/<!DOCTYPE|<!ENTITY/i.test(source)) throw fail("SVG 不支持外部实体");
  const parser = new SaxesParser({ xmlns: false });
  const output = [];
  let depth = 0,
    root = false;
  parser.on("error", () => {
    throw fail("SVG 格式无效");
  });
  parser.on("processinginstruction", ({ target }) => {
    if (target.toLowerCase() !== "xml") throw fail("SVG 不支持处理指令");
  });
  parser.on("opentag", (node) => {
    if (!tags.has(node.name) || (!depth && node.name !== "svg") || ++depth > 32)
      throw fail("SVG 包含不支持的内容");
    root = true;
    const attrs = [];
    for (const [name, value] of Object.entries(node.attributes)) {
      if (
        !attributes.has(name) ||
        /[\x00-\x08]/.test(value) ||
        (/(?:javascript:|data:|https?:|file:|@import|expression\s*\()/i.test(
          value,
        ) &&
          name !== "xmlns")
      )
        throw fail("SVG 包含外部内容或不支持的属性");
      if (name === "xmlns" && value !== "http://www.w3.org/2000/svg")
        throw fail("SVG 命名空间无效");
      if (/url\s*\(/i.test(value) && !/^url\(#[a-zA-Z0-9_-]+\)$/.test(value))
        throw fail("SVG 不能引用外部图片");
      attrs.push(`${name}="${escape(value)}"`);
    }
    output.push(`<${node.name}${attrs.length ? " " + attrs.join(" ") : ""}>`);
  });
  parser.on("closetag", (node) => {
    depth--;
    output.push(`</${node.name}>`);
  });
  parser.on("text", (text) => output.push(escape(text)));
  try {
    parser.write(source).close();
  } catch (error) {
    throw error.status ? error : fail("SVG 格式无效");
  }
  if (!root || depth) throw fail("SVG 格式无效");
  return Buffer.from(output.join(""));
}

export async function normalizeIcon(bytes) {
  if (!Buffer.isBuffer(bytes) || !bytes.length || bytes.length > LIMIT)
    throw fail("图片不能为空且不能超过 1 MiB");
  const text = bytes.toString("utf8").trimStart();
  const isSvg = text.startsWith("<");
  const input = isSvg ? sanitizeSvg(text) : bytes;
  try {
    const image = sharp(input, {
      limitInputPixels: 2048 * 2048,
      animated: false,
    });
    const meta = await image.metadata();
    if (
      !["svg", "png", "webp", "jpeg"].includes(meta.format) ||
      !meta.width ||
      !meta.height ||
      meta.width > 2048 ||
      meta.height > 2048 ||
      (meta.pages || 1) > 1
    )
      throw fail("只支持最长边不超过 2048 像素的静态 SVG、PNG、WebP、JPEG");
    // Normalize all external assets to inert, bounded PNGs; retain built-in SVGs.
    const data = await image
      .resize({
        width: 128,
        height: 128,
        fit: "inside",
        withoutEnlargement: true,
      })
      .png()
      .toBuffer();
    return { data, hash: createHash("sha256").update(data).digest("hex") };
  } catch (error) {
    throw error.status ? error : fail("无法读取图片，请换一张图片");
  }
}

export async function registerSidebarIcons(app, auth, edit, dir, getConfig) {
  const iconDir = path.join(dir, "icons");
  let queue = Promise.resolve();
  const exclusive = (operation) => {
    const result = queue.then(operation);
    queue = result.catch(() => {});
    return result;
  };
  const base = "/api/web/sidebar/icons";
  const hashOK = (hash) => /^[a-f0-9]{64}$/.test(hash);
  const filename = (hash) => path.join(iconDir, `${hash}.png`);
  const wrap = (fn) => async (req, res) => {
    try {
      await fn(req, res);
    } catch (error) {
      res
        .status(error.status || 500)
        .json({
          error: error.status ? error.message : "图标处理失败，请稍后重试",
        });
    }
  };
  app.get(
    base,
    auth.verifyAuth(),
    wrap(async (_req, res) => {
      const files = await readdir(iconDir).catch((error) => {
        if (error.code === "ENOENT") return [];
        throw error;
      });
      res.json({
        icons: files
          .filter((file) => /^[a-f0-9]{64}\.png$/.test(file))
          .sort()
          .map((file) => ({
            id: `asset:${file.slice(0, -4)}`,
            url: `${base}/${file.slice(0, -4)}`,
          })),
      });
    }),
  );
  const store = async (bytes) => {
    const { data, hash } = await normalizeIcon(bytes);
    return exclusive(async () => {
      await mkdir(iconDir, { recursive: true });
      await writeFile(filename(hash) + ".tmp", data);
      await rename(filename(hash) + ".tmp", filename(hash));
      return { id: `asset:${hash}`, url: `${base}/${hash}` };
    });
  };
  app.post(
    base + "/import",
    auth.verifyAuth(),
    edit,
    wrap(async (req, res) => {
      if (typeof req.body?.url !== "string" || req.body.url.length > 4096)
        throw fail("请输入图片链接");
      res.json(await store(await downloadIcon(req.body.url)));
    }),
  );
  app.post(
    base + "/upload",
    auth.verifyAuth(),
    edit,
    wrap(async (req, res) => {
      const data = req.body?.data;
      if (
        typeof data !== "string" ||
        data.length > Math.ceil(LIMIT / 3) * 4 ||
        !/^[a-zA-Z0-9+/]+={0,2}$/.test(data)
      )
        throw fail("图片不能为空且不能超过 1 MiB");
      res.json(await store(Buffer.from(data, "base64")));
    }),
  );
  app.get(
    base + "/:hash",
    auth.verifyAuth(),
    wrap(async (req, res) => {
      if (!hashOK(req.params.hash))
        return res.status(404).json({ error: "图标不存在" });
      const data = await readFile(filename(req.params.hash)).catch((error) => {
        if (error.code === "ENOENT")
          throw Object.assign(fail("图标不存在"), { status: 404 });
        throw error;
      });
      res
        .set({
          "Content-Type": "image/png",
          "X-Content-Type-Options": "nosniff",
          "Cache-Control": "private, max-age=31536000, immutable",
          "Content-Security-Policy": "default-src 'none'",
        })
        .send(data);
    }),
  );
  app.delete(
    base + "/:hash",
    auth.verifyAuth(),
    edit,
    wrap(async (req, res) =>
      exclusive(async () => {
        if (!hashOK(req.params.hash)) throw fail("图标标识无效");
        if (JSON.stringify(getConfig()).includes(`asset:${req.params.hash}`))
          throw Object.assign(fail("图标仍在使用，请先更换后保存布局"), {
            status: 409,
          });
        await unlink(filename(req.params.hash)).catch((error) => {
          if (error.code !== "ENOENT") throw error;
        });
        res.json({ ok: true });
      }),
    ),
  );
  return {
    exclusive,
    async validateReferences(layout) {
      for (const item of [
        ...Object.values(layout.nodes),
        ...Object.values(layout.overrides),
      ]) {
        if (item.icon?.startsWith("asset:"))
          await readFile(filename(item.icon.slice(6))).catch(() => {
            throw fail("所选图标不存在，请重新选择");
          });
      }
    },
  };
}
