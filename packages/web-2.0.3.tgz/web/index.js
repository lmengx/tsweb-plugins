import accessContract from './access.js'
/**
 * TSWeb 最简前端插件（cordis）
 *
 * 职责：
 *   - 静态托管 public/（index.html 直接访问 http://<host>:<port>/）
 *   - 提供 GET /api/me 校验当前登录态（JWT），供前端启动时确认会话
 *   - 保存全局侧边栏显示与排序配置（只控制前端导航）
 *
 * 依赖：accounts 插件（ctx.auth）提供 verifyAuth() 中间件。
 * 登录/登出本身走 accounts 的 /api/auth/* 接口；本插件不重复实现鉴权。
 */
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import express from 'express'
import { registerSidebarConfig } from './sidebar-config.js'

export const name = 'web'
export const inject = ['webServer', 'auth', 'paths']

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PUBLIC_DIR = path.join(__dirname, 'public')

export async function apply(ctx) {
  const app = ctx.auth.access.policyApp(ctx.webServer.app, accessContract, ctx)
  try { await registerSidebarConfig(app, ctx.auth, ctx.paths.dataOf('web')) }
  catch (error) { console.error('[web] 侧边栏配置初始化失败: ' + error.message); throw error }

  // 当前登录用户信息（前端启动时校验 token 用）
  app.get('/api/me', ctx.auth.verifyAuth(), (req, res) => {
    res.json({ ...req.user, qqBindAvailable: !!ctx.auth.identityProvider })
  })

  // 静态前端（express.static 默认把 index.html 挂在 / 上）
  app.use(express.static(PUBLIC_DIR))

  console.log(`[web] 前端插件已挂载: http://localhost:${ctx.webServer.port}/`)
}
