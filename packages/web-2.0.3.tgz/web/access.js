// Module permissions authorize both UI features and their backend routes.
export default {
  "owner": "web",
  "version": 2,
  "modules": [
    {
      "id": "web.overview",
      "permission": "web.ui.overview",
      "title": "总览",
      "roles": [
        "superadmin",
        "admin",
        "subadmin"
      ],
      "scope": "server",
      "requires": [
        "servers.get.servers.id.status",
        "servers.get.servers.id.progress",
        "servers.get.servers.id.players",
        "base.get.base.players.list",
        "base.get.base.bans.list"
      ]
    },
    {
      "id": "web.servers",
      "permission": "web.ui.servers",
      "title": "服务器管理",
      "roles": [
        "superadmin"
      ],
      "scope": "global",
      "requires": [
        "servers.get.servers",
        "servers.post.servers",
        "servers.post.servers.test",
        "servers.put.servers.id",
        "servers.delete.servers.id",
        "servers.post.servers.id.test",
        "servers.post.servers.id.connect",
        "servers.post.servers.id.disconnect",
        "servers.get.servers.id.connection",
        "servers.get.servers.id.console.history",
        "servers.get.servers.id.status",
        "servers.get.servers.id.progress",
        "servers.get.servers.id.players",
        "servers.post.servers.id.command",
        "servers.post.servers.id.broadcast",
        "servers.get.servers.id.details",
        "init.get.setup.platform",
        "init.get.setup.probe",
        "init.post.setup.auto.read",
        "init.post.setup.auto.remote",
        "init.post.setup.auto.verify",
        "registry.get.plugins.servers.serverId"
      ]
    },
    {
      "id": "web.plugins",
      "permission": "web.ui.plugins",
      "title": "已安装插件",
      "roles": [
        "superadmin"
      ],
      "scope": "global",
      "requires": [
        "registry.get.plugins",
        "registry.get.plugins.available",
        "registry.post.plugins.install",
        "registry.post.plugins.name.enable",
        "registry.post.plugins.name.disable",
        "registry.post.plugins.name.deploy",
        "registry.post.plugins.name.undeploy",
        "registry.get.plugins.servers.serverId",
        "registry.delete.plugins.name",
        "servers.get.servers"
      ]
    },
    {
      "id": "web.sidebar",
      "permission": "web.ui.sidebar",
      "title": "侧边栏设置",
      "roles": [
        "superadmin"
      ],
      "scope": "global",
      "requires": [
        "web.get.web.sidebar",
        "web.put.web.sidebar",
        "web.get.web.sidebar.icons",
        "web.get.web.sidebar.icons.hash",
        "web.post.web.sidebar.icons.import",
        "web.post.web.sidebar.icons.upload",
        "web.delete.web.sidebar.icons.hash"
      ]
    },
    {
      "id": "web.common",
      "permission": "web.module.common",
      "title": "面板基础访问",
      "roles": [
        "superadmin",
        "admin",
        "subadmin",
        "custom"
      ],
      "scope": "global",
      "requires": [
        "web.get.me",
        "web.get.web.sidebar",
        "web.get.web.sidebar.icons",
        "web.get.web.sidebar.icons.hash"
      ],
      "grantable": false
    }
  ],
  "actions": [
    {
      "id": "web.get.me",
      "method": "GET",
      "path": "/api/me",
      "scope": "global",
      "module": "web.common"
    },
    {
      "id": "web.get.web.sidebar",
      "method": "GET",
      "path": "/api/web/sidebar",
      "scope": "global",
      "module": "web.common"
    },
    {
      "id": "web.put.web.sidebar",
      "method": "PUT",
      "path": "/api/web/sidebar",
      "scope": "global",
      "module": "web.sidebar"
    },
    {
      "id": "web.get.web.sidebar.icons",
      "method": "GET",
      "path": "/api/web/sidebar/icons",
      "scope": "global",
      "module": "web.common"
    },
    {
      "id": "web.get.web.sidebar.icons.hash",
      "method": "GET",
      "path": "/api/web/sidebar/icons/:hash",
      "scope": "global",
      "module": "web.common"
    },
    {
      "id": "web.post.web.sidebar.icons.import",
      "method": "POST",
      "path": "/api/web/sidebar/icons/import",
      "scope": "global",
      "module": "web.sidebar"
    },
    {
      "id": "web.post.web.sidebar.icons.upload",
      "method": "POST",
      "path": "/api/web/sidebar/icons/upload",
      "scope": "global",
      "module": "web.sidebar"
    },
    {
      "id": "web.delete.web.sidebar.icons.hash",
      "method": "DELETE",
      "path": "/api/web/sidebar/icons/:hash",
      "scope": "global",
      "module": "web.sidebar"
    }
  ],
  "features": [
    {
      "id": "web:overview",
      "module": "web.overview",
      "requires": [
        "servers.get.servers.id.status",
        "servers.get.servers.id.progress",
        "servers.get.servers.id.players",
        "base.get.base.players.list",
        "base.get.base.bans.list"
      ]
    },
    {
      "id": "web:servers",
      "module": "web.servers",
      "requires": [
        "servers.get.servers",
        "servers.post.servers",
        "servers.post.servers.test",
        "servers.put.servers.id",
        "servers.delete.servers.id",
        "servers.post.servers.id.test",
        "servers.post.servers.id.connect",
        "servers.post.servers.id.disconnect",
        "servers.get.servers.id.connection",
        "servers.get.servers.id.console.history",
        "servers.get.servers.id.status",
        "servers.get.servers.id.progress",
        "servers.get.servers.id.players",
        "servers.post.servers.id.command",
        "servers.post.servers.id.broadcast",
        "servers.get.servers.id.details",
        "init.get.setup.platform",
        "init.get.setup.probe",
        "init.post.setup.auto.read",
        "init.post.setup.auto.remote",
        "init.post.setup.auto.verify",
        "registry.get.plugins.servers.serverId"
      ]
    },
    {
      "id": "web:plugins",
      "module": "web.plugins",
      "requires": [
        "registry.get.plugins",
        "registry.get.plugins.available",
        "registry.post.plugins.install",
        "registry.post.plugins.name.enable",
        "registry.post.plugins.name.disable",
        "registry.post.plugins.name.deploy",
        "registry.post.plugins.name.undeploy",
        "registry.get.plugins.servers.serverId",
        "registry.delete.plugins.name",
        "servers.get.servers"
      ]
    },
    {
      "id": "web:sidebar",
      "module": "web.sidebar",
      "requires": [
        "web.get.web.sidebar",
        "web.put.web.sidebar",
        "web.get.web.sidebar.icons",
        "web.get.web.sidebar.icons.hash",
        "web.post.web.sidebar.icons.import",
        "web.post.web.sidebar.icons.upload",
        "web.delete.web.sidebar.icons.hash"
      ]
    }
  ]
}
