import { openBlock as l, createElementBlock as i, createElementVNode as u, toDisplayString as h, renderSlot as $, createCommentVNode as p, inject as L, ref as b, watch as E, onUnmounted as U, unref as _, onMounted as S, createBlock as O, Teleport as N, withModifiers as T, isRef as A, normalizeClass as x, createVNode as B, Fragment as y, createTextVNode as k, withDirectives as j, vModelText as D, renderList as V } from "vue";
import { onBeforeRouteLeave as z } from "vue-router";
const Me = Object.freeze({
  OVERVIEW: 0,
  CONSOLE: 100,
  PLAYERS: 200,
  GROUPS: 300,
  AFTER_BASE: 400,
  MORE_PLUGINS: 800
}), we = Object.freeze({
  PLUGINS: 100,
  MARKET: 200,
  ACCOUNTS: 300,
  QQ_BIND: 400,
  IMPORT: 600,
  SIDEBAR: 700
});
function H(e) {
  e[6] = e[6] & 15 | 64, e[8] = e[8] & 63 | 128;
  const o = Array.from(
    e,
    (a) => a.toString(16).padStart(2, "0")
  ).join("");
  return `${o.slice(0, 8)}-${o.slice(8, 12)}-${o.slice(12, 16)}-${o.slice(16, 20)}-${o.slice(20)}`;
}
function xe(e = globalThis.crypto) {
  if (typeof (e == null ? void 0 : e.randomUUID) == "function")
    return e.randomUUID();
  if (typeof (e == null ? void 0 : e.getRandomValues) != "function")
    throw new Error(
      "当前浏览器不支持安全随机数；请使用现代浏览器，或通过 HTTPS / localhost 访问面板"
    );
  return H(e.getRandomValues(new Uint8Array(16)));
}
const g = (e, o) => {
  const a = e.__vccOpts || e;
  for (const [s, r] of o)
    a[s] = r;
  return a;
}, G = { class: "ui-card" }, Z = { key: 0 }, J = {
  __name: "UiCard",
  props: { title: String },
  setup(e) {
    return (o, a) => (l(), i("section", G, [
      e.title || o.$slots.actions ? (l(), i("header", Z, [
        u(
          "h2",
          null,
          h(e.title),
          1
          /* TEXT */
        ),
        $(o.$slots, "actions", {}, void 0, !0)
      ])) : p("v-if", !0),
      $(o.$slots, "default", {}, void 0, !0)
    ]));
  }
}, $e = /* @__PURE__ */ g(J, [["__scopeId", "data-v-b01648e1"]]), R = {
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  "arrow-right": '<path d="M5 12h14m-6-6 6 6-6 6"/>',
  grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>',
  terminal: '<path d="m4 5 6 6-6 6M12 19h8"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/><circle cx="9" cy="7" r="4"/>',
  layers: '<path d="m12 2 10 5-10 5L2 7l10-5ZM2 12l10 5 10-5M2 17l10 5 10-5"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/>',
  box: '<path d="m12 3 9 5v8l-9 5-9-5V8l9-5ZM3 8l9 5 9-5M12 13v8"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',
  message: '<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8v.5Z"/>',
  server: '<rect x="3" y="3" width="18" height="7" rx="2"/><rect x="3" y="14" width="18" height="7" rx="2"/><path d="M7 6.5h.01M7 17.5h.01"/>',
  key: '<circle cx="8" cy="8" r="5"/><path d="m12 12 9 9m-3-3 3-3m-6 0 3-3"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6ZM14 2v6h6M8 13h8M8 17h6"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>',
  moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8Z"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  close: '<path d="m6 6 12 12M6 18 18 6"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M9 12h12m-4-4 4 4-4 4"/>',
  refresh: '<path d="M20 7v5h-5M4 17v-5h5M6.1 6a8 8 0 0 1 13.2 2L20 12M4 12l.7 4A8 8 0 0 0 18 18"/>'
}, K = ["src"], q = ["innerHTML"], F = {
  __name: "NavIcon",
  props: { name: { type: String, default: "grid" } },
  setup(e) {
    const o = e, a = L(Symbol.for("tsweb.vue.host"), { state: {} }), s = b("");
    let r = 0;
    return E(
      () => [o.name, a.state.token],
      async () => {
        const c = ++r;
        if (s.value && URL.revokeObjectURL(s.value), s.value = "", !(!/^asset:[a-f0-9]{64}$/.test(o.name) || !a.state.token))
          try {
            const n = await fetch(
              "/api/web/sidebar/icons/" + o.name.slice(6),
              { headers: { Authorization: "Bearer " + a.state.token } }
            );
            if (!n.ok) return;
            const t = await n.blob();
            c === r && (s.value = URL.createObjectURL(t));
          } catch {
          }
      },
      { immediate: !0 }
    ), U(() => {
      r++, s.value && URL.revokeObjectURL(s.value);
    }), (c, n) => s.value ? (l(), i("img", {
      key: 0,
      src: s.value,
      class: "nav-icon nav-asset",
      width: "18",
      height: "18",
      alt: ""
    }, null, 8, K)) : (l(), i("svg", {
      key: 1,
      class: "nav-icon",
      width: "18",
      height: "18",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      "stroke-width": "1.7",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "aria-hidden": "true",
      innerHTML: _(R)[e.name.replace(/^builtin:/, "")] || _(R).grid
    }, null, 8, q));
  }
}, Q = /* @__PURE__ */ g(F, [["__scopeId", "data-v-93ab719e"]]), W = ["aria-label"], Y = {
  __name: "UiModal",
  props: {
    title: String,
    contained: Boolean,
    closeOnBackdrop: { type: Boolean, default: !0 }
  },
  emits: ["close"],
  setup(e, { emit: o }) {
    const a = e, s = o, r = b(null);
    let c, n = !1;
    function t() {
      a.closeOnBackdrop && n && s("close"), n = !1;
    }
    function f(d) {
      if (!([...document.querySelectorAll('[role="dialog"]')].at(-1) !== r.value || d.defaultPrevented) && (d.key === "Escape" && s("close"), d.key === "Tab")) {
        const v = [
          ...r.value.querySelectorAll(
            'button,input,select,textarea,[tabindex="0"]'
          )
        ].filter((I) => !I.disabled), M = v[0], w = v.at(-1);
        d.shiftKey && document.activeElement === M ? (d.preventDefault(), w == null || w.focus()) : !d.shiftKey && document.activeElement === w && (d.preventDefault(), M == null || M.focus());
      }
    }
    return S(() => {
      c = document.activeElement, r.value.focus(), document.addEventListener("keydown", f);
    }), U(() => {
      document.removeEventListener("keydown", f), c == null || c.focus();
    }), (d, m) => (l(), O(N, { to: "#tsweb-overlays" }, [
      u(
        "div",
        {
          class: "ui-backdrop",
          onPointerdown: m[1] || (m[1] = (v) => A(n) ? n.value = v.target === v.currentTarget && v.button === 0 : n = v.target === v.currentTarget && v.button === 0),
          onPointercancel: m[2] || (m[2] = (v) => A(n) ? n.value = !1 : n = !1),
          onClick: T(t, ["self"])
        },
        [
          u("section", {
            ref_key: "dialog",
            ref: r,
            class: x(["ui-modal", { "ui-modal-contained": e.contained }]),
            role: "dialog",
            "aria-modal": "true",
            "aria-label": e.title,
            tabindex: "-1"
          }, [
            u("header", null, [
              u(
                "h2",
                null,
                h(e.title),
                1
                /* TEXT */
              ),
              u("button", {
                class: "icon-button",
                "aria-label": "关闭",
                title: "关闭",
                onClick: m[0] || (m[0] = (v) => s("close"))
              }, [
                B(Q, { name: "close" })
              ])
            ]),
            $(d.$slots, "default", {}, void 0, !0)
          ], 10, W)
        ],
        32
        /* NEED_HYDRATION */
      )
    ]));
  }
}, Ue = /* @__PURE__ */ g(Y, [["__scopeId", "data-v-9cffa337"]]), P = {
  key: 0,
  class: "ui-error",
  role: "alert"
}, X = {
  key: 1,
  role: "status",
  class: "ui-loading"
}, ee = {
  __name: "UiResource",
  props: { loading: Boolean, error: String },
  emits: ["retry"],
  setup(e) {
    return (o, a) => (l(), i(
      y,
      null,
      [
        e.error ? (l(), i("p", P, [
          k(
            h(e.error) + " ",
            1
            /* TEXT */
          ),
          u("button", {
            onClick: a[0] || (a[0] = (s) => o.$emit("retry"))
          }, "重试")
        ])) : p("v-if", !0),
        e.loading ? (l(), i("p", X, "正在加载…")) : $(o.$slots, "default", {}, void 0, !0, 2)
      ],
      64
      /* STABLE_FRAGMENT */
    ));
  }
}, Ve = /* @__PURE__ */ g(ee, [["__scopeId", "data-v-b2643e50"]]), te = { class: "ui-json" }, ne = {
  key: 0,
  role: "alert"
}, oe = {
  __name: "UiJsonEditor",
  props: {
    modelValue: [Object, Array],
    label: { type: String, default: "高级编辑" }
  },
  emits: ["update:modelValue"],
  setup(e, { emit: o }) {
    const a = e, s = o, r = b(""), c = b("");
    E(
      () => a.modelValue,
      (t) => {
        r.value = JSON.stringify(t ?? {}, null, 2);
      },
      { immediate: !0 }
    );
    function n() {
      try {
        const t = JSON.parse(r.value);
        if (!t || typeof t != "object")
          throw new Error("请输入完整对象或数组");
        c.value = "", s("update:modelValue", t);
      } catch (t) {
        c.value = t.message;
      }
    }
    return (t, f) => (l(), i("div", te, [
      u("label", null, [
        k(
          h(e.label),
          1
          /* TEXT */
        ),
        j(u(
          "textarea",
          {
            "onUpdate:modelValue": f[0] || (f[0] = (d) => r.value = d),
            spellcheck: "false",
            rows: "15"
          },
          null,
          512
          /* NEED_PATCH */
        ), [
          [D, r.value]
        ])
      ]),
      c.value ? (l(), i(
        "p",
        ne,
        h(c.value),
        1
        /* TEXT */
      )) : p("v-if", !0),
      u("button", { onClick: n }, "应用编辑")
    ]));
  }
}, Ee = /* @__PURE__ */ g(oe, [["__scopeId", "data-v-2e5c8bd7"]]), ae = {
  class: "ui-pager",
  "aria-label": "分页"
}, se = ["disabled"], le = ["disabled"], ie = {
  __name: "UiPager",
  props: {
    page: Number,
    total: Number,
    size: { type: Number, default: 20 }
  },
  emits: ["update:page"],
  setup(e) {
    return (o, a) => (l(), i("nav", ae, [
      u("button", {
        disabled: e.page <= 1,
        onClick: a[0] || (a[0] = (s) => o.$emit("update:page", e.page - 1))
      }, " 上一页", 8, se),
      u(
        "span",
        null,
        "第 " + h(e.page) + " 页 / 共 " + h(Math.max(1, Math.ceil(e.total / e.size))) + " 页",
        1
        /* TEXT */
      ),
      u("button", {
        disabled: e.page * e.size >= e.total,
        onClick: a[1] || (a[1] = (s) => o.$emit("update:page", e.page + 1))
      }, " 下一页 ", 8, le)
    ]));
  }
}, Se = /* @__PURE__ */ g(ie, [["__scopeId", "data-v-cab5d29f"]]), re = { class: "vote-list" }, ue = ["disabled", "onClick"], ce = {
  key: 0,
  class: "card-icon",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  "stroke-width": "1.5",
  "stroke-linecap": "round",
  "stroke-linejoin": "round",
  "aria-hidden": "true"
}, de = { class: "card-title" }, fe = {
  key: 0,
  class: "danger-badge"
}, me = {
  key: 1,
  class: "mini-tag"
}, he = {
  key: 2,
  class: "card-subs"
}, ve = {
  key: 3,
  class: "card-desc"
}, pe = {
  key: 4,
  class: "confirm-hint"
}, ye = {
  __name: "UiInitChoices",
  props: { modelValue: null, cards: { type: Array, default: () => [] }, disabled: Boolean },
  emits: ["update:modelValue", "next"],
  setup(e, { emit: o }) {
    const a = e, s = o;
    function r(c) {
      a.disabled || (a.modelValue === c.key ? s("next") : s("update:modelValue", c.key));
    }
    return (c, n) => (l(), i(
      y,
      null,
      [
        n[7] || (n[7] = u(
          "p",
          { class: "vote-hint" },
          "单击选项选中，再点一次确认并进入下一步。",
          -1
          /* CACHED */
        )),
        u("div", re, [
          (l(!0), i(
            y,
            null,
            V(e.cards, (t) => (l(), i("button", {
              key: String(t.key),
              type: "button",
              class: x(["vote-card", { picked: e.modelValue === t.key, danger: t.danger, "hl-on": e.modelValue === t.key && t.warn }]),
              disabled: e.disabled,
              onClick: (f) => r(t)
            }, [
              t.icon ? (l(), i("svg", ce, [
                t.icon === "users" ? (l(), i(
                  y,
                  { key: 0 },
                  [
                    n[0] || (n[0] = u(
                      "circle",
                      {
                        cx: "9",
                        cy: "8",
                        r: "3.2"
                      },
                      null,
                      -1
                      /* CACHED */
                    )),
                    n[1] || (n[1] = u(
                      "path",
                      { d: "M2.5 19c.6-3.1 3.2-5 6.5-5s5.9 1.9 6.5 5" },
                      null,
                      -1
                      /* CACHED */
                    )),
                    n[2] || (n[2] = u(
                      "circle",
                      {
                        cx: "17",
                        cy: "9",
                        r: "2.4"
                      },
                      null,
                      -1
                      /* CACHED */
                    )),
                    n[3] || (n[3] = u(
                      "path",
                      { d: "M16 14.4c2.4.2 4.3 1.6 5 4.1" },
                      null,
                      -1
                      /* CACHED */
                    ))
                  ],
                  64
                  /* STABLE_FRAGMENT */
                )) : (l(), i(
                  y,
                  { key: 1 },
                  [
                    n[4] || (n[4] = u(
                      "circle",
                      {
                        cx: "12",
                        cy: "12",
                        r: "8.5"
                      },
                      null,
                      -1
                      /* CACHED */
                    )),
                    n[5] || (n[5] = u(
                      "path",
                      { d: "M3.6 12h16.8M12 3.5c2.7 2.2 4 5.3 4 8.5s-1.3 6.3-4 8.5c-2.7-2.2-4-5.3-4-8.5s1.3-6.3 4-8.5z" },
                      null,
                      -1
                      /* CACHED */
                    ))
                  ],
                  64
                  /* STABLE_FRAGMENT */
                ))
              ])) : p("v-if", !0),
              t.badge ? (l(), i(
                "span",
                {
                  key: 1,
                  class: x(["mini-badge", t.badge.cls])
                },
                h(t.badge.text),
                3
                /* TEXT, CLASS */
              )) : p("v-if", !0),
              u("span", de, [
                k(
                  h(t.title) + " ",
                  1
                  /* TEXT */
                ),
                e.modelValue === t.key && t.warn ? (l(), i("span", fe, [...n[6] || (n[6] = [
                  u(
                    "span",
                    { class: "danger-pulse" },
                    null,
                    -1
                    /* CACHED */
                  ),
                  k(
                    "危险",
                    -1
                    /* CACHED */
                  )
                ])])) : p("v-if", !0),
                t.current ? (l(), i("span", me, "当前状态")) : p("v-if", !0)
              ]),
              t.items ? (l(), i("ul", he, [
                (l(!0), i(
                  y,
                  null,
                  V(t.items, (f) => (l(), i(
                    "li",
                    { key: f },
                    h(f),
                    1
                    /* TEXT */
                  ))),
                  128
                  /* KEYED_FRAGMENT */
                ))
              ])) : p("v-if", !0),
              t.desc ? (l(), i("span", ve, [
                Array.isArray(t.desc) ? (l(!0), i(
                  y,
                  { key: 0 },
                  V(t.desc, (f, d) => (l(), i(
                    "span",
                    {
                      key: d,
                      class: x({ hl: f.highlight })
                    },
                    h(f.text),
                    3
                    /* TEXT, CLASS */
                  ))),
                  128
                  /* KEYED_FRAGMENT */
                )) : (l(), i(
                  y,
                  { key: 1 },
                  [
                    k(
                      h(t.desc),
                      1
                      /* TEXT */
                    )
                  ],
                  64
                  /* STABLE_FRAGMENT */
                ))
              ])) : p("v-if", !0),
              e.modelValue === t.key ? (l(), i("span", pe, "再点一次确认")) : p("v-if", !0)
            ], 10, ue))),
            128
            /* KEYED_FRAGMENT */
          ))
        ])
      ],
      64
      /* STABLE_FRAGMENT */
    ));
  }
}, _e = /* @__PURE__ */ g(ye, [["__scopeId", "data-v-07747b96"]]), be = Symbol.for("tsweb.vue.host");
function C() {
  const e = L(be);
  if (!e) throw new Error("Vue 插件必须挂载在 TSWeb 宿主内");
  return e;
}
function Ae(e, { server: o = !1 } = {}) {
  const a = C(), s = b(null), r = b(!1), c = b("");
  let n = 0, t;
  async function f() {
    const d = ++n;
    t == null || t.abort(), t = new AbortController(), r.value = !0, c.value = "";
    try {
      const m = await e(t.signal);
      d === n && (s.value = m);
    } catch (m) {
      d === n && m.name !== "AbortError" && (c.value = m.message);
    } finally {
      d === n && (r.value = !1);
    }
  }
  return S(f), o && E(
    () => a.state.serverId,
    () => {
      s.value = null, f();
    }
  ), U(() => {
    n++, t == null || t.abort();
  }), { data: s, loading: r, error: c, refresh: f };
}
function Re(e, ...o) {
  if (Array.isArray(e)) return e;
  for (const a of o) if (Array.isArray(e == null ? void 0 : e[a])) return e[a];
  return [];
}
function Le(e) {
  const o = C(), a = () => !e() || confirm("当前修改尚未保存，确认离开？");
  o.leaveGuards.add(a), z(() => o.state.disposing.length ? !0 : a());
  const s = (r) => {
    e() && (r.preventDefault(), r.returnValue = "");
  };
  S(() => window.addEventListener("beforeunload", s)), U(() => {
    o.leaveGuards.delete(a), window.removeEventListener("beforeunload", s);
  });
}
export {
  be as HostKey,
  Me as NAV_ORDER,
  we as SYSTEM_NAV_ORDER,
  $e as UiCard,
  _e as UiInitChoices,
  Ee as UiJsonEditor,
  Ue as UiModal,
  Se as UiPager,
  Ve as UiResource,
  xe as randomId,
  Re as rows,
  Le as useDirtyGuard,
  C as useHost,
  Ae as useResource
};
