const revision = new URL(import.meta.url).search;
const { default: access } = await import(`./access.js${revision}`);
const { WorldInfoService } = await import(`./service.js${revision}`);
export const name = "world-info";
export const inject = ["webServer", "auth", "servers", "tshock"];
export function apply(ctx) {
  try {
    const service = new WorldInfoService(ctx),
      controllers = new Set();
    const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx);
    ctx.on("dispose", () => {
      service.disposed = true;
      for (const controller of controllers) controller.abort();
    });
    const wrap = (write, operation) => async (req, res) => {
      const controller = new AbortController();
      controllers.add(controller);
      const closed = () => {
        if (!res.writableFinished) controller.abort();
      };
      res.on("close", closed);
      try {
        const id =
          req.headers["x-server-id"] ||
          req.query?.serverId ||
          req.user?.serverId ||
          req.user?.extraServerIds?.[0];
        const data = operation
          ? await service.npc(id, operation, req.body, controller.signal)
          : await service.call(id, write, req.body, controller.signal);
        if (!res.destroyed) res.json(data);
      } catch (err) {
        if (!res.headersSent && !res.destroyed)
          res.status(err.status || 502).json({ error: err.message });
      } finally {
        controllers.delete(controller);
        res.off("close", closed);
      }
    };
    app.get("/api/world-info/status", wrap(false));
    app.post("/api/world-info/apply", wrap(true));
    app.get("/api/world-info/npcs", wrap(false, "npcs"));
    app.post("/api/world-info/spawn", wrap(true, "spawn"));
  } catch (err) {
    console.error("[world-info] 初始化失败：" + err.message);
    throw err;
  }
}
