const actions = [
  { id: "world-info.read", method: "GET", path: "/api/world-info/status" },
  { id: "world-info.apply", method: "POST", path: "/api/world-info/apply" },
  { id: "world-info.npcs", method: "GET", path: "/api/world-info/npcs" },
  { id: "world-info.spawn", method: "POST", path: "/api/world-info/spawn" },
].map((action) => ({
  ...action,
  module: "world-info.manage",
  scope: "server",
}));
export default {
  owner: "world-info",
  version: 2,
  modules: [
    {
      id: "world-info.manage",
      permission: "world-info.manage",
      title: "世界信息管理",
      roles: ["superadmin", "admin", "subadmin"],
      scope: "server",
      requires: actions.map((a) => a.id),
    },
  ],
  actions,
  features: [
    {
      id: "world-info:manage",
      module: "world-info.manage",
      requires: actions.map((a) => a.id),
    },
  ],
};
