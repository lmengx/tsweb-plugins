const error = (status, message) =>
  Object.assign(new Error(message), { status });
export function validateChange(body) {
  if (
    !body ||
    typeof body.worldToken !== "string" ||
    !body.worldToken ||
    body.worldToken.length > 128
  )
    throw error(400, "请先读取当前世界");
  for (const key of ["fields", "expected"]) {
    const value = body[key];
    if (
      !value ||
      typeof value !== "object" ||
      Array.isArray(value) ||
      Object.keys(value).length > 128
    )
      throw error(400, "字段必须是 JSON 对象，且不超过 128 项");
    for (const [name, item] of Object.entries(value)) {
      if (
        !/^[a-zA-Z][a-zA-Z0-9]*$/.test(name) ||
        !["string", "number", "boolean"].includes(typeof item) ||
        (typeof item === "number" && !Number.isFinite(item)) ||
        (typeof item === "string" && item.length > 4096)
      )
        throw error(400, "字段格式无效：" + name);
    }
  }
  if (
    !Object.keys(body.fields).length ||
    Object.keys(body.fields).some((k) => !Object.hasOwn(body.expected, k))
  )
    throw error(400, "缺少待应用字段或原始值");
  return {
    worldToken: body.worldToken,
    fields: JSON.stringify(body.fields),
    expected: JSON.stringify(body.expected),
  };
}
export function validateSnapshot(data) {
  if (
    !data ||
    typeof data.worldToken !== "string" ||
    !data.fields ||
    !data.meta ||
    !Array.isArray(data.groups) ||
    !Array.isArray(data.progress?.Bosses) ||
    !Array.isArray(data.progress?.Events)
  )
    throw error(502, "游戏服返回的世界信息不完整，请更新插件");
  return data;
}
export function validateSpawn(body) {
  if (!body || typeof body.worldToken !== "string" || !body.worldToken || body.worldToken.length > 128)
    throw error(400, "请先读取当前世界");
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(body.requestId || ""))
    throw error(400, "生成请求标识无效");
  if (!Number.isInteger(body.npcId) || body.npcId < 1 || body.npcId > 100000)
    throw error(400, "请选择有效的 NPC");
  if (!Number.isInteger(body.count) || body.count < 1 || body.count > 20)
    throw error(400, "每次可生成 1 至 20 个 NPC");
  if (!["coordinates", "player"].includes(body.target)) throw error(400, "请选择生成位置");
  const params = { worldToken: body.worldToken, requestId: body.requestId, npcId: body.npcId, count: body.count, target: body.target };
  if (body.target === "player") {
    if (!Number.isInteger(body.playerId) || body.playerId < 0 || body.playerId > 254 ||
        typeof body.playerToken !== "string" || !/^[0-9a-f]{32}$/i.test(body.playerToken))
      throw error(400, "请选择当前在线的玩家");
    Object.assign(params, { playerId: body.playerId, playerToken: body.playerToken });
  } else {
    if (![body.x, body.y].every(v => Number.isInteger(v) && v >= 0 && v <= 100000))
      throw error(400, "坐标必须是世界范围内的整数格坐标");
    Object.assign(params, { x: body.x, y: body.y });
  }
  return params;
}
export class WorldInfoService {
  constructor(ctx) {
    this.ctx = ctx;
    this.disposed = false;
  }
  async npc(id, operation, body, signal) {
    if (this.disposed) throw error(503, "世界信息已停用");
    signal?.throwIfAborted();
    if (typeof id !== "string" || !id) throw error(400, "请先选择服务器");
    const server = this.ctx.servers.getRaw(id);
    if (!server) throw error(404, "服务器不存在");
    const write = operation === "spawn", params = write ? validateSpawn(body) : {};
    let response;
    try {
      response = await this.ctx.tshock[write ? "postFor" : "fetchFor"](server, "/data/world-info/" + operation, params, { timeoutMs: 12000 });
    } catch (err) {
      signal?.throwIfAborted();
      throw error(502, "连接游戏服失败：" + err.message);
    }
    signal?.throwIfAborted();
    if (this.disposed) throw error(503, "世界信息已停用");
    const data = response.data, status = Number(data?.status || response.status || 502);
    if (status === 404) throw error(501, "游戏服尚未启用 NPC 生成器，请更新世界信息插件");
    if (!response.ok || status >= 400 || !data || data.error)
      throw error([400, 409, 503].includes(status) ? status : 502, data?.error || "NPC 操作失败");
    if (write) {
      if (data.requestId !== body.requestId || !Number.isInteger(data.spawned) || data.spawned < 0 || data.spawned > body.count || !Array.isArray(data.npcIds) || data.npcIds.length !== data.spawned)
        throw error(502, "生成结果不完整，请先核对世界状态，勿重复提交");
    } else if (typeof data.worldToken !== "string" || !Array.isArray(data.npcs) || !Array.isArray(data.players) ||
      ![data.spawn?.x, data.spawn?.y, data.world?.width, data.world?.height].every(Number.isInteger))
      throw error(502, "生成器数据不完整，请更新世界信息插件");
    return data;
  }
  async call(id, write, body, signal) {
    if (this.disposed) throw error(503, "世界信息已停用");
    signal?.throwIfAborted();
    if (typeof id !== "string" || !id) throw error(400, "请先选择服务器");
    const server = this.ctx.servers.getRaw(id);
    if (!server) throw error(404, "服务器不存在");
    const params = write ? validateChange(body) : {};
    let response;
    try {
      response = await this.ctx.tshock[write ? "postFor" : "fetchFor"](
        server,
        "/data/world-info/" + (write ? "apply" : "status"),
        params,
        { timeoutMs: 12000 },
      );
    } catch (err) {
      signal?.throwIfAborted();
      throw error(502, "连接游戏服失败：" + err.message);
    }
    signal?.throwIfAborted();
    if (this.disposed) throw error(503, "世界信息已停用");
    const data = response.data,
      status = Number(data?.status || response.status || 502);
    if (status === 404)
      throw error(501, "所选游戏服尚未启用世界信息，请检查 DLL 同步状态");
    if (status === 401 || status === 403)
      throw error(502, "游戏服令牌缺少 tsweb.world-info.manage 权限");
    if (!response.ok || status >= 400 || !data || data.error)
      throw error(
        [400, 409, 503].includes(status) ? status : 502,
        data?.error || "读取世界信息失败",
      );
    if (!write) return validateSnapshot(data);
    if (
      !data.results ||
      typeof data.results !== "object" ||
      !Number.isInteger(data.applied) ||
      Object.keys(body.fields).some((k) => typeof data.results[k] !== "string")
    )
      throw error(502, "应用结果不完整，请重新读取核对");
    validateSnapshot(data.snapshot);
    return data;
  }
}
