/**
 * 本插件自己的追加型 JSONL 存储（审计 + 导入历史）
 *
 * 为什么不复用 plugins/qq-bind/audit.js：那是**另一个插件的文件**，跨插件相对 import 是硬依赖
 * （qq-bind 没装时本件在 import 阶段就崩），宿主也提示过跨插件相对路径可能拿到不同模块实例
 * （docs/插件开发约定.md:189）。两个文件都在自己的数据目录里，没有共享状态的必要。
 *
 * 语义与 qq-bind 的审计文件保持一致，便于运维用同一套方法读两份流水：
 *   - 追加写一行一个 JSON 对象；每行 JSON.parse 失败时**不抛**，降级成 parse-error 行
 *   - 单文件超过 MAX_BYTES 轮转为 <file>.1，避免无限增长
 *   - tail 返回**新的在前**
 */
import { appendFile, mkdir, readFile, rename, stat } from 'node:fs/promises'
import path from 'node:path'

/** 单文件上限（同 plugins/qq-bind/audit.js:12 的 8MB） */
const MAX_BYTES = 8 * 1024 * 1024

/**
 * 追加一条记录。
 * @param {string} file 目标文件（父目录不存在时自动创建）
 * @param {object} entry 任意可 JSON 序列化的对象（写入前把 t 补上——调用方也可以自己给）
 */
export async function appendJsonl(file, entry) {
  const row = entry && typeof entry === 'object' ? entry : { value: entry }
  const line = JSON.stringify({ t: row.t || new Date().toISOString(), ...row }) + '\n'
  await mkdir(path.dirname(file), { recursive: true })
  await rotateIfNeeded(file)
  await appendFile(file, line, 'utf8')
  return true
}

async function rotateIfNeeded(file) {
  try {
    const st = await stat(file)
    if (st.size >= MAX_BYTES) await rename(file, `${file}.1`)
  } catch (err) {
    if (err.code !== 'ENOENT') throw err
  }
}

/**
 * 读最近 n 条（新的在前）。文件不存在 → 空数组（首次使用时不是错误）。
 * @param {string} file
 * @param {number} [limit] 1..1000，缺省 50
 */
export async function tailJsonl(file, limit = 50) {
  const n = Math.min(Math.max(1, Number(limit) || 50), 1000)
  let raw
  try {
    raw = await readFile(file, 'utf8')
  } catch (err) {
    if (err.code === 'ENOENT') return []
    throw err
  }
  const lines = raw.split('\n').filter((l) => l.trim() !== '')
  const out = []
  for (let i = lines.length - 1; i >= 0 && out.length < n; i--) {
    try {
      out.push(JSON.parse(lines[i]))
    } catch {
      // 单行损坏（半行写入 / 手工编辑）不该让整个历史接口失败，如实标出来
      out.push({ t: null, action: 'parse-error', raw: lines[i].slice(0, 200) })
    }
  }
  return out
}
