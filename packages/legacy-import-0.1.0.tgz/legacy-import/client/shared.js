/**
 * legacy-import 前端半 —— 公共工具
 *
 * 顶层零副作用：只有函数定义，不注册任何东西、不碰 DOM。
 * （ESM 的 import 会被提升并顺序求值；工具模块若在顶层抛错，会让后面所有模块静默不注册。）
 *
 * 为什么自带一份而不是 import qq-bind 的 client/shared.js：
 * 浏览器里两个插件的 client bundle 是**两个独立 URL**（loader 的 clientUrl 形如
 * /plugins/<name>/client/<entry>.js，src/loader.js:186-216），跨插件 import 等于让本插件
 * 的前端半硬依赖另一个插件的前端半——qq-bind 没装或换版本都会把本页一起拖死。
 * 前端没有"服务注入"，所以这里的口径用注释与后端契约对齐，而不是共享模块。
 */

/** HTML 转义。所有插入 HTML 的用户数据（角色名 / QQ / 文件路径 / 后端回显）都必须过这里 */
export function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  })
}

/**
 * 安全请求封装：任何异常（网络断、宿主没提供 api、返回不是对象）都归一成
 * `{ ok:false, status:0, data:null, error:'...' }`，**永不抛错**。
 * window.tsweb.api 本身是 async 函数，fetch 失败会 reject（plugins/web/public/app.js:222-244）。
 */
export async function req(path, opts) {
  var tsw = window.tsweb
  if (!tsw || typeof tsw.api !== 'function') {
    return { ok: false, status: 0, data: null, error: '宿主未提供 window.tsweb.api' }
  }
  try {
    var res = await tsw.api(path, opts)
    if (!res || typeof res !== 'object') {
      return { ok: false, status: 0, data: null, error: '请求未返回结果' }
    }
    return res
  } catch (err) {
    return {
      ok: false,
      status: 0,
      data: null,
      error: err && err.message ? String(err.message) : String(err),
    }
  }
}

/**
 * 从 { ok, status, data, error } 里取一句给人看的错误原因。
 * 顺序：服务端 error 文本 > 鉴权类状态码的中文说明 > 网络层 error > HTTP 状态码。
 * 返回**纯文本**（调用方用 textContent 写入，不要拼进 HTML）。
 */
export function errText(res, fallback) {
  if (res && res.data && res.data.error) return String(res.data.error)
  if (res && res.status === 401) return '登录状态已失效（HTTP 401），请重新登录后再试'
  if (res && res.status === 403) return '当前账号没有管理权限（HTTP 403）'
  if (res && res.status === 404) return '接口不存在（HTTP 404）：宿主里的 legacy-import 后端半可能未启用或版本过旧'
  if (res && res.error) return String(res.error)
  if (res && res.status) return 'HTTP ' + res.status
  return fallback || '未知错误'
}

function pad2(n) {
  return (n < 10 ? '0' : '') + n
}

/**
 * 时间显示：ISO 字符串（审计/历史的 t）或 unix 秒/毫秒。
 * 无法解析时**原样返回**输入，不显示 Invalid Date。
 */
export function fmtTime(v) {
  if (v == null || v === '') return ''
  var s = String(v)
  var d
  if (/^\d+$/.test(s)) {
    var n = Number(s)
    if (!isFinite(n) || n <= 0) return s
    d = new Date(n < 1e12 ? n * 1000 : n)
  } else {
    d = new Date(s)
  }
  if (isNaN(d.getTime())) return s
  return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) +
    ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds())
}

/**
 * 快照下发结果 → 一句人话（结果如实回显，不假装成功）。
 * 形状依据 qq-bind 的 pushSnapshot()（plugins/qq-bind/index.js 的
 * { ok, version, total, okCount, servers:[{ id, name, ok, error, count, hashSent, upstreamVersion, serverHalfMissing }] }，
 * 没有启用中的服务器时是 { ok:true, total:0, servers:[], note }）。
 * 本插件不解释这个结构，只把它转成人话（数据由 qq-bind 生成）。
 */
export function snapshotText(sn) {
  if (!sn || typeof sn !== 'object') return ''
  var list = Array.isArray(sn.servers) ? sn.servers : []
  if (!list.length) {
    return sn.note ? '；快照未下发（' + String(sn.note) + '）' : ''
  }
  var okList = list.filter(function (s) { return s && s.ok })
  var badList = list.filter(function (s) { return !s || !s.ok })
  var text = '；快照下发 ' + okList.length + '/' + list.length + ' 台'
  if (badList.length) {
    text += '，失败：' + badList.map(function (s) {
      var who = (s && (s.name || s.id)) || '未知服务器'
      var why = s && s.error ? s.error : '未知原因'
      if (s && s.serverHalfMissing) why += '（该服未安装游戏服半 DLL）'
      return who + '（' + why + '）'
    }).join('；')
  }
  return text
}
