/**
 * legacy-import 前端半 —— 管理页「数据导入」（后端设置 → /b/legacy-import）
 *
 * 页面做四件事（对应本次任务的可用性要求）：
 *   1. 模块清单：列出当前可用的导入模块（标题 / 说明 / 来源提示），
 *      **不可用的显示原因并禁止选中**（原因由后端动态给出，见 plugins/legacy-import/index.js 的
 *      GET /api/legacy-import/modules）；
 *   2. 选模块 + 选来源（本插件数据目录内的文件路径 / 直接粘贴 JSON）；
 *   3. **先试运行**：dryRun=true 只出计划，把 新增 / 跳过 / 冲突 分别呈现，冲突逐条列出
 *      （这是旧版导入面板最重要的可用性，不省）；
 *   4. 确认后真正执行，并显示实际写入条数与快照下发结果。
 *
 * 请求全部走 window.tsweb.api（带 Bearer），并统一经 shared.js 的 req() 包一层：
 * 网络错误 / 401 / 404（插件被停用或后端半版本旧）都**不抛错**，如实显示在页面上。
 * 字段名逐条对着 plugins/legacy-import/index.js 与 modules/qq-ledger.js 的实现读过，没有猜的字段。
 *
 * 安全边界（与后端一致）：REST 的 file 分支只允许读**本插件数据目录**下的文件
 * （后端 readInsideDataDir 会拒绝 ../ 与绝对路径），页面把该目录原样显示出来，
 * 并提示"要导入目录外的文件请用终端命令"，避免用户反复试错。
 *
 * 约定：禁止 emoji；图标只用内联 SVG；样式类用 tswli- 前缀（避免与宿主及别的插件冲突）。
 */
import { esc, req, errText, fmtTime, snapshotText } from './shared.js'

var tsw = window.tsweb
var root = null
var styleDone = false

var state = {
  modules: [],
  dataDir: '',
  /** 当前选中的模块 id */
  moduleId: '',
  /** 来源：file（本插件数据目录内的文件） | json（粘贴 JSON） */
  source: 'file',
  /** 试运行结果：{ key, result }；key 用于判断"输入是否已改动" */
  plan: null,
  /** 真正执行的结果 */
  result: null,
  error: '',
  history: [],
  busy: false,
}

// ═══════════ 工具 ═══════════

function $(id) {
  return root ? root.querySelector('#' + id) : null
}

/** 消息区（textContent 写入，纯文本，也避免把后端错误当 HTML 解析） */
function setMsg(text, cls) {
  var el = $('tswli-msg')
  if (!el) return
  el.className = cls || 'muted'
  el.textContent = text || ''
}

/** 后台跑 promise 且不让异常逃逸（页面渲染回调里绝不允许 unhandledrejection） */
function background(p) {
  Promise.resolve(p).catch(function (err) {
    console.warn('[legacy-import] ' + ((err && err.message) || err))
  })
}

function currentModule() {
  for (var i = 0; i < state.modules.length; i++) {
    if (state.modules[i].id === state.moduleId) return state.modules[i]
  }
  return null
}

function arr(v) {
  return Array.isArray(v) ? v : []
}

// ═══════════ 样式 ═══════════

function injectStyle() {
  if (styleDone) return
  styleDone = true
  var st = document.createElement('style')
  st.textContent = [
    '.tswli-wrap{display:flex;flex-direction:column;gap:14px;min-width:0}',
    '.tswli-mods{display:flex;flex-direction:column;gap:8px}',
    // 模块行：沿用宿主的卡片语言（--border 描边 + --secondary 底），选中态用 --accent
    '.tswli-mod{display:flex;gap:10px;align-items:flex-start;padding:10px 12px;border:1px solid var(--border);',
    'border-radius:var(--radius-md);cursor:pointer;line-height:1.7;font-size:13px}',
    '.tswli-mod:hover{border-color:var(--accent)}',
    '.tswli-mod.on{border-color:var(--accent);background:var(--secondary)}',
    '.tswli-mod.off{opacity:.65;cursor:not-allowed}',
    '.tswli-mod input{width:auto;margin:2px 0 0;flex:0 0 auto}',
    '.tswli-mod .body{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}',
    '.tswli-mod .ttl{font-weight:600;display:flex;gap:8px;align-items:center;flex-wrap:wrap}',
    '.tswli-mod .desc{color:var(--foreground)}',
    '.tswli-hint{font-size:12px;color:var(--muted-foreground);line-height:1.75;margin:0;word-break:break-all}',
    '.tswli-hint code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}',
    '.tswli-row{display:flex;flex-direction:column;gap:6px;margin:0 0 12px}',
    '.tswli-row>label{font-size:12px;color:var(--muted-foreground)}',
    '.tswli-src{display:flex;gap:16px;align-items:center;flex-wrap:wrap;margin:0 0 10px;font-size:13px}',
    '.tswli-src label{display:flex;gap:6px;align-items:center;cursor:pointer;line-height:1.7}',
    '.tswli-src input{width:auto;margin:0}',
    '.tswli-acts{display:flex;gap:8px;align-items:center;flex-wrap:wrap}',
    '.tswli-result{padding:10px 12px;border:1px solid var(--border);border-radius:var(--radius-md);',
    'background:var(--secondary);line-height:1.9;font-size:13px}',
    '.tswli-result .scroll{overflow:auto;max-height:260px;margin-top:8px}',
    '.tswli-result table{font-size:13px}',
    '.tswli-msg{margin-top:10px;font-size:13px;line-height:1.7;min-height:18px;word-break:break-all}',
    '.tswli-msg.error{color:var(--danger)}',
    '.tswli-msg.ok{color:var(--ok)}',
    '.tswli-hidden{display:none}',
  ].join('')
  document.head.appendChild(st)
}

// ═══════════ 渲染：外壳 ═══════════

function shellHtml() {
  return '<div class="tswli-wrap">' +
    // 1) 模块清单
    '<div class="panel">' +
    '<h3>导入模块</h3>' +
    '<p class="tswli-hint" style="margin-bottom:10px">' +
    '本插件是「导入旧版数据」的容器，每种旧格式是一个独立模块；模块可以由其它插件贡献' +
    '（<code>ctx.legacyImport.registerModule</code>）。不可用的模块会给出原因（通常是它依赖的插件没装）。' +
    '</p>' +
    '<div class="tswli-mods" id="tswli-mods"></div>' +
    '</div>' +

    // 2) 输入 + 动作
    '<div class="panel">' +
    '<h3>导入</h3>' +
    '<div class="tswli-src">' +
    '<label><input type="radio" name="tswli-source" data-tswli-source="file">本插件数据目录内的文件</label>' +
    '<label><input type="radio" name="tswli-source" data-tswli-source="json">直接粘贴 JSON</label>' +
    '</div>' +
    '<div class="tswli-row" id="tswli-file-row">' +
    '<label>文件路径（相对本插件数据目录）</label>' +
    '<input id="tswli-file" placeholder="例如 qq_accounts.json">' +
    '<p class="tswli-hint" id="tswli-dir"></p>' +
    '</div>' +
    '<div class="tswli-row" id="tswli-json-row">' +
    '<label>旧数据 JSON</label>' +
    '<textarea id="tswli-json" rows="6" placeholder=\'{"records":{"角色名":{"qq":"12345","passwordHash":"..."}}}\'></textarea>' +
    '</div>' +
    '<div class="tswli-acts">' +
    '<button class="primary sm" data-tswli-act="dry">试运行（不写入）</button>' +
    '<button class="primary sm" id="tswli-run" data-tswli-act="run" disabled>确认导入</button>' +
    '<button class="ghost sm" data-tswli-act="refresh">刷新历史</button>' +
    '</div>' +
    '<div class="tswli-msg muted" id="tswli-msg"></div>' +
    '</div>' +

    // 3) 结果
    '<div class="panel">' +
    '<h3>结果</h3>' +
    '<div id="tswli-result"></div>' +
    '</div>' +

    // 4) 历史
    '<div class="panel">' +
    '<h3>导入历史</h3>' +
    '<div id="tswli-history"></div>' +
    '</div>' +
    '</div>'
}

/** 模块清单：不可用模块的 radio 直接 disabled，并显示原因 */
function modulesHtml() {
  if (!state.modules.length) {
    return '<p class="tswli-hint">没有可用的导入模块（后端未装载任何模块，或接口未就绪）。</p>'
  }
  return state.modules.map(function (m) {
    var on = m.id === state.moduleId
    var tags = []
    if (m.builtin) tags.push('<span class="badge">内置</span>')
    if (!m.available) tags.push('<span class="badge danger">不可用</span>')
    if (m.owner && m.owner !== 'legacy-import') tags.push('<span class="badge">' + esc(m.owner) + '</span>')
    return '<label class="tswli-mod' + (on ? ' on' : '') + (m.available ? '' : ' off') + '">' +
      '<input type="radio" name="tswli-mod" data-tswli-mod="' + esc(m.id) + '"' +
      (on ? ' checked' : '') + (m.available ? '' : ' disabled') + '>' +
      '<span class="body">' +
      '<span class="ttl">' + esc(m.title) + '<span class="tswli-hint">' + esc(m.id) + '</span>' + tags.join('') + '</span>' +
      (m.description ? '<span class="desc">' + esc(m.description) + '</span>' : '') +
      (m.sourceHint ? '<span class="tswli-hint">来源：' + esc(m.sourceHint) + '</span>' : '') +
      (m.available ? '' : '<span class="error">不可用原因：' + esc(m.reason || '未说明') + '</span>') +
      '</span></label>'
  }).join('')
}

/** 来源切换 + 数据目录提示 */
function syncInputArea() {
  var fileRow = $('tswli-file-row')
  var jsonRow = $('tswli-json-row')
  if (fileRow) fileRow.className = 'tswli-row' + (state.source === 'file' ? '' : ' tswli-hidden')
  if (jsonRow) jsonRow.className = 'tswli-row' + (state.source === 'json' ? '' : ' tswli-hidden')

  var dir = $('tswli-dir')
  if (dir) {
    dir.innerHTML = state.dataDir
      ? '本插件数据目录：<code>' + esc(state.dataDir) + '</code>（只允许读这里面的文件；' +
        '要导入目录外的文件请用终端命令 <code>legacy-import ' + esc(state.moduleId || 'qq-ledger') + ' &lt;路径&gt; [--dry]</code>）'
      : ''
  }
  var radios = root ? root.querySelectorAll('[data-tswli-source]') : []
  for (var i = 0; i < radios.length; i++) {
    radios[i].checked = radios[i].getAttribute('data-tswli-source') === state.source
  }
}

function renderModules() {
  var el = $('tswli-mods')
  if (el) el.innerHTML = modulesHtml()
  syncInputArea()
}

// ═══════════ 渲染：结果 ═══════════

/** 逐条表格（列表头 + 最多 max 行 + "另有 N 条未显示"） */
function rowsTable(title, headCells, rows, cellFn, max) {
  if (!rows.length) return ''
  var html = '<div class="scroll"><table><thead><tr><th>' + title + '</th>' +
    headCells.map(function (h) { return '<th>' + esc(h) + '</th>' }).join('') +
    '</tr></thead><tbody>' +
    rows.slice(0, max).map(function (r) {
      return '<tr><td>' + cellFn(r).join('</td><td>') + '</td></tr>'
    }).join('') +
    '</tbody></table></div>'
  if (rows.length > max) html += '<br>（另有 ' + (rows.length - max) + ' 条未显示）'
  return html
}

function resultHtml(r, label) {
  if (!r || typeof r !== 'object') return ''
  var imported = arr(r.imported)
  var skipped = arr(r.skipped)
  var conflicts = arr(r.conflicts)
  var issues = arr(r.parseIssues)
  var dry = r.dryRun === true

  var head = dry
    ? '<strong>' + esc(label || '试运行') + '：未写入台账</strong>'
    : (r.applied === true ? '<strong>已写入台账</strong>' : '<strong>没有可写入的条目</strong>（本次零新增）')

  var html = '<div class="tswli-result">' + head +
    '<br>新增 ' + imported.length + ' 条 · 跳过 ' + skipped.length + ' 条 · 冲突 ' + conflicts.length + ' 条'
  if (r.appliedCount != null) html += ' · 实际写入 ' + esc(r.appliedCount) + ' 条'
  if (r.sourceCount != null) html += '<br>源数据条目数 ' + esc(r.sourceCount) + '（含被跳过与冲突的）'
  if (!dry && r.applied === true) {
    html += '<br>' + esc(snapshotText(r.snapshot) || '；快照下发结果未返回')
  }
  if (r.moduleTitle) html += '<br><span class="tswli-hint">模块：' + esc(r.moduleTitle) + '（' + esc(r.module || '') + '）</span>'

  // 新增（试运行时是"计划新增"）
  html += rowsTable('新增', ['QQ 号'], imported, function (it) {
    return [esc(it && it.username), esc(it && it.qq)]
  }, 50)

  // 冲突：旧版最重要的可用性——逐条列出、绝不覆盖既有绑定
  html += rowsTable('冲突', ['说明'], conflicts, function (c) {
    var why = ''
    if (c && (c.existingQq != null || c.incomingQq != null)) {
      why = '台账已绑 ' + (c.existingQq != null ? c.existingQq : '?') + '，导入值为 ' + (c.incomingQq != null ? c.incomingQq : '?')
    } else if (c && (c.reason || c.error)) {
      why = c.reason || c.error
    } else {
      try { why = JSON.stringify(c) } catch (e) { why = '（无法显示）' }
    }
    return [esc(c && c.username), esc(why)]
  }, 50)

  html += rowsTable('跳过', ['QQ 号', '原因'], skipped, function (s) {
    return [esc(s && s.username), esc((s && s.qq) || ''), esc((s && s.reason) || '')]
  }, 30)

  /**
   * 解析预检：本插件在解析阶段做的"逐条可导入性检查"（modules/qq-ledger.js 的 parseIssues）。
   * 与上面「跳过」的关系要在页面上说清：同一批条目会被 qq-bind 台账按自己的文案再列一次，
   * 这里只是把"哪条坏、坏在哪"提前给出来，便于操作者先修文件再重导。
   */
  if (issues.length) {
    html += '<br><span class="tswli-hint">解析预检：' + issues.length + ' 条条目有问题（这些条目不会被写入；' +
      '台账那边还会以「跳过」再列一次，两处是同一批条目的两种视角）</span>'
    html += rowsTable('解析预检', ['原因'], issues, function (it) {
      return [esc(it && it.username), esc((it && it.reason) || '')]
    }, 30)
  }

  return html + '</div>'
}

function renderResult() {
  var el = $('tswli-result')
  if (!el) return
  if (state.error) {
    el.innerHTML = '<span class="error">' + esc(state.error) + '</span>'
    return
  }
  var html = ''
  if (state.plan) html += resultHtml(state.plan.result, '试运行计划')
  if (state.result) html += (html ? '<div style="height:10px"></div>' : '') + resultHtml(state.result, '执行结果')
  el.innerHTML = html || '<p class="tswli-hint">还没有执行结果。先点「试运行」看计划，确认后再「确认导入」。</p>'
}

/** 历史：时间 / 模块 / 模式 / 操作者 / 新增 / 跳过 / 冲突 / 写入 / 结果 */
function renderHistory() {
  var el = $('tswli-history')
  if (!el) return
  var rows = arr(state.history)
  if (!rows.length) {
    el.innerHTML = '<p class="tswli-hint">暂无导入历史。</p>'
    return
  }
  el.innerHTML = '<div class="scroll" style="overflow:auto;max-height:300px"><table>' +
    '<thead><tr><th>时间</th><th>模块</th><th>模式</th><th>操作者</th><th>入口</th>' +
    '<th>新增</th><th>跳过</th><th>冲突</th><th>写入</th><th>结果</th></tr></thead><tbody>' +
    rows.map(function (h) {
      var state_text = h.ok === false
        ? '<span class="error">失败：' + esc(h.error || '未说明') + '</span>'
        : (h.dryRun ? '<span class="muted">试运行</span>' : '<span class="ok">已执行</span>')
      return '<tr>' +
        '<td class="tswli-hint">' + esc(fmtTime(h.t)) + '</td>' +
        '<td>' + esc(h.moduleTitle || h.module || '') + '</td>' +
        '<td>' + (h.dryRun ? '试运行' : '执行') + '</td>' +
        '<td>' + esc(h.actor || '') + '</td>' +
        '<td class="tswli-hint">' + esc(h.via || '') + '</td>' +
        '<td>' + (h.imported == null ? '-' : esc(h.imported)) + '</td>' +
        '<td>' + (h.skipped == null ? '-' : esc(h.skipped)) + '</td>' +
        '<td>' + (h.conflicts == null ? '-' : esc(h.conflicts)) + '</td>' +
        '<td>' + (h.appliedCount == null ? '-' : esc(h.appliedCount)) + '</td>' +
        '<td>' + state_text + '</td>' +
        '</tr>'
    }).join('') +
    '</tbody></table></div>'
}

// ═══════════ 交互 ═══════════

/** 当前输入的"指纹"：输入一变，上一次的试运行计划就作废（防止"计划是 A、执行的是 B"） */
function inputKey() {
  var fileEl = $('tswli-file')
  var jsonEl = $('tswli-json')
  var file = String((fileEl && fileEl.value) || '').trim()
  var json = String((jsonEl && jsonEl.value) || '').trim()
  return state.moduleId + '|' + state.source + '|' + (state.source === 'file' ? file : json)
}

function planIsFresh() {
  return !!(state.plan && state.plan.key === inputKey())
}

function refreshButtons() {
  var run = $('tswli-run')
  var dry = root ? root.querySelector('[data-tswli-act="dry"]') : null
  var mod = currentModule()
  var usable = !!(mod && mod.available)
  var fresh = planIsFresh()
  if (dry) {
    dry.disabled = state.busy || !usable
    dry.title = usable ? '' : '当前模块不可用，不能导入'
  }
  if (run) {
    run.disabled = state.busy || !usable || !fresh
    run.title = fresh ? '' : '请先对当前输入做一次「试运行」，确认计划后再执行'
  }
}

/** 输入变化：作废过期的计划（只重渲染结果区，不动输入框，避免打断输入） */
function invalidateIfChanged() {
  if (state.plan && !planIsFresh()) {
    state.plan = null
    state.result = null
    state.error = ''
    renderResult()
    setMsg('输入已改动，请重新试运行', 'muted')
  }
  refreshButtons()
}

async function loadModules() {
  var res = await req('/api/legacy-import/modules')
  if (!res.ok || !res.data) {
    state.modules = []
    state.dataDir = ''
    renderModules()
    setMsg('读取模块清单失败：' + errText(res), 'error')
    return
  }
  state.modules = arr(res.data.modules)
  state.dataDir = String(res.data.dataDir || '')
  // 保持原选择；原选择不可用/不存在时退到第一个可用模块
  var keep = null
  for (var i = 0; i < state.modules.length; i++) {
    if (state.modules[i].id === state.moduleId) keep = state.modules[i]
  }
  if (!keep || !keep.available) {
    var first = null
    for (var j = 0; j < state.modules.length; j++) {
      if (state.modules[j].available) { first = state.modules[j]; break }
    }
    if (first) state.moduleId = first.id
  }
  renderModules()
  renderResult()
  refreshButtons()
}

async function loadHistory() {
  var res = await req('/api/legacy-import/history?limit=50')
  if (!res.ok || !res.data) {
    state.history = []
    renderHistory()
    return
  }
  state.history = arr(res.data.rows)
  renderHistory()
}

/**
 * 执行导入。dryRun=true → 只出计划；false → 真正写库（先弹确认，且必须已有同一输入的试运行计划）。
 *
 * 接口：POST /api/legacy-import/run { module, file | data, dryRun }
 * → { imported, skipped, conflicts, applied, appliedCount?, snapshot?, module, dryRun, actor, via }
 *   （dryRun 或零写入时 applied=false 且**没有** appliedCount，见 modules/registry.js 的
 *   normalizeRunResult 与 plugins/qq-bind/ledger.js:527-536）
 */
async function run(dryRun) {
  if (state.busy) return
  var mod = currentModule()
  if (!mod) { setMsg('请先选择一个导入模块', 'error'); return }
  if (!mod.available) { setMsg('模块「' + mod.title + '」当前不可用：' + (mod.reason || '未说明'), 'error'); return }

  var body = { module: state.moduleId, dryRun: !!dryRun }
  if (state.source === 'file') {
    var fileEl = $('tswli-file')
    var file = String((fileEl && fileEl.value) || '').trim()
    if (!file) { setMsg('请填写数据目录内的文件路径', 'error'); return }
    body.file = file
  } else {
    var jsonEl = $('tswli-json')
    var text = String((jsonEl && jsonEl.value) || '').trim()
    if (!text) { setMsg('请先粘贴旧数据 JSON', 'error'); return }
    try {
      body.data = JSON.parse(text)
    } catch (err) {
      setMsg('粘贴的内容不是合法 JSON：' + ((err && err.message) || err), 'error')
      return
    }
  }

  if (!dryRun) {
    if (!planIsFresh()) { setMsg('请先对当前输入做一次「试运行」，确认计划后再执行', 'error'); return }
    var p = (state.plan && state.plan.result) || {}
    var planned = arr(p.imported).length
    /**
     * 真正写库前二次确认：导入是**不可回退**的（台账只前进、冲突不覆盖），
     * 所以把"将要新增多少条"写进确认框，让操作者对着计划核对一次。
     * 一键导入的旧版没有这一步（它只有 dryRun 勾选框）。
     */
    if (!window.confirm('确认执行导入？\n\n模块：' + mod.title + '（' + mod.id + '）\n' +
      '将新增 ' + planned + ' 条绑定；跳过 ' + arr(p.skipped).length + ' 条；冲突 ' + arr(p.conflicts).length + ' 条（冲突不会覆盖既有绑定）。')) {
      return
    }
  }

  var key = inputKey()
  state.busy = true
  refreshButtons()
  setMsg(dryRun ? '正在试运行...' : '正在导入...', 'muted')

  var res = await req('/api/legacy-import/run', { method: 'POST', json: body })
  state.busy = false
  var d = res.data || {}

  if (!res.ok) {
    state.error = errText(res) + (d.reason ? '（' + d.reason + '）' : '')
    if (dryRun) state.plan = null
    else state.result = null
    renderResult()
    refreshButtons()
    setMsg(dryRun ? '试运行失败' : '导入失败', 'error')
    return
  }

  state.error = ''
  if (dryRun) {
    state.plan = { key: key, result: d }
    state.result = null
    var n = arr(d.imported).length
    setMsg('试运行完成：计划新增 ' + n + ' 条（未写入台账）', 'ok')
  } else {
    state.plan = null
    state.result = d
    setMsg(d.applied === true
      ? '导入完成：实际写入 ' + (d.appliedCount != null ? d.appliedCount : arr(d.imported).length) + ' 条'
      : '导入完成：本次没有可新增的条目（未产生写入）', 'ok')
    background(loadHistory())
    // 台账已变，模块清单本身不受影响，无需重载
  }
  renderResult()
  refreshButtons()
}

function onClick(ev) {
  var el = ev.target
  if (!el || !el.getAttribute) return
  var act = el.getAttribute('data-tswli-act')
  if (!act) return
  if (act === 'dry') background(run(true))
  else if (act === 'run') background(run(false))
  else if (act === 'refresh') background(loadHistory())
}

function onChange(ev) {
  var el = ev.target
  if (!el || !el.getAttribute) return
  var modId = el.getAttribute('data-tswli-mod')
  if (modId) {
    state.moduleId = modId
    state.plan = null
    state.result = null
    state.error = ''
    renderModules()
    renderResult()
    refreshButtons()
    return
  }
  var src = el.getAttribute('data-tswli-source')
  if (src) {
    state.source = src
    syncInputArea()
    invalidateIfChanged()
  }
}

function onInput(ev) {
  var el = ev.target
  if (!el || !el.id) return
  if (el.id === 'tswli-file' || el.id === 'tswli-json') invalidateIfChanged()
}

// ═══════════ 视图注册 ═══════════

if (tsw && typeof tsw.registerView === 'function') {
  try {
    tsw.registerView({
      id: 'legacy-import',
      title: '数据导入',
      section: '后端设置',
      path: '/b/legacy-import',
      icon: 'layers',
      render: function (container) {
        var first = root !== container
        root = container
        injectStyle()
        container.innerHTML = shellHtml()

        /**
         * 事件委托：每次进入本路由宿主都会再调一次 render(container)，而 container 是常驻的
         * #plugin-view-content（plugins/web/public/app.js:369-390）。无条件下 addEventListener
         * 会让监听器随访问次数累加（一次点击执行 N 次）；但又不能只靠"绑过一次"的标记：
         * 插件热重载会用带新 query 的 URL 重新 import，新实例若不重新绑定，点击会继续由旧
         * bundle 的闭包处理。所以按同一引用先解绑再绑（照 plugins/qq-bind/client/admin.js:1734-1750）。
         */
        if (container.__tswliClick) container.removeEventListener('click', container.__tswliClick)
        if (container.__tswliInput) container.removeEventListener('input', container.__tswliInput)
        if (container.__tswliChange) container.removeEventListener('change', container.__tswliChange)
        container.__tswliClick = onClick
        container.__tswliInput = onInput
        container.__tswliChange = onChange
        container.addEventListener('click', container.__tswliClick)
        container.addEventListener('input', container.__tswliInput)
        container.addEventListener('change', container.__tswliChange)

        // 首屏：模块清单 + 历史 + 结果（结果区在首次进入时是空态提示）
        state.busy = false
        if (first) {
          state.plan = null
          state.result = null
          state.error = ''
        }
        renderModules()
        renderResult()
        refreshButtons()
        background(loadModules())
        background(loadHistory())
      },
    })
    console.log('[tsweb] legacy-import 客户端插件已注册: #/b/legacy-import')
  } catch (err) {
    console.warn('[legacy-import] 注册管理页失败：' + ((err && err.message) || err))
  }
} else {
  console.warn('[legacy-import] 宿主未提供 window.tsweb.registerView，管理页未注册')
}
