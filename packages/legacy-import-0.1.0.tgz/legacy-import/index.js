/**
 * 导入旧版数据容器（legacy-import）—— 宿主侧半
 *
 * 定位：本件是"导入旧版数据"的**容器**，自身只做四件事：
 *   1. 用模块注册表（modules/registry.js）装载各个"导入模块"；
 *   2. 提供管理端 REST：列模块 / 执行导入 / 看历史；
 *   3. 提供终端命令（宿主装了 terminal 时）；
 *   4. 每次导入写审计（本件视角）+ 历史（页面用）。
 * 具体旧格式的**解析**在各模块里（内置 modules/qq-ledger.js），**落库**交回数据的所有者
 * （内置模块交回 qq-bind 的 ctx.qqBind.importLegacy，绝不自己写别家的数据文件）。
 *
 * 服务（供别的插件依赖）：
 *   ctx.legacyImport.registerModule({ id, title, description, sourceHint, run, check?, requires? })
 *   → 返回摘除函数。**建议用 ctx.inject(['legacyImport'], cb) 注册**（晚到补注册 + 卸载自动摘除），
 *     写法照 plugins/servers/index.js:1209-1230。
 *
 * 依赖：webServer / auth / paths（写进 inject）；
 *       qqBind 与 terminal 是**软依赖**，一律走 modules/registry.js 的 optionalService(ctx, name)
 *       ——不能写 `ctx.qqBind?.x`：未 inject 的服务是"访问即抛错"，可选链挡不住
 *       （docs/插件开发约定.md:139-142；本目录刚修过一次线上故障）。
 *
 * 约定：禁止 emoji；中文注释；状态数据走 ctx.paths.dataOf('legacy-import')（不在插件目录内）；
 *       路由与终端命令都在 apply 内同步注册（宿主用 AsyncLocalStorage 记账，见
 *       docs/插件开发约定.md:192-200）。
 */
import { Service } from '@deepseek-ai/cordis'
import { mkdir, readFile } from 'node:fs/promises'
import path from 'node:path'

import { ModuleRegistry, httpError, optionalService, normalizeRunResult } from './modules/registry.js'
import { createQqLedgerModule, MODULE_ID as QQ_LEDGER_MODULE_ID } from './modules/qq-ledger.js'
import { appendJsonl, tailJsonl } from './store.js'

export const name = 'legacy-import'
export const inject = ['webServer', 'auth', 'paths']

/** 审计动作名（沿用本仓 qq-bind 的 `qqbind.import` 风格：<域>.<动作>） */
const AUDIT_ACTION = 'legacyImport.run'

/** 历史接口默认/最大条数（与 qq-bind 审计接口的夹取口径一致，plugins/qq-bind/audit.js:52） */
const HISTORY_LIMIT_DEFAULT = 50
const HISTORY_LIMIT_MAX = 500

/** 前端"结果里最多逐条显示多少条"由前端决定；后端不截断（旧版同样全量返回） */

export class LegacyImportService extends Service {
  constructor(ctx) {
    super(ctx, 'legacyImport')
    /**
     * 保存构造时的 ctx 引用（宿主 apply 的作用域上下文）。
     * 不用 this.ctx 去取软依赖：Service.ctx 是 cordis 的**追踪代理**，在被服务方法调用时
     * 可能已被替换成带 symbols.shadow 的派生上下文（docs/插件开发约定.md:144-148），
     * 那个上下文解析出的服务集合未必是插件自己的。这里用构造入参，语义最直白。
     */
    this.hostCtx = ctx
    /** 模块注册表（纯逻辑，可脱离宿主导出单测） */
    this.registry = new ModuleRegistry()
    /** 数据目录（apply 里填）：<dataDir>/legacy-import */
    this.dataDir = ''
    this.auditFile = ''
    this.historyFile = ''
    /** 初始化信号（apply 内部建的 Promise；路由与执行都先 await 它） */
    this.ready = Promise.resolve()

    /** 内置模块：旧版 QQ 台账（本容器的第一个模块，也就是唯一"已核实存在"的旧格式） */
    this.registry.register(createQqLedgerModule())
  }

  /**
   * 注册一个导入模块（供**别的插件**贡献自己的导入模块）。
   * @param {object} desc 见 modules/registry.js 的 register 文档
   * @returns {Function} 摘除函数
   */
  registerModule(desc) {
    return this.registry.register(desc)
  }

  /** 摘除模块（一般不需要手调：注册时返回的 off 交给 cordis 即可） */
  unregisterModule(id) {
    return this.registry.unregister(id)
  }

  /** 模块清单（**每次调用重新评估可用性**，见 ModuleRegistry.list） */
  listModules() {
    return this.registry.list(this.hostCtx)
  }

  /**
   * 执行一次导入（REST 与终端命令共用的唯一入口）。
   *
   * @param {object} o
   * @param {string} o.module   模块 id
   * @param {object} o.input    模块载荷（{ kind:'json'|'file', file?, text?, data? }）
   * @param {boolean} [o.dryRun] 试运行
   * @param {string} [o.actor]  操作者（REST = 登录名，终端 = 'terminal'）
   * @param {string} [o.via]    'rest' | 'terminal'（审计里区分入口）
   * @returns {Promise<object>} 归一化结果 + module/dryRun/actor/appliedCount/snapshot
   */
  async runModule({ module: moduleId, input, dryRun = false, actor = 'admin', via = 'rest' } = {}) {
    await this.ready
    const entry = this.registry.resolve(moduleId, this.hostCtx)

    const at = new Date().toISOString()
    const base = {
      at,
      module: entry.id,
      moduleTitle: entry.title,
      dryRun: dryRun === true,
      actor: String(actor || ''),
      via: String(via || ''),
    }
    const startedAt = Date.now()

    let result
    try {
      result = normalizeRunResult(
        await entry.run(input, { dryRun: base.dryRun, actor: base.actor, ctx: this.hostCtx }),
      )
    } catch (err) {
      /**
       * 失败也留痕：模块抛错（格式不对、依赖服务在中途消失、落库异常）时，
       * "有人试过导入、失败了、原因是 X" 恰恰是排障最需要的信息。
       * 审计与历史各一条，不重复写同一条（两者的字段口径不同，见 _record）。
       */
      await this._record({
        ...base,
        ok: false,
        error: (err && err.message) || String(err),
        imported: null,
        skipped: null,
        conflicts: null,
        applied: false,
        appliedCount: null,
      })
      throw err
    }

    const record = {
      ...base,
      ok: true,
      error: '',
      imported: result.imported.length,
      skipped: result.skipped.length,
      conflicts: result.conflicts.length,
      applied: result.applied,
      appliedCount: result.appliedCount ?? null,
    }
    await this._record(record)

    return {
      ...result,
      module: entry.id,
      moduleTitle: entry.title,
      dryRun: base.dryRun,
      actor: base.actor,
      via: base.via,
      at,
      durationMs: Date.now() - startedAt,
    }
  }

  /**
   * 导入历史（新的在前）。
   * @param {number} [limit]
   */
  async history(limit = HISTORY_LIMIT_DEFAULT) {
    const n = Math.min(Math.max(1, Number(limit) || HISTORY_LIMIT_DEFAULT), HISTORY_LIMIT_MAX)
    return tailJsonl(this.historyFile, n)
  }

  /**
   * 落两条流水：
   *   - audit.jsonl   —— 本件视角的审计（action=legacyImport.run，字段含 module/dryRun/各计数/actor）
   *   - history.jsonl —— 管理页的历史列表（含模块标题，便于人读）
   * 注意：qq-bind 自己的 `qqbind.import` 会**另写一条**（台账视角）。两条并存是设计使然
   * （一条记"谁从哪个入口发起导入"、一条记"台账被改成了什么"），但本件绝不写 qqbind.* 动作名，
   * 避免同一条事实被记两遍。
   */
  async _record(rec) {
    const audit = {
      t: rec.at,
      action: AUDIT_ACTION,
      actor: rec.actor,
      via: rec.via,
      module: rec.module,
      dryRun: rec.dryRun,
      ok: rec.ok,
      imported: rec.imported,
      skipped: rec.skipped,
      conflicts: rec.conflicts,
      applied: rec.applied,
      appliedCount: rec.appliedCount,
    }
    if (rec.error) audit.error = rec.error
    await appendJsonl(this.auditFile, audit)

    await appendJsonl(this.historyFile, {
      t: rec.at,
      module: rec.module,
      moduleTitle: rec.moduleTitle,
      dryRun: rec.dryRun,
      via: rec.via,
      actor: rec.actor,
      ok: rec.ok,
      imported: rec.imported,
      skipped: rec.skipped,
      conflicts: rec.conflicts,
      applied: rec.applied,
      appliedCount: rec.appliedCount,
      error: rec.error || '',
    })
  }
}

// ══════════════════════════════════════════════════════════════
// apply
// ══════════════════════════════════════════════════════════════

/**
 * 插件入口。
 * 按 docs/插件开发约定.md:125-137 的约定：声明了 inject 的插件 apply 会**延迟执行**，
 * 期间的异常不会冒泡到加载器（表现成"加载成功但什么都没注册"），所以自己包一层并打印。
 */
export async function apply(ctx) {
  try {
    return await applyInner(ctx)
  } catch (err) {
    console.error('[legacy-import] 初始化失败: ' + err.message)
    if (process.env.TSWEB_DEBUG) console.error(err.stack)
    throw err
  }
}

async function applyInner(ctx) {
  const dataDir = ctx.paths.dataOf('legacy-import')
  const auditFile = path.join(dataDir, 'audit.jsonl')
  const historyFile = path.join(dataDir, 'history.jsonl')

  const service = new LegacyImportService(ctx)
  service.dataDir = dataDir
  service.auditFile = auditFile
  service.historyFile = historyFile

  /** 先挂服务：别的插件用 ctx.inject(['legacyImport'], ...) 时才有服务可等 */
  ctx.legacyImport = service

  const ready = (async () => {
    await mkdir(dataDir, { recursive: true })
    ctx.logger?.info?.(
      `[legacy-import] 数据目录就绪：${dataDir}（已装载模块 ${service.registry.ids().join(', ') || '(无)'}）`,
    )
  })()
  service.ready = ready
  // 先 await 再注册路由：让"数据目录建不出来"在 apply 阶段就暴露。
  // 仍在 apply 的异步链路内，宿主用 AsyncLocalStorage 记账不受影响
  // （plugins/online-stats/index.js:800 也是 await 之后才注册路由的既有先例）。
  await ready

  const app = ctx.webServer.app
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]

  /** 错误 → 状态码（字段透传口径照 plugins/qq-bind/index.js 的 fail：只带白名单字段） */
  const fail = (res, err) => {
    const status = err.status || 500
    const body = { error: err.message }
    for (const key of ['reason', 'module', 'missingPlugin', 'missingCapability', 'availableModules', 'hint']) {
      if (err[key] !== undefined) body[key] = err[key]
    }
    if (!res.headersSent) res.status(status).json(body)
  }
  const wrap = (handler) => async (req, res) => {
    try {
      await ready
      res.json(await handler(req, res))
    } catch (err) {
      fail(res, err)
    }
  }

  /**
   * 模块清单：GET /api/legacy-import/modules（admin）
   * → { ok, modules: [{ id, title, description, sourceHint, owner, builtin, requires, available, reason }], dataDir }
   *
   * dataDir 一并返回：REST 的 file 分支只允许读这个目录下的文件，
   * 页面必须能把这个目录原样显示给操作者（否则"文件该放哪"只能靠猜）。
   */
  app.get('/api/legacy-import/modules', ...admin, wrap(async () => ({
    ok: true,
    modules: service.listModules(),
    dataDir,
    historyLimit: { default: HISTORY_LIMIT_DEFAULT, max: HISTORY_LIMIT_MAX },
  })))

  /**
   * 执行导入：POST /api/legacy-import/run（admin）
   * body: { module: 'qq-ledger', file?: string, data?: any, dryRun?: boolean }
   *
   * 安全边界（照搬旧版 plugins/qq-bind/index.js 的 /api/qq-bind/import）：
   * file 分支**只允许读本插件数据目录下的文件**——path.resolve 之后做前缀校验，
   * 目录外的相对路径（../）与绝对路径都会被拒。理由：这条路由是**浏览器**能打的，
   * 一旦允许任意路径，任何登录的管理员都能把宿主机上的任意文件内容读出来
   * （错误信息里还会带上文件内容片段），等于开了一个读文件的口子。
   * 需要导入数据目录外的文件时，走终端命令（本机 stdin，见下方注释里的取舍说明）。
   *
   * data 分支不落盘、不读盘，只把 JSON 交给模块，因此没有路径问题；
   * 若同时给了 file 与 data，以 data 为准（与旧版一致）。
   */
  app.post('/api/legacy-import/run', ...admin, wrap(async (req) => {
    const b = req.body || {}
    const moduleId = String(b.module || '').trim()
    if (!moduleId) throw httpError(400, '缺少参数: module（导入模块 id）')

    const hasData = b.data !== undefined && b.data !== null
    const file = String(b.file || '').trim()
    if (!hasData && !file) throw httpError(400, '缺少参数: data 或 file')

    let input
    if (hasData) {
      input = { kind: 'json', data: b.data }
    } else {
      input = { kind: 'file', file, text: await readInsideDataDir(dataDir, file) }
    }

    return service.runModule({
      module: moduleId,
      input,
      dryRun: b.dryRun === true,
      actor: req.user?.username || 'admin',
      via: 'rest',
    })
  }))

  /** 导入历史：GET /api/legacy-import/history?limit=N（admin）→ { ok, rows, limit } */
  app.get('/api/legacy-import/history', ...admin, wrap(async (req) => {
    const limit = Number((req.query || {}).limit) || HISTORY_LIMIT_DEFAULT
    const clamped = Math.min(Math.max(1, limit), HISTORY_LIMIT_MAX)
    return { ok: true, rows: await service.history(clamped), limit: clamped, file: historyFile }
  }))

  // ── 终端命令（软依赖：宿主没装 terminal 时跳过，插件照常加载）──
  // 用 optionalService 而不是写进 inject：一个辅助命令不该把整个插件变成"依赖不满足即不可用"
  // （plugins/qq-bind/index.js 的 qqbind-import 同款取舍）。
  //
  // 安全边界的选择（与 REST 不同，是**刻意**的）：
  //   终端命令读**任意路径**。理由：能敲终端的人已经在宿主进程的机器上、且与宿主同权限
  //   （旧版 qqbind-import 就是这个口径，直接 readFile(file)）；而 REST 面向浏览器，
  //   必须假设"管理员账号可能被盗用"，所以只放开本插件数据目录。
  //   两者的差别在报告里显式写明，不做隐式放宽。
  //   注意：终端读文件后把**文本**交给模块，因此本件的"路径校验"仍然只存在于 REST 分支。
  try {
    const terminal = optionalService(ctx, 'terminal')
    if (terminal && typeof terminal.register === 'function') {
      terminal.register(
        'legacy-import',
        '导入旧版数据（用法: legacy-import <模块id> <文件路径> [--dry]；只给一个路径时按内置模块 ' +
          QQ_LEDGER_MODULE_ID + ' 处理）',
        async (args) => {
          const list = Array.isArray(args) ? args.map(String) : String(args || '').split(/\s+/)
          const dry = list.includes('--dry')
          const positional = list.filter((a) => a && !String(a).startsWith('--'))

          const usage = () => {
            console.log('用法: legacy-import <模块id> <文件路径> [--dry]')
            console.log(`  模块id 例如 ${QQ_LEDGER_MODULE_ID}（旧版 QQ 台账）；只给一个参数时按该内置模块处理`)
            const mods = service.listModules()
            console.log(
              '  当前模块: ' +
                (mods.map((m) => `${m.id}${m.available ? '' : `（不可用：${m.reason}）`}`).join('；') || '(无)'),
            )
          }

          // 解析参数：2 个位置参数 = 模块id + 文件；1 个 = 文件（用内置模块）
          let moduleId = QQ_LEDGER_MODULE_ID
          let file = ''
          if (positional.length === 0) {
            usage()
            return
          } else if (positional.length === 1) {
            if (service.registry.has(positional[0])) {
              // 只给了模块 id、没给文件：这是用法错误，不该被当成"文件叫 qq-ledger"
              console.log(`缺少文件路径（模块 ${positional[0]}）`)
              usage()
              return
            }
            file = positional[0]
          } else {
            moduleId = positional[0]
            file = positional[1]
          }

          let text
          try {
            text = await readFile(path.resolve(file), 'utf8')
          } catch (err) {
            console.log(`读取文件失败：${err.message}`)
            return
          }

          const r = await service.runModule({
            module: moduleId,
            input: { kind: 'file', file, text },
            dryRun: dry,
            actor: 'terminal',
            via: 'terminal',
          })

          console.log(
            `${dry ? '[试运行，未写入] ' : ''}新增 ${r.imported.length}　跳过 ${r.skipped.length}　冲突 ${r.conflicts.length}` +
              (r.appliedCount != null ? `　实际写入 ${r.appliedCount}` : ''),
          )
          if (Array.isArray(r.parseIssues) && r.parseIssues.length > 0) {
            console.log(`解析预检：${r.parseIssues.length} 条条目有问题（台账会逐条跳过）`)
            for (const it of r.parseIssues.slice(0, 20)) {
              console.log(`  ${it.username || '(空角色名)'}：${it.reason || ''}`)
            }
          }
          for (const c of r.conflicts.slice(0, 20)) {
            console.log(`  冲突：${c.username}　${conflictText(c)}`)
          }
          if (r.conflicts.length > 20) {
            console.log(`  （另有 ${r.conflicts.length - 20} 条冲突未显示）`)
          }
          if (!dry && r.applied) {
            console.log(`已写台账并下发快照：成功 ${r.snapshot?.okCount ?? 0}/${r.snapshot?.total ?? 0} 台`)
          }
        },
      )
    }
  } catch (err) {
    ctx.logger?.warn?.(`[legacy-import] 终端命令 legacy-import 注册跳过：${err.message}`)
  }

  ctx.logger?.info?.(
    `[legacy-import] 已挂载：模块 ${service.registry.ids().join(', ') || '(无)'}；数据目录 ${dataDir}`,
  )

  /**
   * 释放钩子：本件没有定时器与外部句柄，路由与终端命令由宿主按 apply 记账自动摘除
   * （docs/插件开发约定.md:192-200；src/loader.js 的 removeLayers / terminalCommands）。
   * 返回一个函数而不是 undefined：与仓库其它插件一致，便于宿主统一调用。
   */
  return () => {}
}

/**
 * 只在**本插件数据目录内**读文件（REST 的 file 分支唯一入口）。
 *
 * 三步都不能省：
 *   1. path.resolve 把相对路径（含 ../、带盘符的绝对路径）解析成绝对路径；
 *   2. 前缀校验必须带上 `path.sep`：否则 `<dataDir>-other/x.json` 这种"同前缀的兄弟目录"
 *      会绕过去（旧版 plugins/qq-bind/index.js:1393-1396 就是这么写的，这里照搬并补注释）；
 *   3. 显式区分 ENOENT / EISDIR：让用户看到"文件不存在"或"这是目录"，
 *      而不是一个 500 加一段栈。
 */
async function readInsideDataDir(dataDir, file) {
  const base = path.resolve(dataDir)
  const resolved = path.resolve(base, String(file))
  if (resolved !== base && !resolved.startsWith(base + path.sep)) {
    throw httpError(400, '只允许读取本插件数据目录下的文件')
  }
  try {
    return await readFile(resolved, 'utf8')
  } catch (err) {
    if (err.code === 'ENOENT') {
      throw httpError(404, `文件不存在：${file}（相对本插件数据目录 ${base}）`)
    }
    if (err.code === 'EISDIR') {
      throw httpError(400, `这是一个目录，不是文件：${file}`)
    }
    throw err
  }
}

/**
 * 冲突条目 → 一句人话。
 * 台账的两种冲突形状（plugins/qq-bind/ledger.js:506、:512）：
 *   { username, existingQq, incomingQq }  —— 同名异 QQ
 *   { username, qq, reason }              —— 该 QQ 已属他人
 * 旧版终端只打 reason，于是第一种冲突显示成空字符串；这里两种都给人话。
 */
function conflictText(c) {
  if (!c || typeof c !== 'object') return ''
  if (c.existingQq !== undefined || c.incomingQq !== undefined) {
    return `台账已绑 ${c.existingQq ?? '?'}，导入值为 ${c.incomingQq ?? '?'}`
  }
  return String(c.reason || c.error || '')
}
