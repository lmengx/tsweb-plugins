/**
 * 导入模块注册表（本容器的核心）
 *
 * 定位：本插件是"导入旧版数据"的**容器**，本身不认识任何具体旧格式；
 * 每个旧格式解析器都是一个**模块**，通过这里的注册表挂进来。
 *   - 内置模块：modules/qq-ledger.js（旧版 QQ 台账 → qq-bind 台账）
 *   - 外部模块：别的插件用 `ctx.legacyImport.registerModule({...})` 贡献（见 index.js 的
 *     apply 注释与 test/registry.test.mjs 的用例；软依赖写法照 plugins/servers/index.js:1209-1230）
 *
 * 为什么做成注册表而不是在本件里写 if/else：
 *   1. "导入旧版数据"是一个**会持续加长**的清单（旧台账、旧昵称、旧群配置…），
 *      每加一种就在容器里改一次分支，容器迟早变成什么都懂的上帝对象；
 *   2. 每种旧格式的**解析**天然属于提供该数据的那一族插件（旧 QQ 台账的知识在 qq-bind 一族，
 *      旧服务器列车的知识在 servers 一族），容器只该负责"选模块、跑模块、记审计";
 *   3. 注册表让"可用性"变成**动态**的：模块的依赖服务没装时标记为不可用并给出原因，
 *      而不是让整个容器加载失败（本件的硬约束，见 qq-ledger 的 check）。
 *
 * 本文件只放纯逻辑（无 ctx 副作用、不读盘），因此可以脱离宿主单测：
 *   node test/registry.test.mjs
 */

/**
 * 模块 id 形态：小写字母开头，允许小写字母/数字/连字符（与 qq-bind 能力名的域名段同风格，
 * 见 plugins/qq-bind/adapters/registry.js:22）。用它当 REST 参数与审计字段，所以必须收口。
 */
export const MODULE_ID_RE = /^[a-z][a-z0-9-]*$/

/**
 * 带 HTTP 语义的错误（路由层据 err.status 直接回状态码）。
 *
 * 为什么不从别处 import：plugins/qq-bind/ledger.js:37 有同款实现，但**跨插件相对 import
 * 是硬依赖**——qq-bind 没装时本件在 import 阶段就会失败，整个插件加载不起来。
 * 宿主也明确提示过跨插件相对路径可能拿到不同模块实例（docs/插件开发约定.md:189）。
 * 容器要能在"一个导入模块都没有"的环境里正常加载，所以这类 10 行小工具各自保留一份。
 */
export function httpError(status, message, extra = {}) {
  const err = new Error(message)
  err.status = status
  Object.assign(err, extra)
  return err
}

/**
 * 取**可选**服务（软依赖）。
 *
 * 为什么不能直接写 `ctx.qqBind?.importLegacy`：cordis 的 ctx 代理对**没写进 inject** 的服务
 * 是"访问即抛错"——`@deepseek-ai/cordis/lib/index.js` 的 Proxy get 陷阱在 fiber.inject 里找不到
 * 该 prop 就 `throw new Error('cannot get property "x" without inject')`，可选链 `?.` **挡不住**
 * （抛出的是属性访问本身，见 docs/插件开发约定.md:139-142；本目录刚修过一次线上故障）。
 *
 * 为什么也不把 qqBind 写进 inject：inject 的语义是"等依赖就绪再 apply"，
 * 而 qq-bind 对本件是**软依赖**（它只是内置模块之一的数据落库方）。写进 inject 会让
 * "没装 qq-bind"变成"整个导入容器不加载"——恰恰违反本次的核心要求（模块不可用要降级、
 * 而不是让插件加载失败）。
 *
 * 两级取法：
 *   1. `ctx.get(name)`：服务**注册过**（Service 子类 + super(ctx, 'name')）时命中；
 *      未注册时返回 undefined，**不抛**（实测：@deepseek-ai/cordis 的 Context.get 对未知名返回 undefined）。
 *      注意它**看不到**"普通赋值"挂上去的属性（`ctx.foo = {...}` 对 get 不可见），
 *      所以测试里的假服务要靠第 2 级兜底。
 *   2. `ctx[name]`：包在 try 里读，未 inject 时抛错就当作没有。
 */
export function optionalService(ctx, name) {
  try {
    if (ctx && typeof ctx.get === 'function') {
      const svc = ctx.get(name)
      if (svc) return svc
    }
  } catch {
    /* 取不到就当没有：软依赖失败一律降级，绝不冒泡成"插件加载失败" */
  }
  try {
    return (ctx && ctx[name]) || null
  } catch {
    /* 未 inject 的 ctx 代理在这里抛错：按"没有该服务"处理 */
    return null
  }
}

/**
 * 归一化模块返回结果。
 *
 * 为什么由容器统一做：模块可能来自别的插件，返回形状不可控（漏字段、写成 null、数组写对象）。
 * 容器是唯一写审计与回给前端的地方，若在此处抛错，用户看到的会是 500 而不是"导入本身的结果"。
 * 归一化保证：`imported/skipped/conflicts` 恒为数组，`applied` 恒为布尔，
 * `dryRun` 或零写入时**不产生** appliedCount（对齐 plugins/qq-bind/ledger.js:527-536 的契约）。
 *
 * 非保留字段**原样带出**（浅拷贝）：外部模块可以返回自己的附加信息（例如它自己的解析告警），
 * 容器不解释、只透传，避免"新模式要改容器"。
 */
const RESERVED_KEYS = new Set([
  'imported', 'skipped', 'conflicts', 'applied', 'appliedCount', 'snapshot', 'note',
])

export function normalizeRunResult(raw) {
  const r = raw && typeof raw === 'object' ? raw : {}
  const list = (v) => (Array.isArray(v) ? v : [])
  const out = {
    imported: list(r.imported),
    skipped: list(r.skipped),
    conflicts: list(r.conflicts),
    applied: r.applied === true,
    snapshot: r.snapshot && typeof r.snapshot === 'object' ? r.snapshot : null,
  }
  if (r.appliedCount !== undefined && r.appliedCount !== null) {
    out.appliedCount = Number(r.appliedCount) || 0
  }
  if (r.note !== undefined && r.note !== null) out.note = String(r.note)
  for (const [k, v] of Object.entries(r)) {
    if (RESERVED_KEYS.has(k)) continue
    out[k] = v
  }
  return out
}

export class ModuleRegistry {
  constructor() {
    /** @type {Map<string, object>} id -> 归一化后的模块描述 */
    this._mods = new Map()
  }

  /**
   * 注册一个导入模块。
   *
   * @param {object} desc
   * @param {string} desc.id          唯一 id（小写 kebab，如 qq-ledger）；REST 的 module 参数就是它
   * @param {string} desc.title       页面显示名（中文）
   * @param {string} [desc.description] 一句话说明（这是什么数据、导入到哪里）
   * @param {string} [desc.sourceHint]  旧文件的形态提示（文件名 / JSON 形状），给操作者照着准备文件
   * @param {Function} desc.run       async (input, { dryRun, actor, ctx }) => 结果对象
   * @param {Function} [desc.check]   (ctx) => boolean | { available, reason }，**每次列表/执行时重新评估**
   * @param {string[]} [desc.requires] 需要的 ctx 服务名（便捷写法，等价于用 check 判 ctx.get）
   * @param {string} [desc.owner]     贡献方插件名（审计与页面归属显示用）
   * @param {boolean} [desc.builtin]  是否本容器内置（仅用于页面标注，不参与权限判定）
   * @returns {Function} 摘除函数（照 cordis 惯例返回 off，供贡献方在 dispose 时调用；
   *                      plugins/servers/index.js:1209-1230 就是这么把 off 交回给 cordis 的）
   */
  register(desc) {
    const d = desc && typeof desc === 'object' ? desc : {}
    const id = String(d.id || '').trim()
    if (!MODULE_ID_RE.test(id)) {
      throw new Error(`导入模块 id 不合法：${d.id}（应形如小写 kebab，如 qq-ledger）`)
    }
    const title = String(d.title || '').trim()
    if (!title) throw new Error(`导入模块 ${id} 缺少 title（页面要显示它）`)
    if (typeof d.run !== 'function') {
      throw new Error(`导入模块 ${id} 缺少 run(input, { dryRun, actor }) 函数`)
    }
    /**
     * id 冲突必须**抛错**而不是覆盖：两个模块同名时，"谁被跑"取决于加载顺序，
     * 而审计里只有 id——那就等于事后无法还原"这次导入到底跑的是谁的解析器"。
     */
    if (this._mods.has(id)) {
      throw new Error(`导入模块 id 已注册：${id}（id 必须唯一；如需替换请先 unregister）`)
    }
    this._mods.set(id, {
      id,
      title,
      description: String(d.description || ''),
      sourceHint: String(d.sourceHint || ''),
      owner: String(d.owner || ''),
      builtin: d.builtin === true,
      requires: Array.isArray(d.requires) ? d.requires.map(String).filter(Boolean) : [],
      check: typeof d.check === 'function' ? d.check : null,
      run: d.run,
    })
    return () => this.unregister(id)
  }

  /** 摘除模块；返回是否真的删掉了（宿主 disable 时幂等调用） */
  unregister(id) {
    return this._mods.delete(String(id || '').trim())
  }

  get(id) {
    return this._mods.get(String(id || '').trim()) || null
  }

  has(id) {
    return this._mods.has(String(id || '').trim())
  }

  /** 当前已注册的模块 id（注册顺序：内置模块最先） */
  ids() {
    return [...this._mods.keys()]
  }

  /**
   * 评估某个模块此刻是否可用。
   * 返回值恒为 `{ available, reason, missingPlugin }`；check 抛错也算"不可用 + 原因"，
   * 因为一个坏掉的可用性检查不该让整个模块清单接口 500。
   *
   * `missingPlugin` 是可选的：模块的 check 可以告诉调用方"我缺的是哪个插件"，
   * 由 resolve() 带进 501 的响应体，前端才能给出"该装哪个插件"这句可操作的话
   * （本仓既有口径：plugins/qq-bind/adapters/registry.js:70-76 的 missingPlugin）。
   */
  availability(entry, ctx) {
    try {
      if (entry.check) {
        const r = entry.check(ctx)
        if (r === false) return { available: false, reason: '模块自检未通过（未说明原因）', missingPlugin: '' }
        if (r && typeof r === 'object') {
          const available = r.available !== false
          return {
            available,
            reason: available ? '' : String(r.reason || '模块自检未通过'),
            missingPlugin: available ? '' : String(r.missingPlugin || ''),
          }
        }
      }
      if (entry.requires.length > 0) {
        const missing = entry.requires.filter((name) => !optionalService(ctx, name))
        if (missing.length > 0) {
          return {
            available: false,
            reason: `缺少依赖服务：${missing.join('、')}（提供该服务的插件未安装或未启用）`,
            missingPlugin: '',
          }
        }
      }
      return { available: true, reason: '', missingPlugin: '' }
    } catch (err) {
      return {
        available: false,
        reason: `可用性检查失败：${(err && err.message) || err}`,
        missingPlugin: '',
      }
    }
  }

  /**
   * 列出模块（**每次调用都重新评估可用性**）。
   * 动态性来自这里：qq-bind 被停用后，下一次 GET /api/legacy-import/modules 就会把
   * qq-ledger 标成不可用并带出原因，不需要重启宿主。
   */
  list(ctx) {
    return [...this._mods.values()].map((entry) => {
      const a = this.availability(entry, ctx)
      return {
        id: entry.id,
        title: entry.title,
        description: entry.description,
        sourceHint: entry.sourceHint,
        owner: entry.owner,
        builtin: entry.builtin,
        requires: [...entry.requires],
        available: a.available,
        reason: a.reason,
        /** 不可用时"缺哪个插件"（可为空串）：前端据此提示该装什么 */
        missingPlugin: a.missingPlugin,
      }
    })
  }

  /**
   * 取"可用"模块；未知模块或不可用模块一律抛 httpError。
   *
   * 404 与 501 分开：404 是"id 写错了"（客户端 bug / 手输），501 是"模块在册但它的依赖没装"
   * ——后者要让用户看到"该装哪个插件"，这是本仓既有口径
   * （plugins/qq-bind/adapters/registry.js:70-76 的 missingPlugin 提示）。
   */
  resolve(id, ctx) {
    const key = String(id || '').trim()
    if (!key) throw httpError(400, '缺少参数: module（导入模块 id）')
    const entry = this._mods.get(key)
    if (!entry) {
      throw httpError(404, `未知的导入模块：${key}`, { availableModules: this.ids() })
    }
    const a = this.availability(entry, ctx)
    if (!a.available) {
      throw httpError(501, `导入模块「${entry.title}」当前不可用：${a.reason}`, {
        module: entry.id,
        reason: a.reason,
        ...(a.missingPlugin ? { missingPlugin: a.missingPlugin } : {}),
      })
    }
    return entry
  }
}
