/**
 * 内置导入模块：旧版 QQ 台账（id = qq-ledger）
 *
 * 数据来源：旧版 TsWeb 的 `backend/data/qq_accounts.json`，形状为
 *   { "records": { "<角色名>": { "qq": "12345", "passwordHash": "...", "updatedAt": "..." } } }
 *
 * 职责切分（本文件存在的理由）：
 *   - **解析**（旧文件格式 → 旧台账对象）在本模块：格式知识属于这里；
 *   - **落库**交回 qq-bind：调用 `ctx.qqBind.importLegacy(source, { dryRun, actor })`
 *     （plugins/qq-bind/index.js 的该公开方法）。台账的原子落盘（.tmp + rename + .bak）、
 *     快照下发、1:1 与大小写不敏感等契约**只在那里实现**，本模块绝不自己写 bindings.json，
 *     也绝不复制一份台账逻辑——否则两条实现迟早分叉出"看起来成功但游戏服没同步"。
 *
 * 旧版行为照搬（逐条对齐 plugins/qq-bind/ledger.js 的 import）：
 *   - 幂等：同名同 QQ → skipped，理由文案「已存在且一致（幂等跳过）」
 *   - 同名异 QQ / 该 QQ 已属他人 → conflicts，**逐条列出**，绝不覆盖既有绑定
 *   - dryRun：只出计划不落库（applied=false，且没有 appliedCount）
 *   - passwordHash 原样保留（不校验、不改写、不补算）
 *
 * 与旧版的一处**刻意差异**：本模块在解析阶段做一次"逐条可导入性预检"（parseIssues），
 * 只为把"这条为什么进不去"提前显示在页面上；预检**不过滤、不改写**任何条目，
 * 原对象照样交给 qq-bind，所以跳过口径仍以台账的 skipped 为准（两处文案会同时出现，
 * 页面已注明这是同一批条目的两种视角）。理由：旧版要等落库回执才知道哪条格式坏，
 * 而"文件整体不是合法 JSON / 缺 records"这类**文件级**错误在旧版会静默变成"0 条可导入"，
 * 操作者无从判断是自己文件放错了还是真没数据。
 */
import { httpError, optionalService } from './registry.js'

/** 模块 id（REST 的 module 参数、审计字段都用它） */
export const MODULE_ID = 'qq-ledger'

/**
 * QQ 号格式：与 plugins/qq-bind/ledger.js:30 的 QQ_PATTERN **逐字相同**。
 * 这里重复一份是刻意的：本模块要能在 qq-bind 未安装时也算出"预检结论"，
 * 不能为了一个正则去 import 另一个插件的文件（那是硬依赖）。
 * 若哪天 qq-bind 改了口径，本处要同步——两处不一致时以台账为准（预检只是提示）。
 */
export const QQ_PATTERN = /^\d{5,15}$/

/** 给错误/审计用的来源标签（文件路径或"粘贴的 JSON"） */
function sourceLabel(input) {
  const file = input && input.file ? String(input.file) : ''
  return file ? `（${file}）` : ''
}

/**
 * 解析旧台账。
 *
 * @param {object} input 容器交给模块的载荷
 * @param {'json'|'file'} [input.kind] json = 前端粘贴/接口直传；file = 容器已按安全边界读出的文本
 * @param {string} [input.file] 文件标识（仅用于错误文案；容器已做过路径校验）
 * @param {string} [input.text] 文件文本（kind=file 时由容器读出）
 * @param {*} [input.data] 已解析的 JSON 值（kind=json）
 * @returns {{ source: object, issues: Array<{username:string, qq?:string, reason:string}>, total: number }}
 * @throws 400 文件级畸形（不是对象 / 缺 records / records 不是对象 / 文本不是合法 JSON / 内容为空）
 */
export function parseLegacyLedger(input = {}) {
  const label = sourceLabel(input)
  let raw = input.data

  /**
   * data 是字符串时按文本解析：旧版 REST 直接把它丢给 ledger.import，字符串上没有 records
   * 就被当成"空台账"静默成功——那是最糟的失败方式（用户以为导入了，其实一条没进来）。
   */
  if (typeof raw === 'string') {
    const text = raw
    raw = undefined
    if (!text.trim()) throw httpError(400, `旧台账内容为空${label}`)
    try {
      raw = JSON.parse(text)
    } catch (err) {
      throw httpError(400, `旧台账不是合法 JSON${label}：${err.message}`)
    }
  }

  if (raw === undefined) {
    const text = String(input.text ?? '')
    if (!text.trim()) throw httpError(400, `旧台账内容为空${label}`)
    try {
      raw = JSON.parse(text)
    } catch (err) {
      throw httpError(400, `旧台账不是合法 JSON${label}：${err.message}`)
    }
  }

  if (raw === null || typeof raw !== 'object' || Array.isArray(raw)) {
    throw httpError(
      400,
      `旧台账内容应为对象${label}，实际是 ${describeType(raw)}；` +
        '期望形如 {"records":{"角色名":{"qq":"12345"}}}',
    )
  }
  if (raw.records === undefined || raw.records === null) {
    throw httpError(
      400,
      `旧台账缺少 records 字段${label}；期望形如 {"records":{"角色名":{"qq":"12345"}}}`,
    )
  }
  if (typeof raw.records !== 'object' || Array.isArray(raw.records)) {
    throw httpError(400, `旧台账 records 应为对象（角色名 → {qq, passwordHash}）${label}，实际是 ${describeType(raw.records)}`)
  }

  const issues = []
  const entries = Object.entries(raw.records)
  for (const [rawName, rec] of entries) {
    const username = String(rawName ?? '').trim()
    if (!username) {
      issues.push({ username: String(rawName ?? ''), reason: '角色名为空' })
      continue
    }
    if (rec === null || typeof rec !== 'object' || Array.isArray(rec)) {
      issues.push({ username, reason: `条目应为对象（含 qq 字段），实际是 ${describeType(rec)}` })
      continue
    }
    const qq = rec.qq === undefined || rec.qq === null ? '' : String(rec.qq).trim()
    if (!qq) {
      issues.push({ username, reason: '缺少 QQ 号（条目没有 qq 字段）' })
      continue
    }
    if (!QQ_PATTERN.test(qq)) {
      issues.push({ username, qq, reason: `QQ 号格式不正确（应为 5-15 位数字，实际「${qq}」）` })
    }
  }

  /**
   * source 就是**原对象本身**（同一引用，不深拷贝、不改写）：
   * 落库时的 passwordHash / updatedAt 必须与旧文件逐字节一致，
   * 任何"顺手规范化"都会变成一次静默的数据迁移。
   */
  return { source: raw, issues, total: entries.length }
}

/** 类型中文名（错误文案要能一眼看出实际拿到了什么） */
function describeType(v) {
  if (v === null) return 'null'
  if (Array.isArray(v)) return '数组'
  return { string: '字符串', number: '数字', boolean: '布尔值', object: '对象', undefined: '未提供' }[typeof v] || typeof v
}

/**
 * qq-bind 可用性（软依赖）。
 *
 * 两级判定的区别对用户很重要：**没装** 和 **装了但版本旧**（服务在、没有 importLegacy）
 * 是两种完全不同的处置（装插件 vs 升级插件），所以原因文案分开给。
 */
export function qqBindStatus(ctx) {
  const svc = optionalService(ctx, 'qqBind')
  if (!svc) {
    return {
      svc: null,
      available: false,
      reason: '未安装或未启用 qq-bind 插件（取不到 ctx.qqBind 服务），无法写入绑定台账',
    }
  }
  if (typeof svc.importLegacy !== 'function') {
    return {
      svc,
      available: false,
      reason: 'qq-bind 版本过旧：其服务上没有 importLegacy 方法，请升级 qq-bind 插件',
    }
  }
  return { svc, available: true, reason: '' }
}

/** 内置模块描述（交给 ModuleRegistry.register） */
export function createQqLedgerModule() {
  return {
    id: MODULE_ID,
    title: '旧版 QQ 台账',
    description:
      '把旧版 qq_accounts.json 里的「角色名 → QQ 号」导入 qq-bind 绑定台账：' +
      '幂等、冲突逐条列出且不覆盖既有绑定、试运行不落库；免密哈希原样保留',
    sourceHint:
      'qq_accounts.json，形如 {"records":{"角色名":{"qq":"12345","passwordHash":"...","updatedAt":"2026-01-01T00:00:00.000Z"}}}',
    owner: 'legacy-import',
    builtin: true,
    /**
     * 动态可用性：每次列清单/执行时都重新问一次 ctx。
     * 这样 qq-bind 缺席时本模块显示"不可用 + 原因"，而**整个插件照常加载**
     * （本次任务的硬要求：模块不可用不得升级成插件加载失败）。
     */
    check: (ctx) => {
      const st = qqBindStatus(ctx)
      // missingPlugin 让 501 的响应体直接告诉前端"该装/该升级 qq-bind"，而不是只说"不可用"
      return { available: st.available, reason: st.reason, missingPlugin: st.available ? '' : 'qq-bind' }
    },
    run: async (input, { dryRun = false, actor = 'admin', ctx } = {}) => {
      /**
       * 这里再判一次可用性：resolve() 到 run() 之间服务可能刚好被停用
       * （两次检查之间隔着网络与调度），少了这一层就会变成 "cannot read properties of null"。
       */
      const st = qqBindStatus(ctx)
      if (!st.available) {
        throw httpError(501, st.reason, { missingPlugin: 'qq-bind', module: MODULE_ID })
      }

      const { source, issues, total } = parseLegacyLedger(input)

      /**
       * 等 qq-bind 初始化完成：它用「先挂占位服务、再异步补数据」的写法
       * （plugins/qq-bind/index.js 的 apply：ctx.qqBind = service 之后才有 ledger），
       * 早于其 ready 调用 importLegacy 会读到还没建好的台账。
       * 它自己的路由也是 `await ready` 后才处理请求（同文件的路由 wrap），这里照同一口径。
       */
      if (st.svc.ready && typeof st.svc.ready.then === 'function') {
        await st.svc.ready
      }

      /**
       * 落库交回 qq-bind：它内部已完成 ①台账 import（幂等 / 冲突逐条 / dryRun 不落盘）
       * ②有写入时下发快照 ③写它自己的 qqbind.import 审计。
       */
      const r = (await st.svc.importLegacy(source, { dryRun, actor })) || {}

      return {
        imported: r.imported,
        skipped: r.skipped,
        conflicts: r.conflicts,
        applied: r.applied,
        appliedCount: r.appliedCount,
        snapshot: r.snapshot,
        /** 解析预检（非保留字段，容器原样带出） */
        parseIssues: issues,
        /** 旧文件里的条目总数（含被跳过/冲突的），便于页面区分"文件是空的"与"都被跳过了" */
        sourceCount: total,
      }
    },
  }
}
