/**
 * 模块注册表 + 旧台账解析（纯逻辑单测，不碰宿主、不起 HTTP）
 *
 * 运行：node test/registry.test.mjs
 *（不能写 `node --test test/`：本机该写法会 spawn EPERM，见本仓既有测试的口径）
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'

import { ModuleRegistry, optionalService, normalizeRunResult, MODULE_ID_RE } from '../modules/registry.js'
import { createQqLedgerModule, parseLegacyLedger, qqBindStatus, MODULE_ID, QQ_PATTERN } from '../modules/qq-ledger.js'

/** 造一个"外部插件贡献的模块" */
function externalModule(id, over = {}) {
  return {
    id,
    title: over.title || `外部模块 ${id}`,
    description: over.description || '测试用',
    sourceHint: over.sourceHint || 'whatever.json',
    owner: over.owner || 'other-plugin',
    requires: over.requires,
    check: over.check,
    run: over.run || (async (input, opts) => ({ imported: [{ username: 'X', qq: '12345' }], dryRun: opts.dryRun })),
  }
}

// ═══════════ 注册 / 摘除 ═══════════

test('注册表：注册后可列出、摘除后消失，返回的 off 可重复调用', () => {
  const reg = new ModuleRegistry()
  assert.deepEqual(reg.ids(), [], '空注册表')

  const off = reg.register(externalModule('alpha'))
  assert.equal(typeof off, 'function', 'register 必须返回摘除函数（照 cordis 惯例交给 dispose）')
  assert.deepEqual(reg.ids(), ['alpha'])
  assert.equal(reg.has('alpha'), true)

  const listed = reg.list({})
  assert.equal(listed.length, 1)
  assert.equal(listed[0].id, 'alpha')
  assert.equal(listed[0].title, '外部模块 alpha')
  assert.equal(listed[0].available, true)
  assert.equal(listed[0].reason, '')

  assert.equal(off(), true)
  assert.equal(off(), false, '重复摘除是幂等的（宿主 disable 可能调用多次）')
  assert.deepEqual(reg.ids(), [])
})

test('注册表：重复 id 拒绝（不覆盖），非法描述拒绝', () => {
  const reg = new ModuleRegistry()
  reg.register(externalModule('alpha'))

  assert.throws(
    () => reg.register(externalModule('alpha')),
    (err) => /id 已注册/.test(err.message) && /alpha/.test(err.message),
    '重复 id 必须抛错：谁被跑取决于加载顺序时，审计里只剩 id，事后无法还原跑的是谁的解析器',
  )
  assert.equal(reg.ids().length, 1, '失败的注册不得留下痕迹')

  assert.throws(() => reg.register({ id: 'Bad_Id', title: 'x', run: () => {} }), /id 不合法/)
  assert.throws(() => reg.register({ id: 'beta', title: '', run: () => {} }), /缺少 title/)
  assert.throws(() => reg.register({ id: 'beta', title: 'x' }), /缺少 run/)
  assert.equal(MODULE_ID_RE.test('qq-ledger'), true)
  assert.equal(MODULE_ID_RE.test('QQ-Ledger'), false)
})

test('注册表：别的模块的注册/摘除不影响内置模块', () => {
  const reg = new ModuleRegistry()
  reg.register(createQqLedgerModule())
  assert.deepEqual(reg.ids(), [MODULE_ID], '内置模块应当是第一个')

  const ctx = { qqBind: { importLegacy: async () => ({}) } }
  const off = reg.register(externalModule('other'))
  assert.deepEqual(reg.ids(), [MODULE_ID, 'other'])
  assert.equal(reg.get(MODULE_ID).builtin, true)

  off()
  assert.deepEqual(reg.ids(), [MODULE_ID], '摘除外部模块后内置模块仍在')
  assert.equal(reg.get(MODULE_ID).title, '旧版 QQ 台账')
  assert.equal(reg.list(ctx).length, 1)
})

// ═══════════ 可用性（动态） ═══════════

test('可用性：requires 缺服务 → 不可用 + 原因；服务出现后自动变可用', () => {
  const reg = new ModuleRegistry()
  reg.register(externalModule('needs-svc', { requires: ['qqBind'] }))

  const holder = {}
  // 用一个"普通对象 ctx"模拟服务的有无：optionalService 的第二级兜底就能读到它
  assert.equal(reg.list(holder)[0].available, false)
  assert.match(reg.list(holder)[0].reason, /缺少依赖服务：qqBind/)
  assert.throws(
    () => reg.resolve('needs-svc', holder),
    (err) => err.status === 501 && /不可用/.test(err.message) && /qqBind/.test(err.reason),
    '不可用模块必须 501 + 带原因',
  )

  holder.qqBind = { importLegacy: async () => ({}) }
  assert.equal(reg.list(holder)[0].available, true, '服务出现后应自动变为可用（每次列表都重新评估）')
  assert.equal(reg.resolve('needs-svc', holder).id, 'needs-svc')
})

test('可用性：check 返回 false / 带原因的对象 / 自己抛错，都不该让清单接口炸掉', () => {
  const reg = new ModuleRegistry()
  reg.register(externalModule('c1', { check: () => false }))
  reg.register(externalModule('c2', { check: () => ({ available: false, reason: '缺少 qq-bind 插件' }) }))
  reg.register(externalModule('c3', { check: () => { throw new Error('依赖探测炸了') } }))

  const list = reg.list({})
  const by = (id) => list.find((m) => m.id === id)

  assert.equal(by('c1').available, false)
  assert.match(by('c1').reason, /自检未通过/)
  assert.equal(by('c2').reason, '缺少 qq-bind 插件')
  assert.equal(by('c3').available, false)
  assert.match(by('c3').reason, /可用性检查失败：依赖探测炸了/)
  assert.throws(() => reg.resolve('c2', {}), (err) => err.status === 501)
})

test('可用性：ctx 代理对未 inject 的服务"访问即抛错"时，软依赖必须降级而不是冒泡', () => {
  /**
   * 复刻 cordis 的行为：get 是函数（返回 undefined），其它属性访问直接抛
   * `cannot get property "x" without inject`。可选链挡不住这种抛错，
   * 所以注册表的可用性判定必须包在 try 里（本目录刚修过一次这样的线上故障）。
   */
  const hostile = new Proxy({}, {
    get(_t, prop) {
      if (prop === 'get') return () => undefined
      throw new Error(`cannot get property "${String(prop)}" without inject`)
    },
  })
  assert.equal(optionalService(hostile, 'qqBind'), null, '取不到就返回 null，绝不抛错')

  const reg = new ModuleRegistry()
  reg.register(createQqLedgerModule())
  const m = reg.list(hostile)[0]
  assert.equal(m.available, false)
  assert.match(m.reason, /未安装或未启用 qq-bind 插件/)

  // get 不存在（更老的宿主）：属性访问同样抛错，仍应降级
  const hostile2 = new Proxy({}, {
    get(_t, prop) {
      if (prop === 'get') return undefined
      throw new Error(`cannot get property "${String(prop)}" without inject`)
    },
  })
  assert.equal(optionalService(hostile2, 'qqBind'), null)
})

test('optionalService：两级取法（ctx.get 注册的服务 / 普通属性赋值）', () => {
  // 1) ctx.get 命中（真实宿主里 Service 子类的注册路径）
  const viaGet = { get: (n) => (n === 'qqBind' ? { tag: 'from-get' } : undefined) }
  assert.deepEqual(optionalService(viaGet, 'qqBind'), { tag: 'from-get' })

  // 2) ctx.get 看不到"普通赋值"（实测：@deepseek-ai/cordis 的 Context.get 只认注册服务）
  const viaProp = { get: () => undefined, qqBind: { tag: 'from-prop' } }
  assert.deepEqual(optionalService(viaProp, 'qqBind'), { tag: 'from-prop' })

  // 3) 服务确实不存在
  assert.equal(optionalService({ get: () => undefined }, 'qqBind'), null)
  assert.equal(optionalService(null, 'qqBind'), null)
})

test('可用性：qq-bind 在但版本过旧（无 importLegacy）时，原因要区分"没装"与"要升级"', () => {
  assert.match(qqBindStatus({ qqBind: {} }).reason, /版本过旧/)
  assert.match(qqBindStatus({}).reason, /未安装或未启用/)
  assert.equal(qqBindStatus({ qqBind: { importLegacy: () => {} } }).available, true)
})

// ═══════════ resolve 的错误码 ═══════════

test('resolve：未知模块 404（列出可选模块）、空 id 400', () => {
  const reg = new ModuleRegistry()
  reg.register(createQqLedgerModule())
  assert.throws(
    () => reg.resolve('nope', {}),
    (err) => err.status === 404 && /未知的导入模块/.test(err.message) && Array.isArray(err.availableModules),
  )
  assert.throws(() => reg.resolve('', {}), (err) => err.status === 400)
  assert.throws(() => reg.resolve(null, {}), (err) => err.status === 400)
})

// ═══════════ 结果归一化 ═══════════

test('归一化：缺字段补默认、数组口径统一、dryRun 不产生 appliedCount、附加字段透传', () => {
  const r = normalizeRunResult(undefined)
  assert.deepEqual(r.imported, [])
  assert.deepEqual(r.skipped, [])
  assert.deepEqual(r.conflicts, [])
  assert.equal(r.applied, false)
  assert.equal('appliedCount' in r, false, '零写入时**没有** appliedCount（对齐 ledger.js:527-536）')
  assert.equal(r.snapshot, null)

  // 形状不合规：数组位给了对象、布尔位给了字符串
  const r2 = normalizeRunResult({ imported: { a: 1 }, skipped: null, conflicts: 'x', applied: 'yes', appliedCount: '3' })
  assert.deepEqual(r2.imported, [])
  assert.deepEqual(r2.skipped, [])
  assert.deepEqual(r2.conflicts, [])
  assert.equal(r2.applied, false, '只有恒等 true 才算 applied')
  assert.equal(r2.appliedCount, 3)

  // 外部模块自己的字段原样带出（容器不解释，避免"新模式要改容器"）
  const r3 = normalizeRunResult({ imported: [], applied: true, appliedCount: 2, parseIssues: [{ username: 'A' }], sourceCount: 7, mine: { k: 1 } })
  assert.equal(r3.applied, true)
  assert.equal(r3.sourceCount, 7)
  assert.equal(r3.mine.k, 1)
  assert.equal(r3.parseIssues.length, 1)
})

// ═══════════ 解析：正常 ═══════════

/** 旧版 qq_accounts.json 的真实形状（含大小写不同的同名与各种字段） */
const LEGACY = {
  records: {
    Ivan: { qq: '60001', passwordHash: 'h-i', updatedAt: '2026-01-01T00:00:00.000Z' },
    Judy: { qq: '60002', passwordHash: 'h-j' },
    ivansmall: { qq: '60003' },
    Broken: { qq: 'abc' },
    NoQq: { passwordHash: 'h-x' },
  },
}

test('解析：正常解析，source 原样返回（不改写 key、不 trim、不补字段）', () => {
  const r = parseLegacyLedger({ kind: 'json', data: LEGACY })
  assert.equal(r.total, 5)
  assert.equal(r.source, LEGACY, 'source 必须是同一引用：passwordHash/updatedAt 要逐字保留')
  assert.equal(r.source.records.Ivan.passwordHash, 'h-i')
  assert.equal(r.source.records.Ivan.updatedAt, '2026-01-01T00:00:00.000Z')
  assert.equal(r.issues.length, 2, '非法 QQ 与缺 QQ 各 1 条')
  assert.match(r.issues.find((i) => i.username === 'Broken').reason, /QQ 号格式不正确/)
  assert.match(r.issues.find((i) => i.username === 'NoQq').reason, /缺少 QQ 号/)
})

test('解析：文件文本走 JSON.parse；规则与 qq-bind 台账同口径（5-15 位数字）', () => {
  const r = parseLegacyLedger({ kind: 'file', file: 'qq_accounts.json', text: JSON.stringify(LEGACY) })
  assert.equal(r.total, 5)
  assert.equal(QQ_PATTERN.test('1234'), false, '4 位不是合法 QQ（与 qq-bind/ledger.js:30 一致）')
  assert.equal(QQ_PATTERN.test('12345'), true)
  assert.equal(QQ_PATTERN.test('123456789012345'), true)
  assert.equal(QQ_PATTERN.test('1234567890123456'), false)

  // data 直接给字符串时按文本解析（旧版会把字符串当空台账静默成功，那是最糟的失败方式）
  const r2 = parseLegacyLedger({ data: JSON.stringify({ records: { A: { qq: '12345' } } }) })
  assert.equal(r2.total, 1)
})

test('解析：空 records 是合法的（0 条可导入），不算畸形', () => {
  const r = parseLegacyLedger({ data: { records: {} } })
  assert.equal(r.total, 0)
  assert.deepEqual(r.issues, [])
})

test('解析：兼容旧文件里 qq 是数字（大整数）的情形，按字符串比较', () => {
  const r = parseLegacyLedger({ data: { records: { A: { qq: 123456789 } } } })
  assert.deepEqual(r.issues, [], '数字型 qq 只要位数合法就不该报错')
})

// ═══════════ 解析：畸形输入必须明确报错 ═══════════

test('解析：畸形输入逐条给出明确报错（不是 500，也不是静默 0 条）', () => {
  const cases = [
    [{ data: null }, /内容为空|应为对象/],
    [{ data: 42 }, /应为对象/],
    [{ data: 'not json' }, /不是合法 JSON/],
    [{ data: [] }, /应为对象/],
    [{ data: {} }, /缺少 records 字段/],
    [{ data: { records: null } }, /缺少 records 字段/],
    [{ data: { records: [] } }, /records 应为对象/],
    [{ data: { records: 'x' } }, /records 应为对象/],
    [{ text: '   ' }, /内容为空/],
    [{}, /内容为空/],
  ]
  for (const [input, re] of cases) {
    assert.throws(
      () => parseLegacyLedger(input),
      (err) => err.status === 400 && re.test(err.message),
      `输入 ${JSON.stringify(input)} 应报 400 且匹配 ${re}`,
    )
  }
})

test('解析：条目缺 qq / 条目不是对象 → 计入预检（不过滤、不改写，落库口径仍以台账 skipped 为准）', () => {
  const input = {
    data: {
      records: {
        NoQq: { passwordHash: 'h' },
        Bare: '12345',
        EmptyName: { qq: '60001' },
        '  ': { qq: '60002' },
        Ok: { qq: '60003' },
      },
    },
  }
  const r = parseLegacyLedger(input)
  assert.equal(r.total, 5, '预检不得删条目：原对象要整份交给台账')
  assert.deepEqual(Object.keys(r.source.records), ['NoQq', 'Bare', 'EmptyName', '  ', 'Ok'])
  const reasons = r.issues.map((i) => `${i.username}:${i.reason}`)
  assert.equal(r.issues.length, 3, 'NoQq / Bare / 空名 各 1 条')
  assert.ok(reasons.some((s) => /^NoQq:缺少 QQ 号/.test(s)))
  assert.ok(reasons.some((s) => /^Bare:条目应为对象/.test(s)))
  assert.ok(reasons.some((s) => /角色名为空/.test(s)))
})

test('解析：错误文案带上来源文件名（操作者要能对上自己填的路径）', () => {
  assert.throws(
    () => parseLegacyLedger({ kind: 'file', file: 'legacy/qq.json', text: '{' }),
    (err) => /legacy\/qq\.json/.test(err.message),
  )
})
