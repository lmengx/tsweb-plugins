/**
 * 前后端契约的静态比对
 *
 * 为什么需要它：前端半与后端半是两个文件、两种运行环境（浏览器 / 宿主），
 * 改了一边的路径或字段名，另一边**不会**报错——前端只会安静地显示"读取失败"，
 * 而本仓的验收方式是人肉比对行号。这个文件把那次人肉比对固化下来：
 *   1. client 里每个 req('...') 的路径+方法，都能在后端 index.js 里找到注册（且没有多余的注册）；
 *   2. client 读取的响应字段，都在后端源码里出现过（防止"猜字段名"）；
 *   3. client 用 $('id') 查的元素，都在它自己渲染的 HTML 里声明过；
 *   4. 视图声明的 icon / section 在宿主 web 插件里存在（否则菜单项没有图标或落不进分区）。
 *
 * 能证明的到此为止：它不验证 CSS、不验证真实浏览器 DOM、不验证运行时数据形状
 *（数据形状由 test/apply.test.mjs 与 test/client-flow.test.mjs 用真实/桩宿主覆盖）。
 *
 * 运行：node test/contract.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginDir = path.resolve(here, '..')
const repoRoot = path.resolve(pluginDir, '..', '..')

const serverSrc = await readFile(path.join(pluginDir, 'index.js'), 'utf8')
const clientSrc = await readFile(path.join(pluginDir, 'client', 'legacy-import.js'), 'utf8')
const sharedSrc = await readFile(path.join(pluginDir, 'client', 'shared.js'), 'utf8')

/** 后端注册的路由 */
const serverRoutes = [...serverSrc.matchAll(/app\.(get|post)\('([^']+)'/g)].map((m) => ({
  method: m[1].toUpperCase(),
  route: m[2],
}))

/** 前端调用的接口（req('path', { method: 'POST' })；缺省 GET，与宿主 api 的缺省一致：plugins/web/public/app.js:237） */
const clientCalls = [...clientSrc.matchAll(/req\('([^']+)'((?:.|\n)*?)\)/g)].map((m) => {
  const opts = m[2] || ''
  const method = /method:\s*'([A-Z]+)'/.exec(opts)
  return { route: m[1].split('?')[0], method: method ? method[1] : 'GET' }
})

test('契约：前端调用的每个接口都在后端注册，且后端没有前端未用的接口', () => {
  assert.ok(serverRoutes.length >= 3, `后端应注册至少 3 条路由，实际 ${serverRoutes.length}`)
  assert.ok(clientCalls.length >= 3, `前端应调用至少 3 个接口，实际 ${clientCalls.length}`)

  for (const c of clientCalls) {
    assert.ok(
      serverRoutes.some((r) => r.route === c.route && r.method === c.method),
      `前端调用了后端未注册的接口：${c.method} ${c.route}（后端有：${serverRoutes.map((r) => `${r.method} ${r.route}`).join('、')}）`,
    )
  }
  for (const r of serverRoutes) {
    assert.ok(
      clientCalls.some((c) => c.route === r.route),
      `后端注册了前端从不调用的接口：${r.method} ${r.route}`,
    )
  }
})

test('契约：前端使用的 DOM id 都在它自己渲染的 HTML 里声明', () => {
  const declared = new Set([...clientSrc.matchAll(/id="([a-z0-9-]+)"/g)].map((m) => m[1]))
  const used = new Set([...clientSrc.matchAll(/\$\('([a-z0-9-]+)'\)/g)].map((m) => m[1]))
  assert.ok(used.size > 0, '应当有元素查询（否则这个测试没在测任何东西）')
  for (const id of used) {
    assert.ok(declared.has(id), `前端查询了未声明的元素 id：${id}（已声明：${[...declared].join('、')}）`)
  }
})

test('契约：视图声明的 icon / section 在宿主 web 插件里存在', async () => {
  const hostApp = await readFile(path.join(repoRoot, 'plugins', 'web', 'public', 'app.js'), 'utf8')
  const icons = new Set(
    Object.keys(Object.fromEntries([...hostApp.matchAll(/^\s{4}([a-z]+):\s*'</gm)].map((m) => [m[1], 1]))),
  )
  const icon = /icon:\s*'([a-z]+)'/.exec(clientSrc)?.[1]
  const section = /section:\s*'([^']+)'/.exec(clientSrc)?.[1]

  assert.ok(icon, '视图应声明 icon')
  assert.ok(icons.has(icon), `图标 ${icon} 不在宿主的图标表里（可用：${[...icons].join('、')}）；未知图标会渲染成空白`)
  assert.ok(section, '视图应声明 section')
  assert.ok(hostApp.includes(`section: '${section}'`), `分区 ${section} 在宿主菜单里不存在，菜单项会无处可放`)
})

test('契约：client 用到的共享工具都由本插件的 shared.js 导出（不跨插件 import）', () => {
  const imported = /import\s*\{([^}]*)\}\s*from\s*'\.\/shared\.js'/.exec(clientSrc)
  assert.ok(imported, 'client 应从 ./shared.js 引入工具')
  const names = imported[1].split(',').map((s) => s.trim()).filter(Boolean)
  assert.ok(names.length > 0)
  for (const name of names) {
    assert.ok(
      new RegExp(`export (async )?function ${name}\\b`).test(sharedSrc),
      `shared.js 未导出 ${name}`,
    )
  }
  // 前端半不得 import 其它插件的文件（否则那个插件没装会把本页一起拖死）
  const badImports = [...clientSrc.matchAll(/from\s*'([^']+)'/g)]
    .map((m) => m[1])
    .filter((p) => !p.startsWith('./'))
  assert.deepEqual(badImports, [], 'client 只应使用相对本插件的 import')
})
