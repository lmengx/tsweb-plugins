/**
 * 真实 qq-bind 集成：本插件解析 + **真 qq-bind 台账**落库（幂等 / 冲突 / 哈希原样保留 / 双审计）
 *
 * 为什么单独一个文件：apply.test.mjs 用**假** qqBind 只验证"调用契约"（dryRun 透传、actor、参数），
 * 而"解析出来的东西真的进得了台账吗"必须用真实现跑一遍——尤其三件容易出偏差的事：
 *   1. 幂等（同名同 QQ 跳过）与冲突（同名异 QQ / QQ 已属他人）**逐条列出且不覆盖**；
 *   2. 旧 passwordHash 原样保留（本件绝不能顺手规范化）；
 *   3. 两条审计并存但不重复：本件写 legacyImport.run，qq-bind 自己写 qqbind.import。
 *
 * 用真实 cordis Context + 真实 apply（本件与 qq-bind 都挂同一个 express 实例），**不启动服务器进程**。
 * 与 qq-bind 的装配方式照 plugins/qq-bind/test/apply.test.mjs:39-163。
 *
 * 运行：node test/qqbind-integration.test.mjs
 *（若 plugins/qq-bind 不存在或它没有 importLegacy 方法，本文件会**跳过**而不是失败——
 *  本插件的软依赖语义就是这样：qq-bind 缺席是"模块不可用"，不是"插件坏了"。）
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import express from 'express'
import { Context } from '@deepseek-ai/cordis'

let dataDir
let app
let server
let base
let ctx
let disposeMine
let disposeQqBind
/** 真实 qq-bind 模块（import 失败时为 null → 整份测试跳过） */
let qqBindMod = null
/** 跳过原因（空串 = 不跳过） */
let skipReason = ''

try {
  qqBindMod = await import('../../qq-bind/index.js')
} catch (err) {
  skipReason = `无法 import plugins/qq-bind/index.js：${err.message}`
}

async function readJson(res) {
  const text = await res.text()
  let data = null
  try { data = JSON.parse(text) } catch { data = null }
  return { status: res.status, data, text }
}

function post(p, body) {
  return fetch(`${base}${p}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  }).then(readJson)
}

async function readLines(file) {
  const raw = await readFile(file, 'utf8')
  return raw.split('\n').filter((l) => l.trim() !== '').map((l) => JSON.parse(l))
}

async function readLedger() {
  try {
    return JSON.parse(await readFile(path.join(dataDir, 'qq-bind', 'bindings.json'), 'utf8'))
  } catch (err) {
    if (err.code === 'ENOENT') return null
    throw err
  }
}

/** 旧台账样本：含合法条目、非法 QQ、缺 QQ 三种 */
const LEGACY = {
  records: {
    Ivan: { qq: '60001', passwordHash: '$2y$hash-ivan', updatedAt: '2026-01-01T00:00:00.000Z' },
    Judy: { qq: '60002', passwordHash: '$2y$hash-judy' },
    Broken: { qq: 'abc', passwordHash: 'h-b' },
  },
}

before(async () => {
  if (skipReason) return
  dataDir = await mkdtemp(path.join(tmpdir(), 'legacy-import-real-'))
  process.env.TSWEB_QQBIND_TOKEN = 'test-token-legacy-import'

  app = express()
  app.use(express.json({ limit: '100mb' }))

  ctx = new Context()
  ctx.webServer = { app }
  ctx.auth = {
    verifyAuth: () => (req, res, next) => { req.user = { username: 'tester' }; next() },
    requireAdmin: () => (req, res, next) => next(),
  }
  ctx.paths = { dataOf: (n) => path.join(dataDir, n) }
  ctx.logger = { info() {}, warn() {}, error() {} }
  // qq-bind 的 gameOps 会向"启用服"下发快照；本测试不关心下发，给空服务器列表即可
  ctx.servers = { list: async () => [], getRaw: () => null }
  ctx.tshock = {
    fetchFor: async () => ({ ok: false, status: 404, data: {} }),
    postFor: async () => ({ ok: false, status: 404, data: {} }),
  }

  // 真实的 qq-bind 先上（本件依赖它的服务）
  disposeQqBind = qqBindMod.apply(ctx)
  await ctx.qqBind.ready
  if (typeof ctx.qqBind.importLegacy !== 'function') {
    skipReason = 'plugins/qq-bind 的服务上没有 importLegacy（本件依赖的公开契约未提供）'
    return
  }

  /**
   * 关键：断言本件在**生产路径**上取服务的方式成立。
   * 生产里本件的 ctx 是带 inject 的 fiber 代理，"未 inject 的属性访问会抛错"，
   * 所以只能用 ctx.get('qqBind')。这里直接断言注册的服务能被 get 到——
   * 若哪天 qq-bind 不再用 Service 注册（只做普通赋值），本件在宿主里就会取不到服务。
   */
  assert.equal(typeof ctx.get('qqBind')?.importLegacy, 'function', 'ctx.get("qqBind") 必须能取到带 importLegacy 的服务')

  const mine = await import('../index.js')
  disposeMine = await mine.apply(ctx)

  const s = app.listen(0, '127.0.0.1')
  await new Promise((resolve) => s.once('listening', resolve))
  server = s
  base = `http://127.0.0.1:${s.address().port}`
})

after(async () => {
  delete process.env.TSWEB_QQBIND_TOKEN
  if (server) await new Promise((resolve) => server.close(resolve))
  if (typeof disposeMine === 'function') disposeMine()
  if (typeof disposeQqBind === 'function') disposeQqBind()
  if (dataDir) await rm(dataDir, { recursive: true, force: true })
})

const maybe = (name, fn) => test(name, { skip: skipReason || false }, fn)

maybe('preflight：真 qq-bind 已装配，模块清单里 qq-ledger 可用', async () => {
  const res = await readJson(await fetch(`${base}/api/legacy-import/modules`))
  assert.equal(res.status, 200, res.text)
  assert.equal(res.data.modules[0].id, 'qq-ledger')
  assert.equal(res.data.modules[0].available, true, res.data.modules[0].reason)
  assert.equal(typeof ctx.qqBind.ledger.import, 'function', '台账的 import 是落库入口（本件不复制它的逻辑）')
})

maybe('试运行：真台账不落盘（bindings.json 不产生任何记录）', async () => {
  const res = await post('/api/legacy-import/run', { module: 'qq-ledger', dryRun: true, data: LEGACY })
  assert.equal(res.status, 200, res.text)
  assert.equal(res.data.applied, false)
  assert.equal('appliedCount' in res.data, false, '零写入时没有 appliedCount')
  assert.equal(res.data.imported.length, 2, 'Ivan / Judy 可新增')
  assert.equal(res.data.skipped.length, 1, 'Broken 的非法 QQ 进 skipped')
  assert.equal(res.data.skipped[0].reason, 'QQ 号格式不正确')
  assert.equal(res.data.parseIssues.length, 1, '解析预检也报了同一条（两种视角，不是两个数据源）')

  const led = await readLedger()
  assert.equal(led && led.records ? Object.keys(led.records).length : 0, 0, '试运行绝不落盘')
})

maybe('真执行：写进真台账，passwordHash/updatedAt 原样保留，source=import，并下发快照', async () => {
  const res = await post('/api/legacy-import/run', { module: 'qq-ledger', data: LEGACY })
  assert.equal(res.status, 200, res.text)
  assert.equal(res.data.applied, true)
  assert.equal(res.data.appliedCount, 2)
  assert.equal(res.data.imported.length, 2)
  // 没有启用中的服务器 → 快照对象存在但 total=0（qq-bind 的 pushSnapshot 契约）
  assert.ok(res.data.snapshot && typeof res.data.snapshot === 'object', '有写入时必须带快照结果')

  const led = await readLedger()
  assert.ok(led && led.records, '台账文件应已生成')
  assert.equal(led.records.Ivan.qq, '60001')
  assert.equal(led.records.Ivan.passwordHash, '$2y$hash-ivan', '免密哈希必须逐字保留（不校验、不重算）')
  assert.equal(led.records.Ivan.updatedAt, '2026-01-01T00:00:00.000Z', 'updatedAt 也不改写')
  assert.equal(led.records.Ivan.source, 'import', '台账标记来源为 import（qq-bind 自己的口径）')
  assert.equal(led.records.Judy.qq, '60002')
  assert.equal(led.records.Broken, undefined, '非法 QQ 不落库')
})

maybe('幂等：同样的数据再导一次 → 全部跳过、零写入、没有 appliedCount', async () => {
  const res = await post('/api/legacy-import/run', { module: 'qq-ledger', data: LEGACY })
  assert.equal(res.status, 200, res.text)
  assert.equal(res.data.imported.length, 0, '重复导入不得新增')
  assert.equal(res.data.applied, false, '零写入 → applied=false')
  assert.equal('appliedCount' in res.data, false)
  assert.equal(res.data.skipped.length, 3, 'Ivan/Judy 已存在且一致 + Broken 非法 QQ')
  const reasons = res.data.skipped.map((s) => `${s.username}:${s.reason}`)
  assert.ok(reasons.includes('Ivan:已存在且一致（幂等跳过）'), `跳过理由文案要对齐台账，实际 ${reasons.join(' | ')}`)
  assert.ok(reasons.includes('Judy:已存在且一致（幂等跳过）'))

  const led = await readLedger()
  assert.equal(Object.keys(led.records).length, 2, '台账没有被重复写')
})

maybe('冲突：同名异 QQ 与「QQ 已属他人」逐条列出，既有绑定绝不被覆盖', async () => {
  const res = await post('/api/legacy-import/run', {
    module: 'qq-ledger',
    data: {
      records: {
        Ivan: { qq: '60099' }, // 同名异 QQ
        Zoe: { qq: '60002' }, // 60002 已属 Judy
        Newbie: { qq: '60010' }, // 合法新增：证明冲突不影响其它条目入库
      },
    },
  })
  assert.equal(res.status, 200, res.text)
  assert.equal(res.data.conflicts.length, 2, `应逐条列出两条冲突，实际 ${JSON.stringify(res.data.conflicts)}`)
  const byName = Object.fromEntries(res.data.conflicts.map((c) => [c.username, c]))
  assert.equal(byName.Ivan.existingQq, '60001')
  assert.equal(byName.Ivan.incomingQq, '60099')
  assert.match(byName.Zoe.reason, /该 QQ 已属于 Judy/)
  assert.equal(res.data.imported.length, 1, '无冲突的条目照常导入')
  assert.equal(res.data.appliedCount, 1)

  const led = await readLedger()
  assert.equal(led.records.Ivan.qq, '60001', '冲突绝不覆盖既有绑定')
  assert.equal(led.records.Judy.qq, '60002')
  assert.equal(led.records.Newbie.qq, '60010')
  assert.equal(led.records.Zoe, undefined)
})

maybe('双审计：本件写 legacyImport.run、qq-bind 写 qqbind.import，两条并存且不重复', async () => {
  const mine = await readLines(path.join(dataDir, 'legacy-import', 'audit.jsonl'))
  const theirs = await readLines(path.join(dataDir, 'qq-bind', 'audit.jsonl'))

  assert.ok(mine.length >= 4, `本件审计应有 4 次运行，实际 ${mine.length}`)
  assert.equal(mine.every((r) => r.action === 'legacyImport.run'), true, '本件只写自己的动作名')
  assert.equal(mine.every((r) => r.module === 'qq-ledger'), true)
  assert.equal(mine.some((r) => r.action === 'qqbind.import'), false, '不得替 qq-bind 写它的审计')

  const imports = theirs.filter((r) => r.action === 'qqbind.import')
  assert.equal(imports.length, mine.length, '每次导入：qq-bind 一条（台账视角）+ 本件一条（导入视角）')
  assert.equal(imports.every((r) => r.actor === 'tester'), true, 'actor 由本件透传（登录名）')

  // 两条记录的关注点不同：本件记"入口与模块"，qq-bind 记"台账被改成了什么"
  const mineLast = mine[mine.length - 1]
  const theirsLast = imports[imports.length - 1]
  assert.equal(mineLast.via, 'rest')
  assert.equal(mineLast.appliedCount, 1)
  assert.equal(theirsLast.imported, mineLast.imported)
  assert.equal(theirsLast.conflicts, mineLast.conflicts)
  assert.equal(theirsLast.dryRun, mineLast.dryRun)
})

maybe('文件路径边界：真台账路径下 REST 仍只允许读本插件数据目录内的文件', async () => {
  const outside = path.join(dataDir, 'outside.json')
  const { writeFile } = await import('node:fs/promises')
  await writeFile(outside, JSON.stringify({ records: { FromTerminal: { qq: '60020', passwordHash: 'h-ft' } } }), 'utf8')

  // REST：数据目录外的路径被拒（security 用例在 apply.test.mjs 里更完整，这里确认真台账路径下同样成立）
  const denied = await post('/api/legacy-import/run', { module: 'qq-ledger', file: '../outside.json', dryRun: true })
  assert.equal(denied.status, 400, denied.text)
  assert.match(denied.data.error, /只允许读取本插件数据目录下的文件/)

  // 目录内可以
  const inside = path.join(dataDir, 'legacy-import', 'inside.json')
  await writeFile(inside, JSON.stringify({ records: { FromFile: { qq: '60021', passwordHash: 'h-ff' } } }), 'utf8')
  const ok = await post('/api/legacy-import/run', { module: 'qq-ledger', file: 'inside.json', dryRun: true })
  assert.equal(ok.status, 200, ok.text)
  assert.equal(ok.data.imported.length, 1)

  const led = await readLedger()
  assert.equal(led.records.FromFile, undefined, '试运行仍然不落盘')
})
