/**
 * 装配级集成测试：真实 cordis Context + 真实 apply + 真实 express（**不启动任何服务器进程**）
 *
 * 覆盖本次任务的验收点：
 *   - 模块清单接口：内置模块可用性，及 qq-bind **未安装**时"模块不可用 + 给出原因"（而不是加载失败）
 *   - 执行接口：dryRun 透传、actor 取登录名、appliedCount 缺失/存在两种契约
 *   - 落库**交回 qq-bind**：断言 ctx.qqBind.importLegacy 被正确调用（本件不自己写台账）
 *   - 审计（<dataDir>/legacy-import/audit.jsonl）与历史（history.jsonl、GET /history）
 *   - 安全：file 分支的越界读取必须被拒（../、绝对路径、同前缀兄弟目录）
 *   - 其它插件贡献模块：registerModule 全链路 + 摘除后回到内置状态
 *   - 终端命令：注册成功、可读数据目录**之外**的文件（本机终端的宽松边界，刻意为之）
 *
 * 运行：node test/apply.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import express from 'express'
import { Context } from '@deepseek-ai/cordis'

/** 当前主测试宿主（含假 qqBind） */
let host
/** 假 qqBind 的引用（供"服务中途消失"的用例覆写） */
let fakeQqBind

/**
 * 建一个宿主：真实 Context + 真实 apply（本插件的 apply 是 async，要 await）。
 * 假服务都用**普通属性赋值**挂上去（实测在 root Context 上可行；注意这种挂法对
 * ctx.get() 不可见，正好顺带验证本件 optionalService 的第二级兜底）。
 */
async function startHost({ withQqBind = true, withTerminal = false } = {}) {
  const dir = await mkdtemp(path.join(tmpdir(), 'legacy-import-'))
  const app = express()
  app.use(express.json({ limit: '100mb' }))
  const calls = []
  const terminalHandlers = {}

  const ctx = new Context()
  ctx.webServer = { app }
  ctx.auth = {
    // 模拟"已登录的管理员"：把登录名放进 req.user（后端用它当审计 actor，见 index.js 的 run 路由）
    verifyAuth: () => (req, res, next) => { req.user = { username: 'tester' }; next() },
    requireAdmin: () => (req, res, next) => next(),
  }
  ctx.paths = { dataOf: (n) => path.join(dir, n) }
  ctx.logger = { info() {}, warn() {}, error() {} }
  if (withTerminal) {
    ctx.terminal = { register(name, description, handler) { terminalHandlers[name] = handler } }
  }

  const fake = {
    ready: Promise.resolve(),
    /**
     * 只实现本件唯一用到的契约：importLegacy(source, { dryRun, actor })。
     * 跳过口径照着 plugins/qq-bind/ledger.js:490-525 写：缺 QQ / QQ 格式不对进 skipped
     * （用例要能验证"非法条目不会被当成新增"，假服务太宽松就测不出这条）。
     */
    importLegacy: async (source, opts) => {
      calls.push({ source, opts })
      const entries = Object.entries((source && source.records) || {})
      const imported = []
      const skipped = []
      for (const [username, rec] of entries) {
        const qq = rec && rec.qq != null ? String(rec.qq).trim() : ''
        if (!username || !qq) {
          skipped.push({ username, reason: '缺少用户名或 QQ' })
          continue
        }
        if (!/^\d{5,15}$/.test(qq)) {
          skipped.push({ username, qq, reason: 'QQ 号格式不正确' })
          continue
        }
        imported.push({ username, qq })
      }
      const dry = opts.dryRun === true
      return {
        imported,
        skipped,
        conflicts: [],
        applied: !dry && imported.length > 0,
        // dryRun 或零写入时**没有** appliedCount（对齐 plugins/qq-bind/ledger.js:527-536）
        ...(dry || imported.length === 0 ? {} : { appliedCount: imported.length }),
        snapshot: dry || imported.length === 0
          ? null
          : { ok: true, total: 1, okCount: 1, servers: [{ id: 's1', name: '一服', ok: true, count: imported.length }] },
      }
    },
  }
  if (withQqBind) ctx.qqBind = fake

  const mod = await import('../index.js')
  assert.equal(mod.name, 'legacy-import')
  assert.deepEqual(mod.inject, ['webServer', 'auth', 'paths'])
  const dispose = await mod.apply(ctx)
  assert.equal(typeof dispose, 'function', 'apply 必须返回释放钩子')

  const server = app.listen(0, '127.0.0.1')
  await new Promise((resolve) => server.once('listening', resolve))
  const base = `http://127.0.0.1:${server.address().port}`

  return {
    dir,
    ctx,
    app,
    server,
    base,
    calls,
    fake,
    terminalHandlers,
    dataDir: path.join(dir, 'legacy-import'),
    close: async () => {
      await new Promise((resolve) => server.close(resolve))
      await rm(dir, { recursive: true, force: true })
    },
  }
}

async function readJson(res) {
  const text = await res.text()
  let data = null
  try { data = JSON.parse(text) } catch { data = null }
  return { status: res.status, data, text }
}

function get(base, p) {
  return fetch(`${base}${p}`).then(readJson)
}

function post(base, p, body) {
  return fetch(`${base}${p}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  }).then(readJson)
}

/** 读 JSONL（审计 / 历史） */
async function readLines(file) {
  const raw = await readFile(file, 'utf8')
  return raw.split('\n').filter((l) => l.trim() !== '').map((l) => JSON.parse(l))
}

before(async () => {
  host = await startHost({ withQqBind: true, withTerminal: true })
  fakeQqBind = host.fake
})

after(async () => {
  if (host) await host.close()
})

// ═══════════ 1. 模块清单 ═══════════

test('模块清单：内置模块在列且可用，并回传本插件数据目录', async () => {
  const res = await get(host.base, '/api/legacy-import/modules')
  assert.equal(res.status, 200, res.text)
  assert.equal(res.data.ok, true)
  const mods = res.data.modules
  assert.equal(mods.length, 1, '当前只有内置模块；其它模块由别的插件注册')
  assert.equal(mods[0].id, 'qq-ledger')
  assert.equal(mods[0].title, '旧版 QQ 台账')
  assert.equal(mods[0].builtin, true)
  assert.equal(mods[0].available, true)
  assert.equal(mods[0].reason, '')
  assert.match(mods[0].sourceHint, /records/)
  assert.equal(res.data.dataDir, host.dataDir)
})

// ═══════════ 2. 试运行：dryRun 透传 + actor ═══════════

test('试运行：dryRun 透传给 qqBind.importLegacy，actor 取登录名，零写入时不带 appliedCount', async () => {
  const before = host.calls.length
  const res = await post(host.base, '/api/legacy-import/run', {
    module: 'qq-ledger',
    dryRun: true,
    data: { records: { Ivan: { qq: '60001', passwordHash: 'h-i' }, Judy: { qq: '60002' } } },
  })
  assert.equal(res.status, 200, res.text)

  assert.equal(host.calls.length, before + 1, '必须恰好调用一次落库')
  const call = host.calls[host.calls.length - 1]
  assert.equal(call.opts.dryRun, true, 'dryRun 必须透传')
  assert.equal(call.opts.actor, 'tester', 'actor 应取登录名（不是写死 admin）')
  assert.equal(call.source.records.Ivan.passwordHash, 'h-i', 'source 原样交给 qq-bind（哈希不改写）')

  assert.equal(res.data.dryRun, true)
  assert.equal(res.data.applied, false, '试运行不落库')
  assert.equal('appliedCount' in res.data, false, '零写入时**没有** appliedCount')
  assert.equal(res.data.imported.length, 2)
  assert.equal(res.data.snapshot, null)
  assert.equal(res.data.module, 'qq-ledger')
  assert.equal(res.data.actor, 'tester')
  assert.equal(res.data.via, 'rest')
})

// ═══════════ 3. 真执行 ═══════════

test('真执行：applied=true 且带 appliedCount 与快照结果', async () => {
  const res = await post(host.base, '/api/legacy-import/run', {
    module: 'qq-ledger',
    data: { records: { Ivan: { qq: '60001' }, Judy: { qq: '60002' } } },
  })
  assert.equal(res.status, 200, res.text)
  assert.equal(res.data.dryRun, false)
  assert.equal(res.data.applied, true)
  assert.equal(res.data.appliedCount, 2)
  assert.equal(res.data.snapshot.servers[0].name, '一服')
  assert.equal(res.data.sourceCount, 2, '源数据条目数（解析阶段统计）')
})

// ═══════════ 4. 审计 + 历史 ═══════════

test('审计与历史：每次导入各写一条（含 module/dryRun/计数/actor），历史接口新的在前', async () => {
  const audit = await readLines(path.join(host.dataDir, 'audit.jsonl'))
  // 到这一步共跑过两次导入（试运行 + 真执行），审计各一条
  assert.equal(audit.length, 2, `审计条数应等于导入次数，实际 ${audit.length}`)
  assert.equal(audit[0].dryRun, true)
  const last = audit[audit.length - 1]
  assert.equal(last.action, 'legacyImport.run')
  assert.equal(last.module, 'qq-ledger')
  assert.equal(last.dryRun, false)
  assert.equal(last.actor, 'tester')
  assert.equal(last.via, 'rest')
  assert.equal(last.ok, true)
  assert.equal(last.imported, 2)
  assert.equal(last.appliedCount, 2)

  // 本件**只**写自己的动作名：qq-bind 的 qqbind.import 由 qq-bind 自己写（本文件里是假服务，不写）
  assert.equal(audit.some((a) => String(a.action).startsWith('qqbind.')), false)

  const hist = await get(host.base, '/api/legacy-import/history?limit=2')
  assert.equal(hist.status, 200, hist.text)
  assert.equal(hist.data.rows.length, 2)
  assert.ok(hist.data.rows[0].t >= hist.data.rows[1].t, '新的在前')
  assert.equal(hist.data.rows[0].moduleTitle, '旧版 QQ 台账')
})

// ═══════════ 5. file 分支（数据目录内） ═══════════

test('file 分支：只读本插件数据目录内的文件，内容交给模块解析', async () => {
  await mkdir(host.dataDir, { recursive: true })
  await writeFile(
    path.join(host.dataDir, 'qq_accounts.json'),
    JSON.stringify({ records: { Ivan: { qq: '60001', passwordHash: 'h-i' }, Broken: { qq: 'abc' } } }),
    'utf8',
  )

  const res = await post(host.base, '/api/legacy-import/run', {
    module: 'qq-ledger',
    dryRun: true,
    file: 'qq_accounts.json',
  })
  assert.equal(res.status, 200, res.text)
  assert.equal(res.data.imported.length, 1)
  assert.equal(res.data.sourceCount, 2)
  assert.equal(res.data.parseIssues.length, 1, '解析预检应报出 Broken 的非法 QQ')
  assert.match(res.data.parseIssues[0].reason, /QQ 号格式不正确/)
})

test('file 分支：子目录内的文件也可以（相对数据目录）', async () => {
  await mkdir(path.join(host.dataDir, 'legacy'), { recursive: true })
  await writeFile(
    path.join(host.dataDir, 'legacy', 'qq.json'),
    JSON.stringify({ records: { A: { qq: '12345' } } }),
    'utf8',
  )
  const res = await post(host.base, '/api/legacy-import/run', {
    module: 'qq-ledger', dryRun: true, file: 'legacy/qq.json',
  })
  assert.equal(res.status, 200, res.text)
  assert.equal(res.data.imported.length, 1)
})

// ═══════════ 6. 安全：越界读取必须被拒 ═══════════

test('安全：file 越界（../ 、绝对路径、同前缀兄弟目录）一律 400，且不读文件内容', async () => {
  // 数据目录之外放一个"机密文件"，用于证明越界被挡在校验阶段（不是读完了才报错）
  await writeFile(path.join(host.dir, 'secret.json'), JSON.stringify({ records: { Leak: { qq: '99999' } } }), 'utf8')
  await mkdir(path.join(host.dir, 'legacy-import-x'), { recursive: true })
  await writeFile(
    path.join(host.dir, 'legacy-import-x', 'other.json'),
    JSON.stringify({ records: { Leak2: { qq: '99998' } } }),
    'utf8',
  )

  const cases = [
    '../secret.json',
    '..\\secret.json',
    '../legacy-import-x/other.json', // 与前缀校验最像的绕过尝试：兄弟目录
    path.join(host.dir, 'secret.json'), // 绝对路径
    'sub/../../secret.json',
  ]
  for (const file of cases) {
    const before = host.calls.length
    const res = await post(host.base, '/api/legacy-import/run', { module: 'qq-ledger', file, dryRun: true })
    assert.equal(res.status, 400, `${file} 应被拒绝，实际 ${res.status} ${res.text}`)
    assert.match(res.data.error, /只允许读取本插件数据目录下的文件/)
    assert.equal(host.calls.length, before, '被拒绝的请求不得触达落库')
  }

  // 目录内不存在 → 404（而不是 500）
  const missing = await post(host.base, '/api/legacy-import/run', { module: 'qq-ledger', file: 'nope.json' })
  assert.equal(missing.status, 404, missing.text)
  assert.match(missing.data.error, /文件不存在/)

  // 指向目录 → 400
  await mkdir(path.join(host.dataDir, 'adir'), { recursive: true })
  const isDir = await post(host.base, '/api/legacy-import/run', { module: 'qq-ledger', file: 'adir' })
  assert.equal(isDir.status, 400, isDir.text)
  assert.match(isDir.data.error, /目录/)
})

test('参数校验：缺 module / 缺 data 与 file / 未知模块，三种错误各自有明确状态码', async () => {
  const noModule = await post(host.base, '/api/legacy-import/run', { data: { records: {} } })
  assert.equal(noModule.status, 400)
  assert.match(noModule.data.error, /缺少参数: module/)

  const noInput = await post(host.base, '/api/legacy-import/run', { module: 'qq-ledger' })
  assert.equal(noInput.status, 400)
  assert.match(noInput.data.error, /缺少参数: data 或 file/)

  const unknown = await post(host.base, '/api/legacy-import/run', { module: 'not-exist', data: { records: {} } })
  assert.equal(unknown.status, 404, unknown.text)
  assert.match(unknown.data.error, /未知的导入模块/)
  assert.deepEqual(unknown.data.availableModules, ['qq-ledger'])
})

// ═══════════ 7. 畸形输入与失败留痕 ═══════════

test('畸形输入：400 + 明确原因，并且失败也写一条审计（ok=false）', async () => {
  const res = await post(host.base, '/api/legacy-import/run', { module: 'qq-ledger', data: { nope: 1 } })
  assert.equal(res.status, 400, res.text)
  assert.match(res.data.error, /缺少 records 字段/)

  const audit = await readLines(path.join(host.dataDir, 'audit.jsonl'))
  const last = audit[audit.length - 1]
  assert.equal(last.ok, false)
  assert.match(last.error, /缺少 records 字段/)
  assert.equal(last.module, 'qq-ledger')
  assert.equal(last.dryRun, false)
})

// ═══════════ 8. 别的插件贡献模块 + 摘除 ═══════════

test('外部模块：别的插件经 ctx.legacyImport.registerModule 贡献，可列可跑，摘除后回到内置状态', async () => {
  const seen = []
  const off = host.ctx.legacyImport.registerModule({
    id: 'demo-import',
    title: '演示导入',
    description: '测试用外部模块',
    sourceHint: 'demo.json',
    owner: 'other-plugin',
    run: async (input, opts) => {
      seen.push({ input, opts })
      return { imported: [{ username: 'Demo', qq: '11111' }], skipped: [], conflicts: [], applied: !opts.dryRun, appliedCount: 1 }
    },
  })

  // 立即可见（模块清单是动态的，不需要重启）
  const list = await get(host.base, '/api/legacy-import/modules')
  assert.deepEqual(list.data.modules.map((m) => m.id), ['qq-ledger', 'demo-import'])
  const demo = list.data.modules[1]
  assert.equal(demo.owner, 'other-plugin')
  assert.equal(demo.builtin, false)
  assert.equal(demo.available, true)

  const run = await post(host.base, '/api/legacy-import/run', {
    module: 'demo-import',
    dryRun: false,
    data: { anything: 1 },
  })
  assert.equal(run.status, 200, run.text)
  assert.equal(run.data.applied, true)
  assert.equal(seen.length, 1)
  assert.equal(seen[0].opts.dryRun, false)
  assert.equal(seen[0].opts.actor, 'tester')
  assert.deepEqual(seen[0].input, { kind: 'json', data: { anything: 1 } }, '容器把 JSON 原样交给模块')

  // 审计记的是模块 id
  const audit = await readLines(path.join(host.dataDir, 'audit.jsonl'))
  assert.equal(audit[audit.length - 1].module, 'demo-import')

  // 重复注册同一 id 抛错
  assert.throws(() => host.ctx.legacyImport.registerModule({ id: 'demo-import', title: 'x', run: () => {} }), /id 已注册/)

  // 摘除：外部模块消失，内置模块不受影响
  assert.equal(off(), true)
  const after = await get(host.base, '/api/legacy-import/modules')
  assert.deepEqual(after.data.modules.map((m) => m.id), ['qq-ledger'])
  const gone = await post(host.base, '/api/legacy-import/run', { module: 'demo-import', data: {} })
  assert.equal(gone.status, 404)
})

// ═══════════ 9. 动态可用性：qq-bind 中途消失 ═══════════

test('动态可用性：qq-bind 服务中途消失/变旧版本时，模块立刻标记不可用且执行回 501', async () => {
  // 1) 服务变旧版（在，但没有 importLegacy）
  host.ctx.qqBind = {}
  const list1 = await get(host.base, '/api/legacy-import/modules')
  assert.equal(list1.status, 200, list1.text)
  assert.equal(list1.data.modules[0].available, false)
  assert.match(list1.data.modules[0].reason, /版本过旧/)

  const run1 = await post(host.base, '/api/legacy-import/run', { module: 'qq-ledger', data: { records: {} } })
  assert.equal(run1.status, 501, run1.text)
  assert.equal(run1.data.module, 'qq-ledger')
  assert.match(run1.data.reason, /版本过旧/)

  // 2) 服务又好起来 → 立刻恢复可用（无需重启，也不需要重新加载插件）
  host.ctx.qqBind = fakeQqBind
  const list2 = await get(host.base, '/api/legacy-import/modules')
  assert.equal(list2.data.modules[0].available, true)
  const run2 = await post(host.base, '/api/legacy-import/run', {
    module: 'qq-ledger', dryRun: true, data: { records: { A: { qq: '12345' } } },
  })
  assert.equal(run2.status, 200, run2.text)
})

// ═══════════ 10. qq-bind 完全未安装 ═══════════

test('qq-bind 未安装：插件仍能加载、模块标记不可用并给原因、REST 不 500', async () => {
  const solo = await startHost({ withQqBind: false })
  try {
    // 插件加载成功（apply 没抛），路由在
    const list = await get(solo.base, '/api/legacy-import/modules')
    assert.equal(list.status, 200, list.text)
    assert.equal(list.data.modules.length, 1)
    assert.equal(list.data.modules[0].available, false)
    assert.match(list.data.modules[0].reason, /未安装或未启用 qq-bind 插件/)

    // 执行 → 501 而不是 500（"缺插件"是可预期状态，不是服务端错误）
    const run = await post(solo.base, '/api/legacy-import/run', {
      module: 'qq-ledger', data: { records: { A: { qq: '12345' } } },
    })
    assert.equal(run.status, 501, run.text)
    assert.equal(run.data.missingPlugin, 'qq-bind')
    assert.match(run.data.error, /未安装或未启用 qq-bind 插件/)

    // "模块不可用"是**请求被拒**，不是一次导入尝试：因此不写审计
    // （写审计的边界是"真的调用到了某个模块"，模块自己抛错也算——见上一个用例；
    //  这与 400/404 参数错误不写审计是同一条口径，避免审计被拼错的模块 id 灌满）。
    await assert.rejects(
      () => readFile(path.join(solo.dataDir, 'audit.jsonl'), 'utf8'),
      (err) => err.code === 'ENOENT',
      '模块不可用被拒时不应留下审计记录',
    )

    // 其它接口同样正常
    const hist = await get(solo.base, '/api/legacy-import/history')
    assert.equal(hist.status, 200)
    assert.ok(Array.isArray(hist.data.rows))
  } finally {
    await solo.close()
  }
})

// ═══════════ 11. 终端命令 ═══════════

test('终端命令：注册名与用法；可读数据目录**之外**的文件（本机终端的宽容边界）', async () => {
  const handler = host.terminalHandlers['legacy-import']
  assert.equal(typeof handler, 'function', '应注册 legacy-import 终端命令')

  // 数据目录之外的文件：REST 会拒绝（见安全用例），终端允许——这是刻意的取舍
  const outside = path.join(host.dir, 'outside-qq_accounts.json')
  await writeFile(
    outside,
    JSON.stringify({ records: { TerminalUser: { qq: '70001', passwordHash: 'h-t' } } }),
    'utf8',
  )

  const logs = []
  const orig = console.log
  console.log = (...a) => logs.push(a.join(' '))
  try {
    await handler([outside, '--dry'])
  } finally {
    console.log = orig
  }

  const call = host.calls[host.calls.length - 1]
  assert.equal(call.opts.actor, 'terminal', '终端入口的 actor 必须是 terminal（审计可区分入口）')
  assert.equal(call.opts.dryRun, true, '--dry 应透传为 dryRun')
  assert.equal(call.source.records.TerminalUser.qq, '70001')
  assert.ok(logs.some((l) => /试运行，未写入/.test(l)), `输出应含试运行标记，实际：${logs.join(' | ')}`)

  const audit = await readLines(path.join(host.dataDir, 'audit.jsonl'))
  assert.equal(audit[audit.length - 1].via, 'terminal')

  // 用法错误（只给模块 id、没给文件）不能把模块 id 当成文件名去读
  const logs2 = []
  console.log = (...a) => logs2.push(a.join(' '))
  try {
    await handler(['qq-ledger'])
  } finally {
    console.log = orig
  }
  assert.ok(logs2.some((l) => /缺少文件路径/.test(l)), `应提示缺文件路径，实际：${logs2.join(' | ')}`)

  // 文件不存在：友好提示而不是抛错
  const logs3 = []
  console.log = (...a) => logs3.push(a.join(' '))
  try {
    await handler([path.join(host.dir, 'no-such-file.json')])
  } finally {
    console.log = orig
  }
  assert.ok(logs3.some((l) => /读取文件失败/.test(l)), `应提示读取失败，实际：${logs3.join(' | ')}`)
})
