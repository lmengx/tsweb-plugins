/**
 * 前端半的**逻辑**流程测试（最小 DOM 桩）
 *
 * 诚实说明本文件能证明什么、不能证明什么：
 *   能证明：client/legacy-import.js 在真实调用序列下不抛错、接口路径与请求体正确、
 *           「先试运行才允许执行」的闸门有效、输入改动会作废旧计划、
 *           重复进入页面不会把事件监听器叠成多次点击多次请求（qq-bind 踩过的坑）、
 *           不可用模块被禁用并显示原因、失败与结果如实渲染。
 *   不能证明：任何视觉/布局/CSS 效果，也不能证明真实浏览器里的 DOM 行为
 *           （本仓没有 jsdom 之类的依赖，这里是一个只覆盖本页所用 API 的**最小**桩，
 *            不是浏览器模拟器：它不理解级联、不执行选择器引擎、不做事件冒泡）。
 *
 * 运行：node test/client-flow.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'

// ═══════════ 最小 DOM 桩 ═══════════

/** 只解析"标签 + 属性"，不建树、不做选择器引擎 */
function parseTags(html) {
  const els = []
  const tagRe = /<([a-zA-Z][a-zA-Z0-9]*)((?:\s+[^>]*?)?)\/?>/g
  let m
  while ((m = tagRe.exec(html)) !== null) {
    const attrs = {}
    /**
     * 属性值可省略（HTML 的布尔属性：`disabled`、`checked`），值是空串。
     * 少了这一条，桩就读不出 disabled —— 那不是产品问题而是桩的缺陷，
     * 但它会让"不可用模块必须被禁用"这条断言失真，所以必须正确解析。
     */
    const attrRe = /([a-zA-Z-]+)(?:="([^"]*)")?/g
    let a
    while ((a = attrRe.exec(m[2] || '')) !== null) {
      if (!a[1]) continue
      attrs[a[1]] = a[2] === undefined ? '' : a[2]
    }
    els.push(new StubEl(attrs))
  }
  return els
}

class StubEl {
  constructor(attrs = {}) {
    this.attrs = attrs
    this.id = attrs.id || ''
    this.className = attrs.class || ''
    this.textContent = ''
    this.value = attrs.value || ''
    this.checked = 'checked' in attrs
    this.disabled = 'disabled' in attrs
    this.title = ''
    this.type = attrs.type || 'text'
    this._html = ''
    this.listeners = {}
  }

  set innerHTML(v) { this._html = String(v == null ? '' : v) }
  get innerHTML() { return this._html }

  getAttribute(n) { return this.attrs[n] === undefined ? null : this.attrs[n] }
  setAttribute(n, v) { this.attrs[n] = String(v) }

  addEventListener(t, f) { (this.listeners[t] = this.listeners[t] || []).push(f) }
  removeEventListener(t, f) {
    const l = this.listeners[t] || []
    const i = l.indexOf(f)
    if (i >= 0) l.splice(i, 1)
  }
  listenerCount(t) { return (this.listeners[t] || []).length }
  fire(type, ev) { for (const f of (this.listeners[type] || []).slice()) f(ev) }

  querySelector(sel) { return (this._els || []).find((e) => matches(e, sel)) || null }
  querySelectorAll(sel) { return (this._els || []).filter((e) => matches(e, sel)) }
}

function matches(el, sel) {
  if (sel.startsWith('#')) return el.id === sel.slice(1)
  const attr = /^\[([a-zA-Z-]+)(?:="([^"]*)")?\]$/.exec(sel)
  if (!attr) throw new Error(`最小 DOM 桩不支持该选择器：${sel}`)
  if (attr[1] in el.attrs === false) return false
  return attr[2] === undefined ? true : el.attrs[attr[1]] === attr[2]
}

/** 容器：innerHTML 一变就重建扁平的元素表（模拟"渲染后能按 id/属性查到元素"） */
function makeContainer() {
  const c = new StubEl()
  let html = ''
  Object.defineProperty(c, 'innerHTML', {
    get() { return html },
    set(v) {
      html = String(v == null ? '' : v)
      c._els = parseTags(html)
    },
  })
  c._els = []
  return c
}

/** 装好 window/document 全局，返回"宿主"（捕获注册的视图与 api 调用） */
function setupHost({ api } = {}) {
  const calls = []
  const styles = []
  const view = { registered: null }
  const els = []
  globalThis.document = {
    createElement(tag) {
      const el = new StubEl({ id: '' })
      el.tagName = tag
      if (tag === 'style') els.push(el)
      return el
    },
    head: { appendChild(el) { if (el.tagName === 'style') styles.push(el.textContent) } },
    body: { appendChild() {}, removeChild() {} },
  }
  globalThis.window = {
    confirm: () => true,
    tsweb: {
      registerView(v) { view.registered = v },
      api: async (p, opts) => {
        calls.push({ path: p, opts: opts || {} })
        return api(p, opts || {}, calls.length)
      },
    },
  }
  return { calls, styles, view, els }
}

const MODULES_OK = {
  ok: true,
  data: {
    modules: [
      {
        id: 'qq-ledger',
        title: '旧版 QQ 台账',
        description: '把旧版 qq_accounts.json 导入 qq-bind 台账',
        sourceHint: 'qq_accounts.json，形如 {"records":{...}}',
        owner: 'legacy-import',
        builtin: true,
        requires: [],
        available: true,
        reason: '',
      },
      {
        id: 'ghost',
        title: '幽灵模块',
        description: '依赖一个没装的插件',
        sourceHint: 'ghost.json',
        owner: 'other-plugin',
        builtin: false,
        requires: ['qqBind'],
        available: false,
        reason: '缺少依赖服务：qqBind（提供该服务的插件未安装或未启用）',
      },
    ],
    dataDir: 'C:/data/legacy-import',
  },
}

/** 载入前端半（模块只在首次 import 时求值，所以每个用例前都要换一套全局） */
async function loadClient() {
  // 带唯一 query 绕开 ESM 缓存，让每个用例拿到"全新实例"（与宿主的热重载口径一致）
  return import(`../client/legacy-import.js?t=${Math.random()}`)
}

// ═══════════ 用例 ═══════════

test('首屏：注册视图（id/title/section/path/icon）+ 拉模块清单 + 渲染模块行', async () => {
  const host = setupHost({
    api: async (p) => {
      if (p === '/api/legacy-import/modules') return MODULES_OK
      if (p.startsWith('/api/legacy-import/history')) return { ok: true, data: { rows: [] } }
      throw new Error(`未预期的请求 ${p}`)
    },
  })
  await loadClient()
  assert.ok(host.view.registered, '必须调用 window.tsweb.registerView')
  const v = host.view.registered
  assert.equal(v.id, 'legacy-import')
  assert.equal(v.title, '数据导入')
  assert.equal(v.section, '后端设置')
  assert.equal(v.path, '/b/legacy-import')
  assert.equal(v.icon, 'layers')
  assert.equal(typeof v.render, 'function')

  const container = makeContainer()
  v.render(container)
  // 首屏是异步拉取，等一轮微任务
  await new Promise((r) => setTimeout(r, 0))

  assert.ok(host.styles.length > 0, '样式表应注入一次')
  assert.match(container.innerHTML, /导入模块/)
  const modsHtml = container.querySelector('#tswli-mods').innerHTML
  assert.match(modsHtml, /旧版 QQ 台账/)
  assert.match(modsHtml, /幽灵模块/)
  assert.match(modsHtml, /不可用原因：缺少依赖服务：qqBind/)
  // 不可用模块的 radio 必须 disabled，可用模块默认可选中
  const modEls = parseTags(modsHtml).filter((e) => 'data-tswli-mod' in e.attrs)
  assert.equal(modEls.length, 2)
  assert.equal(modEls[0].disabled, false, '可用模块不应被禁用')
  assert.equal(modEls[1].disabled, true, '不可用模块必须禁用')
  assert.match(container.querySelector('#tswli-dir').innerHTML, /C:\/data\/legacy-import/)
  // 未试运行前不允许执行
  assert.equal(container.querySelector('#tswli-run').disabled, true)
  assert.equal(container.querySelector('[data-tswli-act="dry"]').disabled, false)
})

test('闸门：没试运行过不能执行；空输入点试运行给明确提示（不发请求）', async () => {
  const host = setupHost({
    api: async (p) => {
      if (p === '/api/legacy-import/modules') return MODULES_OK
      if (p.startsWith('/api/legacy-import/history')) return { ok: true, data: { rows: [] } }
      return { ok: true, data: { imported: [], skipped: [], conflicts: [], applied: false, dryRun: true } }
    },
  })
  await loadClient()
  const container = makeContainer()
  host.view.registered.render(container)
  await new Promise((r) => setTimeout(r, 0))

  const before = host.calls.length
  // 点「试运行」但没填文件路径：本地校验兜住，不发请求
  container.fire('click', { target: container.querySelector('[data-tswli-act="dry"]') })
  await new Promise((r) => setTimeout(r, 0))
  assert.equal(host.calls.length, before, '空输入不应发请求')
  assert.equal(container.querySelector('#tswli-msg').textContent, '请填写数据目录内的文件路径')

  // 填好输入后点「确认导入」（仍未试运行）：闸门必须挡住，且不发请求
  // （真浏览器里该按钮此时是 disabled，点不动；这里直接派发事件，等价于"绕过 UI 状态"，
  //   闸门必须自己再判一次，不能只靠按钮 disabled）
  container.querySelector('#tswli-file').value = 'qq_accounts.json'
  container.fire('click', { target: container.querySelector('[data-tswli-act="run"]') })
  await new Promise((r) => setTimeout(r, 0))
  assert.equal(host.calls.length, before, '未试运行不得发起执行请求')
  assert.match(container.querySelector('#tswli-msg').textContent, /请先对当前输入做一次「试运行」/)
})

test('试运行 → 计划渲染（新增/跳过/冲突逐条）→ 输入改动作废计划 → 执行后显示 appliedCount 与快照', async () => {
  const plan = {
    ok: true,
    data: {
      imported: [{ username: 'Ivan', qq: '60001' }, { username: 'Judy', qq: '60002' }],
      skipped: [{ username: 'Broken', qq: 'abc', reason: 'QQ 号格式不正确' }],
      conflicts: [{ username: 'Zoe', existingQq: '60003', incomingQq: '60009' }],
      parseIssues: [{ username: 'Broken', qq: 'abc', reason: 'QQ 号格式不正确（应为 5-15 位数字，实际「abc」）' }],
      applied: false,
      module: 'qq-ledger',
      moduleTitle: '旧版 QQ 台账',
      dryRun: true,
      actor: 'tester',
      via: 'rest',
      sourceCount: 4,
    },
  }
  const applied = {
    ok: true,
    data: {
      imported: [{ username: 'Ivan', qq: '60001' }, { username: 'Judy', qq: '60002' }],
      skipped: [{ username: 'Broken', qq: 'abc', reason: 'QQ 号格式不正确' }],
      conflicts: [{ username: 'Zoe', existingQq: '60003', incomingQq: '60009' }],
      applied: true,
      appliedCount: 2,
      snapshot: { ok: true, total: 1, okCount: 1, servers: [{ id: 's1', name: '一服', ok: true, count: 2 }] },
      module: 'qq-ledger',
      moduleTitle: '旧版 QQ 台账',
      dryRun: false,
      actor: 'tester',
      via: 'rest',
    },
  }
  const host = setupHost({
    api: async (p, opts) => {
      if (p === '/api/legacy-import/modules') return MODULES_OK
      if (p.startsWith('/api/legacy-import/history')) return { ok: true, data: { rows: [{ t: '2026-01-01T00:00:00.000Z', module: 'qq-ledger', moduleTitle: '旧版 QQ 台账', dryRun: false, actor: 'tester', via: 'rest', ok: true, imported: 2, skipped: 1, conflicts: 1, appliedCount: 2 }] } }
      if (p === '/api/legacy-import/run') return opts.json && opts.json.dryRun ? plan : applied
      throw new Error(`未预期的请求 ${p}`)
    },
  })
  await loadClient()
  const container = makeContainer()
  const v = host.view.registered
  v.render(container)
  await new Promise((r) => setTimeout(r, 0))

  // 填文件路径
  container.querySelector('#tswli-file').value = 'qq_accounts.json'
  container.fire('input', { target: container.querySelector('#tswli-file') })

  // 试运行
  container.fire('click', { target: container.querySelector('[data-tswli-act="dry"]') })
  await new Promise((r) => setTimeout(r, 0))

  const runCall = host.calls.filter((c) => c.path === '/api/legacy-import/run')
  assert.equal(runCall.length, 1)
  assert.deepEqual(runCall[0].opts.json, { module: 'qq-ledger', dryRun: true, file: 'qq_accounts.json' })
  assert.equal(runCall[0].opts.method, 'POST')

  const resultHtml = container.querySelector('#tswli-result').innerHTML
  assert.match(resultHtml, /试运行计划：未写入台账/)
  assert.match(resultHtml, /新增 2 条 · 跳过 1 条 · 冲突 1 条/)
  assert.match(resultHtml, /台账已绑 60003，导入值为 60009/, '冲突必须逐条列出')
  assert.match(resultHtml, /QQ 号格式不正确/, '跳过原因要显示')
  assert.match(resultHtml, /解析预检/, '解析预检要显示（并说明与跳过的关系）')
  assert.match(container.querySelector('#tswli-msg').textContent, /试运行完成：计划新增 2 条/)
  // 试运行后允许执行
  assert.equal(container.querySelector('#tswli-run').disabled, false, '试运行后应放行「确认导入」')

  // 改动输入 → 计划作废、执行按钮重新禁用、结果区回到空态提示
  container.querySelector('#tswli-file').value = 'other.json'
  container.fire('input', { target: container.querySelector('#tswli-file') })
  assert.equal(container.querySelector('#tswli-run').disabled, true, '输入改动后必须重新试运行')
  const stale = container.querySelector('#tswli-result').innerHTML
  assert.doesNotMatch(stale, /试运行计划/, '作废的计划不应继续显示')
  assert.match(stale, /还没有执行结果/, '应回到空态提示')
  assert.match(container.querySelector('#tswli-msg').textContent, /输入已改动，请重新试运行/)

  // 重新试运行 → 执行（window.confirm 桩返回 true）
  container.fire('click', { target: container.querySelector('[data-tswli-act="dry"]') })
  await new Promise((r) => setTimeout(r, 0))
  container.fire('click', { target: container.querySelector('[data-tswli-act="run"]') })
  await new Promise((r) => setTimeout(r, 0))

  const runs = host.calls.filter((c) => c.path === '/api/legacy-import/run')
  assert.equal(runs.length, 3, '两次试运行 + 一次执行')
  assert.deepEqual(runs[2].opts.json, { module: 'qq-ledger', dryRun: false, file: 'other.json' })

  const after = container.querySelector('#tswli-result').innerHTML
  assert.match(after, /已写入台账/)
  assert.match(after, /实际写入 2 条/, '必须显示 appliedCount')
  assert.match(after, /快照下发 1\/1 台/, '必须显示快照下发结果')
  assert.match(container.querySelector('#tswli-msg').textContent, /导入完成：实际写入 2 条/)
  // 执行后会刷新历史
  assert.ok(host.calls.some((c) => c.path.startsWith('/api/legacy-import/history')), '执行后应刷新历史')
  await new Promise((r) => setTimeout(r, 0))
  assert.match(container.querySelector('#tswli-history').innerHTML, /旧版 QQ 台账/)
})

test('粘贴 JSON：非法 JSON 本地拦截（不发请求），合法则按 data 提交', async () => {
  const host = setupHost({
    api: async (p, opts) => {
      if (p === '/api/legacy-import/modules') return MODULES_OK
      if (p.startsWith('/api/legacy-import/history')) return { ok: true, data: { rows: [] } }
      return { ok: true, data: { imported: [], skipped: [], conflicts: [], applied: false, dryRun: true } }
    },
  })
  await loadClient()
  const container = makeContainer()
  host.view.registered.render(container)
  await new Promise((r) => setTimeout(r, 0))

  // 切到「粘贴 JSON」
  const radios = container.querySelectorAll('[data-tswli-source]')
  assert.equal(radios.length, 2)
  container.fire('change', { target: radios[1] })
  assert.equal(container.querySelector('#tswli-json-row').className, 'tswli-row')

  container.querySelector('#tswli-json').value = '{oops'
  const before = host.calls.length
  container.fire('click', { target: container.querySelector('[data-tswli-act="dry"]') })
  await new Promise((r) => setTimeout(r, 0))
  assert.equal(host.calls.length, before, '非法 JSON 不该发请求')
  assert.match(container.querySelector('#tswli-msg').textContent, /不是合法 JSON/)

  container.querySelector('#tswli-json').value = '{"records":{"A":{"qq":"12345"}}}'
  container.fire('click', { target: container.querySelector('[data-tswli-act="dry"]') })
  await new Promise((r) => setTimeout(r, 0))
  const last = host.calls[host.calls.length - 1]
  assert.deepEqual(last.opts.json, {
    module: 'qq-ledger',
    dryRun: true,
    data: { records: { A: { qq: '12345' } } },
  }, '粘贴 JSON 应作为 data 提交（不是 file）')
})

test('错误路径：后端 501（模块不可用）与 400（数据畸形）都如实显示，不抛错', async () => {
  let mode = 'unavailable'
  const host = setupHost({
    api: async (p) => {
      if (p === '/api/legacy-import/modules') return MODULES_OK
      if (p.startsWith('/api/legacy-import/history')) return { ok: true, data: { rows: [] } }
      if (mode === 'unavailable') {
        return { ok: false, status: 501, data: { error: '导入模块「旧版 QQ 台账」当前不可用：未安装或未启用 qq-bind 插件', reason: '未安装或未启用 qq-bind 插件', missingPlugin: 'qq-bind' } }
      }
      if (mode === 'auth401') return { ok: false, status: 401, data: null }
      if (mode === 'network') return { ok: false, status: 0, data: null, error: 'Failed to fetch' }
      return { ok: false, status: 400, data: { error: '旧台账缺少 records 字段；期望形如 {"records":{"角色名":{"qq":"12345"}}}' } }
    },
  })
  await loadClient()
  const container = makeContainer()
  host.view.registered.render(container)
  await new Promise((r) => setTimeout(r, 0))

  container.querySelector('#tswli-file').value = 'qq_accounts.json'
  container.fire('click', { target: container.querySelector('[data-tswli-act="dry"]') })
  await new Promise((r) => setTimeout(r, 0))
  assert.match(container.querySelector('#tswli-result').innerHTML, /未安装或未启用 qq-bind 插件/)
  assert.equal(container.querySelector('#tswli-msg').textContent, '试运行失败')

  mode = 'malformed'
  container.fire('click', { target: container.querySelector('[data-tswli-act="dry"]') })
  await new Promise((r) => setTimeout(r, 0))
  assert.match(container.querySelector('#tswli-result').innerHTML, /缺少 records 字段/)

  // 鉴权失效（401，data 为空）也要给中文提示，而不是 "HTTP 401"
  mode = 'auth401'
  container.fire('click', { target: container.querySelector('[data-tswli-act="dry"]') })
  await new Promise((r) => setTimeout(r, 0))
  assert.match(container.querySelector('#tswli-result').innerHTML, /登录状态已失效（HTTP 401）/)

  // 网络层失败（status 0 + error）同样如实显示，且不抛错
  mode = 'network'
  container.fire('click', { target: container.querySelector('[data-tswli-act="dry"]') })
  await new Promise((r) => setTimeout(r, 0))
  assert.match(container.querySelector('#tswli-result').innerHTML, /Failed to fetch/)
})

test('事件委托：重复进入页面不会叠加监听器（一次点击只发一次请求）', async () => {
  const host = setupHost({
    api: async (p) => {
      if (p === '/api/legacy-import/modules') return MODULES_OK
      if (p.startsWith('/api/legacy-import/history')) return { ok: true, data: { rows: [] } }
      return { ok: true, data: { imported: [], skipped: [], conflicts: [], applied: false, dryRun: true } }
    },
  })
  await loadClient()
  const container = makeContainer()
  const v = host.view.registered
  // 模拟"离开再进入本页"三次（宿主每次进入路由都会调 render(container)）
  for (let i = 0; i < 3; i++) v.render(container)
  await new Promise((r) => setTimeout(r, 0))

  assert.equal(container.listenerCount('click'), 1, 'click 监听器不得随进入次数累加')
  assert.equal(container.listenerCount('input'), 1)
  assert.equal(container.listenerCount('change'), 1)

  container.querySelector('#tswli-file').value = 'a.json'
  const before = host.calls.filter((c) => c.path === '/api/legacy-import/run').length
  container.fire('click', { target: container.querySelector('[data-tswli-act="dry"]') })
  await new Promise((r) => setTimeout(r, 0))
  const after = host.calls.filter((c) => c.path === '/api/legacy-import/run').length
  assert.equal(after - before, 1, '一次点击只能发一次请求')
})
