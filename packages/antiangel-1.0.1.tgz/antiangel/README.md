# antiangel

无前端 Cordis 插件，市场包名 `antiangel`，游戏服程序集 `antiangel.dll`，版本 1.0.1。
只检测已知 TerraAngel 隐藏存在感广播，不承诺识别所有修改客户端。

## 安装与配置

在市场安装并启用，由宿主按分服启用范围同步 DLL。无页面、REST 接口或新增面板权限。
先移除手工投放的同名 DLL。支持热加载与卸载，不需要为插件本身重启游戏服。
配置仍位于游戏服 `tshock/antiangel/config.json`：

| 键 | 默认值 | 含义 |
|---|---|---|
| enabled | true | 检测开关 |
| kick | true | 指纹命中后踢出 |
| broadcast | true | 命中后广播 |
| kickText | 检测到 TerraAngel 隐藏存在感指纹，已被踢出 | 踢出原因 |

命令 `/antiangel on/off/status/reload`，游戏内权限 `antiangel.admin`。
读写失败会报告错误；重载失败保留当前配置，启停保存失败还原原状态。

## Review 后修正

- 只匹配 PlayerControls(13) 中精确浮点坐标 (-114514, -1919810)，不再用整数截断近似匹配。
- 不再把未知包号 201 当作 TerraAngel 身份证据；包号可被其它扩展使用，也不能证明客户端身份。
- 严格使用当前声明包范围，校验可选字段、发送者编号与连接状态，不读取缓冲残留。
- 同一 Socket 的日志/广播/踢出最多每 5 秒处理一次；槽位复用的新 Socket 可立即检测。
- 取消每包 HMAC 和虚假的指纹保密承诺；指纹来自公开客户端源码，哈希不能防止绕过。
- 钩子安装失败直接终止加载；卸载只移除自己注册的命令与钩子，保留其它同名命令。

## 能力边界

指纹布局对照本地 TerraAngel PacketBuilderExtensions 源码，关闭或修改广播即可绕过检测。
未命中不代表官方客户端。日志描述为“命中指纹”，不作无法验证的客户端身份结论。
包号 201 若需要拦截应由明确的协议白名单策略处理，不作为本检测插件的默认惩罚条件。
替身宿主回归和实际 MonoMod detour 验证不等于真实游戏服混合版本联机验收。

回归：`dotnet run --project plugins/antiangel/test/Regression.csproj -c Release`。
真实 detour：追加 `-p:RealHooks=true`；2 参签名验证另追加 `-p:TwoParameterHost=true`。
