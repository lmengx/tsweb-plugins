// DLL deployment and lifecycle use the existing host registry.
export const name = 'antiangel'
export function apply() {}
