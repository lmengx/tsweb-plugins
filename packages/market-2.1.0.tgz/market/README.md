# 插件市场界面

界面采用选定的「原版留白」方案：居中圆角搜索、标签筛选、结果计数、数字分页，每页十二条。宽屏四列，普通桌面三列，平板两列，手机单列。卡片边框常驻，收藏点亮后显示黄色实心星星。保留全部插件和我的收藏，不显示安装数量概览。

浏览只展示市场索引中的条目，本地数据仅用于补充同名插件的安装状态和已安装版本，不混入本地独有插件或分类。搜索忽略大小写与首尾空格，覆盖包名、中文名、简述、完整描述、分类和作者名称；切换搜索或筛选后回到第一页。

界面使用宿主主题变量，支持浅色、深色与跟随系统。插件名称和收藏位于顶部，简述居中，版本、安装包大小、安装状态及安装/更新按钮位于底部。完整描述、作者、发布时间和已安装版本可在详情查看，不展示来源标识。

## 元数据与缺项

目前列表接口提供 name、version、description、author、tags、size、publishedAt、requires / missingDeps（依赖与缺失依赖），以及安装状态、来源和更新提示。author 可以是字符串或含 name 的对象；空作者和未知包大小不展示，未知大小不会显示为 0 KB。

参考图中的评分、评分人数、下载次数、认证状态、维护者列表及头像尚无对应接口字段或统计来源，因此不展示。当前本地 `tsweb-plugins/market.json` 的九个条目 author 均为空。插件图标与中文名称仍由前端映射维护，市场索引和列表接口没有可配置的图标或展示名称字段。补齐这些展示需要相应的索引字段、列表接口透传，以及下载/评分统计和认证规则，不能仅靠样式生成数据。

## 图标维护

`client/core/plugin-presentation.js` 的 `presentations` 按插件包名配置中文展示名称、图标名和卡片简述 `summary`，市场与已安装页面共用；`ui/presentation.js` 保留兼容导出。详情保留市场原始描述。`iconPaths` 保存静态 SVG 路径，由 `ui/MarketIcon.vue` 渲染。新插件没有配置时显示原包名、默认包裹图标与原始描述。没有后台图标上传入口。侧边栏图标配置独立，不改变市场卡片图标。

修改共享映射后执行 `node scripts/build-client.mjs web market`，使宿主与市场同步更新，或通过既有插件打包流程构建。

## 安装与管理

未安装显示安装；已安装显示安装状态，有新内容时保留更新按钮。市场卡片和详情都不提供禁用或卸载，相关管理由既有已安装插件页面处理。安装、更新与收藏沿用现有接口和错误提示，提交期间阻止重复操作。

## 依赖（tsweb.requires）

插件可以声明 `tsweb.requires`（发布时写入索引，列表接口透出 `requires` / `missingDeps`）。安装或更新前由服务端解析依赖闭包：

- 本机缺依赖时，卡片显示「需依赖 N」标记；点安装/更新**先弹窗**列出依赖（名称、版本、包大小），确认前**不下载任何包**；
- 确认后带 `installDeps: true` 重试：服务端按"被依赖者在前"安装依赖并自动启用，再装目标；结果提示注明"已先处理依赖"；
- 无依赖的插件保持一键安装（请求里 `installDeps: false`）；
- 依赖已装但被禁用 → 自动启用，不重装；
- 卸载被依赖的插件会被注册表拒绝并点名依赖方（例如卸 world-preview 前要先处理 history / house）。

世界预览自 base 2.4.0 起是独立插件 `world-preview`：`history` 与 `house` 声明 `requires: ["world-preview"]`，安装它们时会先弹窗下载世界预览（约 9.1 MB，含 1138 张图格贴图）。

## 镜像与下载

市场内容托管在自建 **Cloudflare R2**（桶 `tlry-plugins`，与 `mods-market` 同一套架构：R2 桶 + 自定义域直出，包不经过 Worker）。键与仓库目录一致：`/market.json` 与 `/packages/<file>.tgz`，公开基址 **`https://cdn.plugin.tlry.me`**，**默认排在候选镜像第一位**。

原因（实测）：`raw.githubusercontent.com` 在国内解析到黑洞地址（TCP 不通）；`gh-proxy` 速度在 43s~144s 之间波动；R2 直链稳定（索引亚秒级，9.76 MB 的 base 包 3~21 秒，视本地带宽）。

发布到 R2 的方式与 mods-market 一致（用本地已安装的 wrangler，不走 npx）：

```powershell
$env:CLOUDFLARE_API_TOKEN = '<token>'; $env:CLOUDFLARE_ACCOUNT_ID = '<account>'
& ..\mods-market\api\node_modules\.bin\wrangler.cmd r2 object put `
  "tlry-plugins/market.json" "--file=..\tsweb-plugins\market.json" `
  '--content-type=application/json; charset=utf-8' '--cache-control=public, max-age=60' --remote
# packages/*.tgz 逐个上传：--content-type=application/octet-stream --cache-control=public, max-age=31536000, immutable
```

下载相关配置（`<dataDir>/market/config.json`）：

| 键 | 默认 | 说明 |
|---|---|---|
| `mirrorOverride` | 空 | 非空时**只用**它作为基址（基址下就是 `market.json` 和 `packages/...`），适合指向自建镜像或本地联调 |
| `timeoutMs` | 20000 | 拉索引的超时（索引只有几十 KB，短超时便于快速切镜像）。**2.0.3 及更早版本用它同时约束安装包下载**，老版本必须调大才能下 10 MB 的 base 包 |
| `packageTimeoutMs` | 180000 | 2.0.4 起生效：下载发行包的下限超时；实际取它与 `size / 32 KB/s` 的较大者 |

下载失败会写服务器日志（含镜像名、耗时、原因），并在市场页用警示横幅显示，不再只有一闪而过的 toast。



市场索引里的 `market`（市场自身）与 `base`（核心件）不与普通业务插件共用一套提示，因为它们的生效语义不同：

| 项目 | 徽标 | 更新按钮 | 执行前 | 更新后 |
|---|---|---|---|---|
| `market` | 市场自身 | 更新市场 | 弹确认框：服务端半热重载生效、当前页面仍是旧界面、期间勿并行更新其它插件 | 持久横幅「插件市场已更新到 vX」+「刷新页面」按钮，不再重拉列表 |
| `base` | 核心件 | 更新核心件 | 弹确认框：面板半刷新后生效、游戏服 Base.dll 会重新按哈希同步、接收端不随插件更新、其它插件与数据不受影响 | 持久横幅「基础功能已更新到 vX」+ 同步失败台数（若有，黄框）+「刷新页面」按钮 |

结果横幅是页面内元素而非 toast：toast 会被随后的加载/失败提示覆盖，而"要不要刷新页面"必须一直看得见。`deployFailed` 非空时横幅转为警告样式并写明台数，落回普通提示的只有那些既无前端半、也无部署失败的更新。

后端配合点：`GET /api/market/list` 给市场条目带 `self`、给 base 带 `core`；`base` 属于"可更新的内置插件"，判定收口在 `src/plugin-gates.js`（`UPDATABLE_BUILTIN`），所以它能从市场更新，但仍不可卸载。

验证：`node --test plugins/market/test/update-gate.test.mjs plugins/market/test/market-ui.test.mjs plugins/market/test/deploy-failure.test.mjs`。
