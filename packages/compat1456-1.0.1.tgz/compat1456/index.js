// Game-server DLL lifecycle is managed by the host registry. No routes or UI.
export const name = 'compat1456'
export function apply() {}
