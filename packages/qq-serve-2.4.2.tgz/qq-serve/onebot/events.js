import WebSocket from 'ws'

// Owned by the Cordis adapter, never by a separate process or public relay.
export class OneBotEvents {
  constructor({ onEvent, onStatus = () => {}, retryMs = 3000, timeoutMs = 15000, heartbeatMs = 30000 }) {
    Object.assign(this, { onEvent, onStatus, retryMs, timeoutMs, heartbeatMs })
    this.state = { connected: false, connecting: false, qq: '', lastEventAt: null, error: '' }
    this.generation = 0
  }
  status(patch) { Object.assign(this.state, patch); this.onStatus({ ...this.state }) }
  configure(config) {
    const signature = JSON.stringify([config.enabled, config.endpoint, config.accessToken, config.botQq])
    if (signature === this.signature) return
    this.stop(); this.signature = signature; this.config = { ...config }
    if (config.enabled && config.endpoint) this.connect(this.generation)
  }
  connect(generation) {
    if (generation !== this.generation) return
    this.status({ connecting: true, connected: false, error: '' })
    let url
    try {
      url = new URL(this.config.endpoint)
      if (!['http:', 'https:', 'ws:', 'wss:'].includes(url.protocol) || url.username || url.password) throw new Error()
      url.protocol = ['https:', 'wss:'].includes(url.protocol) ? 'wss:' : 'ws:'
    } catch { this.status({ connecting: false, error: 'OneBot Endpoint 格式无效' }); return }
    const socket = this.socket = new WebSocket(url, {
      headers: this.config.accessToken ? { Authorization: `Bearer ${this.config.accessToken}` } : {},
      handshakeTimeout: this.timeoutMs, maxPayload: 1024 * 1024,
    })
    const echo = `qq-serve-login-${generation}`
    let alive = true
    const current = () => generation === this.generation && socket === this.socket
    this.deadline = setTimeout(() => { if (current()) socket.terminate() }, this.timeoutMs)
    this.deadline.unref?.()
    socket.on('open', () => { if (current()) socket.send(JSON.stringify({ action: 'get_login_info', params: {}, echo })) })
    socket.on('pong', () => { alive = true })
    socket.on('message', raw => {
      if (!current()) return
      let event
      try { event = JSON.parse(raw.toString()) } catch { return }
      if (event.echo === echo) {
        if (this.state.connected) return
        const qq = String(event.data?.user_id || '')
        if (event.status !== 'ok' || Number(event.retcode || 0) !== 0 || !/^\d{5,15}$/.test(qq) || (this.config.botQq && qq !== this.config.botQq)) {
          this.status({ error: 'OneBot 账号校验失败' }); socket.close(); return
        }
        clearTimeout(this.deadline)
        this.status({ connected: true, connecting: false, qq, error: '' })
        this.heartbeat = setInterval(() => {
          if (!current()) return
          if (!alive) return socket.terminate()
          alive = false; socket.ping()
        }, this.heartbeatMs)
        this.heartbeat.unref?.()
        return
      }
      if (!this.state.connected || !event.post_type || (event.self_id && String(event.self_id) !== this.state.qq)) return
      this.status({ lastEventAt: new Date().toISOString() })
      Promise.resolve().then(() => current() ? this.onEvent(event) : undefined).catch(() => {
        if (current()) this.status({ error: '消息处理失败，请检查服务配置' })
      })
    })
    socket.on('error', () => { if (current()) this.status({ error: 'OneBot 连接失败，正在重试' }) })
    socket.on('close', () => {
      if (!current()) return
      clearTimeout(this.deadline); clearInterval(this.heartbeat)
      this.status({ connected: false, connecting: false })
      this.retry = setTimeout(() => this.connect(generation), this.retryMs)
      this.retry.unref?.()
    })
  }
  stop() {
    this.generation++
    clearTimeout(this.retry); clearTimeout(this.deadline); clearInterval(this.heartbeat)
    this.socket?.terminate(); this.socket = null; this.signature = null
    this.status({ connected: false, connecting: false, qq: '', error: '' })
  }
}
