// Presentation is supplied by the capability owner, separate from business execution.
// HTTP adapters continue to return only business JSON; they never render or send.
export async function presentCapabilityResult(capability, result, options = {}) {
  if (typeof capability?.meta?.present !== 'function') return null
  try {
    const reply = await capability.meta.present(result, options)
    if (options.signal?.aborted) throw options.signal.reason
    if (!reply) return null
    if (!Array.isArray(reply.images) || !reply.images.length || reply.images.length > 20 || reply.images.some(image => !Buffer.isBuffer(image) || image.length > 8 * 1024 * 1024 || image.subarray(0, 8).toString('hex') !== '89504e470d0a1a0a')) throw new Error('插件图片回复格式无效')
    if (reply.images.reduce((sum, image) => sum + image.length, 0) > 32 * 1024 * 1024) throw new Error('插件图片回复总大小超限')
    return reply
  } catch (error) {
    if (options.signal?.aborted) throw error
    options.onError?.(error)
    return null
  }
}
