import { themes, defaults, validate, collect, sample, sampleProfile } from './data.js'
import { renderSvgPages } from './layout.js'

export function renderingConfig(renderer) {
  return { ...validate(renderer.config, defaults()), revision: renderer.revision, themes, messageKinds: ['home', 'account', 'servers', 'players'] }
}
export function registerQqTemplates(ctx) {
  return ctx.inject(['qqRenderer'], c => {
    const renderer = c.qqRenderer
    if (typeof renderer.registerTemplate !== 'function') return
    let cache = null
    const off = []
    try {
      for (const kind of ['home', 'account', 'servers', 'players']) off.push(renderer.registerTemplate(kind, { owner: 'qq-serve', build: async (options) => {
        const { preview = false, scenario = 'normal', signal, profile, botStatus } = options
        const config = renderingConfig(renderer), theme = options.theme ?? config.theme
        if (!themes.some(value => value.id === theme)) throw Object.assign(new Error('图片风格无效'), { status: 400 })
        let data
        if (preview) data = sample(scenario)
        else if (kind === 'account') data = { rows: [], generatedAt: new Date().toISOString(), sample: false }
        else {
          const key = JSON.stringify(config.addresses)
          if (cache?.key === key && cache.expiresAt > Date.now()) data = cache.data
          else {
            data = await collect(c, config.addresses, signal)
            cache = { key, data, expiresAt: Date.now() + 10_000 }
          }
        }
        return { pages: renderSvgPages(data, kind, theme, { profile: preview ? sampleProfile(scenario) : profile, botStatus: preview ? { connected: true } : botStatus }),
          text: ({ home: '机器人主页', account: '账号服务', players: '全服在线玩家', servers: '服务器列表' })[kind] + ' · ' + themes.find(value => value.id === theme).name, data }
      } }))
    } catch (error) { off.reverse().forEach(dispose => dispose()); throw error }
    return () => { off.reverse().forEach(dispose => dispose()); cache = null }
  })
}
