const clean = (value, limit = 120) =>
  String(value ?? "")
    .replace(/[\u0000-\u001f\u007f-\u009f]/g, " ")
    .slice(0, limit);
export const themes = Object.freeze([
  {
    id: "space",
    number: 2,
    name: "深空面板",
    description: "深蓝网格与冷光，高对比控制台",
  },
  {
    id: "pixel",
    number: 3,
    name: "像素营地",
    description: "原创像素地景与营地配色，默认风格",
  },
  {
    id: "cream",
    number: 4,
    name: "奶油便笺",
    description: "暖杏纸面与柔和圆角卡片",
  },
]);
export const defaults = () => ({
  enabled: true,
  theme: "pixel",
  addresses: {},
});
export function sampleProfile(scenario = "normal") {
  if (scenario === "empty") return { bound: false };
  if (scenario === "partial")
    return { bound: false, pending: true, username: "等待验证的冒险家" };
  return {
    bound: true,
    username: scenario === "long" ? "这是一个需要完整显示的角色名字" : "星野",
    boundAt: "2026-10-28T00:18:00+08:00",
    game: {
      found: true,
      server: "星落 · 生存一服",
      group: "default",
      deaths: 12,
      fishingQuests: 8,
      onlineMinutes: 1365,
    },
  };
}
export function validate(input, base = defaults()) {
  if (!input || typeof input !== "object" || Array.isArray(input))
    throw Object.assign(new Error("渲染配置格式无效"), { status: 400 });
  const next = { ...base, addresses: { ...base.addresses } };
  if (input.enabled !== undefined) {
    if (typeof input.enabled !== "boolean")
      throw Object.assign(new Error("启用状态必须为布尔值"), { status: 400 });
    next.enabled = input.enabled;
  }
  if (input.theme !== undefined) {
    if (!themes.some((theme) => theme.id === input.theme))
      throw Object.assign(new Error("仅支持风格 2、3、4"), { status: 400 });
    next.theme = input.theme;
  }
  if (input.addresses !== undefined) {
    if (
      !input.addresses ||
      typeof input.addresses !== "object" ||
      Array.isArray(input.addresses) ||
      Object.keys(input.addresses).length > 500
    )
      throw Object.assign(new Error("游戏地址配置无效"), { status: 400 });
    next.addresses = {};
    for (const [id, value] of Object.entries(input.addresses)) {
      if (
        typeof value !== "string" ||
        value.length > 200 ||
        /[\s<>"'@/?#\\]/.test(value) ||
        id.length > 128
      )
        throw Object.assign(
          new Error("游戏地址应为 IP 或域名及端口，不得包含 REST 路径或凭据"),
          { status: 400 },
        );
      if (
        value &&
        !/^(?:\[[0-9a-fA-F:]+\]|[\p{L}\p{N}_.-]+):[0-9]{1,5}$/u.test(value)
      )
        throw Object.assign(
          new Error("请填写游戏连接地址，例如 play.example.com:7777"),
          { status: 400 },
        );
      if (
        value &&
        (Number(value.split(":").at(-1)) < 1 ||
          Number(value.split(":").at(-1)) > 65535)
      )
        throw Object.assign(new Error("游戏端口必须在 1–65535 之间"), {
          status: 400,
        });
      next.addresses[id] = value;
    }
  }
  return next;
}
export async function collect({ servers, tshock }, addresses = {}, signal) {
  const listed = await servers.list();
  if (!Array.isArray(listed)) throw new Error("服务器清单格式无效");
  const source = listed.filter((row) => row.enabled !== false);
  const rows = new Array(source.length);
  let cursor = 0;
  await Promise.all(
    Array.from({ length: Math.min(4, source.length) }, async () => {
      while (cursor < source.length) {
        if (signal?.aborted) throw signal.reason || new Error("查询已取消");
        const index = cursor++,
          row = source[index];
        const output = {
          id: String(row.id),
          name: clean(row.name || "未命名服务器"),
          address: addresses[String(row.id)] || "未配置游戏地址",
          available: false,
          players: [],
          capacity: null,
        };
        rows[index] = output;
        try {
          const raw = servers.getRaw(row.id);
          if (!raw || raw.enabled === false) continue;
          const result = await tshock.fetchFor(
            raw,
            "/v2/players/list",
            {},
            { timeoutMs: 5000 },
          );
          if (
            !result.ok ||
            !result.data ||
            result.data.error ||
            Number(result.status) >= 400 ||
            Number(result.data.status) >= 400 ||
            !Array.isArray(result.data.players)
          )
            continue;
          output.players = result.data.players
            .filter((player) => player && player.active !== false)
            .map((player) =>
              clean(player.nickname || player.name || "未命名玩家"),
            );
          output.available = true;
        } catch {
          /* Unavailable is distinct from an empty server. Do not expose upstream errors/tokens. */
        }
      }
    }),
  );
  if (signal?.aborted) throw signal.reason || new Error("查询已取消");
  return { rows, generatedAt: new Date().toISOString(), sample: false };
}
export function sample(scenario = "normal") {
  const data = {
    generatedAt: "2026-10-28T00:18:00+08:00",
    sample: true,
    rows: [
      {
        id: "one",
        name: "星落 · 生存一服",
        address: "203.0.113.20:7777",
        available: true,
        players: [
          "小木偶",
          "云间",
          "月见草",
          "北岛",
          "晚风",
          "星野",
          "折纸",
          "Mango",
        ],
        capacity: 32,
      },
      {
        id: "two",
        name: "星落 · 建筑二服",
        address: "203.0.113.21:7777",
        available: true,
        players: ["白桃", "橘子汽水", "七月", "竹间", "Neko"],
        capacity: 24,
      },
      {
        id: "three",
        name: "星落 · 大师挑战",
        address: "203.0.113.22:7777",
        available: true,
        players: ["旅人", "栗子", "青石"],
        capacity: 16,
      },
    ],
  };
  if (scenario === "empty")
    data.rows.forEach((row) => {
      row.players = [];
    });
  if (scenario === "partial") {
    data.rows[1].available = false;
    data.rows[1].players = [];
  }
  if (scenario === "long") {
    data.rows[0].name = "星落 · 旅行者的超长名字生存服务器";
    data.rows[0].players = [
      "这是一个需要完整显示的长名字玩家",
      ...Array.from({ length: 150 }, (_, i) => "冒险家" + (i + 1)),
    ];
  }
  return data;
}
