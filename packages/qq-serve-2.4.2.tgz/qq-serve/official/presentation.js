import { escapeMarkdown } from "./messages.js";

// Optional visual enrichment: business replies remain complete without it.
export async function renderVisualReply(
  value,
  { renderer, signal, botStatus, onError } = {},
) {
  if (
    !value?.visual ||
    !renderer?.config?.enabled ||
    !["home", "account"].includes(value.visual.kind)
  )
    return value;
  try {
    const result = await renderer.render(value.visual.kind, {
      signal,
      profile: value.visual.profile,
      botStatus,
    });
    const profile = value.visual.profile;
    const summary =
      value.visual.kind === "home"
        ? "# TSWeb 机器人\n\n选择下方入口开始；发送“菜单”可随时返回。"
        : "# 账号服务\n\n" +
          (profile.bound
            ? "绑定状态：**已绑定** · 角色：**" +
              escapeMarkdown(profile.username) +
              "**"
            : profile.pending
              ? "绑定状态：**等待游戏内验证**"
              : "绑定状态：**未绑定**");
    return { ...value, images: result.images, markdown: summary };
  } catch (error) {
    if (signal?.aborted) throw error;
    onError?.(error);
    return value;
  }
}
