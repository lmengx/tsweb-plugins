/**
 * qq-serve 合并权限契约。
 *
 * 四个域各自保留一份契约文件（源码可读、按域评审），此文件只做合并：
 *   - owner 统一为 qq-serve（check-access 要求 contract.owner === 插件目录名）
 *   - module / action / feature 的 id 与 permission 字符串**一律不改**：
 *     accounts 把授权落在 user.extraPermissions（存的就是 module.permission），
 *     base 前端直接 host.canFeature('qq-bind:binding')，改 id 等于静默清空既有授权。
 */
import serve from './mode-access.js'
import bind from './bind/access.js'
import official from './official/access.js'
import onebot from './onebot/access.js'

const parts = [serve, bind, official, onebot]
const pick = key => parts.flatMap(contract => contract[key] || [])
const dedupe = list => [...new Map(list.map(item => [item.id, item])).values()]

export default {
  owner: 'qq-serve',
  version: 2,
  modules: dedupe(pick('modules')),
  actions: dedupe(pick('actions')),
  features: dedupe(pick('features')),
}
