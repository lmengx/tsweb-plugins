const fail = message => Object.assign(new Error(message), { status: 400 })
export function validateRobot(config, provider) {
  if (provider === 'official') {
    if (!/^\d{1,32}$/.test(config.official.appId)) throw fail('请先填写有效的官方机器人 AppID')
    if (!config.official.appSecret) throw fail('请先填写官方机器人 AppSecret')
    if (config.official.appSecret.length > 256 || /[\u0000-\u0020\u007f]/.test(config.official.appSecret)) throw fail('官方机器人 AppSecret 格式无效')
  } else if (provider === 'onebot') {
    let endpoint
    try { endpoint = new URL(config.onebot.endpoint) } catch {}
    if (!endpoint || !['http:', 'https:', 'ws:', 'wss:'].includes(endpoint.protocol) || endpoint.username || endpoint.password)
      throw fail('请先填写有效的 OneBot Endpoint，凭据请填写在 Token 中')
    if (config.onebot.botQq && !/^\d{5,15}$/.test(config.onebot.botQq)) throw fail('OneBot QQ 号格式无效')
  } else throw fail('不支持的机器人类型')
}
export function validateMode(config) {
  if (config.mode !== 'onebot') validateRobot(config, 'official')
  if (config.mode !== 'official') validateRobot(config, 'onebot')
}
// Tests inspect draft credentials without persisting or starting an adapter.
export async function testConnection(config, provider, { fetchImpl = globalThis.fetch } = {}) {
  validateRobot(config, provider)
  try {
    if (provider === 'official') {
      const response = await fetchImpl('https://bots.qq.com/app/getAppAccessToken', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ appId: config.official.appId, clientSecret: config.official.appSecret }), signal: AbortSignal.timeout(15000),
      })
      const body = await response.json()
      if (!response.ok || !body.access_token) throw new Error('auth')
      return { ok: true, provider, message: '官方机器人凭据认证成功；群消息接收权限需以实际事件为准。' }
    }
    // 合并后 OneBot 客户端就在本插件内，静态导入即可（缺件不再可能发生）。
    const { OneBotClient } = await import('./onebot/client.js')
    const client = new OneBotClient({ endpoint: config.onebot.endpoint, token: config.onebot.accessToken, fetchImpl })
    const login = await client.getLoginInfo()
    if (!login?.user_id) throw new Error('identity')
    if (config.onebot.botQq && String(login.user_id) !== config.onebot.botQq)
      return { ok: false, provider, message: '连接返回的机器人 QQ 与配置不一致，请检查 Endpoint 或机器人 QQ 号。' }
    const status = await client.call('get_status')
    if (status?.online !== true || status?.good === false)
      return { ok: false, provider, message: 'OneBot API 可访问，但机器人未在线或状态异常。' }
    return { ok: true, provider, botQq: String(login.user_id), message: 'OneBot 连接成功，机器人在线。' }
  } catch {
    // Never return upstream bodies/errors: they may contain credentials.
    return { ok: false, provider, message: provider === 'official' ? '官方机器人认证失败或请求超时，请检查 AppID、AppSecret 和网络。' : 'OneBot 连接失败或请求超时，请检查 Endpoint、Access Token 和网络。' }
  }
}
