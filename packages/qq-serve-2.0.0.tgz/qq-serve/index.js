/**
 * QQ 服务（qq-serve）组合根。
 *
 * 合并历史：本插件吸收 qq-bind（台账/凭据/适配器注册表）、qq-official（官方机器人）、
 * onebot-bridge（OneBot 接入）与旧 qq-serve（模式/凭据/渲染页签）四个插件。
 * 对外只有一个插件、一个入口页、一个数据目录（data/qq-serve）、一份权限契约。
 *
 * 装配顺序带依赖含义：
 *   1 mode     提供 qqServe 服务（模式与凭据的唯一配置源）
 *   2 bind     提供 qqBind 服务（台账唯一权威，官方端与 OneBot 端都要它）
 *   3 official 把官方机器人适配器挂到 qqServe
 *   4 onebot   把 OneBot 适配器挂到 qqServe
 *   5 applyMode 让已注册适配器按保存的模式启停
 *
 * 鉴权只做一次：四个域的 /api/* 全部复用同一份合并契约下发的 app。
 * 外部 OneBot webhook 仍挂在原始 app 上（机器令牌鉴权，不属于管理员 API）。
 */
import access from './access.js'
import { applyMode } from './mode.js'
import { applyBind } from './bind/index.js'
import { applyOfficial } from './official/index.js'
import { applyOnebot } from './onebot/index.js'

export const name = 'qq-serve'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths', 'plugins']

export async function apply(ctx) {
  const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx)
  const deps = { app, dataDir: ctx.paths.dataOf(name) }

  await applyMode(ctx, deps)
  applyBind(ctx, deps)
  await applyOfficial(ctx, deps)
  await applyOnebot(ctx, deps)
  await deps.serve.applyMode()
}