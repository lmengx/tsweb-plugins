const get = (ctx, name) => {
  try {
    return ctx.get(name)
  } catch {
    return null
  }
}
const fail = (status, message) => Object.assign(new Error(message), { status })
export function registerRendering(app, ctx) {
  const status = async () => {
    const renderer = get(ctx, 'qqRenderer'),
      registry = ctx.plugins.get('qq-render'),
      servers = get(ctx, 'servers')
    if (renderer) await renderer.ready
    const rows = servers?.list ? await servers.list() : []
    return {
      installed: Boolean(registry),
      loaded: Boolean(renderer),
      config: renderer?.publicConfig() || null,
      servers: rows
        .filter((row) => row.enabled !== false)
        .map((row) => ({
          id: String(row.id),
          name: String(row.name || '未命名服务器'),
        })),
    }
  }
  const route = (handler) => async (req, res) => {
    try {
      res.json(await handler(req))
    } catch (error) {
      res
        .status(error.status || 500)
        .json({
          error: error.status
            ? error.message
            : '图片渲染暂不可用，请检查后台日志与插件状态。',
        })
    }
  }
  app.get('/api/qq-serve/rendering', route(status))
  app.post(
    '/api/qq-serve/rendering',
    route(async (req) => {
      const input = req.body || {}
      if (input.action === 'install') {
        if (!ctx.plugins.get('qq-render'))
          await ctx.plugins.installFromDir('qq-render', { enable: true })
        else if (!get(ctx, 'qqRenderer')) await ctx.plugins.enable('qq-render')
      } else if (input.action === 'enable') {
        if (!ctx.plugins.get('qq-render'))
          throw fail(409, '请先安装图片渲染插件')
        if (!get(ctx, 'qqRenderer')) await ctx.plugins.enable('qq-render')
      } else if (input.action === 'save') {
        const renderer = get(ctx, 'qqRenderer')
        if (!renderer) throw fail(409, '请先安装并启用图片渲染插件')
        await renderer.save(input.config, input.revision)
      } else throw fail(400, '未知渲染操作')
      if (input.action === 'install' || input.action === 'enable') {
        await ctx.plugins.loader?.loaded?.get('qq-render')?.handle?.await()
        const renderer = get(ctx, 'qqRenderer')
        if (!renderer)
          throw fail(409, '图片渲染插件等待依赖或未能启动，请检查插件状态')
        await renderer.ready
      }
      return status()
    }),
  )
  app.post(
    '/api/qq-serve/rendering/preview',
    route(async (req) => {
      const renderer = get(ctx, 'qqRenderer')
      if (!renderer) throw fail(409, '请先安装并启用图片渲染插件')
      const { kind, theme, scenario = 'normal', live = false } = req.body || {}
      if (
        !['servers', 'players'].includes(kind) ||
        !['space', 'pixel', 'cream'].includes(theme) ||
        !['normal', 'empty', 'partial', 'long'].includes(scenario) ||
        typeof live !== 'boolean'
      )
        throw fail(400, '预览参数无效')
      const result = await renderer.render(kind, {
        preview: !live,
        theme,
        scenario,
      })
      return {
        images: result.images.map(
          (buffer) => 'data:image/png;base64,' + buffer.toString('base64'),
        ),
        sample: !live,
        pages: result.images.length,
      }
    }),
  )
}
