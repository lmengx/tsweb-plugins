import { randomBytes, createHash } from 'node:crypto'
const revision = new URL(import.meta.url).search
const { CredentialDelivery } = await import(`../bind/credential-delivery.js${revision}`)
const publicError = cause => cause?.publicMessage || '操作暂未完成，请管理员检查游戏服连接、插件版本与后台日志。'

export async function registerAccountCommands(manager, { getService, now = () => Date.now(), pollMs = 2000 }) {
  const delivery = new CredentialDelivery(manager.dataDir, now,
    { state: 'official-credential-delivery.json', key: 'official-credential-delivery.key' })
  await delivery.load()
  const pending = new Map(), busy = new Set(), tasks = new Set(), unregister = []
  let disposed = false
  const identityOf = message => ({ provider: 'qq-official', appId: manager.config.appId, subject: message.senderId })
  const keyOf = identity => delivery.keyOf(identity)
  const service = async () => {
    const core = getService('qqBind')
    if (!core?.registerOfficial || !core?.completeOfficialBinding) throw Object.assign(new Error('missing core'), { publicMessage: '请管理员启用并更新 QQ 绑定插件。' })
    await core.ready
    return core
  }
  const card = (context, title, lines) => context.ui.card({ title, lines,
    buttons: [[context.ui.button.callback('返回账号服务', 'account', [], { style: 0 }), context.ui.button.callback('主菜单', 'menu', [], { style: 0 })]] })
  const deliver = async (core, identity, context) => {
    try {
      const value = await delivery.get(identity)
      if (!value || !core.officialPasswordMatches(identity, value.username, value.passwordHash)) return false
      await context.sendPrivate({
        text: `账号注册\n角色名：${value.username}\n初始密码：${value.password}\n请妥善保管，不要转发到群里。`,
        markdown: `# 🔐 账号注册\n\n角色名：**${context.ui.escapeMarkdown(value.username)}**\n\n初始密码：\`${value.password}\`\n\n请妥善保管，不要转发到群里。`,
        buttons: [[context.ui.button.command('修改密码', '/改密码 ', { enter: false })]],
      })
    } catch {
      manager.log('account', '私信密码未确认送达，保留待领取凭据', { delivery: 'pending' })
      return false
    }
    // A disk error after an accepted send does not turn delivery into failure.
    await delivery.remove(identity).catch(() => { manager.log('account', '私信已发送，待领取记录清理失败') })
    return true
  }
  const outcome = async (core, identity, context, result, action) => {
    const delivered = await deliver(core, identity, context)
    manager.log('account', `${action}完成`, { delivery: delivered ? 'sent' : 'pending', sync: result.snapshot?.ok === true ? 'ok' : 'pending' })
    const notice = delivered ? '初始密码已私信发送，请查看机器人私聊。' : '私信未送达，请添加机器人后私聊发送“领取密码”。'
    let enrichment = ''
    const bridge = getService('onebotBridge')
    if (context.message.kind === 'group' && bridge?.mode === 'hybrid' && bridge?.config?.enabled && bridge?.config?.allowTransfer) {
      enrichment = '\n如需关联 QQ，请打开“绑定转移”菜单，点击“一键转移”。'
    }
    return { text: `${action}成功\n角色：${result.username}\n${notice}${enrichment}`,
      markdown: `# ✅ ${action}成功\n\n角色：**${context.ui.escapeMarkdown(result.username)}**\n\n${notice}${enrichment}`,
      buttons: enrichment ? [[context.ui.button.callback('绑定转移', 'transfer')]] : [] }
  }
  const run = handler => async context => {
    const identity = identityOf(context.message), key = keyOf(identity)
    if (disposed || context.signal.aborted) return
    if (busy.has(key)) return card(context, '正在办理', ['已有操作正在处理，请稍后查看结果。'])
    busy.add(key)
    try { return await handler(context, identity, key) }
    catch (cause) { manager.log('account', '账号操作未完成', { status: cause.status || 503 }); return card(context, '未能完成', [context.ui.escapeMarkdown(publicError(cause))]) }
    finally { busy.delete(key) }
  }
  const showProfile = async (context, identity, profile) => {
      profile ??= await (await service()).officialProfile(identity)
      if (!profile.bound) return card(context, '我的信息', ['当前 QQ 尚未绑定角色。', '新玩家请发送“注册 角色名”；已有账号请发送“绑定 角色名”，并在游戏内验证。'])
      const lines = [`角色：${context.ui.escapeMarkdown(profile.username)}`, '绑定身份：QQ 官方机器人',
        ...(profile.boundAt ? [`绑定时间：${context.ui.escapeMarkdown(profile.boundAt)}`] : [])]
      const game = profile.game
      if (!game) lines.push('绑定记录正常，游戏资料暂不可用；可通过“服务器列表”检查连接。')
      else {
        lines.push(`资料来源：${context.ui.escapeMarkdown(game.server || '游戏服')}`)
        if (!game.found) lines.push('该服尚无角色游戏资料，请先进入游戏。')
        else {
          if (game.group) lines.push(`游戏用户组：${context.ui.escapeMarkdown(game.group)}`)
          if (Number.isFinite(game.deaths)) lines.push(`死亡次数：${game.deaths}`)
          if (Number.isFinite(game.fishingQuests)) lines.push(`钓鱼任务：${game.fishingQuests}`)
        }
        if (Number.isFinite(game.onlineMinutes)) lines.push(`累计游戏时长：${Math.floor(game.onlineMinutes)} 分钟`)
      }
      const result = card(context, '我的信息', lines)
      if (context.message.kind === 'c2c') result.buttons.unshift([context.ui.button.callback('领取初始密码', 'claimpassword'), context.ui.button.command('修改密码', '/改密码 ', { enter: false })])
      return result
  }
  unregister.push(manager.registerCommand({ name: 'me', aliases: ['我的信息', '我的账号', '个人信息'], description: '查看自己的绑定角色和游戏资料', templateAction: true, run: run((context, identity) => showProfile(context, identity)) }))
  unregister.push(manager.registerCommand({ name: 'account', aliases: ['账号', '账号服务', '注册帮助', '绑定帮助'], description: '账号服务：注册、绑定、密码与转移', templateAction: true,
    run: run(async (context, identity) => {
      const profile = await (await service()).officialProfile(identity)
      if (profile.bound) return showProfile(context, identity, profile)
      return context.ui.card({ title: '账号服务', lines: ['请选择账号操作；不清楚如何选择，请查看“账户服务说明”。'],
        buttons: [[context.ui.button.command('注册新账号', '/注册 ', { enter: false }), context.ui.button.command('绑定已有角色', '/绑定 ', { enter: false })],
          [context.ui.button.callback('绑定转移', 'transfer'), context.ui.button.callback('账户服务说明', 'accounthelp')],
          [context.ui.button.callback('主菜单', 'menu', [], { style: 0 })]] })
    }) }))
  unregister.push(manager.registerCommand({ name: 'accounthelp', aliases: ['账户服务说明', '账号服务说明'], description: '说明注册、绑定已有角色与旧账号转移', templateAction: true,
    run: context => card(context, '账户服务说明', [
      '如果你还没有进入游戏服，就选择“注册新账号”；如果游戏服中已有你的角色，就选择“绑定已有角色”。在输入框中补全角色名后发送即可。',
      '绑定转移：如果你已有旧版机器人账号，就选择“绑定转移”，点击“一键转移”直接发送消息即可。',
    ]) }))
  unregister.push(manager.registerCommand({ name: 'register', aliases: ['注册'], description: '注册新账号：注册 角色名', run: run(async (context, identity, key) => {
    const player = context.args.join(' ').trim()
    if (!player) return card(context, '注册新账号', ['请发送：@机器人 注册 角色名。已有账号请使用“绑定”。'])
    if (pending.has(key)) return card(context, '已有待验证绑定', ['请先完成游戏内验证，或发送“取消绑定”。'])
    const core = await service()
    const result = await core.registerOfficial({ identity, player, signal: context.signal,
      prepareDelivery: value => delivery.put(identity, value) })
    return outcome(core, identity, context, result, '注册')
  }) }))
  unregister.push(manager.registerCommand({ name: 'transfer', aliases: ['绑定转移'], description: '将旧 QQ 绑定迁移到官方机器人身份', run: run(async (context, identity) => {
    if (context.message.kind !== 'group') return card(context, '绑定转移', ['请在群内发起绑定转移。'])
    const bridge = getService('onebotBridge')
    if (!bridge?.beginTransfer) return card(context, '绑定转移', ['OneBot 身份补全未启用。'])
    if (context.args.length) {
      if (context.args.length !== 1 || context.source === 'interaction' || !bridge.observeOfficialTransfer) return card(context, '绑定转移', ['请重新打开绑定转移菜单，点击“一键转移”。'])
      await bridge.observeOfficialTransfer({ identity, code: context.args[0], groupOpenid: context.message.groupOpenid, context })
      return
    }
    if (manager.config.responseMode === 'text' || manager.config.keyboardMode !== 'custom')
      return card(context, '绑定转移', ['请管理员启用 Markdown 消息与自定义按钮后，再使用一键转移。'])
    const result = bridge.beginTransfer({ identity, groupOpenid: context.message.groupOpenid })
    return context.ui.card({ title: '绑定转移', lines: ['将原 QQ 绑定关联到当前官方机器人身份。', '角色和密码保持不变。点击下方按钮即可完成。', '本次入口 5 分钟内有效。'],
      buttons: [[context.ui.button.command('一键转移', `/绑定转移 ${result.code}`, { enter: true, style: 1 })],
        [context.ui.button.callback('更新转移入口', 'transfer', [], { style: 0 }), context.ui.button.callback('返回账号服务', 'account', [], { style: 0 })],
        [context.ui.button.callback('主菜单', 'menu', [], { style: 0 })]] })
  }) }))
  unregister.push(manager.registerCommand({ name: 'bind', aliases: ['绑定'], description: '绑定已有账号：绑定 角色名，然后游戏内验证', run: run(async (context, identity, key) => {
    const player = context.args.join(' ').trim()
    if (!player) return card(context, '绑定已有账号', ['请发送：@机器人 绑定 角色名，然后在已登录该账号的游戏中输入验证码。'])
    if (pending.has(key)) return card(context, '等待游戏内验证', ['已有绑定请求。请完成验证，或发送“取消绑定”后重试。'])
    if (pending.size >= 100) return card(context, '请稍后再试', ['当前待验证请求较多，请稍后再试。'])
    const core = await service(), request = await core.prepareOfficialBinding({ identity, player, signal: context.signal })
    // Hex survives Markdown rendering and copying without underscore escapes.
    const code = randomBytes(12).toString('hex'), hash = createHash('sha256').update(code).digest('hex')
    // Only the hash is retained. Verification is tied to the initiating identity,
    // the exact game account, server, conversation and live plugin session.
    pending.set(key, { ...request, hash, context, expiresAt: now() + 180000, inFlight: false })
    return card(context, '请在游戏内验证', [`待绑定角色：${context.ui.escapeMarkdown(request.username)}`, '先登录该游戏账号，再在游戏聊天框输入：', `/qqbind ${code}`, '验证码 3 分钟内有效。验证通过后，本群收到结果，随机初始密码私信发送。'])
  }) }))
  unregister.push(manager.registerCommand({ name: 'cancelbind', aliases: ['取消绑定'], description: '取消尚未验证的绑定请求', run: run(async (context, identity, key) => {
    const request = pending.get(key)
    if (request && (request.context.message.kind !== context.message.kind || request.context.message.replyTarget.targetId !== context.message.replyTarget.targetId))
      return card(context, '请回原会话操作', ['请在发起绑定的群或私聊中取消请求。'])
    pending.delete(key)
    return card(context, '已取消待验证请求', ['已完成的绑定不受影响。'])
  }) }))
  unregister.push(manager.registerCommand({ name: 'claimpassword', aliases: ['领取密码'], description: '仅私聊：领取未送达的初始密码', sensitive: true, run: run(async (context, identity) => {
    if (context.message.kind !== 'c2c') return card(context, '请在私聊领取', ['请打开机器人私聊并发送“领取密码”，密码不会显示在群里。'])
    const core = await service()
    if (await deliver(core, identity, context)) return
    return card(context, '没有可领取的密码', ['没有有效的待领取初始密码，或发送未确认成功。请确认使用办理账号时的同一 QQ；超过 24 小时请联系管理员。'])
  }) }))
  unregister.push(manager.registerCommand({ name: 'password', aliases: ['改密码', '修改密码'], description: '仅私聊：改密码 新密码，无需旧密码', sensitive: true, run: run(async (context, identity) => {
    if (context.message.kind !== 'c2c') return context.ui.card({ title: '请在私聊改密码', lines: ['打开机器人私聊，发送“改密码 新密码”。'] })
    if (context.args.length !== 1) return context.ui.card({ title: '修改密码', lines: ['请发送：改密码 新密码（至少 6 位，不含空格）。'],
      buttons: [[context.ui.button.command('输入新密码', '/改密码 ', { enter: false })]] })
    const core = await service()
    if (!core.changeOfficialPassword) throw Object.assign(new Error('missing password support'), { publicMessage: '请管理员更新 QQ 绑定插件。' })
    await core.changeOfficialPassword({ identity, password: context.args[0], signal: context.signal })
    await delivery.remove(identity).catch(() => { manager.log('account', '改密完成，旧待领取记录清理失败') })
    return context.ui.card({ title: '✅ 密码修改成功', lines: [] })
  }) }))
  const poll = async () => {
    for (const [key, request] of pending) {
      if (disposed || request.context.signal.aborted) { pending.delete(key); continue }
      if (request.inFlight || busy.has(key)) continue
      if (now() >= request.expiresAt) {
        pending.delete(key)
        await request.context.reply(card(request.context, '绑定验证已过期', ['账号未修改，请重新发送“绑定 角色名”。'])).catch(() => {})
        continue
      }
      request.inFlight = true; busy.add(key)
      try {
        const core = await service()
        const result = await core.completeOfficialBinding({ identity: request.identity, player: request.username, serverId: request.serverId,
          proofHash: request.hash, signal: request.context.signal, prepareDelivery: value => delivery.put(request.identity, value) })
        if (result) {
          pending.delete(key)
          const response = await outcome(core, request.identity, request.context, result, '绑定')
          await request.context.reply(response).catch(() => { manager.log('account', '绑定已完成，群内结果未确认送达') })
        }
      } catch (cause) {
        pending.delete(key)
        await request.context.reply(card(request.context, '绑定未完成', [publicError(cause)])).catch(() => {})
      } finally { request.inFlight = false; busy.delete(key) }
    }
  }
  const timer = setInterval(() => { const task = poll().catch(() => {}); tasks.add(task); void task.finally(() => tasks.delete(task)) }, pollMs)
  timer.unref?.()
  return async () => { disposed = true; clearInterval(timer); pending.clear(); for (const stop of unregister.reverse()) stop(); await Promise.allSettled([...tasks]); await delivery.queue }
}
