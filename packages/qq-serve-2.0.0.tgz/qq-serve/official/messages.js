// Platform-independent replies. Business plugins use these builders through ctx.qqOfficial.ui.
const text = (value, limit, label) => {
  if (typeof value !== 'string' || !value.trim() || value.length > limit) throw new Error(`${label}格式无效或超出长度限制`)
  return value
}
export const escapeMarkdown = value => String(value).replace(/[\\`*_{}\[\]()#+.!<>|~-]/g, '\\$&')
export const button = {
  command: (label, command, options = {}) => ({ ...options, type: 'command', label, command }),
  callback: (label, action, args = [], options = {}) => ({ ...options, type: 'callback', label, action, args }),
  link: (label, url, options = {}) => ({ ...options, type: 'link', label, url }),
}
export function card({ title, lines = [], buttons = [], templateParams }) {
  return { text: [title, ...lines].join('\n'), markdown: [`# ${escapeMarkdown(title)}`, ...lines].join('\n\n'), buttons, templateParams }
}
export const ui = Object.freeze({ card, button: Object.freeze(button), escapeMarkdown })

export function normalizeReply(reply) {
  if (reply == null || reply === '') return null
  if (typeof reply === 'string') return { text: reply.slice(0, 1800), buttons: [] }
  if (!reply || typeof reply !== 'object' || Array.isArray(reply)) throw new Error('回复必须是文本或结构化消息')
  const result = { text: text(reply.text, 1800, '纯文本备用回复'), buttons: [] }
  if (reply.images !== undefined) {
    if (!Array.isArray(reply.images) || !reply.images.length || reply.images.length > 100 || reply.images.some(image => !Buffer.isBuffer(image) || image.length < 8 || image.length > 8 * 1024 * 1024 || image.subarray(0, 8).toString('hex') !== '89504e470d0a1a0a')) throw new Error('图片回复必须为有效 PNG，单张不超过 8 MiB')
    result.images = reply.images
  }
  if (reply.markdown !== undefined) result.markdown = text(reply.markdown, 4000, 'Markdown')
  if (reply.templateParams !== undefined) {
    if (!reply.templateParams || typeof reply.templateParams !== 'object' || Array.isArray(reply.templateParams) || Object.keys(reply.templateParams).length > 20) throw new Error('Markdown 模板参数无效')
    result.templateParams = Object.entries(reply.templateParams).map(([key, value]) => ({
      key: text(key, 64, '模板参数名'), values: (Array.isArray(value) ? value : [value]).map(v => text(v, 4000, '模板参数值')),
    }))
    if (result.templateParams.some(param => !param.values.length || param.values.length > 10)) throw new Error('模板参数值数量无效')
  }
  const rows = reply.buttons ?? []
  if (!Array.isArray(rows) || rows.length > 5) throw new Error('按钮最多 5 行')
  result.buttons = rows.map(row => {
    if (!Array.isArray(row) || !row.length || row.length > 5) throw new Error('每行按钮必须为 1 至 5 个')
    return row.map(item => {
      if (!item || !['command', 'callback', 'link'].includes(item.type)) throw new Error('按钮类型无效')
      const normalized = { ...item, label: text(item.label, 50, '按钮文字') }
      if (item.style !== undefined && ![0, 1].includes(item.style)) throw new Error('按钮样式无效')
      if (item.type === 'command') normalized.command = text(item.command, 500, '按钮命令')
      if (item.type === 'link') {
        const url = new URL(text(item.url, 1000, '按钮链接'))
        if (url.protocol !== 'https:' || url.username || url.password) throw new Error('跳转按钮仅允许无凭证的 HTTPS 链接')
      }
      if (item.type === 'callback') {
        text(item.action, 32, '回调名称')
        if (!Array.isArray(item.args) || item.args.length > 10 || item.args.some(arg => typeof arg !== 'string' || arg.length > 200)) throw new Error('回调参数无效')
      }
      return normalized
    })
  })
  return result
}

// Only retry an explicit rich-message rejection. Network/audit/rate-limit errors
// may already have accepted the message, so retrying those can duplicate replies.
export function richPermissionRejected(error) {
  if (![400, 403].includes(error?.httpStatus)) return false
  // Official documented errors: native MD prohibited, template privilege,
  // no MD template privilege, no message-button-component privilege.
  if ([50056, 304014, 304036, 304037].includes(Number(error.bizCode))) return true
  return /markdown|keyboard|button|template|模[板版]|按钮/i.test(error.bizMessage || error.message || '') &&
    /permission|not.?allow|not.?support|not.?open|no.?permission|未开通|无权限|不支持|没有权限|不允许/i.test(error.bizMessage || error.message || '')
}

export function outbound(reply, config, keyboard) {
  if (config.responseMode === 'text' || !reply.markdown) return { content: reply.text, msgType: 0 }
  const markdown = config.responseMode === 'template'
    ? { custom_template_id: config.markdownTemplateId, params: reply.templateParams || [{ key: config.markdownTemplateKey, values: [reply.markdown] }] }
    : { content: reply.markdown }
  return { msgType: 2, markdown, ...(keyboard ? { keyboard } : {}) }
}
