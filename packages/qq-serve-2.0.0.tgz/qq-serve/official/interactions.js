import { randomBytes } from 'node:crypto'

export function interactionMessage(event) {
  if (!event || event.type !== 11 || typeof event.id !== 'string' || !event.id || event.id.length > 256) return null
  const kind = event.scene || ({ 1: 'group', 2: 'c2c' })[event.chat_type]
  if (!['c2c', 'group'].includes(kind)) return null
  if (event.chat_type !== undefined && event.chat_type !== (kind === 'group' ? 1 : 2)) return null
  const senderId = kind === 'group' ? event.group_member_openid : event.user_openid
  const targetId = kind === 'group' ? event.group_openid : senderId
  if (![senderId, targetId].every(value => typeof value === 'string' && value.length > 0 && value.length <= 200)) return null
  const eventId = typeof event.gatewayEventId === 'string' && event.gatewayEventId.length > 0 && event.gatewayEventId.length <= 512 ? event.gatewayEventId : undefined
  return { kind, senderId, groupOpenid: kind === 'group' ? targetId : undefined,
    interactionId: event.id, replyTarget: { scope: kind, targetId, eventId }, content: '' }
}

// Random, short-lived capabilities contain no business parameters or identity.
// Scope + owner + handler identity are checked again on the server, independently
// of the client's button permission display. Disable/reconnect discards all tokens.
export class InteractionStore {
  constructor(now, resolve) { this.now = now; this.resolve = resolve; this.tokens = new Map() }
  prune() {
    for (const [id, item] of this.tokens) if (item.expiresAt <= this.now()) this.tokens.delete(id)
  }
  keyboard(rows, message) {
    this.prune()
    // Validate the whole keyboard before issuing any capabilities.
    for (const row of rows) for (const item of row) {
      if (item.type === 'callback' && !this.resolve(item.action)) throw new Error(`按钮处理逻辑不存在：${item.action}`)
    }
    const issued = []
    const expiresAt = this.now() + 300000
    // QQ can display a card before the POST response reaches this process.
    // Its capabilities must already work then. A failed POST revokes them.
    const card = { state: 'active', expiresAt }
    const content = { rows: rows.map((row, r) => ({ buttons: row.map((item, c) => {
      const id = `b${r}_${c}`
      const action = { permission: { type: 0, specify_user_ids: [message.senderId] }, unsupport_tips: '请发送 menu 或 help 使用文字菜单' }
      if (item.type === 'callback') {
        const record = this.resolve(item.action)
        if (!record) throw new Error(`按钮处理逻辑不存在：${item.action}`)
        const token = `tsw:${randomBytes(18).toString('base64url')}`
        this.tokens.set(token, { record, args: [...item.args], senderId: message.senderId,
          scope: message.replyTarget.scope, targetId: message.replyTarget.targetId, buttonId: id,
          expiresAt, once: item.once === true, used: false, card })
        issued.push(token)
        Object.assign(action, { type: 1, data: token })
      } else if (item.type === 'command') Object.assign(action, { type: 2, data: item.command, enter: item.enter !== false, reply: true })
      else Object.assign(action, { type: 0, data: item.url })
      return { id, render_data: { label: item.label, visited_label: item.visitedLabel || item.label, style: item.style ?? 1 }, action }
    }) })) }
    while (this.tokens.size > 1000) this.tokens.delete(this.tokens.keys().next().value)
    // Navigation is reusable until expiry: sending Help must not disable the
    // original menu's Markdown button. Only explicitly once actions are consumed.
    return { payload: { content }, issued }
  }
  resolveEvent(event, message) {
    this.prune()
    const data = event.data?.resolved?.button_data
    if (typeof data !== 'string') return { code: 4, reason: 'missing-button-data' }
    // Template keyboards cannot interpolate dynamic tokens. Only explicitly
    // public, parameter-free actions are exposed under these fixed names.
    if (/^tsweb:[a-z0-9_-]{1,32}$/.test(data)) {
      const record = this.resolve(data.slice(6))
      return record?.templateAction === true ? { code: 0, record, args: [] } : { code: 4, reason: 'unknown-template-action' }
    }
    const item = this.tokens.get(data)
    if (!item) return { code: 4, reason: 'unknown-or-expired-token' }
    if (item.record !== this.resolve(item.record.name)) return { code: 4, reason: 'handler-unregistered' }
    if (item.senderId !== message.senderId) return { code: 4, reason: 'wrong-owner' }
    if (item.scope !== message.kind || item.targetId !== message.replyTarget.targetId) return { code: 4, reason: 'wrong-conversation' }
    if (event.data?.resolved?.button_id && event.data.resolved.button_id !== item.buttonId) return { code: 4, reason: 'button-id-mismatch', expectedButton: item.buttonId }
    if (item.once && item.used) return { code: 3, reason: 'once-consumed' }
    if (item.card.state !== 'active') return { code: 0, suppressed: true, reason: 'card-busy' }
    return { code: 0, record: item.record, args: [...item.args], consume: () => {
      item.card.state = 'busy'
    }, accepted: () => { item.used = true }, release: () => { if (item.card.state === 'busy') item.card.state = 'active' } }
  }
  revoke(tokens) { for (const token of tokens) this.tokens.delete(token) }
  clear() { this.tokens.clear() }
}
