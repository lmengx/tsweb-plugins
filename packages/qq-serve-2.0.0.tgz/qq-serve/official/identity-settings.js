/**
 * QQ 控制台的统一配置（官方端指令开关 + 协同开关）
 *
 * 归属原则（避免同一功能出现在两处）：
 *   commands  官方机器人自身的指令开关 —— 只影响官方端
 *   collab    协同开关 —— 只影响"用 OneBot 观测补身份"这条链路，
 *             全部集中在这里，官方页只做只读摘要 + 跳转。
 *
 * 落盘：<data>/qq-official/identity.json（原子写：临时文件 + rename）
 */
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'

export const IDENTITY_SETTINGS_SCHEMA = 1

/** 官方端指令目录：id → 展示信息（顺序即界面顺序） */
export const OFFICIAL_COMMANDS = [
  { id: 'menu', name: '菜单', group: '基础', scene: 'both', defaultEnabled: true, locked: false },
  { id: 'help', name: '帮助', group: '基础', scene: 'both', defaultEnabled: true, locked: false },
  { id: 'ping', name: '测试', group: '基础', scene: 'both', defaultEnabled: true, locked: false },
  { id: 'status', name: '状态', group: '基础', scene: 'both', defaultEnabled: true, locked: false },
  { id: 'servers', name: '服务器列表', group: '信息', scene: 'both', defaultEnabled: true, locked: false },
  { id: 'server', name: '服务器状态', group: '信息', scene: 'both', defaultEnabled: true, locked: false },
  { id: 'online', name: '在线玩家', group: '信息', scene: 'both', defaultEnabled: true, locked: false },
  { id: 'me', name: '我的信息', group: '账号', scene: 'both', defaultEnabled: true, locked: false },
  { id: 'account', name: '账号服务', group: '账号', scene: 'both', defaultEnabled: true, locked: false },
  { id: 'accounthelp', name: '账号帮助', group: '账号', scene: 'both', defaultEnabled: true, locked: false },
  { id: 'register', name: '注册', group: '账号', scene: 'both', defaultEnabled: true, locked: false },
  { id: 'bind', name: '绑定', group: '账号', scene: 'both', defaultEnabled: true, locked: false },
  { id: 'cancelbind', name: '取消绑定', group: '账号', scene: 'both', defaultEnabled: true, locked: false },
  // 敏感：场景锁定仅私聊，不可修改
  { id: 'claimpassword', name: '领取密码', group: '敏感', scene: 'private', defaultEnabled: true, locked: true },
  { id: 'password', name: '改密码', group: '敏感', scene: 'private', defaultEnabled: true, locked: true },
  { id: 'group-info', name: '群信息', group: '群标识', scene: 'group', defaultEnabled: true, locked: false },
  { id: 'qq-id', name: '获取 QQ 号', group: '身份', scene: 'both', defaultEnabled: true, locked: false },
]

/** 协同默认值：自动转移默认禁用（需显式开启） */
export const COLLAB_DEFAULTS = Object.freeze({
  observation: true,
  assistQq: true,
  autoTransfer: false,
  autoTransferTrigger: ['menu'],
  writeBackLedger: true,
  windowMs: 5000,
  awaitMs: 2000,
  groupConfirmations: 5,
})

export function defaultIdentitySettings() {
  return {
    schema: IDENTITY_SETTINGS_SCHEMA,
    commands: Object.fromEntries(
      OFFICIAL_COMMANDS.map((c) => [c.id, { enabled: c.defaultEnabled, scene: c.scene }]),
    ),
    collab: { ...COLLAB_DEFAULTS, autoTransferTrigger: [...COLLAB_DEFAULTS.autoTransferTrigger] },
  }
}

const SCENES = new Set(['group', 'private', 'both'])
const TRIGGERS = new Set(['menu', 'any', 'private'])

/**
 * 归一化：只接受已知键，非法值回落到 **base**（当前值），而不是硬回默认值。
 *
 * 关键点（曾经踩过）：面板保存时可能只提交 `{collab}` 或只提交 `{commands}`。
 * 如果缺失的那一段回落到"出厂默认"，那么保存一个开关就会把另一段的自定义全部清掉。
 * 因此这里对缺失项一律继承 base。
 */
export function normalizeIdentitySettings(input, base = defaultIdentitySettings()) {
  const src = input && typeof input === 'object' ? input : {}
  const safeBase = base && typeof base === 'object' ? base : defaultIdentitySettings()
  const out = defaultIdentitySettings()

  // 指令：先继承 base，再用提交里出现的项覆盖
  for (const spec of OFFICIAL_COMMANDS) {
    const cur = safeBase.commands?.[spec.id] || { enabled: spec.defaultEnabled, scene: spec.scene }
    out.commands[spec.id] = {
      enabled: cur.enabled === true,
      scene: spec.locked ? spec.scene : (SCENES.has(cur.scene) ? cur.scene : spec.scene),
    }
  }
  const commands = src.commands && typeof src.commands === 'object' ? src.commands : {}
  for (const spec of OFFICIAL_COMMANDS) {
    const cur = commands[spec.id]
    if (!cur || typeof cur !== 'object') continue
    out.commands[spec.id] = {
      enabled: cur.enabled === undefined ? out.commands[spec.id].enabled : cur.enabled === true,
      scene: spec.locked ? spec.scene : (SCENES.has(cur.scene) ? cur.scene : out.commands[spec.id].scene),
    }
  }

  // 协同：同样先继承 base
  out.collab = { ...safeBase.collab, autoTransferTrigger: [...(safeBase.collab?.autoTransferTrigger || ['menu'])] }
  const collab = src.collab && typeof src.collab === 'object' ? src.collab : {}
  for (const key of ['observation', 'assistQq', 'autoTransfer', 'writeBackLedger']) {
    if (collab[key] !== undefined) out.collab[key] = collab[key] === true
  }
  if (Array.isArray(collab.autoTransferTrigger)) {
    const list = collab.autoTransferTrigger.filter((v) => TRIGGERS.has(v))
    out.collab.autoTransferTrigger = list.length > 0 ? [...new Set(list)] : ['menu']
  }
  for (const [key, min, max] of [['windowMs', 500, 20000], ['awaitMs', 200, 10000], ['groupConfirmations', 3, 10]]) {
    const value = Number(collab[key])
    if (Number.isFinite(value) && value >= min && value <= max) out.collab[key] = Math.round(value)
  }
  return out
}

export class IdentitySettingsStore {
  constructor({ dataDir, now = () => Date.now() }) {
    this.file = join(dataDir, 'official-identity.json')
    this.now = now
    this.value = defaultIdentitySettings()
    this._queue = Promise.resolve()
  }

  async load() {
    try {
      const text = await readFile(this.file, 'utf8')
      this.value = normalizeIdentitySettings(JSON.parse(text))
    } catch (error) {
      if (error.code !== 'ENOENT') {
        // 文件坏了：用默认值继续跑，不覆盖原文件（下次保存会重写）
        this.value = defaultIdentitySettings()
      }
    }
    return this.value
  }

  snapshot() {
    return {
      ...this.value,
      commands: JSON.parse(JSON.stringify(this.value.commands)),
      collab: { ...this.value.collab, autoTransferTrigger: [...this.value.collab.autoTransferTrigger] },
      catalog: OFFICIAL_COMMANDS.map((c) => ({ ...c })),
    }
  }

  /** 某条命令是否放行（含场景判定） */
  allows(id, scene) {
    const conf = this.value.commands[id]
    if (!conf || conf.enabled !== true) return false
    if (conf.scene === 'both') return true
    return conf.scene === scene
  }

  async save(patch) {
    this.value = normalizeIdentitySettings(patch, this.value)
    const text = JSON.stringify(this.value, null, 2) + '\n'
    const run = this._queue.then(async () => {
      await mkdir(dirname(this.file), { recursive: true })
      const tmp = `${this.file}.${process.pid}.${this.now()}.tmp`
      await writeFile(tmp, text, 'utf8')
      await rename(tmp, this.file)
    })
    this._queue = run.then(() => undefined, () => undefined)
    await run
    return this.snapshot()
  }
}
