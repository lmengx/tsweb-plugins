# OneBot 身份补全

这是独立的 Cordis 插件，不依赖 Koishi。混合模式由 QQ 官方机器人负责交互，OneBot 11 在“绑定转移”流程中提供真实 QQ 号和昵称；OneBot 单独模式同时提供普通消息业务指令。

启用后配置：

- `endpoint`：OneBot HTTP API 地址，例如 `http://127.0.0.1:5700`
- `accessToken`：OneBot API token
- `webhookToken`：OneBot 推送到 `/api/onebot-bridge/webhook` 时的 `X-OneBot-Token`
- `groupMap`：官方 `group_openid` 到 OneBot 数字 `group_id` 的显式映射

官方群内打开“绑定转移”二级菜单，点击“一键转移”后自动发送 `/绑定转移 编码`。编码为压缩时间片加随机数的 20 字符标点串，每次打开菜单更新，5 分钟有效。官方与 OneBot 均收到同一编码、且匹配菜单发起人和群后，自动完成关联；无手工复制和二次确认。两端乱序与重复投递只完成一次。插件不比较两端时间或内容哈希；普通菜单、服务器查询和在线查询不会触发身份补全。

OneBot 不启用时，官方身份记录仍可正常注册和使用，QQ 字段保持为空。迁移成功后，旧 QQ 绑定记录会补写官方 OpenID；已有官方记录则补写 QQ 和昵称。
