export default {
  owner: 'onebot-bridge',
  version: 2,
  modules: [{ id: 'onebot-bridge.settings', permission: 'onebot-bridge.ui.settings', title: 'OneBot 身份补全', roles: ['superadmin'], scope: 'global', requires: [
    'onebot-bridge.get.config', 'onebot-bridge.post.config', 'onebot-bridge.post.test',
  ] }],
  actions: [
    { id: 'onebot-bridge.get.config', method: 'GET', path: '/api/onebot-bridge/config', scope: 'global', module: 'onebot-bridge.settings' },
    { id: 'onebot-bridge.post.config', method: 'POST', path: '/api/onebot-bridge/config', scope: 'global', module: 'onebot-bridge.settings' },
    { id: 'onebot-bridge.post.test', method: 'POST', path: '/api/onebot-bridge/test', scope: 'global', module: 'onebot-bridge.settings' },
  ],
}
