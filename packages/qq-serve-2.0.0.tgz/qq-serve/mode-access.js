export default {
  owner: 'qq-serve',
  version: 2,
  modules: [{ id: 'qq-serve.settings', permission: 'qq-serve.ui.settings', title: 'QQ 服务模式', roles: ['superadmin'], scope: 'global', requires: [
    'qq-serve.get.config', 'qq-serve.post.config', 'qq-serve.get.status', 'qq-serve.post.test',
    'qq-serve.get.rendering', 'qq-serve.post.rendering', 'qq-serve.post.render-preview',
  ] }],
  actions: [
    { id: 'qq-serve.get.rendering', method: 'GET', path: '/api/qq-serve/rendering', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.post.rendering', method: 'POST', path: '/api/qq-serve/rendering', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.post.render-preview', method: 'POST', path: '/api/qq-serve/rendering/preview', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.post.test', method: 'POST', path: '/api/qq-serve/test', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.get.status', method: 'GET', path: '/api/qq-serve/status', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.get.config', method: 'GET', path: '/api/qq-serve/config', scope: 'global', module: 'qq-serve.settings' },
    { id: 'qq-serve.post.config', method: 'POST', path: '/api/qq-serve/config', scope: 'global', module: 'qq-serve.settings' },
  ],
  features: [{ id: 'qq-serve:settings', module: 'qq-serve.settings', requires: [
    'qq-serve.get.config', 'qq-serve.post.config', 'qq-serve.get.status', 'qq-serve.post.test',
  ] }, { id: 'qq-serve:rendering', module: 'qq-serve.settings', requires: ['qq-serve.get.rendering', 'qq-serve.post.rendering', 'qq-serve.post.render-preview'] }],
}
