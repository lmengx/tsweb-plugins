/**
 * 消息身份读取：公共词表、校验器与错误类型
 *
 * 设计前提（见 docs/消息身份准确读取机制-20261028.md）：
 *   身份只能来自**平台自己给的字段**，不能来自"另一个进程转述"。
 *   因此本目录不接受形如 { qq: 123456, command: '...' } 的机器人自报请求体。
 *
 * 术语：
 *   subject     平台稳定主体标识。OneBot 侧是真实 QQ 号；官方侧是 OpenID。
 *   subjectKind 主体类型：'qq' | 'openid'。
 *   sceneKey    场景键。群聊 = group_openid / group_id；单聊 = 用户主体本身。
 *   trust       该条消息的身份可信来源，见 TRUST。
 */

/** 接入平台 */
export const PLATFORM = Object.freeze({
  /** OneBot 11 实现（本进程第一方反向 WS 连接） */
  ONEBOT: 'onebot',
  /** QQ 官方机器人（AppID + AppSecret，v2 事件推送） */
  QQ_OFFICIAL: 'qq-official',
})

/** 会话场景 */
export const SCENE = Object.freeze({
  GROUP: 'group',
  PRIVATE: 'private',
  CHANNEL: 'channel',
})

/**
 * 身份可信来源。
 *
 * 关键区别（旧方案的病根就在第一档被当成了第三档）：
 *   PLATFORM_VERIFIED 消息体由平台按协议给出，且连接是本进程与平台之间的第一方认证连接
 *   CORROBORATED      在第一档基础上，另有服务端动作复核过同一条消息（OneBot get_msg / 群成员）
 *   BOT_ASSERTED      由第三方机器人进程转述（旧 /api/bot/* 路径），**不足以据此判定身份**
 */
export const TRUST = Object.freeze({
  PLATFORM_VERIFIED: 'platform-verified',
  CORROBORATED: 'corroborated',
  BOT_ASSERTED: 'bot-asserted',
})

/** 身份解析结果的可信级别 */
export const CONFIDENCE = Object.freeze({
  /** 主体键在权威台账里精确命中 */
  EXACT: 'exact',
  /** 主体精确但附加信息（群角色等）只能降级采信 */
  DEGRADED: 'degraded',
  /** 主体有效但未登记，不能据此授权任何业务动作 */
  NONE: 'none',
})

/** 拒绝码：调用方与审计日志共用，避免各处自造字符串 */
export const REJECT = Object.freeze({
  /** 事件形状不合法（缺关键字段 / 类型不对） */
  MALFORMED: 'malformed-event',
  /** 发送者是机器人自身或 bot 账号 */
  SELF_OR_BOT: 'self-or-bot',
  /** 重复推送（官方文档明确同 msg_id 会重复推送） */
  DUPLICATE: 'duplicate',
  /** 事件来自未配置的机器人实例 */
  UNKNOWN_BOT: 'unknown-bot',
  /** 服务端复核发现与事件内容不一致（可能是伪造/串号） */
  CORROBORATION_MISMATCH: 'corroboration-mismatch',
  /** 该场景不支持准确读身份 */
  UNSUPPORTED_SCENE: 'unsupported-scene',
  /** 主体未登记 */
  UNBOUND: 'unbound-subject',
  /** 台账里同一角色对应多条 QQ，无法唯一确定 */
  AMBIGUOUS: 'ambiguous-subject',
})

/** 业务若要执行敏感动作，需要的最低可信来源（由能力自行声明） */
export const VERIFIED_TRUST = new Set([TRUST.PLATFORM_VERIFIED, TRUST.CORROBORATED])

/**
 * 身份层的统一错误。
 *
 * 与 httpError 的区别：本层不关心 HTTP 状态码，只关心"哪一步拒绝、为什么"，
 * 由接入层决定映射成 4xx 还是仅记审计。
 */
export class IdentityError extends Error {
  /**
   * @param {string} code    REJECT 之一
   * @param {string} message 面向管理员的中文说明
   * @param {object} [extra] 附加字段（会进审计与响应）
   */
  constructor(code, message, extra = {}) {
    super(message)
    this.name = 'IdentityError'
    this.code = code
    Object.assign(this, extra)
  }
}

export function identityError(code, message, extra = {}) {
  return new IdentityError(code, message, extra)
}

/** 中文环境下的字符串判空（不接受纯空白） */
export function isFilled(value) {
  return typeof value === 'string' && value.trim() !== ''
}

/**
 * OpenID 校验。
 *
 * 官方文档只声明"OpenID 格式"，没有给出固定长度与字符集；实测值形如 32 位大写十六进制，
 * 但换实现/换平台后可能带 - _ = 等 base64url 字符。故只做保守的字符集与长度约束：
 * 过松会让伪造串混进台账主键，过紧会在平台调整格式时误杀真实用户。
 */
const OPENID_PATTERN = /^[A-Za-z0-9_-]{8,200}$/

export function isOpenid(value) {
  return typeof value === 'string' && OPENID_PATTERN.test(value)
}

/** 群/单聊场景键（group_openid 同 OpenID 规则） */
export const isSceneKey = isOpenid

/** OneBot 的 QQ 号：正整数，5~15 位（与台账 QQ_PATTERN 一致） */
const QQ_PATTERN = /^[1-9]\d{4,14}$/

export function isQq(value) {
  return (typeof value === 'string' || typeof value === 'number') && QQ_PATTERN.test(String(value))
}

/** 消息 ID：官方是 ROBOT1.0_... 形式；OneBot 是整数或整数串。只要求非空且无空白 */
export function isMessageId(value) {
  const text = String(value ?? '').trim()
  return text !== '' && text.length <= 256 && !/\s/.test(text)
}

/** RFC3339（官方的 timestamp）：必须能被 Date.parse 成有限时间 */
export function parseTimestamp(value) {
  if (typeof value !== 'string' || value.trim() === '') return NaN
  const ms = Date.parse(value)
  return Number.isFinite(ms) ? ms : NaN
}

/** 群内角色词表（官方 member_role 与 OneBot sender.role 取值不同，这里统一） */
export const ROLE = Object.freeze({
  OWNER: 'owner',
  ADMIN: 'admin',
  MEMBER: 'member',
})

const ROLE_ALIASES = new Map([
  ['owner', ROLE.OWNER],
  ['admin', ROLE.ADMIN],
  ['administrator', ROLE.ADMIN],
  ['member', ROLE.MEMBER],
])

export function normalizeRole(value) {
  const key = String(value ?? '').trim().toLowerCase()
  return ROLE_ALIASES.get(key) || ''
}
