/**
 * 消息身份准确读取机制（identity）
 *
 * 对外入口。装配方式见 `createIdentityService`：给一个数据目录与既有 Ledger，
 * 返回可直接被插件/适配器使用的 ingress。
 *
 * 一句话概括本目录相对旧方案的变化：
 *   old: 机器人进程在 HTTP body 里写 { qq, command }  → 服务端采信 → 需要编码互证
 *   new: 本进程与平台的第一方连接里读取平台字段      → 精确键查表 → 不需要编码
 */
import { join } from 'node:path'
import { AttributionLog } from './attribution.js'
import { createMessageIngress } from './ingest.js'
import { SubjectStore } from './store.js'

// 词表与解析结果枚举
export {
  CONFIDENCE,
  identityError,
  IdentityError,
  isOpenid,
  isQq,
  PLATFORM,
  REJECT,
  ROLE,
  SCENE,
  TRUST,
  VERIFIED_TRUST,
} from './schema.js'
// 读取器
export {
  isOfficialEventFrame,
  isOfficialSdkMessage,
  OFFICIAL_C2C_EVENTS,
  OFFICIAL_GROUP_EVENTS,
  OFFICIAL_MESSAGE_TYPE,
  OFFICIAL_SDK_EVENT_TYPES,
  parseSceneExt,
  readOfficialEvent,
  readOfficialSdkMessage,
  readOneBotEvent,
} from './read.js'
// 解析与 principal 转换
export { resolveIdentity, toPrincipal } from './resolve.js'
// 复核
export { corroborateOfficial, corroborateOneBot } from './corroborate.js'
// 跨通道消息对应（官方消息 ↔ 框架机器人同一条消息，用于拿到 QQ 号）
export { CorrespondenceEngine, MATCH, oneBotObservation } from './correspond.js'
// 编排、连接、存储、审计
export { createMessageIngress, normalizeIngressConfig } from './ingest.js'
export { createOneBotLink } from './onebot-link.js'
export { SUBJECT_SCHEMA, SubjectStore, subjectKey } from './store.js'
export { AttributionLog } from './attribution.js'
export { EventCapture } from './capture.js'
export { GroupMappingStore, InMemoryGroupMapping, GROUP_MAP_SCHEMA, REQUIRED_CONFIRMATIONS } from './group-map.js'
export { createIdentityGate, IDENTIFY_STATE } from './gate.js'

/**
 * 装配一个可用的身份服务。
 *
 * @param {object} options
 * @param {string} options.dataDir   插件数据目录（主体登记与归因日志都落这里）
 * @param {object} options.ledger    qq-bind 的 Ledger 实例
 * @param {object} [options.config]  见 normalizeIngressConfig
 * @param {Function} [options.callAction] OneBot 动作通道（连接建立后补齐即可）
 * @param {Function} [options.now]
 */
export async function createIdentityService(options = {}) {
  if (!options.dataDir) throw new Error('createIdentityService 需要 dataDir')
  const now = typeof options.now === 'function' ? options.now : () => Date.now()
  const subjects = new SubjectStore({ file: join(options.dataDir, 'identity-subjects.json'), now })
  await subjects.load()
  const attribution = new AttributionLog({
    file: join(options.dataDir, 'identity-attribution.jsonl'),
    now,
  })
  const ingress = createMessageIngress({
    ledger: options.ledger,
    subjects,
    attribution,
    callAction: options.callAction,
    config: options.config,
    now,
  })
  return { subjects, attribution, ingress }
}
