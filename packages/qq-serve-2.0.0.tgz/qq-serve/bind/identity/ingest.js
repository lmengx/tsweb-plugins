/**
 * 消息接入编排：一条消息从"平台事件"到"可授权身份"的完整流程
 *
 * 流程（每一步失败都有明确的拒绝码，不做静默放行）：
 *
 *   1. 分流    官方事件帧 / OneBot 事件 → 对应读取器（不认第三方转述的请求体）
 *   2. 严格解析 关键字段缺失即拒绝（MALFORMED / SELF_OR_BOT / UNKNOWN_BOT）
 *   3. 去重    官方同 msg_id 会重复推送；重复的只允许生效一次
 *   4. 复核    OneBot 按 message_id 反查发送者与正文；不一致一律拒绝
 *   5. 解析    精确键查表（QQ→台账 / OpenID→主体登记），查不到就是查不到
 *   6. 归因    落一条审计记录（含原文摘要），供事后核对
 *
 * 明确**不做**的事：按昵称/群名片/时间窗/内容哈希匹配身份；用一次性编码去"补"身份。
 */
import { corroborateOfficial, corroborateOneBot } from './corroborate.js'
import { isOfficialSdkMessage, readOfficialEvent, readOfficialSdkMessage, readOneBotEvent } from './read.js'
import { resolveIdentity, toPrincipal } from './resolve.js'
import { identityError, PLATFORM, REJECT } from './schema.js'

const DEFAULT_DEDUPE_TTL = 5 * 60_000
const DEFAULT_DEDUPE_MAX = 4096

/**
 * 去重表：按去重键记时间，超时或被挤出即失效。
 * 只存键不存内容，内存占用与消息数成常数关系（有上限）。
 */
class DedupeTable {
  constructor({ ttlMs, max }) {
    this.ttlMs = ttlMs
    this.max = max
    /** @type {Map<string, number>} */
    this._hits = new Map()
  }

  /** 返回 true 表示这是重复消息 */
  hit(keys, now) {
    const live = []
    for (const key of keys) {
      const at = this._hits.get(key)
      if (at !== undefined && now - at <= this.ttlMs) {
        // 记录时间不刷新：重复推送不应延长窗口，否则刷屏可以永久占位
        return true
      }
      if (at !== undefined) this._hits.delete(key)
      live.push(key)
    }
    for (const key of live) this._hits.set(key, now)
    // 超上限时按插入顺序淘汰最旧的
    while (this._hits.size > this.max) {
      const oldest = this._hits.keys().next()
      if (oldest.done) break
      this._hits.delete(oldest.value)
    }
    return false
  }

  get size() {
    return this._hits.size
  }
}

/**
 * 创建消息接入器。
 *
 * @param {object} options
 * @param {object} options.ledger             qq-bind 的 Ledger（角色 ↔ QQ 权威）
 * @param {object} options.subjects           SubjectStore（OpenID 主体登记）
 * @param {object} [options.attribution]      AttributionLog
 * @param {Function} [options.callAction]     OneBot 动作调用（复核用）
 * @param {object} [options.config]           见下方 normalizeIngressConfig
 * @param {Function} [options.now]
 */
export function createMessageIngress(options = {}) {
  const now = typeof options.now === 'function' ? options.now : () => Date.now()
  const config = normalizeIngressConfig(options.config)
  const dedupe = new DedupeTable({ ttlMs: config.dedupeTtlMs, max: config.dedupeMax })
  const stats = { seen: 0, accepted: 0, rejected: 0, duplicated: 0 }

  async function audit(entry) {
    if (!options.attribution) return null
    try {
      return await options.attribution.append({ ...entry, extra: entry.extra })
    } catch {
      // 审计写失败不能改变业务判定，但也不吞掉：调用方可通过 stats.auditFailed 观察
      stats.auditFailed = (stats.auditFailed || 0) + 1
      return null
    }
  }

  /**
   * 统一的拒绝出口：先记审计再返回，保证"被拒绝也留痕"，
   * 且调用方能确定审计已落盘（不用轮询等文件）。
   */
  async function rejectWith(code, message, read = null, extra = {}) {
    stats.rejected += 1
    if (code === REJECT.DUPLICATE) stats.duplicated += 1
    await audit({ read, identity: null, decision: 'rejected', code, reason: message, extra })
    return {
      accepted: false,
      code,
      reason: message,
      read,
      identity: null,
      principal: null,
    }
  }

  /**
   * 读一条消息并判定身份。
   *
   * @param {object} raw        平台原始事件（官方推送信封 / OneBot 事件对象）
   * @param {object} [meta]
   * @param {string} [meta.transport] 'qq-official' | 'onebot'（缺省按平台配置推断）
   * @param {number} [meta.receivedAt]
   * @returns {Promise<object>} { accepted, code, reason, read, identity, principal, corroboration }
   */
  async function ingest(raw, meta = {}) {
    stats.seen += 1
    const receivedAt = Number(meta.receivedAt) || now()
    const transport = meta.transport || (String(raw?.post_type ?? '') === 'message' ? PLATFORM.ONEBOT : PLATFORM.QQ_OFFICIAL)

    // ── 1. 分流 + 2. 严格解析 ───────────────────────────────────────────
    let read
    try {
      if (transport === PLATFORM.ONEBOT) {
        if (!config.onebot.enabled) return rejectWith(REJECT.UNSUPPORTED_SCENE, 'OneBot 接入未启用')
        read = readOneBotEvent(raw, {
          botId: config.onebot.botId,
          receivedAt,
          allowPrivate: config.onebot.allowPrivate,
        })
      } else {
        if (!config.official.enabled) return rejectWith(REJECT.UNSUPPORTED_SCENE, '官方机器人接入未启用')
        // 两条入口都合法，但语义不同：
        //   平台原始信封（有 t/d）——字段最全，含角色与 msg_idx
        //   SDK 归一化消息（有 kind/senderId）——运行中的插件手上就是它，字段有缺失
        const useSdk = config.official.acceptSdkMessages && isOfficialSdkMessage(raw)
        read = useSdk
          ? readOfficialSdkMessage(raw, {
              botId: config.official.botId,
              receivedAt,
              allowDm: config.official.allowDm,
            })
          : readOfficialEvent(raw, {
              botId: config.official.botId,
              receivedAt,
              allowDm: config.official.allowDm,
            })
      }
    } catch (err) {
      if (err && err.name === 'IdentityError') {
        return rejectWith(err.code || REJECT.MALFORMED, err.message)
      }
      throw err
    }

    // ── 3. 去重 ────────────────────────────────────────────────────────
    if (dedupe.hit(read.dedupeKeys, receivedAt)) {
      // 重复推送：按"已处理过"处理，不重复执行命令，也不当作新的身份判定
      return rejectWith(REJECT.DUPLICATE, '重复推送的消息（同一 msg_id/msg_idx 已处理）', read)
    }

    // ── 4. 服务端复核 ─────────────────────────────────────────────────
    let corroboration = null
    if (read.platform === PLATFORM.ONEBOT && config.corroboration.enabled) {
      if (typeof options.callAction !== 'function') {
        if (config.corroboration.required) {
          return rejectWith(REJECT.CORROBORATION_MISMATCH, '配置要求复核但未提供 OneBot 动作通道', read)
        }
      } else {
        try {
          corroboration = await corroborateOneBot(read, {
            callAction: options.callAction,
            timeoutMs: config.corroboration.timeoutMs,
            required: config.corroboration.required,
            checkMember: config.corroboration.checkMember,
          })
        } catch (err) {
          if (err && err.name === 'IdentityError') {
            return rejectWith(err.code, err.message, read)
          }
          throw err
        }
        // 复核到不一致是"事件体不可信"的正面证据：即使非强制模式也拒绝
        if (corroboration.mismatches.length > 0) {
          return rejectWith(
            REJECT.CORROBORATION_MISMATCH,
            `服务端复核不一致：${corroboration.mismatches[0]}`,
            read,
            { checks: corroboration.checks, mismatches: corroboration.mismatches },
          )
        }
        if (corroboration.corroborated) {
          read = { ...read, trust: corroboration.trust }
        }
      }
    } else if (read.platform === PLATFORM.QQ_OFFICIAL && config.corroboration.enabled) {
      corroboration = await corroborateOfficial(read)
    }

    // ── 5. 身份解析（精确键）───────────────────────────────────────────
    const identity = resolveIdentity(read, {
      ledger: options.ledger,
      subjects: options.subjects,
    })

    // ── 6. 归因 ────────────────────────────────────────────────────────
    if (!identity.verified) {
      stats.rejected += 1
      await audit({
        read,
        identity,
        decision: 'rejected',
        code: identity.code,
        reason: identity.reason,
        extra: corroboration ? { checks: corroboration.checks } : {},
      })
      return {
        accepted: false,
        code: identity.code,
        reason: identity.reason,
        requireAction: identity.requireAction,
        read,
        identity,
        principal: null,
        corroboration,
      }
    }

    stats.accepted += 1
    const principal = toPrincipal(identity, { adapter: `ingress:${read.platform}` })
    await audit({
      read,
      identity,
      decision: 'accepted',
      code: '',
      reason: '',
      extra: corroboration ? { checks: corroboration.checks } : {},
    })
    return {
      accepted: true,
      code: '',
      reason: '',
      read,
      identity,
      principal,
      corroboration,
    }
  }

  return { ingest, config, stats, dedupe }
}

/**
 * 配置归一化。缺省值按"最小放行"原则选：
 *   - 两个通道默认都不启用（必须显式配 botId 才工作，避免误接入别人的机器人）
 *   - 复核默认开启但不强制（强制会因实现不支持 get_msg 而全部拒绝）
 */
export function normalizeIngressConfig(input = {}) {
  const official = input.official || {}
  const onebot = input.onebot || {}
  const corr = input.corroboration || {}
  return {
    official: {
      enabled: official.enabled === true,
      botId: String(official.botId ?? '').trim(),
      allowDm: official.allowDm !== false,
      // 运行中的 qq-official 插件交给 SDK 的就是归一化消息；默认接受，
      // 需要强制只走原始信封时可关掉（关掉后业务必须把 envelope 原样保留）。
      acceptSdkMessages: official.acceptSdkMessages !== false,
    },
    onebot: {
      enabled: onebot.enabled === true,
      botId: String(onebot.botId ?? '').trim(),
      allowPrivate: onebot.allowPrivate !== false,
    },
    corroboration: {
      enabled: corr.enabled !== false,
      required: corr.required === true,
      checkMember: corr.checkMember !== false,
      timeoutMs: Number(corr.timeoutMs) > 0 ? Number(corr.timeoutMs) : 5000,
    },
    dedupeTtlMs: Number(input.dedupeTtlMs) > 0 ? Number(input.dedupeTtlMs) : DEFAULT_DEDUPE_TTL,
    dedupeMax: Number(input.dedupeMax) > 0 ? Number(input.dedupeMax) : DEFAULT_DEDUPE_MAX,
  }
}
