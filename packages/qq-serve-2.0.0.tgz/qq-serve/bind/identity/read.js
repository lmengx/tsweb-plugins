/**
 * 消息读取：把平台事件解析成统一的 MessageRead
 *
 * 原则（三条，违反即回到"靠编码猜身份"）：
 *   1. 只读平台字段：发送者标识取自平台事件体，不取自任何旁路参数。
 *   2. 严格校验：关键字段缺失/类型不对直接拒绝，**不回退猜测**（不回退到 nickname、
 *      不按时间窗配对、不按内容哈希配对）。
 *   3. 保留证据：原始事件摘要、接收时钟、去重键一并带出，供事后追查"到底读的是哪条消息"。
 *
 * 字段来源：
 *   QQ 官方：bot.q.qq.com v2 事件 GROUP_AT_MESSAGE_CREATE / C2C_MESSAGE_CREATE
 *            （含 group_message_create 全量模式），事件体字段见 docs 内对照表。
 *   OneBot 11：post_type=message 的 group / private 事件。
 */
import { createHash } from 'node:crypto'
import {
  identityError,
  isFilled,
  isMessageId,
  isOpenid,
  isQq,
  isSceneKey,
  normalizeRole,
  parseTimestamp,
  PLATFORM,
  REJECT,
  ROLE,
  SCENE,
  TRUST,
} from './schema.js'

/** 官方群消息事件（@机器人 与 全量模式） */
export const OFFICIAL_GROUP_EVENTS = Object.freeze([
  'GROUP_AT_MESSAGE_CREATE',
  'GROUP_MESSAGE_CREATE',
])

/** 官方单聊消息事件 */
export const OFFICIAL_C2C_EVENTS = Object.freeze(['C2C_MESSAGE_CREATE'])

/** 官方 message_type：读正文时只认这三类，其余一律不产生可执行文本 */
const OFFICIAL_TEXT_TYPES = new Set([0, 103])

/** 官方 message_type 取值说明（审计与排障用） */
export const OFFICIAL_MESSAGE_TYPE = Object.freeze({
  0: 'text',
  3: 'ark',
  101: 'parallel',
  102: 'history',
  103: 'quote',
})

function digest(value) {
  return createHash('sha256').update(JSON.stringify(value ?? null)).digest('hex')
}

/** 深冻结：MessageRead 一旦产出不允许下游改写（改了就失去"证据"意义） */
function frozen(value) {
  if (value && typeof value === 'object') {
    for (const key of Object.keys(value)) frozen(value[key])
    Object.freeze(value)
  }
  return value
}

/**
 * 解析官方的 message_scene.ext（形如 ["msg_idx=REFIDX_xx==", "auth_token=xx"]）。
 *
 * 官方文档明确：同一 msg_id 可能重复推送，需结合 msg_idx（或 msg_seq）去重。
 * 这就是准确读取必须处理的第一件事——否则一条消息会被当成两条命令执行两遍。
 */
export function parseSceneExt(ext) {
  const out = {}
  if (!Array.isArray(ext)) return out
  for (const item of ext) {
    if (typeof item !== 'string') continue
    const idx = item.indexOf('=')
    if (idx <= 0) continue
    const key = item.slice(0, idx).trim()
    const value = item.slice(idx + 1).trim()
    if (key) out[key] = value
  }
  return out
}

/**
 * 读一条 QQ 官方机器人事件。
 *
 * @param {object} envelope 推送信封：{ id, op, t, d }（webhook body 或 WS payload 同形）
 * @param {{ botId: string, receivedAt?: number, allowDm?: boolean }} options
 *        botId = 该机器人的 AppID，作为主体键的组成部分（不同 App 的 OpenID 互不相通）
 * @returns {object} MessageRead
 * @throws {IdentityError} MALFORMED / SELF_OR_BOT / UNKNOWN_BOT / UNSUPPORTED_SCENE
 */
export function readOfficialEvent(envelope, options = {}) {
  const botId = String(options.botId ?? '').trim()
  if (!isFilled(botId)) {
    throw identityError(REJECT.UNKNOWN_BOT, '未指定官方机器人 AppID，无法判定主体归属')
  }

  const env = envelope && typeof envelope === 'object' ? envelope : {}
  const eventType = String(env.t ?? '').trim()
  const d = env.d
  if (!isFilled(eventType)) {
    // op=13 之类的控制帧没有 t；调用方应先用 isEventFrame 判定，这里直接拒绝
    throw identityError(REJECT.MALFORMED, '推送信封缺少事件类型 t（不是事件帧）')
  }
  if (!d || typeof d !== 'object' || Array.isArray(d)) {
    throw identityError(REJECT.MALFORMED, `事件 ${eventType} 缺少事件体 d`)
  }

  const isGroup = OFFICIAL_GROUP_EVENTS.includes(eventType)
  const isC2c = OFFICIAL_C2C_EVENTS.includes(eventType)
  if (!isGroup && !isC2c) {
    throw identityError(REJECT.UNSUPPORTED_SCENE, `事件 ${eventType} 不是消息事件，不参与身份判定`)
  }
  if (isC2c && options.allowDm === false) {
    throw identityError(REJECT.UNSUPPORTED_SCENE, '当前配置不接受单聊消息')
  }

  if (!isMessageId(d.id)) {
    throw identityError(REJECT.MALFORMED, '消息缺少 id，无法去重与被动回复')
  }

  const author = d.author && typeof d.author === 'object' ? d.author : null
  if (!author) throw identityError(REJECT.MALFORMED, '消息缺少 author，无法判定发送者')
  if (author.bot === true) {
    throw identityError(REJECT.SELF_OR_BOT, '发送者是机器人账号，不参与业务身份判定')
  }

  // 场景键与主体键分场景取：群聊用 group_openid + member_openid；单聊用 user_openid
  const sceneKey = isGroup ? String(d.group_openid ?? '').trim() : ''
  if (isGroup && !isSceneKey(sceneKey)) {
    throw identityError(REJECT.MALFORMED, '群消息缺少合法 group_openid')
  }

  // 主体键分场景**严格取对应字段**，不用 author.id 兜底：
  //   member_openid 只在同群稳定、user_openid 只在单聊稳定，author.id 的归属范围官方未承诺。
  //   用兜底键会把不同范围的主体混成一个，正是"看起来能认人、实际认错人"的典型来源。
  const subject = isGroup
    ? String(author.member_openid ?? '').trim()
    : String(author.user_openid ?? '').trim()
  if (!isOpenid(subject)) {
    throw identityError(
      REJECT.MALFORMED,
      isGroup
        ? '群消息缺少合法 member_openid（不接受 author.id 兜底）'
        : '单聊消息缺少合法 user_openid（不接受 author.id 兜底）',
    )
  }

  const sentAt = parseTimestamp(d.timestamp)
  if (!Number.isFinite(sentAt)) {
    throw identityError(REJECT.MALFORMED, '消息缺少合法 timestamp')
  }

  const messageType = Number.isInteger(d.message_type) ? d.message_type : 0
  const sceneExt = parseSceneExt(d.message_scene && d.message_scene.ext)
  const text = typeof d.content === 'string' ? d.content.trim() : ''

  // 官方群消息 member_openid 只在「同群」稳定；跨群必须换键，否则会把两个群的人认成同一个
  const subjectScope = isGroup ? `group:${sceneKey}` : 'c2c'

  const dedupeKeys = [`official:${botId}:${d.id}`]
  if (isFilled(sceneExt.msg_idx)) dedupeKeys.push(`official:${botId}:idx:${sceneExt.msg_idx}`)

  return frozen({
    platform: PLATFORM.QQ_OFFICIAL,
    botId,
    eventType,
    scene: isGroup ? SCENE.GROUP : SCENE.PRIVATE,
    sceneKey: isGroup ? sceneKey : subject,
    subject,
    subjectKind: 'openid',
    subjectScope,
    trust: TRUST.PLATFORM_VERIFIED,
    messageId: String(d.id),
    dedupeKeys,
    receivedAt: Number(options.receivedAt) || Date.now(),
    sentAt,
    author: {
      subject,
      subjectKind: 'openid',
      username: typeof author.username === 'string' ? author.username : '',
      role: normalizeRole(author.member_role),
      isBot: author.bot === true,
      unionOpenid: isOpenid(String(author.union_openid ?? '').trim())
        ? String(author.union_openid).trim()
        : '',
    },
    content: {
      text,
      // 只有纯文本与引用消息才产生"可执行文本"；卡片/聊天记录一律不可当命令执行
      commandable: OFFICIAL_TEXT_TYPES.has(messageType) && text !== '',
      kind: OFFICIAL_MESSAGE_TYPE[messageType] || `type-${messageType}`,
      messageType,
      mentions: Array.isArray(d.mentions)
        ? d.mentions.map((m) => ({
            subject: String(m?.id ?? ''),
            username: typeof m?.username === 'string' ? m.username : '',
            isBot: m?.bot === true,
          }))
        : [],
      attachmentCount: Array.isArray(d.attachments) ? d.attachments.length : 0,
      arkType: d.ark_data ? String(d.ark_data.ark_type ?? '') : '',
      refMsgIdx: isFilled(sceneExt.ref_msg_idx) ? sceneExt.ref_msg_idx : '',
    },
    raw: {
      digest: digest({ id: env.id ?? null, t: eventType, d }),
      sceneExt,
    },
  })
}

/**
 * 读一条 OneBot 11 消息事件。
 *
 * 与旧方案的根本差别：`user_id` 来自**本进程与 OneBot 实现之间的第一方认证连接**，
 * 而不是另一个机器人进程在 HTTP 请求体里自报的 `qq` 参数。
 * 仍然保留服务端复核（corroborate.js）作为第二道门。
 *
 * @param {object} event 一条 OneBot 事件对象
 * @param {{ botId: string|number, receivedAt?: number, allowPrivate?: boolean }} options
 *        botId = 该连接 self_id（机器人自身 QQ），用于过滤自身消息与串号
 * @returns {object} MessageRead
 */
export function readOneBotEvent(event, options = {}) {
  const botId = String(options.botId ?? '').trim()
  if (!isFilled(botId)) {
    throw identityError(REJECT.UNKNOWN_BOT, '未指定 OneBot 连接对应的机器人 QQ（self_id）')
  }

  const ev = event && typeof event === 'object' ? event : {}
  if (String(ev.post_type ?? '') !== 'message') {
    throw identityError(REJECT.UNSUPPORTED_SCENE, `post_type=${ev.post_type} 不是消息事件`)
  }

  // 串号防护：一条事件只能由其所属连接处理
  const selfId = String(ev.self_id ?? '').trim()
  if (selfId !== '' && selfId !== botId) {
    throw identityError(REJECT.UNKNOWN_BOT, `事件 self_id=${selfId} 与本连接机器人 ${botId} 不一致`)
  }

  const messageType = String(ev.message_type ?? '').trim()
  if (messageType !== 'group' && messageType !== 'private') {
    throw identityError(REJECT.UNSUPPORTED_SCENE, `不支持的消息类型：${messageType || '(空)'}`)
  }
  if (messageType === 'private' && options.allowPrivate === false) {
    throw identityError(REJECT.UNSUPPORTED_SCENE, '当前配置不接受私聊消息')
  }

  if (!isMessageId(ev.message_id)) {
    throw identityError(REJECT.MALFORMED, '消息缺少 message_id')
  }
  if (!isQq(ev.user_id)) {
    throw identityError(REJECT.MALFORMED, '消息缺少合法 user_id（真实 QQ 号）')
  }

  const sender = ev.sender && typeof ev.sender === 'object' ? ev.sender : {}
  // 默认 sender 对象与 user_id 一致；不一致说明事件体被拼装过，不能采信
  const senderUid = sender.user_id != null ? String(sender.user_id).trim() : ''
  if (senderUid !== '' && senderUid !== String(ev.user_id).trim()) {
    throw identityError(
      REJECT.MALFORMED,
      `sender.user_id=${senderUid} 与 user_id=${ev.user_id} 不一致，事件体不可信`,
    )
  }

  const subject = String(ev.user_id).trim()
  const isGroup = messageType === 'group'
  const groupId = isGroup ? String(ev.group_id ?? '').trim() : ''
  if (isGroup && !/^\d{1,20}$/.test(groupId)) {
    throw identityError(REJECT.MALFORMED, '群聊消息缺少合法 group_id')
  }

  // 自身消息：部分实现在群聊里也会推送机器人自己的消息
  if (subject === botId) {
    throw identityError(REJECT.SELF_OR_BOT, '消息发送者是机器人自身')
  }

  const sentAtMs = Number(ev.time) > 0 ? Number(ev.time) * 1000 : NaN

  const segments = Array.isArray(ev.message) ? ev.message : []
  const textParts = []
  let mentionsSelf = false
  for (const seg of segments) {
    if (!seg || typeof seg !== 'object') continue
    const type = String(seg.type ?? '')
    if (type === 'text' && seg.data && typeof seg.data.text === 'string') {
      textParts.push(seg.data.text)
    } else if (type === 'at') {
      const target = String(seg.data?.qq ?? '')
      if (target === botId) mentionsSelf = true
    }
  }
  const rawMessage = typeof ev.raw_message === 'string' ? ev.raw_message : ''
  const text = (textParts.length > 0 ? textParts.join('') : rawMessage).trim()

  const dedupeKeys = [`onebot:${botId}:${ev.message_id}`]
  const messageSeq = ev.message_seq != null ? String(ev.message_seq).trim() : ''
  if (messageSeq !== '') dedupeKeys.push(`onebot:${botId}:seq:${messageType}:${groupId || subject}:${messageSeq}`)

  return frozen({
    platform: PLATFORM.ONEBOT,
    botId,
    eventType: `message.${messageType}`,
    scene: isGroup ? SCENE.GROUP : SCENE.PRIVATE,
    sceneKey: isGroup ? groupId : subject,
    subject,
    subjectKind: 'qq',
    subjectScope: isGroup ? `group:${groupId}` : 'private',
    trust: TRUST.PLATFORM_VERIFIED,
    messageId: String(ev.message_id),
    dedupeKeys,
    receivedAt: Number(options.receivedAt) || Date.now(),
    sentAt: Number.isFinite(sentAtMs) ? sentAtMs : NaN,
    author: {
      subject,
      subjectKind: 'qq',
      username: typeof sender.nickname === 'string' ? sender.nickname : '',
      card: typeof sender.card === 'string' ? sender.card : '',
      role: isGroup ? normalizeRole(sender.role) : ROLE.MEMBER,
      isBot: false,
      unionOpenid: '',
    },
    content: {
      text,
      raw: rawMessage,
      commandable: text !== '',
      kind: 'text',
      messageType: null,
      mentionsSelf,
      attachmentCount: segments.filter((s) => s && String(s.type ?? '') === 'image').length,
      arkType: '',
      refMsgIdx: '',
    },
    raw: {
      digest: digest(ev),
      messageSeq,
      subType: typeof ev.sub_type === 'string' ? ev.sub_type : '',
    },
  })
}

/**
 * 是否为官方事件帧，供链接层分流。
 *
 * 兼容两种投递形态：WebSocket 载荷带 op=0，webhook body 不带 op。
 * 因此判定依据是"有事件类型 t 且有事件体 d"，op 若存在则必须为 0（13 等控制帧不算事件）。
 */
export function isOfficialEventFrame(payload) {
  if (!payload || typeof payload !== 'object') return false
  if (payload.op !== undefined && payload.op !== null && Number(payload.op) !== 0) return false
  return isFilled(String(payload.t ?? '')) && !!payload.d && typeof payload.d === 'object'
}

// ═══════════════════════════════════════════════════════════════════
// 已运行实例的真实消息形状（官方 SDK 归一化后的对象）
// ═══════════════════════════════════════════════════════════════════

/**
 * 官方 SDK 归一化消息里出现的事件类型。
 *
 * 来源（2026-10-28 从本机 3000 端口运行实例取样）：`/api/qq-official/status` 报
 * `messagesReceived=6 / fullGroupMessagesReceived=6`，`/api/qq-official/logs` 里 6 条真实
 * `message` 行均为 `kind=group`。也就是说生产环境实际收到的是**群全量消息**（未 @ 机器人也会推），
 * 不只是文档首页最常提的「群@机器人消息」。
 */
export const OFFICIAL_SDK_EVENT_TYPES = Object.freeze([
  'GROUP_AT_MESSAGE_CREATE',
  'GROUP_MESSAGE_CREATE',
  'C2C_MESSAGE_CREATE',
])

/** 该对象是不是官方 SDK 归一化后的消息（而不是平台原始事件信封） */
export function isOfficialSdkMessage(value) {
  if (!value || typeof value !== 'object') return false
  if (isOfficialEventFrame(value)) return false
  return (
    isFilled(String(value.kind ?? '')) &&
    isFilled(String(value.messageId ?? '')) &&
    isFilled(String(value.senderId ?? ''))
  )
}

/**
 * 读一条官方 SDK 归一化消息。
 *
 * 为什么需要这个入口：运行中的 `plugins/qq-official` 把平台事件交给腾讯官方 SDK，
 * `handleMessage(session, message)` 拿到的是归一化对象（`kind` / `messageId` / `senderId` /
 * `groupOpenid` / `content` / `rawEventType` / `replyTarget`）。这是本代码库里**唯一能拿到完整
 * OpenID** 的地方（日志里只写 `shortId()` 截断值，实测形如 `CDF7AB...B2A8`，不能当主键用）。
 *
 * 归一化会丢掉三样东西，本函数如实登记在 `partial.missing` 里，不假装拿到：
 *   - `member_role`（群内角色）
 *   - `author.username`（昵称）
 *   - `union_openid`、`message_type`、`message_scene.ext`（含 msg_idx）
 * 因此走这条入口时无法做「群主/管理员」级别的授权判定，也无法用 msg_idx 去重；
 * 去重退化为 `messageId` + 事件 ID。
 *
 * @param {object} message SDK 归一化消息
 * @param {{ botId: string, receivedAt?: number, allowDm?: boolean }} options
 */
export function readOfficialSdkMessage(message, options = {}) {
  const botId = String(options.botId ?? '').trim()
  if (!isFilled(botId)) {
    throw identityError(REJECT.UNKNOWN_BOT, '未指定官方机器人 AppID，无法判定主体归属')
  }
  const msg = message && typeof message === 'object' ? message : {}

  const kind = String(msg.kind ?? '').trim()
  if (kind !== 'group' && kind !== 'c2c') {
    throw identityError(REJECT.UNSUPPORTED_SCENE, `不支持的消息类型：${kind || '(空)'}`)
  }
  if (kind === 'c2c' && options.allowDm === false) {
    throw identityError(REJECT.UNSUPPORTED_SCENE, '当前配置不接受单聊消息')
  }
  if (!isMessageId(msg.messageId)) {
    throw identityError(REJECT.MALFORMED, '消息缺少 messageId')
  }

  const rawEventType = String(msg.rawEventType ?? '').trim()
  if (rawEventType !== '' && !OFFICIAL_SDK_EVENT_TYPES.includes(rawEventType)) {
    throw identityError(REJECT.UNSUPPORTED_SCENE, `事件 ${rawEventType} 不确定是消息事件`)
  }

  const isGroup = kind === 'group'
  const sceneKey = isGroup ? String(msg.groupOpenid ?? '').trim() : ''
  if (isGroup && !isSceneKey(sceneKey)) {
    throw identityError(REJECT.MALFORMED, '群消息缺少合法 groupOpenid')
  }

  const subject = String(msg.senderId ?? '').trim()
  if (!isOpenid(subject)) {
    // 实测教训：日志里的 shortId（`CDF7AB...B2A8`）看起来像 ID，但它不是主键，
    // 长度不足就是不合格——宁可拒绝，也不要拿截断值当身份。
    throw identityError(REJECT.MALFORMED, 'senderId 不是合法的完整 OpenID（截断值不能当身份）')
  }

  const text = typeof msg.content === 'string' ? msg.content.trim() : ''
  const dedupeKeys = [`official:${botId}:${msg.messageId}`]
  const eventId = String(msg.replyTarget?.eventId ?? '').trim()
  if (eventId !== '') dedupeKeys.push(`official:${botId}:evt:${eventId}`)

  return frozen({
    platform: PLATFORM.QQ_OFFICIAL,
    botId,
    eventType: rawEventType || `sdk.${kind}`,
    scene: isGroup ? SCENE.GROUP : SCENE.PRIVATE,
    sceneKey: isGroup ? sceneKey : subject,
    subject,
    subjectKind: 'openid',
    subjectScope: isGroup ? `group:${sceneKey}` : 'c2c',
    trust: TRUST.PLATFORM_VERIFIED,
    messageId: String(msg.messageId),
    dedupeKeys,
    receivedAt: Number(options.receivedAt) || Date.now(),
    sentAt: NaN,
    author: {
      subject,
      subjectKind: 'openid',
      username: '',
      role: '',
      isBot: false,
      unionOpenid: '',
    },
    content: {
      text,
      commandable: text !== '',
      kind: 'sdk-normalized',
      messageType: null,
      mentions: [],
      attachmentCount: 0,
      arkType: '',
      refMsgIdx: '',
    },
    raw: {
      digest: digest(msg),
      sceneExt: {},
      eventId,
    },
    partial: {
      missing: ['member_role', 'author.username', 'union_openid', 'message_type', 'message_scene.ext'],
    },
  })
}
