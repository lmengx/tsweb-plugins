/**
 * 跨通道消息对应（第三阶段）：把官方通道的一条消息，对应到框架机器人（OneBot）观测到的
 * **同一条物理消息**，从而拿到发送者的真实 QQ 号。
 *
 * 为什么这样可以做到"准确"，而不是靠猜：
 *   1. 群是已知的：qq-serve 的 groupMap 把 官方 group_openid 映射到数字群号
 *      （实测：4E9F208624B9511538C52B522E10A33D → 1053404485）。
 *   2. 官方机器人接的是**群全量消息**（实测 6/6 fullGroupMessagesReceived），
 *      也就是说群里每条消息两个通道都会各收到一次。
 *   3. 两个通道的事件由**同一个进程**几乎同时收到，因此"接收时刻"这个本地时钟是可比对的，
 *      不需要依赖两个平台的时间戳精度。
 *
 * 判定规则（只有唯一候选才算匹配，绝不择优）：
 *   同群 + 归一化文本完全相同 + 附件张数相同 + 接收时刻差 ≤ 窗口（默认 5 秒）
 *   → 恰好 1 条未被他消息占用的候选 ⇒ 匹配成功，取该候选的 QQ 号
 *   → 0 条 ⇒ 暂时无对应（等另一通道到达，超时后作废）
 *   → ≥2 条 ⇒ 判为歧义，拒绝（例如两个人同一秒发了同一句话）
 * 匹配成功后会写一条"由消息对应佐证"的登记（proof=corroborated-message），此后该
 * OpenID 永久按 QQ 解析，不需要再靠对应。
 */
import { createHash } from 'node:crypto'
import { InMemoryGroupMapping } from './group-map.js'

export const MATCH = Object.freeze({
  MATCHED: 'matched',
  PENDING: 'pending',
  AMBIGUOUS: 'ambiguous',
  NO_GROUP_MAPPING: 'no-group-mapping',
  NO_COMPARABLE_TEXT: 'no-comparable-text',
  INVALID: 'invalid-event',
})

/** 文本归一化：去首尾、压缩空白。全角空格也算空白 */
function normText(value) {
  return String(value ?? '')
    .replace(/\s+/g, ' ')
    .trim()
}

function digest(value) {
  return createHash('sha256').update(String(value)).digest('hex').slice(0, 16)
}

/**
 * 从一条 OneBot 原始事件里取出用于对应的要素。
 * 只要缺群号/QQ/消息号或不是群消息，就返回 null（不参与对应）。
 */
export function oneBotObservation(event, now = Date.now()) {
  const ev = event && typeof event === 'object' ? event : {}
  if (String(ev.post_type ?? '') !== 'message') return null
  if (String(ev.message_type ?? '') !== 'group') return null
  const groupId = String(ev.group_id ?? '').trim()
  const qq = String(ev.user_id ?? '').trim()
  const messageId = String(ev.message_id ?? '').trim()
  if (!/^\d{1,20}$/.test(groupId)) return null
  if (!/^[1-9]\d{4,14}$/.test(qq)) return null
  if (messageId === '') return null

  const segments = Array.isArray(ev.message) ? ev.message : []
  const textParts = []
  let images = 0
  for (const seg of segments) {
    if (!seg || typeof seg !== 'object') continue
    const type = String(seg.type ?? '')
    if (type === 'text' && typeof seg.data?.text === 'string') textParts.push(seg.data.text)
    else if (type === 'image') images += 1
  }
  const text = normText(textParts.length > 0 ? textParts.join('') : ev.raw_message)
  const sender = ev.sender && typeof ev.sender === 'object' ? ev.sender : {}

  return {
    groupId,
    qq,
    messageId,
    text,
    textDigest: digest(text),
    images,
    nickname: typeof sender.nickname === 'string' ? sender.nickname : '',
    card: typeof sender.card === 'string' ? sender.card : '',
    role: typeof sender.role === 'string' ? sender.role : '',
    at: now,
    consumedBy: '',
  }
}

export class CorrespondenceEngine {
  /**
   * @param {{groupMap?:Record<string,string>, windowMs?:number, bufferTtlMs?:number, maxBuffer?:number, now?:()=>number}} options
   *        groupMap 仅作"已知提示"保留，可为空；空的时候靠自动发现确定群对应关系。
   */
  constructor(options = {}) {
    this.groupMap = options.groupMap && typeof options.groupMap === 'object' ? { ...options.groupMap } : {}
    this.windowMs = Number(options.windowMs) > 0 ? Number(options.windowMs) : 5000
    this.bufferTtlMs = Number(options.bufferTtlMs) > 0 ? Number(options.bufferTtlMs) : 120_000
    this.maxBuffer = Number(options.maxBuffer) > 0 ? Number(options.maxBuffer) : 1000
    this.now = typeof options.now === 'function' ? options.now : () => Date.now()
    /** @type {Array<object>} OneBot 观测缓冲 */
    this._buffer = []
    /** 群对应（连续 N 条一致才确认落盘；默认进程内实现） */
    this.mapping = options.mapping || new InMemoryGroupMapping()
    /** @type {Set<(engine:CorrespondenceEngine)=>void>} 新观测到达时唤醒等待者 */
    this._wakers = new Set()
    this.stats = { observed: 0, matched: 0, ambiguous: 0, pending: 0, noMapping: 0, noText: 0, discovered: 0 }
  }

  setGroupMap(map) {
    this.groupMap = map && typeof map === 'object' ? { ...map } : {}
  }

  /** 官方 group_openid → 数字群号（已确认优先，其次临时对应；配置提示只作兜底） */
  numericGroupOf(groupOpenid) {
    const key = String(groupOpenid ?? '')
    const learned = String(this.mapping.groupOf?.(key) || '')
    if (learned !== '') return learned
    return String(this.groupMap[key] || '')
  }

  /** 当前群对应（只读快照，便于展示/排查） */
  discoveredMappings() {
    return [...(this.mapping.rows || new Map()).entries()].map(([sceneKey, v]) => ({
      groupOpenid: sceneKey,
      groupId: v.groupId,
      confirmations: v.confirmations,
      confirmed: Boolean(v.confirmedAt),
      at: v.confirmedAt || 0,
    }))
  }

  /** 记一条 OneBot 观测（原始事件即可）；返回观测对象或 null */
  observeOneBot(event) {
    const observation = oneBotObservation(event, this.now())
    if (!observation) return null
    this._buffer.push(observation)
    this.stats.observed += 1
    this._prune()
    for (const wake of [...this._wakers]) {
      try { wake(this) } catch { /* 唤醒失败不影响观测 */ }
    }
    return observation
  }

  _prune() {
    const now = this.now()
    // 过期：既没用上、又太旧
    this._buffer = this._buffer.filter(
      (o) => o.consumedBy !== '' ? now - o.at <= this.windowMs : now - o.at <= this.bufferTtlMs,
    )
    if (this._buffer.length > this.maxBuffer) this._buffer.splice(0, this._buffer.length - this.maxBuffer)
  }

  /**
   * 尝试把一条官方消息对应到 OneBot 观测。
   *
   * @param {object} read  readOfficialEvent / readOfficialSdkMessage 的产出
   * @returns {object} { status, observation?, candidates?, reason? }
   */
  match(read, options = {}) {
    const excludeQq = options.excludeQq instanceof Set ? options.excludeQq : new Set(options.excludeQq || [])
    // 已绑定 QQ 的观测**排在第二档**：只有当"未绑定候选"没有唯一结果时才用它们。
    // 这样已绑定用户不会把未绑定用户的同一句话搅成歧义，同时自己仍能被识别出来。
    const boundQq = options.boundQq instanceof Set ? options.boundQq : new Set(options.boundQq || [])
    if (!read || typeof read !== 'object') return { status: MATCH.INVALID, reason: '缺少消息' }
    if (read.scene !== 'group') {
      return { status: MATCH.NO_GROUP_MAPPING, reason: '单聊消息没有群映射，无法跨通道对应' }
    }
    const text = normText(read.content?.text)
    if (text === '') {
      this.stats.noText += 1
      return { status: MATCH.NO_COMPARABLE_TEXT, reason: '这条消息没有可比较的文本（纯图片/卡片）' }
    }
    const attachmentCount = Number(read.content?.attachmentCount) || 0
    const knownGroupId = this.numericGroupOf(read.sceneKey)

    // 候选：同文本 + 同附件数 + 时间窗内（先不限群）
    const all = this._buffer.filter(
      (o) =>
        o.consumedBy === '' &&
        !excludeQq.has(String(o.qq)) &&
        o.text === text &&
        o.images === attachmentCount &&
        Math.abs(o.at - read.receivedAt) <= this.windowMs,
    )
    const fresh = all.filter((o) => !boundQq.has(String(o.qq)))
    const bound = all.filter((o) => boundQq.has(String(o.qq)))

    /** 在给定候选集里挑唯一结果；返回 { hit } | { ambiguous } | null */
    const pick = (list) => {
      if (list.length === 0) return null
      if (list.length === 1) return { hit: list[0] }
      return { ambiguous: list }
    }

    // ── 情况 A：已有群对应（已确认或临时）→ 只在该群内判定 ──────────────────
    if (knownGroupId !== '') {
      const inGroup = (list) => list.filter((o) => o.groupId === knownGroupId)
      const choice = pick(inGroup(fresh)) || pick(inGroup(bound))
      if (choice?.hit) {
        const progress = this._learn(read.sceneKey, knownGroupId)
        return this._take(read, choice.hit, knownGroupId, this._sourceOf(read.sceneKey), progress)
      }
      if (choice?.ambiguous) {
        this.stats.ambiguous += 1
        return {
          status: MATCH.AMBIGUOUS,
          candidates: choice.ambiguous.map((o) => ({ qq: o.qq, messageId: o.messageId, deltaMs: o.at - read.receivedAt })),
          reason: '同一群、同一文本、同一时间窗内有多条候选，不能确定是哪一条',
        }
      }
      // 已知群里没有候选：不直接判死，落到情况 B 重新全群搜索一次，
      // 这样"群对应错了"能被纠正（纠正后需重新累计确认次数）。
    }

    // ── 情况 B：没有群对应（或已知群对不上）→ 全群搜索 + 累计确认 ────────────
    const groupOf = (list) => {
      const map = new Map()
      for (const o of list) {
        if (!map.has(o.groupId)) map.set(o.groupId, [])
        map.get(o.groupId).push(o)
      }
      return map
    }
    const search = (list) => {
      const byGroup = groupOf(list)
      if (byGroup.size === 1) {
        const [groupId, inner] = [...byGroup.entries()][0]
        const choice = pick(inner)
        if (choice?.hit) return { groupId, hit: choice.hit }
        if (choice?.ambiguous) return { groupId, ambiguous: choice.ambiguous }
      }
      return null
    }

    const found = search(fresh) || search(bound)
    if (found?.hit) {
      // 唯一群 + 唯一消息 ⇒ 完成本次对应，并给该群累计一次一致观测
      const progress = this._learn(read.sceneKey, found.groupId)
      this.stats.discovered += 1
      return this._take(read, found.hit, found.groupId, knownGroupId === '' ? 'auto-discovered' : 're-discovered', progress)
    }
    if (found?.ambiguous) {
      this.stats.ambiguous += 1
      return {
        status: MATCH.AMBIGUOUS,
        candidates: found.ambiguous.map((o) => ({ qq: o.qq, messageId: o.messageId, deltaMs: o.at - read.receivedAt })),
        reason: '同一群、同一文本、同一时间窗内有多条候选，不能确定是哪一条',
      }
    }

    // 多个群都有同文本 → 群对应无法唯一确定
    const crossGroups = new Set(all.map((o) => o.groupId))
    if (crossGroups.size > 1) {
      this.stats.ambiguous += 1
      return {
        status: MATCH.AMBIGUOUS,
        candidates: all.map((o) => ({
          qq: o.qq, groupId: o.groupId, messageId: o.messageId, deltaMs: o.at - read.receivedAt,
        })),
        reason: '多个群在同一时间出现相同文本，无法确定属于哪个群',
      }
    }
    this.stats.pending += 1
    return { status: MATCH.PENDING, reason: '框架机器人还没收到这条消息（或尚未连通）' }
  }

  /** 累计一次"群一致"观测（连续 N 条一致才落盘） */
  _learn(sceneKey, groupId) {
    try {
      return this.mapping.observe(String(sceneKey), String(groupId), this.now())
    } catch {
      return { groupId: String(groupId), confirmations: 0, confirmed: false, changed: false }
    }
  }

  /** 该数值来源：已确认 / 临时 / 配置兜底 */
  _sourceOf(sceneKey) {
    if (this.mapping.isConfirmed?.(String(sceneKey))) return 'confirmed-mapping'
    return 'provisional-mapping'
  }

  /** 取用候选：标记占用并产出结果 */
  _take(read, observation, groupId, mappingSource, progress) {
    observation.consumedBy = read.messageId
    this.stats.matched += 1
    return {
      status: MATCH.MATCHED,
      observation,
      evidence: {
        groupId,
        mappingSource,
        confirmations: progress?.confirmations ?? 0,
        groupConfirmed: progress?.confirmed === true,
        textDigest: observation.textDigest,
        deltaMs: observation.at - read.receivedAt,
        oneBotMessageId: observation.messageId,
        officialMessageId: read.messageId,
        windowMs: this.windowMs,
      },
    }
  }

  /**
   * 等另一通道把对应的消息送上来（官方先到时常用）。
   *
   * @param {object} read
   * @param {{timeoutMs?:number}} [options]
   */
  async waitForMatch(read, options = {}) {
    const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : 2500
    const first = this.match(read, { excludeQq: options.excludeQq, boundQq: options.boundQq })
    if (first.status !== MATCH.PENDING) return first

    // 超时用真实时钟：注入的 now() 只用于窗口判定，不能用来当循环条件（可能被冻结）
    const wallDeadline = Date.now() + timeoutMs
    while (Date.now() < wallDeadline) {
      const remaining = wallDeadline - Date.now()
      if (remaining <= 0) break
      await new Promise((resolve) => {
        const wake = () => { this._wakers.delete(wake); clearTimeout(timer); resolve() }
        const timer = setTimeout(() => { this._wakers.delete(wake); resolve() }, Math.min(remaining, 250))
        this._wakers.add(wake)
      })
      const again = this.match(read, { excludeQq: options.excludeQq, boundQq: options.boundQq })
      if (again.status !== MATCH.PENDING) return again
    }
    return { status: MATCH.PENDING, reason: '等待框架机器人对应超时' }
  }

  get buffered() {
    return this._buffer.length
  }
}
