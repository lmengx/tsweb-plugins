/**
 * 服务端复核：让"这条消息是谁发的"从"事件里写着"变成"平台确认过"
 *
 * 适用面（必须说清楚，不能夸大）：
 *   - OneBot：有 get_msg / get_group_member_info 两个动作可按 message_id 与 user_id 反查，
 *     所以能对**同一条消息**做二次确认。这是本机制里唯一真正的交叉验证手段。
 *   - QQ 官方：v2 开放接口没有"按消息 ID 取回原文"的读接口，无法二次确认。
 *     官方一侧的准确性来自"第一方连接 + 平台事件自带 author"，不来自复核。
 *     因此不要声称官方消息经过复核——本函数对官方返回 unsupported。
 */
import { identityError, isFilled, REJECT, SCENE, TRUST } from './schema.js'

const DEFAULT_TIMEOUT = 5_000

/** 归一化文本用于比对：去首尾空白、压缩连续空白（不改变语义，避免格式差异误判） */
function normText(value) {
  return String(value ?? '')
    .replace(/\s+/g, ' ')
    .trim()
}

function withTimeout(promise, timeoutMs) {
  if (!(timeoutMs > 0)) return promise
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      const err = new Error('复核动作超时')
      err.timeout = true
      reject(err)
    }, timeoutMs)
    Promise.resolve(promise).then(
      (v) => {
        clearTimeout(timer)
        resolve(v)
      },
      (e) => {
        clearTimeout(timer)
        reject(e)
      },
    )
  })
}

/**
 * 复核一条 OneBot 消息事件。
 *
 * @param {object} read      readOneBotEvent 的产出
 * @param {object} options
 * @param {(action:string, params:object)=>Promise<any>} options.callAction  OneBot 动作调用
 * @param {number} [options.timeoutMs]
 * @param {boolean} [options.required]  复核失败是否直接判死（默认降到 platform-verified）
 * @param {boolean} [options.checkMember] 是否额外核对群成员身份（默认群聊时开启）
 * @returns {Promise<{corroborated:boolean, trust:string, checks:object, mismatches:string[], reason:string}>}
 */
export async function corroborateOneBot(read, options = {}) {
  const callAction = options.callAction
  if (typeof callAction !== 'function') {
    throw new Error('corroborateOneBot 需要 callAction(action, params)')
  }
  const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : DEFAULT_TIMEOUT
  const checks = {}
  const mismatches = []

  // ── 1. 按 message_id 取回原文，核对发送者与内容 ─────────────────────────
  let fetched = null
  try {
    fetched = await withTimeout(callAction('get_msg', { message_id: read.messageId }), timeoutMs)
    checks.getMsg = 'ok'
  } catch (err) {
    // 实现不支持 / 超时 / 消息已过期：都不算"复核通过"，也不当作伪造证据
    checks.getMsg = err?.timeout ? 'timeout' : 'unsupported'
    if (options.required && checks.getMsg === 'timeout') {
      throw identityError(REJECT.CORROBORATION_MISMATCH, '复核超时，按配置拒绝该消息')
    }
  }

  if (fetched && typeof fetched === 'object') {
    const data = fetched.data && typeof fetched.data === 'object' ? fetched.data : fetched
    const gotSender = String(data?.sender?.user_id ?? '').trim()
    if (gotSender !== '' && gotSender !== read.subject) {
      mismatches.push(`发送者不一致：事件=${read.subject}，平台回读=${gotSender}`)
    }
    if (read.scene === SCENE.GROUP) {
      const gotGroup = String(data?.group_id ?? '').trim()
      if (gotGroup !== '' && gotGroup !== read.sceneKey) {
        mismatches.push(`群号不一致：事件=${read.sceneKey}，平台回读=${gotGroup}`)
      }
    }
    const gotType = String(data?.message_type ?? '').trim()
    if (gotType !== '' && gotType !== (read.scene === SCENE.GROUP ? 'group' : 'private')) {
      mismatches.push(`消息类型不一致：事件=${read.scene}，平台回读=${gotType}`)
    }
    const backText = normText(data?.raw_message ?? data?.message ?? '')
    const eventText = normText(read.content?.raw || read.content?.text)
    if (backText !== '' && eventText !== '' && backText !== eventText) {
      mismatches.push('正文不一致：事件与平台回读不同')
    }
  }

  // ── 2. 群聊时核对成员身份（非群成员发出 @机器人 消息属于异常）───────────
  const checkMember = options.checkMember !== false && read.scene === SCENE.GROUP
  if (checkMember) {
    try {
      const info = await withTimeout(
        callAction('get_group_member_info', {
          group_id: Number(read.sceneKey),
          user_id: Number(read.subject),
          no_cache: true,
        }),
        timeoutMs,
      )
      const data = info && typeof info === 'object' ? (info.data ?? info) : null
      const memberUid = String(data?.user_id ?? '').trim()
      if (memberUid !== '' && memberUid !== read.subject) {
        mismatches.push(`群成员不一致：事件=${read.subject}，平台回读=${memberUid}`)
      }
      checks.member = 'ok'
      const apiRole = String(data?.role ?? '').trim().toLowerCase()
      if (apiRole !== '' && isFilled(read.author?.role) && apiRole !== read.author.role) {
        // 角色不一致不判死（管理员刚被撤职是常态），但必须留痕并降级
        checks.memberRole = `${read.author.role}->${apiRole}`
      }
    } catch (err) {
      checks.member = err?.timeout ? 'timeout' : 'unsupported'
    }
  }

  if (mismatches.length > 0) {
    if (options.required) {
      throw identityError(REJECT.CORROBORATION_MISMATCH, `服务端复核不一致：${mismatches[0]}`, {
        mismatches,
      })
    }
    return {
      corroborated: false,
      trust: read.trust,
      checks,
      mismatches,
      reason: 'mismatch',
    }
  }

  const supported = checks.getMsg === 'ok' || checks.member === 'ok'
  return {
    corroborated: supported,
    trust: supported ? TRUST.CORROBORATED : read.trust,
    checks,
    mismatches,
    reason: supported ? 'ok' : 'unsupported',
  }
}

/**
 * 官方平台的复核入口。
 *
 * 保留同形签名，明确返回 unsupported：官方 v2 没有"按消息 ID 回读"的接口，
 * 声称复核过就是造假。官方消息的可信度只能依靠第一方连接与事件体字段。
 */
export async function corroborateOfficial() {
  return {
    corroborated: false,
    trust: TRUST.PLATFORM_VERIFIED,
    checks: { getMsg: 'unsupported' },
    mismatches: [],
    reason: 'official-has-no-readback-api',
  }
}
