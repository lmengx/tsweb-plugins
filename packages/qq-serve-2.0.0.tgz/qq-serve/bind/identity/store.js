/**
 * 主体登记表（OpenID ↔ 游戏角色 / QQ）
 *
 * 为什么需要它：QQ 官方通道**永远拿不到 QQ 号**（事件体里只有 openid）。
 * 旧方案靠"框架机器人补一条数据 + 编码配对"来补 QQ 号，本质是在两个通道之间猜同一件事。
 * 这里改成：官方通道自己就能被授权——把 openid 精确登记到某个游戏角色；
 * 需要展示 QQ 号时才读同一行的 qq 字段，而那必须是**权威来源写入**的（面板手工确认或已绑定账号）。
 *
 * 与 Ledger 的分工：
 *   Ledger        角色 ↔ QQ 的唯一权威（既有资产，不动）
 *   SubjectStore  平台主体 ↔ 角色/QQ 的登记（本模块新增，只做精确键）
 */
import { constants as fsConstants } from 'node:fs'
import { access, mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import { identityError, isFilled, isOpenid, isQq, isSceneKey, REJECT } from './schema.js'

export const SUBJECT_SCHEMA = 1

/** 主体键：平台 + 机器人实例 + 场景 + 主体。不同机器人/不同群的同一人必须落到不同行 */
export function subjectKey({ platform, botId, sceneKey, subject }) {
  return [platform, botId, sceneKey, subject].map((v) => String(v ?? '')).join(':')
}

function normRow(input = {}) {
  const platform = String(input.platform ?? '').trim()
  const botId = String(input.botId ?? '').trim()
  const sceneKey = String(input.sceneKey ?? '').trim()
  const subject = String(input.subject ?? '').trim()
  if (!isFilled(platform)) throw identityError(REJECT.MALFORMED, '主体登记缺少 platform')
  if (!isFilled(botId)) throw identityError(REJECT.MALFORMED, '主体登记缺少 botId')
  if (!isSceneKey(sceneKey)) throw identityError(REJECT.MALFORMED, '主体登记缺少合法 sceneKey')
  if (!isOpenid(subject)) throw identityError(REJECT.MALFORMED, '主体登记缺少合法 subject')

  const qq = input.qq == null || input.qq === '' ? '' : String(input.qq).trim()
  if (qq !== '' && !isQq(qq)) throw identityError(REJECT.MALFORMED, '主体登记里的 QQ 号格式不正确')

  const username = String(input.username ?? '').trim()
  if (username === '') throw identityError(REJECT.MALFORMED, '主体登记必须指向一个游戏角色')

  return {
    platform,
    botId,
    sceneKey,
    subject,
    subjectKind: String(input.subjectKind || 'openid'),
    qq,
    username,
    /** 这条登记是怎么来的：panel（面板手工）/ proof（本人一次性所有权证明）/ import（批量导入） */
    proof: String(input.proof || 'panel'),
    note: String(input.note || '').slice(0, 200),
    updatedAt: Number(input.updatedAt) || Date.now(),
  }
}

export class SubjectStore {
  /**
   * @param {{file:string, now?:()=>number}} options
   */
  constructor({ file, now = () => Date.now() } = {}) {
    this.file = file
    this.now = now
    /** @type {Map<string, object>} */
    this._rows = new Map()
    this._loaded = false
    /** 写队列：同一文件的所有写入串行，避免并发 bind 互相覆盖 */
    this._queue = Promise.resolve()
  }

  get size() {
    return this._rows.size
  }

  async load() {
    let text = ''
    try {
      text = await readFile(this.file, 'utf8')
    } catch (err) {
      if (err.code === 'ENOENT') {
        this._loaded = true
        return this
      }
      // 读错误不等于"没有文件"：绝不能当成空表继续跑，否则下一次写会覆盖掉真实数据
      throw identityError(REJECT.MALFORMED, `主体登记表读取失败：${err.message}`)
    }
    let doc
    try {
      doc = JSON.parse(text)
    } catch (err) {
      throw identityError(REJECT.MALFORMED, `主体登记表不是合法 JSON：${err.message}`)
    }
    if (!doc || typeof doc !== 'object' || !Array.isArray(doc.subjects)) {
      throw identityError(REJECT.MALFORMED, '主体登记表结构不合法（缺少 subjects 数组）')
    }
    this._rows.clear()
    for (const raw of doc.subjects) {
      const row = normRow(raw)
      this._rows.set(subjectKey(row), row)
    }
    this._loaded = true
    return this
  }

  _assertLoaded() {
    if (!this._loaded) {
      throw identityError(REJECT.MALFORMED, '主体登记表尚未加载（先 await load()）')
    }
  }

  _serialize() {
    return (
      JSON.stringify(
        {
          schema: SUBJECT_SCHEMA,
          updatedAt: this.now(),
          subjects: [...this._rows.values()].sort((a, b) =>
            subjectKey(a).localeCompare(subjectKey(b)),
          ),
        },
        null,
        2,
      ) + '\n'
    )
  }

  /** 原子落盘：写唯一临时文件 → rename 覆盖。失败时原文件保持不动 */
  async _flush() {
    const text = this._serialize()
    const tmp = `${this.file}.${process.pid}.${this.now()}.tmp`
    await mkdir(dirname(this.file), { recursive: true })
    await writeFile(tmp, text, 'utf8')
    try {
      await rename(tmp, this.file)
    } catch (err) {
      // Windows 下 rename 覆盖偶发失败：清理临时文件后抛出，避免留下垃圾
      try {
        await access(tmp, fsConstants.F_OK)
        await writeFile(tmp, '', 'utf8')
      } catch {
        /* 清理失败不掩盖原始错误 */
      }
      throw err
    }
  }

  _enqueue(fn) {
    const run = this._queue.then(fn, fn)
    // 队列自身不能因为一次失败而中断后续写入
    this._queue = run.then(
      () => undefined,
      () => undefined,
    )
    return run
  }

  get(row) {
    this._assertLoaded()
    return this._rows.get(subjectKey(row)) || null
  }

  list({ qq = '', username = '', platform = '' } = {}) {
    this._assertLoaded()
    const out = []
    for (const row of this._rows.values()) {
      if (qq && row.qq !== String(qq)) continue
      if (username && row.username !== String(username)) continue
      if (platform && row.platform !== String(platform)) continue
      out.push({ ...row })
    }
    return out
  }

  findByQq(qq) {
    return this.list({ qq })
  }

  /**
   * 登记/更新一个主体。同一角色可以被多个主体指向（一个人多个 OpenID），
   * 但同一主体只能指向一个角色——后者由主键保证。
   *
   * 声明为 async：字段校验失败也走 promise 拒绝，调用方只需 `await` + `try/catch`，
   * 不会出现"有的错误同步抛、有的错误异步抛"这种半途状态。
   */
  async bind(input) {
    this._assertLoaded()
    const row = normRow({ ...input, updatedAt: this.now() })
    return this._enqueue(async () => {
      this._rows.set(subjectKey(row), row)
      await this._flush()
      return { ...row }
    })
  }

  async unbind(row) {
    this._assertLoaded()
    const key = subjectKey(row)
    return this._enqueue(async () => {
      const existed = this._rows.delete(key)
      if (existed) await this._flush()
      return existed
    })
  }
}
