/**
 * 身份归因日志（append-only JSONL）
 *
 * 目的：事后能回答"这条消息当时被判给谁、依据是什么、读过哪些字段"。
 * 旧方案在这件事上只有一句"机器人说 qq=xxx"，出了争议无从核对。
 *
 * 隐私与体积：
 *   - 正文只存前 PREVIEW_MAX 字符 + sha256 摘要，不落全文（群里可能有手机号等）
 *   - 按文件大小轮转，保留 N 份
 */
import { createHash } from 'node:crypto'
import { appendFile, mkdir, rename, stat } from 'node:fs/promises'
import { dirname } from 'node:path'

const PREVIEW_MAX = 120

function digestOf(value) {
  return createHash('sha256').update(String(value ?? '')).digest('hex')
}

export class AttributionLog {
  /**
   * @param {{file:string, maxBytes?:number, keep?:number, now?:()=>number}} options
   */
  constructor({ file, maxBytes = 2 * 1024 * 1024, keep = 3, now = () => Date.now() } = {}) {
    this.file = file
    this.maxBytes = maxBytes
    this.keep = keep
    this.now = now
    this._queue = Promise.resolve()
  }

  /**
   * 记录一条归因结果。
   *
   * @param {object} entry
   * @param {object} entry.read        MessageRead
   * @param {object|null} entry.identity ResolvedIdentity（拒绝时可为 null）
   * @param {string} [entry.decision]  accepted / rejected
   * @param {string} [entry.code]      拒绝码
   * @param {object} [entry.extra]     附加（复核结果等）
   */
  append(entry = {}) {
    const read = entry.read || {}
    const identity = entry.identity || {}
    const text = String(read.content?.text ?? '')
    const record = {
      at: this.now(),
      decision: String(entry.decision || 'accepted'),
      code: String(entry.code || ''),
      reason: String(identity.reason || entry.reason || ''),
      platform: read.platform || '',
      botId: read.botId || '',
      eventType: read.eventType || '',
      scene: read.scene || '',
      sceneKey: read.sceneKey || '',
      subject: read.subject || '',
      subjectKind: read.subjectKind || '',
      subjectScope: read.subjectScope || '',
      messageId: read.messageId || '',
      receivedAt: read.receivedAt || 0,
      sentAt: Number.isFinite(read.sentAt) ? read.sentAt : 0,
      role: identity.role || read.author?.role || '',
      qq: identity.qq || '',
      username: identity.username || '',
      confidence: identity.confidence || '',
      trust: read.trust || '',
      via: identity.via || '',
      rawDigest: read.raw?.digest || '',
      textDigest: digestOf(text),
      textPreview: text.slice(0, PREVIEW_MAX),
      checks: entry.extra?.checks ? { ...entry.extra.checks } : undefined,
      mismatches: Array.isArray(entry.extra?.mismatches) && entry.extra.mismatches.length > 0
        ? entry.extra.mismatches.slice(0, 5)
        : undefined,
    }
    const line = JSON.stringify(record) + '\n'
    return this._enqueue(async () => {
      await mkdir(dirname(this.file), { recursive: true })
      await this._rotateIfNeeded(Buffer.byteLength(line, 'utf8'))
      await appendFile(this.file, line, 'utf8')
      return record
    })
  }

  async _rotateIfNeeded(incomingBytes) {
    let size = 0
    try {
      size = (await stat(this.file)).size
    } catch (err) {
      if (err.code === 'ENOENT') return
      throw err
    }
    if (size + incomingBytes <= this.maxBytes) return
    // file → file.1 → file.2 …，只保留 keep 份；轮转失败不阻断本次写入
    for (let i = this.keep - 1; i >= 1; i -= 1) {
      const from = i === 1 ? this.file : `${this.file}.${i - 1}`
      const to = `${this.file}.${i}`
      try {
        await rename(from, to)
      } catch (err) {
        if (err.code !== 'ENOENT') return
      }
    }
    try {
      await rename(this.file, `${this.file}.1`)
    } catch {
      /* 轮转尽力而为 */
    }
  }

  _enqueue(fn) {
    const run = this._queue.then(fn, fn)
    this._queue = run.then(
      () => undefined,
      () => undefined,
    )
    return run
  }
}
