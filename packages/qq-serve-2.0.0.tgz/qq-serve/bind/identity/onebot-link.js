/**
 * OneBot 11 连接层：第一方认证连接 + 动作调用（复核用）
 *
 * 为什么单独一层而不是直接塞进适配器：
 *   - 复核需要用 get_msg / get_group_member_info 反查，这就要求"能发动作、能等 echo"，
 *     是连接层职责，不该让身份解析层依赖任何 WebSocket 实现。
 *   - 传输实现可注入（生产用 ws，测试用内存管道），因此本文件不 import 任何第三方包。
 *
 * 硬前置：**连接必须是本进程与 OneBot 实现之间的第一方认证连接**。
 * 构造时 `authorized !== true` 直接拒绝创建——这是旧方案被替换掉的根因所在：
 * 旧路径的身份来自"另一个机器人进程在 HTTP body 里自报 qq"，无论加多少校验都只是转述。
 */
import { identityError, PLATFORM, REJECT } from './schema.js'

const DEFAULT_ACTION_TIMEOUT = 5_000

/**
 * @param {object} options
 * @param {string|number} options.botId        本连接对应的机器人 QQ（self_id）
 * @param {boolean} options.authorized         握手是否已由传输层完成认证（必须为 true）
 * @param {{send:(text:string)=>void}} options.transport 已建立的连接（单向发送出口）
 * @param {object} [options.ingress]            createMessageIngress 的返回值
 * @param {(event:object, transport:string)=>Promise<any>} [options.onEvent] 自定义事件消费
 * @param {number} [options.actionTimeoutMs]
 * @param {Function} [options.now]
 */
export function createOneBotLink(options = {}) {
  if (options.authorized !== true) {
    throw identityError(
      REJECT.UNKNOWN_BOT,
      'OneBot 连接未完成第一方认证（Authorization 未校验通过）。' +
        '不允许用未认证连接读取身份：那等于采信第三方转述。',
    )
  }
  const botId = String(options.botId ?? '').trim()
  if (botId === '') throw identityError(REJECT.UNKNOWN_BOT, 'OneBot 连接缺少机器人 QQ（self_id）')

  const transport = options.transport
  if (!transport || typeof transport.send !== 'function') {
    throw new Error('createOneBotLink 需要 transport.send(text)')
  }
  const timeoutMs = Number(options.actionTimeoutMs) > 0 ? Number(options.actionTimeoutMs) : DEFAULT_ACTION_TIMEOUT
  const now = typeof options.now === 'function' ? options.now : () => Date.now()
  const stats = { frames: 0, events: 0, ignored: 0, actions: 0, actionTimeouts: 0 }

  /** @type {Map<string, {resolve:Function, reject:Function, timer:any}>} */
  const pending = new Map()
  let seq = 0
  let closed = false

  function settle(echo, ok, payload) {
    const entry = pending.get(echo)
    if (!entry) return false
    pending.delete(echo)
    clearTimeout(entry.timer)
    if (ok) entry.resolve(payload)
    else entry.reject(payload)
    return true
  }

  /**
   * 调用一个 OneBot 动作并等待 echo 回执。
   *
   * @returns {Promise<any>} 回执的 data（失败回执按 retcode 抛错）
   */
  function callAction(action, params = {}, { timeout = timeoutMs } = {}) {
    if (closed) return Promise.reject(new Error('OneBot 连接已关闭'))
    const echo = `tsweb-${now()}-${(seq += 1)}`
    stats.actions += 1
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pending.delete(echo)
        stats.actionTimeouts += 1
        const err = new Error(`OneBot 动作超时：${action}`)
        err.timeout = true
        reject(err)
      }, timeout)
      pending.set(echo, { resolve, reject, timer })
      try {
        transport.send(JSON.stringify({ action, params, echo }))
      } catch (err) {
        pending.delete(echo)
        clearTimeout(timer)
        reject(err)
      }
    })
  }

  /**
   * 处理一帧（字符串或已解析对象）。
   *
   * @param {string|object} frame
   * @returns {Promise<object|null>} 事件消费结果（无事件时返回 null）
   */
  async function handleFrame(frame) {
    stats.frames += 1
    let payload = frame
    if (typeof frame === 'string') {
      try {
        payload = JSON.parse(frame)
      } catch {
        stats.ignored += 1
        return null
      }
    }
    if (!payload || typeof payload !== 'object') {
      stats.ignored += 1
      return null
    }

    // 动作回执：只有 echo 能对上的才认，其他一律忽略（不猜）
    if (payload.echo != null) {
      const ok = payload.retcode === 0
      const handled = settle(payload.echo, ok, payload)
      if (!handled) stats.ignored += 1
      return null
    }

    // 心跳/生命周期事件不参与身份判定
    if (payload.post_type !== 'message') {
      stats.ignored += 1
      return null
    }

    stats.events += 1
    if (typeof options.onEvent === 'function') {
      return options.onEvent(payload, PLATFORM.ONEBOT)
    }
    if (options.ingress) {
      return options.ingress.ingest(payload, { transport: PLATFORM.ONEBOT, receivedAt: now() })
    }
    return null
  }

  function close(reason = 'closed') {
    closed = true
    for (const [echo, entry] of pending) {
      clearTimeout(entry.timer)
      entry.reject(new Error(`OneBot 连接关闭：${reason}`))
      pending.delete(echo)
    }
  }

  return {
    botId,
    stats,
    callAction,
    handleFrame,
    close,
    get pendingCount() {
      return pending.size
    },
  }
}
