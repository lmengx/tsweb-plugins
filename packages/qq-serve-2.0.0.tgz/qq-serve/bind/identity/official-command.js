/**
 * 「获取qq号」：官方通道收到消息 → 跨通道对应到框架机器人观测 → 报出发送者真实 QQ。
 *
 * 三条路径：
 *   1. OpenID 已登记过 → 直接给 QQ（最快，永久有效）
 *   2. 未登记 → 拿这条官方消息去和框架机器人（OneBot）的观测做**唯一性对应**：
 *      同群 + 同文本 + 同附件数 + 接收时刻差 ≤ 5 秒，且只有一个候选 ⇒ 得到 QQ
 *      （成功后落一条 proof=corroborated-message 的登记，以后不用再对应）
 *   3. 对应不上（群没映射 / 框架没连通 / 有歧义）→ 明确说明原因，不猜
 */
import { join } from 'node:path'

const COMMAND_NAMES = ['获取qq号', '我的qq号', 'qq号']
const WAIT_MS = 2500

export async function registerIdentityCommand(manager, { dataDir, getService, identitySettings = null, revision = '' }) {
  const {
    AttributionLog,
    CorrespondenceEngine,
    GroupMappingStore,
    MATCH,
    PLATFORM,
    REQUIRED_CONFIRMATIONS,
    SubjectStore,
    createIdentityGate,
    createMessageIngress,
    IDENTIFY_STATE,
    readOfficialSdkMessage,
  } = await import(`./index.js${revision}`)

  /** 当前设置（指令开关 + 协同开关）；没注入时用设计默认值 */
  const settings = () => identitySettings?.value || {
    commands: {},
    collab: { observation: true, assistQq: true, autoTransfer: false, autoTransferTrigger: ['menu'],
      writeBackLedger: true, windowMs: 5000, awaitMs: 2000, groupConfirmations: 5 },
  }
  const collab = () => settings().collab

  const subjects = new SubjectStore({ file: join(dataDir, 'identity-subjects.json') })
  const attribution = new AttributionLog({ file: join(dataDir, 'identity-attribution.jsonl') })

  const hookLog = (line) => {
    try { console.log(`[identity] ${line}`) } catch { /* 日志失败无关 */ }
  }

  /**
   * 群对应：连续 REQUIRED_CONFIRMATIONS 条消息一致才确认并落盘。
   * 未确认前只作为本进程内的临时对应（重启即忘），避免一次偶然吻合被固化。
   */
  const mapping = new GroupMappingStore({
    file: join(dataDir, 'group-map.json'),
    required: Number(settings().collab?.groupConfirmations) || REQUIRED_CONFIRMATIONS,
  })
  await mapping.load().catch((error) => hookLog(`群对应表读取失败（忽略）：${error?.message || error}`))
  mapping.onConfirm = ({ sceneKey, groupId, confirmations }) => {
    hookLog(`群对应已确认并落盘：官方 ${sceneKey} ↔ 群 ${groupId}（连续 ${confirmations} 条一致）`)
  }

  /** 跨通道对应引擎 */
  const engine = new CorrespondenceEngine({ mapping, windowMs: Number(collab().windowMs) || 5000 })
  // 供面板读取「已识别群」（只读）
  if (identitySettings) {
    identitySettings.groupsProvider = () => engine.discoveredMappings()
  }

  /** 当前台账（延迟解析；qq-bind 可能晚于本插件就绪） */
  let currentLedger = null
  async function refreshLedger() {
    try {
      const bind = getService('qqBind')
      if (!bind) { currentLedger = null; return }
      if (bind.ready && typeof bind.ready.then === 'function') await bind.ready.catch(() => {})
      currentLedger = bind.ledger || null
    } catch { currentLedger = null }
  }
  const ledgerProxy = {
    getByQq: qq => currentLedger?.getByQq?.(qq) ?? null,
    getByUsername: name => currentLedger?.getByUsername?.(name) ?? null,
  }

  const ingress = createMessageIngress({
    ledger: ledgerProxy,
    subjects,
    attribution,
    config: {
      official: { enabled: true, botId: String(manager?.config?.appId || '') },
      onebot: { enabled: false },
      corroboration: { enabled: true },
    },
  })

  // ── 把框架机器人的入站事件接进对应引擎 ────────────────────────────────────
  // 项目结构：qq-serve 是同一个 QQ 插件族的共享服务，onebot-bridge 通过
  // qqServe.registerAdapter('onebot', service) 把自己挂进 qqServe.adapters。
  // 因此这里直接取 adapter 实例包装它的 handleEvent 即可，不需要跨插件模块补丁。
  let disposedHook = null
  let messageObservations = 0

  function oneBotAdapter() {
    try {
      return getService('qqServe')?.adapters?.get?.('onebot') || null
    } catch {
      return null
    }
  }

  function hookOneBot() {
    if (collab().observation === false) { if (disposedHook) { try { disposedHook() } catch { /* 已恢复 */ } disposedHook = null } return false }
    const bridge = oneBotAdapter()
    if (!bridge || typeof bridge.handleEvent !== 'function') return false
    if (bridge.__identityObserved) return true
    const original = bridge.handleEvent.bind(bridge)
    bridge.handleEvent = async (event) => {
      try {
        const observation = engine.observeOneBot(event)
        if (observation) {
          messageObservations += 1
          hookLog(`OneBot 群消息观测 +${messageObservations}：群 ${observation.groupId} QQ ${observation.qq} 文本 ${observation.text.slice(0, 20)}`)
        }
      } catch (error) {
        hookLog(`OneBot 观测处理异常：${error?.message || error}`)
      }
      return original(event)
    }
    bridge.__identityObserved = true
    disposedHook = () => {
      bridge.handleEvent = original
      bridge.__identityObserved = false
    }
    hookLog('OneBot 观测钩子已挂上（qqServe.adapters.onebot）')
    return true
  }
  hookOneBot()
  // 插件加载顺序不保证（实测 qq-serve 在 qq-official 之后加载，apply 时还取不到 qqServe），
  // 在服务出现之前短暂轮询，确保第一条消息之前钩子已挂好，不漏掉 OneBot 观测。
  const hookTimer = setInterval(() => {
    if (hookOneBot()) clearInterval(hookTimer)
  }, 500)
  hookTimer.unref?.()


  function safe(error) {
    try { return manager.safeError ? manager.safeError(error) : String(error?.message || error) }
    catch { return '未知错误' }
  }

  function lines(...parts) {
    return parts.filter((p) => p !== '' && p !== undefined && p !== null).join('\n')
  }

  // ── 需要真实 QQ 号的身份闸门（注册 / 绑定 / 绑定转移） ────────────────────
  const identityWaitMs = () => Number(collab().awaitMs) || 2000

  /** 面板改了数值项后无需重启：每次判定前把运行期参数同步一遍 */
  function syncRuntimeSettings() {
    const conf = collab()
    const windowMs = Number(conf.windowMs) || 5000
    if (engine.windowMs !== windowMs) engine.windowMs = windowMs
    const required = Number(conf.groupConfirmations) || REQUIRED_CONFIRMATIONS
    if (mapping.required !== required) mapping.required = required
  }
  /** 角色记录尚未落库时的待补 QQ（角色名 → qq） */
  const pendingLedgerFill = new Map()
  const gate = createIdentityGate({ engine, subjects, getLedger: () => currentLedger, log: hookLog })

  /** 从插件收到的消息对象解析 MessageRead（失败返回 null） */
  function readOf(message) {
    try {
      return readOfficialSdkMessage(message, { botId: String(manager?.config?.appId || '') })
    } catch {
      return null
    }
  }

  /** 把已验证的 QQ 挂到消息上，供命令处理器读取 */
  function attachVerified(message, info) {
    if (!message || !info?.qq) return
    message.__verifiedQq = info.qq
    message.__verifiedUsername = info.username || ''
    message.__verifiedState = info.state
  }

  /**
   * 包装命令：
   *   - 竞争（同群同文本同窗口多条候选）→ 返回 undefined，插件层不会发送任何消息（静默失败）
   *   - 已绑定（openid 已登记）或对应成功 → 把 QQ 挂到消息上再交给原处理器
   *   - 命令成功后写表单：台账补 QQ + 主体登记补 openid / 群 / 角色
   */
  function gateCommand(record, { writeForm = false } = {}) {
    if (!record || typeof record.run !== 'function' || record.__identityGated) return
    const original = record.run.bind(record)
    record.run = async (context) => {
      syncRuntimeSettings()
      const read = readOf(context?.message)
      let info = null
      if (read) {
        try {
          await refreshLedger()
          info = collab().assistQq === false ? null : await gate.identify(read, { waitMs: identityWaitMs() })
        } catch (error) {
          hookLog(`身份判定异常（继续原流程）：${safe(error)}`)
          info = null
        }
        if (info?.state === IDENTIFY_STATE.AMBIGUOUS) {
          hookLog(`命令 ${record.name} 身份竞争失败，静默不回复`)
          return undefined
        }
        if (info && (info.state === IDENTIFY_STATE.VERIFIED || info.state === IDENTIFY_STATE.KNOWN)) {
          attachVerified(context.message, info)
        }
      }
      const result = await original(context)
      // 命令成功后写表单：**KNOWN 与 VERIFIED 都写**——
      // KNOWN 表示该 openid 已登记过，但台账里的角色记录可能还没有 QQ，同样要补齐。
      const identifiable = info && (info.state === IDENTIFY_STATE.KNOWN || info.state === IDENTIFY_STATE.VERIFIED)
      hookLog(`命令 ${record.name}：身份=${info?.state || 'none'} qq=${info?.qq || '-'} 成功=${Boolean(result)}`)
      if (writeForm && result && identifiable && read && collab().writeBackLedger !== false) {
        const target = String(context?.args?.[0] || '').trim()
        if (target) {
          const written = await gate.writeForm(read, { qq: info.qq, username: target, proof: 'verified-command' })
          if (written.error) hookLog(`写表单未完全成功：${written.error}`)
          else hookLog(`已写入表单：角色 ${target} ↔ QQ ${info.qq}（台账=${written.ledger} 主体=${written.subjects}）`)
          // 注册完成后台账记录可能稍后才出现：记下待补，下次命令时再试
          if (!written.ledger) pendingLedgerFill.set(target, info.qq)
        }
      }
      // 补写上次没赶上的台账 QQ（角色记录当时还没落库）
      if (pendingLedgerFill.size > 0) {
        try {
          await refreshLedger()
          for (const [username, qq] of [...pendingLedgerFill]) {
            const rec = currentLedger?.getByUsername?.(username)
            if (!rec || rec.qq) { pendingLedgerFill.delete(username); continue }
            await currentLedger.rebind({ username, newQq: qq })
            pendingLedgerFill.delete(username)
            hookLog(`已补写台账 QQ：角色 ${username} ↔ ${qq}`)
          }
        } catch (error) {
          hookLog(`补写台账失败（保留待补）：${safe(error)}`)
        }
      }
      return result
    }
    record.__identityGated = true
  }

  /**
   * 自动转移旧用户（协同开关，默认禁用）：
   *   仅在 collab.autoTransfer 开启、且触发时机包含本命令场景时，才静默把
   *   "已绑定数字 QQ 但没有 openid 接入" 的老用户补绑 openid —— 不改动任何回复内容。
   */
  function silentTransferCommand(record, id) {
    if (!record || typeof record.run !== 'function' || record.__identityTransferWrapped) return
    const original = record.run.bind(record)
    record.run = async (context) => {
      try {
        syncRuntimeSettings()
        const conf = collab()
        const trigger = Array.isArray(conf.autoTransferTrigger) ? conf.autoTransferTrigger : ['menu']
        const scene = context?.message?.kind === 'group' ? 'group' : 'private'
        const wanted = conf.autoTransfer === true
          && (trigger.includes('any') || (id === 'menu' && trigger.includes('menu')))
          && (scene === 'group' || trigger.includes('private'))
        if (wanted) {
          const read = readOf(context?.message)
          if (read) {
            await refreshLedger()
            const r = await gate.silentLinkOpenid(read, { waitMs: identityWaitMs() })
            if (r?.linked) hookLog('自动转移已静默补绑 openid（未改动回复内容）')
          }
        }
      } catch (error) {
        hookLog(`自动转移异常（不影响回复）：${safe(error)}`)
      }
      return original(context)
    }
    record.__identityTransferWrapped = true
  }

  for (const name of ['register', '注册', 'bind', '绑定']) gateCommand(manager.commands.get(name), { writeForm: true })
  for (const name of ['menu', '菜单', '开始']) silentTransferCommand(manager.commands.get(name), 'menu')

  /** 命令名/别名 → 指令目录 id（用于"哪些指令可以用"的开关） */
  const NAME_TO_ID = {
    menu: 'menu', '菜单': 'menu', '开始': 'menu',
    help: 'help', '帮助': 'help',
    ping: 'ping', '测试': 'ping',
    status: 'status', '状态': 'status',
    servers: 'servers', '服务器': 'servers', '服务器列表': 'servers',
    server: 'server', '服务器状态': 'server',
    online: 'online', '在线': 'online', '在线玩家': 'online',
    me: 'me', '我的信息': 'me', '我的账号': 'me', '个人信息': 'me',
    account: 'account', '账号': 'account', '账号服务': 'account', '注册帮助': 'account', '绑定帮助': 'account',
    accounthelp: 'accounthelp', '账户服务说明': 'accounthelp', '账号服务说明': 'accounthelp',
    register: 'register', '注册': 'register',
    bind: 'bind', '绑定': 'bind',
    cancelbind: 'cancelbind', '取消绑定': 'cancelbind',
    claimpassword: 'claimpassword', '领取密码': 'claimpassword',
    password: 'password', '改密码': 'password', '修改密码': 'password',
    'group-info': 'group-info', '群信息': 'group-info', '群标识': 'group-info',
    transfer: 'transfer', '绑定转移': 'transfer',
    '获取qq号': 'qq-id', '我的qq号': 'qq-id', 'qq号': 'qq-id',
  }

  /**
   * 指令开关（官方端唯一归属）：
   *   关闭 → 回复一句"该功能已关闭"（不静默，避免用户以为机器人坏了）
   *   场景不符 → 同样回复，并说明该指令只允许在群/私聊
   */
  function applyCommandGates() {
    for (const [name, record] of manager.commands) {
      const id = NAME_TO_ID[String(name)]
      if (!id || !record || typeof record.run !== 'function' || record.__identityGated2) continue
      const original = record.run.bind(record)
      record.run = async (context) => {
        const conf = settings().commands?.[id]
        if (conf) {
          const scene = context?.message?.kind === 'group' ? 'group' : 'private'
          if (conf.enabled !== true) {
            return `「${name}」已被管理员关闭。`
          }
          if (conf.scene !== 'both' && conf.scene !== scene) {
            return conf.scene === 'private' ? `「${name}」只允许在私聊中使用。` : `「${name}」只允许在群内使用。`
          }
        }
        return original(context)
      }
      record.__identityGated2 = true
    }
  }
  applyCommandGates()

  async function describe(message) {
    syncRuntimeSettings()
    await refreshLedger()
    // 插件加载顺序不保证：onebot-bridge 可能晚于本插件就绪，每条命令再尝试挂一次观测钩子
    hookOneBot()
    // 每条命令重读登记表：运维/面板登记后即时生效
    try { await subjects.load() } catch { /* 读失败按未登记处理 */ }

    const result = await ingress.ingest(message, { transport: 'qq-official' })
    if (result.accepted) {
      return lines(
        `你的 QQ：${result.identity.qq || '（台账未记录）'}`,
        `游戏角色：${result.identity.username}`,
        `来源：${result.identity.via}，可信度 ${result.identity.confidence}`,
      )
    }
    // 平台会重复推送同一条消息：重复的直接回一句，不再走对应（否则会回两条）
    if (result.code === 'duplicate') {
      return '这条消息已经处理过一次（平台重复推送）。要再查一次，请重新发送。'
    }

    const read = result.read
    if (!read) {
      return `无法读取这条消息的发送者字段：${result.reason || result.code || '事件体不合法'}`
    }
    const subject = read.subject || String(message?.senderId || '')
    const subjectTitle = read.subjectScope || ''

    // ── 未登记：靠跨通道对应拿 QQ ────────────────────────────────────────
    // 注意：这里**不写任何登记**。对应结果只在本次回复里给出，不落盘、不进缓存。
    // 目的：每次测试都真实走一遍「消息对应」，便于反复验证同群并发相同消息的判定。
    const matched = await engine.waitForMatch(read, { timeoutMs: WAIT_MS })
    if (matched.status === MATCH.MATCHED) {
      const qq = matched.observation.qq
      const username = await resolveUsername(qq)
      const mappingNote = matched.evidence.groupConfirmed === true
        ? `群对应：官方 ${read.sceneKey.slice(0, 8)}… ↔ 群 ${matched.evidence.groupId}（已确认并落盘）`
        : `群对应：官方 ${read.sceneKey.slice(0, 8)}… ↔ 群 ${matched.evidence.groupId}（临时，连续一致 ${matched.evidence.confirmations}/${REQUIRED_CONFIRMATIONS} 条后落盘）`
      return lines(
        `你的 QQ：${qq}`,
        username ? `游戏角色：${username}` : '',
        `依据：与框架机器人同一条消息对应（同群同文本，相差 ${Math.abs(matched.evidence.deltaMs)} 毫秒）`,
        mappingNote,
        `对应明细：官方消息 ${read.messageId} ↔ OneBot 消息 ${matched.observation.messageId}`,
      )
    }

    if (matched.status === MATCH.AMBIGUOUS) {
      return lines(
        '无法唯一确定发送者：同一时刻有多条相同内容的消息。',
        ...matched.candidates.map((c, i) => {
          const gid = c.groupId ? `，群 ${c.groupId}` : ''
          return `候选 ${i + 1}：QQ ${c.qq}（相差 ${Math.abs(c.deltaMs)} 毫秒${gid}）`
        }),
        '请换个说法单独发一次「获取qq号」，即可准确对应。',
      )
    }

    const reasonText = {
      [MATCH.NO_GROUP_MAPPING]: '单聊消息无法与框架机器人对消息（那边只有群消息）。',
      [MATCH.NO_COMPARABLE_TEXT]: '这条消息没有可比较的文本（纯图片或卡片），无法跨通道对应。',
      [MATCH.PENDING]:
        '框架机器人没有收到这条消息，无法取到 QQ 号。请确认 OneBot 已连通、且机器人在本群。' +
        `（当前已缓冲框架消息 ${engine.buffered} 条）`,
    }[matched.status] || `对应失败：${matched.reason || matched.status}`

    return lines(
      '取不到你的 QQ 号。',
      reasonText,
      `你的 OpenID：${subject}${subjectTitle ? `（范围 ${subjectTitle}）` : ''}`,
      '说明：官方机器人收到的消息里只有 OpenID，平台不下发 QQ 号；QQ 号只能来自框架机器人的同一条消息。',
    )
  }

  async function resolveUsername(qq) {
    const rec = currentLedger?.getByQq?.(qq)
    return rec?.username || ''
  }

  const disposers = []
  for (const name of COMMAND_NAMES) {
    disposers.push(manager.registerCommand({
      name,
      description: '获取本条消息发送者的 QQ（官方通道只有 OpenID，QQ 来自框架机器人的同一条消息）',
      run: async ({ message }) => {
        try {
          return await describe(message)
        } catch (error) {
          return `身份查询失败：${safe(error)}`
        }
      },
    }))
  }

  return () => {
    clearInterval(hookTimer)
    if (disposedHook) { try { disposedHook() } catch { /* 已恢复 */ } }
    // 热重载/停用必须摘掉进程级观察者，否则旧 engine 与其缓冲一直挂在进程上，
    // 多个代际叠加会重复处理事件、重复打日志、内存不回收。
    try { hookModule?.removeOneBotObserver() } catch { /* 已移除 */ }
    for (const dispose of disposers) { try { dispose() } catch { /* 已注销 */ } }
  }
}
