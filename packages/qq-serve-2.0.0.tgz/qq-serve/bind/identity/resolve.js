/**
 * 身份解析：把 MessageRead 落到台账里的唯一一行
 *
 * 硬规则（这是"准确"二字的全部含义）：
 *   1. 只做**精确键查表**：OneBot 用 QQ 号查，官方用 OpenID 查。
 *   2. **禁止**用昵称、群名片、时间窗、内容哈希、最近一条消息等弱特征做匹配。
 *      旧方案之所以需要"编码"，正是因为这些弱特征无法定论；把它们删掉，编码也就不需要了。
 *   3. 查不到就是查不到：返回 confidence=none 与一个可执行的下一步，绝不猜。
 */
import {
  CONFIDENCE,
  identityError,
  REJECT,
  SCENE,
} from './schema.js'

/** 未验证身份时给机器人/前端的一句可执行提示 */
const ACTION_TEXT = Object.freeze({
  'bind-via-onebot': '请在与机器人同一账号的聊天里发送「绑定 角色名」完成绑定',
  'bind-subject': '当前 QQ 尚未关联游戏角色，请在面板的 QQ 绑定页完成关联',
})

/**
 * @typedef {object} IdentityLookup
 * @property {{getByQq:(qq:string)=>object|null, getByUsername:(name:string)=>object|null}} ledger
 * @property {{get:(key:object)=>object|null}} subjects
 */

/**
 * 解析一条消息的发送者身份。
 *
 * @param {object} read      readOfficialEvent / readOneBotEvent 的产出
 * @param {IdentityLookup} lookups
 * @returns {object} ResolvedIdentity
 */
export function resolveIdentity(read, { ledger, subjects } = {}) {
  if (!read || typeof read !== 'object') {
    throw identityError(REJECT.MALFORMED, '缺少消息读取结果')
  }
  const base = {
    platform: read.platform,
    botId: read.botId,
    scene: read.scene,
    sceneKey: read.sceneKey,
    subject: read.subject,
    subjectKind: read.subjectKind,
    messageId: read.messageId,
    trust: read.trust,
    role: read.author?.role || '',
    reasons: [],
  }

  let record = null
  let via = ''

  if (read.subjectKind === 'qq') {
    // OneBot：主体键本身就是真实 QQ 号，与台账主键同构
    record = ledger?.getByQq?.(read.subject) || null
    via = 'ledger.qq'
  } else {
    // 官方：主体键是 OpenID，只有"主体登记表"能给出对应的 QQ/角色
    const row = subjects?.get?.({
      platform: read.platform,
      botId: read.botId,
      sceneKey: read.sceneKey,
      subject: read.subject,
    })
    if (row) {
      via = 'subjects.openid'
      if (row.qq) {
        record = ledger?.getByQq?.(row.qq) || null
      } else if (row.username) {
        record = ledger?.getByUsername?.(row.username) || null
      }
      if (!record) {
        // 主体登记过，但台账里已没有对应角色（改名/解绑/删号）：不能拿旧登记授权
        return {
          ...base,
          confidence: CONFIDENCE.NONE,
          verified: false,
          code: REJECT.UNBOUND,
          reason: 'OpenID 登记的角色在台账中已不存在',
          requireAction: ACTION_TEXT['bind-subject'],
          via,
        }
      }
    }
  }

  if (!record) {
    const code = REJECT.UNBOUND
    const requireAction =
      read.subjectKind === 'qq' ? ACTION_TEXT['bind-via-onebot'] : ACTION_TEXT['bind-subject']
    return {
      ...base,
      confidence: CONFIDENCE.NONE,
      verified: false,
      code,
      reason: read.subjectKind === 'qq' ? '该 QQ 尚未绑定游戏角色' : '该 OpenID 尚未关联游戏角色',
      requireAction,
      via,
    }
  }

  // 一致性自检：台账是"角色 ↔ QQ"的一对一表，两个方向必须互指同一条记录。
  // 不一致说明台账已损坏或存在同角色多绑定——此时宁可不认，也不要挑一条来用。
  const backRef =
    record.username && ledger?.getByUsername
      ? ledger.getByUsername(record.username)
      : null
  if (backRef && backRef.qq !== record.qq) {
    return {
      ...base,
      confidence: CONFIDENCE.NONE,
      verified: false,
      code: REJECT.AMBIGUOUS,
      reason: `角色 ${record.username} 在台账里对应多个 QQ，无法唯一确定`,
      requireAction: '请在面板的 QQ 绑定页处理冲突后重试',
      via,
    }
  }

  const reasons = []
  // 官方群聊的 member_openid 只在同群稳定：换群即换键，这里把范围带出来供审计核对
  if (read.subjectKind === 'openid' && read.scene === SCENE.GROUP) {
    reasons.push('subject-scope=group（member_openid 仅同群稳定）')
  }

  return {
    ...base,
    confidence: reasons.length > 0 ? CONFIDENCE.DEGRADED : CONFIDENCE.EXACT,
    verified: true,
    code: '',
    qq: record.qq || '',
    username: record.username || '',
    record,
    reasons,
    requireAction: '',
    via,
  }
}

/**
 * 把解析结果转成能力层可用的 principal。
 *
 * 与旧 principal 的差别：带 `identity` 结构，能力层可据此要求"必须来自平台验证的身份"。
 * boundUsername 保持同名字段，兼容既有能力处理器。
 */
export function toPrincipal(resolved, { adapter = 'ingress', kind = 'user' } = {}) {
  if (!resolved) return null
  return {
    kind,
    adapter,
    qq: resolved.qq || '',
    boundUsername: resolved.username || '',
    identity: {
      verified: resolved.verified === true,
      confidence: resolved.confidence,
      platform: resolved.platform,
      botId: resolved.botId,
      scene: resolved.scene,
      sceneKey: resolved.sceneKey,
      subject: resolved.subject,
      subjectKind: resolved.subjectKind,
      role: resolved.role || '',
      trust: resolved.trust,
      messageId: resolved.messageId,
      code: resolved.code || '',
    },
  }
}
