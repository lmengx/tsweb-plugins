/**
 * 实测事件采集（为"结合实测接收消息的数据"提供可复现的入口）
 *
 * 用途：把线上真实推送的原始事件原样落盘，再用 EventCapture.replay 在离线测试里重放。
 * 这样"机制对不对"可以用真实数据验证，而不是只对着文档示例自说自话。
 *
 * 隐私：默认**不**改写正文（采集是为了复现问题）；确实要交出数据时用 redact:true，
 * 正文/卡片描述/昵称会被替换为占位符，只保留结构与标识字段。
 */
import { appendFile, mkdir, readFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import { identityError, PLATFORM, REJECT } from './schema.js'

const REDACTED = '[已隐去]'

/** 正文类字段：这些是"能看出人说了什么"的内容，分享数据前必须隐去 */
const TEXT_FIELDS = new Set(['content', 'raw_message', 'username', 'nickname', 'card'])

function redactDeep(value) {
  if (Array.isArray(value)) return value.map(redactDeep)
  if (!value || typeof value !== 'object') return value
  const out = {}
  for (const [key, child] of Object.entries(value)) {
    if (TEXT_FIELDS.has(key) && typeof child === 'string' && child !== '') {
      out[key] = REDACTED
    } else if (key === 'message' && Array.isArray(child)) {
      // OneBot 的消息段：只保留类型，去掉文本
      out[key] = child.map((seg) =>
        seg && typeof seg === 'object'
          ? { type: seg.type, data: seg.type === 'text' ? { text: REDACTED } : seg.data }
          : seg,
      )
    } else if (key === 'ark_data' && child && typeof child === 'object') {
      out[key] = { ...child, prompt: REDACTED, fields: REDACTED }
    } else {
      out[key] = redactDeep(child)
    }
  }
  return out
}

export class EventCapture {
  /**
   * @param {{file:string, now?:()=>number}} options
   */
  constructor({ file, now = () => Date.now() } = {}) {
    this.file = file
    this.now = now
  }

  /**
   * 采集一条原始事件。
   *
   * @param {object} raw        平台原始事件（官方推送信封 / OneBot 事件对象）
   * @param {{transport:string, note?:string, redact?:boolean}} meta
   */
  async record(raw, meta = {}) {
    const transport = String(meta.transport || '').trim()
    if (transport !== PLATFORM.QQ_OFFICIAL && transport !== PLATFORM.ONEBOT) {
      throw identityError(REJECT.MALFORMED, `采集需要明确 transport（${PLATFORM.QQ_OFFICIAL} / ${PLATFORM.ONEBOT}）`)
    }
    if (!raw || typeof raw !== 'object') {
      throw identityError(REJECT.MALFORMED, '采集内容必须是原始事件对象')
    }
    const entry = {
      at: this.now(),
      transport,
      note: String(meta.note || '').slice(0, 200),
      redacted: meta.redact === true,
      payload: meta.redact === true ? redactDeep(raw) : raw,
    }
    await mkdir(dirname(this.file), { recursive: true })
    await appendFile(this.file, JSON.stringify(entry) + '\n', 'utf8')
    return entry
  }

  /**
   * 读出采集文件（JSONL），供离线重放。
   * @returns {Promise<Array<{at:number, transport:string, note:string, redacted:boolean, payload:object}>>}
   */
  static async replay(file) {
    let text = ''
    try {
      text = await readFile(file, 'utf8')
    } catch (err) {
      if (err.code === 'ENOENT') return []
      throw err
    }
    const out = []
    for (const line of text.split('\n')) {
      const trimmed = line.trim()
      if (trimmed === '') continue
      try {
        const entry = JSON.parse(trimmed)
        if (entry && typeof entry === 'object' && entry.payload) out.push(entry)
      } catch {
        // 坏行跳过：采集文件是排障产物，不该因为一行损坏就无法重放其余部分
      }
    }
    return out
  }
}
