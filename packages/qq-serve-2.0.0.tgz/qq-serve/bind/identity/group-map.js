/**
 * 群对应落盘（官方 group_openid ↔ 数字群号），需要"连续 N 条消息一致"才确认
 *
 * 为什么要求连续多条一致：
 *   单条消息的对应可能偶然吻合（同一人同时在别的群发了同一句话、或另一个群恰好有同文本），
 *   一次就落盘会把错误关系固化下来。要求连续 REQUIRED_CONFIRMATIONS 条都指向同一个群，
 *   并且中途出现不同群就从头计数，才能把"偶然"挡在外面。
 *
 * 落盘位置：<data>/qq-bind/group-map.json
 *   { schema, updatedAt, groups: { "<group_openid>": { groupId, confirmations, confirmedAt } } }
 *
 * 语义分层：
 *   - confirmations < N：**临时对应**，只用于本次进程内的判定，不落盘、重启即忘；
 *   - confirmations >= N：**已确认**，落盘，重启后直接复用。
 */
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'

export const GROUP_MAP_SCHEMA = 1
export const REQUIRED_CONFIRMATIONS = 5

/** 默认的进程内实现（不加锁、不落盘），供引擎单测使用 */
export class InMemoryGroupMapping {
  constructor({ required = REQUIRED_CONFIRMATIONS } = {}) {
    this.required = required
    /** @type {Map<string, {groupId:string, confirmations:number, confirmedAt:number}>} */
    this.rows = new Map()
    this.onConfirm = null
  }

  groupOf(sceneKey) {
    return this.rows.get(String(sceneKey))?.groupId || ''
  }

  isConfirmed(sceneKey) {
    const row = this.rows.get(String(sceneKey))
    return Boolean(row?.confirmedAt)
  }

  /**
   * 记一次一致观测。
   * @returns {{groupId:string, confirmations:number, confirmed:boolean, changed:boolean}}
   */
  observe(sceneKey, groupId, now = Date.now()) {
    const key = String(sceneKey)
    const row = this.rows.get(key)
    if (row && row.groupId === String(groupId)) {
      row.confirmations += 1
      if (!row.confirmedAt && row.confirmations >= this.required) {
        row.confirmedAt = now
        this._fire(key, row)
        return { groupId: row.groupId, confirmations: row.confirmations, confirmed: true, changed: true }
      }
      return { groupId: row.groupId, confirmations: row.confirmations, confirmed: Boolean(row.confirmedAt), changed: false }
    }
    // 首次或换了群：从头计数（不一致就重置，避免"东一条西一条"凑满次数）
    const fresh = { groupId: String(groupId), confirmations: 1, confirmedAt: 0 }
    this.rows.set(key, fresh)
    if (this.required <= 1) {
      fresh.confirmedAt = now
      this._fire(key, fresh)
      return { groupId: fresh.groupId, confirmations: 1, confirmed: true, changed: true }
    }
    return { groupId: fresh.groupId, confirmations: 1, confirmed: false, changed: false }
  }

  _fire(sceneKey, row) {
    if (typeof this.onConfirm !== 'function') return
    try { void this.onConfirm({ sceneKey, groupId: row.groupId, confirmations: row.confirmations }) } catch { /* 回调失败不影响判定 */ }
  }

  /** 供落盘实现初始化：直接注入已确认的行 */
  seed(rows) {
    for (const [sceneKey, row] of Object.entries(rows || {})) {
      this.rows.set(String(sceneKey), {
        groupId: String(row.groupId || ''),
        confirmations: Number(row.confirmations) || this.required,
        confirmedAt: Number(row.confirmedAt) || 0,
      })
    }
  }
}

export class GroupMappingStore extends InMemoryGroupMapping {
  /**
   * @param {{file:string, required?:number, now?:()=>number}} options
   */
  constructor({ file, required = REQUIRED_CONFIRMATIONS, now = () => Date.now() } = {}) {
    super({ required })
    this.file = file
    this.now = now
    this._queue = Promise.resolve()
  }

  async load() {
    let text = ''
    try {
      text = await readFile(this.file, 'utf8')
    } catch (error) {
      if (error.code === 'ENOENT') return this
      throw error
    }
    let doc
    try {
      doc = JSON.parse(text)
    } catch {
      // 坏了就当没有：不覆盖原文件，等下一次确认时重写
      return this
    }
    this.seed(doc?.groups)
    return this
  }

  /** 已确认才落盘；临时对应不写文件 */
  async save() {
    const groups = {}
    for (const [sceneKey, row] of this.rows) {
      if (!row.confirmedAt) continue
      groups[sceneKey] = { groupId: row.groupId, confirmations: row.confirmations, confirmedAt: row.confirmedAt }
    }
    const text = JSON.stringify({ schema: GROUP_MAP_SCHEMA, updatedAt: this.now(), groups }, null, 2) + '\n'
    const run = this._queue.then(async () => {
      await mkdir(dirname(this.file), { recursive: true })
      const tmp = `${this.file}.${process.pid}.${this.now()}.tmp`
      await writeFile(tmp, text, 'utf8')
      await rename(tmp, this.file)
    })
    this._queue = run.then(() => undefined, () => undefined)
    return run
  }

  /** 覆盖 observe：确认时落盘 */
  observe(sceneKey, groupId, now = this.now()) {
    const result = super.observe(sceneKey, groupId, now)
    if (result.confirmed && result.changed) {
      result.persisted = this.save()
      result.persisted.catch(() => { /* 落盘失败不影响本次判定，下次确认会再写 */ })
    }
    return result
  }

  /** 等待所有排队中的落盘完成（测试与优雅停机用） */
  async flush() {
    await this._queue
  }
}
