import { randomInt, createHash } from 'node:crypto'
import bcrypt from 'bcryptjs'
import { officialIdentity, identityKey, httpError } from './ledger.js'
import { serverFlags } from './config.js'
import { registrationSnapshot } from './credentials.js'

export const proofHash = code => createHash('sha256').update(code).digest('hex')
const problem = (status, message) => httpError(status, message, { publicMessage: message })
const serverName = server => String(server.name || '未命名服务器').replace(/[\x00-\x1f\x7f]/g, ' ').slice(0, 80)
export const initialPassword = () => {
  const alphabet = '0123456789abcdefghijklmnopqrstuvwxyz'
  let value
  do { value = Array.from({ length: 6 }, () => alphabet[randomInt(alphabet.length)]).join('') }
  while (!/[0-9]/.test(value) || !/[a-z]/.test(value))
  return value
}

// Only called by trusted local plugins. No HTTP route accepts a caller-supplied
// platform identity. Existing numeric QQ APIs and their validation stay intact.
export function installOfficialAccounts(service) {
  let queue = Promise.resolve()
  const exclusive = operation => {
    const result = queue.then(operation)
    queue = result.catch(() => {})
    return result
  }
  const check = async (identity, player, signal) => {
    await service.ready
    if (signal?.aborted) throw problem(503, '机器人已断开，请稍后重试。')
    const normalized = officialIdentity(identity), name = String(player || '').trim()
    if (!name || name.length > 32 || /[\x00-\x1f\x7f]/.test(name)) throw problem(400, '角色名不能为空，最长 32 个字符，不能包含控制字符。')
    if (service.ledger.getByIdentity(normalized)) throw problem(409, '你已经绑定了角色，无需重复注册或绑定。')
    if (service.ledger.getByUsername(name)) throw problem(409, '该角色已经绑定，不能由其他用户领取密码。')
    return { identity: normalized, name }
  }
  const rawCall = async (server, endpoint, params = {}) => {
    let result
    try { result = await service.ctx.tshock.fetchFor(server, endpoint, params, { timeoutMs: 5000 }) }
    catch { throw problem(502, `游戏服「${serverName(server)}」连接失败，绑定验证暂不可用；请恢复连接后重试。`) }
    if (!result.ok || !result.data || Number(result.data.status) >= 400 || result.data.error) throw problem(502, `游戏服「${serverName(server)}」未准备好，请管理员检查连接、REST 权限和 QqBind 插件版本。`)
    return result.data
  }
  const compatible = async server => {
    const status = await rawCall(server, '/data/qq/status')
    if (status.officialAccounts !== true) throw problem(503, '游戏服需要更新 QqBind 插件，才能使用官方机器人注册和绑定。')
  }
  const commit = async ({ identity, name, uuid = '', prepareDelivery, signal }) => {
    if (signal?.aborted) throw problem(503, '机器人已断开，请重新发起操作。')
    const password = initialPassword()
    const passwordHash = await bcrypt.hash(password, 10)
    // Durable encrypted delivery is prepared before the account commit. Readers
    // must match both the exact identity and current hash before disclosing it.
    await prepareDelivery({ username: name, password, passwordHash })
    if (signal?.aborted) throw problem(503, '机器人已断开，请重新发起操作。')
    await service.ledger.bind({ qq: '', identity, username: name, passwordHash, uuid, source: 'qq-official' })
    const snapshot = await registrationSnapshot(service)
    // An audit failure after commit must not suppress credential delivery.
    await service.audit.append('qqbind.official', { username: name, source: 'qq-official' }).catch(() => {})
    return { username: name, snapshot }
  }
  service.getByOfficialIdentity = identity => service.ledger?.getByIdentity(identity) || null
  // Resolve the requesting identity first and project owner-visible fields only.
  service.officialProfile = async identity => {
    await service.ready
    const record = service.ledger.getByIdentity(officialIdentity(identity))
    if (!record) return { bound: false }
    const profile = { bound: true, username: record.username, boundAt: record.boundAt, game: null }
    if (typeof service.playerInfo === 'function') {
      try {
        const info = await service.playerInfo(record.username)
        profile.game = { server: info.server, found: info.game?.found === true,
          group: info.game?.group, deaths: info.game?.deaths, fishingQuests: info.game?.fishing_quests,
          onlineMinutes: info.onlineMinutes }
      } catch { /* Binding remains readable while the game is offline. */ }
    }
    return profile
  }
  service.officialPasswordMatches = (identity, username, passwordHash) => {
    const rec = service.ledger?.secretsOf(username)
    return !!rec?.identity && identityKey(rec.identity) === identityKey(identity) && rec.passwordHash === passwordHash
  }
  service.changeOfficialPassword = options => exclusive(async () => {
    await service.ready
    const identity = officialIdentity(options.identity)
    if (options.signal?.aborted) throw problem(503, '机器人已断开，请稍后重试。')
    const record = service.ledger.getByIdentity(identity)
    if (!record) throw problem(404, '你还没有绑定角色。')
    const password = typeof options.password === 'string' ? options.password : ''
    if (password.length < 6 || Buffer.byteLength(password, 'utf8') > 72 || /\s|[\x00-\x1f\x7f]/.test(password))
      throw problem(400, '新密码至少 6 位，不含空格，UTF-8 长度不超过 72 字节。')
    const passwordHash = await bcrypt.hash(password, 10)
    // Identity and cancellation are checked again inside the ledger's serialized
    // write, so an administrator rebind during hashing cannot reset another user.
    const changed = await service.ledger.setPasswordHash(record.username, passwordHash, { expectedIdentity: identity, signal: options.signal })
    const snapshot = await registrationSnapshot(service)
    await service.audit.append('qqbind.change_password', { username: changed.username, source: 'qq-official' }).catch(() => {})
    return { username: changed.username, snapshot }
  })
  service.registerOfficial = options => exclusive(async () => {
    const { identity, name } = await check(options.identity, options.player, options.signal)
    if (!service.config.binding.allowSelfRegister) throw problem(403, '当前未开放自助注册。')
    const servers = await service.gameOps.enabledServers()
    if (!servers.length) throw problem(503, '尚未配置启用的游戏服。')
    if (!servers.some(server => serverFlags(service.config, server.id).syncCredentials)) throw problem(503, '请管理员先为至少一个游戏服启用 QQ 登录凭据同步。')
    // The central ledger owns namespace and credentials. Registration never
    // queries/creates game Users accounts. Offline replicas reconcile later;
    // QqLogin materializes a local account only after credential verification.
    return commit({ ...options, identity, name })
  })
  service.prepareOfficialBinding = async options => {
    const { identity, name } = await check(options.identity, options.player, options.signal)
    let located
    try { located = await service.gameOps.locateAccount(name, { serverId: options.serverId || '' }) }
    catch (cause) {
      throw problem(cause.status || 502, cause.status === 404 ? '没有找到该游戏账号，请先使用“注册 角色名”。' : '暂时不能定位唯一游戏账号，请管理员检查服务器连接或同名账号。')
    }
    await compatible(located.server)
    if (!serverFlags(service.config, located.server.id).syncCredentials) throw problem(503, '请管理员先为该游戏服启用 QQ 登录凭据同步。')
    return { identity, username: name, serverId: located.server.id }
  }
  service.completeOfficialBinding = options => exclusive(async () => {
    const { identity, name } = await check(options.identity, options.player, options.signal)
    const server = service.gameOps.rawOf(options.serverId)
    if (!server || server.enabled === false) throw problem(503, '验证服务器已停用，请重新发起绑定。')
    const proof = await rawCall(server, '/data/qq/binding-proof', { hash: options.proofHash })
    if (!proof.found) return null
    if (String(proof.username || '').toLowerCase() !== name.toLowerCase() || !/^[0-9a-fA-F-]{1,128}$/.test(proof.uuid || '')) throw problem(403, '游戏内验证的账号与待绑定角色不一致，请使用正确账号重新发起。')
    return commit({ ...options, identity, name: proof.username, uuid: proof.uuid })
  })
}
