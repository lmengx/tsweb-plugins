import fs from 'node:fs/promises'
import path from 'node:path'
import { randomBytes, randomUUID, createHash, createCipheriv, createDecipheriv } from 'node:crypto'

// Passwords awaiting private delivery survive a hot reload, encrypted at rest.
// Nothing here is returned from the configuration, status or log HTTP APIs.
// 合并后官方端与 OneBot 端共用同一数据目录，靠 names 区分各自的待投递队列文件，
// 保持"每端一份队列、互不覆盖"的既有行为。
export class CredentialDelivery {
  constructor(dataDir, now = () => Date.now(), names = {}) {
    this.dir = dataDir; this.now = now; this.queue = Promise.resolve()
    this.file = path.join(dataDir, names.state || 'credential-delivery.json')
    this.keyFile = path.join(dataDir, names.key || 'credential-delivery.key')
  }
  keyOf(identity) { return createHash('sha256').update(JSON.stringify([identity.appId, identity.subject])).digest('hex') }
  async load() {
    await fs.mkdir(this.dir, { recursive: true })
    try { this.key = await fs.readFile(this.keyFile) }
    catch (cause) {
      if (cause.code !== 'ENOENT') throw cause
      // Never silently replace a missing key when ciphertext already exists.
      try { await fs.access(this.file); throw new Error('密码投递密钥缺失，请管理员检查数据目录。') }
      catch (error) { if (error.code !== 'ENOENT') throw error }
      this.key = randomBytes(32)
      await fs.writeFile(this.keyFile, this.key, { mode: 0o600, flag: 'wx' })
    }
    if (this.key.length !== 32) throw new Error('密码投递密钥无效。')
    try {
      const data = JSON.parse(await fs.readFile(this.file, 'utf8'))
      if (data.version !== 1 || !data.rows || Array.isArray(data.rows) || typeof data.rows !== 'object') throw new Error('invalid delivery data')
      this.rows = Object.assign(Object.create(null), data.rows)
    } catch (cause) {
      if (cause.code !== 'ENOENT') throw new Error('密码待领取数据无法读取；已保留原文件。')
      this.rows = Object.create(null)
    }
  }
  mutate(operation) {
    const task = this.queue.then(async () => {
      const rows = { ...this.rows }, result = operation(rows)
      const tmp = `${this.file}.${randomUUID()}.tmp`
      try {
        await fs.writeFile(tmp, JSON.stringify({ version: 1, rows }), { mode: 0o600, flag: 'wx' })
        await fs.rename(tmp, this.file); this.rows = rows
      } finally { await fs.unlink(tmp).catch(() => {}) }
      return result
    })
    this.queue = task.catch(() => {})
    return task
  }
  put(identity, value) {
    return this.mutate(rows => {
      for (const [key, row] of Object.entries(rows)) if (row.expiresAt <= this.now()) delete rows[key]
      if (Object.keys(rows).length >= 1000 && !rows[this.keyOf(identity)]) throw new Error('密码待领取队列已满。')
      const key = this.keyOf(identity), nonce = randomBytes(12)
      const cipher = createCipheriv('aes-256-gcm', this.key, nonce)
      cipher.setAAD(Buffer.from(key))
      const ciphertext = Buffer.concat([cipher.update(JSON.stringify(value), 'utf8'), cipher.final()])
      rows[key] = { expiresAt: this.now() + 24 * 60 * 60 * 1000,
        nonce: nonce.toString('base64'), ciphertext: ciphertext.toString('base64'), tag: cipher.getAuthTag().toString('base64') }
    })
  }
  async get(identity) {
    await this.queue
    const key = this.keyOf(identity), row = this.rows[key]
    if (!row || row.expiresAt <= this.now()) return null
    const decipher = createDecipheriv('aes-256-gcm', this.key, Buffer.from(row.nonce, 'base64'))
    decipher.setAAD(Buffer.from(key)); decipher.setAuthTag(Buffer.from(row.tag, 'base64'))
    return JSON.parse(Buffer.concat([decipher.update(Buffer.from(row.ciphertext, 'base64')), decipher.final()]).toString('utf8'))
  }
  remove(identity) { return this.mutate(rows => { delete rows[this.keyOf(identity)] }) }
}
