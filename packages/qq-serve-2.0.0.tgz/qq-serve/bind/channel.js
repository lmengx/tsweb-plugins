import { receiveCredentialLogin } from './credentials.js'
import { httpError } from './ledger.js'

// Independent business transport, deployed with QqBind.dll. No Host event bridge.
export class QqCredentialChannels {
  constructor(ctx, service, ready) {
    this.ctx = ctx
    this.service = service
    this.ready = ready
    this.connections = new Map()
    this.disposed = false
  }

  start() {
    const reconcile = async () => {
      try {
        await this.ready
        if (this.disposed) return
        const servers = await this.service.gameOps.enabledServers()
        if (this.disposed) return
        const ids = new Set(servers.map(s => s.id))
        for (const [id, connection] of this.connections) if (!ids.has(id)) {
          connection.controller.abort(); this.connections.delete(id)
        }
        await Promise.allSettled(servers.map(server => this.ensure(server)))
      } catch { /* next tick retries connection establishment only */ }
    }
    this.timer = setInterval(reconcile, 10000)
    this.timer.unref?.()
    void reconcile()
  }

  ensure(server) {
    if (this.disposed) return Promise.reject(new Error('QQ 凭据通道已关闭'))
    const hookBase = this.ctx.servers.connection?.backendBase || process.env.TSWEB_BACKEND_BASE ||
      `http://127.0.0.1:${this.ctx.webServer.port || 3000}`
    const secret = this.service.credentialSecretFor?.(server) || server.pushSecret
    const signature = JSON.stringify([server.host, server.port, server.token, secret, hookBase])
    const previous = this.connections.get(server.id)
    if (previous?.signature === signature) return previous.ready
    previous?.controller.abort()
    const connection = { signature, controller: new AbortController() }
    this.connections.set(server.id, connection)
    connection.ready = new Promise((resolve, reject) => { connection.resolve = resolve; connection.reject = reject })
    void this.run(server, hookBase, connection)
    return connection.ready
  }

  async run(server, hookBase, connection) {
    const { controller } = connection
    let deadline
    const touch = () => { clearTimeout(deadline); deadline = setTimeout(() => controller.abort(), 15000); deadline.unref?.() }
    const current = () => !this.disposed && this.connections.get(server.id) === connection && !controller.signal.aborted
    try {
      touch()
      const secret = this.service.credentialSecretFor?.(server) || server.pushSecret
      const result = await this.ctx.tshock.fetchFor(server, '/data/qq/connect', { serverId: server.id, secret, hookBase })
      if (!current()) throw new Error('QQ 凭据连接已被替换')
      const metadata = result.data
      if (result.status === 404) throw httpError(501, '游戏服端未安装 QqBind.dll', { serverHalfMissing: true, serverId: server.id })
      if (result.status === 401 || result.status === 403 || Number(metadata?.status) === 401 || Number(metadata?.status) === 403)
        throw httpError(502, '游戏服 token 权限不足：需要 data.rest.invsee 权限', { serverId: server.id })
      if (!result.ok || Number(metadata?.status) >= 400 || metadata?.protocol !== 2 ||
          !Number.isInteger(metadata.port) || metadata.port < 1 || metadata.port > 65535 ||
          !/^[a-f0-9]{64}$/i.test(metadata.key || '')) throw new Error('QqBind 凭据通道未就绪，请检查游戏服插件')
      const url = new URL(this.ctx.tshock.baseUrl(server))
      url.protocol = 'http:'; url.port = String(metadata.port); url.pathname = '/qq-bind/events'; url.search = ''; url.hash = ''
      const response = await fetch(url, { headers: { Authorization: `Bearer ${metadata.key}` }, redirect: 'error', signal: controller.signal })
      if (!response.ok || !response.headers.get('content-type')?.startsWith('text/event-stream')) throw new Error('QQ SSE 连接失败')
      const reader = response.body.getReader()
      const decoder = new TextDecoder()
      let buffer = '', connected = false
      try {
        while (current()) {
          const { value, done } = await reader.read()
          if (done) break
          buffer += decoder.decode(value, { stream: true }).replaceAll('\r', '')
          if (buffer.length > 65536) throw new Error('QQ SSE frame too large')
          let end
          while ((end = buffer.indexOf('\n\n')) >= 0) {
            const frame = buffer.slice(0, end); buffer = buffer.slice(end + 2)
            const lines = frame.split('\n')
            const event = lines.find(line => line.startsWith('event:'))?.slice(6).trim()
            const data = lines.filter(line => line.startsWith('data:')).map(line => line.slice(5).trimStart()).join('\n')
            if (!current()) break
            if (event === 'connected') {
              connected = true; touch(); connection.resolve()
              // Reconnect always restores the backend snapshot, without replaying offline UUIDs.
              void this.service._schedulePush().catch(() => {})
            } else if (event === 'ping') touch()
            else if (event === 'qq-credentials.uuid' && connected) {
              touch()
              let parsed; try { parsed = JSON.parse(data) } catch { continue }
              void receiveCredentialLogin(this.service, { serverId: server.id, data: parsed }).catch(() => {
                this.ctx.logger?.warn?.('[qq-bind] UUID 事件处理失败')
              })
            }
          }
        }
      } finally { await reader.cancel().catch(() => {}) }
      throw new Error('QQ SSE 已断开')
    } catch (error) {
      connection.reject(error)
    } finally {
      clearTimeout(deadline)
      controller.abort()
      if (this.connections.get(server.id) === connection) this.connections.delete(server.id)
    }
  }

  dispose() {
    this.disposed = true
    clearInterval(this.timer)
    for (const connection of this.connections.values()) connection.controller.abort()
    this.connections.clear()
  }
}
