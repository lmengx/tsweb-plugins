import { collect } from '../render-templates/data.js'
import { onlinePages } from '../online.js'
import { onebotHelp, helpText } from '../help.js'
import { renderHelp } from '../help-cache.js'
import { Service } from '@deepseek-ai/cordis'
import { randomInt } from 'node:crypto'
import { readFile, writeFile, mkdir } from 'node:fs/promises'
import path from 'node:path'
import { OneBotClient } from './client.js'
import { OneBotEvents } from './events.js'
import { handleVoteCommand } from './votes.js'

import accessContract from './access.js'

// 合并后本目录由 ../index.js 组合根以 applyOnebot(ctx, deps) 装配。
// name/inject 与无 deps 的单域装配仅为测试与旧调用保留。
export const name = 'onebot-bridge'
export const inject = ['webServer', 'auth', 'paths', 'qqBind', 'servers', 'tshock']
function domainDeps(ctx) {
  return {
    app: ctx.auth.access.policyApp(ctx.webServer.app, accessContract, ctx),
    dataDir: ctx.paths.dataOf('onebot-bridge'),
    serve: (() => { try { return ctx.get('qqServe') } catch { return null } })(),
  }
}

const defaults = () => ({ enabled: false, endpoint: '', accessToken: '', webhookToken: '', botQq: '', allowTransfer: true })
const transferAlphabet = '.-_|\\/'
const transferCodePattern = /^[.\-_|\\/]{20}$/
function transferCode() {
  // Six base-6 digits hold a compact seconds counter; 14 independent random
  // digits distinguish requests. Time is never used to match platform events.
  let stamp = Math.floor(Date.now() / 1000) % (6 ** 6), prefix = ''
  for (let i = 0; i < 6; i++) { prefix = transferAlphabet[stamp % 6] + prefix; stamp = Math.floor(stamp / 6) }
  return prefix + Array.from({ length: 14 }, () => transferAlphabet[randomInt(6)]).join('')
}
function normalize(patch, base = defaults()) {
  const out = { ...base }
  if (patch.enabled !== undefined) out.enabled = patch.enabled === true
  if (patch.allowTransfer !== undefined) out.allowTransfer = patch.allowTransfer !== false
  for (const key of ['endpoint', 'accessToken', 'webhookToken', 'botQq']) if (patch[key] !== undefined) out[key] = String(patch[key] || '').trim().slice(0, 512)
  return out
}

class OneBotBridge extends Service {
  constructor(ctx, configFile) {
    super(ctx, 'onebotBridge')
    this.configFile = configFile; this.config = defaults(); this.pending = new Map()
    this.seen = new Map(); this.queues = new Map(); this.mode = 'onebot'; this.disposed = false
    this.events = new OneBotEvents({ onEvent: event => this.handleEvent(event), onStatus: state => {
      if (state.connected !== this.connected) {
        this.connected = state.connected
        console.log(`[qq_serve] OneBot ${state.connected ? '已连接，QQ ' + state.qq : '未连接'}`)
        if (state.connected) void this.groups()?.refreshNumeric({ force: true })
      }
    } })
  }
  async load() {
    await mkdir(path.dirname(this.configFile), { recursive: true })
    let qqServe = null
    try { qqServe = this.ctx.get('qqServe') } catch {}
    const canonical = qqServe?.config?.onebot
    try {
      const stored = JSON.parse(await readFile(this.configFile, 'utf8'))
      this.config = normalize(canonical || stored)
    } catch (error) {
      if (error.code !== 'ENOENT') throw error
      this.config = normalize(canonical || {})
      await this.save()
    }
    if (qqServe?.config?.mode) this.config.enabled = ['onebot', 'hybrid'].includes(qqServe.config.mode)
  }
  async save() {
    await writeFile(this.configFile, JSON.stringify(this.config, null, 2) + '\n', { mode: 0o600 })
    // 合并后模式域是唯一配置源：本域保存后同步回 qqServe，避免两份配置互相覆盖。
    // 单域装配/测试里可能只有占位属主（没有 config/save），此时只落本域文件。
    let qqServe = null
    try { qqServe = this.ctx.get('qqServe') } catch {}
    if (qqServe?.config && typeof qqServe.save === 'function') {
      qqServe.config.onebot = { ...this.config }
      await qqServe.save()
    }
  }
  publicConfig() { return { ...this.config, accessToken: this.config.accessToken ? '***已设置***' : '', webhookToken: this.config.webhookToken ? '***已设置***' : '' } }
  setEnabled(enabled) { this.configure({ enabled: Boolean(enabled) }) }
  configure(value) {
    if (this.disposed) return
    this.config = normalize(value, this.config)
    this.mode = value.mode || this.mode
    if (!this.config.enabled || this.mode !== 'hybrid' || !this.config.allowTransfer) this.pending.clear()
    this.events.configure(this.config)
  }
  status() { return { enabled: this.config.enabled, configured: Boolean(this.config.endpoint), pendingTransfers: this.pending.size, ...this.events.state } }
  dispose() { this.disposed = true; this.events.stop(); this.pending.clear(); this.seen.clear() }
  client() { return new OneBotClient({ endpoint: this.config.endpoint, token: this.config.accessToken }) }
  groups() { try { return this.ctx.get('qqServe')?.groups || null } catch { return null } }
  groupAllowed(event) { return event?.message_type === 'group' && (!this.groups() || this.groups().allowsNumeric(event.group_id)) }
  groupId(groupOpenid) { return this.groups()?.groupOf(String(groupOpenid || '')) || '' }
  beginTransfer({ identity, groupOpenid }) {
    if (this.disposed || !this.config.enabled || this.mode !== 'hybrid' || !this.config.allowTransfer) throw Object.assign(new Error('OneBot 身份补全未启用。'), { status: 503, publicMessage: 'OneBot 身份补全未启用。' })
    for (const [key, value] of this.pending) if (value.expiresAt <= Date.now()) this.pending.delete(key)
    const key = `${identity.appId}:${identity.subject}`
    if (this.pending.get(key)?.completing) throw Object.assign(new Error('转移正在完成。'), { publicMessage: '绑定转移正在完成，请稍后查看结果。' })
    if (this.pending.size >= 100 && !this.pending.has(key)) throw Object.assign(new Error('待处理请求已满。'), { publicMessage: '请稍后再试。' })
    const groupId = this.groupId(groupOpenid)
    if (!groupId) throw Object.assign(new Error('官方群与 OneBot 群尚未自动关联。'), { status: 400, publicMessage: '该群正在等待双端消息自动关联，请稍后重试。' })
    if (!this.groups()?.allowsNumeric(groupId)) throw Object.assign(new Error('该群未启用。'), { status: 403, publicMessage: '管理员尚未启用该群。' })
    let code
    do { code = transferCode() } while ([...this.pending.values()].some(item => item.code === code))
    const expiresAt = Date.now() + 5 * 60_000
    this.pending.set(key, { key, identity, groupOpenid: String(groupOpenid), groupId, code, expiresAt })
    return { code, expiresAt }
  }
  async handleEvent(event) {
    if (this.disposed || !this.config.enabled) return { ok: true, ignored: true }
    const self = this.config.botQq || this.events.state.qq
    if (self && event?.self_id && String(event.self_id) !== String(self)) return { ok: true, ignored: true }
    this.groups()?.observeNumericMembership(event, self)
    if (event?.post_type !== 'message' || event.message_type !== 'group') return { ok: true, ignored: true }
    if (event.message_id == null) return { ok: true, ignored: true }
    if (event.message_type === 'group') this.groups()?.observeNumeric(event)
    const id = JSON.stringify([event.self_id || self, event.message_type, event.group_id || '', event.user_id, event.message_id])
    const time = Date.now()
    for (const [key, expires] of this.seen) if (expires <= time) this.seen.delete(key)
    if (this.seen.has(id)) return { ok: true, duplicate: true }
    if (this.seen.size >= 5000) this.seen.delete(this.seen.keys().next().value)
    this.seen.set(id, time + 5 * 60_000)
    const user = String(event.user_id || '')
    if (this.queues.size >= 100 && !this.queues.has(user)) return { ok: false, error: '正在处理其他消息，请稍后再试' }
    const generation = this.events.generation
    const queued = (this.queues.get(user) || Promise.resolve()).catch(() => {}).then(() => generation === this.events.generation ? this.processEvent(event) : { ok: true, ignored: true })
    this.queues.set(user, queued)
    try { return await queued } finally { if (this.queues.get(user) === queued) this.queues.delete(user) }
  }
  async processEvent(event) {
    if (this.disposed || !this.config.enabled) return { ok: true, ignored: true }
    if (!this.groupAllowed(event)) return { ok: true, ignored: true }
    const text = Array.isArray(event.message) ? event.message.filter(x => x.type === 'text').map(x => x.data?.text || '').join('') : String(event.raw_message || event.message || '').replace(/\[CQ:at,qq=\d+\]/g, '')
    const match = /^\s*\/?绑定转移\s+([.\-_|\\/]{20})\s*$/.exec(text)
    if (match && event.message_type === 'group') return this.handleTransferEvent(event, match[1])
    if (this.mode === 'hybrid') return { ok: true, ignored: true }
    const command = text.trim().replace(/^\/?/, '').split(/\s+/)
    if (!command[0]) return { ok: true, ignored: true }
    return this.handleCommand(event, command[0].toLowerCase(), command.slice(1))
  }
  async handleTransferEvent(event, rawCode) {
    if (!this.groupAllowed(event)) return { ok: true, ignored: true }
    if (!this.config.enabled || this.mode !== 'hybrid' || !this.config.allowTransfer || event.message_type !== 'group' || !transferCodePattern.test(rawCode)) return { ok: true, ignored: true }
    const groupId = String(event.group_id || ''), code = rawCode
    const item = [...this.pending.values()].find(x => x.groupId === groupId && x.code === code && x.expiresAt > Date.now())
    if (!item || item.claiming || item.claimedQq) return { ok: true, ignored: true }
    const userId = String(event.user_id || '')
    if (!/^\d{5,15}$/.test(userId)) return { ok: true, ignored: true }
    item.claiming = true
    try {
      const member = await this.client().getGroupMemberInfo(groupId, userId)
      if (String(member?.user_id || '') !== userId) throw new Error('OneBot 返回的 QQ 身份不一致')
      if (!this.activeTransfer(item)) return { ok: true, ignored: true }
      item.claimedQq = userId; item.nickname = member?.card || member?.nickname || ''
      return await this.completeTransfer(item)
    } finally { item.claiming = false }
  }
  activeTransfer(item) {
    return !this.disposed && this.config.enabled && this.mode === 'hybrid' && this.config.allowTransfer &&
      this.groups()?.allowsNumeric(item.groupId) === true &&
      this.pending.get(item.key) === item && item.expiresAt > Date.now() && this.groupId(item.groupOpenid) === item.groupId
  }
  async observeOfficialTransfer({ identity, code, groupOpenid, context }) {
    const key = `${identity.appId}:${identity.subject}`, item = this.pending.get(key)
    if (!item || !this.activeTransfer(item) || item.code !== code || item.groupOpenid !== String(groupOpenid || ''))
      throw Object.assign(new Error('绑定转移编码无效或已过期。'), { publicMessage: '绑定转移编码无效或已过期，请重新打开“绑定转移”菜单。' })
    if (!item.officialContext) item.officialContext = context
    return this.completeTransfer(item)
  }
  async completeTransfer(item) {
    if (!this.activeTransfer(item) || item.completing) return { ok: true, ignored: true }
    if (!item.officialContext || !item.claimedQq) return { ok: true, awaitingPeer: true }
    item.completing = true
    let reply, completed = false
    try {
      const qqBind = this.ctx.get('qqBind')
      await qqBind.enrichOfficialIdentity({ identity: item.identity, qq: item.claimedQq, nickname: item.nickname })
      completed = true
      reply = { text: `绑定转移成功\nQQ：${item.claimedQq}\n已关联原角色与官方 OpenID，原有凭据保持不变。`, buttons: [] }
    } catch (error) {
      reply = { text: `绑定转移未完成\n${error.publicMessage || '请管理员检查绑定记录，重新打开绑定转移菜单后重试。'}`, buttons: [] }
    } finally {
      if (this.pending.get(item.key) === item) this.pending.delete(item.key)
    }
    if (!this.disposed && !item.officialContext.signal?.aborted) await item.officialContext.reply(reply).catch(() => {})
    return { ok: true, completed }
  }
  async handleCommand(event, command, args) {
    if (!this.groupAllowed(event)) return { ok: true, ignored: true }
    const generation = this.events.generation
    const qq = String(event.user_id || '')
    if (!/^\d{5,15}$/.test(qq)) return { ok: true, ignored: true }
    const target = { group_id: event.group_id }
    const send = text => {
      if (this.disposed || !this.config.enabled || this.mode === 'hybrid' || generation !== this.events.generation || !this.groupAllowed(event)) return
      return this.client().sendMessage(target, text)
    }
    const render = async kind => {
      let renderer
      try { renderer = this.ctx.get('qqRenderer') } catch {}
      if (!renderer?.config?.enabled) return null
      try { return await renderer.render(kind) }
      catch { this.ctx.logger?.warn?.('[qq-serve] 图片渲染失败，已回退文字'); return null }
    }
    if (['菜单', 'menu', '帮助', '测试', 'ping'].includes(command)) return { ok: true, ignored: true }
    const bind = this.ctx.qqBind
    if (!bind) return send('QQ 绑定服务尚未启用。')
    await bind.ready
    if (!this.groupAllowed(event) || generation !== this.events.generation) return { ok: true, ignored: true }
    const saveNickname = async () => {
      const nickname = String(event.sender?.nickname || '').trim()
      if (nickname && bind.nicknames?.saveNicknames) await bind.nicknames.saveNicknames([{ qq, nickname }], { source: 'onebot' }).catch(() => {})
    }
    try {
      if (await handleVoteCommand(bind, event, command, args, send)) return { ok: true }
      if (command === 'help') {
        const document = onebotHelp({ mode: this.mode, scene: event.message_type === 'group' ? 'group' : 'private', bind, servers: this.ctx.servers })
        let result
        try { result = await renderHelp(this.ctx.get('qqRenderer'), document) } catch { /* Complete text fallback uses the same command document. */ }
        if (result) return send(result.images.map(image => ({ type: 'image', data: { file: 'base64://' + image.toString('base64') } })))
        return send(helpText(document))
      }
      if (['服务器', '服务器列表', 'servers'].includes(command)) {
        const result = await render('servers')
        if (result) { for (const image of result.images) await send([{ type: 'image', data: { file: 'base64://' + image.toString('base64') } }]); return }
        const rows = (await this.ctx.servers.list()).filter(row => row.enabled !== false)
        return send(rows.length ? rows.map((row, i) => `${i + 1}. ${row.name || '未命名服务器'}（${row.connected ? '已连接' : '未连接'}）`).join('\n') : '暂无启用的服务器。')
      }
      if (['在线', '在线玩家', 'online', 'players'].includes(command)) {
        const rendered = await render('players')
        if (rendered) { for (const image of rendered.images) await send([{ type: 'image', data: { file: 'base64://' + image.toString('base64') } }]); return }
        const data = await collect({ servers: this.ctx.servers, tshock: this.ctx.tshock })
        for (const page of onlinePages(data)) await send(page.join('\n'))
        return
      }
      if (['注册', 'register'].includes(command)) {
        return send('OneBot 模式不提供账号注册或私信发密，请通过官方机器人注册，或联系管理员创建账号后在群内绑定。')
      }
      if (['绑定', 'bind'].includes(command)) {
        const result = await bind.bind({ qq, player: args.join(' '), source: 'onebot' })
        await saveNickname()
        return send(`绑定成功\n角色：${result.username}`)
      }
      if (['我的信息', 'me'].includes(command)) {
        const record = bind.ledger.getByQq(qq)
        if (!record) return send('你还没有绑定角色，请先创建游戏账号，再在群内发送“绑定 角色名”。')
        let result
        try { result = await bind.playerInfo(qq) } catch {}
        return send(`角色：${record.username}\nQQ：${record.qq}\n${result?.server ? '服务器：' + result.server : '绑定记录正常，游戏服资料暂不可用。'}`)
      }
      if (['绑定转移', 'transfer'].includes(command) && event.message_type === 'group') {
        const groupOpenid = this.groups()?.snapshot().mappings.find(row => row.confirmed && row.groupId === String(event.group_id))?.groupOpenid
        if (!groupOpenid) return send('该群尚未自动关联官方机器人。')
        return send('请打开官方机器人的“绑定转移”菜单，点击“一键转移”。')
      }
      return { ok: true, ignored: true }
    } catch (error) {
      let message = String(error.publicMessage || error.message || '操作失败。')
      for (const token of [this.config.accessToken, this.config.webhookToken]) if (token) message = message.split(token).join('[已隐藏]')
      return send(message)
    }
  }
}

export async function applyOnebot(ctx, deps = domainDeps(ctx)) {
  const service = new OneBotBridge(ctx, path.join(deps.dataDir, 'onebot-config.json'))
  ctx.effect(() => () => service.dispose(), 'onebot-bridge:dispose')
  ctx.onebotBridge = service
  await service.load()
  // 组合根保证 qqServe 已就位；直接注册适配器，不再靠 inject 等待跨插件服务。
  // 单域装配（测试/被单独挂载）没有 settings 属主时允许缺省：传输件仍可独立跑。
  if (deps.serve) ctx.effect(() => deps.serve.registerAdapter('onebot', service), 'onebot-bridge:mode')
  service.configure(service.config)
  const unregisterCapabilities = ctx.qqBind.registerAdapter({ name: 'onebot', description: 'OneBot 原生事件接入', capabilities: ['vote.list', 'vote.cast', 'vote.propose'] })
  ctx.effect(() => unregisterCapabilities, 'onebot-bridge:capabilities')
  const app = deps.app
  const webhook = ctx.webServer.app
  const route = handler => async (req, res) => { try { res.json(await handler(req)) } catch (error) { res.status(error.status || 500).json({ error: error.message }) } }
  app.get('/api/onebot-bridge/config', route(() => service.publicConfig()))
  app.post('/api/onebot-bridge/config', route(async req => { const body = req.body || {}; service.config = normalize({ ...body, accessToken: body.accessToken === '***已设置***' ? service.config.accessToken : body.accessToken, webhookToken: body.webhookToken === '***已设置***' ? service.config.webhookToken : body.webhookToken }, service.config); await service.save(); service.configure(service.config); return service.publicConfig() }))
  app.post('/api/onebot-bridge/test', route(() => service.client().getLoginInfo()))
  const webhookHandler = Object.assign(async (req, res) => {
    if (!service.config.webhookToken) return res.status(403).json({ error: 'Webhook 未启用，请使用原生事件连接或配置 Webhook Token' })
    if (req.headers['x-onebot-token'] !== service.config.webhookToken) return res.status(401).json({ error: 'unauthorized' })
    res.json(await service.handleEvent(req.body).catch(() => ({ ok: false, error: '消息处理失败' })))
  }, { [Symbol.for('tsweb.access.machine')]: 'onebot-webhook' })
  webhook.post('/api/onebot-bridge/webhook', webhookHandler)
  // Cordis apply accepts a disposer or nothing; returning a service object
  // causes Invalid effect and removes the routes registered above.
}

/** 单域兼容别名：旧测试用 apply(ctx) 直接装配本域。 */
export const apply = applyOnebot
