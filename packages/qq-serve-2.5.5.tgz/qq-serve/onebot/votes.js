import { presentCapabilityResult } from './presentation.js'
// OneBot 已完成连接鉴权，直接调用业务能力；不经过旧 HTTP 接口或 bot token。
export async function handleVoteCommand(bind, event, command, args, send) {
  const commands = { 投票: 'list', votes: 'list', 投: 'cast', 参与投票: 'cast', vote: 'cast', 提案: 'propose', 投票提案: 'propose', propose: 'propose' }
  let action = Object.hasOwn(commands, command) ? commands[command] : null
  if (!action) return false
  let capability = bind.capabilities?.get(`vote.${action}`)
  if (!capability) {
    await send('投票功能未启用，请管理员安装或启用投票插件。')
    return true
  }
  const value = args.join(' ').trim()
  let result = await bind.invoke(`vote.${action}`, {
    principal: { kind: 'bot', adapter: 'onebot', qq: String(event.user_id), groupId: event.group_id ? String(event.group_id) : '' },
    params: action === 'list' ? { name: value, resolveCast: command === '投票' && !!value } : action === 'cast' ? { option: value } : { text: value },
  })
  if (action === 'list' && result.mode === 'cast-target') {
    if (bind.capabilities.get('vote.list') !== capability) return true
    action = 'cast'
    capability = bind.capabilities.get('vote.cast')
    if (!capability) { await send('参与投票功能未启用。'); return true }
    result = await bind.invoke('vote.cast', {
      principal: { kind: 'bot', adapter: 'onebot', qq: String(event.user_id), groupId: event.group_id ? String(event.group_id) : '' },
      params: { option: result.target },
    })
  }
  const visual = await presentCapabilityResult(capability, result)
  // A plugin update may have removed or replaced the business handler during rendering.
  if (bind.capabilities.get(`vote.${action}`) !== capability) return true
  if (visual) {
    await send([
      ...visual.images.map(image => ({ type: 'image', data: { file: 'base64://' + image.toString('base64') } })),
    ])
    return true
  }
  const rounds = result.round ? [result.round] : result.rounds || []
  const overview = !result.round && rounds.length > 1
  const lines = []
  if (action === 'cast') lines.push(`投票成功，本次分值 ${result.weight}，剩余可投 ${result.round.my.votesLeft} 项。`)
  if (action === 'propose') lines.push(result.existing ? '该提案已存在。' : '提案已提交。')
  if (!rounds.length) lines.push('当前没有可查看的投票。')
  if (overview) lines.push(`共 ${rounds.length} 轮投票，以下显示前 ${Math.min(rounds.length, 20)} 轮；发送「投票 完整轮次名」查看选项。`)
  for (const round of overview ? rounds.slice(0, 20) : rounds) {
    lines.push(`【${round.title}】（${round.id}）${round.status === 'open' ? '进行中' : '已结束'}`)
    if (overview) { lines.push(`${round.options.length} 个选项`); continue }
    if (round.description) lines.push(round.description)
    for (const [i, option] of round.options.entries()) lines.push(`${i + 1}. ${option.text} · ${option.votes} 票 / ${option.score} 分`)
  }
  lines.push('查看：投票 [投票轮次名]')
  const open = rounds.filter(round => round.status === 'open' && !round.archived), personal = result.round?.my
  if (open.length) {
    if (!personal || personal.votesLeft > 0) lines.push('参与：参与投票 选项\n多个投票同时进行时：投票 投票轮次名 选项')
    else lines.push('本轮投票额度已用完，可继续查看结果。')
    if (open.some(round => round.allowProposals)) {
      if (!personal || personal.proposalsLeft > 0) lines.push('提案：投票提案 内容\n指定提案轮次：投票提案 投票轮次名 内容')
      else lines.push('本轮提案额度已用完。')
    }
  } else if (rounds.length) lines.push('投票已结束或归档，仅可查看结果。')
  // 按段拆分，避免轮次多时超过 OneBot 消息长度；结果只含业务公开字段。
  let chunk = ''
  for (const line of lines) {
    if (chunk && chunk.length + line.length > 1800) { await send(chunk); chunk = '' }
    chunk += (chunk ? '\n' : '') + line
  }
  if (chunk) await send(chunk)
  return true
}
