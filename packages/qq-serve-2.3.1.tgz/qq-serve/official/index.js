import { testConnection } from '../connection.js'
import { Service } from '@deepseek-ai/cordis'
const revision = new URL(import.meta.url).search
const { BotManager } = await import(`./service.js${revision}`)
const { ui } = await import(`./messages.js${revision}`)
const { registerServerCommands } = await import(`./server-commands.js${revision}`)
const { registerAccountCommands } = await import(`./account-commands.js${revision}`)
const { renderVisualReply } = await import(`./presentation.js${revision}`)
const { default: accessContract } = await import(`./access.js${revision}`)

// 合并后本目录由 ../index.js 组合根以 applyOfficial(ctx, deps) 装配。
// name/inject 与无 deps 的单域装配仅为测试与旧调用保留。
export const name = 'qq-official'
export const inject = ['webServer', 'auth', 'paths']
function domainDeps(ctx) {
  return {
    app: ctx.auth.access.policyApp(ctx.webServer.app, accessContract, ctx),
    dataDir: ctx.paths.dataOf('qq-official'),
    serve: (() => { try { return ctx.get('qqServe') } catch { return null } })(),
  }
}

class OfficialService extends Service {
  constructor(ctx, manager) { super(ctx, 'qqOfficial'); this.manager = manager; this.ui = ui }
  registerCommand(command) { return this.manager.registerCommand(command) }
  registerAction(action) { return this.manager.registerAction(action) }
  status() { return this.manager.status() }
}

export async function applyOfficial(ctx, deps = domainDeps(ctx)) {
  const manager = new BotManager({ dataDir: deps.dataDir, renderReply: (value, options) => {
    let renderer
    try { renderer = ctx.get('qqRenderer') } catch {}
    return renderVisualReply(value, { ...options, renderer, onError: () => manager.log('render', '图片暂不可用，已保留完整文字与操作按钮') })
  }, createBot: async config => {
    const runtime = await import(`./runtime/sdk.mjs${revision}`)
    return runtime.createBot(config)
  } })
  // Cordis 4 disposes registered effects; it does not emit a "dispose" event.
  // An event listener here leaked the manager/socket on every hot reload.
  ctx.effect(() => () => manager.dispose(), 'qq-official:manager')
  await manager.load()
  // qq-serve 是官方凭据的统一配置源；旧 qq-official/config.json 只作为兼容回退。
  let qqServe = null
  try { qqServe = ctx.get('qqServe') } catch {}
  const canonical = qqServe?.config?.official
  if (canonical?.appId || canonical?.appSecret) {
    manager.config = manager.validate({ appId: canonical.appId, appSecret: canonical.appSecret }, manager.config)
    manager.state = manager.config.appId && manager.config.appSecret ? 'stopped' : 'unconfigured'
  } else if (qqServe && manager.config.appId && manager.config.appSecret) {
    /**
     * 兼容回退不会自己活下来：canonical 为空时，任何一次 applyMode 都以 canonical 为准。
     * 所以这里把旧文件里的凭据回写进 canonical，让"统一配置源"和实际生效凭据一致，
     * 否则旧部署升级后每次启动都只有内存里有凭据、磁盘上的 canonical 永远是空。
     */
    qqServe.config = { ...qqServe.config, official: { appId: manager.config.appId, appSecret: manager.config.appSecret } }
    await qqServe.save()
  }
  if (manager.disposed) throw new Error('QQ 官方机器人插件已停用')
  ctx.effect(() => registerServerCommands(manager, { getService: name => {
    try { return ctx.get(name) } catch { return null }
  } }), 'qq-official:server-commands')
  const disposeAccounts = await registerAccountCommands(manager, { getService: name => {
    try { return ctx.get(name) } catch { return null }
  } })
  ctx.effect(() => disposeAccounts, 'qq-official:account-commands')
  // 消息身份读取与跨通道对应（dsf41 交付）：注册「获取qq号」等命令
  const { registerIdentityCommand } = await import(`../bind/identity/official-command.js${revision}`)
  // 官方端指令开关 + 协同开关（唯一归属：本域）
  const { IdentitySettingsStore } = await import(`./identity-settings.js${revision}`)
  const identitySettings = new IdentitySettingsStore({ dataDir: deps.dataDir })
  await identitySettings.load()
  const disposeIdentityCommand = await registerIdentityCommand(manager, {
    dataDir: deps.dataDir,
    getService: name => {
      try { return ctx.get(name) } catch { return null }
    },
    getContext: () => ctx,
    identitySettings,
    revision,
  })
  ctx.effect(() => disposeIdentityCommand, 'qq-official:identity-command')
  ctx.qqOfficial = new OfficialService(ctx, manager)
  // 组合根保证 qqServe 已就位；直接注册适配器，不再靠 inject 等待跨插件服务。
  if (deps.serve) deps.serve.registerAdapter('official', manager)
  const app = deps.app
  const route = handler => async (req, res) => {
    try { res.json(await handler(req)) }
    catch (error) { res.status(error.status || 500).json({ error: manager.safeError(error) }) }
  }
  app.get('/api/qq-official/config', route(() => manager.publicConfig()))
  app.post('/api/qq-official/test', route(req => {
    const input = req.body || {}
    const appId = String(input.appId ?? manager.config.appId).trim()
    // A changed identity must never inherit the previous application's saved secret.
    const appSecret = input.appSecret === undefined && appId === manager.config.appId ? manager.config.appSecret : String(input.appSecret ?? '').trim()
    return testConnection({ official: { appId, appSecret } }, 'official')
  }))
  /**
   * 合并后官方凭据只有一个权威来源：模式域的 config.json（qqServe）。
   *
   * 旧结构下 qq-official 的 config.json 与 qq-serve 的 canonical 配置并存，靠"canonical 优先"
   * 兜底；两份文件在同一插件里会互相清空（实测：从本端点保存的凭据在重启用后被空 canonical 抹掉）。
   * 因此本端点保存后同步写回 qqServe 的配置，保证任何一处保存都被另一处看到。
   */
  const syncCanonical = async () => {
    const serve = ctx.qqServe
    if (!serve) return
    const { appId, appSecret } = manager.config
    if (serve.config.official?.appId === appId && serve.config.official?.appSecret === appSecret) return
    serve.config = { ...serve.config, official: { appId, appSecret } }
    await serve.save()
  }
  app.post('/api/qq-official/config', route(async req => {
    const saved = await manager.saveConfig(req.body)
    await syncCanonical()
    return saved
  }))
  app.get('/api/qq-official/status', route(() => manager.status()))
  app.get('/api/qq-official/logs', route(() => ({ rows: manager.logs() })))
  // 指令开关 + 协同开关（官方端唯一归属）
  app.get('/api/qq-official/identity', route(() => ({ ...identitySettings.snapshot(), groups: identitySettings.groupsProvider?.() || [] })))
  app.post('/api/qq-official/identity', route(req => identitySettings.save(req.body)))
  app.post('/api/qq-official/start', route(() => manager.start()))
  app.post('/api/qq-official/stop', route(() => manager.stop()))
  // Canonical mode owns startup. Legacy autoconnect only applies without qq-serve.
  let canonicalService
  try { canonicalService = ctx.get('qqServe') } catch {}
  if (!canonicalService && manager.publicConfig().autoConnect) await manager.start()
}

/** 单域兼容别名：旧测试用 apply(ctx) 直接装配本域。 */
export const apply = applyOfficial
