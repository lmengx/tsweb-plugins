import accessContract from './access.js'
/**
 * 状态面板：经 REST 直接读取、编辑和保存游戏服配置。
 * 配置以游戏服为准，宿主不保存配置副本，也不定时覆盖游戏服。
 * 全服在线数继续由 online-stats 聚合并独立更新，不写入配置。
 */
const moduleRevision = new URL(import.meta.url).search
const { ACTIONS, AuditLog } = await import(`./audit.js${moduleRevision}`)
const {
  MAX_ROWS_PER_PANEL, PUSH_DEFAULTS, changedKeys, configWarnings,
  defaultConfig, defaultPanelRows, httpError, normalizeConfig, toLegacyPayload,
  validateConfig, LOG_LEVELS, MAX_SPACER_WIDTH, PLACEHOLDER_TOKENS,
} = await import(`./config.js${moduleRevision}`)
const { DLL_NAME, REST_PERMISSION, SERVER_HALF_PREFIX, createGameOps, optionalService } =
  await import(`./gameOps.js${moduleRevision}`)

export const name = 'status-panel'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths']
const UNKNOWN_ONLINE = -1

export class StatusPanelService {
  constructor({ ctx, auditFile, push }) {
    this.ctx = ctx
    this.auditFile = auditFile
    this.push = { ...PUSH_DEFAULTS, ...(push || {}) }
    this.gameOps = createGameOps({ ctx })
    this.audit = new AuditLog({ file: auditFile })
    this.onlineStatus = new Map()
    this.online = {
      total: UNKNOWN_ONLINE, available: false, reason: '尚未读取', fetchedAt: '',
      source: '', servers: [], pushedTotal: null,
    }
    this._editQueue = Promise.resolve()
    this._retryTimer = null
    this._retryDelay = this.push.retryIntervalMs
    this._onlineDebounceTimer = null
    this._onlineReconcileTimer = null
    this._onlineUnsubscribers = []
    this._disposed = false
  }

  async init() {
    this.startOnlineReconcile()
    this.refreshOnline({ reason: '宿主启动初始化' }).catch(err => {
      console.error('[status-panel] 初始化全服在线数失败：' + err.message)
    })
  }

  dispose() {
    if (this._disposePromise) return this._disposePromise
    this._disposed = true
    this._clearRetry()
    clearTimeout(this._onlineDebounceTimer)
    clearInterval(this._onlineReconcileTimer)
    this._onlineDebounceTimer = this._onlineReconcileTimer = null
    for (const off of this._onlineUnsubscribers) {
      try { off() } catch { /* 继续清理其他订阅 */ }
    }
    this._onlineUnsubscribers = []
    this._disposePromise = this._editQueue
    return this._disposePromise
  }

  _assertActive() {
    if (this._disposed) throw httpError(503, '状态面板正在热重载，请稍后重试')
  }

  _queueEdit(work) {
    this._assertActive()
    const pending = this._editQueue.then(() => {
      this._assertActive()
      return work()
    })
    this._editQueue = pending.catch(() => {})
    return pending
  }

  async readConfig(serverId) {
    this._assertActive()
    const server = await this.resolveServer(serverId)
    if (!server.raw) throw httpError(404, '服务器不存在：' + server.id)
    const fetched = await this.gameOps.fetchConfig(server.raw)
    this._assertActive()
    const config = normalizeConfig(fetched.config)
    return {
      ok: true, serverId: server.id, serverName: server.name, config,
      saveError: fetched.saveError,
      warnings: configWarnings(config),
      defaults: {
        config: defaultConfig(), rows: defaultPanelRows(),
        placeholders: PLACEHOLDER_TOKENS, logLevels: LOG_LEVELS,
      },
    }
  }

  async setConfig(serverId, rawConfig, { actor = 'admin' } = {}) {
    validateConfig(rawConfig)
    const snapshot = JSON.parse(JSON.stringify(rawConfig))
    return this._queueEdit(() => this._setConfig(serverId, snapshot, { actor, audit: true }))
  }

  async _setConfig(serverId, rawConfig, { actor, audit }) {
    this._assertActive()
    validateConfig(rawConfig)
    const next = normalizeConfig(rawConfig)
    const before = await this.readConfig(serverId)
    this._assertActive()
    const server = await this.resolveServer(before.serverId)
    if (!server.raw) throw httpError(404, '服务器不存在：' + server.id)
    await this.gameOps.saveConfig(server.raw, toLegacyPayload(next))
    this._assertActive()
    const changed = changedKeys(before.config, next)
    if (audit) await this.audit.append(ACTIONS.configSet, {
      actor, serverId: server.id, changed, enabled: next.enabled,
      spacerWidth: next.spacerWidth, logLevel: next.logLevel,
      panels: Object.keys(next.panels), panelSpacers: next.panelSpacers,
    })
    return { ok: true, serverId: server.id, config: next, warnings: configWarnings(next), changed }
  }

  /** 订阅 online-stats 的采集事件（软依赖：没装就只记一条日志） */
  subscribeOnlineStats() {
    const svc = optionalService(this.ctx, 'onlineStats')
    if (!svc || typeof svc.on !== 'function') {
      console.log('[status-panel] online-stats 未安装/未启用：全服在线数无法取得，{AllOnlineCount} 将显示为 —')
      return false
    }

    try {
      const offChange = svc.on('change', () => this.scheduleOnlinePush('在线数变化'))
      if (typeof offChange === 'function') this._onlineUnsubscribers.push(offChange)
      const offTick = svc.on('tick', () => this.onOnlineTick())
      if (typeof offTick === 'function') this._onlineUnsubscribers.push(offTick)
      return true
    } catch (err) {
      // 事件订阅不可用时退化为"只靠周期对账"，如实记录，不假装成功
      console.error(`[status-panel] 订阅 online-stats 事件失败（全服在线数改为仅靠周期对账刷新）：${err.message}`)
      return false
    }
  }

  /** online-stats 每轮采样完成：在线数变了就立即推（没变不动，避免每 60s 白推一遍） */
  onOnlineTick() {
    if (this._disposed) return
    if (this.push.onlinePushOnTick === false) return
    this._readOnline()
      .then((snap) => {
        if (!snap.available) return
        if (this.online.pushedTotal === snap.total) return
        return this.pushOnline({ reason: '采集节拍发现在线数变化', snapshot: snap })
      })
      .catch((err) => {
        console.error(`[status-panel] 采集节拍下发全服在线数失败：${err.message}`)
      })
  }

  /** 在线数变化 → 去抖后下发（旧版后端是同样的 300ms 去抖思路） */
  scheduleOnlinePush(reason) {
    if (this._disposed) return
    const ms = Number(this.push.onlineDebounceMs)
    if (!(ms > 0)) {
      this.refreshOnline({ reason }).catch((err) => {
        console.error(`[status-panel] 下发全服在线数失败：${err.message}`)
      })
      return
    }
    if (this._onlineDebounceTimer) clearTimeout(this._onlineDebounceTimer)
    this._onlineDebounceTimer = setTimeout(() => {
      this._onlineDebounceTimer = null
      this.refreshOnline({ reason }).catch((err) => {
        console.error(`[status-panel] 下发全服在线数失败：${err.message}`)
      })
    }, ms)
    this._onlineDebounceTimer.unref?.()
  }

  /**
   * 局部写入（终端/脚本用）：`{ 路径: 值 }`，路径用点号分隔。
   * 支持的路径：enabled / spacerWidth / logLevel / panels / panelSpacers /
   *             panels.<面板名> / panelSpacers.<面板名>
   * 限制：面板名里带点号时无法用路径表达（请改传整份 config）。
   */
  async applyUpdates(serverId, updates, { actor = 'admin' } = {}) {
    if (!updates || typeof updates !== 'object' || Array.isArray(updates)) {
      throw httpError(400, '缺少参数: updates（应为 { 配置路径: 值 } 对象）')
    }
    const snapshot = JSON.parse(JSON.stringify(updates))
    return this._queueEdit(() => this._applyUpdates(serverId, snapshot, { actor }))
  }

  async _applyUpdates(serverId, updates, { actor }) {
    const keys = Object.keys(updates)
    if (keys.length === 0) throw httpError(400, 'updates 为空，没有可写入的配置项')

    const { config: draft } = await this.readConfig(serverId)
    const appliedKeys = []
    for (const key of keys) {
      const parts = String(key).split('.')
      const root = parts[0]
      if (!['enabled', 'spacerWidth', 'logLevel', 'panels', 'panelSpacers'].includes(root)) {
        throw httpError(400, `不可写的配置项：${key}（可写项：enabled/spacerWidth/logLevel/panels/panelSpacers，`
          + '以及 panels.<面板名> / panelSpacers.<面板名>）')
      }
      if (parts.length === 1) {
        draft[root] = updates[key]
        appliedKeys.push(key)
        continue
      }
      if (parts.length !== 2) {
        throw httpError(400, `配置路径最多两级：${key}`)
      }
      const name = parts[1]
      if (root === 'panels') {
        if (!draft.panels || typeof draft.panels !== 'object') draft.panels = {}
        draft.panels[name] = updates[key]
      } else if (root === 'panelSpacers') {
        if (!draft.panelSpacers || typeof draft.panelSpacers !== 'object') draft.panelSpacers = {}
        if (updates[key] === null) delete draft.panelSpacers[name]
        else draft.panelSpacers[name] = updates[key]
      } else {
        // enabled/spacerWidth/logLevel 不接受两级路径
        throw httpError(400, `配置项 ${root} 不能带子路径：${key}`)
      }
      appliedKeys.push(key)
    }

    const result = await this._setConfig(serverId, draft, { actor, audit: true })
    return { ...result, keys: appliedKeys }
  }

  async resolveServer(serverId) {
    const list = await this.ctx.servers.list()
    const id = serverId === undefined || serverId === null || serverId === '' ? null : String(serverId)
    if (id) {
      const hit = list.find((s) => String(s.id) === id)
      if (!hit) throw httpError(404, `服务器不存在：${id}`, { serverId: id })
      return { id: String(hit.id), name: hit.name, enabled: hit.enabled !== false, raw: this.ctx.servers.getRaw(hit.id) || null }
    }
    const first = list.find((s) => s.enabled !== false) || list[0]
    if (!first) throw httpError(404, '还没有登记任何服务器：请先在「服务器管理」里添加一台')
    return { id: String(first.id), name: first.name, enabled: first.enabled !== false, raw: this.ctx.servers.getRaw(first.id) || null }
  }

  static serverIdFromRequest(req) {
    const header = req && req.headers ? req.headers['x-server-id'] : undefined
    if (header) return String(header)
    if (req && req.query && req.query.serverId) return String(req.query.serverId)
    if (req && req.body && req.body.serverId) return String(req.body.serverId)
    return null
  }

  async _readOnline() {
    const svc = optionalService(this.ctx, 'onlineStats')
    const fetchedAt = new Date().toISOString()
    if (!svc || typeof svc.getCurrent !== 'function') {
      return {
        total: UNKNOWN_ONLINE,
        available: false,
        reason: 'online-stats 插件未安装/未启用：无法取得全服在线数（{AllOnlineCount} 会显示为 —）',
        fetchedAt,
        source: '',
        servers: [],
      }
    }

    try {
      const res = await svc.getCurrent()
      const servers = res && Array.isArray(res.servers) ? res.servers : []
      let total = Number(res && res.total)
      if (!Number.isFinite(total)) {
        // 退化路径：自己把各服 playercount 加起来（online-stats 未给 total 时）
        const sum = servers.reduce((acc, s) => acc + (Number.isFinite(Number(s.playercount)) ? Number(s.playercount) : 0), 0)
        total = servers.length > 0 ? sum : NaN
      }
      if (!Number.isFinite(total) || total < 0) {
        return {
          total: UNKNOWN_ONLINE,
          available: false,
          reason: 'online-stats 返回的在线总数不可用（total 既不是有效数字，也无法由各服 playercount 求和得到）',
          fetchedAt,
          source: 'ctx.onlineStats.getCurrent()',
          servers,
        }
      }
      return {
        total: Math.floor(total),
        available: true,
        reason: '',
        fetchedAt: res && res.fetchedAt ? String(res.fetchedAt) : fetchedAt,
        source: 'ctx.onlineStats.getCurrent()',
        servers,
      }
    } catch (err) {
      return {
        total: UNKNOWN_ONLINE,
        available: false,
        reason: `读取全服在线数失败：${err.message}`,
        fetchedAt,
        source: 'ctx.onlineStats.getCurrent()',
        servers: [],
      }
    }
  }

  /**
   * 读一次全服在线数并下发给**所有启用服**（每台服拿到的是同一个数字）。
   * snapshot 参数用于"调用方已经读过一次"的场景（例如采集节拍里先读后判），避免重复读。
   */
  async refreshOnline({ reason = '', snapshot = null } = {}) {
    const servers = await this.gameOps.enabledServers()
    const snap = snapshot || (await this._readOnline())
    this.online = { ...this.online, ...snap, pushedTotal: this.online.pushedTotal }
    return this.pushOnline({ reason, snapshot: snap, servers })
  }

  /** 把（已经读好的）全服在线数逐服下发 */
  async pushOnline({ reason = '', snapshot = null, servers = null } = {}) {
    const targets = servers || (await this.gameOps.enabledServers())
    const snap = snapshot || (await this._readOnline())
    const at = new Date().toISOString()
    const results = []

    if (!snap.available) {
      // 读不到全服在线数：**不下发**（服端保持它当前的值，而不是被写成 0/—），
      // 但把"没下发 + 原因"记录下来，界面上能直接看到为什么 {AllOnlineCount} 是 —
      this.online = { ...this.online, ...snap, pushedTotal: this.online.pushedTotal }
      for (const server of targets) {
        const entry = {
          id: String(server.id), name: server.name, ok: false, skipped: true,
          total: UNKNOWN_ONLINE, at, error: snap.reason,
        }
        this.onlineStatus.set(String(server.id), entry)
        results.push(entry)
      }
      return { ok: false, reason, available: false, total: UNKNOWN_ONLINE, error: snap.reason, serverCount: results.length, servers: results }
    }

    for (const server of targets) {
      const id = String(server.id)
      try {
        const data = await this.gameOps.pushOnline(server, { total: snap.total, ts: at })
        const ok = data.applied === true
        const entry = {
          id,
          name: server.name,
          ok,
          skipped: false,
          total: snap.total,
          applied: data.applied === true,
          allOnlineDisplay: data.allOnlineDisplay,
          // 服端自己数的本服在线：与宿主侧的 playercount 互为交叉验证
          serverLocalOnlineCount: data.localOnlineCount,
          at,
          error: ok ? '' : '服端未确认应用（applied=false）',
        }
        this.onlineStatus.set(id, entry)
        results.push(entry)
      } catch (err) {
        const entry = {
          id, name: server.name, ok: false, skipped: false, total: snap.total, at,
          error: err.message, serverHalfMissing: err.serverHalfMissing === true, status: err.status || 502,
        }
        this.onlineStatus.set(id, entry)
        results.push(entry)
      }
    }

    this.online = { ...this.online, ...snap, pushedTotal: snap.total }
    const okCount = results.filter((r) => r.ok).length
    const failed = results.filter((r) => !r.ok && !r.skipped)
    if (failed.length > 0) this._scheduleRetry()

    return { ok: failed.length === 0, reason, available: true, total: snap.total, serverCount: results.length, okCount, servers: results }
  }

  /** 是否有"真正失败（不是跳过）"的在线数下发 —— 重试定时器据此决定要不要带上在线数 */
  hasOnlineFailure() {
    for (const entry of this.onlineStatus.values()) {
      if (!entry.ok && entry.skipped !== true) return true
    }
    return false
  }

  // ═══════════════════════ 定时器 ═══════════════════════

  /**
   * 全服在线数周期兜底：即使在线数没变也重推一遍。
   * 旧版**没有**这条兜底（只在"聚合值变化"时下发），于是"服端重启 / 那一次下发丢了 / 后端与插件
   * 短暂失联"之后，{AllOnlineCount} 会一直停在 — 或旧值 —— 这里补上。
   */
  startOnlineReconcile() {
    if (this._disposed) return false
    if (this._onlineReconcileTimer) {
      clearInterval(this._onlineReconcileTimer)
      this._onlineReconcileTimer = null
    }
    const ms = Number(this.push.onlineReconcileIntervalMs) || 0
    if (ms <= 0) return false
    this._onlineReconcileTimer = setInterval(() => {
      this.refreshOnline({ reason: '周期对账（全服在线数）' }).catch((err) => {
        console.error(`[status-panel] 周期对账下发全服在线数失败：${err.message}`)
      })
    }, ms)
    this._onlineReconcileTimer.unref?.()
    return true
  }

  /** 失败重试（指数退避到 push.retryMaxIntervalMs）；全部确认后由 _clearRetry 停掉 */
  _scheduleRetry() {
    if (this._disposed) return false
    const cfg = this.push
    if (cfg.retryIntervalMs <= 0) return false
    if (this._retryTimer) return true
    const delay = Math.max(cfg.retryIntervalMs, Math.min(this._retryDelay, cfg.retryMaxIntervalMs))
    this._retryTimer = setTimeout(() => {
      this._retryTimer = null
      this._retryDelay = Math.min(Math.max(this._retryDelay, cfg.retryIntervalMs) * 2, cfg.retryMaxIntervalMs)
      if (this.hasOnlineFailure()) {
        this.refreshOnline({ reason: '失败重试（全服在线数）' }).catch((err) => {
          console.error(`[status-panel] 失败重试下发全服在线数异常：${err.message}`)
        })
      }
    }, delay)
    this._retryTimer.unref?.()
    return true
  }

  _clearRetry() {
    if (this._retryTimer) {
      clearTimeout(this._retryTimer)
      this._retryTimer = null
    }
    this._retryDelay = this.push.retryIntervalMs
  }

  async serversOverview() {
    return (await this.ctx.servers.list()).map(s => ({
      id: String(s.id), name: s.name, host: s.host, port: s.port,
      enabled: s.enabled !== false, online: this.onlineStatus.get(String(s.id)) || null,
    }))
  }

  status() {
    return {
      auditFile: this.auditFile, pendingServerIds: [], pendingCount: 0,
      retryScheduled: this._retryTimer != null,
      onlineFailures: [...this.onlineStatus.values()].filter(e => !e.ok && !e.skipped).map(e => e.id),
      online: {
        available: this.online.available,
        total: this.online.total,
        reason: this.online.reason,
        fetchedAt: this.online.fetchedAt,
        source: this.online.source,
        pushedTotal: this.online.pushedTotal,
        display: this.online.available ? String(this.online.total) : '—',
        perServer: this.online.servers || [],
      },
      dll: { name: DLL_NAME, prefix: SERVER_HALF_PREFIX, permission: REST_PERMISSION },
      limits: { maxRowsPerPanel: MAX_ROWS_PER_PANEL, maxSpacerWidth: MAX_SPACER_WIDTH },
    }
  }

  async probeServers({ serverIds = null } = {}) {
    const servers = await this.gameOps.enabledServers()
    const targets = serverIds ? servers.filter(s => serverIds.map(String).includes(String(s.id))) : servers
    return { servers: await Promise.all(targets.map(async server => {
      try { return { id: String(server.id), name: server.name, ok: true, state: await this.gameOps.probe(server) } }
      catch (err) { return { id: String(server.id), name: server.name, ok: false, error: err.message } }
    })) }
  }
}

export async function apply(ctx, options = {}) {
  try {
    return await applyInner(ctx, options)
  } catch (err) {
    // 约定（docs/插件开发约定.md §2.2）：声明 inject 的插件 apply 是延迟执行的，
    // 期间抛出的异常不会被加载器的 try/catch 捕获，表现为"插件加载成功但什么都没注册"，
    // 所以这里自己兜一层并打印。
    console.error('[status-panel] 初始化失败: ' + err.message)
    if (process.env.TSWEB_DEBUG) console.error(err.stack)
    throw err
  }
}

async function applyInner(ctx, options = {}) {
  // 宿主数据目录仅保留审计记录，配置由游戏服保存。
  const dataDir = options.dataDir || ctx.paths.dataOf('status-panel')
  const service = new StatusPanelService({
    ctx,
    dataDir,
    auditFile: options.auditFile || `${dataDir}/audit.jsonl`,
    push: options.push,
  })
  await service.init()

  const app = ctx.auth.access.policyApp(ctx.webServer.app, accessContract, ctx)
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireServerManager()]
  const fail = (res, err) => {
    const status = err.status || 500
    const body = { error: err.message }
    for (const key of ['serverId', 'serverHalfMissing', 'serverIds', 'missingDll']) {
      if (err[key] !== undefined) body[key] = err[key]
    }
    if (!res.headersSent) res.status(status).json(body)
  }
  const wrap = (handler) => async (req, res) => {
    try {
      res.json(await handler(req, res))
    } catch (err) {
      fail(res, err)
    }
  }

  const serverIdOf = (req) => StatusPanelService.serverIdFromRequest(req)

  /**
   * 返回可访问的服务器及全服在线数更新状态。
   */
  app.get('/api/status-panel/servers', ...admin, wrap(async (req) => {
    let servers = []
    let error = ''
    try {
      servers = ctx.auth.filterServers(req.user, await service.serversOverview())
    } catch (err) {
      error = `读取服务器列表失败：${err.message}`
    }
    return {
      ok: error === '',
      error,
      servers,
      defaults: { enabled: false, spacerWidth: defaultConfig().spacerWidth, logLevel: defaultConfig().logLevel },
      dll: { name: DLL_NAME, prefix: SERVER_HALF_PREFIX, permission: REST_PERMISSION },
    }
  }))

  /** 读某台服的配置（x-server-id 指定；缺省第一台启用服） */
  app.get('/api/status-panel/config', ...admin, wrap(req => service.readConfig(serverIdOf(req))))

  /**
   * 保存所选游戏服的配置。两种请求形态：
   *   { config: {...} }          整份替换（界面"改动即自动保存"用这条；严格校验，非法即 400）
   *   { updates: { 路径: 值 } }   局部写入（终端/脚本用）
   *   { path, value }            单字段（updates 的语法糖）
   * 保存成功表示游戏服已确认写入；连接或落盘失败直接返回错误。
   */
  app.post('/api/status-panel/config', ...admin, wrap(async (req) => {
    const b = req.body || {}
    const server = await service.resolveServer(serverIdOf(req))
    if (b.config !== undefined) {
      if (b.updates !== undefined) {
        throw httpError(400, 'config 与 updates 不能同时给出（前者整份替换、后者局部写入）')
      }
      return service.setConfig(server.id, b.config, { actor: 'admin' })
    }
    let updates = b.updates && typeof b.updates === 'object' && !Array.isArray(b.updates) ? b.updates : null
    if (!updates) {
      if (b.path === undefined) throw httpError(400, '缺少参数: config 或 updates 或 path/value')
      updates = { [String(b.path)]: b.value }
    }
    return service.applyUpdates(server.id, updates, { actor: 'admin' })
  }))

  /** 在线数更新状态；probe=1 时读取游戏服实际配置与运行状态。 */
  app.get('/api/status-panel/status', ...admin, wrap(async (req) => {
    const q = req.query || {}
    const out = service.status()
    out.servers = ctx.auth.filterServers(req.user, await service.serversOverview())
    if (!['superadmin', 'admin'].includes(req.user.usergroup)) {
      out.pendingServerIds = out.pendingServerIds.filter(id => ctx.auth.canAccessServer(req.user, id))
      out.pendingCount = out.pendingServerIds.length
      out.onlineFailures = out.onlineFailures.filter(id => ctx.auth.canAccessServer(req.user, id))
      out.online.perServer = ctx.auth.filterServers(req.user, out.online.perServer)
      out.online.total = out.online.perServer.reduce((n, s) => n + s.playercount, 0)
      out.online.display = String(out.online.total)
      delete out.online.pushedTotal
    }
    if (q.probe === '1' || q.probe === 'true') {
      out.probe = await service.probeServers({ serverIds: serverIdOf(req) ? [serverIdOf(req)] : null })
    }
    return { ok: true, ...out }
  }))

  /** 当前全服在线数快照（含数据来源与"这台服现在显示的是多少"的对照） */
  app.get('/api/status-panel/online', ...admin, wrap(async (req) => {
    const snap = await service._readOnline()
    service.online = { ...service.online, ...snap }
    const visible = ctx.auth.filterServers(req.user, snap.servers || [])
    const total = !['superadmin', 'admin'].includes(req.user.usergroup) ? visible.reduce((n, s) => n + Number(s.playercount || 0), 0) : snap.total
    return {
      ok: snap.available,
      online: {
        available: snap.available,
        total,
        display: snap.available ? String(total) : '—',
        reason: snap.reason,
        fetchedAt: snap.fetchedAt,
        source: snap.source,
        perServer: visible.map((s) => ({
          id: String(s.id), name: s.name, playercount: Number(s.playercount || 0),
        })),
      },
      pushed: Object.fromEntries([...service.onlineStatus.entries()].filter(([id]) => ctx.auth.canAccessServer(req.user, id))),
    }
  }))

  /** 审计流水 */
  app.get('/api/status-panel/audit', ...admin, wrap(async (req) => ({
    ok: true,
    entries: ctx.auth.filterAudit(req.user, await service.audit.tail((req.query && req.query.limit) || 100)),
  })))

  /**
   * 默认值与常量（前端**单一真相源**：模板行、占位符清单、上限）。
   * 旧版是"插件里一份模板 + 前端里一份模板"的双份真相源（改一处不会同步另一处），
   * 本件由这条接口 + 测试里的三方一致性断言消除漂移。
   */
  app.get('/api/status-panel/defaults', ...admin, wrap(async () => ({
    ok: true,
    config: defaultConfig(),
    rows: defaultPanelRows(),
    placeholders: PLACEHOLDER_TOKENS,
    logLevels: LOG_LEVELS,
    limits: {
      maxRowsPerPanel: MAX_ROWS_PER_PANEL,
      maxSpacerWidth: MAX_SPACER_WIDTH,
      maxConfiguredRowsPerPanel: 200,
    },
  })))

  service.subscribeOnlineStats()

  try {
    ctx.on('push/connected', () => {
      service.refreshOnline({ reason: '服务器连接建立' }).catch((err) => {
        console.error(`[status-panel] 连接恢复下发全服在线数失败：${err.message}`)
      })
    })
    ctx.on('servers/loaded', () => {
      service.refreshOnline({ reason: '服务器列表加载' }).catch((err) => {
        console.error(`[status-panel] 服务器列表加载下发全服在线数失败：${err.message}`)
      })
    })
  } catch (err) {
    // ctx.on 在个别宿主版本上不可用/不允许：补推少一层兜底但插件照常工作，如实记录
    console.error(`[status-panel] 事件订阅失败（连接恢复补推不可用）：${err.message}`)
  }

  console.log('[status-panel] 已挂载：配置直接读取并保存到游戏服；全服在线数由 online-stats 提供')

  // 返回 dispose effect：cordis 在插件禁用/卸载时调用（停定时器/退订事件）
  return () => service.dispose()
}
