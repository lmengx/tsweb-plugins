// Module permissions authorize both UI features and their backend routes.
export default {
  "owner": "status-panel",
  "version": 2,
  "modules": [
    {
      "id": "status-panel.status-panel",
      "permission": "status-panel.ui.status-panel",
      "title": "状态面板",
      "roles": [
        "superadmin",
        "admin",
        "subadmin"
      ],
      "scope": "server",
      "requires": [
        "status-panel.get.status.panel.servers",
        "status-panel.get.status.panel.config",
        "status-panel.post.status.panel.config",
        "status-panel.get.status.panel.status",
        "status-panel.get.status.panel.online",
        "status-panel.get.status.panel.audit",
        "status-panel.get.status.panel.defaults"
      ]
    }
  ],
  "actions": [
    {
      "id": "status-panel.get.status.panel.servers",
      "method": "GET",
      "path": "/api/status-panel/servers",
      "scope": "server",
      "module": "status-panel.status-panel"
    },
    {
      "id": "status-panel.get.status.panel.config",
      "method": "GET",
      "path": "/api/status-panel/config",
      "scope": "server",
      "module": "status-panel.status-panel"
    },
    {
      "id": "status-panel.post.status.panel.config",
      "method": "POST",
      "path": "/api/status-panel/config",
      "scope": "server",
      "module": "status-panel.status-panel"
    },
    {
      "id": "status-panel.get.status.panel.status",
      "method": "GET",
      "path": "/api/status-panel/status",
      "scope": "server",
      "module": "status-panel.status-panel"
    },
    {
      "id": "status-panel.get.status.panel.online",
      "method": "GET",
      "path": "/api/status-panel/online",
      "scope": "server",
      "module": "status-panel.status-panel"
    },
    {
      "id": "status-panel.get.status.panel.audit",
      "method": "GET",
      "path": "/api/status-panel/audit",
      "scope": "server",
      "module": "status-panel.status-panel"
    },
    {
      "id": "status-panel.get.status.panel.defaults",
      "method": "GET",
      "path": "/api/status-panel/defaults",
      "scope": "server",
      "module": "status-panel.status-panel"
    }
  ],
  "features": [
    {
      "id": "status-panel:status-panel",
      "module": "status-panel.status-panel",
      "requires": [
        "status-panel.get.status.panel.servers",
        "status-panel.get.status.panel.config",
        "status-panel.post.status.panel.config",
        "status-panel.get.status.panel.status",
        "status-panel.get.status.panel.online",
        "status-panel.get.status.panel.audit",
        "status-panel.get.status.panel.defaults"
      ]
    }
  ]
}
