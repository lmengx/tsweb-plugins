import { error, validateConfig } from './config.js';
export class EmoteService {
  constructor(ctx) { this.ctx = ctx; this.disposed = false; }
  async call(id, write, body, signal) {
    if (this.disposed) throw error(503, '表情指令正在停用，请稍后重试');
    signal?.throwIfAborted();
    if (typeof id !== 'string' || !id) throw error(400, '请先选择服务器');
    const server = this.ctx.servers.getRaw(id);
    if (!server) throw error(404, '服务器不存在');
    let params = {};
    if (write) {
      params.config = JSON.stringify(validateConfig(body?.config));
      if (!/^[a-f0-9]{64}$/.test(body?.expectedRevision || '')) throw error(400, '请先读取配置，再保存修改');
      params.expectedRevision = body.expectedRevision;
    }
    let response;
    try {
      response = write
        ? await this.ctx.tshock.postFor(server, '/data/emote-command/config/set', params, { timeoutMs: 12000 })
        : await this.ctx.tshock.fetchFor(server, '/data/emote-command/config', {}, { timeoutMs: 12000 });
    } catch (err) { signal?.throwIfAborted(); throw error(502, '连接游戏服失败：' + err.message); }
    signal?.throwIfAborted();
    if (this.disposed) throw error(503, '表情指令已停用，请重新打开页面');
    const data = response.data, status = Number(data?.status || response.status || 502);
    if (status === 404) throw error(501, '所选游戏服尚未启用表情指令，请检查插件同步状态');
    if (status === 401 || status === 403) throw error(502, '游戏服令牌缺少 tsweb.emote-command.manage 权限');
    if (!response.ok || status >= 400 || !data || data.error)
      throw error([400, 409, 503].includes(status) ? status : 502, data?.error || '游戏服未返回有效配置');
    if (!/^[a-f0-9]{64}$/.test(data.revision || '')) throw error(502, '游戏服返回的配置版本无效，请更新插件');
    let config;
    try { config = validateConfig(data.config); } catch { throw error(502, '游戏服返回的表情规则无效'); }
    return { config, revision: data.revision, warning: typeof data.warning === 'string' ? data.warning : '' };
  }
}
