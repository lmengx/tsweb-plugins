const actions = [
  { id: 'shopui.config.read', method: 'GET', path: '/api/shopui/config' },
  { id: 'shopui.config.save', method: 'POST', path: '/api/shopui/config' },
].map(action => ({ ...action, module: 'shopui.manage', scope: 'server' }));
export default { owner: 'shopui', version: 2,
  modules: [{ id: 'shopui.manage', permission: 'shopui.manage', title: '虚拟商店管理', roles: ['superadmin', 'admin'], scope: 'server', requires: actions.map(a => a.id) }],
  actions, features: [{ id: 'shopui:manage', module: 'shopui.manage', requires: actions.map(a => a.id) }] };
