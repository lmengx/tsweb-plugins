export const fail = (status, message) => Object.assign(new Error(message), { status });
const flags = new Set(['downedSlimeKing','downedBoss1','downedQueenBee','downedBoss3','downedMechBoss1','downedMechBoss2','downedMechBoss3','downedPlantBoss','downedGolemBoss','downedFishron','downedMoonlord','downedQueenSlime','downedEmpressOfLight','downedDeerclops','hardMode']);
const integer = (n, min, max, label) => { if (!Number.isSafeInteger(n) || n < min || n > max) throw fail(400, `${label}应为 ${min}～${max} 的整数`); return n; };
function condition(c) {
  if (!c || !['always','never','hardmode','boss','kill'].includes(c.type)) throw fail(400, '未知解锁条件');
  if (c.type === 'boss' && !flags.has(c.flag)) throw fail(400, '未知 Boss 进度');
  const ids = c.type === 'kill' ? (c.npcIds?.length ? c.npcIds : c.npcId ? [c.npcId] : []) : [];
  if (c.type === 'kill' && (!ids.length || ids.length > 100)) throw fail(400, '请填写有效 NPC ID');
  ids.forEach(n => integer(n, 1, 10000, 'NPC ID'));
  return { type: c.type, ...(c.type === 'boss' ? { flag: c.flag } : {}), ...(c.type === 'kill' ? { npcIds: [...new Set(ids)] } : {}) };
}
export function validateConfig(c) {
  if (!c || typeof c.enabled !== 'boolean' || !Array.isArray(c.shops) || !c.shops.length || c.shops.length > 100 || !Array.isArray(c.statueControls) || c.statueControls.length > 40) throw fail(400, '商店配置结构无效');
  integer(c.summonItemId, 1, 100000, '召唤物 ID');
  const slots = new Set(), controls = new Set(), keys = new Set();
  const statueControls = c.statueControls.map(s => {
    if (!s) throw fail(400, '分类控件无效');
    integer(s.slot, 0, 39, '控件格子'); integer(s.statueItemId, 1, 100000, '控件 ID'); integer(s.targetShopIndex, 0, c.shops.length - 1, '目标商店');
    if (slots.has(s.slot) || controls.has(s.statueItemId)) throw fail(400, '控件格子或物品 ID 重复');
    slots.add(s.slot); controls.add(s.statueItemId);
    return { slot: s.slot, statueItemId: s.statueItemId, targetShopIndex: s.targetShopIndex, name: String(s.name || '').slice(0, 40) };
  });
  const shops = c.shops.map((s, index) => {
    if (!s || typeof s.name !== 'string' || !s.name.trim() || s.name.length > 40 || !Array.isArray(s.items) || s.items.length > 40 - slots.size) throw fail(400, `商店 ${index + 1} 名称或容量无效`);
    const key = s.key || `legacy-${index}`;
    if (typeof key !== 'string' || !/^[a-zA-Z0-9_-]{1,80}$/.test(key) || keys.has(key)) throw fail(400, '商店标识重复或无效');
    keys.add(key);
    const used = new Set();
    const items = s.items.map(i => {
      if (!i) throw fail(400, '商品无效');
      integer(i.slot, 0, 39, '商品格子'); integer(i.itemId, 1, 100000, '商品 ID'); integer(i.price, 0, 2147483647, '铜币价格'); integer(i.stack, 1, 32767, '商品数量');
      if (used.has(i.slot) || slots.has(i.slot)) throw fail(400, `${s.name}的格子重复或被控件占用`);
      if (controls.has(i.itemId)) throw fail(400, '分类控件不能同时出售');
      used.add(i.slot);
      return { slot: i.slot, itemId: i.itemId, price: i.price, stack: i.stack, condition: condition(i.condition || { type: 'always' }) };
    });
    return { key, name: s.name.trim(), items };
  });
  return { enabled: c.enabled, summonItemId: c.summonItemId, unlockCondition: condition(c.unlockCondition || { type: 'always' }), shops, statueControls };
}
export class ShopService {
  constructor(ctx) { this.ctx = ctx; }
  async call(id, write, body) {
    if (typeof id !== 'string' || !id) throw fail(400, '请先选择目标服务器');
    const server = this.ctx.servers.getRaw(id);
    if (!server) throw fail(404, '目标服务器不存在');
    const params = {};
    if (write) {
      params.config = JSON.stringify(validateConfig(body?.config));
      if (!/^[a-f0-9]{64}$/.test(body?.expectedRevision || '')) throw fail(400, '请先读取服务器配置');
      params.expectedRevision = body.expectedRevision;
    }
    const response = write
      ? await this.ctx.tshock.postFor(server, '/data/shopui/config/set', params, { timeoutMs: 12000 })
      : await this.ctx.tshock.fetchFor(server, '/data/shopui/config', {}, { timeoutMs: 12000 });
    const data = response.data, status = Number(data?.status || response.status || 502);
    if (status === 404) throw fail(501, '游戏服尚未加载独立虚拟商店插件，请检查插件同步状态');
    if (status === 401 || status === 403) throw fail(502, '游戏服 REST 令牌没有虚拟商店管理权限');
    if (!response.ok || status >= 400 || data?.error) throw fail([400, 409, 503, 504].includes(status) ? status : 502, data?.error || '游戏服未返回有效配置');
    if (data?.plugin !== 'TsWebShopUI' || !/^[a-f0-9]{64}$/.test(data.revision || '')) throw fail(502, '游戏服仍在运行旧版商店，请检查 DLL 冲突');
    return { config: validateConfig(data.config), revision: data.revision, warning: data.warning || '', plugin: data.plugin, applied: true };
  }
}
