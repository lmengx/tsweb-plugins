const revision = new URL(import.meta.url).search;
const { default: access } = await import(`./access.js${revision}`);
const { ShopService } = await import(`./service.js${revision}`);
export const name = 'shopui';
export const inject = ['webServer', 'auth', 'servers', 'tshock'];
export function apply(ctx) {
  try {
    const service = new ShopService(ctx);
    const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx);
    let disposed = false;
    ctx.on('dispose', () => { disposed = true; });
    const handle = write => async (req, res) => {
      try {
        if (disposed) throw Object.assign(new Error('插件已停用'), { status: 503 });
        const result = await service.call(req.headers['x-server-id'], write, req.body);
        if (!res.destroyed) res.json(result);
      } catch (err) { if (!res.headersSent) res.status(err.status || 502).json({ error: err.message }); }
    };
    app.get('/api/shopui/config', handle(false));
    app.post('/api/shopui/config', handle(true));
  } catch (err) { console.error('[shopui] 初始化失败：' + err.message); throw err; }
}
