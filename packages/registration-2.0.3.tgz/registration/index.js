const { default: access } = await import(`./access.js${new URL(import.meta.url).search}`)
export const name = 'registration'
export const inject = ['webServer', 'auth', 'servers', 'tshock']
const modes = new Set(['default', 'auto', 'block'])
const error = (status, message) => Object.assign(new Error(message), { status })
export function apply(ctx) {
  try {
    const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx)
    const status = () => ({ qqLoaded: !!ctx.get('qqBind') })
    const wrap = handler => async (req, res) => {
      try { res.json(await handler(req)) }
      catch (err) { res.status(err.status || 502).json({ error: err.message }) }
    }
    async function remote(req, write, passwordMessage = false) {
      const id = req.headers['x-server-id'] || req.query?.serverId || req.user?.serverId || req.user?.extraServerIds?.[0]
      if (typeof id !== 'string' || !id) throw error(400, '请先选择服务器')
      const server = ctx.servers.getRaw(id)
      if (!server) throw error(404, '服务器不存在')
      const mode = req.body?.mode
      const text = req.body?.kickPasswordMessage
      if (write && !passwordMessage && !modes.has(mode)) throw error(400, '请选择有效的注册模式')
      if (write && passwordMessage && (typeof text !== 'string' || !text.trim() || text.length > 2000))
        throw error(400, '踢出提示须为 1–2000 字的文本')
      if (write && passwordMessage && req.body?.enabled !== undefined && typeof req.body.enabled !== 'boolean') throw error(400, '无效的登录验证开关')
      const target = passwordMessage ? '/data/registration/password-message' : '/data/registration/config'
      const result = await ctx.tshock.fetchFor(server, `${target}${write ? '/set' : ''}`, write ? (passwordMessage ? { kickPasswordMessage: text, ...(req.body?.enabled === undefined ? {} : { enabled: req.body.enabled }) } : { mode }) : {})
      const code = Number(result.data?.status || result.status || 200)
      if (code === 404) throw error(501, passwordMessage ? '所选游戏服需要更新注册登录插件，才能配置密码不匹配踢出文本' : '所选游戏服尚未安装注册登录控制插件')
      if (!result.ok || code >= 400) throw error(code === 400 ? 400 : 502, result.data?.error || '游戏服注册配置读取或保存失败')
      if (passwordMessage ? typeof result.data?.kickPasswordMessage !== 'string' : !modes.has(result.data?.mode))
        throw error(502, '游戏服返回的注册配置无效，请更新插件后重试')
      return { ...result.data, ...status() }
    }
    app.get('/api/registration/config', wrap(req => remote(req, false)))
    app.post('/api/registration/config', wrap(req => remote(req, true)))
    app.get('/api/registration/status', wrap(() => status()))
    app.get('/api/registration/password-message', wrap(req => remote(req, false, true)))
    app.post('/api/registration/password-message', wrap(req => remote(req, true, true)))
  } catch (err) { console.error('[registration] 初始化失败：' + err.message); throw err }
}
