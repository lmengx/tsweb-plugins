const actions = [
  { id: 'registration.config.read', method: 'GET', path: '/api/registration/config' },
  { id: 'registration.config.save', method: 'POST', path: '/api/registration/config' },
  { id: 'registration.status', method: 'GET', path: '/api/registration/status' },
  { id: 'registration.password-message.read', method: 'GET', path: '/api/registration/password-message' },
  { id: 'registration.password-message.save', method: 'POST', path: '/api/registration/password-message' },
].map(action => ({ ...action, module: 'registration.settings', scope: 'server' }))
export default {
  owner: 'registration', version: 2,
  modules: [{ id: 'registration.settings', permission: 'registration.settings', title: '注册登录控制',
    roles: ['superadmin', 'admin'], scope: 'server', requires: actions.map(action => action.id) }],
  actions,
  features: [{ id: 'registration:settings', module: 'registration.settings', requires: actions.map(action => action.id) }],
}
