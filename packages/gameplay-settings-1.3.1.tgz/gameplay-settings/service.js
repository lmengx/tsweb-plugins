const fail = (status, message) => Object.assign(new Error(message), { status });
export function validateConfig(value) {
  if (!value || Array.isArray(value) || typeof value !== 'object' ||
    !['inherit', 'mediumcore', 'hardcore'].includes(value.deathMode) ||
    !['inherit', 'forced', 'randomTeams'].includes(value.pvpMode) ||
    typeof value.resetRandomTeamsOnWorldChange !== 'boolean') throw fail(400, '请选择有效的玩法规则');
  if (Object.keys(value).some(k => !['deathMode', 'pvpMode', 'resetRandomTeamsOnWorldChange', 'mediumcoreDrops', 'hardcoreAccountDeath'].includes(k)))
    throw fail(400, '包含不支持的玩法配置');
  const hardcoreAccountDeath = Object.hasOwn(value, 'hardcoreAccountDeath') ? value.hardcoreAccountDeath : false;
  if (typeof hardcoreAccountDeath !== 'boolean') throw fail(400, '账号硬核开关须为布尔值');
  const rules = Object.hasOwn(value, 'mediumcoreDrops') ? value.mediumcoreDrops : {
    enabled: false, inventory: { range: 1, keep: 1 }, equipment: { range: 0, keep: 0 },
  };
  if (!rules || Array.isArray(rules) || typeof rules !== 'object' || Object.keys(rules).length !== 3 || typeof rules.enabled !== 'boolean')
    throw fail(400, '中核保留规则不完整');
  for (const [key, max] of [['inventory', 50], ['equipment', 10]]) {
    const pair = rules[key];
    if (!pair || Array.isArray(pair) || typeof pair !== 'object' || Object.keys(pair).length !== 2 ||
      !Number.isInteger(pair.range) || !Number.isInteger(pair.keep) || pair.range < 0 || pair.range > max || pair.keep < 0 || pair.keep > pair.range)
      throw fail(400, `中核${key === 'inventory' ? '物品栏' : '装备栏'}：范围须为 0–${max}，保留格数须为 0–范围格数`);
  }
  return { ...value, mediumcoreDrops: rules, hardcoreAccountDeath };
}
export function validateOperation(body) {
  if (!body || !/^[a-zA-Z0-9-]{16,80}$/.test(body.operationId || '') ||
    !Number.isSafeInteger(body.expectedRevision) || body.expectedRevision < 0 ||
    typeof body.expectedWorldId !== 'string' || !/^-?\d{1,12}$/.test(body.expectedWorldId))
    throw fail(400, '操作信息已失效，请重新读取');
  return { operationId: body.operationId, expectedRevision: body.expectedRevision, expectedWorldId: body.expectedWorldId };
}
export class GameplayService {
  constructor(ctx) { this.ctx = ctx; this.disposed = false; }
  async call(id, suffix, params = {}, signal) {
    if (this.disposed) throw fail(503, '玩法设置正在停用');
    signal?.throwIfAborted();
    if (typeof id !== 'string' || !id) throw fail(400, '请先选择服务器');
    const server = this.ctx.servers.getRaw(id);
    if (!server) throw fail(404, '服务器不存在');
    let response;
    try { response = await this.ctx.tshock.fetchFor(server, `/data/gameplay-settings/${suffix}`, params, { signal, timeoutMs: 12000 }); }
    catch (err) { signal?.throwIfAborted(); throw fail(502, '连接游戏服失败：' + err.message); }
    signal?.throwIfAborted();
    if (this.disposed) throw fail(503, '玩法设置正在停用');
    const data = response.data, status = Number(data?.status || response.status || 502);
    if (status === 404 && suffix !== 'operation') throw fail(501, '游戏服尚未启用玩法设置，请检查插件同步状态');
    if (status === 401 || status === 403) throw fail(502, '游戏服令牌需要 tsweb.gameplay-settings.manage 权限');
    if (!response.ok || status >= 400 || !data || data.error)
      throw fail([400, 404, 409, 429, 503].includes(status) ? status : 502, data?.error || '游戏服未返回有效结果');
    return data;
  }
  save(id, body, actor, signal) {
    const config = validateConfig(body?.config), operation = validateOperation(body);
    return this.call(id, 'config/set', { ...operation, config: JSON.stringify(config), actor }, signal);
  }
  reset(id, body, actor, signal) { return this.call(id, 'teams/reset', { ...validateOperation(body), actor }, signal); }
}
