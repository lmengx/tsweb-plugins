const { ui } = await import(`./messages.js${new URL(import.meta.url).search}`)
const navigation = () => [[ui.button.callback('主菜单', 'menu', [], { style: 0 }), ui.button.callback('机器人状态', 'status', [], { style: 0 })]]
const menu = ({ commands }) => ui.card({ title: 'TSWeb 机器人', lines: ['查服务器、看在线，或管理自己的游戏账号。', '发送“菜单”可随时返回。'],
  buttons: [...(commands.some(command => command.name === 'servers') ? [[ui.button.callback('服务器列表', 'servers'), ui.button.callback('在线玩家', 'online')]] : []),
    [...(commands.some(command => command.name === 'account') ? [ui.button.callback('账号服务', 'account')] : []), ui.button.callback('使用帮助', 'help')]] })
export const builtinCommands = [
  { name: 'group-info', description: '获取当前官方群标识', aliases: ['群信息', '群标识'],
    run: ({ message }) => message?.groupOpenid ? '当前群 group_openid：' + message.groupOpenid + '\n在 QQ 控制台 → 群管理启用目标群；混合模式的群映射由系统自动建立，无需填写。' : '请在目标 QQ 群中 @机器人 发送“群信息”。' },
  { name: 'menu', description: '打开交互主菜单', aliases: ['菜单', '开始'], templateAction: true, run: menu },
  { name: 'ping', description: '测试机器人连接', aliases: ['测试'],
    run: () => 'pong：QQ 官方机器人已连接。' },
  { name: 'help', description: '查看可用命令', aliases: ['帮助'], templateAction: true,
    run: ({ commands }) => ui.card({ title: '使用帮助', lines: [
      '优先使用菜单按钮。群里 @机器人，私聊直接发送。',
      ...(commands.some(command => command.name === 'servers') ? ['**服务器查询**', '服务器：选择服务器、查看状态。在线 服名：查看在线玩家。'] : []),
      ...(commands.some(command => command.name === 'account') ? ['**账号服务**', '注册 角色名：新建账号。绑定 角色名：验证已有角色。', '我的信息：查看自己的角色。取消绑定：取消尚未验证的请求。', '**密码仅限私聊**', '领取密码：补领初始密码。改密码 新密码：修改自己的密码。'] : []),
      ...(commands.some(command => command.name === 'transfer') ? ['**旧账号转移**', '绑定转移：打开专用菜单，点击“一键转移”。'] : []),
      '**其他指令**', '菜单：返回首页。状态：查看机器人运行状态。群信息：获取管理员配置所需的群标识。',
    ], buttons: navigation() }) },
  { name: 'status', description: '查看机器人运行状态', aliases: ['状态'], templateAction: true,
    run: ({ status }) => {
      const s = status()
      return ui.card({ title: '机器人状态', lines: [s.connected ? '机器人在线' : '机器人正在连接', `运行 ${s.uptimeSeconds} 秒`,
        `收到 ${s.messagesReceived} 条消息，回复 ${s.repliesSent} 条。`, `按钮回调 ${s.interactionsReceived} 次。`], buttons: navigation() })
    } },
]

export function parseCommand(content) {
  // Group command buttons prepend <@OpenID>, not necessarily a numeric AppID.
  // Strip address prefixes only: mentions inside arguments must remain literal.
  const text = String(content || '').replace(/^(?:\s*<@!?[A-Za-z0-9_-]{1,128}>)+\s*/, '').trim().replace(/^\//, '')
  const [name = '', ...args] = text.split(/\s+/)
  return { name: name.toLowerCase(), args }
}
