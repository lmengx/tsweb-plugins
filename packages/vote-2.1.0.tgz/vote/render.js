const xml = value => String(value ?? '').replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[char])
const palettes = {
  pixel: { bg: '#222c32', card: '#303e3e', ink: '#f6efd9', muted: '#bbc7b8', accent: '#f1d496', line: '#4b5d50', radius: 0 },
  space: { bg: '#0b1426', card: '#14233b', ink: '#e9f0ff', muted: '#a0b0cf', accent: '#9cc4ff', line: '#293b58', radius: 16 },
  cream: { bg: '#fcf3e8', card: '#fffaf3', ink: '#4a3930', muted: '#80695b', accent: '#96563b', line: '#e3d2bd', radius: 20 },
}
function wrap(value, columns = 48) {
  const lines = []; let line = '', width = 0
  for (const char of String(value ?? '')) {
    const size = /[^\x00-\xff]/.test(char) ? 2 : 1
    if (char === '\n' || width + size > columns) { lines.push(line); line = ''; width = 0; if (char === '\n') continue }
    line += char; width += size
  }
  if (line || !lines.length) lines.push(line)
  return lines
}
export function voteSummary(result, action) {
  if (action === 'cast') return `投票成功，本次分值 ${result.weight}，剩余可投 ${result.round.my.votesLeft} 项。`
  if (action === 'propose') return result.existing ? '该提案已存在。' : '提案已提交。'
  return '投票结果'
}
export function buildVotePages({ result, action = 'list', theme = 'pixel' }) {
  const p = palettes[theme] || palettes.pixel
  const rounds = result.round ? [result.round] : result.rounds || [], overview = !result.round && rounds.length > 1
  const text = (x, y, value, size = 26, color = p.ink, weight = 400, anchor = 'start') => `<text x="${x}" y="${y}" fill="${color}" font-size="${size}" font-weight="${weight}" text-anchor="${anchor}">${xml(value)}</text>`
  const blocks = []
  const lines = (value, size = 25, color = p.muted, weight = 400) => {
    for (const line of wrap(value, size >= 30 ? 48 : 64)) blocks.push({ height: size + 14, draw: y => text(60, y + size, line, size, color, weight) })
  }
  if (!rounds.length) lines('当前没有可查看的投票。', 30, p.ink)
  if (overview) lines(`共 ${rounds.length} 轮，显示前 ${Math.min(rounds.length, 20)} 轮。发送「投票 完整轮次名」查看选项。`)
  for (const [index, round] of (overview ? rounds.slice(0, 20) : rounds).entries()) {
    lines(`${overview ? index + 1 + '. ' : ''}${round.title}`, 32, p.ink, 700)
    lines(`${round.status === 'open' ? '进行中' : '已结束'} · ${round.options.length} 个选项`, 22, p.accent)
    if (overview) continue
    if (round.description) lines(round.description)
    if (round.endAt) lines('截止：' + new Date(round.endAt).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', hour12: false }), 22)
    const max = Math.max(1, ...round.options.map(option => Number(option.score) || 0))
    for (const [i, option] of round.options.entries()) {
      const label = wrap(`${i + 1}. ${option.text}`, 56), height = 80 + label.length * 33
      blocks.push({ height: height + 14, draw: y => `<rect x="44" y="${y}" width="872" height="${height}" rx="${p.radius}" fill="${p.card}" stroke="${p.line}"/>` +
        label.map((line, n) => text(64, y + 36 + n * 33, line, 26, p.ink, 600)).join('') +
        text(896, y + height - 38, `${option.votes} 票 / ${option.score} 分`, 23, p.accent, 400, 'end') +
        `<rect x="64" y="${y + height - 22}" width="832" height="8" fill="${p.line}"/><rect x="64" y="${y + height - 22}" width="${Math.max(0, Math.min(832, 832 * (Number(option.score) || 0) / max))}" height="8" fill="${p.accent}"/>` })
    }
  }
  const pages = []; let page = [], used = 0
  for (const block of blocks) {
    if (page.length && used + block.height > 960) { pages.push(page); page = []; used = 0 }
    page.push(block); used += block.height
  }
  if (page.length || !pages.length) pages.push(page)
  const summary = voteSummary(result, action)
  return { text: summary, pages: pages.map((items, i) => {
    const height = Math.max(480, 160 + items.reduce((sum, item) => sum + item.height, 0) + 120)
    let y = 150
    const body = items.map(item => { const value = item.draw(y); y += item.height; return value }).join('')
    return `<svg xmlns="http://www.w3.org/2000/svg" width="960" height="${height}" viewBox="0 0 960 ${height}"><title>投票结果 ${i + 1}/${pages.length}</title><rect width="960" height="${height}" fill="${p.bg}"/><g font-family="Microsoft YaHei,Noto Sans CJK SC,WenQuanYi Zen Hei,sans-serif">${text(44, 57, 'TSWEB / 玩家投票', 32, p.ink, 700)}${text(44, 102, summary, 24, p.accent)}${body}<path d="M44 ${height - 99}H916" stroke="${p.line}"/>${text(44, height - 62, '参与：投 轮次名 选项编号 · 提案：提案 轮次名 内容', 21)}${text(44, height - 28, '查看：投票 [轮次名]', 20, p.muted)}${text(790, height - 28, `${i + 1} / ${pages.length}`, 20, p.muted)}</g></svg>`
  }) }
}
export function registerVoteRendering(ctx) {
  return ctx.inject(['qqRenderer'], c => {
    if (!c.qqRenderer.registerTemplate) return
    return c.qqRenderer.registerTemplate('vote/results', { owner: 'vote', build: (options, { config }) => buildVotePages({ ...options, theme: options.theme ?? config.theme }) })
  })
}
export async function presentVote(ctx, result, { action, signal } = {}) {
  let renderer
  try { renderer = ctx.get('qqRenderer') } catch {}
  if (!renderer?.config?.enabled || !renderer.registerTemplate) return null
  return renderer.render('vote/results', { result, action, signal })
}
