import path from 'node:path'
import { fileURLToPath } from 'node:url'
import express from 'express'
import { Service } from '@deepseek-ai/cordis'
import accessContract from './access.js'
// Carry the loader's reload key into the data service so re-enabling the plugin
// also picks up service changes without restarting the panel.
const serviceUrl = new URL('./service.js', import.meta.url)
serviceUrl.search = new URL(import.meta.url).search
const { VoteStore, fail } = await import(serviceUrl.href)
import { PlayerSessions } from './player-auth.js'
import { registerBot } from './bot.js'
import { registerVoteRendering, presentVote } from './render.js'

export const name = 'vote'
export const inject = ['webServer', 'auth', 'paths']
const root = path.dirname(fileURLToPath(import.meta.url))
export function optional(ctx, name) { try { return ctx.get(name) } catch { return null } }

class VoteService extends Service {
  constructor(ctx, store) { super(ctx, 'vote'); this.store = store }
  importData(source, actor, options) { return this.store.importData(source, actor, options) }
}

export async function apply(ctx) {
  let sessions, store
  try {
    const resolve = async (identifier, secret = false) => {
      const qq = optional(ctx, 'qqBind')
      if (!qq) return null
      await qq.ready
      if (secret) return ctx.auth.identityProvider?.find(identifier) || null
      return qq.resolve(identifier)
    }
    store = new VoteStore({ dir: ctx.paths.dataOf('vote'), identity: resolve,
      nicknames: async () => await optional(ctx, 'qqBind')?.nicknameMap?.() || {},
      playtime: async username => {
        const online = optional(ctx, 'onlineStats')
        if (!online) throw fail(503, '在线统计未启用，暂时无法计算时长加权')
        const result = await online.getAllPlaytime()
        if (result.errors?.length) throw fail(503, '部分服务器时长不可用，请稍后投票')
        const entry = Object.entries(result.stats || {}).find(([key]) => key.toLowerCase() === username.toLowerCase())
        return entry ? Number(entry[1]) / 60 : 0
      },
    })
    await store.read() // Malformed existing files must fail visibly, never turn into an empty database.
    new VoteService(ctx, store)
    sessions = new PlayerSessions({ auth: ctx.auth, resolve })
    const app = ctx.auth.access.policyApp(ctx.webServer.app, accessContract, ctx)
    const wrap = fn => async (req, res) => {
      res.set('Cache-Control', 'no-store')
      try { res.json(await fn(req, res)) }
      catch (error) { if (!res.headersSent) res.status(error.status || 500).json({ success: false, error: error.status ? error.message : '投票服务处理失败' }) }
    }
    const actor = req => req.user.username
    app.get('/api/vote/admin/rounds', wrap(async () => ({ rounds: await store.list({ admin: true }), qqBindAvailable: !!optional(ctx, 'qqBind'), playtimeAvailable: !!optional(ctx, 'onlineStats') })))
    app.get('/api/vote/admin/rounds/:id/detail', wrap(async req => ({ success: true, round: await store.list({ admin: true, detail: req.params.id }) })))
    app.post('/api/vote/rounds', wrap(async req => ({ success: true, round: await store.create(req.body || {}, actor(req)) })))
    app.patch('/api/vote/rounds/:id', wrap(async req => ({ success: true, round: await store.update(req.params.id, req.body || {}, actor(req)) })))
    app.post('/api/vote/rounds/:id/options', wrap(async req => ({ success: true, ...await store.manage(req.params.id, 'addOption', actor(req), req.body?.text) })))
    app.delete('/api/vote/rounds/:id/options/:optionId', wrap(async req => ({ success: true, ...await store.manage(req.params.id, 'removeOption', actor(req), req.params.optionId) })))
    app.post('/api/vote/rounds/:id/close', wrap(async req => ({ success: true, ...await store.manage(req.params.id, 'close', actor(req)) })))
    app.post('/api/vote/rounds/:id/archive', wrap(async req => ({ success: true, ...await store.manage(req.params.id, 'archive', actor(req)) })))
    app.post('/api/vote/rounds/:id/unarchive', wrap(async req => ({ success: true, ...await store.manage(req.params.id, 'unarchive', actor(req)) })))
    app.delete('/api/vote/rounds/:id', wrap(async req => ({ success: true, ...await store.manage(req.params.id, 'delete', actor(req)) })))
    app.get('/api/vote/admin/audit', wrap(async () => ({ entries: (await store.read()).audit.slice(-200).reverse() })))
    app.get('/api/vote/rounds', wrap(async () => ({ rounds: await store.list(), loginAvailable: !!optional(ctx, 'qqBind') })))
    app.get('/api/vote/rounds/mine', wrap(async req => ({ rounds: await store.list({ identity: await sessions.require(req) }) })))
    app.get('/api/vote/player/key', wrap(req => {
      if (!optional(ctx, 'qqBind')) throw fail(503, '玩家登录暂不可用')
      sessions.take(req.ip, 'key', 15)
      return ctx.auth.generateServerKeyPair()
    }))
    app.post('/api/vote/player/login', wrap((req, res) => sessions.login(req, res)))
    app.get('/api/vote/player/me', wrap(async req => ({ ...await sessions.require(req) })))
    app.post('/api/vote/player/logout', wrap((req, res) => sessions.logout(req, res)))
    app.post('/api/vote/rounds/:id/cast', wrap(async req => {
      sessions.sameOrigin(req)
      const identity = await sessions.require(req)
      return { success: true, ...await store.cast(req.params.id, identity, req.body?.optionId) }
    }))
    app.post('/api/vote/rounds/:id/propose', wrap(async req => {
      sessions.sameOrigin(req)
      const identity = await sessions.require(req)
      return { success: true, ...await store.propose(req.params.id, identity, req.body?.text, req.body?.anonymous === true) }
    }))
    // Separate public entry: no changes to the panel's administrator shell or authentication.
    ctx.webServer.app.get('/vote', (_req, res) => res.set('Cache-Control', 'no-store').sendFile(path.join(root, 'public/index.html')))
    ctx.webServer.app.use('/vote-assets', express.static(path.join(root, 'dist'), { etag: true, maxAge: 0 }))
    registerVoteRendering(ctx)
    ctx.inject(['qqBind'], c => {
      const off = registerBot(c.qqBind, store, resolve, { present: (result, options) => presentVote(ctx, result, options) })
      return off
    })
    console.log('[vote] 投票插件已加载，玩家入口 /vote')
    return async () => { sessions.dispose(); await store.dispose() }
  } catch (error) {
    sessions?.dispose(); await store?.dispose()
    console.error('[vote] 初始化失败: ' + error.message)
    throw error
  }
}
