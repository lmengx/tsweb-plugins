/**
 * 插件市场插件（cordis）
 *
 * 职责：从市场仓库（tsweb-plugins）拉取集中索引 market.json，把其中的 tgz 发行包安装到本机运行时插件目录。
 *
 * 市场仓库的约定（只存发行包与元数据，不存源码）：
 *   tsweb-plugins/
 *   ├── market.json                  索引：每个插件当前版本的 name/version/url/sha256/size/dll[]
 *   └── packages/<name>-<ver>.tgz    发行包（顶层 <name>/，含 package.json/index.js/client//plugin/*.dll）
 *
 * 安装/更新完全复用宿主注册表能力：ctx.plugins.installFromTgz / updateFromTgz / uninstall，
 * 因此"市场装"与"本地 tgz 装"走同一条落位与校验路径，不会出现两套逻辑分叉。
 *
 * 两条取包通道：
 *   1. 在线：按 mirrors 顺序从 GitHub raw / gh-proxy 逐个尝试（失败自动切换并记住成功者）
 *   2. 离线：配置 localDir 指向市场仓库工作副本，直接读本地文件（用于 push 之前自测）
 *
 * 配置：<dataDir>/market/config.json（首次运行写出默认值）
 *   { repo, branch, mirrorOrder, localDir, timeoutMs }
 */
import crypto from 'node:crypto'
import fs from 'node:fs/promises'
import path from 'node:path'
import { Service } from '@deepseek-ai/cordis'

export const name = 'market'
// 需要 servers：安装/更新后按 tsweb.deploy 三态决定 DLL 下发目标
//   all   = 自动下发全部 enabled 服务器（缺省）
//   ask   = 前端弹窗让用户勾选（serverIds 必传，未传则跳过下发）
//   manual= 安装时全程静默不下发（仅装后端半；可在「插件下发」页手动逐服 deploy）
// 注意三态只管**安装/更新时的自动下发**；update() 还会额外把新 DLL 重推给
// "原先已记录为 loaded 且当前有活跃通道"的服务器（ask/manual 同样适用），
// 否则面板会一直显示"已下发"而服务器上跑的还是旧 DLL。
export const inject = ['webServer', 'auth', 'plugins', 'servers', 'terminal', 'paths']

/** 市场自身在索引与登记表里的插件名；自更新分支用它判定"要更新的就是我自己" */
const SELF_NAME = 'market'

const DEFAULT_CONFIG = {
  repo: 'lmengx/tsweb-plugins',
  branch: 'main',
  /** 镜像候选顺序：失败自动切换到下一个，成功的被记住并优先复用 */
  mirrorOrder: ['github', 'ghproxy'],
  /** 离线模式：指向市场仓库工作副本；非空时优先于在线拉取（push 前自测用） */
  localDir: '',
  /** 覆盖下载基址（自建镜像/内网分发/本地联调用）：非空时替代 mirrors 模板，形如 http://host/path */
  mirrorOverride: '',
  timeoutMs: 20000,
  /** 索引缓存有效期（毫秒） */
  cacheTtlMs: 10 * 60 * 1000,
  /** 收藏的插件名（市场页「收藏」栏用；存在服务端，换浏览器/清缓存都不丢） */
  favorites: [],
}

/**
 * 镜像模板：{repo}/{branch} 由配置替换。
 *
 * 注：原设计里的 **Gitee 镜像已移除**。它需要 GitHub Actions 推送同步，但该 CI
 * 从未实现、Gitee 侧也没有同名仓库，候选恒为 404——每次拉索引都要先白撞一次失败。
 * 老配置里残留的 'gitee' 会被 baseUrls() 的 `MIRRORS[id]` 过滤掉，不会报错，无需迁移。
 * 国内兜底由 ghproxy 承担。
 */
const MIRRORS = {
  github: 'https://raw.githubusercontent.com/{repo}/{branch}',
  ghproxy: 'https://gh-proxy.com/https://raw.githubusercontent.com/{repo}/{branch}',
}

function sha256(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex')
}

function human(bytes) {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(2) + ' MB'
}

/**
 * 解析终端命令里的下发参数（market-install/update <name> 之后的附加参数）：
 *   --servers <id1,id2>  显式指定目标服务器（逗号分隔的 serverId 列表）
 *   --no-deploy          不下发 DLL（等价于传空 serverIds）
 * 返回 { serverIds: string[] | null, noDeploy: boolean }（serverIds=null 表示未指定）
 */
function parseDeployArgs(args) {
  let serverIds = null
  let noDeploy = false
  for (let i = 1; i < (args?.length || 0); i++) {
    const a = args[i]
    if (a === '--no-deploy') {
      noDeploy = true
    } else if (a === '--servers') {
      const raw = String(args[++i] || '').trim()
      serverIds = raw ? raw.split(',').map((s) => s.trim()).filter(Boolean) : []
    } else {
      console.warn(`[market] 忽略未知参数: ${a}`)
    }
  }
  return { serverIds, noDeploy }
}

/** 版本比较（与宿主 registry.compareVersions 同语义：仅向前视为可更新） */
function compareVersions(a, b) {
  const parse = (v) => {
    const m = /^(\d+)\.(\d+)\.(\d+)(?:-(.+))?$/.exec(String(v || '').trim())
    return m ? { nums: [Number(m[1]), Number(m[2]), Number(m[3])], pre: m[4] || '' } : null
  }
  const pa = parse(a)
  const pb = parse(b)
  if (!pa || !pb) return String(a).localeCompare(String(b))
  for (let i = 0; i < 3; i++) if (pa.nums[i] !== pb.nums[i]) return pa.nums[i] - pb.nums[i]
  if (pa.pre === pb.pre) return 0
  if (!pa.pre) return 1
  if (!pb.pre) return -1
  return pa.pre.localeCompare(pb.pre)
}

export class MarketService extends Service {
  constructor(ctx, options = {}) {
    // 必须继承 Service 并以 super(ctx,'market') 注册：cordis 不允许插件直接
    // 往 ctx 上赋一个未声明的服务名（会报 cannot set property "market" without provide）
    super(ctx, 'market')
    this.ctx = ctx
    this.dataDir = options.dataDir ?? ctx.paths?.dataOf('market') ?? path.join(process.cwd(), 'data', 'market')
    this.configPath = path.join(this.dataDir, 'config.json')
    this.config = { ...DEFAULT_CONFIG, ...options }
    this.index = null          // market.json 内容
    this.indexAt = 0           // 拉取时间戳（缓存用）
    this.preferredMirror = null
  }

  async loadConfig() {
    try {
      const raw = await fs.readFile(this.configPath, 'utf8')
      this.config = { ...DEFAULT_CONFIG, ...JSON.parse(raw) }
    } catch {
      await this.saveConfig()
    }
    return this.config
  }

  async saveConfig() {
    await fs.mkdir(this.dataDir, { recursive: true })
    await fs.writeFile(this.configPath, JSON.stringify(this.config, null, 2), 'utf8')
  }

  /** 候选基址顺序：成功的镜像优先，其余按配置顺序 */
  baseUrls() {
    const override = String(this.config.mirrorOverride || '').trim()
    if (override) {
      // 覆盖模式下只用一个基址（自建镜像/内网/本地联调），不再尝试公共镜像
      return [{ id: 'override', base: override.replace(/\/+$/, '') }]
    }
    const order = (this.config.mirrorOrder || DEFAULT_CONFIG.mirrorOrder).filter((id) => MIRRORS[id])
    const rest = Object.keys(MIRRORS).filter((id) => !order.includes(id))
    const list = this.preferredMirror
      ? [this.preferredMirror, ...order.filter((i) => i !== this.preferredMirror), ...rest]
      : [...order, ...rest]
    return list.map((id) => ({
      id,
      base: MIRRORS[id].replace('{repo}', this.config.repo).replace('{branch}', this.config.branch),
    }))
  }

  async fetchWithTimeout(url, timeoutMs) {
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), timeoutMs)
    try {
      const res = await fetch(url, { signal: ctrl.signal, redirect: 'follow' })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      return Buffer.from(await res.arrayBuffer())
    } finally {
      clearTimeout(timer)
    }
  }

  /** 拉索引：localDir 优先；在线按镜像逐个尝试 */
  async fetchIndex(force = false) {
    const now = Date.now()
    if (!force && this.index && now - this.indexAt < (this.config.cacheTtlMs || DEFAULT_CONFIG.cacheTtlMs)) {
      return this.index
    }
    const localDir = String(this.config.localDir || '').trim()
    if (localDir) {
      const file = path.join(localDir, 'market.json')
      this.index = JSON.parse(await fs.readFile(file, 'utf8'))
      this.indexAt = now
      return this.index
    }
    const errors = []
    for (const { id, base } of this.baseUrls()) {
      try {
        const buf = await this.fetchWithTimeout(`${base}/market.json`, this.config.timeoutMs || 20000)
        this.index = JSON.parse(buf.toString('utf8'))
        this.indexAt = now
        if (this.preferredMirror !== id) {
          this.preferredMirror = id
          console.log(`[market] 索引来源镜像: ${id}`)
        }
        return this.index
      } catch (err) {
        errors.push(`${id}: ${err.message}`)
      }
    }
    throw new Error('拉取 market.json 失败（已尝试 ' + errors.join(' | ') + '）')
  }

  /** 取发行包字节（本地或在线），并校验 sha256 */
  async fetchPackage(entry, { verify = true } = {}) {
    const localDir = String(this.config.localDir || '').trim()
    let buf
    let from
    if (localDir) {
      const file = path.join(localDir, entry.url.split('/').join(path.sep))
      buf = await fs.readFile(file)
      from = file
    } else {
      const errors = []
      for (const { id, base } of this.baseUrls()) {
        try {
          buf = await this.fetchWithTimeout(`${base}/${entry.url}`, this.config.timeoutMs || 20000)
          from = `${id}:${entry.url}`
          this.preferredMirror = id
          break
        } catch (err) {
          errors.push(`${id}: ${err.message}`)
        }
      }
      if (!buf) throw new Error('下载发行包失败（已尝试 ' + errors.join(' | ') + '）')
    }
    if (verify && entry.sha256) {
      const got = sha256(buf)
      if (got !== entry.sha256) {
        throw new Error(`sha256 校验失败: 期望 ${entry.sha256.slice(0, 16)}… 实际 ${got.slice(0, 16)}…`)
      }
    }
    return { buf, from, size: buf.length }
  }

  /** 市场索引与本地已装状态对比 */
  async list(force = false) {
    const index = await this.fetchIndex(force)
    const installed = new Map((this.ctx.plugins?.entries || []).map((e) => [e.name, e]))
    const favorites = new Set(this.config.favorites || [])
    return (index.packages || []).map((p) => {
      const cur = installed.get(p.name)
      const installedVersion = cur?.version || null
      const hasUpdate = installedVersion ? compareVersions(p.version, installedVersion) > 0 : false
      return {
        name: p.name,
        version: p.version,
        description: p.description || '',
        author: p.author || null,
        // 分类标签（索引里可选；老索引没有该字段时为空数组，前端据此不渲染标签区）
        tags: Array.isArray(p.tags) ? p.tags.filter((t) => typeof t === 'string' && t.trim()) : [],
        bundled: p.bundled === true,
        hasClient: p.hasClient === true,
        dll: p.dll || [],
        // DLL 下发模式（三态，缺省 all）：all=自动下发所有 enabled 服务器 / ask=安装时弹窗让用户选 / manual=全程静默不下发
        deploy: ['all', 'ask', 'manual'].includes(p.deploy) ? p.deploy : 'all',
        size: p.size || 0,
        publishedAt: p.publishedAt || null,
        installed: Boolean(cur),
        installedVersion,
        hasUpdate,
        origin: cur?.source || null,
        favorite: favorites.has(p.name),
        // 市场自身：前端据此标出"这是市场"，更新它时提示"刷新页面后生效"
        self: p.name === SELF_NAME,
      }
    })
  }

  /** 收藏 / 取消收藏（持久化到 market config.json） */
  async setFavorite(name, on) {
    const plugin = String(name || '').trim()
    if (!plugin) throw new Error('缺少插件名')
    const set = new Set(this.config.favorites || [])
    if (on) set.add(plugin)
    else set.delete(plugin)
    this.config.favorites = [...set]
    await this.saveConfig()
    return { name: plugin, favorite: on, favorites: this.config.favorites }
  }

  findEntry(index, name) {
    const hit = (index.packages || []).find((p) => p.name === name)
    if (!hit) throw new Error(`市场中不存在插件: ${name}`)
    return hit
  }

  /** 安装：下载 -> 校验 -> installFromTgz -> 按 tsweb.deploy 模式决定 DLL 下发 */
  async install(name, opts = {}) {
    const index = await this.fetchIndex()
    const entry = this.findEntry(index, name)
    const existing = (this.ctx.plugins.entries || []).find((e) => e.name === name)
    if (existing) {
      // 登记在、目录已删（手工删目录/上次中断/换机器）→ 允许重新安装；目录健在才要求走 update
      const dirOk = await this.ctx.plugins.dirExists(name)
      if (dirOk) {
        throw new Error(`${name} 已安装（v${existing.version}），如需升级请用 update`)
      }
      console.log(`[market] 登记存在但目录缺失，按重新安装处理: ${name}`)
    }
    const { buf, from } = await this.fetchPackage(entry)
    console.log(`[market] 安装 ${name}@${entry.version}（${human(buf.length)}，来源 ${from}）`)
    const created = await this.ctx.plugins.installFromTgz(buf, { enable: true, source: 'market' })
    const result = await this.deployToServers(name, entry, opts.serverIds)
    return { name, version: created.version, from, deployed: result.deployed, deployMode: result.mode, deploySkipped: result.skipped }
  }

  /** 更新：下载 -> 校验 -> updateFromTgz（失败自动回滚） */
  async update(name, opts = {}) {
    const index = await this.fetchIndex()
    const entry = this.findEntry(index, name)
    const existing = (this.ctx.plugins.entries || []).find((e) => e.name === name)
    if (!existing) throw new Error(`${name} 未安装，请用 install`)
    if (compareVersions(entry.version, existing.version) <= 0) {
      throw new Error(`已是最新或非向前版本：本地 v${existing.version}，市场 v${entry.version}`)
    }
    const { buf, from } = await this.fetchPackage(entry)
    console.log(`[market] 更新 ${name} ${existing.version} -> ${entry.version}（来源 ${from}）`)
    const result = await this.ctx.plugins.updateFromTgz(name, buf)
    /**
     * 更新后的下发目标。
     *
     * updateFromTgz 只替换本地插件目录（并**保留** entry.servers），所以这里必须补上重推，
     * 否则会出现"登记表说已下发、服务器上跑的还是旧 DLL"：
     *  - 显式指定（面板勾选 / ask 弹窗）→ 照办；
     *  - mode === 'all' → 保持其语义（自动铺满所有 enabled 服务器）；
     *  - 其余（ask / manual）→ 只重推记录为 loaded 的服务器，因为这些正是用户当初
     *    明确下发过的目标。不给 mode=all 之外的模式扩散，避免把插件推给从未装过它的服务器。
     *  为什么不连 offline 一起推：它们会在重连时按**当前文件**自动重发
     *  （registry 的 push/connected 处理），此刻硬推会失败并把状态从 offline 改成 error:，
     *  反而丢掉"重连恢复"这个能力。
     */
    const mode = await this.resolveDeployMode(name, entry)
    const alreadyDeployed = Object.entries(existing.servers || {})
      .filter(([, st]) => st === 'loaded')
      .map(([sid]) => sid)
    /**
     * 自动重推只打**当前有活跃下行通道**的服务器。
     *
     * 离线机器此刻推必然失败，而失败会把该 (插件,服务器) 的状态从 loaded 改写成
     * `error: …`（registry.deploy 的 catch 分支），于是永久丢掉"重连时按**新文件**
     * 自动重发"这个能力（push/connected 只对 loaded / offline 重发）——一次瞬时
     * 失败换来必须手动重新下发。离线的那几台保持原状即可，重连时自己会补上。
     * 显式指定的目标（面板勾选 / ask 弹窗）不做这层过滤：用户已经明确表态，
     * 失败也要如实回报。
     */
    const inferred = alreadyDeployed.filter((sid) => this.ctx.push?.hasChannel?.(sid) !== false)
    const deployTargets = (opts.serverIds !== undefined && opts.serverIds !== null)
      ? opts.serverIds
      : (mode === 'all' ? undefined : inferred)
    if (Array.isArray(deployTargets) && deployTargets.length > 0) {
      console.log(`[market] 更新后重推 DLL 到原先已下发的 ${deployTargets.length} 台服务器（模式 ${mode}）：${deployTargets.join(', ')}`)
    }
    const deploy = await this.deployToServers(name, entry, deployTargets)
    return { ...result, from, deployed: deploy.deployed, deployMode: deploy.mode, deploySkipped: deploy.skipped }
  }

  /**
   * 自更新的前半段：只做**不碰磁盘**的准备（查索引 → 比版本 → 下载 → 校验 sha256）。
   *
   * 为什么必须拆成两段：自更新会替换掉**正在服务这个请求的插件自己**——
   * updateFromTgz 内部是 disable(name) → 换目录 → enable(name)（src/registry.js）。
   * 若合成一段（先替换、再响应），替换之后 svc.update 还要用**已被销毁的旧实例**
   * 去跑 deployToServers；那里一旦抛错，路由的 catch 会把错误当 400 返回——
   * **更新其实成功了，界面却报失败**。
   * 所以路由必须"先把成功响应发出去，再执行替换"，与 dsh-market 的自我卸载同款次序范式
   * （它也是响应发出之后才 setTimeout 关掉自己的 entry）。
   */
  async prepareSelfUpdate() {
    const index = await this.fetchIndex()
    const entry = this.findEntry(index, SELF_NAME)
    const existing = (this.ctx.plugins?.entries || []).find((e) => e.name === SELF_NAME)
    if (!existing) throw new Error(`插件未登记，无法自更新: ${SELF_NAME}`)
    if (compareVersions(entry.version, existing.version) <= 0) {
      throw new Error(`已是最新或非向前版本：本地 v${existing.version}，市场 v${entry.version}`)
    }
    const { buf, from, size } = await this.fetchPackage(entry)
    return { buf, from, size, before: existing.version, to: entry.version }
  }

  /**
   * 自更新的后半段：**响应已发出之后**才调用。此时抛错已无法回写响应，只记日志。
   *
   * 刻意不做 DLL 下发：市场自身没有 C# 半（登记表里 dlls 为空），而 deployToServers
   * 恰恰就是那个要用被销毁旧实例的步骤——跳过它同时也避开了这个坑。
   */
  async applySelfUpdate(plan) {
    try {
      console.log(`[market] 自更新 ${SELF_NAME} v${plan.before} -> v${plan.to}（来源 ${plan.from}）`)
      const result = await this.ctx.plugins.updateFromTgz(SELF_NAME, plan.buf)
      console.log(`[market] 自更新完成 v${result.to}；服务端半已热重载，前端半需刷新页面后生效`)
      return result
    } catch (err) {
      console.error(`[market] 自更新失败（已回滚到 v${plan.before}）: ${err.message}`)
      throw err
    }
  }

  /** 卸载（含从服务器撤下 DLL，若曾下发） */
  async uninstall(name, opts = {}) {
    const entry = (this.ctx.plugins.entries || []).find((e) => e.name === name)
    if (!entry) throw new Error(`${name} 未安装`)
    const undeployed = []
    for (const [serverId, state] of Object.entries(entry.servers || {})) {
      if (state !== 'loaded') continue
      try {
        await this.ctx.plugins.undeploy(name, serverId)
        undeployed.push(serverId)
      } catch (err) {
        console.error(`[market] 从服务器撤下失败 ${serverId}: ${err.message}`)
      }
    }
    await this.ctx.plugins.uninstall(name)
    return { name, undeployed }
  }

  /**
   * 解析插件的 DLL 下发模式（三态）：
   *   - 优先读已安装包内 package.json 的 tsweb.deploy（权威，安装/更新后即存在）
   *   - 回退 market.json 条目里的 deploy（安装前、或包内缺失时）
   *   - 再回退 'all'（与旧包/未声明行为一致）
   */
  async resolveDeployMode(name, marketEntry) {
    let pkg = null
    try {
      const pkgFile = path.join(this.ctx.plugins.pluginsDir, name, 'package.json')
      pkg = JSON.parse(await fs.readFile(pkgFile, 'utf8'))
    } catch { /* 包内缺失，回退 market entry */ }
    const raw = pkg?.tsweb?.deploy ?? marketEntry?.deploy ?? 'all'
    return ['all', 'ask', 'manual'].includes(raw) ? raw : 'all'
  }

  /**
   * 把插件包内的 DLL 下发到目标服务器并热加载。
   * 按 tsweb.deploy 三态决策目标（失败不影响后端安装结果，只记录）：
   *   - all    ：未指定时自动下发全部 enabled 服务器；显式 serverIds 则只下发指定
   *   - ask    ：未指定时跳过下发（前端弹窗勾选后以显式 serverIds 传入）
   *   - manual ：未指定时跳过下发（全程静默）；显式 serverIds 可手动逐服下发
   * 注意：三态只描述**本函数在"未指定"时的缺省行为**。update() 走的是另一条路——
   * 它会先把"原先已记录为 loaded 的服务器"作为显式目标传进来（ask/manual 亦然），
   * 以免更新后服务器仍跑旧 DLL 而界面显示"已下发"。详见 update() 里的注释。
   * serverIds 语义（关键）：
   *   - null/undefined  = 未指定，按模式默认决策
   *   - []（显式空数组）= 明确"不下发"（--no-deploy / 前端「不下发」按钮）
   *   - ['id',...]      = 只下发指定服务器
   * 返回 { deployed: string[], mode, skipped }（deployed 保持数组，兼容旧前端 .length）
   */
  async deployToServers(name, marketEntry, serverIds) {
    const globs = marketEntry?.dll || []
    if (globs.length === 0) return { deployed: [], mode: 'none', skipped: false }
    const mode = await this.resolveDeployMode(name, marketEntry)

    // 显式数组（含空数组）= 用户明确指定目标；空数组 = 明确不下发
    if (Array.isArray(serverIds)) {
      if (serverIds.length === 0) return { deployed: [], mode, skipped: true }
      return this._deployTo(name, serverIds, mode)
    }

    // 未指定 → 按模式默认
    if (mode === 'ask' || mode === 'manual') {
      // ask 未显式选择（终端无交互、或 API 未传）→ 跳过下发；manual 全程静默 → 跳过
      return { deployed: [], mode, skipped: true }
    }
    // mode === 'all'：自动下发全部 enabled 服务器
    // ctx.servers 是 cordis 服务，属性访问本身可能抛错（未注入时），必须包在 try 内
    let enabled = []
    try {
      enabled = (this.ctx.servers?.servers || []).filter((s) => s.enabled !== false)
    } catch (err) {
      console.error('[market] 无法读取服务器清单，跳过 DLL 下发: ' + err.message)
      return { deployed: [], mode, skipped: true }
    }
    return this._deployTo(name, enabled.map((s) => s.id), mode)
  }

  /** 实际逐服下发（被 deployToServers 复用；单台下发失败不影响其他台） */
  async _deployTo(name, serverIds, mode) {
    const done = []
    for (const serverId of serverIds) {
      try {
        await this.ctx.plugins.deploy(name, serverId)
        done.push(serverId)
      } catch (err) {
        console.error(`[market] DLL 下发失败 ${name} -> ${serverId}: ${err.message}`)
      }
    }
    return { deployed: done, mode, skipped: false }
  }

  async refresh() {
    this.index = null
    this.indexAt = 0
    const index = await this.fetchIndex(true)
    return { count: (index.packages || []).length, mirror: this.preferredMirror || (this.config.localDir ? 'local' : 'unknown') }
  }
}

export async function apply(ctx, options = {}) {
  try {
    return await applyInner(ctx, options)
  } catch (err) {
    // cordis 对"等待 inject 后才执行"的插件，apply 异常不会冒泡到加载器，必须在此显式记录
    console.error('[market] 初始化失败: ' + err.message)
    if (process.env.TSWEB_DEBUG) console.error(err.stack)
    throw err
  }
}

async function applyInner(ctx, options = {}) {
  if (process.env.TSWEB_DEBUG) console.log('[market][dbg] apply 被调用，开始加载配置')
  const svc = new MarketService(ctx, options)
  await svc.loadConfig()
  ctx.market = svc

  const app = ctx.webServer.app
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]

  app.get('/api/market/list', ...admin, async (req, res) => {
    try {
      // force=1 时绕过索引缓存（面板「刷新索引」用）
      res.json({ success: true, plugins: await svc.list(req.query?.force === '1') })
    } catch (err) {
      res.status(502).json({ error: err.message })
    }
  })

  // 收藏 / 取消收藏（服务端持久化；收藏栏与列表星标共用）
  app.post('/api/market/favorite', ...admin, async (req, res) => {
    try {
      res.json({ success: true, ...(await svc.setFavorite(String(req.body?.name || ''), req.body?.favorite === true)) })
    } catch (err) {
      res.status(400).json({ error: err.message })
    }
  })

  app.post('/api/market/refresh', ...admin, async (_req, res) => {
    try {
      res.json({ success: true, ...(await svc.refresh()) })
    } catch (err) {
      res.status(502).json({ error: err.message })
    }
  })

  app.post('/api/market/install', ...admin, async (req, res) => {
    try {
      res.json({ success: true, ...(await svc.install(String(req.body?.name || ''), { serverIds: req.body?.serverIds || null })) })
    } catch (err) {
      res.status(400).json({ error: err.message })
    }
  })

  app.post('/api/market/update', ...admin, async (req, res) => {
    const target = String(req.body?.name || '')

    /**
     * 自更新：**先把响应发出去，再替换自己**。
     *
     * 见 prepareSelfUpdate 的注释：替换过程会销毁正在服务本请求的插件实例，
     * 所以准备工作（含下载校验）全部在响应之前完成，替换放到响应之后。
     */
    if (target === SELF_NAME) {
      let plan
      try {
        plan = await svc.prepareSelfUpdate()
      } catch (err) {
        res.status(400).json({ error: err.message })
        return
      }
      res.json({
        success: true,
        name: SELF_NAME,
        self: true,
        from: plan.before,
        to: plan.to,
        source: plan.from,
        size: plan.size,
        // 服务端半由 loader 热重载立即生效；前端半仍是页面加载时的旧 bundle，必须刷新
        refreshRequired: true,
        restartRequired: false,
      })
      // 响应已发出，此后才动自己；失败只记日志（市场无 C# 半，无需 DLL 下发）
      setImmediate(() => { svc.applySelfUpdate(plan).catch(() => {}) })
      return
    }

    try {
      const result = await svc.update(target, { serverIds: req.body?.serverIds || null })
      /**
       * 普通更新的生效语义（与自更新同一套双标记）：
       * 后端半由 updateFromTgz 热重载、立即生效；前端半仍是页面加载时的旧 bundle。
       * loader 此时已重新加载出该插件的 clientUrl（带 ?v=），非空即表示它有前端半、需要刷新。
       */
      let refreshRequired = false
      try {
        refreshRequired = Boolean(svc.ctx.plugins?.loader?.loaded?.get?.(target)?.clientUrl)
      } catch { /* 拿不到就按"无需刷新"处理，不因此让更新报错 */ }
      res.json({ success: true, ...result, refreshRequired, restartRequired: false })
    } catch (err) {
      res.status(400).json({ error: err.message })
    }
  })

  app.post('/api/market/uninstall', ...admin, async (req, res) => {
    try {
      res.json({ success: true, ...(await svc.uninstall(String(req.body?.name || ''))) })
    } catch (err) {
      res.status(400).json({ error: err.message })
    }
  })

  // ── 终端命令 ──
  const term = ctx.terminal
  if (term?.register) {
    term.register('market-list', '列出市场插件与本地状态', async () => {
      try {
        const rows = await svc.list()
        if (rows.length === 0) { console.log('（市场暂无插件）'); return }
        for (const r of rows) {
          const st = !r.installed ? `未安装 -> 可装 v${r.version}`
            : r.hasUpdate ? `v${r.installedVersion} -> v${r.version}`
              : `已最新 v${r.installedVersion}`
          console.log(`  ${r.name.padEnd(16)} ${st.padEnd(28)} ${r.bundled ? '[自带]' : ''} ${r.description || ''}`)
        }
      } catch (err) {
        console.error('拉取市场索引失败: ' + err.message)
      }
    })
    term.register('market-install', '从市场安装插件（用法: market-install <name> [--servers id1,id2] [--no-deploy]）', async (args) => {
      if (!args?.[0] || args[0].startsWith('--')) { console.log('用法: market-install <name> [--servers id1,id2] [--no-deploy]'); return }
      try {
        const { serverIds, noDeploy } = parseDeployArgs(args)
        const r = await svc.install(String(args[0]), { serverIds: noDeploy ? [] : serverIds })
        console.log(`已安装 ${r.name}@${r.version}；DLL 下发 ${r.deployed.length} 台`
          + (r.deployMode === 'manual' ? '（插件声明 manual：全程静默，未自动下发）'
            : r.deploySkipped ? `（deploy=${r.deployMode}：未显式指定服务器，跳过下发）` : ''))
      } catch (err) {
        console.error('安装失败: ' + err.message)
      }
    })
    term.register('market-update', '从市场更新插件（用法: market-update <name> [--servers id1,id2] [--no-deploy]）', async (args) => {
      if (!args?.[0] || args[0].startsWith('--')) { console.log('用法: market-update <name> [--servers id1,id2] [--no-deploy]'); return }
      try {
        const { serverIds, noDeploy } = parseDeployArgs(args)
        const r = await svc.update(String(args[0]), { serverIds: noDeploy ? [] : serverIds })
        console.log(`已更新 ${r.name}: ${r.from} -> ${r.to}；DLL 下发 ${r.deployed.length} 台`
          + (r.deployMode === 'manual' ? '（插件声明 manual：全程静默，未自动下发）'
            : r.deploySkipped ? `（deploy=${r.deployMode}：未显式指定服务器，跳过下发）` : ''))
      } catch (err) {
        console.error('更新失败: ' + err.message)
      }
    })
    term.register('market-uninstall', '卸载市场插件（用法: market-uninstall <name>）', async (args) => {
      if (!args?.[0]) { console.log('用法: market-uninstall <name>'); return }
      try {
        const r = await svc.uninstall(String(args[0]))
        console.log(`已卸载 ${r.name}；从 ${r.undeployed.length} 台服务器撤下`)
      } catch (err) {
        console.error('卸载失败: ' + err.message)
      }
    })
    term.register('market-refresh', '强制重拉市场索引', async () => {
      try {
        const r = await svc.refresh()
        console.log(`索引已刷新: ${r.count} 个插件（来源 ${r.mirror}）`)
      } catch (err) {
        console.error('刷新失败: ' + err.message)
      }
    })
  }

  console.log(`[market] 插件市场已就绪（repo=${svc.config.repo} 分支=${svc.config.branch}`
    + (svc.config.localDir ? ` 离线目录=${svc.config.localDir}` : ' 在线模式') + '）')
}
