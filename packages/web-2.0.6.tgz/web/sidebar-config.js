import { mkdir, readFile, writeFile, rename } from "node:fs/promises";
import path from "node:path";
import {
  emptyLayout,
  keyPattern,
  iconPattern,
  FIXED_KEYS,
} from "./navigation-model.js";
import { registerSidebarIcons } from "./sidebar-icons.js";

const invalid = (message) => Object.assign(new Error(message), { status: 400 });
const object = (value) =>
  value && typeof value === "object" && !Array.isArray(value);
const record = (value) => object(value) && Object.keys(value).length <= 2000;
const fields = (value, allowed) =>
  Object.keys(value).every((key) => allowed.includes(key));
export function validateSidebarConfig(body) {
  if (
    !object(body) ||
    body.schema !== 2 ||
    !Number.isSafeInteger(body.revision) ||
    body.revision < 0 ||
    !fields(body, [
      "schema",
      "revision",
      "nodes",
      "overrides",
      "childrenOrder",
    ]) ||
    !record(body.nodes) ||
    !record(body.overrides) ||
    !record(body.childrenOrder) ||
    Object.keys(body.nodes).length + Object.keys(body.overrides).length >
      2000 ||
    Buffer.byteLength(JSON.stringify(body)) > 512 * 1024
  )
    throw invalid("无效的侧边栏配置");
  const result = emptyLayout(body.revision);
  const validKey = (key) =>
    typeof key === "string" && keyPattern.test(key) && !FIXED_KEYS.has(key);
  function properties(value, allowed) {
    if (
      !object(value) ||
      !fields(value, allowed) ||
      (value.title !== undefined &&
        (typeof value.title !== "string" ||
          !value.title.trim() ||
          value.title.length > 60)) ||
      (value.icon !== undefined &&
        (typeof value.icon !== "string" || !iconPattern.test(value.icon))) ||
      (value.parent !== undefined &&
        value.parent !== null &&
        !validKey(value.parent)) ||
      (value.visible !== undefined && typeof value.visible !== "boolean") ||
      (value.defaultOpen !== undefined &&
        typeof value.defaultOpen !== "boolean") ||
      (value.order !== undefined &&
        (!Number.isFinite(value.order) || Math.abs(value.order) > 1000000))
    )
      throw invalid("无效的侧边栏栏位配置");
    return { ...value };
  }
  for (const [key, value] of Object.entries(body.nodes)) {
    if (!/^custom:[a-zA-Z0-9_-]+$/.test(key)) throw invalid("自建栏位标识无效");
    const item = properties(value, [
      "type",
      "title",
      "icon",
      "parent",
      "page",
      "visible",
      "defaultOpen",
    ]);
    if (
      !["group", "link"].includes(item.type) ||
      (item.type === "group" &&
        (!item.title || item.parent != null || item.page !== undefined)) ||
      (item.type === "link" && !validKey(item.page || ""))
    )
      throw invalid("分组只能位于顶层，页面必须指向可调整的分页");
    result.nodes[key] = item;
  }
  for (const [key, value] of Object.entries(body.overrides)) {
    if (!validKey(key) || key.startsWith("custom:"))
      throw invalid("固定页面不能调整");
    const item = properties(value, [
      "title",
      "icon",
      "parent",
      "visible",
      "defaultOpen",
      "order",
    ]);
    if (
      (key.startsWith("shared:") || key === "anti-cheat:tools") &&
      item.parent != null
    )
      throw invalid("分组不能嵌套");
    result.overrides[key] = item;
  }
  for (const [key, item] of Object.entries(result.nodes)) {
    if (item.parent && result.nodes[item.parent]?.type === "link")
      throw invalid("目标必须是分组");
    if (item.parent === key) throw invalid("不能挂载到自身");
  }
  const ordered = new Set();
  for (const [parent, list] of Object.entries(body.childrenOrder)) {
    if (
      (parent !== "$root" && !validKey(parent)) ||
      !Array.isArray(list) ||
      list.length > 2000
    )
      throw invalid("分组顺序无效");
    if (parent !== "$root" && result.nodes[parent]?.type === "link")
      throw invalid("页面不能包含其他栏位");
    for (const key of list) {
      if (!validKey(key) || ordered.has(key))
        throw invalid("栏位顺序重复或无效");
      ordered.add(key);
      const node = result.nodes[key],
        override = result.overrides[key];
      if (
        (node?.type === "group" ||
          key.startsWith("shared:") ||
          key === "anti-cheat:tools") &&
        parent !== "$root"
      )
        throw invalid("分组不能嵌套");
      const explicitParent =
        node && Object.hasOwn(node, "parent")
          ? node.parent
          : override && Object.hasOwn(override, "parent")
            ? override.parent
            : undefined;
      if (
        explicitParent !== undefined &&
        (explicitParent || "$root") !== parent
      )
        throw invalid("栏位位置与顺序不一致");
    }
    result.childrenOrder[parent] = [...list];
  }
  return result;
}

export async function registerSidebarConfig(app, auth, dir) {
  const file = path.join(dir, "sidebar.json");
  let config = emptyLayout();
  try {
    const old = JSON.parse(await readFile(file, "utf8"));
    config = validateSidebarConfig(old);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  let queue = Promise.resolve();
  const edit = auth.requireAdmin();
  const icons = await registerSidebarIcons(app, auth, edit, dir, () => config);
  app.get("/api/web/sidebar", auth.verifyAuth(), (_req, res) =>
    res.json(config),
  );
  app.put("/api/web/sidebar", auth.verifyAuth(), edit, async (req, res) => {
    try {
      const input = validateSidebarConfig(req.body);
      const operation = queue.then(() =>
        icons.exclusive(async () => {
          if (input.revision !== config.revision)
            throw Object.assign(
              new Error("侧边栏配置已被其他管理员更新，请重新加载后保存"),
              { status: 409 },
            );
          await icons.validateReferences(input);
          const next = { ...input, revision: config.revision + 1 };
          await mkdir(dir, { recursive: true });
          await writeFile(file + ".tmp", JSON.stringify(next, null, 2), "utf8");
          await rename(file + ".tmp", file);
          config = next;
          return config;
        }),
      );
      queue = operation.catch(() => {});
      res.json(await operation);
    } catch (error) {
      res
        .status(error.status || 500)
        .json({ error: error.status ? error.message : "侧边栏配置保存失败" });
    }
  });
}
