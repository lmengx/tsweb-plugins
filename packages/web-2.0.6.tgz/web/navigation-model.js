// Pure shared contract: usable by the browser bundle and the packaged web backend.
export const NAV_ORDER = Object.freeze({
  OVERVIEW: 0,
  CONSOLE: 100,
  PLAYERS: 200,
  GROUPS: 300,
  AFTER_BASE: 400,
  MORE_PLUGINS: 800,
});
export const SYSTEM_NAV_ORDER = Object.freeze({
  PLUGINS: 100,
  MARKET: 200,
  ACCOUNTS: 300,
  QQ_BIND: 400,
  IMPORT: 600,
  SIDEBAR: 700,
});
export const FIXED_KEYS = new Set([
  "host:servers",
  "host:plugins",
  "host:accounts",
  "host:sidebar",
  "market:market",
  "qq-bind:qq-bind",
  "legacy-import:legacy-import",
]);
export const keyPattern = /^[a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+$/;
export const iconPattern = /^(?:builtin:[a-zA-Z0-9_-]+|asset:[a-f0-9]{64})$/;
export const emptyLayout = (revision = 0) => ({
  schema: 2,
  revision,
  nodes: {},
  overrides: {},
  childrenOrder: {},
});
export function normalizeLayout(input = {}) {
  if (input.schema === 2) return { ...emptyLayout(), ...input };
  return emptyLayout();
}
