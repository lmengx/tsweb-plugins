import { fail } from './service.js'

function findRound(rounds, keyword) {
  if (!keyword) return rounds.find(r => r.status === 'open')
  const byId = rounds.find(r => r.id === keyword)
  if (byId) return byId
  const exact = rounds.filter(r => r.title === keyword)
  if (exact.length === 1) return exact[0]
  if (/^[1-9]\d*$/.test(keyword) && rounds[Number(keyword) - 1]) return rounds[Number(keyword) - 1]
  const matches = rounds.filter(r => r.title.includes(keyword) || keyword.includes(r.title))
  return matches.length === 1 ? matches[0] : null
}
function findOption(round, value) {
  if (/^\d+$/.test(value)) return round.options[Number(value) - 1]
  const exact = round.options.find(o => o.text === value)
  if (exact) return exact
  const matches = round.options.filter(o => o.text.includes(value) || value.includes(o.text))
  return matches.length === 1 ? matches[0] : null
}
export function parseTarget(rounds, value, propose = false) {
  const clean = String(value || '').trim()
  if (!clean || clean.length > 250) throw fail(400, propose ? '请输入提案内容' : '请输入选项名称或编号')
  // 最长标题优先，支持含空格的轮次名；编号/ID 也可定位轮次。
  const candidates = rounds.flatMap((round, i) => [...new Set([round.title, round.id, String(i + 1)])].map(key => ({ round, key })))
    .filter(({ key }) => clean.startsWith(key + ' ')).sort((a, b) => b.key.length - a.key.length)
  if (candidates.length) {
    const { round, key } = candidates[0]
    if (candidates.filter(item => item.key === key).length > 1) throw fail(400, '轮次名重复，请使用轮次编号')
    const rest = clean.slice(key.length).trim()
    if (propose) return { round, text: rest }
    const option = findOption(round, rest)
    if (option) return { round, option }
    throw fail(400, '该轮次中未找到选项')
  }
  const open = rounds.filter(round => round.status === 'open' && !round.archived)
  if (open.length > 1) throw fail(400, propose ? '多个投票正在进行，请发送「投票提案 投票轮次名 内容」。' : '多个投票正在进行，请发送「投票 投票轮次名 选项」。')
  const first = open[0]
  if (first && !propose) { const option = findOption(first, clean); if (option) return { round: first, option } }
  if (propose && first) return { round: first, text: clean }
  throw fail(400, first ? '未找到选项，请发送「投票」查看' : '当前没有进行中的投票')
}
export function registerBot(qqBind, store, resolve, { present } = {}) {
  const unregister = []
  const meta = (path, method, action) => ({ owner: 'vote', legacy: { path: `/api/bot/${path}`, method }, requireBound: false,
    ...(present ? { present: (result, options) => present(result, { ...options, action }) } : {}) })
  try {
    unregister.push(qqBind.registerCapability('vote.list', async ({ params }) => {
      const rounds = await store.list()
      const keyword = String(params.name || '').trim()
      if (!keyword) return { mode: 'list', rounds }
      // A full round title remains a read, even if it ends with an option number.
      const exact = rounds.filter((round, i) => round.title === keyword || round.id === keyword || String(i + 1) === keyword)
      if (params.resolveCast === true && !exact.length && rounds.some((round, i) => [round.title, round.id, String(i + 1)].some(key => keyword.startsWith(key + ' ')))) {
        parseTarget(rounds, keyword)
        return { mode: 'cast-target', target: keyword }
      }
      const round = findRound(rounds, keyword)
      if (round) return { mode: 'single', round }
      const matches = rounds.filter(r => r.title.includes(keyword) || keyword.includes(r.title))
      if (matches.length) return { mode: 'list', rounds: matches }
      throw fail(404, `未找到投票「${keyword}」`)
    }, meta('votes', 'GET', 'list')))
    for (const action of ['cast', 'propose']) unregister.push(qqBind.registerCapability(`vote.${action}`, async ({ principal, params }) => {
      const qq = String(principal?.qq || params.qq || '').trim()
      if (!/^\d{5,15}$/.test(qq)) throw fail(400, 'QQ 号格式不正确')
      const record = await resolve(qq)
      const identity = record ? { username: record.username, qq, bound: true } : { username: `qq:${qq}`, qq, bound: false }
      const { round, option, text } = parseTarget(await store.list(), action === 'cast' ? params.option : params.text, action === 'propose')
      const result = action === 'cast' ? await store.cast(round.id, identity, option.id) : await store.propose(round.id, identity, text, false)
      const state = (await store.list({ identity })).find(r => r.id === round.id)
      return { status: 'ok', mode: action === 'cast' ? 'voted' : 'proposed', qq, username: identity.username, unbound: !identity.bound,
        ...(action === 'cast' ? { weight: result.vote.weight } : { option: result.option, existing: result.existing }), round: state }
    }, meta(`vote-${action}`, 'POST', action)))
  } catch (error) { unregister.reverse().forEach(off => off()); throw error }
  return () => unregister.reverse().forEach(off => off())
}
