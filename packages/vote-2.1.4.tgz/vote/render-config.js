import { mkdir, readFile, writeFile, rename, rm } from 'node:fs/promises'
import path from 'node:path'
import { randomUUID } from 'node:crypto'

const fail = (status, message) => Object.assign(new Error(message), { status })
export const renderingDefaults = () => ({ enabled: true, theme: 'pixel', accent: '', optionsPerPage: 20, showDescription: true })
export function validateRendering(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw fail(400, '图片样式配置无效')
  const value = { ...renderingDefaults(), ...input }
  if (typeof value.enabled !== 'boolean' || typeof value.showDescription !== 'boolean') throw fail(400, '图片开关必须为布尔值')
  if (!['pixel', 'space', 'cream', 'mist'].includes(value.theme)) throw fail(400, '图片主题无效')
  if (typeof value.accent !== 'string' || (value.accent && !/^#[0-9a-f]{6}$/i.test(value.accent))) throw fail(400, '强调色必须为六位十六进制颜色')
  if (!Number.isInteger(value.optionsPerPage) || value.optionsPerPage < 6 || value.optionsPerPage > 30) throw fail(400, '每页选项数必须在 6 至 30 之间')
  return Object.fromEntries(Object.keys(renderingDefaults()).map(key => [key, value[key]]))
}
export class VoteRenderingConfig {
  constructor(dir) { this.file = path.join(dir, 'rendering.json'); this.config = renderingDefaults(); this.revision = randomUUID(); this.tail = Promise.resolve() }
  async load() {
    try { const stored = JSON.parse(await readFile(this.file, 'utf8')); this.config = validateRendering(stored.config); this.revision = stored.revision || this.revision }
    catch (error) { if (error.code !== 'ENOENT') throw error }
  }
  publicConfig() { return { config: structuredClone(this.config), revision: this.revision } }
  save(input, revision) {
    const job = this.tail.then(async () => {
      if (revision !== this.revision) throw fail(409, '图片样式已被修改，请重新打开后重试')
      const config = validateRendering(input), next = randomUUID(), temporary = this.file + '.' + randomUUID() + '.tmp'
      await mkdir(path.dirname(this.file), { recursive: true })
      try { await writeFile(temporary, JSON.stringify({ config, revision: next }, null, 2) + '\n', { flag: 'wx' }); await rename(temporary, this.file) }
      finally { await rm(temporary, { force: true }).catch(() => {}) }
      this.config = config; this.revision = next
      return this.publicConfig()
    })
    this.tail = job.catch(() => {})
    return job
  }
}
