import { validateRendering } from './render-config.js'
const fail = (status, message) => Object.assign(new Error(message), { status })
const rendererOf = ctx => { try { return ctx.get('qqRenderer') } catch { return null } }
export function registerRendering(app, ctx, settings, store, wrap) {
  const status = () => {
    const renderer = rendererOf(ctx)
    return { ...settings.publicConfig(), engine: { loaded: !!renderer?.registerTemplate, enabled: renderer?.config?.enabled === true } }
  }
  app.get('/api/vote/admin/rendering', wrap(status))
  app.post('/api/vote/admin/rendering', wrap(async req => {
    await settings.save(req.body?.config, req.body?.revision)
    return status()
  }))
  app.post('/api/vote/admin/rendering/preview', wrap(async req => {
    const renderer = rendererOf(ctx)
    if (!renderer?.registerTemplate) throw fail(409, '请到插件市场安装并启用「QQ 图片渲染」引擎')
    const config = validateRendering(req.body?.config)
    const scenario = req.body?.scenario ?? 'sample'
    if (!['sample', 'long', 'current', 'voted', 'proposed'].includes(scenario)) throw fail(400, '预览场景无效')
    let round
    if (scenario === 'current') {
      const current = (await store.list({ admin: true })).find(row => row.id === req.body?.roundId)
      if (!current) throw fail(404, '当前轮次不存在')
      round = Object.fromEntries(['title', 'description', 'status', 'archived', 'createdAt', 'endAt', 'allowProposals', 'maxProposalsPerUser', 'maxVotesPerUser', 'baseWeight', 'weightRules', 'allowUnbound'].map(key => [key, current[key]]))
      round.options = current.options.map(({ id, text, votes, score, type, anonymous }) => ({ id, text, votes, score, type, anonymous }))
    } else {
      round = { title: '下期服务器玩法', status: 'open', createdAt: '2026-11-03T12:00:00Z', endAt: '2026-11-07T12:00:00Z', allowProposals: true, maxProposalsPerUser: 1, maxVotesPerUser: 2, baseWeight: 1, allowUnbound: false, weightRules: [{ field: 'playtime_hours', op: '>=', threshold: 10, weight: .5 }], description: '示例数据：决定下一次周末活动的世界玩法。', options: Array.from({ length: scenario === 'long' ? 45 : 3 }, (_, i) => ({ id: 'sample-' + i, type: 'preset', text: scenario === 'long' ? `选项 ${i + 1}：包含较长描述的服务器玩法，完整显示名称与票数` : ['经典生存', '专家开荒', '建筑共创'][i], votes: [24, 15, 9][i % 3], score: [36, 22.5, 13.5][i % 3] })) }
      if (['voted', 'proposed'].includes(scenario)) round.my = { votedOptions: ['sample-1'], votesLeft: 1, proposalsLeft: scenario === 'proposed' ? 0 : 1, weight: 1.5 }
      if (scenario === 'proposed') round.options.push({ id: 'sample-proposal', text: '大师挑战', type: 'custom', votes: 0, score: 0 })
    }
    const result = await renderer.render('vote/results', { ...config, result: { round, ...(scenario === 'voted' ? { weight: 1.5 } : scenario === 'proposed' ? { option: round.options.at(-1), existing: false } : {}) }, action: scenario === 'voted' ? 'cast' : scenario === 'proposed' ? 'propose' : 'list', preview: true })
    return { images: result.images.map(buffer => 'data:image/png;base64,' + buffer.toString('base64')), pages: result.images.length, sample: scenario !== 'current' }
  }))
}
