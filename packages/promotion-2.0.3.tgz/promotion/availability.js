// QQ 服务可用性检查，不读取旧版配置。
export function optionalService(ctx, name) {
  try {
    if (ctx && typeof ctx.get === 'function') {
      const svc = ctx.get(name)
      if (svc) return svc
    }
  } catch {
    /* 取不到就当没有：软依赖失败一律降级，绝不冒泡成"插件加载失败" */
  }
  try {
    return (ctx && ctx[name]) || null
  } catch {
    /* 未 inject 的 ctx 代理在这里抛错：按"没有该服务"处理 */
    return null
  }
}

/**
 * qq-bind 是否可用（管理页要据此把「QQ 绑定提升」那块显示为"不可用 + 原因"）。
 * 这是**软依赖**：没装 qq-bind 时本件照常工作，「游玩时长提升」完全不受影响。
 */
export function qqBindAvailability(ctx) {
  const svc = optionalService(ctx, 'qqBind')
  if (!svc) {
    return {
      installed: false,
      reason: '未检测到 qq-bind 插件（ctx 上没有 qqBind 服务）：安装并启用 qq-bind 后，'
        + '本插件的「QQ 绑定提升」才能识别已绑定账号；「游玩时长提升」不受影响，可照常使用',
    }
  }
  return { installed: true, reason: '' }
}

