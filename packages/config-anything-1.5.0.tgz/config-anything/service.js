import fs from "node:fs/promises";
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { sortReads } from "./matching.js";

export const httpError = (status, message) =>
  Object.assign(new Error(message), { status });
export class ConfigAnythingService {
  constructor(ctx, files) {
    this.capabilities = Object.freeze({
      sharedDependencies: true,
      unloadPlugin: true,
      chunkedInstall: true,
      logicalPackages: true,
      configurationApply: true,
    });
    this.ctx = ctx;
    this.files = files;
    this.file = path.join(ctx.paths.dataOf("config-anything"), "bindings.json");
    this.bindings = [];
    this.queue = Promise.resolve();
    this.disposed = false;
    this.lifecyclePolicies = new Map();
  }
  async init() {
    let state;
    try {
      state = JSON.parse(await fs.readFile(this.file, "utf8"));
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      return;
    }
    if (state.schema !== 1 || !Array.isArray(state.bindings))
      throw new Error("配置关联数据格式不兼容");
    const ids = new Set();
    for (const row of state.bindings) {
      if (
        !/^[a-f0-9]{24}$/.test(row.id) ||
        ids.has(row.id) ||
        !["serverId", "pluginId", "path", "title", "slot"].every(
          (key) => typeof row[key] === "string" && row[key],
        )
      )
        throw new Error("配置关联数据损坏，请恢复 bindings.json");
      ids.add(row.id);
    }
    this.bindings = state.bindings;
  }
  assertActive() {
    if (this.disposed) throw httpError(503, "配置管理正在停用");
  }
  async persist(next) {
    this.assertActive();
    await fs.mkdir(path.dirname(this.file), { recursive: true });
    const temp = `${this.file}.${randomUUID()}.tmp`;
    try {
      await fs.writeFile(
        temp,
        JSON.stringify({ schema: 1, bindings: next }, null, 2),
        { flag: "wx" },
      );
      this.assertActive();
      await fs.rename(temp, this.file);
      this.bindings = next;
    } finally {
      await fs.rm(temp, { force: true });
    }
  }
  serial(action) {
    const task = this.queue.then(() => {
      this.assertActive();
      return action();
    });
    this.queue = task.catch(() => {});
    return task;
  }
  server(id) {
    this.assertActive();
    if (typeof id !== "string" || !id) throw httpError(400, "请先选择服务器");
    const server = this.ctx.servers.getRaw(id);
    if (!server) throw httpError(404, "服务器不存在");
    return server;
  }
  async remote(id, action, params = {}, signal) {
    signal?.throwIfAborted();
    const server = this.server(id);
    const write =
      ["load", "install", "unload", "reload", "hot-reload"].includes(action) ||
      action.startsWith("install/");
    const response = await this.ctx.tshock[write ? "postFor" : "fetchFor"](
      server,
      `/data/config-anything/${action}`,
      params,
      { timeoutMs: write ? 60000 : 15000, signal },
    );
    this.assertActive();
    const status = Number(response.data?.status || response.status || 502);
    if (!response.ok || status >= 400 || !response.data?.result)
      throw httpError(
        [400, 403, 404, 409, 413].includes(status) ? status : 502,
        response.data?.error ||
          "请确认游戏服已加载 ConfigAnything.dll，并授予 tsweb.configanything.manage",
      );
    return response.data.result;
  }
  async listPlugins(serverId, { signal } = {}) {
    const result = await this.remote(serverId, "plugins", {}, signal);
    if (!Array.isArray(result.plugins))
      throw httpError(502, "游戏服插件列表格式错误");
    return {
      ...result,
      plugins: result.plugins.map((plugin) => {
        const observed = plugin.reads || [];
        const reads = sortReads([
          ...observed,
          ...(plugin.configurationHints || []).filter(hint => !observed.some(read => read.path === hint.path)),
        ], plugin.fileName);
        return {
          ...plugin,
          reads,
          suggestedPath: reads.find((row) => row.rank < 6)?.path || "",
          configurations: this.bindings
            .filter(
              (row) => row.serverId === serverId && row.pluginId === plugin.id,
            )
            .map((row) => this.describe(row)),
        };
      }),
    };
  }
  async loadPlugin(
    serverId,
    { path: dllPath, dependencies = [] } = {},
    { signal } = {},
  ) {
    if (
      typeof dllPath !== "string" ||
      !dllPath ||
      !Array.isArray(dependencies) ||
      dependencies.length > 20 ||
      dependencies.some((file) => typeof file !== "string")
    )
      throw httpError(400, "请输入插件 DLL 路径及依赖文件列表");
    return this.remote(
      serverId,
      "load",
      { path: dllPath, dependencies: JSON.stringify(dependencies) },
      signal,
    );
  }
  describe(row) {
    return {
      ...row,
      permission: `config-anything-${row.id}.config`,
      feature: `config-anything-${row.id}:config`,
      pageId: `config-${row.id}`,
      pagePath: `/s/config-anything/configs/${row.id}`,
    };
  }
  // Trusted package API for other Cordis plugins. Public callers must authorize their own routes.
  async unloadPlugin(
    serverId,
    { assemblyName, reloadableAssemblies } = {},
    { signal } = {},
  ) {
    if (
      typeof assemblyName !== "string" ||
      !assemblyName.trim() ||
      assemblyName.length > 200 ||
      !Array.isArray(reloadableAssemblies) ||
      reloadableAssemblies.length > 100 ||
      reloadableAssemblies.some(
        (name) => typeof name !== "string" || !name || name.length > 200,
      )
    )
      throw httpError(400, "插件卸载参数无效");
    return this.remote(
      serverId,
      "unload",
      {
        assemblyName,
        reloadableAssemblies: JSON.stringify(reloadableAssemblies),
      },
      signal,
    );
  }
  async installPlugin(
    serverId,
    {
      mainFile,
      files,
      sharedDependencies = [],
      replace = false,
      reloadable = true,
    } = {},
    { signal } = {},
  ) {
    if (
      typeof mainFile !== "string" ||
      !Array.isArray(files) ||
      !files.length ||
      files.length > 21 ||
      typeof replace !== "boolean" ||
      typeof reloadable !== "boolean" ||
      !Array.isArray(sharedDependencies) ||
      sharedDependencies.length > 100 ||
      sharedDependencies.some(
        (row) =>
          !row ||
          typeof row.assemblyName !== "string" ||
          !/^[^\\/,:\x00-\x1f]{1,200}$/.test(row.assemblyName) ||
          (row.minimumVersion !== undefined &&
            (typeof row.minimumVersion !== "string" ||
              !/^\d+(\.\d+){1,3}$/.test(row.minimumVersion))),
      )
    )
      throw httpError(400, "插件包参数无效");
    let total = 0;
    const names = new Set();
    const blobs = files.map(({ fileName, bytes }) => {
      if (
        typeof fileName !== "string" ||
        !/^[^\\/:\x00-\x1f]+\.dll$/i.test(fileName) ||
        names.has(fileName.toLowerCase()) ||
        !Buffer.isBuffer(bytes) ||
        !bytes.length ||
        bytes.length > 20 * 1024 * 1024 ||
        (total += bytes.length) > 50 * 1024 * 1024
      )
        throw httpError(400, "插件包文件名、大小或内容无效");
      names.add(fileName.toLowerCase());
      return {
        fileName,
        base64: bytes.toString("base64"),
        sha256: createHash("sha256").update(bytes).digest("hex"),
      };
    });
    if (!files.some((file) => file.fileName === mainFile))
      throw httpError(400, "插件包缺少主 DLL");
    const params = {
      mainFile,
      files: JSON.stringify(blobs),
      replace: String(replace),
      reloadable: String(reloadable),
      sharedDependencies: JSON.stringify(
        sharedDependencies.map(({ assemblyName, minimumVersion }) => ({
          assemblyName,
          minimumVersion,
        })),
      ),
    };
    // The TShock HTTP library can close connections after a full 64 KiB read.
    // Keep forms below half of its receive buffer; base64url avoids percent expansion.
    if (Buffer.byteLength(new URLSearchParams(params).toString()) <= 24 * 1024)
      return this.remote(serverId, "install", params, signal);
    const bytes = Buffer.from(JSON.stringify(params));
    let uploadId;
    let stage = "创建上传任务";
    try {
      const upload = await this.remote(
        serverId,
        "install/begin",
        {
          length: String(bytes.length),
          sha256: createHash("sha256").update(bytes).digest("hex"),
        },
        signal,
      );
      if (
        typeof upload.uploadId !== "string" ||
        !/^[a-f0-9]{32}$/.test(upload.uploadId)
      )
        throw httpError(502, "游戏服返回的上传任务无效");
      uploadId = upload.uploadId;
      const chunkBytes = 12 * 1024;
      for (let offset = 0; offset < bytes.length; offset += chunkBytes) {
        stage = `上传 DLL 分块 ${Math.floor(offset / chunkBytes) + 1}/${Math.ceil(bytes.length / chunkBytes)}`;
        const part = bytes.subarray(offset, offset + chunkBytes);
        const result = await this.remote(
          serverId,
          "install/chunk",
          {
            uploadId,
            offset: String(offset),
            data: part.toString("base64url"),
          },
          signal,
        );
        if (result.received !== offset + part.length)
          throw httpError(502, "游戏服接收分块长度不一致");
      }
      stage = "校验并加载插件";
      const result = await this.remote(
        serverId,
        "install/commit",
        { uploadId },
        signal,
      );
      uploadId = null;
      return result;
    } catch (err) {
      if (err.name === "AbortError" || signal?.aborted) throw err;
      throw httpError(
        err.status || 502,
        `${stage}失败：${err.status === 404 && !uploadId ? "请更新游戏服 ConfigAnything.dll 至 1.3.1 或以上" : err.message}`,
      );
    } finally {
      if (uploadId)
        await this.remote(
          serverId,
          "install/abort",
          { uploadId },
          AbortSignal.timeout(5000),
        ).catch(() => {});
    }
  }
  allowed(user, row) {
    const access = this.ctx.auth.access;
    return (
      this.ctx.auth.canAccessServer(user, row.serverId) &&
      access.hasModule(user, access.module(`config-anything-${row.id}.config`))
    );
  }
  listConfigurations(serverId, user) {
    this.server(serverId);
    return this.bindings
      .filter(
        (row) =>
          row.serverId === serverId && (!user || this.allowed(user, row)),
      )
      .map((row) => this.describe(row));
  }
  getConfiguration(id, serverId) {
    this.server(serverId);
    const row = this.bindings.find((binding) => binding.id === id);
    if (!row) throw httpError(404, "配置页面不存在");
    if (row.serverId !== serverId)
      throw httpError(403, "此配置属于另一台服务器");
    return row;
  }
  registerLifecyclePolicy(owner, resolver) {
    this.lifecyclePolicies.set(owner, resolver);
    return () => { if (this.lifecyclePolicies.get(owner) === resolver) this.lifecyclePolicies.delete(owner); };
  }
  async configurationRuntime(id, serverId, { signal } = {}) {
    const row = this.getConfiguration(id, serverId);
    const state = await this.remote(serverId, "runtime", { pluginId: row.pluginId }, signal);
    if (state.pluginId !== row.pluginId || typeof state.reloadHandlerCount !== "number")
      throw httpError(502, "插件状态接口不兼容，请更新游戏服 ConfigAnything.dll");
    for (const resolve of this.lifecyclePolicies.values()) {
      const policy = await resolve(state.assemblyName);
      if (policy?.hotReload === false) {
        state.hotReloadAvailable = false;
        state.hotReloadReason = "APM 清单标记此插件不支持热重载";
      }
    }
    return state;
  }
  async applyConfiguration(id, serverId, action, { revision, version } = {}, { signal } = {}) {
    if (!["reload", "hotReload"].includes(action)) throw httpError(400, "配置生效操作无效");
    return this.serial(async () => {
      const row = this.getConfiguration(id, serverId);
      if (revision !== row.revision) throw httpError(409, "配置关联已变化，请重新打开页面");
      if (typeof version !== "string" || !version) throw httpError(400, "请先保存配置并提供文件版本");
      const resolved = await this.remote(serverId, "resolve", { pluginId: row.pluginId, path: row.path }, signal);
      const current = await this.files.remote(this.server(serverId), "read", { path: resolved.filePath }, { signal });
      if (current.version !== version) throw httpError(409, "配置文件已变化，请重新读取后再生效");
      const state = await this.configurationRuntime(id, serverId, { signal });
      if (action === "reload" && !state.reloadSubscribed) throw httpError(409, "目标插件未检测到 Reload 订阅，请使用热重载");
      if (action === "hotReload" && !state.hotReloadAvailable) throw httpError(409, state.hotReloadReason || "此插件当前无法热重载");
      signal?.throwIfAborted();
      return this.remote(serverId, action === "reload" ? "reload" : "hot-reload", { pluginId: row.pluginId }, signal);
    });
  }
  async registerConfiguration(
    {
      serverId,
      pluginId,
      path: configPath,
      title,
      slot = "main",
      sidebar = true,
    },
    { signal } = {},
  ) {
    if (
      typeof sidebar !== "boolean" ||
      typeof pluginId !== "string" ||
      !pluginId ||
      typeof configPath !== "string" ||
      !configPath ||
      typeof slot !== "string" ||
      !/^[a-zA-Z0-9_-]{1,64}$/.test(slot) ||
      (title != null &&
        (typeof title !== "string" || !title.trim() || title.length > 100))
    )
      throw httpError(400, "请选择插件并指定配置文件");
    // The game process resolves the actual SavePath and rejects config.json, traversal and links.
    const resolved = await this.remote(
      serverId,
      "resolve",
      { pluginId, path: configPath },
      signal,
    );
    await this.files.remote(
      this.server(serverId),
      "read",
      { path: resolved.filePath },
      { signal },
    );
    return this.serial(async () => {
      const id = createHash("sha256")
        .update(JSON.stringify([serverId, pluginId, slot]))
        .digest("hex")
        .slice(0, 24);
      const previous = this.bindings.find((row) => row.id === id);
      const row = {
        id,
        serverId,
        serverName: this.server(serverId).name || serverId,
        pluginId,
        pluginName: resolved.pluginName,
        slot,
        sidebar,
        path: resolved.path,
        title:
          title?.trim() || previous?.title || `${resolved.pluginName} 配置`,
        revision: (previous?.revision || 0) + 1,
      };
      this.mount?.(row); // An owned router contains these runtime routes.
      try {
        await this.persist([
          ...this.bindings.filter((item) => item.id !== id),
          row,
        ]);
      } catch (error) {
        this.unmount?.(id);
        if (previous) this.mount?.(previous);
        throw error;
      }
      return this.describe(row);
    });
  }
  async unregisterConfiguration(id, serverId) {
    return this.serial(async () => {
      this.getConfiguration(id, serverId);
      await this.persist(this.bindings.filter((row) => row.id !== id));
      this.unmount?.(id);
      return { removed: true };
    });
  }
  async readConfiguration(id, serverId, { signal } = {}) {
    const row = this.getConfiguration(id, serverId);
    const resolved = await this.remote(
      serverId,
      "resolve",
      { pluginId: row.pluginId, path: row.path },
      signal,
    );
    const value = await this.files.remote(
      this.server(serverId),
      "read",
      { path: resolved.filePath },
      { signal },
    );
    let runtime;
    try { runtime = await this.configurationRuntime(id, serverId, { signal }); }
    catch (error) {
      if (signal?.aborted) throw error;
      runtime = { unavailableReason: error.message };
    }
    return { ...value, binding: this.describe(row), runtime };
  }
  async writeConfiguration(
    id,
    serverId,
    { content, version, revision } = {},
    { signal } = {},
  ) {
    const row = this.getConfiguration(id, serverId);
    if (revision !== row.revision)
      throw httpError(409, "配置关联已变化，请重新打开页面");
    if (
      typeof content !== "string" ||
      Buffer.byteLength(content) > 5 * 1024 * 1024 ||
      typeof version !== "string" ||
      !version
    )
      throw httpError(400, "请提交有效文本及文件版本，最大支持 5 MB");
    if (/\.json$/i.test(row.path)) {
      try {
        JSON.parse(content.replace(/^\uFEFF/, ""));
      } catch {
        throw httpError(400, "JSON 格式有误，请修正后再保存");
      }
    }
    // Serialize with rebinding/removal so an in-flight request cannot write a previous target.
    return this.serial(async () => {
      if (this.getConfiguration(id, serverId).revision !== revision)
        throw httpError(409, "配置关联已变化");
      const resolved = await this.remote(
        serverId,
        "resolve",
        { pluginId: row.pluginId, path: row.path },
        signal,
      );
      const result = await this.files.remote(
        this.server(serverId),
        "write",
        { path: resolved.filePath, content, version },
        { write: true, signal },
      );
      return { ...result, saved: true, binding: this.describe(row) };
    });
  }
}
