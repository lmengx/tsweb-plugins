const actions = [
  ["plugins", "GET", "/api/config-anything/plugins"],
  ["load", "POST", "/api/config-anything/load"],
  ["register", "POST", "/api/config-anything/bindings"],
  ["remove", "DELETE", "/api/config-anything/bindings/:id"],
];
export default {
  owner: "config-anything",
  version: 2,
  modules: [
    {
      id: "config-anything.manage",
      permission: "config-anything.manage",
      title: "原生插件与配置关联",
      roles: ["superadmin"],
      superadminOnly: true,
      scope: "server",
      requires: actions.map(([id]) => `config-anything.${id}`),
    },
    {
      id: "config-anything.catalog",
      permission: "config-anything.catalog",
      title: "已授权配置页面",
      roles: ["superadmin", "admin", "subadmin", "custom"],
      grantable: false,
      scope: "server",
      requires: ["config-anything.bindings"],
    },
  ],
  actions: [
    ...actions.map(([id, method, path]) => ({
      id: `config-anything.${id}`,
      module: "config-anything.manage",
      method,
      path,
      scope: "server",
    })),
    {
      id: "config-anything.bindings",
      module: "config-anything.catalog",
      method: "GET",
      path: "/api/config-anything/bindings",
      scope: "server",
    },
  ],
  features: [
    {
      id: "config-anything:manage",
      module: "config-anything.manage",
      requires: actions.map(([id]) => `config-anything.${id}`),
    },
  ],
};

// Each confirmed configuration is one business module, not a set of API grants.
export function configurationContract(binding) {
  const owner = `config-anything-${binding.id}`,
    module = `${owner}.config`;
  const path = `/api/config-anything/configs/${binding.id}`;
  const endpoints = [["read", "GET", path], ["write", "PUT", path], ["runtime", "GET", `${path}/runtime`],
    ["reload", "POST", `${path}/reload`], ["hot-reload", "POST", `${path}/hot-reload`]];
  const requires = endpoints.map(([action]) => `${owner}.${action}`);
  return {
    owner,
    version: 2,
    modules: [
      {
        id: module,
        permission: module,
        title: `${binding.title} · ${binding.serverName || binding.serverId}`,
        roles: ["superadmin"],
        scope: "server",
        requires,
      },
    ],
    actions: endpoints.map(([action, method, path]) => ({
      id: `${owner}.${action}`,
      module,
      method,
      path,
      scope: "server",
    })),
    features: [
      {
        id: `${owner}:config`,
        module,
        requires,
      },
    ],
  };
}
