const han = /\p{Script=Han}/u;
export function matchRank(path, pluginFile) {
  const name = String(path).replaceAll("\\", "/").split("/").at(-1) || "";
  if (!/\.(json|txt)$/i.test(name)) return 6;
  const stem = name.replace(/\.[^.]+$/, "").toLowerCase();
  const plugin = String(pluginFile || "")
    .replaceAll("\\", "/")
    .split("/")
    .at(-1)
    .replace(/\.dll$/i, "")
    .toLowerCase();
  if (plugin && stem === plugin) return 0;
  if (plugin && stem.includes(plugin)) return 1;
  if (/config|配置/i.test(name)) return 2;
  if (han.test(name)) return 3;
  if (/zh-cn/i.test(name)) return 4;
  return 5;
}
export function sortReads(reads, pluginFile) {
  const seen = new Set();
  return reads
    .filter((row) => {
      const path = String(row.path).replaceAll("\\", "/");
      if (path.toLowerCase() === "config.json" || seen.has(path)) return false;
      seen.add(path);
      return true;
    })
    .map((row, index) => ({
      ...row,
      rank: matchRank(row.path, pluginFile),
      index,
    }))
    .sort(
      (a, b) =>
        a.rank - b.rank ||
        Number(a.order ?? a.index) - Number(b.order ?? b.index),
    );
}
export function highlightParts(text, pluginFile) {
  const plugin = String(pluginFile || "").replace(/\.dll$/i, "");
  const escape = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const pattern = new RegExp(
    [plugin && escape(plugin), "zh-CN", "config", "配置", "json", "txt"]
      .filter(Boolean)
      .join("|"),
    "gi",
  );
  const result = [];
  let start = 0;
  for (const match of String(text).matchAll(pattern)) {
    if (match.index > start)
      result.push({ text: text.slice(start, match.index), match: false });
    result.push({ text: match[0], match: true });
    start = match.index + match[0].length;
  }
  if (start < text.length)
    result.push({ text: text.slice(start), match: false });
  return result;
}
