import { Service } from "@deepseek-ai/cordis";
import express from "express";
const revision = new URL(import.meta.url).search;
const { default: contract, configurationContract } = await import(
  `./access.js${revision}`
);
const { ConfigAnythingService, httpError } = await import(
  `./service.js${revision}`
);

export const name = "config-anything";
export const inject = ["webServer", "auth", "servers", "tshock", "paths"];
class Foundation extends Service {
  constructor(ctx, service) {
    super(ctx, "configAnything");
    this.capabilities = service.capabilities;
    for (const method of [
      "listPlugins",
      "loadPlugin",
      "installPlugin",
      "unloadPlugin",
      "registerConfiguration",
      "unregisterConfiguration",
      "listConfigurations",
      "getConfiguration",
      "readConfiguration",
      "writeConfiguration",
      "configurationRuntime",
      "applyConfiguration",
      "registerLifecyclePolicy",
    ])
      this[method] = service[method].bind(service);
  }
}
export async function apply(ctx) {
  const mounted = new Map(),
    controllers = new Set();
  let service, files;
  try {
    // Reuse the file-manager implementation without granting its public routes to the user.
    const { FileManagerService } = await import(
      `../file-manager/service.js${revision}`
    );
    files = new FileManagerService(ctx);
    service = new ConfigAnythingService(ctx, files);
    const dispose = () => {
      service.disposed = true;
      for (const controller of controllers) controller.abort();
      for (const id of [...mounted.keys()]) service.unmount(id);
      files.dispose();
    };
    ctx.effect(() => dispose);
    await service.init();
    const app = ctx.auth.access.policyApp(ctx.webServer.app, contract, ctx);
    const router = express.Router();
    // Only this parent layer is mounted on Express; dynamic child routes remain owned by it.
    app.use(router);
    const wrap = (handler) => async (req, res) => {
      const controller = new AbortController();
      controllers.add(controller);
      const close = () => {
        if (!res.writableFinished) controller.abort();
      };
      res.on("close", close);
      try {
        const id = req.headers["x-server-id"];
        service.server(id);
        const result = await handler(req, id, controller.signal);
        if (!res.destroyed) res.json(result);
      } catch (error) {
        if (!res.destroyed)
          res.status(error.status || 502).json({ error: error.message });
      } finally {
        controllers.delete(controller);
        res.off("close", close);
      }
    };
    service.unmount = (id) => {
      const entry = mounted.get(id);
      if (!entry) return;
      for (const cleanup of entry.cleanups.reverse()) cleanup();
      router.stack = router.stack.filter(
        (layer) => !entry.layers.includes(layer),
      );
      mounted.delete(id);
    };
    service.mount = (row) => {
      service.unmount(row.id);
      const cleanups = [],
        before = new Set(router.stack);
      const owned = {
        effect(fn) {
          const cleanup = fn();
          if (typeof cleanup === "function") cleanups.push(cleanup);
        },
      };
      try {
        const policy = ctx.auth.access.policyApp(
          router,
          configurationContract(row),
          owned,
        );
        const target = `/api/config-anything/configs/${row.id}`;
        policy.get(
          target,
          wrap((req, id, signal) =>
            service.readConfiguration(row.id, id, { signal }),
          ),
        );
        policy.put(
          target,
          wrap((req, id, signal) => {
            // Extra body fields never replace the server-side confirmed path.
            if ("path" in (req.body || {}) || "serverId" in (req.body || {}))
              throw httpError(400, "请通过配置关联修改目标");
            return service.writeConfiguration(row.id, id, req.body, { signal });
          }),
        );
        policy.get(`${target}/runtime`, wrap((req, id, signal) => service.configurationRuntime(row.id, id, { signal })));
        for (const [suffix, action] of [["reload", "reload"], ["hot-reload", "hotReload"]])
          policy.post(`${target}/${suffix}`, wrap((req, id, signal) => {
            if (Object.keys(req.body || {}).some(key => !["revision", "version"].includes(key)))
              throw httpError(400, "生效操作只能提交配置关联版本和文件版本");
            return service.applyConfiguration(row.id, id, action, req.body, { signal });
          }));
        mounted.set(row.id, {
          cleanups,
          layers: router.stack.filter((layer) => !before.has(layer)),
        });
      } catch (error) {
        for (const cleanup of cleanups.reverse()) cleanup();
        router.stack = router.stack.filter((layer) => before.has(layer));
        throw error;
      }
    };
    for (const row of service.bindings) service.mount(row);
    app.get(
      "/api/config-anything/plugins",
      wrap((req, id, signal) => service.listPlugins(id, { signal })),
    );
    app.post(
      "/api/config-anything/load",
      wrap((req, id, signal) => service.loadPlugin(id, req.body, { signal })),
    );
    app.get(
      "/api/config-anything/bindings",
      wrap((req, id) => ({
        bindings: service.listConfigurations(id, req.user),
      })),
    );
    app.post(
      "/api/config-anything/bindings",
      wrap((req, id, signal) =>
        service.registerConfiguration(
          { ...req.body, serverId: id },
          { signal },
        ),
      ),
    );
    app.delete(
      "/api/config-anything/bindings/:id",
      wrap((req, id) => service.unregisterConfiguration(req.params.id, id)),
    );
    // Lightweight test contexts can omit Service; a real Cordis context always has plugin().
    if (typeof ctx.plugin === "function") {
      new Foundation(ctx, service);
      return;
    }
    return service;
  } catch (error) {
    files?.dispose();
    if (service) {
      service.disposed = true;
      for (const id of [...mounted.keys()]) service.unmount?.(id);
    }
    console.error("[config-anything] 初始化失败：" + error.message);
    throw error;
  }
}
