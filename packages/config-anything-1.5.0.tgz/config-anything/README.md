# config-anything

原生 TShock 插件的加载、配置路径发现与独立授权配置页。APM 浏览器不在本插件中。

## 使用

1. 构建前端 `node scripts/build-client.mjs config-anything web`，构建服端 `dotnet build plugins/config-anything/plugin/ConfigAnything.csproj -c Release`，将产物 `ConfigAnything.dll` 放到本插件 `plugin/` 目录供现有下发机制使用。
2. 配套启用 `file-manager` 及游戏服 `FileManager.dll`。游戏服 REST 账号需要 `tsweb.configanything.manage` 和原有 `tsweb.files.manage`；网页用户不需要通用文件权限。
3. 在「插件配置」查看当前服务器的原生插件，选择候选或直接输入配置路径，确认后生成配置子页。在现有账号权限页单独授予该配置权限，在侧边栏编辑器调整入口并保存。
4. 「加载本地 DLL」接受游戏服 `ServerPlugins` 内的相对路径或绝对路径，以及依赖 DLL 列表，通过现有 TsWebHost 加载。请使用本次带有读取观察通知的 TsWebHost。插件仍须兼容现有 TShock API 和加载器；此功能不会解决插件自身依赖或生命周期缺陷。

## 界面预览

正式入口 `/s/config-anything` 使用左右工作台：左侧插件按最佳候选的匹配优先级排列，右侧文件按匹配规则、首次读取时间排序。支持搜索、状态筛选、手动路径、关联管理及内嵌配置编辑；保存使用真实配置接口，配置子页与独立权限照常持久化。

权限刷新重建页面时，会根据地址中的服务器、插件与关联 ID 恢复已确认的编辑器；恢复仅使用当前服务器列表中的有效关联。重新读取文件时，名称、路径、编辑类型与版本一起更新，关联变化会显示提示。

原三方案对比保留于 `/s/config-anything/demos`，操作仍为临时演示，不修改服务器。

## 发现规则

只记录目标插件构造与初始化期间成功读取/以可读方式打开的文件，范围为真实 `TShock.SavePath`。先排除根目录 `config.json`，再对 JSON/TXT 排序：文件主名等于 DLL 主名、包含 DLL 主名、含 config/配置、含中文、含 zh-CN、其他 JSON/TXT。同级按首次读取顺序选第一个。其他扩展仍出现在手动选择列表；无自动候选时提示手动指定。

观察器加载之前已经初始化的插件会显示「未捕获加载期」，仍可手动输入路径。观察不追溯历史，不继续收集运行期读取。异步操作按调用发起时是否处于加载期判断，完成成功后才记入；文件打开记录不保证内容确实是配置，最终由管理员确认。读取数上限为每插件 2048，可通过列表 API 的 observation 查看观察点失败或丢弃数量。

1.4.0 配合 TsWebHost 2.1.1 在实例构造之前开启观察，覆盖 LazyAPI 共享基类构造期间的配置加载。加载期成功首次创建的 JSON/TXT 也列为候选，标注为「加载期首次创建」；不收集运行期写入。对于已加载的 LazyAPI 插件，只读取已初始化配置单例的路径元数据，单独返回 `configurationHints` 并标记 `source: lazyapi`，不调用配置加载、不伪造历史读取。候选仍须管理员确认。快照增加 `packageKey`，表示逻辑归属；兼容旧数据时可回退到 `loadContext`。

外部包中附带的其他原生插件会拆成独立逻辑包，所需普通库按程序集引用归属，使用方持久化共享依赖。已有混装包迁移保留原实例与加载上下文，用可恢复的清单事务更新归属；最后一个逻辑包卸载后才释放共享上下文。支持热卸载的业务插件可独立卸载，不再被同包 LazyAPI 的热卸载限制连带阻止；依赖本身的卸载限制和使用方保护仍生效。

配置关联持久化到 `data/config-anything/bindings.json`，稳定页面键使已有侧边栏布局可恢复。每次读写都会在游戏服重新校验目录、链接和排除项，使用文件管理现有版本冲突保护。保存只修改文件，配置何时生效由目标插件决定。

## 扩展接口

1.5.0 在配置编辑页提供 Reload 与热重载按钮，需要配套 TsWebHost 2.2.0。观察 `GeneralHooks.ReloadEvent` 的订阅，并读取当前调用列表，识别既有实例方法和 LazyAPI 泛型配置回调；有订阅时建议 Reload，否则建议热重载。归属不明确的共享回调不执行。Reload 只调用目标插件回调，不触发全服 `/reload`，订阅存在不保证回调一定会读取所选文件。热重载重建目标实例、保留配置和依赖，使用现有加载事务恢复失败版本；卸载后清理该实例的 Reload 订阅，防止 LazyAPI 回调残留。

生效操作沿用该配置的独立权限，新增 `GET configs/:id/runtime`、`POST configs/:id/reload`、`POST configs/:id/hot-reload`（前缀 `/api/config-anything/`）。POST 只接受 `revision` 和 `version`，服务器和插件由已确认的关联决定；关联或文件已变化时拒绝执行。未保存时按钮禁用，成功后重新读取文件。宿主拒绝重载被依赖的提供方、系统组件或含多个插件的包；APM 通过可信策略登记保留清单中的 `HotReload: false` 限制。原生目录插件通过现有 HotReload 加载器执行固定目标操作，不授予用户命令权限。

Cordis 插件声明 `inject: ['configAnything']`，即可调用 `ctx.configAnything`：

```js
const inventory = await ctx.configAnything.listPlugins(serverId);
const binding = await ctx.configAnything.registerConfiguration({
  serverId,
  pluginId,
  path: "Example.json",
  title: "示例配置",
  slot: "main",
});
// binding 含 pageId/pagePath、permission/feature，可按现有侧边栏规范引用。
```

另外提供 `loadPlugin(serverId, { path, dependencies })`、`listConfigurations(serverId, user)`、`getConfiguration(id, serverId)`、`readConfiguration(id, serverId)`、`writeConfiguration(id, serverId, { content, version, revision })`、`unregisterConfiguration(id, serverId)`。slot 默认 main；不同 slot 可为同一插件注册多个文件。`registerConfiguration` 可设置 `sidebar: false`，供调用插件将同一配置页挂到自己的分组，关联与独立权限仍由基础件保存。此服务是后端可信调用接口，调用方负责用户授权；HTTP 路由已通过现有权限系统保护。

1.1.0 新增 `installPlugin(serverId, { mainFile, files: [{ fileName, bytes: Buffer }], replace: false, reloadable: true }, { signal })`，供 APM 等可信后端安装在线下载的 DLL 包。基础件计算哈希，原生端检查托管元数据及加载来源后委托 TsWebHost 安装/回滚；禁止覆盖其他加载器或插件包管理的活动插件。此接口不额外暴露公开上传路由。插件快照增加 `assemblyName`、`assemblyVersion`、`loadContext`，用于版本与归属比较。使用安装包接口需要同步更新 `ConfigAnything.dll`。

1.2.0 的安装接口增加 `sharedDependencies: [{ assemblyName, minimumVersion }]`，`ctx.configAnything.capabilities.sharedDependencies` 标记支持此能力。依赖可来自原生加载器或另一个 TsWebHost 外部包，主插件仍不能覆盖其他包。TsWebHost 2.1.0 负责校验运行中的提供方、复用同一程序集、去重相同内容的库 DLL、持久化共享关系及恢复加载顺序。提供包被其他插件使用时禁止更新或卸载，并提示使用方。加载本地 DLL 同样支持自动去重依赖；两种加载入口都需要配套更新接收端。

1.3.0 新增可信后端接口 `unloadPlugin(serverId, { assemblyName, reloadableAssemblies }, { signal })`，由 TsWebHost 卸载对应外部包并删除其 DLL 清单，保留配置文件。调用方须确认所有包内插件支持热卸载；原生端检查归属和热卸载清单，加载器拒绝卸载仍被其他包使用的提供方。`capabilities.unloadPlugin` 表示支持此能力；配置页关联由调用方在成功后清理。

1.3.1 修复大 DLL 下发时 TShock HTTP 接收库断开连接的问题。编码后的请求超过 24 KiB 时，`installPlugin` 自动调用原生 `install/begin`、`install/chunk`、`install/commit`：每块最多 12 KiB 原始字节，使用 base64url 避免表单百分号膨胀，单次请求体小于 24 KiB；完成总长度与 SHA-256 校验后才执行原有 DLL 元数据校验和加载。最多同时暂存两个包，每包不超过 72 MiB，闲置 5 分钟自动清理；失败或取消时请求 `install/abort`。这些端点沿用 `tsweb.configanything.manage`，不增加网页上传入口或用户文件权限。后端与游戏服 `ConfigAnything.dll` 需一同升级；`capabilities.chunkedInstall` 标记此能力。

HTTP 管理接口：`GET /api/config-anything/plugins`、`POST /load`、`GET/POST /bindings`、`DELETE /bindings/:id`（后三者同前缀）。每个确认配置有独立的 `GET/PUT /api/config-anything/configs/<id>`，绑定服务器和路径，PUT 只接收文本及两个版本字段。管理关联限 superadmin，每个配置模块可独立授权。

## 验证

`node --test plugins/config-anything/test/*.test.mjs`：真实 MonoMod 观察、路径边界、HTTP 权限隔离、持久化恢复、失败回滚、Vue JSON 编辑及切服过期响应。
