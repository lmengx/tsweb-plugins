export class OneBotClient {
  constructor({ endpoint, token = '', fetchImpl = globalThis.fetch } = {}) {
    this.endpoint = String(endpoint || '').replace(/\/$/, '')
    this.token = String(token || '')
    this.fetch = fetchImpl
  }
  async wsCall(action, params = {}) {
    const mod = await import('ws').catch(() => null)
    const WebSocketImpl = mod?.WebSocket || globalThis.WebSocket
    if (!WebSocketImpl) throw Object.assign(new Error('当前运行环境未提供 WebSocket 客户端'), { status: 502 })
    const url = this.endpoint.replace(/^http:/i, 'ws:').replace(/^https:/i, 'wss:')
    const echo = `tsweb-${Date.now()}-${Math.random().toString(16).slice(2)}`
    return await new Promise((resolve, reject) => {
      let settled = false
      const finish = (fn, value) => { if (settled) return; settled = true; clearTimeout(timer); try { socket.close() } catch {} ; fn(value) }
      const socket = mod?.WebSocket
        ? new WebSocketImpl(url, { headers: this.token ? { Authorization: `Bearer ${this.token}` } : {} })
        : new WebSocketImpl(url)
      const timer = setTimeout(() => finish(reject, Object.assign(new Error('OneBot WebSocket 请求超时'), { status: 504 })), 10000)
      socket.on('open', () => socket.send(JSON.stringify({ action, params, echo })))
      socket.on('message', raw => {
        let body
        try { body = JSON.parse(raw.toString()) } catch { return }
        if (body.echo !== echo) return
        if (body.status !== 'ok' || Number(body.retcode || 0) !== 0) return finish(reject, Object.assign(new Error(body.wording || `OneBot ${action} 失败`), { status: 502 }))
        finish(resolve, body.data)
      })
      socket.on('error', error => finish(reject, Object.assign(new Error(`OneBot WebSocket 连接失败：${error.message}`), { status: 502 })))
      socket.on('close', () => { if (!settled) finish(reject, Object.assign(new Error('OneBot 在返回结果前断开连接'), { status: 502 })) })
    })
  }
  async call(action, params = {}) {
    if (!this.endpoint) throw Object.assign(new Error('OneBot endpoint 未配置'), { status: 400 })
    if (/^wss?:/i.test(this.endpoint)) return this.wsCall(action, params)
    const headers = { 'content-type': 'application/json' }
    if (this.token) headers.Authorization = `Bearer ${this.token}`
    const response = await this.fetch(`${this.endpoint}/${action}`, { method: 'POST', headers, body: JSON.stringify(params), signal: AbortSignal.timeout(15000) })
    if (response.status === 426) return this.wsCall(action, params)
    if (!response.ok) throw Object.assign(new Error(`OneBot HTTP ${response.status}`), { status: 502 })
    const body = await response.json()
    if (body?.status !== 'ok' || Number(body?.retcode || 0) !== 0) throw Object.assign(new Error(body?.wording || `OneBot ${action} 失败`), { status: 502 })
    return body.data
  }
  getLoginInfo() { return this.call('get_login_info') }
  getGroupList() { return this.call('get_group_list') }
  getGroupMemberInfo(group_id, user_id) { return this.call('get_group_member_info', { group_id, user_id, no_cache: false }) }
  sendGroupMessage(group_id, message) { return this.call('send_group_msg', { group_id, message }) }
  sendPrivateMessage(user_id, message) { return this.call('send_private_msg', { user_id, message }) }
  sendMessage(target, message) { return target?.group_id ? this.sendGroupMessage(target.group_id, message) : this.sendPrivateMessage(target?.user_id, message) }
}
