// A single, public command document drives both image and text help.
const definitions = [
  ['服务器查询', 'servers', '服务器', '查看服务器列表'],
  ['服务器查询', 'server', '服务器状态 服名', '查看指定服务器状态'],
  ['服务器查询', 'online', '在线 服名', '查看在线玩家'],
  ['账号服务', 'account', '账号', '打开账号服务菜单'],
  ['账号服务', 'register', '注册 角色名', '新建游戏账号'],
  ['账号服务', 'bind', '绑定 角色名', '绑定已有角色，按提示在游戏内验证'],
  ['账号服务', 'me', '我的信息', '查看自己的绑定角色'],
  ['账号服务', 'cancelbind', '取消绑定', '取消尚未验证的绑定请求'],
  ['账号服务', 'accounthelp', '账户服务说明', '查看账号操作说明'],
  ['密码管理', 'claimpassword', '领取密码', '补领初始密码', 'private'],
  ['密码管理', 'password', '改密码 新密码', '修改自己的登录密码', 'private'],
  ['旧账号转移', 'transfer', '绑定转移', '打开菜单，点击“一键转移”', 'group'],
  ['投票服务', 'vote.list', '投票', '查看投票轮次与规则'],
  ['投票服务', 'vote.cast', '投 轮次名 选项', '按选项名称或编号参与投票'],
  ['投票服务', 'vote.propose', '提案 轮次名 内容', '提交自定义提案'],
  ['常用指令', 'menu', '菜单', '返回主菜单'],
  ['常用指令', 'help', '帮助', '查看当前可用指令'],
  ['常用指令', 'ping', '测试', '测试机器人连接'],
  ['常用指令', 'status', '状态', '查看机器人运行状态'],
  ['常用指令', 'group-info', '群信息', '获取当前官方群标识', 'group'],
  ['常用指令', '获取qq号', '获取qq号', '查看当前消息的身份对应'],
]
const accounts = new Set(['account', 'accounthelp', 'register', 'bind', 'me', 'cancelbind', 'claimpassword', 'password', 'transfer'])
export function officialHelpContext({ message, commands, mode = 'official', settings = {}, bind, servers, bridge, config = {} }) {
  const scene = message?.kind === 'group' ? 'group' : 'private'
  const available = commands.filter(command => {
    const id = ['获取qq号', '我的qq号', 'qq号'].includes(command.name) ? 'qq-id' : command.name
    if (['我的qq号', 'qq号'].includes(command.name) && commands.some(c => c.name === '获取qq号')) return false
    const policy = settings.commands?.[id]
    if (policy && (policy.enabled !== true || (policy.scene !== 'both' && policy.scene !== scene))) return false
    if (accounts.has(id) && !bind) return false
    if (['servers', 'server', 'online'].includes(id) && !servers?.list) return false
    if (id === 'transfer' && !(mode === 'hybrid' && bridge?.config?.enabled && bridge?.config?.allowTransfer && bridge?.beginTransfer && config.responseMode !== 'text' && config.keyboardMode === 'custom')) return false
    return !definitions.some(([, name, , , only]) => name === command.name && only && only !== scene)
  })
  return { commands: available, helpDocument: buildHelp({ mode, scene, commands: available }) }
}
export function buildHelp({ mode = 'official', scene = 'group', commands = [] } = {}) {
  const names = new Set(commands.map(c => typeof c === 'string' ? c : c.name))
  const sections = []
  for (const [title, name, cmd, desc, only] of definitions) {
    if (!names.has(name) || (only && only !== scene)) continue
    let section = sections.find(s => s.title === title)
    if (!section) sections.push(section = { title, items: [] })
    section.items.push({ cmd, desc, channel: scene === 'private' ? '私聊' : '群聊' })
  }
  for (const command of commands) {
    if (typeof command === 'string' || definitions.some(d => d[1] === command.name)) continue
    let section = sections.find(s => s.title === '扩展指令')
    if (!section) sections.push(section = { title: '扩展指令', items: [] })
    section.items.push({ cmd: command.name, desc: command.description || '扩展插件提供', channel: scene === 'private' ? '私聊' : '群聊' })
  }
  return { title: '使用帮助 · 机器人指令', mode, scene, subtitle: `${({ official: '官方模式', onebot: 'OneBot 模式', hybrid: '混合模式 · 官方回复' })[mode] || '官方模式'} · ${scene === 'group' ? '群聊' : '私聊'}`, hint: scene === 'group' ? '群内 @机器人 发送指令；密码操作仅限私聊。' : '私聊直接发送指令；仅显示此会话可用的功能。', sections }
}
export function onebotHelp({ mode = 'onebot', scene = 'group', bind, servers } = {}) {
  const commands = ['menu', 'help', 'ping']
  if (servers?.list) commands.push('servers', 'online')
  if (bind) commands.push('register', 'bind', 'me', ...(scene === 'private' ? ['claimpassword', 'password'] : []))
  for (const id of ['vote.list', 'vote.cast', 'vote.propose']) if (bind?.capabilities?.get(id)) commands.push(id)
  return buildHelp({ mode, scene, commands })
}
export function helpText(document) {
  return [document.title, document.subtitle, document.hint, ...document.sections.flatMap(section => ['', section.title, ...section.items.map(item => `${item.cmd} · ${item.desc}（${item.channel}）`)])].join('\n')
}
