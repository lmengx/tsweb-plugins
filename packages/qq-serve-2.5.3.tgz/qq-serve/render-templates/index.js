import { renderHelpPages } from './help-layout.js'
import { registerHelpCache, renderHelp } from '../help-cache.js'
import { onebotHelp, helpText } from '../help.js'
import path from 'node:path'
import { themes, defaults, validate, collect, sample, sampleProfile } from './data.js'
import { renderSvgPages } from './layout.js'

export function renderingConfig(renderer) {
  return { ...validate(renderer.config, defaults()), revision: renderer.revision, themes, messageKinds: ['home', 'account', 'servers', 'players'] }
}
export function registerQqTemplates(ctx) {
  return ctx.inject(['qqRenderer'], c => {
    const renderer = c.qqRenderer
    if (typeof renderer.registerTemplate !== 'function') return
    let cache = null
    const off = []
    try {
      off.push(renderer.registerTemplate('help', { owner: 'qq-serve', build: async options => {
        const theme = options.theme ?? renderingConfig(renderer).theme
        if (!themes.some(value => value.id === theme)) throw new Error('图片风格无效')
        const document = options.document || onebotHelp({ scene: 'private', bind: c.qqBind, servers: c.servers })
        return { pages: renderHelpPages(document, theme), text: helpText(document) }
      } }))
      off.push(registerHelpCache(renderer, path.join(c.paths.dataOf('qq-serve'), 'help-cache')))
      for (const kind of ['home', 'account', 'servers', 'players']) off.push(renderer.registerTemplate(kind, { owner: 'qq-serve', build: async (options) => {
        const { preview = false, scenario = 'normal', signal, profile, botStatus } = options
        const config = renderingConfig(renderer), theme = options.theme ?? config.theme
        if (!themes.some(value => value.id === theme)) throw Object.assign(new Error('图片风格无效'), { status: 400 })
        let data
        if (preview) data = sample(scenario)
        else if (kind === 'account') data = { rows: [], generatedAt: new Date().toISOString(), sample: false }
        else {
          const key = JSON.stringify(config.addresses)
          if (cache?.key === key && cache.expiresAt > Date.now()) data = cache.data
          else {
            data = await collect(c, config.addresses, signal)
            cache = { key, data, expiresAt: Date.now() + 10_000 }
          }
        }
        return { pages: renderSvgPages(data, kind, theme, { profile: preview ? sampleProfile(scenario) : profile, botStatus: preview ? { connected: true } : botStatus }),
          text: ({ home: '机器人主页', account: '账号服务', players: '全服在线玩家', servers: '服务器列表' })[kind] + ' · ' + themes.find(value => value.id === theme).name, data }
      } }))
      // As before, warm the current help images after startup without sending a message.
      const timer = setTimeout(() => {
        if (!renderer.config?.enabled) return
        const get = name => { try { return c.get(name) } catch { return null } }
        const mode = get('qqServe')?.config?.mode || 'official'
        for (const scene of ['group', 'private']) {
          const document = mode === 'onebot'
            ? onebotHelp({ mode, scene, bind: get('qqBind'), servers: get('servers') })
            : get('qqOfficial')?.manager?.helpContext?.({ kind: scene === 'group' ? 'group' : 'c2c' })?.helpDocument
          if (document) void renderHelp(renderer, document).catch(() => {})
        }
      }, 1000)
      timer.unref?.()
      off.push(() => clearTimeout(timer))
    } catch (error) { off.reverse().forEach(dispose => dispose()); throw error }
    return () => { off.reverse().forEach(dispose => dispose()); cache = null }
  })
}
