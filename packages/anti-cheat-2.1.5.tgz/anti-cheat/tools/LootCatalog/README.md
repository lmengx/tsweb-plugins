# 开袋关联数据提取

本工具用 Roslyn 解析当前 Terraria 反编译源码，静态遍历开袋分支、局部变量取值及循环上限，输出每个容器可能产生的物品及保守数量上限。不执行游戏、不采样随机种子。影响产物的未知表达式会中止提取。仅开发时需要 .NET 10 SDK，游戏插件仍使用 .NET 9，无 Roslyn 运行依赖。

先用本地 ilspycmd 将同一个 `OTAPI.dll` 的 `Terraria.Player`、`Terraria.ID.ItemID` 和 `Terraria.NPC` 反编译到 `tmp/container-source/`，随后在宿主仓库根运行：

```powershell
dotnet run --project plugins/anti-cheat/tools/LootCatalog/LootCatalog.csproj -c Release -- tmp/container-source/Terraria.Player.decompiled.cs tmp/container-source/Terraria.ID.ItemID.decompiled.cs tmp/container-source/Terraria.NPC.decompiled.cs PATH_TO_OTAPI_DLL plugins/anti-cheat/resources/container-loot.json
```

当前数据针对 1.4.5.8。升级版本时需审查容器分派、金币倍率和循环行为后再重新生成；工具不承诺任意新版本自动适配。金币价值使用 NPC 基础价值及传奇难度最高倍率 3.5，再包含所有独立随机奖励上限，统一为铜币当量。物品上限是分支合并后的保守界限，可能宽于单次随机结果；互斥奖励组合和概率不用于处罚。

关联资源嵌入 `AntiCheat.dll`。更新 JSON 后必须重新构建 DLL，再通过现有哈希自动同步下发。`node --test plugins/anti-cheat/test/item-balance.test.mjs` 使用同一资源测试所有容器、限额、钥匙、前缀共享、配方不重复扣除及实际事件结算。
