import accessContract from './access.js'
/**
 * 服务器初始化引导插件（ctx.init）—— 添加服务器三模式向导后端
 *
 * 三个模式（对齐旧版 frontend/AddServerWizard.vue + backend/setupRoutes.js 的引导能力）：
 *   1. 手动    —— 前端填 host/port/apiKey → REST 测试后经 auto-verify 幂等登记并校验就绪
 *   2. 本机自动 —— probe 扫描进程 → auto-read 一键配置（改 tshock/config.json 开 REST + 写 superadmin token
 *                  + 复制 TsWebHost.dll）→ auto-verify 验证运行接收端与 Base 哈希
 *   3. 远程自动 —— auto-remote 解析粘贴的 config.json → 生成修改后内容（复制/下载）→ auto-verify 验证落库
 *
 * HTTP API（前缀 /api/setup，全部 admin：verifyAuth + requireAdmin）：
 *   GET  /api/setup/platform      平台建议进程名（前端"自动·本机"默认值适配）
 *   GET  /api/setup/probe         进程扫描（?name= 按程序名 / ?port= 按端口）
 *   POST /api/setup/auto-read     一键配置（本机：改配置 + 写 token + 复制 DLL）
 *   POST /api/setup/local-restart 用户点击后保存退出并重启扫描选中的本机实例
 *   POST /api/setup/auto-remote   解析远程 config.json → 生成修改后内容
 *   POST /api/setup/auto-verify   验证连接并落库（复用 ctx.servers.add，自动连接）
 *
 * 说明：
 *   - 新架构无 setup token，全部端点走 admin JWT（verifyAuth + requireAdmin）
 *   - 鉴权中间件由 accounts 插件提供（ctx.auth）
 *   - 落库复用 servers 插件 ctx.servers.add（自动连接现有 TShock REST）
 *   - DLL 复制目标为 TsWebHost.dll（新架构 TShock 端接收插件，替代旧 TsWeb.dll）
 */
import crypto from 'node:crypto'
import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { assemblyIdentity, prepareReceiverFiles } from './receiver-files.js'
import { verifySetup, serialize } from './readiness.js'
import { createLocalRestart, inspectLocalProcess } from './local-restart.js'
import { createLocalHotload } from './local-hotload.js'
import { probeLocal, preferredRestPort } from './probe-local.js'

export const name = 'init'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'terminal', 'plugins']

const __dirname = path.dirname(fileURLToPath(import.meta.url))

// ═══════════════ 平台判定 ═══════════════
const IS_WIN = process.platform === 'win32'

/**
 * TsWebHost.dll 候选来源（按优先级，**全部在宿主根之内**，无任何跨目录引用）：
 *   1. 环境变量 TSWEB_HOST_DLL —— 显式指定，任何部署形态都能用
 *   2. <host>/resources/TsWebHost.dll —— 干净 Windows 发行包的只读资源
 *   3. <host>/data/resources/TsWebHost.dll —— 旧发行目录内置位置
 *   3. <host>/plugins/tsweb-host/bin/Release/net9.0/TsWebHost.dll —— 开发树就地构建产物
 *   4. <host>/plugins/tsweb-host/TsWebHost.dll —— 已把产物复制到该插件目录根的情形
 * 说明：候选由 buildHostDllCandidates() 在调用时求值，便于运行期改环境变量后立即生效。
 * 独立发行形态下只有候选 2 存在（make-dist 会把它放好），这正是期望的路径。
 */
function buildHostDllCandidates() {
  const hostRoot = path.resolve(__dirname, '../..') // plugins/init → 宿主根
  const list = []
  if (process.env.TSWEB_HOST_DLL) {
    list.push(path.resolve(process.env.TSWEB_HOST_DLL))
  }
  list.push(
    path.join(hostRoot, 'resources', 'TsWebHost.dll'),
    path.join(hostRoot, 'data', 'resources', 'TsWebHost.dll'),
    path.join(hostRoot, 'plugins', 'tsweb-host', 'bin', 'Release', 'net9.0', 'TsWebHost.dll'),
    path.join(hostRoot, 'plugins', 'tsweb-host', 'TsWebHost.dll')
  )
  return list
}

export async function apply(ctx) {
  const app = ctx.auth.access.policyApp(ctx.webServer.app, accessContract, ctx)
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]
  const localRestart = createLocalRestart()
  const localHotload = createLocalHotload({ dataDir: ctx.paths?.dataDir })

  // ═══════════════ GET /api/setup/platform ═══════════════
  app.get('/api/setup/platform', ...admin, (_req, res) => {
    res.json({
      platform: process.platform,
      suggestedName: IS_WIN ? 'TShock.Server.exe' : 'TShock.Server',
    })
  })

  // ═══════════════ GET /api/setup/probe ═══════════════
  // 本机扫描：一次请求返回进程、各自监听端口、实例 tshock/config.json 里的 REST 端口
  // 与监听状态、磁盘接收端版本。调用次数固定（与实例数无关），见 probe-local.js。
  app.get('/api/setup/probe', ...admin, async (req, res) => {
    try {
      const portQ = String(req.query.port || '').trim()
      const nameQ = String(req.query.name || '').trim()
      const source = await receiverSource()
      const bundled = source ? { ...source.identity, path: source.source } : null
      const result = nameQ
        ? await probeLocal({ mode: 'name', name: nameQ, bundled })
        : await probeLocal({ mode: 'port', port: portQ || '7777', bundled })
      res.json({ ...result, platform: process.platform })
    } catch (err) {
      res.status(err.status || 500).json({ error: err.message })
    }
  })

  // ═══════════════ POST /api/setup/auto-read ═══════════════
  // 本机一键配置：改 tshock/config.json（开 REST + 写 TSWeb superadmin token）+ 复制 TsWebHost.dll
  app.post('/api/setup/auto-read', ...admin, async (req, res) => {
    try {
      const { processPath, pid, restPort: requestedRestPort, restPortConfirmed } = req.body || {}
      if (typeof processPath !== 'string' || !processPath) return res.status(400).json({ error: '缺少 processPath' })
      // A selected live Windows instance uses first-install injection. This
      // branch never prepares a restart or silently falls back to one.
      if (IS_WIN && pid !== undefined) {
        const result = await localHotload.configure({ processPath, pid, restPort: requestedRestPort, restPortConfirmed }, await receiverSource())
        // 运行中已加载的旧接收端无法热替换：新文件已落盘，这里补一张重启凭据，
        // 让向导可以"保存退出并重启一次"，而不是把版本不一致当成接入成功。
        if (result.receiverMismatch) result.restart = await localRestart.prepare({ processPath, pid }, req.user?.username)
        return res.json(result)
      }
      const serverDir = path.dirname(processPath)
      const configPath = path.join(serverDir, 'tshock', 'config.json')
      let raw
      try {
        raw = await fs.readFile(configPath, 'utf8')
      } catch {
        return res.json({ success: false, error: '未找到 tshock/config.json，请确认 TShock 已正确安装' })
      }
      const config = JSON.parse(raw)
      const settings = config.Settings || config
      if (!settings.RestApiPort) {
        return res.json({ success: false, error: '配置文件中未找到 RestApiPort' })
      }
      const restPort = settings.RestApiPort

      // 已有 TSWeb superadmin token 则复用
      let tokenKey
      let reused = false
      if (settings.ApplicationRestTokens) {
        for (const [k, v] of Object.entries(settings.ApplicationRestTokens)) {
          if (v.Username === 'TSWeb' && v.UserGroupName === 'superadmin') {
            tokenKey = k
            reused = true
            break
          }
        }
      }
      if (!tokenKey) tokenKey = generateRandomToken(35)

      const originalConfig = JSON.stringify(config)
      settings.RestApiEnabled = true
      if (!settings.ApplicationRestTokens) settings.ApplicationRestTokens = {}
      if (!reused) {
        settings.ApplicationRestTokens[tokenKey] = { Username: 'TSWeb', UserGroupName: 'superadmin' }
      }
      const configChanged = JSON.stringify(config) !== originalConfig
      if (configChanged) await fs.writeFile(configPath, JSON.stringify(config, null, 2), 'utf8')

      // 复制 TsWebHost.dll（TShock 端接收插件）：自动归档旧副本并替换；不能写入时明确报错
      const pluginDir = path.join(serverDir, 'ServerPlugins')
      const pluginDst = path.join(pluginDir, 'TsWebHost.dll')
      const copyNote = await copyHostDll(pluginDir, pluginDst)

      // 配置已写入，但接收端 DLL 未就绪时不能算"配置完成"，把警告显式回传面板
      const warning = ['copied', 'replaced', 'exists'].includes(copyNote.status)
        ? null
        : `TsWebHost.dll 未就绪（${copyNote.status}）：${copyNote.note || ''}。插件下发链路需该 DLL 就位后才可用。`

      const restart = await localRestart.prepare({ processPath, pid }, req.user?.username)
      res.json({ success: true, restPort, tokenKey, configPath, reused, configChanged, copyNote, warning, restart,
        needsRestart: configChanged || !['exists'].includes(copyNote.status) })
    } catch (err) {
      res.status(500).json({ error: err.message })
    }
  })

  app.post('/api/setup/local-restart', ...admin, async (req, res) => {
    try { res.json(await localRestart.run(req.body?.restartId, req.user?.username)) }
    catch (error) { res.status(error.status || 500).json({ error: error.message }) }
  })

  // ═══════════════ POST /api/setup/auto-remote ═══════════════
  // 远程模式：解析粘贴的 config.json → 生成修改后内容（不开本地文件，不复制 DLL）
  app.post('/api/setup/auto-remote', ...admin, async (req, res) => {
    try {
      const { configRaw } = req.body || {}
      if (!configRaw) return res.status(400).json({ error: '缺少 configRaw' })
      let config
      try {
        config = JSON.parse(configRaw)
      } catch {
        return res.json({ success: false, error: '无效的 JSON 格式' })
      }
      const settings = config.Settings || config
      if (!settings.RestApiPort) {
        return res.json({ success: false, error: '配置文件中未找到 RestApiPort' })
      }
      const restPort = settings.RestApiPort

      let tokenKey
      let reused = false
      if (settings.ApplicationRestTokens) {
        for (const [k, v] of Object.entries(settings.ApplicationRestTokens)) {
          if (v.Username === 'TSWeb' && v.UserGroupName === 'superadmin') {
            tokenKey = k
            reused = true
            break
          }
        }
      }
      if (!tokenKey) tokenKey = generateRandomToken(35)

      settings.RestApiEnabled = true
      if (!settings.ApplicationRestTokens) settings.ApplicationRestTokens = {}
      if (!reused) {
        settings.ApplicationRestTokens[tokenKey] = { Username: 'TSWeb', UserGroupName: 'superadmin' }
      }
      const modifiedRaw = JSON.stringify(config, null, 2)
      res.json({ success: true, restPort, tokenKey, modifiedRaw, reused })
    } catch (err) {
      res.status(500).json({ error: err.message })
    }
  })

  // ═══════════════ POST /api/setup/auto-verify ═══════════════
  // 验证连接并落库（复用 ctx.servers.add → 自动连接）
  app.post('/api/setup/auto-verify', ...admin, async (req, res) => {
    try {
      const { host, port, apiKey, name } = req.body || {}
      if (!host || !port || !apiKey) {
        return res.status(400).json({ error: 'host、port、apiKey 均为必填' })
      }
      const source = await receiverSource()
      if (!source) return res.json({ success: false, error: '宿主缺少配套 TsWebHost.dll，无法核验运行中的接收端，请修复宿主资源' })
      res.json(await verifySetup(ctx, { host, port, apiKey, name, note: req.body.note }, source.identity))
    } catch (err) {
      res.status(err.status || 500).json({ error: err.message })
    }
  })

  // ═══════════════ 终端命令 ═══════════════
  ctx.terminal.register('setup-probe', '扫描本机 TShock 进程（用法: setup-probe [进程名]）', async (args) => {
    const nameQ = (args && args[0]) || (IS_WIN ? 'TShock.Server.exe' : 'TShock.Server')
    try {
      const source = await receiverSource()
      const bundled = source ? { ...source.identity, path: source.source } : null
      const result = await probeLocal({ mode: 'name', name: nameQ, bundled })
      if (!result.instances.length) {
        console.log('未找到进程 ' + nameQ)
        return
      }
      for (const instance of result.instances) {
        const ports = instance.ports.join(' / ') || '无'
        const rest = instance.restPort
          ? `  REST ${instance.restPort}（${instance.restListening ? '已在监听，直接复用' : instance.restConflict ? '被其它进程占用' : '配置内，未监听'}）`
          : '  REST 端口读不到（将建议 ' + preferredRestPort(instance, result.suggestedRestPort) + '）'
        const receiver = instance.receiver.copies
          ? `  接收端 ${instance.receiver.version || '版本未知'}${instance.receiver.matches ? '（与宿主配套）' : '（与宿主不配套，需重启一次）'}`
          : '  接收端 未安装'
        console.log(`  PID ${instance.pid}  端口 [${ports}]${rest}${receiver}  ${instance.path || '路径未知'}`)
      }
    } catch (err) {
      console.log('扫描失败: ' + err.message)
    }
  })

  console.log('[init] 服务器初始化引导插件已挂载（/api/setup/platform|probe|auto-read|local-restart|auto-remote|auto-verify）')
}

// ═══════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════
// 探测实现见 probe-local.js（跨平台进程 / 端口 / 实例配置 / 接收端）
// ═══════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════
// 工具
// ═══════════════════════════════════════════════════════════

async function receiverSource() {
  for (const source of buildHostDllCandidates()) {
    try {
      const identity = assemblyIdentity(await fs.readFile(source))
      if (identity?.name === 'TsWebHost') return { source, identity }
    } catch { /* try next candidate */ }
  }
  return null
}

/** Retire receiver assemblies by identity, including renamed old copies. */
export async function copyHostDll(pluginDir, pluginDst = path.join(pluginDir, 'TsWebHost.dll')) {
  return serialize(`receiver:${path.resolve(pluginDir).toLowerCase()}`, async () => {
    const found = await receiverSource()
    if (!found) {
      const exists = await fs.stat(pluginDst).then(() => true, () => false)
      return { status: exists ? 'unverified' : 'missing', path: pluginDst,
        attempted: buildHostDllCandidates(), note: '未找到有效的宿主配套 TsWebHost.dll，无法确认接收端版本。请修复 resources/TsWebHost.dll 或 TSWEB_HOST_DLL' }
    }
    try { return await prepareReceiverFiles(pluginDir, found.source) }
    catch (error) { return { status: 'failed', path: pluginDst, from: found.source, note: error.message } }
  })
}

function generateRandomToken(length) {
  // 密码学安全随机数生成器（CSPRNG）
  return crypto.randomBytes(length).toString('base64url').slice(0, length)
}
