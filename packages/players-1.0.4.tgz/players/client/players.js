/* TSWeb 玩家管理客户端插件（players）
 * 依赖宿主能力（window.tsweb）：
 *   - window.tsweb.registerView({ id, title, section, path, render })
 *   - window.tsweb.api(path, opts)       带 Bearer 的统一请求（同 app.js api()）
 *   - window.tsweb.getServerId()         当前目标服务器 id（列表/详情请求带 x-server-id）
 * 页面：
 *   - #/s/players                        玩家列表（在线/全部 Tab、搜索、分页、重复 IP 入口）
 *   - #/s/players/<username>             玩家详情（账号只读 + 属性编辑 + 背包编辑）
 */
(function () {
  'use strict'

  var tsw = window.tsweb

  // ═══════════ 工具 ═══════════
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    })
  }

  function api(path, opts) {
    opts = opts || {}
    var serverId = tsw.getServerId()
    var headers = opts.headers || {}
    if (serverId) headers['x-server-id'] = serverId
    opts.headers = headers
    return tsw.api(path, opts)
  }

  // 格式化时间：unix epoch 秒 / ISO 8601 UTC 字符串（TShock 存 DateTime.UtcNow.ToString("s")，无时区后缀）
  // 一律转本地时区显示（旧版 formatLocalDate 同款逻辑）
  function fmtTime(s) {
    if (!s) return '-'
    if (/^\d+$/.test(s)) {
      var n = parseInt(s, 10)
      if (n <= 0) return '-'
      var d = new Date(n * 1000)
      return isNaN(d.getTime()) ? s : d.toLocaleString()
    }
    var iso = String(s).replace(' ', 'T')
    if (!/[zZ]|[+-]\d{2}:?\d{2}$/.test(iso)) iso += 'Z'
    var d2 = new Date(iso)
    return isNaN(d2.getTime()) ? s : d2.toLocaleString('zh-CN')
  }

  // ═══════════ 物品数据（data-items 内置插件：ID.json 字典 + 物品图标）═══════════
  // 数据源约定：/plugins/data-items/client/ID.json、/plugins/data-items/client/img/img/Item_<id>.png
  var ITEM_DATA_BASE = '/plugins/data-items/client'
  var itemDict = null // { "<netID>": { chinese, english } }
  var itemDictLoaded = null

  function loadItemData() {
    if (itemDictLoaded) return itemDictLoaded
    itemDictLoaded = fetch(ITEM_DATA_BASE + '/ID.json')
      .then(function (r) { return r.json() })
      .then(function (data) {
        itemDict = {}
        ;(data.list || []).forEach(function (it) {
          if (it && it.id != null) itemDict[String(it.id)] = { chinese: it.chinese || '', english: it.english || '' }
        })
        return itemDict
      })
      .catch(function () {
        itemDict = {}
        return itemDict
      })
    return itemDictLoaded
  }

  function getItemInfo(netID) {
    if (!netID || netID <= 0) return null
    return (itemDict && itemDict[String(netID)]) || null
  }

  // 物品图标：本地资产优先（data-items），缺失回退 Terraria Wiki
  function getItemImage(netID) {
    return ITEM_DATA_BASE + '/img/img/Item_' + netID + '.png'
  }

  function getItemWikiImage(netID) {
    var info = getItemInfo(netID)
    if (!info || !info.english) return ''
    return 'https://terraria.wiki.gg/images/' + info.english.replace(/\s+/g, '_') + '.png'
  }

  // stats 字段展示/编辑定义（中文标签 + 类型），与 Players.dll 白名单一致
  var STATS_FIELDS = [
    { key: 'maxHealth', label: '最大生命', type: 'int' },
    { key: 'health', label: '当前生命', type: 'int' },
    { key: 'maxMana', label: '最大魔力', type: 'int' },
    { key: 'mana', label: '当前魔力', type: 'int' },
    { key: 'questsCompleted', label: '已完成钓鱼任务', type: 'int' },
    { key: 'extraSlot', label: '额外饰品栏', type: 'bool' },
    { key: 'unlockedBiomeTorches', label: '已解锁环境火把', type: 'bool' },
    { key: 'ateArtisanBread', label: '已食用工匠面包', type: 'bool' },
    { key: 'usedAegisCrystal', label: '已使用神盾水晶', type: 'bool' },
    { key: 'usedAegisFruit', label: '已使用神盾果实', type: 'bool' },
    { key: 'usedArcaneCrystal', label: '已使用秘法水晶', type: 'bool' },
    { key: 'usedGalaxyPearl', label: '已使用银河珍珠', type: 'bool' },
    { key: 'usedGummyWorm', label: '已使用软糖蠕虫', type: 'bool' },
    { key: 'usedAmbrosia', label: '已使用神馔', type: 'bool' },
    { key: 'unlockedSuperCart', label: '已解锁机械矿车', type: 'bool' },
    { key: 'enabledSuperCart', label: '启用机械矿车', type: 'bool' }
  ]

  // ═══════════ 玩家列表页 ═══════════
  // 2026-09 优化：单一列表（不再分「在线/全部」两个 Tab），
  // 在线玩家由服务端排在最前（SQL CASE WHEN 排序），每页最多 100 条。
  var listState = { page: 1, pageSize: 100, keyword: '', hasCharacter: false, onlineOnly: false }

  async function renderList(container) {
    disposePluginSections() // 离开详情页：先清理插件区块的在途请求
    container.innerHTML = ''
    var el = document.createElement('div')
    el.innerHTML = [
      '<style>',
      '.tswp-toolbar{display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap}',
      '.tswp-search{flex:1;min-width:180px;padding:9px 12px;background:var(--card);border:1px solid var(--border);border-radius:var(--radius);color:var(--text);font-size:13px;transition:border-color .15s, box-shadow .15s}',
      '.tswp-search:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb, var(--accent) 15%, transparent)}',
      '.tswp-search::placeholder{color:var(--muted-foreground);opacity:.7}',
      '.tswp-filter{display:inline-flex;align-items:center;gap:7px;padding:7px 12px;background:var(--card);border:1px solid var(--border);border-radius:var(--radius);color:var(--muted-foreground);font-size:12.5px;cursor:pointer;user-select:none;white-space:nowrap;transition:border-color .15s, color .15s}',
      '.tswp-filter:hover{border-color:var(--accent);color:var(--text)}',
      '.tswp-filter input{accent-color:var(--accent);width:14px;height:14px;cursor:pointer;margin:0}',
      '.tswp-table-wrap{background:var(--card);border:1px solid var(--border);border-radius:var(--radius-md);overflow:auto;margin-bottom:12px}',
      '.tswp-table{width:100%;border-collapse:collapse;font-size:13px;min-width:640px}',
      '.tswp-table thead th{position:sticky;top:0;z-index:2;background:color-mix(in srgb, var(--muted) 70%, var(--card));color:var(--muted-foreground);font-weight:600;font-size:11.5px;text-transform:uppercase;letter-spacing:.4px;padding:10px 14px;border-bottom:1px solid var(--border);white-space:nowrap}',
      '.tswp-table tbody td{padding:10px 14px;border-bottom:1px solid var(--border);vertical-align:middle}',
      '.tswp-table tbody tr:last-child td{border-bottom:none}',
      '.tswp-table tbody tr{transition:background .12s}',
      '.tswp-table tbody tr:hover{background:color-mix(in srgb, var(--accent-subtle) 55%, transparent)}',
      '.tswp-table tbody tr.is-online{background:color-mix(in srgb, #22c55e 4%, transparent)}',
      '.tswp-table tbody tr.is-online:hover{background:color-mix(in srgb, var(--accent-subtle) 55%, color-mix(in srgb, #22c55e 4%, transparent))}',
      '.tswp-dot{display:inline-flex;align-items:center;gap:6px;font-size:12px;color:var(--muted-foreground)}',
      '.tswp-dot::before{content:"";width:8px;height:8px;border-radius:50%;background:var(--border);flex-shrink:0}',
      '.tswp-dot.online{color:#22c55e;font-weight:600}',
      '.tswp-dot.online::before{background:#22c55e;box-shadow:0 0 6px #22c55e}',
      '.tswp-dot.online + .tswp-dot-extra{margin-left:4px}',
      '.tswp-link{color:var(--accent);cursor:pointer;text-decoration:none;font-weight:500;transition:color .12s}',
      '.tswp-link:hover{text-decoration:underline;color:var(--accent-dark)}',
      '.tswp-ghost-link{color:var(--muted-foreground);cursor:pointer;font-size:12px;text-decoration:none;transition:color .12s}',
      '.tswp-ghost-link:hover{color:var(--accent)}',
      '.tswp-empty{padding:28px 16px;text-align:center;color:var(--muted-foreground);font-size:13px}',
      '.tswp-pager{display:flex;align-items:center;justify-content:center;gap:8px;margin-top:4px;padding:8px 0;flex-wrap:wrap}',
      '.tswp-pager-info{color:var(--muted-foreground);font-size:12px;margin-right:10px;white-space:nowrap}',
      '.tswp-page-btn{min-width:30px;height:30px;padding:0 9px;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text);font-size:12.5px;cursor:pointer;transition:all .12s;display:inline-flex;align-items:center;justify-content:center}',
      '.tswp-page-btn:hover:not(:disabled){border-color:var(--accent);color:var(--accent)}',
      '.tswp-page-btn:disabled{opacity:.4;cursor:not-allowed}',
      '.tswp-page-btn.active{background:var(--accent);border-color:var(--accent);color:var(--accent-foreground);font-weight:600}',
      '.tswp-page-ellipsis{color:var(--muted-foreground);font-size:12px;padding:0 2px}',
      '</style>',
      '<div class="toolbar" style="margin-bottom:14px">',
      '<h2 style="margin:0;font-size:17px">玩家管理</h2>',
      '<span id="tswp-online-count" class="badge ok hidden" style="font-size:12px"></span>',
      '<div class="spacer"></div>',
      '<button id="tswp-dip-all" class="ghost sm">重复 IP（全量）</button>',
      '</div>',
      '<div class="tswp-toolbar">',
      '<input id="tswp-keyword" class="tswp-search" placeholder="搜索用户名..." spellcheck="false">',
      '<label class="tswp-filter" title="只看当前在线玩家"><input type="checkbox" id="tswp-onlineonly"> 仅在线</label>',
      '<label class="tswp-filter" title="只在 tsCharacter 表中有角色数据的玩家"><input type="checkbox" id="tswp-haschar"> 有角色数据</label>',
      '<button id="tswp-refresh" class="ghost sm">刷新</button>',
      '</div>',
      '<div class="tswp-table-wrap">',
      '<table class="tswp-table"><thead><tr>',
      '<th style="width:84px">状态</th><th>用户名</th><th>用户组</th><th>注册时间</th><th>最后访问</th>',
      '<th style="width:64px;text-align:center">角色</th><th style="width:56px;text-align:right">操作</th>',
      '</tr></thead><tbody id="tswp-tbody"></tbody></table>',
      '<p id="tswp-empty" class="tswp-empty hidden"></p>',
      '</div>',
      '<div class="tswp-pager" id="tswp-pager"></div>',
      '<p id="tswp-error" class="error hidden"></p>'
    ].join('')
    container.appendChild(el)

    el.querySelector('#tswp-keyword').addEventListener('input', debounce(function (e) {
      listState.keyword = e.target.value.trim()
      listState.page = 1
      loadList()
    }, 300))
    el.querySelector('#tswp-haschar').addEventListener('change', function (e) {
      listState.hasCharacter = e.target.checked
      listState.page = 1
      loadList()
    })
    el.querySelector('#tswp-onlineonly').addEventListener('change', function (e) {
      listState.onlineOnly = e.target.checked
      listState.page = 1
      loadList()
    })
    el.querySelector('#tswp-refresh').addEventListener('click', loadList)
    el.querySelector('#tswp-dip-all').addEventListener('click', function () {
      renderAllDuplicateIps(container)
    })

    async function loadList() {
      hideErr()
      var params = ['page=' + listState.page, 'pageSize=' + listState.pageSize]
      if (listState.keyword) params.push('keyword=' + encodeURIComponent(listState.keyword))
      if (listState.hasCharacter) params.push('hasCharacter=true')
      if (listState.onlineOnly) params.push('onlineOnly=true')
      var res = await api('/api/players/list?' + params.join('&'))
      if (!res.ok) return showErr(el, (res.data && res.data.error) || '加载失败')
      renderRows(el, res.data.users || [], res.data.total || 0, res.data.onlineCount || 0)
    }

    function renderRows(root, users, total, onlineCount) {
      var onlineBadge = root.querySelector('#tswp-online-count')
      if (onlineCount > 0) {
        onlineBadge.textContent = '在线 ' + onlineCount
        onlineBadge.classList.remove('hidden')
      } else {
        onlineBadge.classList.add('hidden')
      }
      var tbody = root.querySelector('#tswp-tbody')
      var empty = root.querySelector('#tswp-empty')
      if (!users.length) {
        tbody.innerHTML = ''
        empty.textContent = onlineCount > 0 && listState.onlineOnly ? '当前没有在线玩家' : '暂无玩家'
        empty.classList.remove('hidden')
        root.querySelector('#tswp-pager').innerHTML = ''
        return
      }
      empty.classList.add('hidden')
      tbody.innerHTML = users.map(function (u) {
        var rowCls = u.IsOnline ? 'is-online' : ''
        var dot = u.IsOnline
          ? '<span class="tswp-dot online" title="在线">在线</span>'
          : '<span class="tswp-dot" title="离线">离线</span>'
        var hasChar = u.HasCharacter
          ? '<span class="badge ok" style="font-size:11px">有</span>'
          : '<span class="badge" style="font-size:11px">无</span>'
        return '<tr class="' + rowCls + '">' +
          '<td>' + dot + '</td>' +
          '<td><span class="tswp-link" data-user="' + esc(u.Username) + '">' + esc(u.Username) + '</span></td>' +
          '<td><span class="badge" style="font-size:11px;background:color-mix(in srgb, var(--accent) 10%, var(--card));color:var(--accent);border-color:color-mix(in srgb, var(--accent) 25%, transparent)">' + esc(u.Usergroup || 'guest') + '</span></td>' +
          '<td>' + esc(fmtTime(u.Registered)) + '</td>' +
          '<td>' + esc(fmtTime(u.LastAccessed)) + '</td>' +
          '<td style="text-align:center">' + hasChar + '</td>' +
          '<td style="text-align:right"><a class="tswp-ghost-link" data-user="' + esc(u.Username) + '">详情</a></td>' +
          '</tr>'
      }).join('')
      tbody.querySelectorAll('[data-user]').forEach(function (a) {
        a.addEventListener('click', function () {
          location.hash = '/s/players/' + encodeURIComponent(a.getAttribute('data-user'))
        })
      })
      renderPager(root, total)
    }

    function renderPager(root, total) {
      var pager = root.querySelector('#tswp-pager')
      var pages = Math.max(1, Math.ceil(total / listState.pageSize))
      var cur = listState.page
      if (cur > pages) cur = pages

      // 数字分页：始终显示首页/末页，中间窗口 ±2，超范围用省略号
      var nums = []
      var lo = Math.max(2, cur - 2)
      var hi = Math.min(pages - 1, cur + 2)
      for (var i = lo; i <= hi; i++) nums.push(i)

      var html = '<span class="tswp-pager-info">共 ' + total + ' 个账号 · 第 ' + cur + '/' + pages + ' 页</span>'
      html += '<button class="tswp-page-btn" data-pg="prev" ' + (cur <= 1 ? 'disabled' : '') + '>上一页</button>'
      html += '<button class="tswp-page-btn' + (cur === 1 ? ' active' : '') + '" data-pg="1">1</button>'
      if (lo > 2) html += '<span class="tswp-page-ellipsis">…</span>'
      nums.forEach(function (n) {
        html += '<button class="tswp-page-btn' + (n === cur ? ' active' : '') + '" data-pg="' + n + '">' + n + '</button>'
      })
      if (hi < pages - 1) html += '<span class="tswp-page-ellipsis">…</span>'
      if (pages > 1) html += '<button class="tswp-page-btn' + (cur === pages ? ' active' : '') + '" data-pg="' + pages + '">' + pages + '</button>'
      html += '<button class="tswp-page-btn" data-pg="next" ' + (cur >= pages ? 'disabled' : '') + '>下一页</button>'

      pager.innerHTML = html
      pager.querySelectorAll('[data-pg]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          if (btn.disabled) return
          var pg = btn.getAttribute('data-pg')
          if (pg === 'prev') pg = cur - 1
          else if (pg === 'next') pg = cur + 1
          pg = parseInt(pg, 10)
          if (pg < 1 || pg > pages || pg === cur) return
          listState.page = pg
          loadList()
        })
      })
    }

    loadList()
  }

  // ═══════════ 全量重复 IP ═══════════
  async function renderAllDuplicateIps(container) {
    container.innerHTML = '<div class="panel"><p class="muted">加载中...</p></div>'
    var res = await api('/api/players/allduplicateips')
    if (!res.ok) {
      container.innerHTML = '<div class="panel"><p class="error">' + esc((res.data && res.data.error) || '加载失败') + '</p></div>'
      return
    }
    var groups = (res.data && res.data.duplicateips) || []
    var html = '<div class="toolbar" style="margin-bottom:14px"><h2 style="margin:0;font-size:17px">重复 IP / UUID 关联</h2>' +
      '<div class="spacer"></div><button id="tswp-dip-back" class="ghost sm">返回玩家列表</button></div>'
    if (!groups.length) {
      html += '<div class="panel"><p class="muted" style="text-align:center;padding:24px 0">未发现关联组</p></div>'
    } else {
      html += '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:12px">' +
        groups.map(function (g) {
          return '<div class="panel" style="margin:0;padding:14px;display:flex;flex-direction:column;gap:10px">' +
            '<div style="display:flex;align-items:center;gap:8px">' +
            '<span class="badge" style="font-size:11px;background:color-mix(in srgb, var(--accent) 10%, var(--card));color:var(--accent);border-color:color-mix(in srgb, var(--accent) 25%, transparent)">组 #' + g.index + '</span>' +
            '<span class="muted" style="font-size:12px">' + g.accounts.length + ' 个账号</span>' +
            '</div>' +
            '<div style="display:flex;flex-wrap:wrap;gap:6px">' + g.accounts.map(function (a) {
              return '<span class="tswp-link" data-user="' + esc(a.username) + '" style="padding:3px 10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--muted);font-size:12px;text-decoration:none">' + esc(a.username) + '</span>'
            }).join('') + '</div>' +
            '<div class="muted" style="font-size:12px;display:flex;align-items:center;gap:6px;flex-wrap:wrap">' +
            '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>' +
            '<span>IP: ' + esc((g.ips || []).join(', ')) + '</span></div>' +
            '</div>'
        }).join('') + '</div>'
    }
    container.innerHTML = html
    container.querySelectorAll('[data-user]').forEach(function (a) {
      a.addEventListener('click', function () {
        location.hash = '/s/players/' + encodeURIComponent(a.getAttribute('data-user'))
      })
    })
    var back = container.querySelector('#tswp-dip-back')
    if (back) back.addEventListener('click', function () { location.hash = '/s/players' })
  }

  // ═══════════ 玩家详情页 ═══════════
  var detailState = null // { doc, edited }

  // ── 玩家详情页扩展区块（宿主 API：window.tsweb.registerPlayerDetailSection）──
  // 任意插件（如 online-stats）可注册区块挂到详情页底部，无需修改本文件。
  // 这里只负责：按 order 排序渲染、单个区块异常隔离、详情页重建/离开时调用清理函数。
  var sectionCleanups = []

  function disposePluginSections() {
    var list = sectionCleanups
    sectionCleanups = []
    for (var i = 0; i < list.length; i++) {
      try { list[i]() } catch (e) { /* 清理失败不阻断详情页 */ }
    }
  }

  function renderPluginSections(container, doc) {
    disposePluginSections()
    var tsw = window.tsweb
    if (!tsw || typeof tsw.getPlayerDetailSections !== 'function') return
    var sections = tsw.getPlayerDetailSections().slice().sort(function (a, b) {
      return (a.order == null ? 100 : a.order) - (b.order == null ? 100 : b.order)
    })
    if (!sections.length) return

    var wrap = document.createElement('div')
    wrap.id = 'tswp-detail-sections'
    container.appendChild(wrap)

    sections.forEach(function (sec) {
      var el = document.createElement('div')
      el.className = 'panel tswp-sec'
      el.style.padding = '18px 20px'
      var title = document.createElement('h3')
      title.style.margin = '0 0 12px 0'
      title.style.fontSize = '14px'
      title.textContent = sec.title || sec.id
      var body = document.createElement('div')
      el.appendChild(title)
      el.appendChild(body)
      wrap.appendChild(el)
      try {
        var cleanup = sec.render(body, doc.account, doc)
        if (typeof cleanup === 'function') sectionCleanups.push(cleanup)
      } catch (e) {
        body.innerHTML = '<p class="error">区块渲染失败：' + esc(e && e.message ? e.message : e) + '</p>'
        console.error('[players] 详情区块渲染失败: ' + sec.id, e)
      }
    })
  }

  async function renderDetail(container, username) {
    disposePluginSections() // 重建详情页：先清理上一次插件区块的在途请求
    container.innerHTML = '<div class="panel"><p class="muted">加载中...</p></div>'
    // 预加载物品数据（ID.json），供背包图标与 tooltip 使用；不阻塞详情渲染
    loadItemData()
    var res = await api('/api/players/' + encodeURIComponent(username))
    if (!res.ok) {
      container.innerHTML = '<div class="panel"><p class="error">' + esc((res.data && res.data.error) || '加载失败') + '</p>' +
        '<button id="tswp-back" class="ghost sm" style="margin-top:10px">返回玩家列表</button></div>'
      bindBack(container)
      return
    }
    var doc = res.data.document
    if (!doc) {
      container.innerHTML = '<div class="panel"><p class="error">响应缺少 document 字段</p><button id="tswp-back" class="ghost sm" style="margin-top:10px">返回玩家列表</button></div>'
      bindBack(container)
      return
    }
    detailState = {
      doc: doc,
      username: username,
      _invOriginal: (doc.inventory || []).map(function (x) { return x ? Object.assign({}, x) : null })
    }

    var html = [
      '<style>',
      // ── 标题区（旧版 page-header 风格，无头像）──
      '.tswp-ud-title{display:flex;align-items:center;gap:12px;margin-bottom:16px;flex-wrap:wrap}',
      '.tswp-ud-title h2{margin:0;font-size:17px}',
      '.tswp-ud-username{font-size:16px;font-weight:600;color:var(--text)}',
      '.tswp-ud-online{display:inline-flex;align-items:center;gap:6px;font-size:12px;color:var(--muted-foreground);padding:3px 10px;border:1px solid var(--border);border-radius:20px;background:var(--card)}',
      '.tswp-ud-online .tswp-ud-dot{width:8px;height:8px;border-radius:50%;background:var(--border)}',
      '.tswp-ud-online.online{color:#22c55e;border-color:rgba(34,197,94,.35);background:rgba(34,197,94,.08)}',
      '.tswp-ud-online.online .tswp-ud-dot{background:#22c55e;box-shadow:0 0 6px #22c55e}',
      // ── 用户信息区（旧版 info-list / info-item）──
      '.tswp-info-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px;margin:0 0 14px 0}',
      '.tswp-info-item{display:flex;justify-content:space-between;align-items:center;padding:11px 14px;background:color-mix(in srgb, var(--muted) 40%, var(--card));border:1px solid var(--border);border-radius:var(--radius)}',
      '.tswp-info-item dt{color:var(--muted-foreground);font-weight:500;font-size:12.5px;flex-shrink:0}',
      '.tswp-info-item dd{color:var(--text);font-size:13px;margin:0;text-align:right;word-break:break-all;max-width:70%}',
      '.tswp-group-click{display:inline-flex;align-items:center;gap:6px;cursor:pointer;padding:4px 10px;background:color-mix(in srgb, var(--accent) 10%, transparent);border:1px solid color-mix(in srgb, var(--accent) 30%, transparent);border-radius:var(--radius-sm);color:var(--accent);font-weight:600;font-size:12.5px;transition:all .15s}',
      '.tswp-group-click:hover{background:color-mix(in srgb, var(--accent) 18%, transparent);border-color:color-mix(in srgb, var(--accent) 55%, transparent)}',
      '.tswp-group-click .tswp-change-hint{font-size:10.5px;font-weight:400;color:var(--muted-foreground)}',
      '.tswp-uuid-box{cursor:pointer;padding:4px 10px;background:color-mix(in srgb, var(--accent) 8%, transparent);border:1px solid color-mix(in srgb, var(--accent) 25%, transparent);border-radius:var(--radius-sm);color:var(--accent);font-weight:700;font-family:"Courier New",monospace;letter-spacing:.5px;transition:all .15s}',
      '.tswp-uuid-box:hover{background:color-mix(in srgb, var(--accent) 15%, transparent);border-color:color-mix(in srgb, var(--accent) 50%, transparent)}',
      '.tswp-info-extra{margin-top:12px;display:flex;gap:8px;flex-wrap:wrap}',
      // ── 操作区（旧版 action-section 三分类）──
      '.tswp-action-section{display:flex;flex-direction:column;gap:14px;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-md);padding:18px 20px;margin-bottom:16px}',
      '.tswp-action-group{display:flex;flex-direction:column;gap:8px}',
      '.tswp-group-label{margin:0;font-size:12px;color:var(--muted-foreground);font-weight:600;text-align:center;letter-spacing:.3px}',
      '.tswp-group-buttons{display:flex;gap:8px;flex-wrap:wrap;justify-content:center}',
      '.tswp-op-btn{display:inline-flex;align-items:center;gap:7px;padding:9px 18px;border:none;border-radius:var(--radius);cursor:pointer;font-size:13px;font-weight:500;color:#fff;transition:transform .15s, box-shadow .15s;box-shadow:0 1px 3px rgba(0,0,0,.15)}',
      '.tswp-op-btn:hover:not(:disabled){transform:translateY(-1px)}',
      '.tswp-op-btn:disabled{opacity:.5;cursor:not-allowed}',
      '.tswp-op-green{background:linear-gradient(135deg,#10b981,#059669)}',
      '.tswp-op-green:hover:not(:disabled){box-shadow:0 4px 12px rgba(16,185,129,.4)}',
      '.tswp-op-red{background:linear-gradient(135deg,#ef4444,#dc2626)}',
      '.tswp-op-red:hover:not(:disabled){box-shadow:0 4px 12px rgba(239,68,68,.4)}',
      '.tswp-op-indigo{background:linear-gradient(135deg,#6366f1,#4f46e5)}',
      '.tswp-op-indigo:hover:not(:disabled){box-shadow:0 4px 12px rgba(99,102,241,.4)}',
      '.tswp-op-sky{background:linear-gradient(135deg,#0ea5e9,#0284c7)}',
      '.tswp-op-sky:hover:not(:disabled){box-shadow:0 4px 12px rgba(14,165,233,.4)}',
      '.tswp-op-purple{background:linear-gradient(135deg,#8b5cf6,#7c3aed)}',
      '.tswp-op-purple:hover:not(:disabled){box-shadow:0 4px 12px rgba(139,92,246,.4)}',
      '.tswp-op-blue{background:linear-gradient(135deg,#3b82f6,#2563eb)}',
      '.tswp-op-blue:hover:not(:disabled){box-shadow:0 4px 12px rgba(59,130,246,.4)}',
      '.tswp-op-amber{background:linear-gradient(135deg,#f59e0b,#d97706)}',
      '.tswp-op-amber:hover:not(:disabled){box-shadow:0 4px 12px rgba(245,158,11,.4)}',
      '.tswp-act-msg{margin-top:10px;font-size:12.5px;min-height:16px;text-align:center}',
      '.tswp-act-msg.ok{color:#22c55e}',
      '.tswp-act-msg.err{color:var(--danger)}',
      // ── 角色属性区（旧版 stats-section）──
      '.tswp-sec{margin-bottom:16px}',
      '.tswp-stats-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:12px;margin-bottom:14px}',
      '.tswp-stat-item{display:flex;flex-direction:column;gap:6px}',
      '.tswp-stat-item label{font-size:12px;color:var(--muted-foreground);font-weight:500}',
      '.tswp-stat-item input{background:var(--card);border:1px solid var(--border);border-radius:var(--radius-sm);padding:8px 10px;color:var(--text);font-size:13px;transition:border-color .15s, box-shadow .15s}',
      '.tswp-stat-item input:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb, var(--accent) 15%, transparent)}',
      '.tswp-enhances-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px;margin-bottom:14px}',
      '.tswp-enhance-item{display:flex;align-items:center;gap:8px;padding:8px 12px;background:color-mix(in srgb, var(--muted) 40%, var(--card));border:1px solid var(--border);border-radius:var(--radius-sm);font-size:12.5px;color:var(--text);cursor:pointer;transition:border-color .15s}',
      '.tswp-enhance-item:hover{border-color:var(--accent)}',
      '.tswp-enhance-item input{accent-color:var(--accent);width:14px;height:14px;cursor:pointer;margin:0}',
      '.tswp-stats-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}',
      // ── 背包区（旧版 InventoryViewer 布局）──
      '.tswp-inv-main-row{display:flex;gap:16px;flex-wrap:wrap;align-items:flex-start;margin-bottom:16px}',
      '.tswp-inv-main-area{flex:0 0 auto}',
      '.tswp-inv-section{background:var(--card);border:1px solid var(--border);border-radius:var(--radius-md);padding:14px}',
      '.tswp-inv-section-title{display:flex;align-items:center;gap:8px;margin-bottom:12px;padding-bottom:9px;border-bottom:1px solid var(--border);color:var(--text);font-weight:600;font-size:13px}',
      '.tswp-inv-section-title img{width:22px;height:22px;image-rendering:pixelated}',
      '.tswp-bag-with-extras{display:flex;gap:8px}',
      '.tswp-bag-grid{display:grid;grid-template-columns:repeat(10,44px);gap:6px}',
      '.tswp-inv-cell{width:44px;height:44px;background:color-mix(in srgb, var(--muted) 45%, var(--card));border:2px solid var(--border);border-radius:var(--radius-sm);position:relative;display:flex;align-items:center;justify-content:center;transition:all .15s}',
      '.tswp-inv-cell.empty{background:transparent;border:1px dashed var(--border)}',
      '.tswp-inv-cell.clickable{cursor:pointer}',
      '.tswp-inv-cell.clickable:hover{border-color:var(--accent);transform:scale(1.06);box-shadow:0 2px 8px rgba(0,0,0,.2)}',
      '.tswp-inv-cell img{width:85%;height:85%;object-fit:contain;image-rendering:pixelated}',
      '.tswp-inv-stack{position:absolute;bottom:1px;right:3px;font-size:10px;font-weight:700;color:#fff;text-shadow:1px 1px 2px rgba(0,0,0,.85)}',
      '.tswp-inv-fav{position:absolute;top:1px;left:2px;font-size:11px;line-height:1}',
      '.tswp-inv-idx{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:10px;color:#fff;background:rgba(0,0,0,.8);padding:2px 6px;border-radius:4px;opacity:0;transition:opacity .15s;pointer-events:none;font-weight:500}',
      '.tswp-inv-cell:hover .tswp-inv-idx{opacity:1}',
      '.tswp-inv-col{display:flex;flex-direction:column;gap:6px}',
      '.tswp-equipment-groups{display:flex;flex-wrap:wrap;gap:12px;align-items:flex-start}',
      '.tswp-equipment-group{flex:0 0 auto;min-width:160px}',
      '.tswp-equipment-table{display:flex;flex-direction:column;gap:6px}',
      '.tswp-equipment-row{display:flex;gap:6px}',
      '.tswp-extra-storage{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}',
      '.tswp-extra-storage .tswp-inv-section{flex:0 0 auto}',
      '.tswp-slot-editor{position:fixed;z-index:60;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-md);padding:14px;width:250px;box-shadow:0 12px 40px rgba(0,0,0,.25)}',
      '.tswp-slot-editor label{display:block;font-size:12px;color:var(--muted-foreground);margin-bottom:3px;margin-top:6px}',
      '.tswp-slot-editor label:first-child{margin-top:0;color:var(--text);font-weight:600;font-size:13px}',
      '.tswp-slot-editor input{width:100%;box-sizing:border-box;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-sm);padding:5px 8px;color:var(--text);font-size:13px;margin-bottom:2px;transition:border-color .15s, box-shadow .15s}',
      '.tswp-slot-editor input:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb, var(--accent) 15%, transparent)}',
      '.tswp-slot-editor .tswp-se-actions{display:flex;gap:6px;justify-content:flex-end;margin-top:12px}',
      '.tswp-no-icon{color:var(--muted-foreground);font-size:10px;word-break:break-all;padding:2px;text-align:center;line-height:1.2}',
      // ── 用户组切换模态框（旧版 custom-select 风格）──
      '.tswp-modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:200;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px)}',
      '.tswp-modal{background:var(--card);border:1px solid var(--border);border-radius:var(--radius-md);width:420px;max-width:92vw;box-shadow:0 20px 60px rgba(0,0,0,.3)}',
      '.tswp-modal-head{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid var(--border)}',
      '.tswp-modal-head h3{margin:0;font-size:15px}',
      '.tswp-modal-close{background:none;border:none;color:var(--muted-foreground);font-size:18px;cursor:pointer;line-height:1;padding:4px}',
      '.tswp-modal-close:hover{color:var(--text)}',
      '.tswp-modal-body{padding:16px 18px}',
      '.tswp-modal-foot{display:flex;gap:8px;justify-content:flex-end;padding:12px 18px;border-top:1px solid var(--border)}',
      '.tswp-select-trigger{display:flex;align-items:center;justify-content:space-between;padding:9px 12px;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text);font-size:13px;cursor:pointer;transition:border-color .15s}',
      '.tswp-select-trigger:hover{border-color:var(--accent)}',
      '.tswp-select-arrow{color:var(--muted-foreground);font-size:10px;transition:transform .15s}',
      '.tswp-select-arrow.rotated{transform:rotate(180deg)}',
      '.tswp-select-list{max-height:260px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--radius-sm);margin-top:6px;background:var(--card)}',
      '.tswp-select-opt{padding:8px 12px;font-size:13px;color:var(--text);cursor:pointer;transition:background .1s}',
      '.tswp-select-opt:hover{background:color-mix(in srgb, var(--accent-subtle) 60%, transparent)}',
      '.tswp-select-opt.selected{background:color-mix(in srgb, var(--accent) 12%, transparent);color:var(--accent);font-weight:600}',
      '.tswp-form-row{margin-bottom:10px}',
      '.tswp-form-row label{display:block;font-size:12px;color:var(--muted-foreground);margin-bottom:5px}',
      '</style>',
      // ── 标题区（旧版 page-header：返回 + 标题 + 用户名 + 在线状态）──
      '<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">' +
      '<button id="tswp-back" class="ghost sm" style="flex-shrink:0">← 返回</button>' +
      '<div class="tswp-ud-title" style="margin:0">' +
      '<h2>用户详情</h2>' +
      '<span class="tswp-ud-username">' + esc(doc.account.username) + '</span>' +
      '<span class="tswp-ud-online' + (doc.online ? ' online' : '') + '"><span class="tswp-ud-dot"></span>' + (doc.online ? '在线' : '离线') + '</span>' +
      '</div>' +
      '<div class="spacer"></div>' +
      '</div>'
    ].join('')
    container.innerHTML = html
    bindBack(container)

    // ── 用户信息（旧版 info-list 风格）──
    var acc = doc.account
    container.insertAdjacentHTML('beforeend',
      '<div class="panel tswp-sec" style="padding:18px 20px">' +
      '<dl class="tswp-info-list">' +
      '<div class="tswp-info-item"><dt>ID</dt><dd>' + esc(acc.id) + '</dd></div>' +
      '<div class="tswp-info-item"><dt>用户名</dt><dd>' + esc(acc.username) + '</dd></div>' +
      '<div class="tswp-info-item"><dt>用户组</dt><dd><span id="tswp-group-click" class="tswp-group-click" title="点击修改">' + esc(acc.group || 'guest') + '<span class="tswp-change-hint">点击修改</span></span></dd></div>' +
      '<div class="tswp-info-item"><dt>UUID</dt><dd><span id="tswp-uuid-box" class="tswp-uuid-box" title="点击复制">' + esc((acc.uuid || '未知').slice(0, 8)) + '</span></dd></div>' +
      '<div class="tswp-info-item"><dt>注册时间</dt><dd>' + esc(fmtTime(acc.registered)) + '</dd></div>' +
      '<div class="tswp-info-item"><dt>最后访问</dt><dd>' + esc(fmtTime(acc.lastAccess)) + '</dd></div>' +
      '<div class="tswp-info-item"><dt>已知 IP</dt><dd>' + esc((acc.knownIPs || []).join(', ')) + '</dd></div>' +
      '</dl>' +
      '<div class="tswp-info-extra">' +
      '<button id="tswp-dupid" class="ghost sm">检测关联账号</button>' +
      '</div>' +
      '</div>')
    container.querySelector('#tswp-dupid').addEventListener('click', function () {
      renderSingleDuplicateIps(container, acc.username)
    })
    container.querySelector('#tswp-uuid-box').addEventListener('click', function () {
      if (acc.uuid) {
        try { navigator.clipboard.writeText(acc.uuid).then(function () { setActMsg('UUID 已复制') }) } catch (e) { }
      }
    })

    // ── 操作区（旧版 action-section 三分类：管理操作/账号操作/互动操作）──
    var onlineDisabled = doc.online ? '' : ' disabled title="仅在线玩家可用"'
    container.insertAdjacentHTML('beforeend',
      '<div class="tswp-action-section">' +
      '<div class="tswp-action-group">' +
      '<h4 class="tswp-group-label">管理操作</h4>' +
      '<div class="tswp-group-buttons">' +
      '<button id="tswp-act-pass" class="tswp-op-btn tswp-op-green">改密码</button>' +
      '<button id="tswp-act-kick" class="tswp-op-btn tswp-op-indigo"' + onlineDisabled + '>踢出</button>' +
      '<button id="tswp-act-ban" class="tswp-op-btn tswp-op-red">封禁</button>' +
      '<button id="tswp-act-clearch" class="tswp-op-btn tswp-op-red">清空角色</button>' +
      '<button id="tswp-act-dupid" class="tswp-op-btn tswp-op-green">检测关联账号</button>' +
      '</div></div>' +
      '<div class="tswp-action-group">' +
      '<h4 class="tswp-group-label">账号操作</h4>' +
      '<div class="tswp-group-buttons">' +
      '<button id="tswp-act-rename" class="tswp-op-btn tswp-op-indigo">改名</button>' +
      '<button id="tswp-act-uuid" class="tswp-op-btn tswp-op-sky">UUID 管理</button>' +
      '<button id="tswp-act-delete" class="tswp-op-btn tswp-op-red">删除账号</button>' +
      '</div></div>' +
      '<div class="tswp-action-group">' +
      '<h4 class="tswp-group-label">互动操作</h4>' +
      '<div class="tswp-group-buttons">' +
      '<button id="tswp-act-tp" class="tswp-op-btn tswp-op-purple"' + onlineDisabled + '>传送</button>' +
      '<button id="tswp-act-whisper" class="tswp-op-btn tswp-op-blue"' + onlineDisabled + '>私聊</button>' +
      '<button id="tswp-act-give" class="tswp-op-btn tswp-op-amber">给物品</button>' +
      '</div></div>' +
      '<div id="tswp-act-msg" class="tswp-act-msg"></div>' +
      '</div>')

    var actMsg = container.querySelector('#tswp-act-msg')
    var actBusy = false

    function setActMsg(text, isErr) {
      actMsg.textContent = text || ''
      actMsg.className = 'tswp-act-msg ' + (isErr ? 'err' : 'ok')
    }

    // ── 用户组切换模态框（点击用户组 → 下拉选择）──
    var groupModal = null
    var groupList = []
    var newGroup = acc.group || 'guest'

    function openGroupModal() {
      groupModal = buildGroupModal(acc.username, newGroup, groupList)
      document.body.appendChild(groupModal)
    }
    function closeGroupModal() {
      if (groupModal) { groupModal.remove(); groupModal = null }
    }

    container.querySelector('#tswp-group-click').addEventListener('click', function () {
      if (groupList.length === 0) {
        api('/api/players/groups').then(function (r) {
          groupList = (r.data && r.data.groups) || []
          if (groupList.length === 0 && !r.ok) groupList = []
          openGroupModal()
        })
      } else {
        openGroupModal()
      }
    })

    // ── 用户组切换模态框（旧版 custom-select 下拉风格）──
    function buildGroupModal(username, currentGroup, groups) {
      var overlay = document.createElement('div')
      overlay.className = 'tswp-modal-overlay'
      overlay.innerHTML =
        '<div class="tswp-modal">' +
        '<div class="tswp-modal-head"><h3>修改用户组</h3>' +
        '<button class="tswp-modal-close" data-gm-close="1">×</button></div>' +
        '<div class="tswp-modal-body">' +
        '<div class="tswp-form-row"><label>选择新用户组</label>' +
        '<div class="tswp-select-trigger" data-gm-trigger="1">' +
        '<span data-gm-value="1">' + esc(newGroup || '请选择用户组') + '</span>' +
        '<span class="tswp-select-arrow" data-gm-arrow="1">▼</span>' +
        '</div>' +
        '<div class="tswp-select-list hidden" data-gm-list="1">' +
        groups.map(function (g) {
          return '<div class="tswp-select-opt' + (g === newGroup ? ' selected' : '') + '" data-gm-opt="' + esc(g) + '">' + esc(g) + '</div>'
        }).join('') +
        '</div></div>' +
        '<div class="tswp-form-row" style="margin-top:10px"><label>或直接输入组名</label>' +
        '<input data-gm-input type="text" value="' + esc(newGroup) + '" placeholder="输入用户组名" style="width:100%;box-sizing:border-box;padding:9px 12px;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text);font-size:13px">' +
        '</div>' +
        '<div id="tswp-gm-msg" class="tswp-act-msg" style="margin-top:8px"></div>' +
        '</div>' +
        '<div class="tswp-modal-foot">' +
        '<button class="ghost sm" data-gm-cancel="1">取消</button>' +
        '<button class="sm" data-gm-ok="1">确认修改</button>' +
        '</div></div>'
      document.body.appendChild(overlay)

      var list = overlay.querySelector('[data-gm-list]')
      var valueEl = overlay.querySelector('[data-gm-value]')
      var arrowEl = overlay.querySelector('[data-gm-arrow]')
      var inputEl = overlay.querySelector('[data-gm-input]')
      var msgEl = overlay.querySelector('#tswp-gm-msg')
      var busy = false

      function setMsg(t, err) {
        msgEl.textContent = t || ''
        msgEl.className = 'tswp-act-msg ' + (err ? 'err' : 'ok')
      }

      function toggleList(open) {
        list.classList.toggle('hidden', !open)
        arrowEl.classList.toggle('rotated', open)
      }
      function pickGroup(name) {
        newGroup = name
        valueEl.textContent = name
        inputEl.value = name
        toggleList(false)
        list.querySelectorAll('[data-gm-opt]').forEach(function (o) {
          o.classList.toggle('selected', o.getAttribute('data-gm-opt') === name)
        })
      }

      overlay.querySelector('[data-gm-trigger]').addEventListener('click', function (e) {
        e.stopPropagation()
        toggleList(list.classList.contains('hidden'))
      })
      list.querySelectorAll('[data-gm-opt]').forEach(function (o) {
        o.addEventListener('click', function () { pickGroup(o.getAttribute('data-gm-opt')) })
      })
      inputEl.addEventListener('input', function () { newGroup = inputEl.value.trim() })
      overlay.querySelector('[data-gm-close]').addEventListener('click', closeGroupModal)
      overlay.querySelector('[data-gm-cancel]').addEventListener('click', closeGroupModal)
      overlay.addEventListener('click', function (e) { if (e.target === overlay) closeGroupModal() })
      overlay.querySelector('[data-gm-ok]').addEventListener('click', async function () {
        if (busy) return
        var target = newGroup
        if (!target) { setMsg('用户组不能为空', true); return }
        busy = true; setMsg('修改中...')
        try {
          var r = await api('/api/players/group?player=' + encodeURIComponent(acc.username) + '&group=' + encodeURIComponent(target))
          var d = r.data || {}
          if (!r.ok) { setMsg(d.error || '修改失败', true); busy = false; return }
          setMsg(d.response || '用户组已更改')
          setTimeout(function () { closeGroupModal(); renderDetail(container, username) }, 500)
        } catch (e) { setMsg(e.message || '修改失败', true); busy = false }
      })

      // 点击外部关闭下拉
      setTimeout(function () {
        document.addEventListener('click', function closeList(e) {
          if (!overlay.contains(e.target)) { toggleList(false); document.removeEventListener('click', closeList) }
        })
      }, 0)

      return overlay
    }

    // 通用确认弹窗（踢出/封禁/清角色/改密码）
    function confirmAction(title, promptHtml, danger) {
      return new Promise(function (resolve) {
        var overlay = document.createElement('div')
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:200;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px)'
        overlay.innerHTML =
          '<div class="panel" style="width:380px;max-width:92vw;box-shadow:0 20px 60px rgba(0,0,0,.3)">' +
          '<h3 style="margin:0 0 14px;font-size:15px">' + esc(title) + '</h3>' +
          '<div>' + promptHtml + '</div>' +
          '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:16px">' +
          '<button class="ghost sm" data-act-cancel="1">取消</button>' +
          '<button class="sm ' + (danger ? 'danger' : '') + '" data-act-ok="1">确认</button>' +
          '</div></div>'
        overlay.querySelector('[data-act-cancel]').addEventListener('click', function () {
          overlay.remove(); resolve(null)
        })
        overlay.querySelector('[data-act-ok]').addEventListener('click', function () {
          var val = overlay.querySelector('[data-act-input]')
          var result = val ? val.value : ''
          overlay.remove(); resolve(result)
        })
        overlay.addEventListener('click', function (e) {
          if (e.target === overlay) { overlay.remove(); resolve(null) }
        })
        document.body.appendChild(overlay)
        var firstInput = overlay.querySelector('[data-act-input]')
        if (firstInput) firstInput.focus()
      })
    }

    // 多输入确认弹窗（返回所有 data-act-inputN 的值数组；取消返回 null）
    function confirmActionMulti(title, promptHtml, danger) {
      return new Promise(function (resolve) {
        var overlay = document.createElement('div')
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:200;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px)'
        overlay.innerHTML =
          '<div class="panel" style="width:380px;max-width:92vw;box-shadow:0 20px 60px rgba(0,0,0,.3)">' +
          '<h3 style="margin:0 0 14px;font-size:15px">' + esc(title) + '</h3>' +
          '<div>' + promptHtml + '</div>' +
          '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:16px">' +
          '<button class="ghost sm" data-act-cancel="1">取消</button>' +
          '<button class="sm ' + (danger ? 'danger' : '') + '" data-act-ok="1">确认</button>' +
          '</div></div>'
        overlay.querySelector('[data-act-cancel]').addEventListener('click', function () {
          overlay.remove(); resolve(null)
        })
        overlay.querySelector('[data-act-ok]').addEventListener('click', function () {
          var vals = []
          var first = overlay.querySelector('[data-act-input]')
          if (first) vals.push(first.value)
          for (var i = 2; ; i++) {
            var el = overlay.querySelector('[data-act-input' + i + ']')
            if (!el) break
            vals.push(el.value)
          }
          overlay.remove(); resolve(vals)
        })
        overlay.addEventListener('click', function (e) {
          if (e.target === overlay) { overlay.remove(); resolve(null) }
        })
        document.body.appendChild(overlay)
        var firstInput = overlay.querySelector('[data-act-input]')
        if (firstInput) firstInput.focus()
      })
    }

    container.querySelector('#tswp-act-kick').addEventListener('click', async function () {
      if (actBusy) return
      var reason = await confirmAction('踢出 ' + acc.username, '<input data-act-input placeholder="原因（可选）" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--card);color:var(--text);font-size:13px">')
      if (reason === null) return
      actBusy = true; setActMsg('执行中...')
      try {
        var r = await api('/api/players/kick?player=' + encodeURIComponent(acc.username) + (reason ? '&reason=' + encodeURIComponent(reason) : ''))
        var d = r.data || {}
        if (!r.ok) setActMsg(d.error || '踢出失败', true)
        else { setActMsg(d.response || '已踢出'); renderDetail(container, username) }
      } catch (e) { setActMsg(e.message || '踢出失败', true) }
      actBusy = false
    })

    container.querySelector('#tswp-act-ban').addEventListener('click', async function () {
      if (actBusy) return
      var reason = await confirmAction('封禁 ' + acc.username + '（acc+UUID+IP 三重）', '<input data-act-input placeholder="原因（可选）" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--card);color:var(--text);font-size:13px">', true)
      if (reason === null) return
      actBusy = true; setActMsg('执行中...')
      try {
        var r = await api('/api/players/ban?player=' + encodeURIComponent(acc.username) + (reason ? '&reason=' + encodeURIComponent(reason) : ''))
        var d = r.data || {}
        if (!r.ok) setActMsg(d.error || '封禁失败', true)
        else { setActMsg(d.response || '封禁成功'); renderDetail(container, username) }
      } catch (e) { setActMsg(e.message || '封禁失败', true) }
      actBusy = false
    })

    container.querySelector('#tswp-act-clearch').addEventListener('click', async function () {
      if (actBusy) return
      var ok = await confirmAction('清空 ' + acc.username + ' 的角色数据？', '<p class="muted" style="margin:0;font-size:13px;line-height:1.6">将删除 SSC 角色数据' + (doc.online ? '，在线玩家会被重置为初始角色' : '') + '。此操作不可恢复。</p>', true)
      if (ok === null) return
      actBusy = true; setActMsg('执行中...')
      try {
        var r = await api('/api/players/clearcharacter?player=' + encodeURIComponent(acc.username))
        var d = r.data || {}
        if (!r.ok) setActMsg(d.error || '清角色失败', true)
        else { setActMsg(d.response || '角色数据已清空'); renderDetail(container, username) }
      } catch (e) { setActMsg(e.message || '清角色失败', true) }
      actBusy = false
    })

    container.querySelector('#tswp-act-pass').addEventListener('click', async function () {
      if (actBusy) return
      var pw = await confirmAction('重置 ' + acc.username + ' 的密码', '<input data-act-input type="password" placeholder="新密码" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--card);color:var(--text);font-size:13px">')
      if (pw === null || !pw.trim()) { setActMsg('密码不能为空', true); return }
      actBusy = true; setActMsg('执行中...')
      try {
        var r = await api('/api/players/password?player=' + encodeURIComponent(acc.username) + '&password=' + encodeURIComponent(pw))
        var d = r.data || {}
        if (!r.ok) setActMsg(d.error || '改密码失败', true)
        else setActMsg(d.response || '密码已重置')
      } catch (e) { setActMsg(e.message || '改密码失败', true) }
      actBusy = false
    })

    container.querySelector('#tswp-act-dupid').addEventListener('click', function () {
      renderSingleDuplicateIps(container, acc.username)
    })

    // ── 互动操作（传送/私聊/给物品，走 /api/players/command → TShock rawcmd）──
    async function runCommand(cmd) {
      var res = await api('/api/players/command', { method: 'POST', json: { cmd: cmd } })
      var d = res.data || {}
      if (!res.ok) throw new Error(d.error || '命令执行失败（' + res.status + '）')
      return d
    }

    container.querySelector('#tswp-act-tp').addEventListener('click', async function () {
      if (actBusy) return
      var target = await confirmAction('传送 ' + acc.username + ' 到...', '<input data-act-input placeholder="目标玩家名（在线）" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--card);color:var(--text);font-size:13px">')
      if (target === null || !target.trim()) { setActMsg('目标玩家不能为空', true); return }
      if (target.trim() === acc.username) { setActMsg('不能传送自己到自己', true); return }
      actBusy = true; setActMsg('传送中...')
      try {
        // 用目标玩家身份 /tphere 拉当前玩家过来（旧版同款命令）
        await runCommand('/runas -f ' + target.trim() + ' "/tphere ' + acc.username + '"')
        setActMsg('已传送 ' + acc.username + ' 到 ' + target.trim())
      } catch (e) { setActMsg(e.message || '传送失败', true) }
      actBusy = false
    })

    container.querySelector('#tswp-act-whisper').addEventListener('click', async function () {
      if (actBusy) return
      var msg = await confirmAction('私聊 ' + acc.username, '<textarea data-act-input placeholder="输入消息内容" rows="3" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--card);color:var(--text);font-size:13px;resize:vertical"></textarea>')
      if (msg === null || !msg.trim()) { setActMsg('消息不能为空', true); return }
      actBusy = true; setActMsg('发送中...')
      try {
        await runCommand('/w ' + acc.username + ' ' + msg.trim())
        setActMsg('消息已发送给 ' + acc.username)
      } catch (e) { setActMsg(e.message || '发送失败', true) }
      actBusy = false
    })

    container.querySelector('#tswp-act-give').addEventListener('click', async function () {
      if (actBusy) return
      var form = '<div style="display:flex;flex-direction:column;gap:8px">' +
        '<div class="tswp-form-row" style="margin:0"><label>物品 ID</label><input data-act-input type="number" min="1" placeholder="如 76（荣耀之剑）" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--card);color:var(--text);font-size:13px"></div>' +
        '<div class="tswp-form-row" style="margin:0"><label>数量（默认 1）</label><input data-act-input2 type="number" min="1" value="1" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--card);color:var(--text);font-size:13px"></div>' +
        '<div class="tswp-form-row" style="margin:0"><label>前缀 ID（可选）</label><input data-act-input3 type="number" min="0" placeholder="如 63（传说）" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--card);color:var(--text);font-size:13px"></div>' +
        '</div>'
      var inputs = await confirmActionMulti('给 ' + acc.username + ' 发物品', form)
      if (!inputs) return
      var itemId = inputs[0], amount = inputs[1], prefix = inputs[2]
      if (!itemId || itemId <= 0) { setActMsg('物品 ID 无效', true); return }
      var cmd = '/give ' + itemId + ' ' + acc.username + ' ' + (amount > 0 ? amount : 1)
      if (prefix && prefix > 0) cmd += ' ' + prefix
      actBusy = true; setActMsg('发放中...')
      try {
        var d = await runCommand(cmd)
        setActMsg((d.response && d.response !== '{}') ? d.response : '物品已发放')
      } catch (e) { setActMsg(e.message || '发放失败', true) }
      actBusy = false
    })

    // ── 账号操作（改名 / UUID 管理 / 删除账号）──
    container.querySelector('#tswp-act-rename').addEventListener('click', async function () {
      if (actBusy) return
      var newName = await confirmAction('改名 ' + acc.username, '<input data-act-input placeholder="新用户名（至少 3 字符）" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--card);color:var(--text);font-size:13px">')
      if (newName === null || !newName.trim()) { setActMsg('新用户名不能为空', true); return }
      actBusy = true; setActMsg('改名中...')
      try {
        var r = await api('/api/players/rename?player=' + encodeURIComponent(acc.username) + '&newName=' + encodeURIComponent(newName.trim()))
        var d = r.data || {}
        if (!r.ok) setActMsg(d.error || '改名失败', true)
        else { setActMsg(d.response || '改名成功'); setTimeout(function () { renderDetail(container, newName.trim()) }, 800) }
      } catch (e) { setActMsg(e.message || '改名失败', true) }
      actBusy = false
    })

    container.querySelector('#tswp-act-uuid').addEventListener('click', async function () {
      if (actBusy) return
      var curUuid = acc.uuid || ''
      var form = '<div class="tswp-form-row" style="margin:0"><label>当前 UUID：' + esc(curUuid || '未绑定') + '</label>' +
        '<input data-act-input placeholder="输入新 UUID（32 位十六进制），留空清除" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--card);color:var(--text);font-size:13px"></div>' +
        '<p class="muted" style="margin:8px 0 0;font-size:12px;line-height:1.6">清除 UUID 后该账号需密码登录。</p>'
      var uuid = await confirmAction('UUID 管理（' + acc.username + '）', form)
      if (uuid === null) return
      actBusy = true; setActMsg('更新中...')
      try {
        var r = await api('/api/players/uuid?player=' + encodeURIComponent(acc.username) + '&uuid=' + encodeURIComponent(uuid.trim()))
        var d = r.data || {}
        if (!r.ok) setActMsg(d.error || 'UUID 更新失败', true)
        else { setActMsg(d.response || 'UUID 已更新'); renderDetail(container, username) }
      } catch (e) { setActMsg(e.message || 'UUID 更新失败', true) }
      actBusy = false
    })

    container.querySelector('#tswp-act-delete').addEventListener('click', async function () {
      if (actBusy) return
      var form = '<p style="margin:0;font-size:13px;line-height:1.6;color:var(--text)">确定删除账号 <strong>' + esc(acc.username) + '</strong> 吗？此操作不可撤销！</p>' +
        '<label class="tswp-enhance-item" style="margin-top:10px"><input type="checkbox" data-act-input2 checked value="1"><span>同时删除角色数据（SSC）</span></label>'
      var inputs = await confirmActionMulti('删除账号（危险操作）', form, true)
      if (inputs === null) return
      var deleteCharacter = inputs[0] === '1'
      actBusy = true; setActMsg('删除中...')
      try {
        var r = await api('/api/players/delete?player=' + encodeURIComponent(acc.username) + '&deleteCharacter=' + deleteCharacter)
        var d = r.data || {}
        if (!r.ok) setActMsg(d.error || '删除失败', true)
        else { setActMsg(d.response || '账号已删除'); setTimeout(function () { renderList(container) }, 1000) }
      } catch (e) { setActMsg(e.message || '删除失败', true) }
      actBusy = false
    })

    // ── 角色属性区（旧版 stats-section：数值横排 + 增益网格 + 刷新/保存）──
    var statsHtml = '<div class="panel tswp-sec" style="padding:18px 20px">'
    statsHtml += '<h3 style="margin:0 0 14px;font-size:14px">角色属性</h3>'
    // 数值字段（旧版 stats-row）
    var numberFields = STATS_FIELDS.filter(function (f) { return f.type !== 'bool' })
    var boolFields = STATS_FIELDS.filter(function (f) { return f.type === 'bool' })
    statsHtml += '<div class="tswp-stats-row">' +
      numberFields.map(function (f) {
        var v = doc.stats[f.key]
        return '<div class="tswp-stat-item"><label>' + f.label + '</label>' +
          '<input type="number" data-stats-key="' + f.key + '" value="' + esc(v == null ? '' : v) + '"></div>'
      }).join('') + '</div>'
    // 布尔字段（旧版 enhances-grid 永久增益）
    statsHtml += '<h4 style="margin:0 0 10px;font-size:12.5px;color:var(--muted-foreground)">角色永久增益</h4>' +
      '<div class="tswp-enhances-grid">' +
      boolFields.map(function (f) {
        var v = doc.stats[f.key]
        return '<label class="tswp-enhance-item"><input type="checkbox" data-stats-key="' + f.key + '"' + (v ? ' checked' : '') + '><span>' + f.label + '</span></label>'
      }).join('') + '</div>'
    statsHtml += '<div class="tswp-stats-actions">' +
      '<button id="tswp-stats-refresh" class="ghost sm">刷新</button>' +
      '<button id="tswp-stats-save" class="sm">保存属性</button>' +
      '<span id="tswp-stats-msg" class="tswp-act-msg" style="margin-top:0"></span>' +
      '</div></div>'
    container.insertAdjacentHTML('beforeend', statsHtml)

    container.querySelector('#tswp-stats-refresh').addEventListener('click', function () {
      renderDetail(container, username)
    })
    container.querySelector('#tswp-stats-save').addEventListener('click', function () {
      var ops = []
      STATS_FIELDS.forEach(function (f) {
        var input = container.querySelector('[data-stats-key="' + f.key + '"]')
        if (!input) return
        var newVal
        if (f.type === 'bool') newVal = input.checked
        else newVal = input.value === '' ? null : parseInt(input.value, 10)
        var oldVal = doc.stats[f.key]
        if (f.type === 'bool' && newVal !== !!oldVal) ops.push({ op: 'replace', path: '/stats/' + f.key, value: newVal })
        else if (f.type === 'int' && newVal !== oldVal && newVal !== null) ops.push({ op: 'replace', path: '/stats/' + f.key, value: newVal })
      })
      if (!ops.length) {
        container.querySelector('#tswp-stats-msg').textContent = '没有需要保存的改动'
        return
      }
      doPatch(container, username, ops, '#tswp-stats-msg')
    })

    // ── 背包信息区（旧版 InventoryViewer 布局）──
    container.insertAdjacentHTML('beforeend',
      '<div class="panel tswp-sec" style="padding:18px 20px">' +
      '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">' +
      '<h3 style="margin:0;font-size:14px">背包信息</h3>' +
      '<div style="display:flex;gap:8px;align-items:center">' +
      '<button id="tswp-inv-refresh" class="ghost sm">刷新</button>' +
      '<button id="tswp-inv-save" class="sm">保存改动</button>' +
      '</div></div>' +
      '<div id="tswp-inv"></div>' +
      '<div id="tswp-inv-msg" class="tswp-act-msg" style="text-align:left"></div>' +
      '</div>')

    renderInventory(container)

    container.querySelector('#tswp-inv-refresh').addEventListener('click', function () {
      renderDetail(container, username)
    })
    container.querySelector('#tswp-inv-save').addEventListener('click', function () {
      var ops = collectInvOps(container)
      if (!ops.length) {
        container.querySelector('#tswp-inv-msg').textContent = '没有需要保存的改动'
        return
      }
      doPatch(container, username, ops, '#tswp-inv-msg')
    })

    // ── 插件详情页扩展区块（如 online-stats：累计在线时长/日历）──
    // 放在最后渲染，位置固定在详情页底部；无插件注册时不留任何痕迹。
    renderPluginSections(container, doc)
  }

  // ── 背包渲染（旧版 InventoryViewer：主背包 + 装备组 + 存储区）──
  function renderInventory(container) {
    var inv = detailState.doc.inventory || []
    var wrap = container.querySelector('#tswp-inv')
    wrap.innerHTML = ''
    var editorEl = null

    // 物品格子 HTML：has = 有物品（实底）/ 空（虚框），hover 显示序号
    function cellHtml(slot, cls) {
      var item = inv[slot] || { netID: 0, stack: 0, prefix: 0, favorited: false }
      var has = item.netID > 0
      var tip = '槽 ' + slot
      var inner = '<span class="tswp-inv-idx">' + slot + '</span>'
      if (has) {
        var info = getItemInfo(item.netID)
        if (info && info.chinese) tip += '：' + info.chinese + '（ID ' + item.netID + '）'
        else tip += '：netID=' + item.netID
        if (info && info.english) tip += '\n' + info.english
        if (item.prefix) tip += ' prefix=' + item.prefix
        inner += '<img class="tswp-item-icon" src="' + getItemImage(item.netID) + '"' +
          ' data-netid="' + item.netID + '" alt="' + esc(item.netID) + '" loading="lazy">'
        if (item.stack > 1) inner += '<span class="tswp-inv-stack">' + item.stack + '</span>'
        if (item.favorited) inner += '<span class="tswp-inv-fav">★</span>'
      }
      return '<div class="tswp-inv-cell' + (cls ? ' ' + cls : '') + (has ? '' : ' empty') + ' clickable" data-slot="' + slot + '"' +
        ' title="' + esc(tip) + '">' + inner + '</div>'
    }

    // 区段标题（旧版：图标 + 文字 + 底边框）
    function sectionTitle(iconId, text) {
      var icon = iconId ? '<img src="' + getItemImage(iconId) + '" alt="">' : ''
      return '<div class="tswp-inv-section-title">' + icon + esc(text) + '</div>'
    }

    // 主背包区：50 格主背包 + 钱币列(50-53) + 弹药列(54-57)
    var mainArea = '<div class="tswp-inv-section">' +
      sectionTitle(5343, '背包') +
      '<div class="tswp-bag-with-extras">' +
      '<div class="tswp-bag-grid">'
    for (var i = 0; i < 50; i++) mainArea += cellHtml(i)
    mainArea += '</div>' +
      '<div class="tswp-inv-col">' + [50, 51, 52, 53].map(function (s) { return cellHtml(s) }).join('') + '</div>' +
      '<div class="tswp-inv-col">' + [54, 55, 56, 57].map(function (s) { return cellHtml(s) }).join('') + '</div>' +
      '</div></div>'

    // 装备组：染料(79-88) / 时装(69-78) / 护甲(59-68) 三列
    function equipGroup(title, iconId, dyeStart, cosmeticStart, armorStart) {
      var html = '<div class="tswp-inv-section tswp-equipment-group">' + sectionTitle(iconId, title) +
        '<div class="tswp-equipment-table">'
      for (var r = 0; r < 10; r++) {
        html += '<div class="tswp-equipment-row">' +
          cellHtml(dyeStart + r, 'dye-cell') +
          cellHtml(cosmeticStart + r, 'cosmetic-cell') +
          cellHtml(armorStart + r, 'armor-cell') +
          '</div>'
      }
      html += '</div></div>'
      return html
    }

    // 副装备：饰品染料(94-98) / 饰品(89-93) 两列（图标 3623 与旧版一致）
    function accessoryGroup() {
      var html = '<div class="tswp-inv-section tswp-equipment-group">' + sectionTitle(3623, '副装备') +
        '<div class="tswp-equipment-table">'
      for (var r = 0; r < 5; r++) {
        html += '<div class="tswp-equipment-row">' +
          cellHtml(94 + r, 'dye-cell') +
          cellHtml(89 + r, 'cosmetic-cell') +
          '</div>'
      }
      html += '</div></div>'
      return html
    }

    var equipmentGroups = '<div class="tswp-equipment-groups">' +
      equipGroup('装备组1', 5000, 79, 69, 59) +
      accessoryGroup() +
      equipGroup('装备组2', 5000, 310, 300, 290) +
      equipGroup('装备组3', 5000, 340, 330, 320) +
      '</div>'

    // 主区：背包 + 装备组横排
    wrap.insertAdjacentHTML('beforeend',
      '<div class="tswp-inv-main-row">' +
      '<div class="tswp-inv-main-area">' + mainArea + '</div>' +
      '<div class="tswp-inv-main-area">' + equipmentGroups + '</div>' +
      '</div>')

    // 存储区：存储罐(99-138) / 保险柜(139-178) / 护卫熔炉(180-219) / 虚空宝库(220-259)
    function storageGroup(title, iconId, start, count) {
      var html = '<div class="tswp-inv-section">' + sectionTitle(iconId, title) +
        '<div class="tswp-bag-grid">'
      for (var s = 0; s < count; s++) html += cellHtml(start + s)
      html += '</div></div>'
      return html
    }
    wrap.insertAdjacentHTML('beforeend',
      '<div class="tswp-extra-storage">' +
      storageGroup('存储罐', 3213, 99, 40) +
      storageGroup('保险柜', 346, 139, 40) +
      storageGroup('护卫熔炉', 3813, 180, 40) +
      storageGroup('虚空宝库', 4131, 220, 40) +
      '</div>')

    // 物品图标加载失败：回退 wiki；wiki 也失败则显示 netID 文字
    wrap.querySelectorAll('.tswp-item-icon').forEach(function (img) {
      img.addEventListener('error', function () {
        if (!img.dataset.wiki) {
          var wiki = getItemWikiImage(parseInt(img.getAttribute('data-netid'), 10))
          if (wiki) {
            img.dataset.wiki = '1'
            img.src = wiki
            return
          }
        }
        var span = document.createElement('span')
        span.className = 'tswp-no-icon'
        span.textContent = img.getAttribute('data-netid')
        img.replaceWith(span)
      })
    })

    wrap.querySelectorAll('.tswp-inv-cell').forEach(function (slotEl) {
      slotEl.addEventListener('click', function (e) {
        e.stopPropagation()
        openSlotEditor(container, slotEl, parseInt(slotEl.getAttribute('data-slot'), 10))
      })
    })

    document.addEventListener('click', function closeEditor() {
      if (editorEl && !editorEl.contains(event.target)) {
        editorEl.remove()
        editorEl = null
        document.removeEventListener('click', closeEditor)
      }
    })

    function openSlotEditor(root, slotEl, slot) {
      if (editorEl) editorEl.remove()
      var item = detailState.doc.inventory[slot] || { netID: 0, stack: 0, prefix: 0, favorited: false }
      editorEl = document.createElement('div')
      editorEl.className = 'tswp-slot-editor'
      editorEl.innerHTML =
        '<label>槽位 ' + slot + '</label>' +
        '<label>netID（0 清空）</label><input id="tswp-se-netid" type="number" value="' + item.netID + '">' +
        '<label>数量</label><input id="tswp-se-stack" type="number" min="0" value="' + item.stack + '">' +
        '<label>前缀</label><input id="tswp-se-prefix" type="number" min="0" value="' + item.prefix + '">' +
        '<div class="tswp-se-actions">' +
        '<button class="ghost sm" id="tswp-se-clear">清空</button>' +
        '<button class="ghost sm" id="tswp-se-cancel">取消</button>' +
        '<button class="sm" id="tswp-se-ok">应用</button>' +
        '</div>'
      document.body.appendChild(editorEl)

      // 定位：格子下方，靠右对齐避免溢出
      var rect = slotEl.getBoundingClientRect()
      var left = Math.min(rect.left, window.innerWidth - 260)
      var top = rect.bottom + 4
      if (top + editorEl.offsetHeight > window.innerHeight) top = rect.top - editorEl.offsetHeight - 4
      editorEl.style.left = Math.max(4, left) + 'px'
      editorEl.style.top = Math.max(4, top) + 'px'

      editorEl.querySelector('#tswp-se-clear').addEventListener('click', function () {
        applySlot(slot, { netID: 0, stack: 0, prefix: 0, favorited: false })
      })
      editorEl.querySelector('#tswp-se-cancel').addEventListener('click', function () {
        editorEl.remove(); editorEl = null
      })
      editorEl.querySelector('#tswp-se-ok').addEventListener('click', function () {
        var netID = parseInt(editorEl.querySelector('#tswp-se-netid').value, 10) || 0
        var stack = parseInt(editorEl.querySelector('#tswp-se-stack').value, 10) || 0
        var prefix = parseInt(editorEl.querySelector('#tswp-se-prefix').value, 10) || 0
        applySlot(slot, { netID: netID, stack: stack, prefix: prefix, favorited: !!item.favorited })
      })

      function applySlot(s, data) {
        detailState.doc.inventory[s] = data
        editorEl.remove()
        editorEl = null
        renderInventory(root)
      }
    }
  }

  // 收集背包改动 ops（对比渲染时的原值）
  function collectInvOps(container) {
    var ops = []
    var inv = detailState.doc.inventory || []
    var original = detailState._invOriginal || []
    for (var s = 0; s < inv.length; s++) {
      var it = inv[s]
      var old = original[s]
      if (!it || !old) continue
      if (it.netID !== old.netID || it.stack !== old.stack || it.prefix !== old.prefix || !!it.favorited !== !!old.favorited) {
        // 注意：固定长度数组，清空格子用 replace 全 0 对象（remove 会缩短数组导致槽位错位）
        ops.push({ op: 'replace', path: '/inventory/' + s, value: { slot: s, netID: it.netID, prefix: it.prefix, stack: it.stack, favorited: !!it.favorited } })
      }
    }
    return ops
  }

  // ═══════════ patch 提交 ═══════════
  async function doPatch(container, username, ops, msgSel) {
    var msg = container.querySelector(msgSel)
    msg.textContent = '保存中...'
    msg.className = 'tswp-act-msg'
    var res = await api('/api/players/' + encodeURIComponent(username), {
      method: 'PATCH',
      json: { ops: ops }
    })
    if (!res.ok) {
      msg.textContent = '保存失败: ' + ((res.data && res.data.error) || res.status)
      msg.className = 'tswp-act-msg err'
      return
    }
    msg.textContent = '已保存（' + ops.length + ' 个操作），文档已刷新'
    msg.className = 'tswp-act-msg ok'
    // 用服务端返回的最终文档刷新本地状态
    if (res.data && res.data.document) {
      detailState.doc = res.data.document
      detailState._invOriginal = null
      var cur = location.hash
      // 重新渲染（保持当前用户名）
      renderDetail(container, username)
    }
  }

  // ═══════════ 单账号重复 IP ═══════════
  async function renderSingleDuplicateIps(container, username) {
    container.innerHTML = '<div class="panel"><p class="muted">加载中...</p></div>'
    var res = await api('/api/players/duplicateips?username=' + encodeURIComponent(username))
    if (!res.ok) {
      container.innerHTML = '<div class="panel"><p class="error">' + esc((res.data && res.data.error) || '加载失败') + '</p>' +
        '<button class="ghost sm" data-back-detail="1" style="margin-top:10px">返回详情</button></div>'
      bindBack(container, true)
      return
    }
    var d = res.data || {}
    var html = '<div class="toolbar" style="margin-bottom:14px"><h2 style="margin:0;font-size:17px">重复 IP / UUID：' + esc(d.targetUser || username) + '</h2>' +
      '<div class="spacer"></div><button class="ghost sm" data-back-detail="1">返回详情</button></div>'
    if (!d.duplicates || !d.duplicates.length) {
      html += '<div class="panel"><p class="muted" style="text-align:center;padding:20px 0">未发现关联账号（共 ' + (d.totalAccounts || 1) + ' 个账号）</p>' +
        '<div style="padding:0 14px 14px" class="muted" style="font-size:12px;display:flex;align-items:center;gap:6px">' +
        '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>' +
        '<span>该账号 IP: ' + esc((d.targetIPs || []).join(', ')) + '</span></div></div>'
    } else {
      html += '<div class="panel" style="padding:0;overflow:hidden"><div style="padding:12px 14px;border-bottom:1px solid var(--border);background:color-mix(in srgb, var(--muted) 50%, var(--card))">' +
        '<span style="font-weight:600;font-size:13px">发现 ' + d.count + ' 个关联账号</span>' +
        '<span class="muted" style="font-size:12px;margin-left:8px">共享 ' + esc((d.sharedIPs || []).length) + ' 个 IP</span></div>' +
        '<table class="tswp-table"><thead><tr><th style="width:90px">账号 ID</th><th>用户名</th></tr></thead><tbody>' +
        d.duplicates.map(function (x) {
          return '<tr><td>' + esc(x.ID) + '</td><td><span class="tswp-link" data-user="' + esc(x.Username) + '">' + esc(x.Username) + '</span></td></tr>'
        }).join('') +
        '</tbody></table></div>' +
        '<div class="panel" style="margin-top:10px"><div class="muted" style="font-size:12px;display:flex;align-items:center;gap:6px">' +
        '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>' +
        '<span>共享 IP: ' + esc((d.sharedIPs || []).join(', ')) + '</span></div></div>'
    }
    container.innerHTML = html
    bindBack(container, true)
    container.querySelectorAll('[data-user]').forEach(function (a) {
      a.addEventListener('click', function () {
        location.hash = '/s/players/' + encodeURIComponent(a.getAttribute('data-user'))
      })
    })
  }

  // ═══════════ 通用 ═══════════
  function bindBack(container, detail) {
    var btn = container.querySelector('#tswp-back') || container.querySelector('[data-back-detail]')
    if (btn) btn.addEventListener('click', function () {
      location.hash = detail ? '/s/players/' + encodeURIComponent(detailState.username) : '/s/players'
    })
  }

  function showErr(el, msg) {
    var errEl = el.querySelector('#tswp-error')
    if (errEl) { errEl.textContent = msg; errEl.classList.remove('hidden') }
  }
  function hideErr() { /* 每次渲染新容器无需处理 */ }

  function debounce(fn, ms) {
    var t = null
    return function () {
      var args = arguments
      clearTimeout(t)
      t = setTimeout(function () { fn.apply(null, args) }, ms)
    }
  }

  // ═══════════ 视图注册 ═══════════
  window.tsweb.registerView({
    id: 'players',
    title: '玩家管理',
    section: '服务器设置',
    path: '/s/players',
    render: function (container) {
      var hash = location.hash || '#/s/players'
      var parts = hash.replace(/^#\//, '').split('/')
      var sub = parts[2]
      if (sub) renderDetail(container, decodeURIComponent(sub))
      else renderList(container)
    }
  })
})()
