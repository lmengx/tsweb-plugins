/**
 * 默认违禁清单（插件内 `resources/`）—— 「应用默认配置」的数据源
 *
 * ══════════ 为什么放在插件内 resources/ 而不是 data/ ══════════
 * `scripts/pack-plugin.mjs:54` 的 `SKIP_DIRS` **排除 `data/`**（那是"状态数据"的约定位置，
 * 不该进发行包），所以默认清单放 `data/` 会被打包器丢掉、装到用户机器上就不存在。
 * 放 `resources/` 既能进包（不是排除项、也不是被排除的扩展名），又语义清晰（只读资源）。
 *
 * ══════════ 两个来源的核对结论（对应必改缺陷 #11「默认清单要移植」）══════════
 * 旧版存在**三份**同名"违禁"JSON（规格 B §5.1 已逐条核实）：
 *   ① backend/resources/默认配置/物品违禁.json   19 档 / 119 条  ← **活跃**，后端 anticheatDefaults.js 读取下发
 *   ② backend/resources/默认配置/弹幕违禁.json   11 档 /  53 条  ← **活跃**，同上
 *   ③ scripts/数据/弹幕违禁.json                  8 档 /  22 条  ← **死文件**：全仓库 0 处代码引用，
 *      且内容特征与权威文件矛盾（`启用:true` 而权威是 false；缺 双子魔眼/机械骷髅王/猪龙鱼公爵 三档）
 * 本件**只移植 ①②**，并逐条确认：①②同源（同一份"后端权威默认清单"的两种品类），
 * ③ 是旧版遗留的死文件，**不作为数据源**（照规格 B §5.1 的显式结论「不要把它当作数据源迁移」）。
 *
 * ══════════ 移植时补齐的数据内容（对应必改缺陷 #10）══════════
 * 移植不是逐字照抄：规格 B §4.6 列出的**仍然成立**的数据缺陷里有 4 条被本次补齐，
 * 每一条都在下面 `APPLIED_DATA_FIXES` 里逐条记明"补了什么 / 依据是什么"，
 * 并由 test/defaults-migration.test.mjs 对"旧版条目一条不少 + 只多了这些"做差异断言。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

import { ENTRY_KEY, defaultConfig, normalizeConfig, progressOrder } from './config.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

/** 默认清单文件名（资源目录下的两份，逐字沿用旧版文件名以便对照） */
export const ITEM_DEFAULT_FILE = '物品违禁.json'
export const PROJ_DEFAULT_FILE = '弹幕违禁.json'

/** 资源目录（插件内，不是 data/） */
export const RESOURCES_DIR = path.join(__dirname, 'resources')

/**
 * 移植时补齐/修正的数据内容，逐条记明依据。
 * 每一项都会被 test/defaults-migration.test.mjs 用于生成"相对旧版的差异清单"断言，
 * 即：**除了这里列出来的，不允许有任何其它差异**。
 */
export const APPLIED_DATA_FIXES = [
  {
    id: 'D-28',
    scope: 'item',
    what: '新增「巨鹿」档（1 条）：天气收音机 3037，stack 1，method log',
    why:
      '规格 B §4.6 D-28 逐字：「巨鹿（独眼巨鹿）档整体缺失」→「独眼巨鹿掉落（鹿华/天气收音机/独眼巨鹿眼等）无任何进度限制」。' +
      '档位插在「蜂后」与「骷髅王」之间，与旧 GetWorldInfo.cs:48-65 `BossOrder` 的进度顺序一致。' +
      '条目取 3037（天气收音机，物品字典 internal=WeatherRadio，独眼巨鹿掉落物）；method 用 log 是照报告 D-28 的写法' +
      '（独眼巨鹿在暴雪夜可提前遭遇，用 log 只记账不误踢）；未收录纪念章/面具/圣物/八音盒等纯装饰掉落，' +
      '因为旧版其它档位同样不收录它们（如「史莱姆王」档只有 3090 皇家凝胶，没有纪念章/面具）。',
  },
  {
    id: 'D-32',
    scope: 'proj',
    what: '「始终生效」档补 6 条：28 炸弹 kick、29 雷管 ban、30 手榴弹 kick、133 榴弹一型 kick、139 榴弹三型 kick、140 火箭三型 kick',
    why:
      '规格 B §4.6 D-32 逐字：「始终生效档爆炸物不完整（只有 II/IV 级）」→「I/III 级及炸弹/雷管弹幕不拦」→' +
      '「补 133/139/140、28/29/30 等」。旧文件该档已有 榴弹二型(136)/四型(142)、火箭二型(137)/四型(143)、' +
      '感应雷二型(138)/四型(144)、炸药(108)、地雷(164) —— **一型与三型是同一族的显式缺号**，属清单不完整而非策略变更。' +
      'method 取值照该档既有规律：基础炸药类（108 炸药 / 164 地雷）是 ban，发射器弹药族是 kick；' +
      '故 29 雷管（Dynamite，破坏力最强）取 ban，28 炸弹 / 30 手榴弹 / 133 / 139 / 140 取 kick。',
  },
  {
    id: 'D-27',
    scope: 'proj',
    what: '「光之女皇」档新增 927（星光）kick',
    why:
      '规格 B §4.6 D-27 逐字：「弹幕 927（星光弹）缺失（物品侧 4923 星光已收）」→「使用星光剑不实时拦截」→「光之女皇档新增 927」。' +
      '核对：物品侧「光之女皇」档**确实已收录 4923 星光**（物品字典 internal=Starlight），弹幕侧却漏了它的弹幕 927（internal=Starlight）——' +
      '这是同一个武器"物品拦了、弹幕没拦"的口径不一致。',
  },
  {
    id: 'D-30',
    scope: 'proj',
    what: '「光之女皇」档新增 946（泰拉棱镜）kick',
    why:
      '规格 B §4.6 D-30 逐字：「弹幕 946（泰拉棱镜弹）档位错放」→ 报告建议「移动到光之女皇档」，' +
      '而「当前文件里 946 已不存在」→「需确认是「删除」还是「移动未落地」，若落实为删除则应补到光之女皇档」。' +
      '核对：旧文件里 946 确实**不存在于任何档位**（属"删除而非移动"），而物品侧「光之女皇」档已收录 5005 泰拉棱镜——' +
      '同样是"物品拦了、弹幕漏了"。故照报告落实为**补进光之女皇档**。',
  },
]

/**
 * 未被本次采纳的数据缺陷（**必须逐条留痕**，否则"补齐了哪些"无从核对）。
 * 这三条都来自规格 B §4.6，本件维持旧版现状并给出理由。
 */
export const DEFERRED_DATA_DECISIONS = [
  {
    id: 'D-29',
    decision: '照搬（不补）',
    detail:
      '弹幕侧 9 个低进度档空白（哥布林/史莱姆王/克苏鲁之眼/世界吞噬者/克苏鲁之脑/巨鹿/骷髅王/史莱姆皇后/毁灭者）。' +
      '报告自身的建议就是「克苏鲁之眼/脑/吞噬者/骷髅王/哥布林**维持空档**（误伤风险 > 收益）」；' +
      '「史莱姆皇后补刃杖弹幕（ID 待查）」——在 data-projectiles 的 ProjectileData.json 里按中文名/英文名/internal 三种口径' +
      '检索「刃杖 / BladeStaff / Blade Staff」均**无命中**，ID 无法确认，故不臆造；' +
      '「毁灭者补巨兽鲨弹幕（意义有限）」——巨兽鲨(533) 是枪，发射的是通用子弹弹幕，没有专属弹幕可拦，确实"意义有限"。',
  },
  {
    id: 'D-31',
    decision: '照搬（不收紧）',
    detail:
      '拜月教档 4 条 log（617/630/631/635）可收紧为 kick/ban。报告标 P3「可选」，属策略选择而非缺陷；' +
      '收紧会提高误封面，且 log 档同样会落检测日志（管理员可据此自行在界面上改成 ban），故维持旧版。',
  },
  {
    id: 'D-33',
    decision: '不适用（不补）',
    detail:
      '物品侧「始终生效」只有大师鱼饵，报告建议「如需防『背包囤爆炸物』可补 166/167/168」。' +
      '**不采纳**的理由：本次已在弹幕侧「始终生效」档补齐了爆炸物的**使用**拦截（含 28/29/30），' +
      '实际破坏路径已被覆盖；物品侧是「持有即违规」（判定 `stack >= Stack`，旧 item-restrict.cs:187），' +
      '而炸弹/雷管/手榴弹是**正常游玩中普遍存在于背包**的物品，无论阈值取多少都会造成大面积误踢（阈值 1 立刻误踢、' +
      '阈值 99 则几乎永不命中而形同虚设）；报告原文也只是条件句「如需…可补」，不是结论。',
  },
]

/**
 * 读并缓存两份默认清单。
 *
 * 返回 `{ config, warnings, error }`：
 *   - 读不到 / 不是合法 JSON → `config` 为"默认开关 + 空清单"、`error` 写明原因。
 *     **绝不静默返回空清单**：那会让「应用默认配置」把管理员的清单清空（旧版"应用默认配置"静默重置字段的同一形态）。
 *   - 归一过程里的警告（档位/条目被跳过等）进 `warnings`，由路由回显。
 */
let _cache = null

export async function loadDefaults() {
  if (_cache) return _cache
  _cache = await readDefaults()
  return _cache
}

/** 仅供测试重置缓存（生产路径不需要） */
export function resetDefaultsCache() {
  _cache = null
}

async function readDefaults() {
  const files = [
    { kind: 'item', file: path.join(RESOURCES_DIR, ITEM_DEFAULT_FILE) },
    { kind: 'proj', file: path.join(RESOURCES_DIR, PROJ_DEFAULT_FILE) },
  ]
  const config = defaultConfig()
  const warnings = []
  const errors = []

  for (const { kind, file } of files) {
    let raw
    try {
      raw = await readFile(file, 'utf8')
    } catch (err) {
      errors.push(`默认清单缺失：${file}（${err.message}）`)
      continue
    }
    let parsed
    try {
      parsed = JSON.parse(raw)
    } catch (err) {
      errors.push(`默认清单不是合法 JSON：${file}（${err.message}）`)
      continue
    }
    const normalized = normalizeConfig({ [kind]: parsed })
    config[kind] = normalized.config[kind]
    for (const w of normalized.warnings) warnings.push(`默认清单 ${path.basename(file)}：${w}`)
  }

  const entries = (kind) => (config[kind].限制列表 || []).reduce((n, t) => n + (t[ENTRY_KEY[kind]] || []).length, 0)
  return {
    config,
    warnings,
    error: errors.join('；'),
    stats: {
      itemTiers: config.item.限制列表.length,
      itemEntries: entries('item'),
      projTiers: config.proj.限制列表.length,
      projEntries: entries('proj'),
    },
    files: {
      item: path.join(RESOURCES_DIR, ITEM_DEFAULT_FILE),
      proj: path.join(RESOURCES_DIR, PROJ_DEFAULT_FILE),
    },
    fixes: APPLIED_DATA_FIXES,
    deferred: DEFERRED_DATA_DECISIONS,
  }
}

/**
 * 「应用默认配置」的**预览**（不写任何东西）。
 *
 * 必改缺陷 #6 要求这个动作「显式、可预览、可审计」。本函数给出：
 *   - 将替换掉的档位（默认清单里的档位）
 *   - 会**新增**的档位 / 会**消失**的档位（管理员自定义的档位在 scope 内会被替换掉，必须让他看见）
 *   - 开关是否变化（默认**不动开关**，只有 `includeSwitches` 为真才动）
 *
 * @param {object} current 当前配置（归一后）
 * @param {object} defaults 默认清单
 * @param {{scope?: 'item'|'proj'|'both', includeSwitches?: boolean}} [opts]
 */
export function previewDefaults(current, defaults, opts = {}) {
  const scope = normalizeScope(opts.scope)
  const includeSwitches = opts.includeSwitches === true
  const out = { scope, includeSwitches, kinds: {} }

  for (const kind of scope) {
    const curTiers = (current[kind]?.限制列表 || []).map((t) => t.进度)
    const defTiers = (defaults[kind]?.限制列表 || []).map((t) => t.进度)
    const curSet = new Set(curTiers)
    const defSet = new Set(defTiers)
    const entriesNow = (current[kind]?.限制列表 || []).reduce((n, t) => n + (t[ENTRY_KEY[kind]] || []).length, 0)
    const entriesAfter = (defaults[kind]?.限制列表 || []).reduce((n, t) => n + (t[ENTRY_KEY[kind]] || []).length, 0)

    out.kinds[kind] = {
      档位_现在: curTiers,
      档位_应用后: defTiers,
      新增档位: defTiers.filter((t) => !curSet.has(t)),
      消失档位: curTiers.filter((t) => !defSet.has(t)),
      条数_现在: entriesNow,
      条数_应用后: entriesAfter,
      // 开关变化：默认不动；只有 includeSwitches 才列出将改动的项
      开关变化: includeSwitches ? switchDiff(current[kind], defaults[kind], kind) : [],
    }
  }

  // 档位顺序来自数据派生（config.js:progressOrder），预览里一并给出应用后的卡片顺序
  const hypothetical = { ...current }
  for (const kind of scope) hypothetical[kind] = defaults[kind]
  out.progressOrder = progressOrder(hypothetical)
  return out
}

function switchDiff(cur, def, kind) {
  const keys = kind === 'item' ? ['启用', '自动扫描', '扫描间隔', '没收违禁物品'] : ['启用', '伤害上限']
  const diffs = []
  for (const key of keys) {
    if (cur?.[key] !== def?.[key]) diffs.push({ 字段: key, 现在: cur?.[key], 应用后: def?.[key] })
  }
  return diffs
}

/**
 * 应用默认清单（**纯函数，不落盘**；落盘与下发由路由负责，见 index.js）。
 *
 * 关键语义（对应必改缺陷 #6）：
 *   1. **只替换 `限制列表`**（弹幕侧连 `伤害上限` 也不动，除非 includeSwitches）；
 *      开关（启用/自动扫描/扫描间隔/没收违禁物品/伤害上限）默认保持**现值**。
 *      旧版的「应用默认配置」是把默认 JSON 整体写下去，而默认 JSON **没有 `没收违禁物品` 键**，
 *      于是反序列化回落 false → 管理员已开启的没收被**静默关掉**。本件从两头避免：
 *      ① 资源文件补上了该键；② 应用默认配置默认不碰开关，且预览里明确列出"开关变化"。
 *   2. `scope` 决定动哪一侧（item/proj/both），另一侧**原样保留**（旧版两侧是两次独立下发）。
 *   3. 结果里返回 `changes`（改动摘要），由调用方写进审计与响应体。
 */
export function applyDefaults(current, defaults, opts = {}) {
  const scope = normalizeScope(opts.scope)
  const includeSwitches = opts.includeSwitches === true
  const next = normalizeConfig(current).config
  const changes = []

  for (const kind of scope) {
    const before = next[kind].限制列表 || []
    const after = defaults[kind].限制列表 || []
    next[kind].限制列表 = JSON.parse(JSON.stringify(after))
    changes.push({
      kind,
      档位: `${before.length} → ${after.length}`,
      条数: `${before.reduce((n, t) => n + (t[ENTRY_KEY[kind]] || []).length, 0)} → ${after.reduce((n, t) => n + (t[ENTRY_KEY[kind]] || []).length, 0)}`,
    })
    if (includeSwitches) {
      const keys = kind === 'item' ? ['启用', '自动扫描', '扫描间隔', '没收违禁物品'] : ['启用', '伤害上限']
      for (const key of keys) {
        const from = next[kind][key]
        const to = defaults[kind][key]
        if (from !== to) {
          next[kind][key] = to
          changes.push({ kind, 字段: key, 从: from, 到: to })
        }
      }
    }
  }

  return { config: next, changes, scope, includeSwitches }
}

function normalizeScope(scope) {
  if (scope === 'item') return ['item']
  if (scope === 'proj') return ['proj']
  return ['item', 'proj']
}
