/**
 * anti-cheat 配置落盘（宿主侧状态数据，位置由 ctx.paths.dataOf('anti-cheat') 决定）
 *
 * 为什么不能写进插件目录：`docs/插件开发约定.md:154-161` 明确"状态数据一律走 ctx.paths.dataOf()"，
 * 插件目录在卸载/更新时会被删除，配置放那里等于"更新即丢配置"。
 *
 * 读写语义（照 promotion/config.js:296-351 的既有做法，理由同源）：
 *   - 文件不存在 → 默认配置 + existed=false（不是错误）
 *   - 非法 JSON / 顶层不是对象 → **也返回默认配置**，同时把原因放进 error 字段（绝不抛错）：
 *     插件装载失败会让管理员连配置页都进不去，等于没有修复入口；
 *     而"按默认运行"在反作弊上是**安全方向**（默认未启用，不会误踢误封）。
 *   - 落盘一律**原子**（.tmp + rename，并保留 .bak）：半个文件不会被下一次读取当成配置。
 *     旧版是 `File.WriteAllText` 直接覆写（旧 AntiCheat.cs:316、:125、:270、:91），
 *     写到一半崩溃/磁盘满 → 配置文件损坏 → 下次 LoadConfig 走 catch → **静默回退为全新默认配置**，
 *     违禁清单整体丢失（旧版缺陷 §7 #18）。这里从两头堵住：原子写 + 读失败明确报错。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import { copyFile, mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import path from 'node:path'

import { defaultConfig, normalizeConfig } from './config.js'

/**
 * 读配置。返回 `{ config, warnings, existed, error }`，**永不抛错**。
 * @param {string} file 配置文件绝对路径
 */
export async function loadConfigFile(file) {
  let raw
  try {
    raw = await readFile(file, 'utf8')
  } catch (err) {
    if (err.code === 'ENOENT') return { config: defaultConfig(), warnings: [], existed: false, error: '' }
    return {
      config: defaultConfig(),
      warnings: [],
      existed: true,
      error: `配置文件读取失败（${file}）：${err.message}；已按默认配置（检测未启用）运行`,
    }
  }

  let parsed
  try {
    parsed = JSON.parse(raw)
  } catch (err) {
    return {
      config: defaultConfig(),
      warnings: [],
      existed: true,
      error: `配置文件不是合法 JSON（${file}）：${err.message}；已按默认配置（检测未启用）运行，请修复后重新保存`,
    }
  }

  const { config, warnings } = normalizeConfig(parsed)
  return { config, warnings, existed: true, error: '' }
}

/**
 * 原子落盘。失败**抛错**（调用方必须让管理员看见，绝不静默）——
 * 旧版物品侧 `SaveConfig()` 无返回值、失败只打一行控制台日志（旧 AntiCheat.cs:299-302、:318-321），
 * 管理员在界面上完全看不出"保存没生效"。
 */
export async function saveConfigFile(file, config) {
  const payload = JSON.stringify(normalizeConfig(config).config, null, 2)
  await mkdir(path.dirname(file), { recursive: true })
  const tmp = `${file}.tmp`
  await writeFile(tmp, payload, 'utf8')
  try {
    await copyFile(file, `${file}.bak`)
  } catch (err) {
    if (err.code !== 'ENOENT') throw err
  }
  await rename(tmp, file)
  return file
}
