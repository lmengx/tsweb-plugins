/**
 * 游戏服调用层（宿主 → TShock）
 *
 * 本件用自己的端点前缀 `/data/anticheat/*`，**不复用**任何其它插件的前缀：
 * 两个插件各自独立发布，共用前缀会让"DLL 没装"的 404 无法区分是哪一半缺失。
 * 前缀先例：plugins/online-stats 的 `/data/online`、plugins/promotion 的 `/data/promotion`。
 *
 * ══════════ 传输契约（必改缺陷 #5：大配置不许走 URL query）══════════
 * 旧版把**整份清单**塞进 URL query（旧 tshockService.js:1201、:1275：
 * `POST …/saveitemconfig?config=${encodeURIComponent(JSON.stringify(config))}`）：
 * 默认清单 119 条约 12 KB JSON，`encodeURIComponent` 后（中文按字节展开）URL 约 15–20 KB
 * → ① 常见反代/HTTP 实现有 8 KB URL 上限，超限直接 414；② 整条 URL 进 access log 与
 * tshockService 的 console.log（redactUrl 只脱 token，不脱 config）。
 *
 * 本件的做法（三条一起，缺一不可）：
 *   1. **优先 POST + form body**（`ctx.tshock.postFor`，见 plugins/servers/index.js:238-256）：
 *      token 仍走 query，载荷走 body，没有 URL 长度上限。servers 插件的注释已实证
 *      「TShock 的 SecureRestCommand 只读 Request.Parameters，该集合由 query 与 form body 合并」，
 *      所以服端代码不变。
 *   2. **旧式 query 形态保留兼容**（宿主没有 postFor 时退化为 GET + query），但带
 *      `MAX_QUERY_BYTES` 上限校验；
 *   3. 超限时**逐服可见地失败**（抛 502 并写明"这台服没收到配置、原因是载荷过大且宿主缺少 postFor"），
 *      绝不静默跳过 —— 静默跳过就是"界面显示已保存、实际那台服还是旧清单"。
 *
 * ══════════ 错误语义（与 online-stats / promotion / task-scheduler 的既有约定一致）══════════
 *   404      → 501 + serverHalfMissing=true（目标服没装 AntiCheat.dll）
 *   401/403  → 502（token 缺本插件端点要求的权限）
 *   400      → 400 + 服端原文（参数被服端拒绝，不要让管理员只看到"游戏服返回异常"）
 *   网络/超时 → 502
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import { normalizeConfig, toGamePayload } from './config.js'

/** 游戏服半的端点前缀 */
export const SERVER_HALF_PREFIX = '/data/anticheat'

/** 游戏服半的 DLL 名（报错文案用） */
export const DLL_NAME = 'AntiCheat.dll'

/**
 * 本件**协议端点**在 TShock 侧注册所用的权限节点。
 *
 * 用 `data.rest.invsee`：这是本仓"宿主 → 游戏服"通道的统一口径
 * （promotion / status-panel / task-scheduler / qq-bind / base / online-stats 全部如此），
 * 即本宿主的 REST token 已被证明持有的权限。此处必须与
 * `plugin/AntiCheatEndpoints.cs` 里 snapshot/status/logs/log/check-anomaly/scan 的注册权限一致，
 * 否则权限真不足时本文件给出的报错文案会把权限名说错。
 *
 * 关于旧版 D-14（"只授看背包权限的组能读全服检测日志"）：那是**旧架构**的缺陷。
 * 旧版把游戏服 REST 端点直接暴露给前端，游戏服权限节点于是成了最终用户的授权边界，
 * 而旧版日志端点错用了 `data.rest.invsee`（旧 `Main.cs:215-216`），
 * 同一文件其余端点却是 `tshock.admin`（旧 `Main.cs:133-139`）。
 * 新架构下这个端点只有宿主（服务器到服务器、用宿主自己的 token）会调用，
 * 最终用户读检测日志的授权由**宿主层**决定（一律 admin-only，见 `index.js`），
 * 所以 D-14 是在宿主层修的，**不能**靠换游戏服权限节点来修。
 *
 * 另注：旧版兼容别名（`item-config/*`、`proj-config/*`、`enable`）的权限逐字沿用旧版的
 * `tshock.admin`，见 `plugin/AntiCheatEndpoints.cs` 的权限表；那些是给旧调用方用的，
 * 不在本常量描述范围内。
 */
export const REST_PERMISSION = 'data.rest.invsee'

/**
 * 退化为 GET + query 时允许的最大 URL 字节数。
 * 取 6 KB（而不是常见的 8 KB 上限）：留出 token、主机名与其它参数的空间，
 * 并且这是"宁可显式失败也不要被反代截断成 414"的保守值。
 */
export const MAX_QUERY_BYTES = 6000

/** 构造带 status 的错误（宿主路由按 err.status 回状态码） */
export function httpError(status, message, extra = {}) {
  const err = new Error(message)
  err.status = status
  Object.assign(err, extra)
  return err
}

/**
 * "端点缺失（404）"的默认口径：本件自己的端点在 404 时只可能是游戏服没装 AntiCheat.dll。
 */
const DEFAULT_MISSING = {
  status: 501,
  dllName: DLL_NAME,
  message: `游戏服端未安装 ${DLL_NAME}`,
  hint: '请在「插件下发」页对该服务器启用本插件',
}

/** 把 unknown 归一成字符串数组（服端可能回数组/JSON 串/逗号串） */
function toStrList(value) {
  if (Array.isArray(value)) return value.map(String)
  if (typeof value === 'string' && value.trim() !== '') {
    return value.split(/[\s,;，；]+/).filter((s) => s !== '').map(String)
  }
  return []
}

/** 服端回的统计块（结构异常时给零值，不让上层拿到 null） */
function toStats(value) {
  const v = value && typeof value === 'object' && !Array.isArray(value) ? value : {}
  const num = (x) => (Number.isFinite(Number(x)) ? Number(x) : 0)
  return {
    total: num(v.total),
    today: num(v.today),
    byCategory: value && typeof v.byCategory === 'object' && v.byCategory !== null ? v.byCategory : {},
    byMethod: value && typeof v.byMethod === 'object' && v.byMethod !== null ? v.byMethod : {},
    recent: Array.isArray(v.recent) ? v.recent : [],
  }
}

/**
 * 把服端返回的整份配置归一（服端可能回旧形态/坏值；一律经本件的归一，保证上层拿到的东西合法）。
 * 注意：**不把"服端回的配置缺字段"当错误**——服端版本可能比宿主旧，归一正是为了对齐。
 */
function toEffectiveConfig(data) {
  const src = data && typeof data === 'object' ? data : {}
  return normalizeConfig({
    item: src.item ?? src.itemConfig ?? undefined,
    proj: src.proj ?? src.projConfig ?? undefined,
  }).config
}

/**
 * 创建游戏服调用层。
 * @param {{ctx: object}} deps
 */
export function createGameOps({ ctx }) {
  const log = (...args) => console.log('[anti-cheat]', ...args)

  /** 统一把调用结果翻成数据或抛错（dll 名用于把 404 说清楚） */
  function unwrap(result, server, what, missing = DEFAULT_MISSING) {
    const status = Number(result?.status) || 0
    if (status === 404) {
      throw httpError(missing.status, missing.message, {
        serverId: server.id,
        serverHalfMissing: true,
        dllName: missing.dllName,
        hint: missing.hint,
        what,
      })
    }
    if (status === 401 || status === 403) {
      throw httpError(502, `游戏服拒绝了 ${what}（HTTP ${status}）：REST token 缺少 ${REST_PERMISSION} 权限`, {
        serverId: server.id,
        // ★ 不能叫 status：httpError（:71-76）先设 err.status=502 再 Object.assign(extra)，
        //   用 status 当键会把 502 覆盖成服端的 401/403，宿主按 err.status 回码 → 浏览器收到 401
        //   以为"自己没登录"（前端会去重新登录），而真实原因是游戏服 token 权限不足。改名 serverStatus。
        serverStatus: status,
        what,
      })
    }
    if (status === 400) {
      const detail = result?.data?.error || result?.data?.message || '参数被游戏服拒绝'
      throw httpError(400, `游戏服拒绝了 ${what}（HTTP 400）：${detail}`, { serverId: server.id, what })
    }
    if (!result || result.ok !== true) {
      const detail = result?.data?.error || result?.data?.message || `HTTP ${status || '无响应'}`
      // 同上：status 会覆盖 httpError 设的 502（服端 500/0 会让宿主回 500 甚至 0），改名 serverStatus。
      throw httpError(502, `${what}失败：${detail}`, { serverId: server.id, serverStatus: status, what })
    }
    const data = result.data
    if (data && typeof data === 'object' && data.error) {
      // 服端把错误包在 200 里（旧版 /logs 的形态，见规格 B §4.2）：**必须当失败**
      throw httpError(502, `${what}失败：${data.error}`, { serverId: server.id, what })
    }
    return data || {}
  }

  /** 启用中的服务器列表（raw 记录，含 token） */
  async function enabledServers() {
    const list = await ctx.servers.list()
    const out = []
    for (const summary of list || []) {
      const raw = ctx.servers.getRaw(summary.id)
      if (!raw) continue
      if (raw.enabled === false) continue
      out.push(raw)
    }
    return out
  }

  return {
    enabledServers,
    log,

    /**
     * 下发给某台服（`POST {prefix}/snapshot`）。
     *
     * 参数形态与服端 AntiCheatEndpoints.cs 逐字对应：
     *   version  正整数，宿主侧单调（服端拒绝更旧的载荷）
     *   item     物品侧配置 JSON 字符串（旧「物品违禁.json」的完整形态）
     *   proj     弹幕侧配置 JSON 字符串（旧「弹幕违禁.json」的完整形态）
     *   ts       宿主下发时间（只进日志，不参与判定）
     *
     * @returns {Promise<object>} 服端回包（含 applied / stale / version / notes / 生效配置）
     */
    async pushConfig(server, { version, config, ts }) {
      const payload = toGamePayload(config)
      const params = { version: String(version), item: payload.item, proj: payload.proj, ts: String(ts || '') }
      const what = '下发违禁清单'

      // ① 优先 POST + form body：没有 URL 长度上限（这正是必改缺陷 #5 要求的做法）
      if (typeof ctx.tshock.postFor === 'function') {
        let result
        try {
          result = await ctx.tshock.postFor(server, `${SERVER_HALF_PREFIX}/snapshot`, params)
        } catch (err) {
          throw httpError(err.status || (err.type === 'timeout' ? 504 : 502), `${what}失败：${err.message}`, {
            serverId: server.id,
            what,
          })
        }
        return unwrap(result, server, what)
      }

      // ② 兼容：宿主没有 postFor 时退化为 GET + query，但先做上限校验
      const encoded = new URLSearchParams(params).toString()
      const bytes = Buffer.byteLength(encoded, 'utf8')
      if (bytes > MAX_QUERY_BYTES) {
        throw httpError(
          502,
          `${what}失败：清单编码后 ${bytes} 字节，超过 GET+query 的 ${MAX_QUERY_BYTES} 字节上限，` +
          '而当前宿主版本不提供 ctx.tshock.postFor（无法改走 body）——这台服**没有收到**本次清单，' +
          '请升级宿主，或先减小清单规模',
          { serverId: server.id, what, bytes, maxBytes: MAX_QUERY_BYTES, queryOnly: true },
        )
      }
      let result
      try {
        result = await ctx.tshock.fetchFor(server, `${SERVER_HALF_PREFIX}/snapshot`, params)
      } catch (err) {
        throw httpError(err.status || (err.type === 'timeout' ? 504 : 502), `${what}失败：${err.message}`, {
          serverId: server.id,
          what,
        })
      }
      return unwrap(result, server, what)
    },

    /**
     * 读某台服**实际生效**的整份配置 + 自证信息（`GET {prefix}/status`）。
     * 这是"界面写了什么"与"服端真的按什么在检测"之间的唯一直接证据。
     */
    async status(server) {
      let result
      try {
        result = await ctx.tshock.fetchFor(server, `${SERVER_HALF_PREFIX}/status`, {})
      } catch (err) {
        throw httpError(err.status || (err.type === 'timeout' ? 504 : 502), `读取服端状态失败：${err.message}`, {
          serverId: server.id,
        })
      }
      const data = unwrap(result, server, '读取服端状态')
      return {
        config: toEffectiveConfig(data),
        version: Number(data.version) || 0,
        updatedAt: String(data.updatedAt || ''),
        source: String(data.source || ''),
        file: String(data.file || ''),
        legacyFiles: toStrList(data.legacyFiles),
        saveError: String(data.saveError || ''),
        importedLegacy: data.importedLegacy === true,
        importNotes: toStrList(data.importNotes),
        detection: data.detection && typeof data.detection === 'object' ? data.detection : {},
        logStore: data.logStore && typeof data.logStore === 'object' ? data.logStore : {},
        trigger: String(data.trigger || ''),
        hooks: toStrList(data.hooks),
      }
    },

    /**
     * 分页查某台服的检测日志（`GET {prefix}/logs`）。
     * 参数与旧 AntiCheatLog.GetLogsApi 逐字对应（规格 A §5.6）：8 个筛选/分页参数。
     */
    async logs(server, query = {}) {
      let result
      try {
        result = await ctx.tshock.fetchFor(server, `${SERVER_HALF_PREFIX}/logs`, {
          page: query.page,
          pageSize: query.pageSize,
          category: query.category,
          method: query.method,
          player: query.player,
          q: query.q,
          // 参数名逐字对齐旧 AntiCheatLog.GetLogsApi（旧 AntiCheatLog.cs:162 的 remarks）：
          // page / pageSize / player / category / method / **timeFrom** / **timeTo** / q
          timeFrom: query.timeFrom,
          timeTo: query.timeTo,
        })
      } catch (err) {
        throw httpError(err.status || (err.type === 'timeout' ? 504 : 502), `读取检测日志失败：${err.message}`, {
          serverId: server.id,
        })
      }
      const data = unwrap(result, server, '读取检测日志')
      return {
        rows: Array.isArray(data.rows) ? data.rows : [],
        total: Number(data.total) || 0,
        page: Number(data.page) || 1,
        pageSize: Number(data.pageSize) || 0,
        totalPages: Number(data.totalPages) || 0,
      }
    },

    /** 统计（`GET {prefix}/logs/stats`），支持与列表同一个筛选口径（必改缺陷 D-25：统计与列表不联动） */
    async logStats(server, query = {}) {
      let result
      try {
        result = await ctx.tshock.fetchFor(server, `${SERVER_HALF_PREFIX}/logs/stats`, {
          category: query.category,
          method: query.method,
          player: query.player,
          q: query.q,
          timeFrom: query.timeFrom,
          timeTo: query.timeTo,
        })
      } catch (err) {
        throw httpError(err.status || (err.type === 'timeout' ? 504 : 502), `读取日志统计失败：${err.message}`, {
          serverId: server.id,
        })
      }
      const data = unwrap(result, server, '读取日志统计')
      const stats = toStats(data)
      return { ...stats, filtered: data.filtered === true, scope: String(data.scope || '') }
    },

    /** 手动扫描全部在线玩家（`GET {prefix}/scan`）——会**真的执行处置**（与旧版 scanall 一致） */
    async scanAll(server) {
      let result
      try {
        result = await ctx.tshock.fetchFor(server, `${SERVER_HALF_PREFIX}/scan`, {})
      } catch (err) {
        throw httpError(err.status || (err.type === 'timeout' ? 504 : 502), `扫描失败：${err.message}`, {
          serverId: server.id,
        })
      }
      const data = unwrap(result, server, '扫描在线玩家')
      return {
        players: Array.isArray(data.players) ? data.players : [],
        count: Number(data.count) || 0,
        scannedPlayers: Number(data.scannedPlayers) || 0,
        violationCount: Number(data.violationCount) || 0,
        durationMs: Number(data.durationMs) || 0,
      }
    },

    /** 按物品 ID 查持有者（`GET {prefix}/scan-by-id`）——**纯查询**，不判定不处置 */
    async scanById(server, itemId) {
      let result
      try {
        result = await ctx.tshock.fetchFor(server, `${SERVER_HALF_PREFIX}/scan-by-id`, { itemId: String(itemId) })
      } catch (err) {
        throw httpError(err.status || (err.type === 'timeout' ? 504 : 502), `按物品查询失败：${err.message}`, {
          serverId: server.id,
        })
      }
      const data = unwrap(result, server, '按物品 ID 查询持有者')
      return {
        players: Array.isArray(data.players) ? data.players : [],
        count: Number(data.count) || 0,
        scannedPlayers: Number(data.scannedPlayers) || 0,
        durationMs: Number(data.durationMs) || 0,
      }
    },

    /**
     * 异常物品判定（`GET {prefix}/check-anomaly`）——**真正的实现**。
     *
     * 旧版这个端点在前后端都有引用，但 C# **从未注册**（规格 A §6.0 / 规格 B §3.5 双向核对），
     * 于是恒 200 且恒 false；旧前端又自己用错字段名重算了一遍（读 `config.items`），
     * 结果"异常物品检测"在后端和前端两条路上同时失效。
     *
     * 之所以必须问服端而不是宿主自己算：判定要过滤"当前世界进度下仍生效的档位"
     * （旧 GetWorldInfo.cs:273-303 的 BossProgress.GetWorldStatus 要读 NPC.downed* 与击杀计数），
     * 那是**游戏服进程内**的状态，宿主不可能知道。
     */
    async checkAnomaly(server, { id, stack }) {
      let result
      try {
        result = await ctx.tshock.fetchFor(server, `${SERVER_HALF_PREFIX}/check-anomaly`, {
          id: String(id),
          stack: String(stack),
        })
      } catch (err) {
        throw httpError(err.status || (err.type === 'timeout' ? 504 : 502), `异常物品判定失败：${err.message}`, {
          serverId: server.id,
        })
      }
      const data = unwrap(result, server, '异常物品判定')
      const matched = Array.isArray(data.matched) ? data.matched : []
      return {
        id: Number(data.id) || Number(id),
        stack: Number(data.stack) || Number(stack),
        anomaly: data.anomaly === true,
        inConfig: data.inConfig === true,
        // allowedStack / method 为 null 表示"该物品不在清单里"（不是 0，0 会被误读成"限制 0 个"）
        allowedStack: Number.isFinite(Number(data.allowedStack)) && data.allowedStack !== null ? Number(data.allowedStack) : null,
        method: data.method == null ? null : String(data.method),
        command: String(data.command || ''),
        itemName: data.itemName == null ? null : String(data.itemName),
        progress: toStrList(data.progress),
        matched: matched.map((m) => ({
          进度: String(m.progress ?? m.进度 ?? ''),
          id: Number(m.id) || 0,
          stack: Number(m.stack) || 0,
          method: String(m.method ?? ''),
          command: String(m.command ?? ''),
        })),
        effectiveEntries: Number(data.effectiveEntries) || 0,
      }
    },

    /**
     * 往服端的检测日志通道写一条记录（`POST {prefix}/log`）。
     *
     * 这是"日志不私有化"的对外通道：未来的粒子防线插件（归「漏洞修复」，是**另一个插件**）
     * 走这个 HTTP 端点就能写进同一张 `CheatLog` 表、同一个 `category='particle'` 分类，
     * **不需要编译期引用 AntiCheat.dll**。宿主侧对应 `ctx.anticheatLog.record(...)`。
     */
    async recordLog(server, entry = {}) {
      const params = {
        playerName: entry.playerName == null ? '' : String(entry.playerName),
        playerId: entry.playerId == null ? '0' : String(entry.playerId),
        category: entry.category == null ? '' : String(entry.category),
        method: entry.method == null ? '' : String(entry.method),
        detail: entry.detail == null ? '' : String(entry.detail),
        itemId: entry.itemId == null ? '0' : String(entry.itemId),
        itemName: entry.itemName == null ? '' : String(entry.itemName),
        projId: entry.projId == null ? '0' : String(entry.projId),
      }
      const what = '写入检测日志'
      let result
      try {
        // 用 POST + form body（同 pushConfig 的理由：detail 可能很长，不该进 URL）
        result = typeof ctx.tshock.postFor === 'function'
          ? await ctx.tshock.postFor(server, `${SERVER_HALF_PREFIX}/log`, params)
          : await ctx.tshock.fetchFor(server, `${SERVER_HALF_PREFIX}/log`, params)
      } catch (err) {
        throw httpError(err.status || (err.type === 'timeout' ? 504 : 502), `${what}失败：${err.message}`, {
          serverId: server.id,
        })
      }
      const data = unwrap(result, server, what)
      return { recorded: data.recorded !== false, id: Number(data.id) || 0 }
    },
  }
}
