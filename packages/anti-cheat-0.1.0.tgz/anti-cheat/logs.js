/**
 * 检测日志：跨服聚合查询 + 统计 + ID→名称兜底
 *
 * ══════════ 为什么需要这一层（新架构的必然结果）══════════
 * 旧版是**单机单库**：`<TShock.SavePath>/AntiCheatLog.sqlite` 一张表，前端一页直接查它。
 * 新宿主是**多服**架构：每台游戏服各有自己的 `<SavePath>/AntiCheatLog.sqlite`，
 * 所以「反作弊日志」这一页天然要在宿主侧把多台服的查询结果聚合起来。
 * 「日志服务必须预留」的约束也落在这里：`particle` 分类与统计卡照旧版存在
 * （旧 AntiCheatLog.cs:15 自述含「粒子恶意 / 粒子超频丢弃」，将来的粒子插件写同一个通道），
 * 本模块**不按 category 白名单过滤**，任何分类都会原样透出。
 *
 * ══════════ 精确与近似（必须如实标注，不许含糊）══════════
 *   - **指定单台服务器**：完全精确。分页/排序/总数都由该服自己的 SQL 给出
 *     （`ORDER BY Id DESC`，旧 AntiCheatLog.cs:228），本层不重排。
 *     `orderBasis='Id'` 如实说明"最新在前是按主键而不是按时间列"（旧版注释写的是 Time DESC，
 *     与 SQL 不符，见规格 A §7 #13；本件照旧版 SQL 行为并如实标注）。
 *   - **全部服务器（聚合）**：scatter-gather 分页，**是近似的**。
 *     做法：向每台服请求同一页（相同的 offset），把各服结果按 `time` 归并排序后取前 pageSize 条。
 *     局限：全局第 N 页不等于"把各服全部日志合起来排序后的第 N 页"，跨服边界处可能漏条/重条。
 *     因此响应里固定带 `approximate: true` 与**逐服明细**（每台服自己的 rows/total/error），
 *     前端必须把这一点显示出来 —— 静默给一个"看起来完整"的列表比少显示几条更糟。
 *   - **统计**：聚合模式下 `total`/`today`/`byCategory`/`byMethod` 是**逐服求和，精确**（各服各自 GROUP BY）。
 *     但 `recent` 仍是近似（同样只取各服最近 10 条后归并）。
 *
 * ══════════ ID→名称（宿主侧职责）══════════
 * 服端落库时已经带上了名称（`ItemName` 列，旧 AntiCheatLog.cs:130）。但：
 *   - 历史库里可能是空的（旧版有些调用点不传 itemName）；
 *   - 弹幕只有 `ProjId` 没有名称列；
 * 所以宿主侧用 `ctx.itemData` / `ctx.projectileData`（plugins/data-items、plugins/data-projectiles
 * 提供的服务，见其 index.js:55 与 :55）做**兜底解析**。
 * ★ 必须经 ctx 服务取，**不得** import 对方模块或自己读 JSON：
 *   loader 给 import 加 `?tsweb-load=`（src/loader.js:181），同一文件可能被加载成不同实例，
 *   模块级缓存会不一致（docs/插件开发约定.md:185-189）。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */

/** 内存里的兜底解析只用于"库里没有名称"的行；这一层缓存避免逐行 await 打爆字典查询 */
function makeNameResolver({ itemData, projectileData }) {
  const itemCache = new Map()
  const projCache = new Map()

  async function itemName(id) {
    const key = Number(id) || 0
    if (key <= 0) return null
    if (itemCache.has(key)) return itemCache.get(key)
    let name = null
    try {
      name = itemData ? await itemData.nameOf(key) : null
    } catch {
      name = null // 字典缺失不该让日志页整体失败
    }
    itemCache.set(key, name)
    return name
  }

  async function projName(id) {
    const key = Number(id) || 0
    if (key <= 0) return null
    if (projCache.has(key)) return projCache.get(key)
    let name = null
    try {
      name = projectileData ? await projectileData.nameOf(key) : null
    } catch {
      name = null
    }
    projCache.set(key, name)
    return name
  }

  return { itemName, projName }
}

/** 把一行服端记录归一 + 补名称（服端字段名逐字见旧 AntiCheatLog.cs:238-251） */
async function normalizeRow(row, server, resolver) {
  const r = row && typeof row === 'object' ? row : {}
  const category = String(r.category ?? '')
  const itemId = Number(r.itemId) || 0
  const projId = Number(r.projId) || 0
  const storedItemName = String(r.itemName ?? '')

  // 名称优先级：服端落库的名称 → 宿主字典兜底 → 空（前端显示 "ID: n"）
  let itemName = storedItemName
  let itemNameSource = storedItemName !== '' ? 'log' : ''
  if (itemName === '' && itemId > 0) {
    const resolved = await resolver.itemName(itemId)
    if (resolved) {
      itemName = resolved
      itemNameSource = 'dictionary'
    }
  }
  let projName = ''
  let projNameSource = ''
  if (projId > 0) {
    const resolved = await resolver.projName(projId)
    if (resolved) {
      projName = resolved
      projNameSource = 'dictionary'
    }
  }

  return {
    id: Number(r.id) || 0,
    // Time 是**游戏服本地时间**的 "yyyy-MM-dd HH:mm:ss" 文本（旧 AntiCheatLog.cs:21、:125 的 DateTime.Now）。
    // 本件不臆造时区转换（宿主机与游戏服可能不在同一时区），只在响应里标明 timeBasis 让界面标注。
    time: String(r.time ?? ''),
    playerName: String(r.playerName ?? ''),
    playerId: Number(r.playerId) || 0,
    category,
    itemId,
    itemName,
    itemNameSource,
    projId,
    projName,
    projNameSource,
    method: String(r.method ?? ''),
    detail: String(r.detail ?? ''),
    worldId: String(r.worldId ?? ''),
    serverId: String(server.id),
    serverName: String(server.name || server.id),
  }
}

/** 按 time 归并排序（相同则按 id 降序，保证稳定可预期的顺序） */
function sortRows(rows) {
  return rows.slice().sort((a, b) => {
    if (a.time !== b.time) return a.time < b.time ? 1 : -1
    return Number(b.id) - Number(a.id)
  })
}

/** 时间区间参数归一：只给日期（YYYY-MM-DD）时补足时分秒，否则字符串比较会漏掉当天 */
export function normalizeTimeRange({ timeFrom, timeTo }) {
  const dateOnly = /^\d{4}-\d{2}-\d{2}$/
  const from = String(timeFrom ?? '').trim()
  const to = String(timeTo ?? '').trim()
  return {
    // 旧版是直接 `Time >= @tf` 字符串比较（旧 AntiCheatLog.cs:193-204）。
    // 前端传 "2026-01-01" 时，`"2026-01-01 09:00:00" >= "2026-01-01"` 恰好成立（前缀比较），
    // 但 `<= "2026-01-01"` 会让**当天所有记录都被排除**（因为 "2026-01-01 09:00" > "2026-01-01"）。
    // 这是一个真实的边界缺陷，故这里把"只给日期"的 timeTo 补成当天 23:59:59、timeFrom 补成 00:00:00。
    timeFrom: from === '' ? '' : dateOnly.test(from) ? `${from} 00:00:00` : from,
    timeTo: to === '' ? '' : dateOnly.test(to) ? `${to} 23:59:59` : to,
    // 让界面知道我们改写过区间（不许静默改语义）
    expanded: (from !== '' && dateOnly.test(from)) || (to !== '' && dateOnly.test(to)),
  }
}

/**
 * 查询检测日志。
 *
 * @param {object} p
 * @param {Array} p.servers           要查的服务器（raw 记录）
 * @param {object} p.gameOps          createGameOps 的返回值
 * @param {object} p.query            { page, pageSize, category, method, player, q, timeFrom, timeTo }
 * @param {object} p.itemData         ctx.itemData（可空）
 * @param {object} p.projectileData   ctx.projectileData（可空）
 * @param {boolean} [p.aggregate]     true=全部服务器聚合模式（近似）；false=指定单台（精确）
 */
export async function queryLogs({ servers, gameOps, query = {}, itemData, projectileData, aggregate = false }) {
  const resolver = makeNameResolver({ itemData, projectileData })
  const range = normalizeTimeRange(query)
  const page = Math.max(1, Number(query.page) || 1)
  const pageSize = Math.min(Math.max(1, Number(query.pageSize) || 50), 200)
  const effective = { ...query, page, pageSize, timeFrom: range.timeFrom, timeTo: range.timeTo }

  const perServer = []
  const merged = []
  let totalAll = 0

  for (const server of servers) {
    try {
      const r = await gameOps.logs(server, effective)
      const rows = []
      for (const row of r.rows) rows.push(await normalizeRow(row, server, resolver))
      perServer.push({
        id: String(server.id),
        name: String(server.name || server.id),
        ok: true,
        rows: rows.length,
        total: r.total,
        totalPages: r.totalPages,
        error: '',
      })
      totalAll += r.total
      for (const row of rows) merged.push(row)
    } catch (err) {
      // **失败逐服可见**：某台服查不到必须让管理员看到是哪台、为什么，绝不当作"没有日志"
      perServer.push({
        id: String(server.id),
        name: String(server.name || server.id),
        ok: false,
        rows: 0,
        total: 0,
        totalPages: 0,
        error: err.message,
        serverHalfMissing: err.serverHalfMissing === true,
      })
    }
  }

  const sorted = sortRows(merged)
  const okServers = perServer.filter((s) => s.ok).length
  const failed = perServer.filter((s) => !s.ok)

  // 单台服：直接用它自己的分页结果（精确，不重排、不截断）
  if (!aggregate && servers.length === 1) {
    const only = perServer[0]
    const totalPages = only.ok ? only.totalPages : 0
    return {
      // ★ 必须是 merged（= 该服按 ORDER BY Id DESC 自己分好页的那一页，见 :186 的 push 顺序），
      //   不能是 sorted：sortRows 是按时间重排，会把服端已经算好的第 N 页在页内重排出另一个顺序，
      //   于是 orderBasis 标着 'Id'、分页却按时间跳（同一条日志在某页出现/消失），与"精确、不重排"的声明矛盾。
      rows: merged,
      total: totalAll,
      page,
      pageSize,
      totalPages,
      approximate: false,
      orderBasis: 'Id',
      timeBasis: 'server-local',
      range,
      servers: perServer,
      error: only.ok ? '' : only.error,
    }
  }

  // 聚合：scatter-gather（近似），固定标注
  const rows = sorted.slice(0, pageSize)
  return {
    rows,
    total: totalAll,
    page,
    pageSize,
    // 聚合模式下 totalPages 按"求和总数"估算，仅用于给出翻页上限的感觉；前端必须配合 approximate 文案
    totalPages: pageSize > 0 ? Math.ceil(totalAll / pageSize) : 0,
    approximate: true,
    orderBasis: 'time-merge',
    timeBasis: 'server-local',
    range,
    servers: perServer,
    error: '',
    // 有服失败时，总数字必然偏小：把事实明确说出来
    note: failed.length > 0
      ? `有 ${failed.length} 台服务器查询失败（${failed.map((s) => s.name).join('、')}），下面的总数与统计都不含它们`
      : (okServers > 1 ? `已合并 ${okServers} 台服务器的结果（各服取同一页后按时间归并，属近似分页）` : ''),
  }
}

/**
 * 统计（总量 / 今日 / 按分类 / 按处理方式 / 最近命中）。
 *
 * 与旧版的关键差异（必改缺陷 D-25）：旧 GetStatsApi **完全不接受筛选参数**
 * （旧 AntiCheatLog.cs:273 无参），所以管理员筛了某个玩家之后，统计卡仍是全服数字，
 * 极易被误读为"该玩家的统计"。本件把同一套筛选参数透传给每台服，逐服求和，
 * 并在响应里带 `filtered` 与 `scope` 让界面能如实标注。
 */
export async function queryLogStats({ servers, gameOps, query = {}, itemData, projectileData }) {
  const resolver = makeNameResolver({ itemData, projectileData })
  const range = normalizeTimeRange(query)
  const effective = { ...query, timeFrom: range.timeFrom, timeTo: range.timeTo }

  const byCategory = {}
  const byMethod = {}
  const recent = []
  const perServer = []
  let total = 0
  let today = 0

  for (const server of servers) {
    try {
      const s = await gameOps.logStats(server, effective)
      total += s.total
      today += s.today
      for (const [k, v] of Object.entries(s.byCategory || {})) {
        byCategory[k] = (byCategory[k] || 0) + (Number(v) || 0)
      }
      for (const [k, v] of Object.entries(s.byMethod || {})) {
        byMethod[k] = (byMethod[k] || 0) + (Number(v) || 0)
      }
      const rows = []
      for (const row of s.recent) rows.push(await normalizeRow(row, server, resolver))
      for (const row of rows) recent.push(row)
      perServer.push({ id: String(server.id), name: String(server.name || server.id), ok: true, total: s.total, today: s.today, error: '' })
    } catch (err) {
      perServer.push({
        id: String(server.id),
        name: String(server.name || server.id),
        ok: false,
        total: 0,
        today: 0,
        error: err.message,
        serverHalfMissing: err.serverHalfMissing === true,
      })
    }
  }

  const failed = perServer.filter((s) => !s.ok)
  const filtered = Boolean(effective.category || effective.method || effective.player || effective.q || effective.timeFrom || effective.timeTo)
  return {
    total,
    today,
    byCategory,
    byMethod,
    // recent 在聚合模式下是"各服最近 10 条归并后取前 10 条"，与旧版单库语义一致（同样是 LIMIT 10）
    recent: sortRows(recent).slice(0, 10),
    perServer,
    filtered,
    scope: servers.length > 1 ? 'all-servers' : 'single-server',
    approximateRecent: servers.length > 1,
    timeBasis: 'server-local',
    range,
    error: '',
    note: failed.length > 0
      ? `有 ${failed.length} 台服务器统计失败（${failed.map((s) => s.name).join('、')}），下列数字不含它们`
      : '',
  }
}
