/**
 * anti-cheat 前端半 —— 静态契约 + 真实挂载行为测试
 *
 * 覆盖矩阵（对应交付要求第 6、7 类，外加把一次性脚本 tmp/ac-verify.mjs 的检查提升为交付物）：
 *   A. 注册面与真实渲染 —— 三个视图 + 一个玩家详情区块真的能挂载、真的能渲染；
 *      **未定义标识符**（渲染路径上才会炸的 undefined 引用）在真跑时抛错即失败。
 *   B. api 调用形状 —— 宿主 api() 只认 `json`/`method`/`headers`（plugins/web/public/app.js:222-244），
 *      所以客户端**绝不能**传 `body`；每次请求都要有 method，POST 必带 json 对象，
 *      路径必须命中宿主真实注册的路由白名单。
 *   C. 两条回归（历史上真的发生过的两个前端缺陷，见下）
 *   D. 破坏性动作的确认守卫（放弃修改 / 重新载入 / 删除条目 / 应用默认清单）
 *   E. 局部重绘（[data-ac-pushpanel] / [data-ac-savebar]）与选择器对话框的挂载/清理
 *   F. 从 tmp/ac-verify.mjs 提升上来的纯函数与文案核对
 *
 * 历史缺陷（本文件必须长期守住，不许再退化）：
 *   1. `log.js` 曾把 `./shared/api.js` 写成 `./api.js`（相对路径少一层 → 运行时整页加载失败）。
 *      → 见「回归：相对 import 全部解析得到」与「回归：log.js 的 style 导入」。
 *   2. `tier-editor.js` 曾读 `tier[entryKey]`，而 `shared/progress.js:137-178` 的 `buildTierList()`
 *      回的是 `{进度, entries, known, inConfig}`（中性字段 `entries`）→ **保存时把所有档位写空**，
 *      而且是 200 成功 + 界面显示成功的最坏一类静默丢数据。
 *      → 见「回归：真实 buildTierList 结构喂进保存路径」与「回归：buildTierPayload 只经 tierEntries」。
 *
 * 为什么必须"真挂载"：本机没有浏览器，但 `typeof window !== 'undefined'` 这类模块级判断
 * 让前端半在 Node 里也能跑；不真跑就只能靠读代码，而上面第 1 个缺陷恰恰是读代码容易漏、
 * 必须靠 import 解析 + 渲染才暴露的那一类。
 *
 * 约定：禁止 emoji（本文件里的排版符号一律用码点表达，避免自己踩自己的 emoji 检查）；
 *       中文注释；引用位置写 `文件:行号`。
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs'
import { join, dirname, resolve, relative } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { makeDom, makeEl, sleep } from './support/dom.mjs'

const HERE = dirname(fileURLToPath(import.meta.url))
const PLUGIN = resolve(HERE, '..')
const CLIENT = join(PLUGIN, 'client')
const REPO = resolve(PLUGIN, '..', '..')
const HOST_APP_JS = join(REPO, 'plugins', 'web', 'public', 'app.js')
const INDEX_JS = join(PLUGIN, 'index.js')
const fileUrl = (p) => pathToFileURL(p).href

// ═════════════════════════ 极简 DOM + 假宿主（support/dom.mjs）═════════════════════════
//
// 必须在 import 前端半之前 install：item.js:65、proj.js:57、log.js:632、player-section.js:346
// 都是**模块级**读 `window.tsweb`（用来自注册视图），模块只加载一次，装晚了就自注册不上。

/** 宿主 `GET /api/anticheat/config` 的形状（plugins/anti-cheat/index.js:693 的返回体） */
const HOST_CONFIG = {
  item: {
    启用: true,
    自动扫描: true,
    扫描间隔: 10,
    没收违禁物品: false,
    限制列表: [
      { 进度: '困难模式', 限制物品: [{ id: 2676, stack: 99, method: 'ban', command: '' }] },
      // 不在宿主进度表里的档位名：旧版保存会静默删掉它（本文件的「未知档位」用例就是守这个）
      { 进度: '自定义档位X', 限制物品: [{ id: 4000, stack: 5, method: 'command', command: '/say hi' }] },
    ],
  },
  proj: {
    启用: false,
    伤害上限: 20000,
    限制列表: [{ 进度: '始终生效', 限制弹幕: [{ id: 100, method: 'drop', command: '' }] }],
  },
}

/** 与 index.js:693-739 的响应逐字段同形；文案取 config.js 的权威表 */
const CONFIG_META = {
  config: HOST_CONFIG,
  configFile: '/tmp/anticheat.json',
  configError: '',
  defaultsError: '',
  warnings: ['示例警告：档位「自定义档位X」不在权威进度表里'],
  stats: { itemTiers: 2, itemEntries: 2, projTiers: 1, projEntries: 1 },
  progressOrder: ['始终生效', '困难模式'],
  knownProgress: ['始终生效', '困难模式'],
  dependencies: { itemData: true, projectileData: true },
  methodValues: ['log', 'kick', 'ban', 'drop', 'command'],
  methodLabels: {
    log: '仅记录日志', kick: '踢出玩家', ban: '封禁玩家', drop: '仅阻断（不踢不封）', command: '执行自定义命令',
  },
  // 与宿主 config.js 的 QUICK_COMMANDS 逐字一致（物品侧 4 条；弹幕侧由 shared/method.js:109 派生 3 条）
  quickCommands: [
    { method: 'ban', label: '封禁玩家', template: '/banp "{playername}" "违规使用{itemname}"' },
    { method: 'kick', label: '踢出玩家', template: '/kick "{playername}" "违规使用{itemname}"' },
    { method: 'log', label: '广播公告', template: '/bc "{playername}违规使用{itemname}"' },
    { method: 'command', label: '清除物品', template: '/remove {playername} {itemid}' },
  ],
  commandPlaceholders: ['{playername}', '{itemname}', '{itemid}', '{projid}'],
}

/** 让前端半在各个接口上都能拿到"像真的"的响应；未知路径给空对象（前端半必须容错） */
function fullApi(path, opts) {
  if (path === '/api/anticheat/config' && opts && opts.method === 'POST') {
    // 宿主同请求内落盘 + 下发，并把归一后的配置回给前端（store.js:289-295 读 d.config）
    return {
      ok: true, status: 200,
      data: {
        config: opts.json, warnings: [],
        push: { ok: true, total: 1, okCount: 1, pendingCount: 0, reason: '', results: [] },
      },
    }
  }
  if (path.startsWith('/api/anticheat/config')) return { ok: true, status: 200, data: CONFIG_META }
  if (path.startsWith('/api/anticheat/logs/stats')) {
    return { ok: true, status: 200, data: { total: 1, today: 1, byCategory: { item: 1 }, byMethod: { ban: 1 }, filtered: false } }
  }
  if (path.startsWith('/api/anticheat/logs')) {
    return {
      ok: true, status: 200,
      data: {
        rows: [{ id: 1, time: '2026-01-01 10:00:00', playerName: 'steve', category: 'item', itemId: 2676, itemName: '天顶剑', method: 'ban', detail: 'x'.repeat(80) }],
        total: 1, page: 1, pageSize: 50, totalPages: 1, approximate: false, timeBasis: 'server-local',
        servers: [{ id: 'srv-1', name: '主服', ok: true, rows: 1, total: 1 }],
      },
    }
  }
  if (path.startsWith('/api/servers')) return { ok: true, status: 200, data: { servers: [{ id: 'srv-1', name: '主服', enabled: true }] } }
  if (path.startsWith('/api/anticheat/status')) {
    return {
      ok: true, status: 200,
      data: {
        desiredVersion: 3, pendingCount: 0, pendingServerIds: [], retryScheduled: false, servers: [],
        probe: { servers: [{ id: 'srv-1', name: '主服', ok: true, match: true, diff: [] }] },
      },
    }
  }
  if (path.startsWith('/api/anticheat/defaults')) {
    return {
      ok: true, status: 200,
      data: {
        source: 'resources/默认清单',
        preview: {
          kinds: {
            item: { 条数_现在: 2, 条数_应用后: 120, 消失档位: [] },
            proj: { 条数_现在: 1, 条数_应用后: 61, 消失档位: [] },
          },
        },
      },
    }
  }
  if (path.startsWith('/api/anticheat/apply-defaults')) {
    return {
      ok: true, status: 200,
      data: {
        changes: [{ kind: 'item', field: '限制列表' }],
        push: { ok: true, total: 1, okCount: 1, pendingCount: 0, reason: '', results: [] },
      },
    }
  }
  if (path.startsWith('/api/anticheat/audit')) return { ok: true, status: 200, data: { rows: [{ time: '2026-01-01 10:00:00', action: 'save', actor: 'admin' }], total: 1 } }
  if (path.startsWith('/api/anticheat/push')) {
    return { ok: true, status: 200, data: { ok: true, total: 1, okCount: 1, pendingCount: 0, reason: '', results: [] } }
  }
  if (path.startsWith('/api/anticheat/check-anomaly')) return { ok: true, status: 200, data: { anomaly: true, serverName: '主服' } }
  if (path.startsWith('/api/anticheat/scan-by-id')) return { ok: true, status: 200, data: { holders: [], total: 0 } }
  return { ok: true, status: 200, data: {} }
}

const dom = makeDom({ api: fullApi })
dom.install()

// 前端半入口（anti-cheat.js）会在加载时把三个视图与一个区块注册到 window.tsweb 上；
// 载入失败（例如相对 import 写错）会在这里直接抛错 —— 这正是回归 1 要守的东西。
const entryErr = []
try {
  await import(fileUrl(join(CLIENT, 'anti-cheat.js')))
} catch (err) {
  entryErr.push(err)
}

const store = await import(fileUrl(join(CLIENT, 'shared', 'store.js')))
const tier = await import(fileUrl(join(CLIENT, 'shared', 'tier-editor.js')))
const progress = await import(fileUrl(join(CLIENT, 'shared', 'progress.js')))
const apiMod = await import(fileUrl(join(CLIENT, 'shared', 'api.js')))
const methodMod = await import(fileUrl(join(CLIENT, 'shared', 'method.js')))
const searchMod = await import(fileUrl(join(CLIENT, 'shared', 'search.js')))
const logMod = await import(fileUrl(join(CLIENT, 'log.js')))
const psMod = await import(fileUrl(join(CLIENT, 'player-section.js')))
const panelMod = await import(fileUrl(join(CLIENT, 'shared', 'panel.js')))

// ═════════════════════════════ 工具 ═════════════════════════════

/** 递归收集某个目录下的文件（用于静态扫描） */
function walk(dir, filter) {
  const out = []
  for (const name of readdirSync(dir)) {
    const p = join(dir, name)
    const st = statSync(p)
    if (st.isDirectory()) out.push(...walk(p, filter))
    else if (!filter || filter(p)) out.push(p)
  }
  return out
}

function relFrom(base, p) {
  return relative(base, p).split('\\').join('/')
}

/** 取某个顶层函数的源码（从含 marker 的那一行起做大括号配平，避免把邻居函数算进来） */
function topLevelFunctionSource(src, marker) {
  const lines = src.split(/\r?\n/)
  const start = lines.findIndex((l) => l.includes(marker))
  assert.ok(start >= 0, '找不到函数：' + marker)
  let depth = 0
  let seen = false
  for (let i = start; i < lines.length; i++) {
    for (const ch of lines[i]) {
      if (ch === '{') { depth += 1; seen = true }
      else if (ch === '}') depth -= 1
    }
    if (seen && depth === 0) return lines.slice(start, i + 1).join('\n')
  }
  assert.fail('函数源码括号不配平：' + marker)
}

/** 渲染一次并记录抛错；三个页面 + 区块只挂载一次，后续用例复用（前端半里有单例状态） */
const M = { done: false, throws: [], item: null, proj: null, log: null, section: null, sectionCleanup: null }
async function ensureMounted() {
  if (M.done) return M
  M.done = true
  const byId = (id) => dom.registered.views.find((v) => v.id === id)
  for (const [key, id] of [['item', 'anticheat-item'], ['proj', 'anticheat-proj'], ['log', 'anticheat-log']]) {
    const v = byId(id)
    if (!v) { M.throws.push(new Error('未注册视图：' + id)); continue }
    const c = makeEl('div')
    try {
      await v.render(c)
    } catch (err) {
      M.throws.push(err)
    }
    await sleep(40)
    M[key] = c
  }
  const sec = dom.registered.sections[0]
  if (sec) {
    const c = makeEl('div')
    try {
      M.sectionCleanup = await sec.render(c, { username: 'steve' }, { account: { username: 'steve' }, inventory: [{ slot: 0, netID: 2676, stack: 500 }] })
    } catch (err) {
      M.throws.push(err)
    }
    await sleep(40)
    M.section = c
  }
  return M
}

/** 把配置恢复成 fixture 基线的样子（改动类用例互相隔离用） */
async function restore() {
  await store.loadConfig({ force: true })
  store.discard()
  await sleep(10)
}

/** 从渲染出来的 HTML 里取所有 ac- 前缀类名，以及 CSS 里定义过的类名 */
function classNameSet(html) {
  const out = new Set()
  const re = /class="([^"]*)"/g
  let m
  while ((m = re.exec(String(html))) !== null) {
    for (const c of m[1].split(/\s+/)) if (c) out.add(c)
  }
  return out
}

/** emoji 判据：按码点判定（不依赖字体/渲染），并给出仓内既有的排版符号白名单 */
const EMOJI_RANGES = [[0x1f000, 0x1faff], [0x2600, 0x27bf], [0x2b00, 0x2bff], [0xfe0f, 0xfe0f], [0x1f1e6, 0x1f1ff]]
// 仓内既有的几何/排版符号（style.js:14 明确"非 emoji，本仓既有文案字符"）：
// U+2715 U+FF0B U+2212 U+2014 U+283F U+25B6 U+2605 U+2192
const GEOMETRY_OK = new Set([0x2715, 0xff0b, 0x2212, 0x2014, 0x283f, 0x25b6, 0x2605, 0x2192])

function emojiHits(text) {
  const out = []
  for (const ch of String(text)) {
    const cp = ch.codePointAt(0)
    if (GEOMETRY_OK.has(cp)) continue
    if (EMOJI_RANGES.some(([a, b]) => cp >= a && cp <= b)) out.push(ch)
  }
  return out
}

// ═════════════════════════════ A. 注册面与真实渲染 ═════════════════════════════

test('注册面：三个视图 + 一个玩家详情区块都真的注册了，路径/分区/图标合法', () => {
  assert.deepEqual(entryErr.map((e) => (e && e.message) || String(e)), [], '前端半入口加载失败（相对 import 或顶层代码抛错）')
  assert.equal(dom.registered.views.length, 3, '应注册 3 个视图，实际 ' + dom.registered.views.length)
  assert.equal(dom.registered.sections.length, 1, '应注册 1 个玩家详情区块')
  const ids = dom.registered.views.map((v) => v.id).sort()
  assert.deepEqual(ids, ['anticheat-item', 'anticheat-log', 'anticheat-proj'])
  // 宿主只切两段扁路径，且侧边栏图标只能取宿主的图标表键（plugins/web/public/app.js:99-105）
  const ICONS = ['grid', 'terminal', 'box', 'layers', 'server', 'key']
  for (const v of dom.registered.views) {
    assert.ok(/^\/s\/[a-z-]+$/.test(v.path), '路径必须是两段扁平：' + v.path)
    assert.equal(v.section, '服务器设置', v.id + ' 的分区')
    assert.ok(ICONS.includes(v.icon), v.id + ' 的图标必须是宿主图标表的键：' + v.icon)
    assert.equal(typeof v.render, 'function', v.id + ' 必须有 render')
    assert.equal(typeof v.title, 'string')
  }
  const sec = dom.registered.sections[0]
  assert.equal(sec.id, 'anticheat-item-alert')
  assert.equal(sec.title, '违禁物品告警')
  assert.equal(typeof sec.order, 'number')
  assert.equal(typeof sec.render, 'function')
})

test('未定义标识符：三个页面与玩家区块都真的挂载渲染成功，渲染路径不抛错且结果非空', async () => {
  const m = await ensureMounted()
  assert.deepEqual(
    m.throws.map((e) => (e && e.message) || String(e)),
    [],
    '真实挂载/渲染时抛错（通常是未定义标识符或 DOM 用法不兼容）'
  )
  for (const k of ['item', 'proj', 'log', 'section']) {
    assert.ok(m[k], k + ' 没有渲染出容器（视图可能没挂载）')
    assert.ok(String(m[k].innerHTML).length > 50, k + ' 渲染结果过短，疑似渲染中断：' + String(m[k].innerHTML).slice(0, 120))
  }
})

test('物品页渲染：标题/副标题/开关/未知档位/保存栏文案都在', async () => {
  const m = await ensureMounted()
  const html = String(m.item.innerHTML)
  for (const s of ['物品限制配置', '配置不同游戏进度下的物品限制规则', '启用检测', '自动扫描', '没收违禁物品', '扫描间隔']) {
    assert.ok(html.includes(s), '物品页缺少文案：' + s)
  }
  assert.ok(html.includes('未知档位'), '未知档位应有可见标记')
  assert.ok(html.includes('自定义档位X'), '未知档位卡必须被渲染出来（旧版保存会静默删掉它）')
  assert.ok(html.includes('保存配置') && html.includes('放弃修改'), '保存栏应有保存/放弃按钮')
  assert.ok(html.includes('data-ac-savebar'), '保存栏必须带 data-ac-savebar（局部重绘的锚点）')
  assert.ok(html.includes('data-ac-pushpanel'), '下发面板必须带 data-ac-pushpanel（局部重绘的锚点）')
})

test('弹幕页渲染：标题/副标题/伤害上限，且不出现物品侧字段', async () => {
  const m = await ensureMounted()
  const html = String(m.proj.innerHTML)
  for (const s of ['弹幕限制配置', '配置不同游戏进度下的弹幕限制规则', '启用检测', '伤害上限']) {
    assert.ok(html.includes(s), '弹幕页缺少文案：' + s)
  }
  // 弹幕侧条目没有 stack 字段（config.js 的 ENTRY_KEY 差异），文案必须用「弹幕ID」
  assert.ok(html.includes('弹幕ID'), '弹幕页应显示「弹幕ID」')
})

test('日志页渲染：页面标题逐字，且真的去查了日志与统计', async () => {
  const m = await ensureMounted()
  const html = String(m.log.innerHTML)
  assert.ok(html.includes('反作弊日志'), '日志页标题应为「反作弊日志」（log.js:369）')
  const logCalls = dom.callsTo('/api/anticheat/logs').filter((r) => !r.path.includes('/logs/stats'))
  assert.ok(logCalls.length > 0, '日志页必须真的查询 /api/anticheat/logs')
  assert.ok(dom.callsTo('/api/anticheat/logs/stats').length > 0, '日志页必须真的查询 /api/anticheat/logs/stats')
  const q = new URLSearchParams(String(logCalls[0].path).split('?')[1] || '')
  assert.ok(q.get('page'), '日志查询必须带 page')
  assert.ok(q.get('pageSize'), '日志查询必须带 pageSize')
})

test('玩家详情区块渲染：违禁物品告警真的按服端判定结果渲染', async () => {
  const m = await ensureMounted()
  const html = String(m.section.innerHTML)
  assert.ok(html.length > 20, '区块渲染结果为空')
  const calls = dom.requests.filter((r) => r.path.includes('/api/anticheat/check-anomaly'))
  assert.ok(calls.length > 0, '背包里有清单命中的物品时必须调用 check-anomaly')
  const q = new URLSearchParams(String(calls[0].path).split('?')[1] || '')
  assert.equal(q.get('id'), '2676', 'check-anomaly 必须带命中的物品 id')
  assert.equal(q.get('stack'), '500', 'check-anomaly 必须带数量')
  assert.equal(q.get('serverId'), 'srv-1', 'check-anomaly 必须带当前服务器')
})

test('渲染结果里没有 emoji（按码点判定，仓内既有排版符号不算）', async () => {
  const m = await ensureMounted()
  // 自证判据有效：真 emoji 必须被抓到、既有排版符号必须不被误报
  assert.deepEqual(emojiHits(String.fromCodePoint(0x1f600)), [String.fromCodePoint(0x1f600)], 'emoji 判据自证失败')
  assert.deepEqual(emojiHits(String.fromCodePoint(0x2715, 0xff0b, 0x2212, 0x2014)), [], '既有排版符号被误报成 emoji')
  for (const k of ['item', 'proj', 'log', 'section']) {
    const hits = emojiHits(String(m[k].innerHTML))
    assert.deepEqual(hits, [], k + ' 渲染结果里有 emoji：' + hits.join(' '))
  }
})

test('样式：CSS 只注入一次，且渲染用到的 ac- 类名都在 CSS 里有定义', async () => {
  const m = await ensureMounted()
  const styles = dom.head.children.filter((el) => el.getAttribute && el.getAttribute('data-tsweb-plugin') === 'anti-cheat')
  assert.equal(styles.length, 1, '注入的 anti-cheat <style> 应恰好一份（多页共用），实际 ' + styles.length)
  const css = String(styles[0].textContent || '')
  assert.ok(css.includes('.ac-wrap'), 'CSS 内容为空或缺少骨架类')
  const defined = new Set()
  const re = /\.(ac-[a-zA-Z0-9_-]+)/g
  let mm
  while ((mm = re.exec(css)) !== null) defined.add(mm[1])
  assert.ok(defined.size > 10, 'CSS 里定义的 ac- 类太少，疑似 CSS 被截断：' + defined.size)
  const used = new Set()
  for (const k of ['item', 'proj', 'log', 'section']) {
    for (const c of classNameSet(String(m[k].innerHTML))) if (c.startsWith('ac-')) used.add(c)
  }
  const missing = [...used].filter((c) => !defined.has(c)).sort()
  assert.deepEqual(missing, [], '渲染用到了 CSS 里没定义的类（会掉样式）：' + missing.join(' '))
})

// ═════════════════════════════ B. api 调用形状 ═════════════════════════════

test('api 调用形状（静态）：宿主 api() 只认 json/method/headers，客户端从不传 body/signal', () => {
  // 宿主实现：plugins/web/public/app.js:222-244
  const appSrc = readFileSync(HOST_APP_JS, 'utf8')
  const appLines = appSrc.split(/\r?\n/)
  const seg = appLines.slice(221, 244).join('\n')
  assert.ok(seg.includes('options.json'), '宿主 api() 应当读 options.json（本用例的前提）')
  assert.ok(!/options\.body/.test(seg), '宿主 api() 不认 options.body —— 传了就是被静默丢弃')
  assert.ok(!/options\.signal/.test(seg), '宿主 api() 不透传 options.signal')
  assert.ok(/'POST' : 'GET'|"POST" : "GET"/.test(seg), '宿主按有没有 json 决定 GET/POST')

  // 客户端侧：不得出现 body: 键，也不得自己拼 fetch
  const files = walk(CLIENT, (p) => p.endsWith('.js'))
  assert.ok(files.length >= 10, '前端半文件数异常：' + files.length)
  const bad = []
  for (const f of files) {
    const src = readFileSync(f, 'utf8')
    const rel = relFrom(CLIENT, f)
    // 去掉注释再判断，避免"注释里提到 body"被误报
    const code = src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:])\/\/[^\n]*/g, '$1')
    if (/\bbody\s*:/.test(code)) bad.push(rel + ' 出现 body: 键')
    if (/\bwindow\.fetch\s*\(|\bfetch\s*\(\s*['"`]/.test(code)) bad.push(rel + ' 绕过宿主 api() 自己 fetch')
    if (/options\.signal|signal\s*:/.test(code)) bad.push(rel + ' 传了 signal（宿主不透传）')
  }
  assert.deepEqual(bad, [], 'api 调用形状违规：' + bad.join('；'))
})

test('api 调用形状（静态）：只有 shared/api.js 直接调 window.tsweb.api，其余一律走 req/get/post', () => {
  const offenders = []
  for (const f of walk(CLIENT, (p) => p.endsWith('.js'))) {
    const rel = relFrom(CLIENT, f)
    const src = readFileSync(f, 'utf8')
    if (/tsweb\.api\s*\(/.test(src) && rel !== 'shared/api.js') offenders.push(rel)
  }
  assert.deepEqual(offenders, [], '这些文件绕过 shared/api.js 直接调宿主 api()：' + offenders.join(' '))
  // 唯一出口本身只构造 method/json 两种调用（api.js:85-92）
  const src = readFileSync(join(CLIENT, 'shared', 'api.js'), 'utf8')
  assert.ok(/return req\(path, \{ method: 'GET' \}\)/.test(src), 'get() 必须只传 method')
  assert.ok(/return req\(path, \{ method: 'POST', json: json === undefined \? \{\} : json \}\)/.test(src), 'post() 必须传 method+json')
})

test('api 调用形状（运行时）：每次调用都带 method，POST 必带 json 对象，且没有未知键', async () => {
  const m = await ensureMounted()
  // 先制造一次 POST（下发按钮走 post()），保证下面的 POST 分支真的被覆盖到
  m.item.fireAct('click', 'push-now')
  await sleep(40)
  assert.ok(dom.requests.length >= 5, '没记录到请求，形状断言没有意义：' + dom.requests.length)
  const ALLOWED = ['method', 'json', 'headers']
  const problems = []
  let posts = 0
  for (const r of dom.requests) {
    const o = r.opts
    if (o === undefined || o === null) { problems.push(r.path + ' 没有传 options'); continue }
    const keys = Object.keys(o)
    const unknown = keys.filter((k) => !ALLOWED.includes(k))
    if (unknown.length) problems.push(r.path + ' 传了宿主不识别的键：' + unknown.join(','))
    const m = o.method
    if (m !== 'GET' && m !== 'POST') problems.push(r.path + ' 的 method 非法：' + String(m))
    if (m === 'POST') {
      posts += 1
      if (!Object.prototype.hasOwnProperty.call(o, 'json')) problems.push(r.path + ' 是 POST 但没有 json')
      else if (typeof o.json !== 'object' || o.json === null) problems.push(r.path + ' 的 json 不是对象')
    } else if (Object.prototype.hasOwnProperty.call(o, 'json')) {
      problems.push(r.path + ' 是 GET 却带了 json')
    }
  }
  assert.deepEqual(problems, [], 'api 调用形状违规：' + problems.join('；'))
  assert.ok(posts > 0, '没有观察到任何 POST，形状断言覆盖不全')
})

test('api 调用形状（运行时）：所有请求路径都命中宿主真实注册的路由白名单', async () => {
  await ensureMounted()
  // 白名单从 index.js 的路由注册语句里解析（不硬编码，避免路由改名后测试失效）
  const idx = readFileSync(INDEX_JS, 'utf8')
  const declared = new Set()
  const pairs = new Set()
  const re = /app\.(get|post)\(\s*'(\/api\/[^']+)'/g
  let mm
  while ((mm = re.exec(idx)) !== null) {
    declared.add(mm[2])
    pairs.add(mm[1].toUpperCase() + ' ' + mm[2])
  }
  // 12 条注册 = 11 条唯一路径（/api/anticheat/config 同时有 GET 与 POST）
  assert.equal(pairs.size, 12, '宿主应注册 12 条 /api/anticheat 路由（method+path），实际 ' + pairs.size)
  assert.equal(declared.size, 11, '宿主 /api/anticheat 唯一路径应为 11 条，实际 ' + declared.size)
  assert.ok(pairs.has('GET /api/anticheat/config') && pairs.has('POST /api/anticheat/config'), 'config 必须同时有 GET 与 POST')
  // /api/servers 来自 servers 插件（api.js:231 的注释指明了出处）
  declared.add('/api/servers')

  const missingApi = Object.values(apiMod.API).filter((p) => !declared.has(p))
  assert.deepEqual(missingApi, [], '这些 API 常量在宿主里不存在：' + missingApi.join(' '))

  const offenders = []
  for (const r of dom.requests) {
    const p = String(r.path).split('?')[0]
    if (!declared.has(p)) offenders.push(r.path)
  }
  assert.deepEqual([...new Set(offenders)], [], '前端半调用了宿主不存在的路由（会 404）：' + offenders.join(' '))
})

test('api 调用形状（运行时）：保存提交的是整份配置，且未知档位不会被静默删除', async () => {
  const m = await ensureMounted()
  await restore()
  dom.requests.length = 0
  assert.ok(m.item.fireAct('click', 'save') > 0, '保存按钮应有委托监听器')
  await sleep(60)
  const posts = dom.callsTo('/api/anticheat/config').filter((r) => r.opts && r.opts.method === 'POST')
  assert.equal(posts.length, 1, '应恰好发出一次保存请求，实际 ' + posts.length)
  const body = posts[0].opts.json
  assert.deepEqual(Object.keys(body).sort(), ['item', 'proj'], '保存必须整份提交 item+proj（漏一侧宿主会清空它）')
  assert.ok(Array.isArray(body.item['限制列表']) && Array.isArray(body.proj['限制列表']))
  const names = body.item['限制列表'].map((t) => String(t.进度))
  assert.ok(names.includes('自定义档位X'), '未知档位不得被静默删除（旧版核心缺陷）：' + JSON.stringify(names))
  const unknown = body.item['限制列表'].find((t) => String(t.进度) === '自定义档位X')
  assert.equal(unknown['限制物品'].length, 1, '未知档位的条目也必须保留')
  const known = body.item['限制列表'].find((t) => String(t.进度) === '困难模式')
  assert.ok(known && known['限制物品'].length === 1, '已知档位的条目不得被写空')
})

// ═════════════════════════════ C. 两条回归 ═════════════════════════════

test('回归：client 下每一条相对 import/动态 import 都解析得到真实文件', () => {
  const files = walk(CLIENT, (p) => p.endsWith('.js'))
  const RES = [
    /\bfrom\s*['"](\.[^'"]+)['"]/g,
    /\bimport\s*\(\s*['"](\.[^'"]+)['"]/g,
    /\bimport\s+['"](\.[^'"]+)['"]/g,
  ]
  const missing = []
  let total = 0
  for (const f of files) {
    const src = readFileSync(f, 'utf8')
    const dir = dirname(f)
    for (const re of RES) {
      re.lastIndex = 0
      let mm
      while ((mm = re.exec(src)) !== null) {
        total += 1
        const spec = mm[1]
        const target = resolve(dir, spec)
        if (!existsSync(target) || !statSync(target).isFile()) {
          missing.push(relFrom(CLIENT, f) + ' -> ' + spec)
        }
      }
    }
  }
  assert.ok(total >= 20, '解析到的相对 import 太少，疑似扫描逻辑失效：' + total)
  assert.deepEqual(missing, [], '相对 import 指向了不存在的文件（运行时整页加载失败）：' + missing.join('；'))
})

test('回归：log.js 的样式导入指向 shared/style.js（历史上曾写成 ./api.js）', () => {
  const src = readFileSync(join(CLIENT, 'log.js'), 'utf8')
  assert.ok(
    /import\s*\{[^}]*injectStyle[^}]*shellHtml[^}]*\}\s*from\s*'\.\/shared\/style\.js'/.test(src.replace(/\r?\n/g, ' ')),
    'log.js 必须从 ./shared/style.js 取 injectStyle 与 shellHtml'
  )
  assert.ok(!/from\s*'\.\/api\.js'/.test(src), 'log.js 不得再出现 ./api.js（少一层的错误相对路径）')
  assert.ok(!/from\s*'\.\/tier-editor\.js'/.test(src), 'log.js 不得出现 ./tier-editor.js（少一层的错误相对路径）')
  assert.ok(/from\s*'\.\/shared\/api\.js'/.test(src), 'log.js 应经 ./shared/api.js 发请求')
})

test('回归：真实 buildTierList 结构喂进保存路径后，档位不会被写空', async () => {
  await ensureMounted()
  await restore()
  // buildTierList 回的是中性字段视图：{进度, entries, known, inConfig}（progress.js:137-178）
  const view = progress.buildTierList(store.tiers('item'), store.getState().meta, '限制物品')
  assert.ok(view.length >= 3, '视图档位数应包含 2 个已知 + 1 个未知档位，实际 ' + view.length)
  for (const t of view) {
    assert.deepEqual(Object.keys(t).sort(), ['entries', 'inConfig', 'known', '进度'], '视图对象字段名变了：' + JSON.stringify(Object.keys(t)))
    assert.ok(Array.isArray(t.entries), '视图档位必须用 entries 承载条目')
    assert.equal(Object.prototype.hasOwnProperty.call(t, '限制物品'), false, '视图对象不应带配置形态的中文键')
  }
  // 把真实视图结构喂进保存路径用的构建器
  const payload = tier.buildTierPayload('item', view)
  const byName = new Map(payload.map((t) => [String(t.进度), t]))
  // 空档位在保存产物里被正常丢弃（宿主只关心有条目的档位），但**非空档位一条都不能少、一条都不能空**
  const nonEmpty = view.filter((t) => t.entries.length > 0)
  assert.ok(nonEmpty.length >= 1, 'fixture 里应当有非空档位，否则本用例空转')
  for (const t of nonEmpty) {
    const p = byName.get(String(t.进度))
    assert.ok(p, '保存产物丢失了非空档位：' + t.进度)
    assert.equal(
      p['限制物品'].length, t.entries.length,
      '档位「' + t.进度 + '」条目数被改动：视图 ' + t.entries.length + ' 条 -> 产物 ' + p['限制物品'].length + ' 条'
    )
    assert.ok(p['限制物品'].length > 0, '非空档位「' + t.进度 + '」在保存产物里被写空（历史缺陷的症状）')
  }
  for (const t of payload) {
    const src = view.find((v) => String(v.进度) === String(t.进度))
    if (src) assert.ok(t['限制物品'].length <= src.entries.length, '保存产物凭空多了条目：' + t.进度)
  }
  // 兼容配置形态（中文键）的输入也要能取到条目（tierEntries 的兜底分支）
  const cfgShape = [{ 进度: '始终生效', 限制物品: [{ id: 1, stack: 1, method: 'log', command: '' }] }]
  assert.equal(tier.buildTierPayload('item', cfgShape)[0]['限制物品'].length, 1)
})

test('回归：buildTierPayload 只经 tierEntries 取条目，不直接索引 tier[entryKey]', () => {
  const src = readFileSync(join(CLIENT, 'shared', 'tier-editor.js'), 'utf8')
  const body = topLevelFunctionSource(src, 'export function buildTierPayload')
  assert.ok(body.includes('tierEntries('), 'buildTierPayload 必须经 tierEntries 取条目（否则视图结构会被写空）')
  assert.ok(
    !/[A-Za-z_$][\w$]*\s*\[\s*entryKey\s*\]/.test(body),
    'buildTierPayload 里出现了对 tier[entryKey] 的直接索引 —— 这正是"保存时档位被写空"的原始缺陷写法'
  )
  const helper = topLevelFunctionSource(src, 'function tierEntries')
  assert.ok(/Array\.isArray\(tier\.entries\)/.test(helper), 'tierEntries 必须优先视图字段 entries')
  assert.ok(/\[\s*entryKey\s*\]/.test(helper), 'tierEntries 必须兼容配置形态的中文键')
  assert.ok(/return \[\]/.test(helper), 'tierEntries 必须对空值返回空数组（绝不 undefined）')
})

// ═════════════════════════════ D. 破坏性动作的确认守卫 ═════════════════════════════

test('守卫：放弃未保存修改必须先确认，取消确认时一个字节都不许改', async () => {
  const m = await ensureMounted()
  await restore()
  store.mutate((c) => { c.item['启用'] = !c.item['启用'] })
  assert.equal(store.getState().dirty, true, '前置：应当处于"有未保存修改"状态')
  const dirtyCfg = JSON.stringify(store.side('item'))

  dom.clearConfirms()
  dom.setConfirm(false)
  m.item.fireAct('click', 'discard')
  await sleep(20)
  assert.equal(dom.confirms.length, 1, '放弃修改必须先弹确认')
  assert.equal(store.getState().dirty, true, '取消确认后不得丢弃修改')
  assert.equal(JSON.stringify(store.side('item')), dirtyCfg, '取消确认后配置不得变化')

  dom.setConfirm(true)
  m.item.fireAct('click', 'discard')
  await sleep(20)
  assert.equal(store.getState().dirty, false, '确认后应真的回到基线')
  assert.equal(JSON.stringify(store.side('item')), JSON.stringify(HOST_CONFIG.item), '确认后配置应回到服务端基线')
  await restore()
})

test('守卫：重新载入（会用服务端配置覆盖本地修改）必须先确认', async () => {
  const m = await ensureMounted()
  await restore()
  store.mutate((c) => { c.item['扫描间隔'] = 33 })
  const before = dom.callsTo('/api/anticheat/config').length

  dom.clearConfirms()
  dom.setConfirm(false)
  m.item.fireAct('click', 'reload')
  await sleep(30)
  assert.equal(dom.confirms.length, 1, '重新载入必须先弹确认')
  assert.equal(dom.callsTo('/api/anticheat/config').length, before, '取消确认后不得重新拉取（否则本地修改白丢）')
  assert.equal(store.side('item')['扫描间隔'], 33, '取消确认后本地修改必须还在')

  dom.setConfirm(true)
  m.item.fireAct('click', 'reload')
  await sleep(40)
  assert.ok(dom.callsTo('/api/anticheat/config').length > before, '确认后应真的重新拉取')
  assert.equal(store.getState().dirty, false, '重新载入后脏标记应归零')
  assert.equal(store.side('item')['扫描间隔'], HOST_CONFIG.item['扫描间隔'], '重新载入后应回到服务端值')
  await restore()
})

test('守卫：删除一条违禁记录必须先确认', async () => {
  const m = await ensureMounted()
  await restore()
  const view = progress.buildTierList(store.tiers('item'), store.getState().meta, '限制物品')
  const tIdx = view.findIndex((t) => String(t.进度) === '困难模式')
  assert.ok(tIdx >= 0, 'fixture 里应有困难模式档位')
  assert.equal(view[tIdx].entries.length, 1, '前置：该档位应有 1 条')
  const attrs = { 'data-ac-tier': String(tIdx), 'data-ac-idx': '0' }

  dom.clearConfirms()
  dom.setConfirm(false)
  m.item.fireAct('click', 'entry-del', attrs)
  await sleep(20)
  assert.equal(dom.confirms.length, 1, '删除条目必须先弹确认')
  const after = progress.buildTierList(store.tiers('item'), store.getState().meta, '限制物品')
  assert.equal(after[tIdx].entries.length, 1, '取消确认后条目不得被删除')

  dom.setConfirm(true)
  m.item.fireAct('click', 'entry-del', attrs)
  await sleep(20)
  const final = progress.buildTierList(store.tiers('item'), store.getState().meta, '限制物品')
  assert.equal(final[tIdx].entries.length, 0, '确认后条目应被删除')
  await restore()
})

test('守卫：应用默认清单先预览后确认，取消确认时不得带 confirm:true 写入', async () => {
  const m = await ensureMounted()
  await restore()
  dom.requests.length = 0
  dom.clearConfirms()
  dom.setConfirm(false)
  m.item.fireAct('click', 'defaults-apply')
  await sleep(40)
  assert.equal(dom.confirms.length, 1, '应用默认清单必须先弹确认（会把整侧清单替换掉）')
  const blocked = dom.callsTo('/api/anticheat/apply-defaults')
  assert.equal(blocked.length, 1, '第一步只应有预览请求，实际 ' + blocked.length)
  assert.ok(!(blocked[0].opts.json && blocked[0].opts.json.confirm === true), '预览请求绝不能带 confirm:true（那会直接写入）')

  dom.setConfirm(true)
  dom.requests.length = 0
  m.item.fireAct('click', 'defaults-apply')
  await sleep(50)
  const calls = dom.callsTo('/api/anticheat/apply-defaults')
  assert.equal(calls.length, 2, '确认后应是"预览 + 写入"两次请求，实际 ' + calls.length)
  assert.ok(!(calls[0].opts.json && calls[0].opts.json.confirm === true), '第一次仍必须是预览（不带 confirm）')
  assert.equal(calls[1].opts.method, 'POST')
  assert.equal(calls[1].opts.json.confirm, true, '第二次才带 confirm:true（index.js:758-787 的契约）')
  assert.equal(calls[1].opts.json.scope, 'item')
  await restore()
})

test('单服动作：手动扫描走 POST /api/anticheat/scan 且带当前服务器 id', async () => {
  const m = await ensureMounted()
  await restore()
  dom.requests.length = 0
  m.item.fireAct('click', 'scan')
  await sleep(50)
  const calls = dom.callsTo('/api/anticheat/scan')
  assert.equal(calls.length, 1, '应恰好发起一次扫描请求，实际 ' + calls.length)
  assert.equal(calls[0].opts.method, 'POST')
  assert.equal(calls[0].opts.json.serverId, 'srv-1', '多台启用服时必须显式指定 serverId（否则宿主回 400）')
  // 扫描结果面板（逐字文案）
  const html = String(m.item.innerHTML)
  for (const s of ['扫描结果', '名在线玩家，发现', '条违规，耗时']) {
    assert.ok(html.includes(s), '扫描面板缺少逐字文案：' + s)
  }
  await restore()
})

// ═════════════════════════════ E. 局部重绘与对话框 ═════════════════════════════

test('局部重绘：下发面板与保存栏各自局部刷新，不整页重建', async () => {
  const m = await ensureMounted()
  await restore()
  m.item._panelProxyValue = undefined
  m.item._saveProxyValue = undefined

  m.item.fireAct('click', 'push-refresh')
  await sleep(40)
  assert.equal(typeof m.item._panelProxyValue, 'string', '下发面板应通过 [data-ac-pushpanel] 局部重绘')
  assert.ok(m.item._panelProxyValue.length > 20, '下发面板重绘内容过短')

  m.item.fireAct('change', 'sw-enable')
  await sleep(20)
  assert.equal(typeof m.item._saveProxyValue, 'string', '保存栏应通过 [data-ac-savebar] 局部重绘')
  await restore()
})

test('选择器对话框：挂到 body、能关闭，关闭后不留残留节点', async () => {
  await ensureMounted()
  await restore()
  const before = dom.body.children.length
  const dlg = searchMod.openSearchDialog({
    kind: 'item',
    mode: 'browse',
    multi: false,
    tiers: ['始终生效', '困难模式'],
    defaultProgress: '始终生效',
    onClose() {},
    onPick() { return { ok: true } },
  })
  assert.ok(dlg && typeof dlg.close === 'function', 'openSearchDialog 应返回带 close() 的对话框')
  assert.equal(dom.body.children.length, before + 1, '对话框应挂到 body 上')
  dlg.close()
  assert.equal(dom.body.children.length, before, '关闭后必须把自己从 body 摘掉（不留残留遮罩）')
})

// ═════════════════════════════ F. 纯函数与文案核对 ═════════════════════════════

test('编辑器预校验：空 id / 超范围 id / 扫描间隔越界 / command 为空都会被拦下', async () => {
  await ensureMounted()
  await restore()
  const idMin = tier.ID_MIN
  const idMax = tier.ID_MAX
  assert.equal(idMin, 1)
  assert.equal(idMax, 65535)

  // 合法基线：必须零错误（否则后面的负例没有区分度）
  assert.deepEqual(tier.validateEditor('item'), [], 'fixture 基线应当是合法配置')

  const cases = [
    ['空 id', (c) => { c.item['限制列表'][0]['限制物品'][0].id = '' }],
    ['非数字 id', (c) => { c.item['限制列表'][0]['限制物品'][0].id = 'abc' }],
    ['超范围 id', (c) => { c.item['限制列表'][0]['限制物品'][0].id = idMax + 1 }],
    ['id 小于下限', (c) => { c.item['限制列表'][0]['限制物品'][0].id = idMin - 1 }],
    ['堆叠数量非法', (c) => { c.item['限制列表'][0]['限制物品'][0].stack = 0 }],
    ['command 方式但命令为空', (c) => { c.item['限制列表'][1]['限制物品'][0].command = '' }],
    ['扫描间隔为 0', (c) => { c.item['扫描间隔'] = 0 }],
    ['扫描间隔越界', (c) => { c.item['扫描间隔'] = tier.INTERVAL_MAX + 1 }],
    ['扫描间隔非数字', (c) => { c.item['扫描间隔'] = 'x' }],
  ]
  const notCaught = []
  for (const [name, mutate] of cases) {
    await restore()
    store.mutate(mutate)
    const errs = tier.validateEditor('item')
    if (!errs.length) notCaught.push(name)
  }
  assert.deepEqual(notCaught, [], '这些非法输入没有被客户端预校验拦下：' + notCaught.join('、'))
  await restore()
})

test('未知档位：buildTierList 保留它、buildTierPayload 也保留它（旧版会静默删除）', async () => {
  await ensureMounted()
  await restore()
  const view = progress.buildTierList(store.tiers('item'), store.getState().meta, '限制物品')
  const unknown = view.filter((t) => t.known === false)
  assert.equal(unknown.length, 1, '应有 1 个未知档位被保留，实际 ' + unknown.length)
  assert.equal(String(unknown[0].进度), '自定义档位X')
  assert.equal(unknown[0].inConfig, true)
  assert.equal(unknown[0].entries.length, 1, '未知档位的条目也必须保留')
  // 已知档位顺序必须按宿主的 knownProgress（不是按配置里的顺序）
  assert.deepEqual(view.filter((t) => t.known).map((t) => String(t.进度)), ['始终生效', '困难模式'])
  const payload = tier.buildTierPayload('item', view)
  assert.ok(payload.some((t) => String(t.进度) === '自定义档位X'), '保存产物里未知档位必须还在')
})

test('搜索：按 id / 中文名 / 英文名 / 非数字模组弹幕都能命中', () => {
  const dict = {
    2676: { chinese: '天顶剑', english: 'Zenith', internal: 'Zenith' },
    100: { chinese: '木箭', english: 'Wooden Arrow', internal: 'WoodenArrow' },
  }
  const entries = Object.keys(dict).map((k) => ({
    id: Number(k),
    rawId: k,
    chinese: dict[k].chinese,
    english: dict[k].english,
    internal: dict[k].internal,
    numeric: true,
  }))
  assert.equal(searchMod.searchEntries(entries, '2676').rows.length, 1, '数字串应按 id 命中')
  assert.equal(searchMod.searchEntries(entries, '天顶').rows.length, 1, '中文名子串应命中')
  assert.equal(searchMod.searchEntries(entries, 'zenith').rows.length, 1, '英文名应大小写不敏感命中')
  assert.equal(searchMod.searchEntries(entries, '').rows.length, 2, '空查询应回全部（上限内）')

  // 弹幕侧的模组弹幕：id 不是数字，必须仍然可搜（search.js:58-78 保留 rawId）
  const mixed = entries.concat([{ id: NaN, rawId: 'm1001', chinese: '模组弹幕', english: '', internal: '', numeric: false }])
  const hit = searchMod.searchEntries(mixed, '模组')
  assert.equal(hit.rows.length, 1, '非数字 id 的模组弹幕必须能被中文名搜到')
  assert.equal(hit.rows[0].rawId, 'm1001', '命中项必须保留原始 rawId（回填给配置的就是它）')
  assert.equal(typeof hit.total, 'number')
  assert.equal(typeof hit.truncated, 'boolean')
})

test('日志查询：page/pageSize 始终下发，日期补成闭区间整天，且不发 aggregate', () => {
  const q = logMod.buildLogQuery(
    { timeFrom: '2026-01-01', timeTo: '2026-01-02', player: 'steve', category: 'item' },
    2, 50
  )
  const p = new URLSearchParams(String(q).replace(/^\?/, ''))
  assert.equal(p.get('page'), '2')
  assert.equal(p.get('pageSize'), '50')
  assert.equal(p.get('player'), 'steve')
  assert.equal(p.get('category'), 'item')
  assert.equal(p.get('timeFrom'), '2026-01-01 00:00:00', '只给日期时必须补 00:00:00（闭区间整天）')
  assert.equal(p.get('timeTo'), '2026-01-02 23:59:59', '只给日期时必须补 23:59:59')
  assert.equal(p.get('aggregate'), null, '不得下发 aggregate（会让单台服也被标成近似）')
  // 空筛选：page/pageSize 仍要在
  const p2 = new URLSearchParams(String(logMod.buildLogQuery({}, 1, 50)).replace(/^\?/, ''))
  assert.equal(p2.get('page'), '1')
  assert.equal(p2.get('pageSize'), '50')
  assert.equal(p2.get('player'), null)
  assert.deepEqual(Object.keys(logMod.emptyFilters()).sort(), ['category', 'method', 'player', 'q', 'serverId', 'timeFrom', 'timeTo'])
})

test('日志展示：分类/处置方式的文案与颜色对未知值都有兜底', () => {
  for (const c of ['item', 'proj', 'particle', 'unknown-cat', '', null]) {
    assert.equal(typeof logMod.categoryText(c), 'string')
    assert.ok(String(logMod.categoryText(c)).length > 0, '分类文案不能为空：' + String(c))
    assert.ok(String(logMod.categoryColor(c)).length > 0, '分类颜色不能为空：' + String(c))
  }
  for (const mv of ['log', 'kick', 'ban', 'drop', 'command', 'unknown-method', '', null]) {
    assert.equal(typeof logMod.methodText(mv), 'string')
    assert.ok(String(logMod.methodText(mv)).length > 0, '处置文案不能为空：' + String(mv))
    assert.ok(String(logMod.methodColor(mv)).length > 0, '处置颜色不能为空：' + String(mv))
  }
  // 「目标」列文案（逐字复刻旧 rowTitle）
  assert.equal(logMod.rowTitle({ itemName: '天顶剑', itemId: 2676 }), '[i:2676] 天顶剑')
  assert.equal(logMod.rowTitle({ projId: 100, projName: '光之矢' }), '弹幕#100 光之矢')
  assert.equal(logMod.rowTitle({ projId: 100 }), '弹幕#100')
  assert.equal(logMod.rowTitle({ category: 'particle' }), '粒子请求')
  assert.equal(logMod.rowTitle({}), '检测事件')
})

test('玩家区块：cleanup 之后到达的陈旧响应必须被丢弃（不写回已卸载的容器）', async () => {
  await ensureMounted()
  await restore()
  let release = null
  const pending = new Promise((resolve) => { release = resolve })
  const saved = dom.setApi((path) => {
    if (path.startsWith('/api/anticheat/check-anomaly')) return pending
    return fullApi(path)
  })
  const c = makeEl('div')
  let cleanup = null
  const renderErr = []
  try {
    cleanup = await psMod.renderAlertSection(c, { username: 'steve' }, { account: { username: 'steve' }, inventory: [{ slot: 0, netID: 2676, stack: 500 }] })
  } catch (err) {
    renderErr.push(err)
  }
  assert.deepEqual(renderErr.map((e) => (e && e.message) || String(e)), [], '区块渲染抛错')
  await sleep(20)
  const snapshot = c.innerHTML
  assert.equal(typeof cleanup, 'function', 'renderAlertSection 必须返回 cleanup（宿主切玩家时要能取消）')
  cleanup()
  release({ ok: true, status: 200, data: { anomaly: true, serverName: '主服' } })
  await sleep(40)
  assert.equal(c.innerHTML, snapshot, 'cleanup 之后到达的响应把内容写回去了（陈旧响应未被丢弃）')
  // 反过来自证：不清 cleanup 的情况下，同样的响应必须真的改变渲染结果（否则本用例空转）
  saved.setApi(fullApi)
  const c2 = makeEl('div')
  await psMod.renderAlertSection(c2, { username: 'steve' }, { account: { username: 'steve' }, inventory: [{ slot: 0, netID: 2676, stack: 500 }] })
  await sleep(40)
  assert.ok(c2.innerHTML.includes('违禁判定'), '正常路径下应渲染出违禁判定结果：' + String(c2.innerHTML).slice(0, 160))
  await restore()
})

test('图片兜底：图标加载失败时替换成占位，不留破图；非 IMG 目标与重复绑定都被正确处理', async () => {
  await ensureMounted()
  const holder = makeEl('div')
  const img = makeEl('img')
  img.setAttribute('data-ac-img', '')
  holder.appendChild(img)
  // 语义依据：api.js:416-431，用**捕获阶段**绑 error（图片 error 不冒泡），失败时用 span 占位
  apiMod.bindImageFallback(holder)
  apiMod.bindImageFallback(holder)
  assert.equal(holder.listenerCount('error'), 1, '重复绑定不得累加监听器（api.js:418 的 __acImgFallback 去重）')

  // 非 IMG 目标必须被忽略（不能把别的元素替换掉）
  const div = makeEl('div')
  holder.appendChild(div)
  holder.fire('error', { target: div })
  assert.equal(holder.children.length, 2, '非 IMG 目标不应被替换')

  holder.fire('error', { target: img })
  assert.equal(holder.children.length, 2, '失败图片应被占位替换（数量不变：一个换一个）')
  const ph = holder.children[0]
  assert.equal(ph.className, 'ac-icon-ph', '占位元素必须带 ac-icon-ph 类')
  assert.equal(ph.textContent, '?', '占位元素应显示 ?')
  assert.ok(holder.children.includes(img) === false, '原 img 必须已被摘下（不留破图）')

  // 同一个 img 重复触发只替换一次（__acFallbackDone 幂等）
  holder.fire('error', { target: img })
  assert.equal(holder.children.length, 2, '重复触发不得反复替换')
})

test('弹幕侧快捷命令：恰好 3 条、占位符为 {projid}，且没有 /remove 那条', async () => {
  const m = await ensureMounted()
  const html = String(m.proj.innerHTML)
  for (const t of ['/banp "{playername}" "违规使用{projid}"', '/kick "{playername}" "违规使用{projid}"', '/bc "{playername}违规使用{projid}"']) {
    assert.ok(html.includes(t) || html.includes(t.replace(/"/g, '&quot;')), '缺少弹幕侧快捷命令模板：' + t)
  }
  assert.ok(!html.includes('/remove'), '弹幕侧不得出现 /remove 模板（旧版只有 3 条）')
  assert.ok(!html.includes('{itemname}'), '弹幕侧不得出现 {itemname} 占位符')
  assert.ok(!html.includes('{itemid}'), '弹幕侧不得出现 {itemid} 占位符')
  const n = (html.match(/data-ac-act="entry-quick"/g) || []).length
  assert.equal(n, 3, '弹幕侧快捷命令按钮应恰好 3 个，实际 ' + n)
  // 派生函数本身也要对：4 条物品命令 -> 3 条弹幕命令
  const derived = methodMod.projQuickCommands(CONFIG_META.quickCommands)
  assert.equal(derived.length, 3)
  for (const d of derived) {
    assert.ok(String(d.template).includes('{projid}'), '派生模板必须用 {projid}：' + d.template)
    assert.ok(!String(d.template).includes('{itemid}'), '派生模板不得残留 {itemid}')
  }
})

test('物品侧快捷命令：4 条逐字模板都出现在页面上，占位符提示与 method 标签一致', async () => {
  const m = await ensureMounted()
  const html = String(m.item.innerHTML)
  for (const t of ['/banp "{playername}" "违规使用{itemname}"', '/kick "{playername}" "违规使用{itemname}"', '/bc "{playername}违规使用{itemname}"', '/remove {playername} {itemid}']) {
    assert.ok(html.includes(t) || html.includes(t.replace(/"/g, '&quot;')), '缺少物品侧快捷命令模板：' + t)
  }
  for (const s of ['物品ID', '数量', '最大数量', '仅记录日志', '踢出玩家', '封禁玩家', '执行自定义命令', '仅阻断（不踢不封）', '快速:', '批量添加', '保存配置']) {
    assert.ok(html.includes(s), '物品页缺少逐字文案：' + s)
  }
  assert.ok(html.includes('支持 {playername}、{itemname}、{itemid} 转义'), '物品侧占位符提示应逐字')
  // method 取值域来自宿主（config.js 的 METHOD_VALUES），前端不得自造
  for (const mv of CONFIG_META.methodValues) {
    assert.equal(typeof methodMod.methodLabel(mv, CONFIG_META.methodLabels), 'string')
    assert.ok(String(methodMod.methodLabel(mv, CONFIG_META.methodLabels)).length > 0)
  }
  // method.js:150-154：闭集里**除 command 外**都算标准档（旧版"非 log/kick/ban 即当命令执行"
  // 正是 D-34 任意命令执行面的成因，前端必须跟宿主一起收敛）
  assert.equal(methodMod.isStandardMethod('ban', CONFIG_META.methodValues), true)
  assert.equal(methodMod.isStandardMethod('drop', CONFIG_META.methodValues), true, 'drop 是标准档，不得被当成自定义命令模板')
  assert.equal(methodMod.isStandardMethod('command', CONFIG_META.methodValues), false, 'command 是自定义命令模板，不算标准档')
  assert.equal(methodMod.isStandardMethod('remove', CONFIG_META.methodValues), false, 'method 取值域之外的值必须被判为非标准')
  assert.equal(methodMod.isStandardMethod('', CONFIG_META.methodValues), false)
  assert.equal(methodMod.isStandardMethod('log', []), true, 'values 缺失时应回落到内置闭集')
  assert.deepEqual(methodMod.defaultEntry('item'), { id: 0, stack: 1, method: 'log', command: '' })
  assert.deepEqual(methodMod.defaultEntry('proj'), { id: 0, method: 'log', command: '' })
})
