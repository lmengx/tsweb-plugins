/**
 * anti-cheat 打包元数据 + 构建产物新鲜度测试（被测对象：scripts/pack-plugin.mjs）
 *
 * ══════════ 为什么需要这个文件 ══════════
 *   1. 本插件的 C# 半（plugin/AntiCheat.dll）是**会被打包下发到每一台游戏服**的东西，而
 *      plugin/ 下同时存在两个有可能装着它的位置：plugin/AntiCheat.dll 与
 *      plugin/bin/Release/net9.0/AntiCheat.dll。本仓实测过这两个位置打架的缺陷：
 *      plugins/qq-bind/plugin/QqBind.dll（27136 B）里根本没有 QqPromotion 那段代码，而同目录
 *      obj/Release 的产物（32768 B）里有——打包器无条件从 bin/Release/<tfm>/ 回拷，把刚构建好的
 *      产物覆盖成了陈旧的那份，全程没有任何报错（见 scripts/pack-plugin.mjs:204-230 的长注释）。
 *      所以"到底哪一份 DLL 会被下发""它是不是比 .cs 源码还旧"必须变成可复跑的断言，
 *      而不是每次靠人眼比对体积和 mtime。
 *   2. package.json 的元数据决定"市场里能不能搜到、装到哪、下发什么"：
 *      name 与目录名不一致 -> "装了但找不到"；tsweb.tags 越界 -> 市场筛选维度失效；
 *      tsweb.dll 的 glob 写错 -> 打出没有 C# 半的包（游戏服侧完全失效）。这些要逐字段锁死。
 *
 * ══════════ 本机限制（如实说明，不含糊）══════════
 *   本机**没有 TShock**，也没有能加载 C# 插件的服务器运行环境。因此本文件里的全部断言
 *   只能证明：**会被打包下发的文件是哪一个、它会比源码旧吗、打包器会不会接受这个目录**。
 *   它**不能**证明 AntiCheat.dll 在真实 TShock 上能加载、能挂 ItemDrop/NewProjectile 包钩子、
 *   能就地阻断违禁物，也不能证明 Microsoft.Data.Sqlite 在服务器上能解析到
 *   （AntiCheat.csproj:29-31 已就这一点写明"未经运行期验证"）。
 *   "插件在服务器上真的可用"不在本文件的覆盖范围内。
 *
 * ══════════ 关于"node scripts/pack-plugin.mjs anti-cheat --check 通过"这条要求的替代 ══════════
 *   本机沙箱下 Node 子进程的**管道 stdio 会 EPERM**（用 child_process 捕获子进程输出不可用），
 *   因此本文件**不**用 child_process 去跑打包脚本，改为 import scripts/pack-plugin.mjs（文件末尾
 *   invokedDirectly 判断保证 import 时不会执行 main，见 pack-plugin.mjs:542-550）并**直接调用它导出的
 *   validate(pluginDir, name, opts)**（pack-plugin.mjs:347）——这正是 `--check` 路径里做校验的那个函数
 *   （main 在 pack-plugin.mjs:496 调用它，随后 501-505 行在 opts.check 时直接返回，不产出任何文件）。
 *   等价覆盖点：name 等于目录名 / version 是 semver / index.js 存在且导出 apply(ctx) /
 *   tsweb.client 指向的文件存在 / tsweb.deploy 三态 / tsweb.tags 闭集与去重 / dll glob 至少命中一份 /
 *   文件清单非空，以及返回的 { files } 清单形状。
 *   两处如实说明的差异：
 *     a) 本文件传 { build: false }，即**不触发 dotnet build**（测试不该改磁盘上的 DLL 产物）；
 *        CLI 的 `--check` 默认 opts.build=true，会先真的构建一遍。
 *     b) CLI 额外做的是打印清单与失败时置非 0 退出码；本文件改为断言"抛不抛错"。
 *
 * 运行：cd plugins/anti-cheat && node test/pack-freshness.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, mkdir, writeFile, utimes, readFile, readdir, stat } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

// 打包器已导出函数供其它脚本 import（import 时不会执行 main，见其文件末尾的 invokedDirectly 判断）
import { pickBuildArtifact, ALLOWED_TAGS, validate, collectFiles } from '../../../scripts/pack-plugin.mjs'

/** 本插件的程序集名（plugin/AntiCheat.csproj:7 的 <AssemblyName>AntiCheat</AssemblyName>） */
const ASSEMBLY = 'AntiCheat'

/** 本插件唯一的构建目标框架（plugin/AntiCheat.csproj:4 的 <TargetFramework>net9.0</TargetFramework>） */
const TFM = 'net9.0'

const here = path.dirname(fileURLToPath(import.meta.url))
/** 本插件的真实目录（A / B / D 三组用例直接对它断言） */
const pluginDir = path.resolve(here, '..')
/** 本插件的真实 C# 半目录 */
const realPluginSub = path.join(pluginDir, 'plugin')
/** 打包器回拷 DLL 的来源目录（pack-plugin.mjs:309 的 plugin/bin/Release） */
const realBinDir = path.join(realPluginSub, 'bin', 'Release')

/** package.json 只读一次（它同时是 A 组用例的被测对象与 B/D 组用例的对照数据） */
const pkg = JSON.parse(await readFile(path.join(pluginDir, 'package.json'), 'utf8'))

let root

before(async () => {
  root = await mkdtemp(path.join(tmpdir(), 'anti-cheat-pack-'))
})

after(async () => {
  await rm(root, { recursive: true, force: true })
})

let caseSeq = 0

/**
 * 造一个"插件目录"：
 *   pluginDll：{ content, ageMs } 写入 plugin/<Assembly>.dll（ageMs = 相对现在的"多久以前"）
 *   binDlls：  { '<tfm>': { content, ageMs } } 写入 plugin/bin/Release/<tfm>/<Assembly>.dll
 */
async function makeCase({ pluginDll, binDlls = {} } = {}) {
  caseSeq += 1
  const pluginSub = path.join(root, `case-${caseSeq}`, 'plugin')
  await mkdir(pluginSub, { recursive: true })

  const now = Date.now()
  const stamp = async (file, spec) => {
    await writeFile(file, spec.content, 'utf8')
    const t = new Date(now - spec.ageMs)
    await utimes(file, t, t)
  }

  if (pluginDll) await stamp(path.join(pluginSub, `${ASSEMBLY}.dll`), pluginDll)
  for (const [tfm, spec] of Object.entries(binDlls)) {
    const dir = path.join(pluginSub, 'bin', 'Release', tfm)
    await mkdir(dir, { recursive: true })
    await stamp(path.join(dir, `${ASSEMBLY}.dll`), spec)
  }

  return { pluginSub, binDir: path.join(pluginSub, 'bin', 'Release') }
}

/** 陈旧夹具的年龄必须远大于打包器的"本次构建"容许误差（pack-plugin.mjs:183 = 2000 ms） */
const FRESH = { content: '本次构建的新产物', ageMs: 0 }
const STALE = { content: '很久以前的陈旧产物（内容不同）', ageMs: 60 * 60 * 1000 }

/** 读文件算 sha256；文件不存在返回 null（D 组用例用它做"跳过而不是误报"） */
async function shaOf(file) {
  try {
    return createHash('sha256').update(await readFile(file)).digest('hex')
  } catch (err) {
    if (err.code === 'ENOENT') return null
    throw err
  }
}

/** 真实 DLL 是否在磁盘上（决定 D③ / D⑤ 是"跳过并说明未验证"还是"真的断言"） */
const realDllExists = (await shaOf(path.join(realPluginSub, `${ASSEMBLY}.dll`))) !== null
const realBinDllExists = (await shaOf(path.join(realBinDir, TFM, `${ASSEMBLY}.dll`))) !== null

// ════════════════════════════════════════════════════════════════════════
// A 组：package.json 元数据（逐字段）
// ════════════════════════════════════════════════════════════════════════

test('A① name 必须等于目录名 anti-cheat（loader 与市场注册表都以目录名为键）', async () => {
  assert.equal(pkg.name, 'anti-cheat')
  // 目录名是权威：市场/ loader 按目录名匹配，package.json 里写别的名字会"装了但找不到"
  assert.equal(pkg.name, path.basename(pluginDir), 'package.json 的 name 必须与插件目录名逐字相同')
})

test('A② type 必须是 module，main 必须是 index.js', () => {
  assert.equal(pkg.type, 'module', '宿主按 ESM 加载插件，type 写错会 import 失败')
  assert.equal(pkg.main, 'index.js')
})

test('A③ tsweb.autoload 为 true、tsweb.bundled 为 false', () => {
  assert.equal(pkg.tsweb?.autoload, true, '本插件要随宿主自动加载（不是手动启用的可选插件）')
  assert.equal(pkg.tsweb?.bundled, false, 'bundled=true 是"随宿主发行包一起下发"的标记，本插件不属于自带插件')
})

test('A④ tsweb.client 必须指向真实存在的前端入口 ./client/anti-cheat.js', async () => {
  assert.equal(pkg.tsweb?.client, './client/anti-cheat.js')
  // 声明了就要真的存在，否则前端半整块缺失（打包器只在"声明了"才校验存在性，见 pack-plugin.mjs:363-367）
  const st = await stat(path.join(pluginDir, pkg.tsweb.client))
  assert.ok(st.isFile(), `${pkg.tsweb.client} 必须是一个真实存在的文件`)
})

test('A⑤ tsweb.dll 必须是 ["./plugin/*.dll"]（C# 半的下发来源，就这一层）', () => {
  assert.deepEqual(pkg.tsweb?.dll, ['./plugin/*.dll'])
})

test('A⑥ tsweb.deploy 必须是 all（配置变更后自动下发到所有已启用服务器）', () => {
  assert.equal(pkg.tsweb?.deploy, 'all', '反作弊清单不下发就等于没有防护，必须是 all 而不是 ask/manual')
})

test('A⑦ tsweb.tags 必须是 ["反作弊"]，且每一项都在 ALLOWED_TAGS 闭集内', () => {
  assert.deepEqual(pkg.tsweb?.tags, ['反作弊'])
  for (const t of pkg.tsweb.tags) {
    assert.ok(ALLOWED_TAGS.includes(t), `tsweb.tags 里的"${t}"不在打包器白名单 ALLOWED_TAGS 内，pack --check 会直接失败`)
  }
})

test('A⑧ ALLOWED_TAGS 恰好 7 个分类，七个一个不少（市场筛选维度是闭集，不得私自扩张）', () => {
  // 为什么逐条列出来：这七项是市场页的**筛选维度**，是 scripts/pack-plugin.mjs:75-83 定义的唯一权威闭集。
  // 少一项 -> 该分类下的插件全部打包失败；多一项 -> 市场多出一个没人认的分类，筛选退化成关键词匹配。
  // 逐条理由（与 pack-plugin.mjs:76-82 的注释一致）：
  //   管理工具 —— 玩家/用户组/权限/文件/运维/审计/世界编辑等管理员操作
  //   机制拓展 —— 给游戏加玩法：圈地、商店、传送、观战、Boss 魔改等
  //   反作弊   —— 检测与阻断作弊、抓包取证（本插件属于这一类）
  //   漏洞修复 —— 修缺陷与误判（不是"加玩法"，也不是"跨版本适配"）
  //   数据统计 —— 只读的统计/报表/排行/日历，不含管理动作
  //   版本兼容 —— 跨游戏版本的协议适配、更新抑制
  //   QQ管理   —— 围绕 QQ 绑定的一族插件
  const expected = ['管理工具', '机制拓展', '反作弊', '漏洞修复', '数据统计', '版本兼容', 'QQ管理']
  assert.deepEqual(
    expected.filter((t) => !ALLOWED_TAGS.includes(t)),
    [],
    'ALLOWED_TAGS 少了下述分类（打包校验依赖这份闭集）：',
  )
  assert.deepEqual(
    ALLOWED_TAGS.filter((t) => !expected.includes(t)),
    [],
    'ALLOWED_TAGS 多了下述分类（新增分类要改 pack-plugin.mjs 与 docs/插件开发约定.md，不能在插件里偷偷加）',
  )
  assert.equal(ALLOWED_TAGS.length, 7, 'ALLOWED_TAGS 必须恰好 7 项：多了少了都意味着筛选维度被改动')
})

test('A⑨ version 必须是合法 semver（x.y.z，可带 -pre 后缀）', () => {
  assert.match(String(pkg.version), /^\d+\.\d+\.\d+/, `version 必须形如 x.y.z：实际 ${pkg.version}`)
  // 与打包器同一套判定（pack-plugin.mjs:355），避免"测试用的正则比打包器松"这种假通过
  assert.match(String(pkg.version), /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/)
})

test('A⑩ 没有多余的自造顶层字段，且 description 如实覆盖三块功能（防"描述与实际功能不符"）', () => {
  // 这条防的是"写了个字段但没有任何代码读它"与"自造分类字段绕过 ALLOWED_TAGS 闭集"：
  // 市场的分类只有 tsweb.tags 一个来源，不允许再出现 tsweb.category / tsweb.kind 之类的自造字段。
  const allowedTop = new Set(['name', 'version', 'private', 'type', 'main', 'scripts', 'description', 'tsweb'])
  const extraTop = Object.keys(pkg).filter((k) => !allowedTop.has(k))
  assert.deepEqual(extraTop, [], `package.json 出现了约定之外的自造顶层字段（没有代码读它，容易"写了以为生效了"）：${extraTop.join('、')}`)

  const allowedTsweb = new Set(['autoload', 'bundled', 'client', 'dll', 'deploy', 'tags'])
  const extraTsweb = Object.keys(pkg.tsweb).filter((k) => !allowedTsweb.has(k))
  assert.deepEqual(extraTsweb, [], `tsweb 下出现了约定之外的自造字段（例如自造分类字段，它会绕过 tags 闭集校验）：${extraTsweb.join('、')}`)

  assert.equal(typeof pkg.description, 'string', 'description 必须存在（市场列表直接展示它）')
  assert.ok(pkg.description.trim().length >= 40, `description 不能是空壳：实际 ${pkg.description.trim().length} 字符`)

  // 描述必须和实际做的三块对得上。本插件的范围界定见 index.js:8-14：
  //   物品违禁（ItemDrop / ChestItemChange 包钩子 + 背包扫描）
  //   弹幕违禁（NewProjectile 钩子 + 伤害上限 / 负伤害判定）
  //   检测日志（CheatLog 表，跨服聚合查询与统计）
  // 若把没做的功能写进描述（或做了却没写），市场展示的与实际行为不符，用户按描述装了会发现没效果。
  assert.match(pkg.description, /物品违禁/, 'description 必须写明"物品违禁"这一块')
  assert.match(pkg.description, /弹幕违禁/, 'description 必须写明"弹幕违禁"这一块')
  assert.match(pkg.description, /检测日志/, 'description 必须写明"检测日志"这一块')
  assert.doesNotMatch(pkg.description, /粒子防线/, '粒子防线是本插件明确不做、归"漏洞修复"的部分（index.js:13），不得写进描述')
})

// ════════════════════════════════════════════════════════════════════════
// B 组：直接调用打包器的校验函数（替代 child_process 跑 `--check`，理由见文件头）
// ════════════════════════════════════════════════════════════════════════

test('B① validate(pluginDir, "anti-cheat", { build: false }) 通过，返回 { pkg, name, version, files, built, dllGlobs }', async () => {
  const info = await validate(pluginDir, 'anti-cheat', { build: false })

  assert.deepEqual(Object.keys(info).sort(), ['built', 'dllGlobs', 'files', 'name', 'pkg', 'version'].sort())
  assert.equal(info.name, 'anti-cheat')
  assert.equal(info.version, pkg.version)
  assert.equal(info.pkg.name, 'anti-cheat')
  assert.deepEqual(info.dllGlobs, ['./plugin/*.dll'], 'dllGlobs 必须原样带出 package.json 的 tsweb.dll')
  // build:false 时不构建，built 保持 null（pack-plugin.mjs:397-400）
  assert.equal(info.built, null, 'opts.build=false 时不应触发 dotnet build')

  assert.ok(Array.isArray(info.files) && info.files.length > 0)
  for (const f of info.files) {
    assert.equal(typeof f.rel, 'string', 'collectFiles 的元素应当是 { rel, size }')
    assert.equal(typeof f.size, 'number')
    assert.ok(f.size > 0, `清单里的 ${f.rel} 体积为 0，不正常`)
    assert.equal(f.rel.includes('\\'), false, 'rel 必须用正斜杠（collectFiles 内部做过 path.sep 归一）')
  }
  // 清单必须按路径排序（打包可复现的前提，见 pack-plugin.mjs:144）
  const rels = info.files.map((f) => f.rel)
  assert.deepEqual(rels, [...rels].sort((a, b) => a.localeCompare(b)), '文件清单必须按路径排序')
})

test('B② 清单里不含 bin/ obj/ 与源码类后缀（.cs/.csproj/.pdb），且 collectFiles 与 validate 结论一致', async () => {
  const info = await validate(pluginDir, 'anti-cheat', { build: false })
  const rels = info.files.map((f) => f.rel)

  // SKIP_DIRS = bin/obj/.git/node_modules/data/.vs（pack-plugin.mjs:54）
  const inBuildDirs = rels.filter((r) => r.split('/').some((seg) => seg === 'bin' || seg === 'obj'))
  assert.deepEqual(inBuildDirs, [], `发行包不应包含构建中间产物目录里的东西：${inBuildDirs.join('、')}`)

  // SKIP_EXT 确实包含 .cs/.csproj/.pdb（pack-plugin.mjs:61-64）——C# 半只下发编译好的 .dll
  const sourceish = rels.filter((r) => /\.(cs|csproj|sln|slnx|props|targets|pdb|xml|log|tgz)$/.test(r))
  assert.deepEqual(sourceish, [], `发行包不应包含源码/中间产物后缀的文件：${sourceish.join('、')}`)

  // validate 内部就是 collectFiles(pluginDir)（pack-plugin.mjs:409），两者必须完全一致，
  // 否则"打包器算出来的清单"和"我们看到的清单"是两回事，下面 B③ 的断言就没有意义
  assert.deepEqual(collectFiles(pluginDir), info.files, 'collectFiles 与 validate 返回的 files 必须逐项一致')
})

test('B③ 关键文件都在清单里，且文件数与总体积是合理量级（防"什么都没打包"也算过"）', async () => {
  const info = await validate(pluginDir, 'anti-cheat', { build: false })
  const rels = new Set(info.files.map((f) => f.rel))

  const required = [
    'package.json',
    'index.js',
    'config.js',
    'store.js',
    'defaults.js',
    'logs.js',
    'audit.js',
    'gameOps.js',
    'client/anti-cheat.js',
    'client/shared/api.js',
    `plugin/${ASSEMBLY}.dll`,
    'resources/物品违禁.json',
    'resources/弹幕违禁.json',
    'test/support/fake-host.mjs',
  ]
  const missing = required.filter((r) => !rels.has(r))
  assert.deepEqual(missing, [], `打包清单缺少这些运行必需文件：${missing.join('、')}`)

  // 量级守卫：清单不能是"几乎空的"。本插件当前约 25 个文件 / 约 539 KB（含 147 KB 的 DLL），
  // 取 20 个文件 / 300 KB 作为下限——低于它说明打包器漏收了整块目录（例如 client/ 或 resources/）。
  assert.ok(info.files.length >= 20, `打包清单只有 ${info.files.length} 个文件，量级明显不对`)
  const totalBytes = info.files.reduce((s, f) => s + f.size, 0)
  assert.ok(totalBytes >= 300 * 1024, `打包清单总体积只有 ${totalBytes} B，量级明显不对`)
  // resources/ 两份默认清单必须都在（游戏服侧要靠它们初始化默认违禁表）
  assert.ok(rels.has('resources/物品违禁.json') && rels.has('resources/弹幕违禁.json'))

  // DLL 必须真的能被打包器 glob 命中（pack-plugin.mjs:404-407 的命中校验），否则打出没有 C# 半的包
  const dlls = info.files.filter((f) => /^plugin\/[^/]+\.dll$/.test(f.rel))
  assert.deepEqual(dlls.map((f) => f.rel), [`plugin/${ASSEMBLY}.dll`], 'plugin/ 这一层应当正好命中一份 AntiCheat.dll')
})

// ════════════════════════════════════════════════════════════════════════
// C 组：pickBuildArtifact 的四种情形（合成目录 + 显式 mtime，不依赖真实构建）
// ════════════════════════════════════════════════════════════════════════

test('C① plugin/ 是本次产物、bin/ 是陈旧产物 -> 选 plugin/ 的（修复点：不再用陈旧 bin 覆盖新构建）', async () => {
  const { pluginSub, binDir } = await makeCase({
    pluginDll: { content: '本次新构建的内容-A', ageMs: 0 },
    binDlls: { [TFM]: { content: '陈旧内容-B', ageMs: 3600_000 } },
  })
  const { chosen } = pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() })
  assert.equal(chosen.origin, 'plugin', '必须采用构建直接写出的 plugin/ 产物（旧实现这里会回拷 bin 的陈旧副本）')
  assert.match(chosen.sha256, /^[0-9a-f]{64}$/)
})

test('C② bin/ 是本次产物 -> 选 bin/ 的（本插件的常规布局：csproj:15 OutputPath=bin\\$(Configuration)\\）', async () => {
  const { pluginSub, binDir } = await makeCase({
    pluginDll: { content: '上一次的旧内容', ageMs: 3600_000 },
    binDlls: { [TFM]: { content: '本次新构建的内容', ageMs: 0 } },
  })
  const { chosen } = pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() })
  assert.equal(chosen.origin, `bin/Release/${TFM}`, '本插件的构建产物落在 bin/Release/net9.0/，由打包器复制到 plugin/AntiCheat.dll')
})

test('C③ 两份都不是本次产物且内容不同 -> 必须报错（不许静默用旧的那份）', async () => {
  const { pluginSub, binDir } = await makeCase({
    pluginDll: { content: '旧内容-plugin（含新代码）', ageMs: 7200_000 },
    binDlls: { [TFM]: { content: '更旧的 bin 内容（缺新代码）', ageMs: 10 * 24 * 3600_000 } },
  })
  assert.throws(
    () => pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() }),
    (err) => {
      assert.match(err.message, /构建产物不新鲜/)
      assert.match(err.message, /--rebuild/, '报错必须给出可操作的恢复手段')
      assert.match(err.message, /plugin[\\/]bin/, '报错必须说明该删哪些目录')
      return true
    },
  )
})

test('C④ 两份都不是本次产物但内容相同 -> 允许（增量构建没重写文件，不存在陈旧副本冲突）', async () => {
  const same = '内容完全一致（增量构建空转）'
  const { pluginSub, binDir } = await makeCase({
    pluginDll: { content: same, ageMs: 3600_000 },
    binDlls: { [TFM]: { content: same, ageMs: 3600_000 } },
  })
  const { chosen, candidates } = await pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() })
  assert.equal(candidates.length, 2)
  assert.ok(chosen.sha256)
  assert.equal(chosen.origin, 'plugin', '内容一致时优先取 plugin/ 那份（它就是要下发的目标位置，连复制都不需要）')
})

test('C⑤ 没有任何候选产物 -> 报错，文案含 AntiCheat.dll 与两个查找位置', async () => {
  const { pluginSub, binDir } = await makeCase({})
  assert.throws(
    () => pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() }),
    (err) => {
      // 程序集名必须是本插件的（写错名字会让报错指向别的插件，排障时白跑一趟）
      assert.match(err.message, /未找到 AntiCheat\.dll/)
      assert.ok(
        err.message.includes(path.join(pluginSub, `${ASSEMBLY}.dll`)),
        `报错必须给出 plugin/ 这个查找位置：${err.message}`,
      )
      assert.ok(err.message.includes(binDir), `报错必须给出 bin/Release 这个查找位置：${err.message}`)
      return true
    },
  )
})

test('C⑥ 多份"本次产物"但内容不同（多目标框架）-> 报错而不是随手挑一份', async () => {
  const { pluginSub, binDir } = await makeCase({
    binDlls: {
      'net8.0': { content: 'net8 产物', ageMs: 0 },
      [TFM]: { content: 'net9 产物', ageMs: 0 },
    },
  })
  assert.throws(
    () => pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() }),
    /多份内容不同/,
  )
})

test('C⑦ 多份"本次产物"且内容一致 -> 正常选中（不误报）', async () => {
  const same = '一致的内容'
  const { pluginSub, binDir } = await makeCase({
    pluginDll: { content: same, ageMs: 0 },
    binDlls: { [TFM]: { content: same, ageMs: 0 } },
  })
  const { chosen, fresh } = pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() })
  assert.equal(fresh.length, 2)
  assert.ok(chosen.file.endsWith(`${ASSEMBLY}.dll`))
})

test('C⑧ 陈旧/新鲜夹具本身可区分（防前面用例因 mtime 精度而假通过）', () => {
  assert.notEqual(FRESH.content, STALE.content, '新鲜与陈旧夹具的内容必须不同，C③/C④ 才有意义')
  assert.ok(FRESH.ageMs < STALE.ageMs, '新鲜夹具的年龄必须小于陈旧夹具')
  // 容差是 2000 ms（pack-plugin.mjs:183），陈旧夹具必须远大于它，否则会被误判成"本次产物"
  assert.ok(STALE.ageMs > 2000 * 10, '陈旧夹具要比构建容差大出一个数量级，否则用例可能因时钟精度假通过')
})

// ════════════════════════════════════════════════════════════════════════
// D 组：真实磁盘状态（本插件的真实布局）
// ════════════════════════════════════════════════════════════════════════

test('D① plugin/ 下恰好一个 .dll，且文件名就是 AntiCheat.dll（防"留下旧名产物"被一起下发）', async () => {
  const entries = await readdir(realPluginSub, { withFileTypes: true })
  // 只数 plugin/ 的直接子文件：plugin/bin、plugin/obj 里的产物不算"会被下发的 dll"
  const dlls = entries.filter((e) => e.isFile() && e.name.toLowerCase().endsWith('.dll')).map((e) => e.name)
  assert.equal(
    dlls.length, 1,
    `plugin/ 下的 .dll 必须恰好一个（tsweb.dll 的 glob 是 ./plugin/*.dll，多一个就会被一起下发到每台服）：实际 ${dlls.join('、') || '(无)'}`,
  )
  assert.equal(dlls[0], `${ASSEMBLY}.dll`, 'plugin/ 下那份 .dll 的名字必须等于 csproj 的 AssemblyName')
})

test('D② plugin/AntiCheat.dll 存在、体积 > 4096、以 MZ 开头（合法 PE）', async () => {
  const file = path.join(realPluginSub, `${ASSEMBLY}.dll`)
  const st = await stat(file)
  assert.ok(st.isFile())
  assert.ok(st.size > 4096, `会被打包下发的 DLL 体积异常小（${st.size} B），很可能是坏产物`)
  const buf = await readFile(file)
  assert.equal(buf.subarray(0, 2).toString('latin1'), 'MZ', 'DLL 必须是合法的 PE 文件（MZ 开头）')
})

test('D③ plugin/AntiCheat.dll 的 mtime 不早于 plugin/ 下任何 .cs/.csproj（否则下发的 DLL 比源码旧）', { skip: realDllExists ? false : `plugin/${ASSEMBLY}.dll 不存在（尚未构建）：本用例未做任何验证` }, async () => {
  const dllStat = await stat(path.join(realPluginSub, `${ASSEMBLY}.dll`))
  const sources = (await readdir(realPluginSub, { withFileTypes: true }))
    .filter((e) => e.isFile() && (e.name.endsWith('.cs') || e.name.endsWith('.csproj')))
    .map((e) => e.name)
  assert.ok(sources.length > 0, 'plugin/ 下应当有 .cs/.csproj 源码')

  let newest = { name: null, mtimeMs: -1 }
  for (const name of sources) {
    const st = await stat(path.join(realPluginSub, name))
    if (st.mtimeMs > newest.mtimeMs) newest = { name, mtimeMs: st.mtimeMs }
  }

  assert.ok(
    dllStat.mtimeMs >= newest.mtimeMs,
    `会被打包下发的 plugin/${ASSEMBLY}.dll（mtime ${new Date(dllStat.mtimeMs).toISOString()}）`
    + `比源码 plugin/${newest.name}（mtime ${new Date(newest.mtimeMs).toISOString()}）旧：\n`
    + `  这说明 DLL 里没有最新的 C# 代码，而下发的是这个 DLL。\n`
    + `  恢复：cd tsweb-cordis && node scripts/pack-plugin.mjs anti-cheat --rebuild，\n`
    + `        或删掉 plugins/anti-cheat/plugin/bin、plugins/anti-cheat/plugin/obj 后重新构建。`,
  )
})

test('D④ AntiCheat.csproj 的程序集名/目标框架/OutputPath 与用例假设一致（且 OutputPath 不是 "."）', async () => {
  const csprojPath = path.join(realPluginSub, `${ASSEMBLY}.csproj`)
  const text = await readFile(csprojPath, 'utf8')

  assert.match(text, /<AssemblyName>AntiCheat<\/AssemblyName>/, '程序集名决定 DLL 文件名（必须是 AntiCheat）')
  assert.match(text, new RegExp(`<TargetFramework>${TFM}</TargetFramework>`), `目标框架决定 bin/Release/<tfm> 这一级目录名，必须是 ${TFM}`)

  // OutputPath 不能是 "."（= 构建直接写 plugin/）：
  // 那会让"构建直接写 plugin/AntiCheat.dll"与"打包器从 bin/Release/<tfm>/ 回拷"两条路径并存，
  // bin 里留着陈旧产物就会把刚构建好的 DLL 覆盖回去——本仓 qq-bind 实测踩过这个缺陷
  // （见 scripts/pack-plugin.mjs:204-230，以及 plugins/task-scheduler/test/pack-freshness.test.mjs:9-14）。
  assert.doesNotMatch(text, /<OutputPath>\s*\.\s*<\/OutputPath>/, 'OutputPath 不得为 "."：那会让构建产物与 bin 回拷两条路径并存，产生陈旧副本覆盖新构建')
  assert.match(
    text,
    /<OutputPath>bin\\\$\(Configuration\)\\<\/OutputPath>/,
    'OutputPath 必须是 bin\\$(Configuration)\\（产物落在 bin/Release/<tfm>/，再由打包器回拷到 plugin/）',
  )
})

test('D⑤ bin/Release/net9.0/AntiCheat.dll 与 plugin/AntiCheat.dll 逐字节相同（两者都在时）', { skip: (realDllExists && realBinDllExists) ? false : `缺少 plugin/${ASSEMBLY}.dll 或 bin/Release/${TFM}/${ASSEMBLY}.dll（尚未构建）：本用例未做任何验证` }, async () => {
  const shipped = await shaOf(path.join(realPluginSub, `${ASSEMBLY}.dll`))
  const built = await shaOf(path.join(realBinDir, TFM, `${ASSEMBLY}.dll`))
  assert.equal(
    shipped, built,
    `会被打包下发的 plugin/${ASSEMBLY}.dll 与构建产物 bin/Release/${TFM}/${ASSEMBLY}.dll 内容不一致：\n`
    + `  这是"陈旧副本覆盖新构建"的现场（本仓 qq-bind 实测踩过）。\n`
    + `  恢复：cd tsweb-cordis && node scripts/pack-plugin.mjs anti-cheat --rebuild，或删掉 plugin/bin、plugin/obj 后重试。`,
  )
})

test('D⑥ plugin/ 下 8 个 .cs 源文件都在 plugin/ 直接层，obj/bin 里的自动生成 .cs 不被算作源码', async () => {
  const entries = await readdir(realPluginSub, { withFileTypes: true })
  const direct = entries.filter((e) => e.isFile() && e.name.endsWith('.cs')).map((e) => e.name).sort()
  assert.equal(
    direct.length, 8,
    `本插件的 C# 源码是 8 个 .cs 文件（plugin/ 的直接子文件）：实际得到 ${direct.length} 个 —— ${direct.join('、')}`,
  )
  assert.ok(direct.includes('AntiCheat.cs'), '入口 AntiCheat.cs 必须在列')
  assert.ok(direct.includes('AntiCheatPlugin.cs'), '插件主类 AntiCheatPlugin.cs 必须在列')
  assert.equal(
    direct.includes(`${ASSEMBLY}.AssemblyInfo.cs`), false,
    `${ASSEMBLY}.AssemblyInfo.cs 是 obj/ 里的构建中间产物，绝不能被当作源码统计`,
  )

  // 递归列出 plugin/ 下所有 .cs（含 bin/obj），确认"多出来的那些"全部在 bin/ 或 obj/ 里：
  // 若源码藏在某个子目录里，本节结论（"8 个源文件"）就会漏掉它。
  const all = []
  const walk = async (dir, rel) => {
    for (const e of await readdir(dir, { withFileTypes: true })) {
      const r = rel ? `${rel}/${e.name}` : e.name
      if (e.isDirectory()) { await walk(path.join(dir, e.name), r); continue }
      if (e.name.endsWith('.cs')) all.push(r)
    }
  }
  await walk(realPluginSub, '')
  const outsideBuildDirs = all.filter((r) => !r.startsWith('bin/') && !r.startsWith('obj/')).sort()
  assert.deepEqual(outsideBuildDirs, direct, '除 bin/obj 外，plugin/ 下的 .cs 应当正好是那 8 个源文件（源码不得藏在子目录里）')

  const inObj = all.filter((r) => r.startsWith('obj/'))
  if (inObj.length > 0) {
    assert.ok(
      inObj.some((r) => r.endsWith(`${ASSEMBLY}.AssemblyInfo.cs`)),
      `obj/ 下应当有 SDK 自动生成的 ${ASSEMBLY}.AssemblyInfo.cs（它正是"不能被算作源码"的那类文件）`,
    )
  }

  // csproj 必须让 SDK 的默认 Compile 通配把 8 个 .cs 全部纳入编译：
  // 关掉默认项（EnableDefaultCompileItems=false）或 <Compile Remove> 掉某个文件，都会让"源码在，但没被编译"
  // ——那正是"下发的 DLL 里缺代码"的另一条产生路径。
  const csprojText = await readFile(path.join(realPluginSub, `${ASSEMBLY}.csproj`), 'utf8')
  assert.doesNotMatch(
    csprojText, /<EnableDefaultCompileItems>\s*false\s*<\/EnableDefaultCompileItems>/,
    '关掉默认 Compile 项会让 8 个 .cs 一个都不被编译，而本 csproj 里没有任何显式 <Compile Include>',
  )
  assert.doesNotMatch(csprojText, /<Compile\s+Remove=/, '不允许用 <Compile Remove> 排除源码：8 个源文件必须全部参与编译')
})
