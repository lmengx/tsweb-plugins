/**
 * 反作弊（anti-cheat）检测日志层 —— `logs.js` + 对外日志服务契约测试
 *
 * ══════════ 为什么需要这个文件 ══════════
 * `logs.js` 是"反作弊日志"这一页的全部宿主侧逻辑，而它有三个**极易静默出错**的地方：
 *   1. **时间区间归一**（logs.js:132-147）：旧版是字符串比较，前端只给日期时
 *      `time <= "2026-01-01"` 会让**当天所有记录被整段排除**（看着像"今天没抓到人"）。
 *   2. **精确 vs 近似**：指定单台服是精确的（分页/排序/总数都由该服 SQL 给），全部服务器是
 *      scatter-gather **近似**分页。界面若不标注就会把"少显示几条"读成"就这么多"。
 *      本文件把 `approximate` / `orderBasis` / `note` 这些"如实标注"逐条钉住。
 *   3. **逐服失败可见**：多服聚合时某台服挂了，绝不能把结果当"没有日志"——
 *      本文件断言失败服在逐服明细里必须 ok:false + error + note 点名。
 * 另外两条是**对外承诺**（不许悄悄退化）：
 *   - `ctx.anticheatLog` 是给别的插件用的服务（`inject: ['anticheatLog']`），
 *     将来写 `category='particle'` 的粒子防线插件是**另一个插件**，所以"任何分类都原样透出"
 *     与"统计卡始终有 particle 位置"必须在测试里固定下来；
 *   - `record/query/stats` 必须与 `/api/anticheat/*` 路由**同一实现**（否则两条路会慢慢走岔）。
 *
 * ══════════ 本机限制（本文件验证不到什么）══════════
 *   - **没有 TShock / 没有游戏服进程**：假 gameOps（本文件的局部辅助）模拟 `GET /data/anticheat/logs`
 *     与 `/logs/stats` 的回包形状，"服端 SQL 真的怎么排序/分组"不在本文件范围内；
 *     真机上的 `ORDER BY Id DESC` 只按 C# 源码与假服端行为对齐。
 *   - **没有数据库**：日志行都是内存数组，不验证 sqlite/表结构/索引。
 *   - **没有浏览器**：`client/log.js` 那一页不在本文件范围内（近似分页该怎么标注由前端负责）。
 *   - **真实多 fiber 的 inject 时序无法验证**：本文件用真实 cordis `Context` 证明
 *     "`ctx.anticheatLog` 与 `ctx.get('anticheatLog')` 都能取到、且都是同一个服务实例"，
 *     这是"别的插件 inject 后能拿到"的**等价证据**，但不是真实多 fiber 的时序验证
 *     （那种验证要跑完整宿主）。
 *
 * 运行：`node test/logs.test.mjs`（**不要**用 `node test/`：本机沙箱不允许管道捕获子进程）
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { AntiCheatLogService, LOG_SERVICE_NAME, apply } from '../index.js'
import { normalizeTimeRange, queryLogStats, queryLogs } from '../logs.js'
import { makeFakeHost, makeGameHalf, waitFor } from './support/fake-host.mjs'

const SERVERS = [
  { raw: { id: 's1', name: '一服', host: '127.0.0.1', port: 7777, token: 't1', enabled: true } },
  { raw: { id: 's2', name: '二服', host: '127.0.0.1', port: 7778, token: 't2', enabled: true } },
]

let dir
let seq = 0
const disposers = []

/**
 * 局部辅助：剥掉源码注释（与 test/host-api.test.mjs 里的同名函数同一实现）。
 *
 * 为什么两个测试文件各留一份而不抽公共文件：共享夹具 `test/support/fake-host.mjs` 是**别人也在用**
 * 的文件（任务书明令不许改），而新增第三个共享文件又超出"只新建这两个测试文件"的边界，
 * 所以这里刻意重复一小段纯函数，代价是几十行，换来的是两个文件都能独立 `node test/x.test.mjs` 跑。
 *
 * 为什么必须剥注释：`logs.js` 的注释里**故意**写着"本模块不按 category 白名单过滤"
 * （logs.js:10、:105 附近），直接用 `includes` 断言"没有白名单"会被自己的说明文字顶回去。
 */
function stripComments(src) {
  let out = ''
  const stack = [{ type: 'code', brace: 0 }]
  let i = 0
  while (i < src.length) {
    const f = stack[stack.length - 1]
    const c = src[i]
    const two = src.slice(i, i + 2)
    if (f.type === 'code') {
      if (two === '//') {
        while (i < src.length && src[i] !== '\n') i += 1
        continue
      }
      if (two === '/*') {
        i += 2
        while (i < src.length && src.slice(i, i + 2) !== '*/') {
          if (src[i] === '\n') out += '\n'
          i += 1
        }
        i += 2
        continue
      }
      if (c === "'" || c === '"') {
        stack.push({ type: c === "'" ? 'sq' : 'dq' })
        out += c
        i += 1
        continue
      }
      if (c === '`') {
        stack.push({ type: 'tpl' })
        out += c
        i += 1
        continue
      }
      if (c === '{') {
        f.brace += 1
        out += c
        i += 1
        continue
      }
      if (c === '}') {
        if (f.brace === 0 && stack.length > 1) {
          stack.pop()
          out += c
          i += 1
          continue
        }
        f.brace -= 1
        out += c
        i += 1
        continue
      }
      out += c
      i += 1
      continue
    }
    if (f.type === 'sq' || f.type === 'dq') {
      if (c === '\\') {
        out += c + (src[i + 1] || '')
        i += 2
        continue
      }
      if ((f.type === 'sq' && c === "'") || (f.type === 'dq' && c === '"')) {
        stack.pop()
        out += c
        i += 1
        continue
      }
      out += c
      i += 1
      continue
    }
    if (c === '\\') {
      out += c + (src[i + 1] || '')
      i += 2
      continue
    }
    if (two === '${') {
      stack.push({ type: 'code', brace: 0 })
      out += two
      i += 2
      continue
    }
    if (c === '`') {
      stack.pop()
      out += c
      i += 1
      continue
    }
    out += c
    i += 1
  }
  return out
}

/**
 * 假 gameOps（`logs.js` 只依赖 `gameOps.logs` / `gameOps.logStats` 两个方法）。
 *
 * `list` 里每台服给 `{ rows, total, totalPages, recent, byCategory, byMethod, today }`；
 * `fail` 里给一个 Error（可带 `serverHalfMissing`）表示这台服查询失败。
 */
function makeOps({ list = {}, fail = {} } = {}) {
  const calls = []
  return {
    calls,
    async logs(server, query) {
      calls.push({ what: 'logs', serverId: String(server.id), query: { ...query } })
      const bad = fail[String(server.id)]
      if (bad) throw bad
      const e = list[String(server.id)] || {}
      const rows = e.rows || []
      return { rows, total: e.total === undefined ? rows.length : e.total, totalPages: e.totalPages === undefined ? 1 : e.totalPages }
    },
    async logStats(server, query) {
      calls.push({ what: 'stats', serverId: String(server.id), query: { ...query } })
      const bad = fail[String(server.id)]
      if (bad) throw bad
      const e = list[String(server.id)] || {}
      return {
        total: e.total || 0,
        today: e.today || 0,
        byCategory: e.byCategory || {},
        byMethod: e.byMethod || {},
        recent: e.recent || [],
      }
    },
  }
}

const halfMissing = (serverName) => Object.assign(new Error(`游戏服端未安装 AntiCheat.dll（${serverName}）`), { serverHalfMissing: true })

/** 装配一个真实插件实例（服务对外契约需要它；apply 的第二个参数关掉周期对账） */
async function boot({ servers = SERVERS } = {}) {
  seq += 1
  const dataDir = path.join(dir, `case-${seq}`)
  const gameHalf = makeGameHalf({ serverIds: servers.map((s) => s.raw.id) })
  const host = makeFakeHost({
    dataDir,
    servers,
    postFor: gameHalf.postFor.bind(gameHalf),
    fetchFor: gameHalf.fetchFor.bind(gameHalf),
  })
  const dispose = await apply(host.ctx, { push: { reconcileIntervalMs: 0 } })
  disposers.push(dispose)
  // 等"宿主启动对账"（index.js:204 的不 await 下发）落定，避免它与后续断言抢时序
  await waitFor(() => host.ctx.anticheatLog._svc.pushStatus.size >= servers.length, { label: '启动对账落定' })
  return { dataDir, host, gameHalf, dispose, svc: host.ctx.anticheatLog._svc }
}

after(async () => {
  for (const d of disposers) {
    try {
      d()
    } catch {
      // 清理异常不该掩盖测试结果
    }
  }
  if (dir) await rm(dir, { recursive: true, force: true })
})

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), 'anticheat-logs-'))
})

// ═══════════════════════ 1. normalizeTimeRange ═══════════════════════

test('normalizeTimeRange：只给日期时补齐时分秒（timeFrom 00:00:00 / timeTo 23:59:59），并标 expanded', () => {
  const r = normalizeTimeRange({ timeFrom: '2026-01-01', timeTo: '2026-01-01' })
  assert.equal(r.timeFrom, '2026-01-01 00:00:00')
  assert.equal(r.timeTo, '2026-01-01 23:59:59')
  assert.equal(r.expanded, true, '改写过区间就必须让界面知道（不许静默改语义）')
})

test('normalizeTimeRange：带时分秒的原样保留，expanded=false', () => {
  const r = normalizeTimeRange({ timeFrom: '2026-01-01 08:30:00', timeTo: '2026-01-01 18:00:00' })
  assert.equal(r.timeFrom, '2026-01-01 08:30:00')
  assert.equal(r.timeTo, '2026-01-01 18:00:00')
  assert.equal(r.expanded, false)
})

test('normalizeTimeRange：空值/缺字段不变为空串，非日期形态原样透传、不猜', () => {
  const empty = normalizeTimeRange({})
  assert.deepEqual(empty, { timeFrom: '', timeTo: '', expanded: false })
  assert.deepEqual(normalizeTimeRange({ timeFrom: null, timeTo: undefined }), { timeFrom: '', timeTo: '', expanded: false })
  // 只补"恰好是 YYYY-MM-DD"的形态；别的形态（斜杠日期、只有年份）不做猜测
  const odd = normalizeTimeRange({ timeFrom: '2026/01/01', timeTo: '2026-01' })
  assert.equal(odd.timeFrom, '2026/01/01')
  assert.equal(odd.timeTo, '2026-01')
  assert.equal(odd.expanded, false)
  // 前后空白要被 trim 掉（query 参数带空格是很常见的手滑）
  const trimmed = normalizeTimeRange({ timeFrom: '  2026-01-01  ', timeTo: ' 2026-01-01 ' })
  assert.equal(trimmed.timeFrom, '2026-01-01 00:00:00')
  assert.equal(trimmed.timeTo, '2026-01-01 23:59:59')
})

test('normalizeTimeRange：不补时分秒会让当天记录被整段排除（这条就是它存在的理由，自证一次）', () => {
  // 服端是**字符串比较**（旧 AntiCheatLog.cs:193-204 的口径，假服端 fake-host.mjs:348-349 同口径）：
  //   WHERE Time >= @tf AND Time <= @tt
  // 只给日期时 `"2026-01-01 09:00:00" <= "2026-01-01"` 为 false → 当天所有记录被排除。
  assert.equal('2026-01-01 09:00:00' <= '2026-01-01', false, '这正是"查今天什么都没有"的根因')
  assert.equal('2026-01-01 09:00:00' >= '2026-01-01', true, '下界反而"恰好"成立，所以症状只出现在 timeTo 一侧')
  // 补过之后必须成立
  const r = normalizeTimeRange({ timeFrom: '2026-01-01', timeTo: '2026-01-01' })
  assert.equal('2026-01-01 09:00:00' >= r.timeFrom, true)
  assert.equal('2026-01-01 09:00:00' <= r.timeTo, true)
})

// ═══════════════════════ 2. queryLogs：参数透传 ═══════════════════════

test('queryLogs：page/pageSize 先归一（page 最小 1、pageSize 钳制 [1,200]）再透传给服端', async () => {
  const ops = makeOps({ list: { s1: { rows: [], total: 0 } } })
  await queryLogs({ servers: [SERVERS[0].raw], gameOps: ops, query: { page: -3, pageSize: 99999 }, aggregate: false })
  assert.equal(ops.calls[0].query.page, 1)
  assert.equal(ops.calls[0].query.pageSize, 200)

  await queryLogs({ servers: [SERVERS[0].raw], gameOps: ops, query: { pageSize: -5 }, aggregate: false })
  assert.equal(ops.calls[1].query.pageSize, 1)

  // 0/非法视为"未指定" → 回落默认 50（与 task-scheduler 的 log 端点同一口径）
  await queryLogs({ servers: [SERVERS[0].raw], gameOps: ops, query: { pageSize: 0, page: 'abc' }, aggregate: false })
  assert.equal(ops.calls[2].query.pageSize, 50)
  assert.equal(ops.calls[2].query.page, 1)
})

test('queryLogs：timeFrom/timeTo 用归一后的值透传（服端不需要知道"补时分秒"这回事）', async () => {
  const ops = makeOps({ list: { s1: { rows: [], total: 0 } } })
  const out = await queryLogs({
    servers: [SERVERS[0].raw],
    gameOps: ops,
    query: { timeFrom: '2026-01-01', timeTo: '2026-01-02 03:00:00' },
    aggregate: false,
  })
  assert.equal(ops.calls[0].query.timeFrom, '2026-01-01 00:00:00')
  assert.equal(ops.calls[0].query.timeTo, '2026-01-02 03:00:00')
  assert.equal(ops.calls[0].query.page, 1, '没传 page 也要给服端一个明确的值（服端回落是另一层的兜底）')
  assert.equal(ops.calls[0].query.pageSize, 50)
  assert.deepEqual(out.range, { timeFrom: '2026-01-01 00:00:00', timeTo: '2026-01-02 03:00:00', expanded: true })
  // 其它筛选参数原样透传（不在这里做二次解释）
  const ops2 = makeOps({ list: { s1: { rows: [], total: 0 } } })
  await queryLogs({ servers: [SERVERS[0].raw], gameOps: ops2, query: { category: 'item', method: 'kick', player: '甲', q: '剑' }, aggregate: false })
  assert.equal(ops2.calls[0].query.category, 'item')
  assert.equal(ops2.calls[0].query.method, 'kick')
  assert.equal(ops2.calls[0].query.player, '甲')
  assert.equal(ops2.calls[0].query.q, '剑')
})

// ═══════════════════════ 3. queryLogs：单台服（精确）═══════════════════════

test('queryLogs：单台服要如实标注"精确"（approximate=false / orderBasis=Id / timeBasis=server-local）', async () => {
  const ops = makeOps({ list: { s1: { rows: [{ id: 7, time: '2026-01-01 10:00:00', category: 'item' }], total: 120, totalPages: 5 } } })
  const out = await queryLogs({ servers: [SERVERS[0].raw], gameOps: ops, query: { page: 2, pageSize: 25 }, aggregate: false })
  assert.equal(out.approximate, false)
  assert.equal(out.orderBasis, 'Id', '单台服的顺序依据是服端自己的 ORDER BY Id DESC')
  assert.equal(out.timeBasis, 'server-local', 'Time 列是游戏服本地时间，宿主不臆造时区转换')
  assert.equal(out.total, 120, '总数直接来自服端')
  assert.equal(out.totalPages, 5, '总页数必须原样来自服端，而不是宿主自己算')
  assert.equal(out.page, 2)
  assert.equal(out.pageSize, 25)
  assert.equal(out.error, '')
  assert.equal(out.servers.length, 1)
  assert.deepEqual(out.servers[0], { id: 's1', name: '一服', ok: true, rows: 1, total: 120, totalPages: 5, error: '' })
  assert.equal(ops.calls.length, 1)
  assert.equal(ops.calls[0].query.page, 2)
})

test('queryLogs：单台服必须原样保留服端给出的顺序（本层不重排；见报告 D-C）', async () => {
  // 判别性夹具：服端 SQL 是 ORDER BY Id DESC（id 9 更新），而 time 列被手工回填成"更旧"，
  // 于是"按 Id 排序"与"按 time 排序"给出不同结果 —— 只有这样的夹具才能判别宿主有没有擅自重排。
  // （时钟回拨、历史数据补录都会造成这种形态，不是人为构造的极端情况。）
  const ops = makeOps({
    list: {
      s1: {
        rows: [
          { id: 9, time: '2026-01-01 10:00:00', category: 'item', method: 'log' },
          { id: 3, time: '2026-06-01 10:00:00', category: 'item', method: 'log' },
        ],
        total: 2,
        totalPages: 1,
      },
    },
  })
  const out = await queryLogs({ servers: [SERVERS[0].raw], gameOps: ops, query: {}, aggregate: false })
  assert.equal(out.orderBasis, 'Id')
  assert.deepEqual(
    out.rows.map((r) => r.id),
    [9, 3],
    'orderBasis 声明的是 Id，本层就不得再按 time 重排（当前实现返回的是 sortRows(merged)，见报告 D-C）',
  )
})

// ═══════════════════════ 4. queryLogs：多台服聚合（近似）═══════════════════════

test('queryLogs：多台服按 time 归并（相同 time 按 id 降序）、slice(0,pageSize)、totalPages 按求和估算、note 标注近似', async () => {
  const ops = makeOps({
    list: {
      s1: { rows: [{ id: 5, time: '2026-01-02 10:00:00', category: 'item' }, { id: 2, time: '2026-01-01 10:00:00', category: 'item' }], total: 25, totalPages: 1 },
      s2: { rows: [{ id: 4, time: '2026-01-03 10:00:00', category: 'item' }, { id: 9, time: '2026-01-01 10:00:00', category: 'item' }], total: 40, totalPages: 2 },
    },
  })
  const out = await queryLogs({ servers: SERVERS.map((s) => s.raw), gameOps: ops, query: { pageSize: 3 }, aggregate: true })
  assert.equal(out.approximate, true, '聚合分页是近似的，必须标注')
  assert.equal(out.orderBasis, 'time-merge')
  assert.equal(out.timeBasis, 'server-local')
  // 归并顺序：01-03 → 01-02 → （01-01 两条同 time，按 id 降序：9 在 2 前）
  assert.deepEqual(out.rows.map((r) => [r.serverId, r.id]), [['s2', 4], ['s1', 5], ['s2', 9]])
  assert.equal(out.rows.length, 3, '合并后必须截断到 pageSize（本例合并出 4 条）')
  assert.equal(out.total, 65, 'total 是逐服 total 求和（精确）')
  assert.equal(out.totalPages, 22, '聚合模式下 totalPages 按求和总数估算（ceil(65/3)）')
  assert.equal(out.page, 1)
  assert.equal(out.pageSize, 3)
  assert.ok(out.note.includes('已合并 2 台'), out.note)
  assert.ok(out.note.includes('近似'), out.note)
  assert.equal(out.servers.length, 2)
  assert.equal(ops.calls.length, 2, '两台启用服各查一次')
})

test('queryLogs：聚合模式下每台服拿到的是同一个 offset（scatter-gather 的固有局限，如实记录）', async () => {
  const ops = makeOps({ list: { s1: { rows: [], total: 0 }, s2: { rows: [], total: 0 } } })
  await queryLogs({ servers: SERVERS.map((s) => s.raw), gameOps: ops, query: { page: 3, pageSize: 10 }, aggregate: true })
  assert.equal(ops.calls.length, 2)
  for (const c of ops.calls) {
    assert.equal(c.query.page, 3)
    assert.equal(c.query.pageSize, 10)
  }
})

// ═══════════════════════ 5. queryLogs：逐服失败可见 ═══════════════════════

test('queryLogs：一台成功一台失败 → 失败服在逐服明细里 ok:false + error + serverHalfMissing，note 点名且说明总数不含它们', async () => {
  const ops = makeOps({
    list: { s1: { rows: [{ id: 1, time: '2026-01-01 10:00:00', category: 'item' }], total: 7, totalPages: 1 } },
    fail: { s2: halfMissing('二服') },
  })
  const out = await queryLogs({ servers: SERVERS.map((s) => s.raw), gameOps: ops, query: {}, aggregate: true })
  // 注意键名：列表接口用的是 `servers`（logs.js:219/:238），统计接口用的才是 `perServer`（logs.js:304）
  assert.equal(out.servers.length, 2)
  const bad = out.servers.find((s) => s.id === 's2')
  const good = out.servers.find((s) => s.id === 's1')
  assert.equal(bad.ok, false)
  assert.equal(bad.serverHalfMissing, true)
  assert.ok(bad.error.includes('AntiCheat.dll'), bad.error)
  assert.equal(bad.rows, 0)
  assert.equal(bad.total, 0)
  assert.equal(bad.totalPages, 0)
  assert.deepEqual(good, { id: 's1', name: '一服', ok: true, rows: 1, total: 7, totalPages: 1, error: '' })
  // 总数字必然偏小 → 必须把事实说出来，绝不当作"没有日志"
  assert.equal(out.total, 7)
  assert.ok(out.note.includes('二服'), out.note)
  assert.ok(out.note.includes('不含它们'), out.note)
  assert.equal(out.rows.length, 1, '成功那台的日志照常返回')
  assert.equal(out.rows[0].serverId, 's1')
})

test('queryLogs：唯一一台服查询失败 → error 非空、不假装成功（旧版把错误包在 200 里就是这种坑）', async () => {
  const ops = makeOps({ fail: { s2: halfMissing('二服') } })
  const out = await queryLogs({ servers: [SERVERS[1].raw], gameOps: ops, query: {}, aggregate: false })
  assert.equal(out.rows.length, 0)
  assert.equal(out.total, 0)
  assert.equal(out.totalPages, 0)
  assert.equal(out.approximate, false)
  assert.ok(out.error.includes('AntiCheat.dll'), out.error)
  assert.equal(out.servers[0].ok, false)
  assert.equal(out.servers[0].serverHalfMissing, true)
})

// ═══════════════════════ 6. ID→名称兜底与字段归一 ═══════════════════════

test('queryLogs：服端没有物品名时用 itemData 兜底，itemNameSource=dictionary；服端有名字则用 log 且不覆盖', async () => {
  let itemCalls = 0
  let projCalls = 0
  const itemData = {
    async nameOf(id) {
      itemCalls += 1
      return Number(id) === 267 ? '可疑物品' : null
    },
  }
  const projectileData = {
    async nameOf(id) {
      projCalls += 1
      return Number(id) === 108 ? '可疑弹幕' : null
    },
  }
  const ops = makeOps({
    list: {
      s1: {
        rows: [
          { id: 1, time: '2026-01-01 10:00:00', category: 'item', itemId: 267, itemName: '' },
          { id: 2, time: '2026-01-01 11:00:00', category: 'item', itemId: 267, itemName: '' },
          { id: 3, time: '2026-01-01 12:00:00', category: 'item', itemId: 267, itemName: '服端落库的名字' },
          { id: 4, time: '2026-01-01 13:00:00', category: 'proj', itemId: 0, itemName: '', projId: 108 },
          { id: 5, time: '2026-01-01 14:00:00', category: 'item', itemId: 999, itemName: '' },
        ],
        total: 5,
        totalPages: 1,
      },
    },
  })
  const out = await queryLogs({ servers: [SERVERS[0].raw], gameOps: ops, query: {}, itemData, projectileData, aggregate: false })
  const byId = new Map(out.rows.map((r) => [r.id, r]))
  assert.equal(byId.get(2).itemName, '可疑物品', '服端 itemName 为空 → 用字典兜底')
  assert.equal(byId.get(2).itemNameSource, 'dictionary')
  assert.equal(byId.get(3).itemName, '服端落库的名字')
  assert.equal(byId.get(3).itemNameSource, 'log', '服端已有名字时来源必须是 log')
  assert.equal(byId.get(4).projName, '可疑弹幕', '弹幕侧没有名称列，只能靠 projectileData')
  assert.equal(byId.get(4).projNameSource, 'dictionary')
  assert.equal(byId.get(4).itemName, '', '该项 itemId=0，不该去查物品字典')
  assert.equal(byId.get(5).itemName, '', '字典查不到 → 留空，由前端显示 "ID: n"')
  assert.equal(byId.get(5).itemNameSource, '')
  // 缓存：id=267 出现两次（一行服端有名字，两行没有）→ 只查一次；字典查不到也要缓存，不再重复查
  assert.equal(itemCalls, 2, 'id 267 查一次、999 查一次（同一 id 第二次必须命中缓存）')
  assert.equal(projCalls, 1)
})

test('queryLogs：itemData 缺失或 nameOf 抛错都不能让日志页整体失败（名称留空即可）', async () => {
  const rows = [
    { id: 1, time: '2026-01-01 10:00:00', category: 'item', itemId: 267, itemName: '' },
    { id: 2, time: '2026-01-01 11:00:00', category: 'proj', itemId: 0, projId: 108 },
  ]
  // ① 完全没有字典服务（软依赖没装）
  const noDict = await queryLogs({ servers: [SERVERS[0].raw], gameOps: makeOps({ list: { s1: { rows, total: 2 } } }), query: {}, aggregate: false })
  assert.equal(noDict.rows.length, 2)
  for (const r of noDict.rows) {
    assert.equal(r.itemName, '')
    assert.equal(r.itemNameSource, '')
    assert.equal(r.projName, '')
    assert.equal(r.projNameSource, '')
  }
  // ② 字典存在但查询抛错（字典文件损坏/服务初始化中途）
  const boom = { async nameOf() { throw new Error('字典坏了') } }
  const threw = await queryLogs({
    servers: [SERVERS[0].raw],
    gameOps: makeOps({ list: { s1: { rows, total: 2 } } }),
    query: {},
    itemData: boom,
    projectileData: boom,
    aggregate: false,
  })
  assert.equal(threw.rows.length, 2, '字典抛错不得让整个查询失败')
  for (const r of threw.rows) {
    assert.equal(r.itemName, '')
    assert.equal(r.itemNameSource, '')
    assert.equal(r.projName, '')
  }
})

test('queryLogs：行字段归一（缺字段给 "" / 0，serverId/serverName 来自服务器记录）', async () => {
  const ops = makeOps({
    list: {
      s9: {
        rows: [{}, { id: '7', category: 'proj', time: null, itemId: '267', playerId: 'x' }],
        total: 2,
        totalPages: 1,
      },
    },
  })
  const server = { id: 's9', name: '九服', enabled: true }
  const out = await queryLogs({ servers: [server], gameOps: ops, query: {}, itemData: { async nameOf() { return '字典名' } }, aggregate: false })
  const empty = out.rows.find((r) => r.id === 0)
  assert.deepEqual(empty, {
    id: 0,
    time: '',
    playerName: '',
    playerId: 0,
    category: '',
    itemId: 0,
    itemName: '',
    itemNameSource: '',
    projId: 0,
    projName: '',
    projNameSource: '',
    method: '',
    detail: '',
    worldId: '',
    serverId: 's9',
    serverName: '九服',
  })
  const partial = out.rows.find((r) => r.id === 7)
  assert.equal(partial.category, 'proj')
  assert.equal(partial.itemId, 267, '字符串形态的 id 要被归一成数字')
  assert.equal(partial.playerId, 0, '脏 playerId 给 0 而不是 NaN')
  assert.equal(partial.time, '', 'time 为 null 时给空串')
  assert.equal(partial.itemName, '字典名', 'itemId 有效时照常兜底')
  assert.equal(partial.serverName, '九服')
})

// ═══════════════════════ 7. queryLogStats ═══════════════════════

test('queryLogStats：逐服求和（total/today/byCategory/byMethod），recent 归并后取前 10 且标注近似', async () => {
  const mk = (n, base, idBase) => Array.from({ length: n }, (_, i) => ({
    id: idBase + i,
    time: `2026-01-0${(i % 9) + 1} 10:00:00`,
    category: 'item',
  }))
  const ops = makeOps({
    list: {
      s1: { total: 10, today: 1, byCategory: { item: 4, proj: 6 }, byMethod: { log: 10 }, recent: mk(12, 0, 100) },
      s2: { total: 20, today: 2, byCategory: { item: 1, particle: 19 }, byMethod: { log: 20 }, recent: mk(12, 0, 200) },
    },
  })
  const out = await queryLogStats({ servers: SERVERS.map((s) => s.raw), gameOps: ops, query: {} })
  assert.equal(out.total, 30, 'total 是逐服精确求和')
  assert.equal(out.today, 3)
  assert.deepEqual(out.byCategory, { item: 5, proj: 6, particle: 19 }, '同分类要相加，不同分类要保留')
  assert.deepEqual(out.byMethod, { log: 30 })
  assert.equal(out.recent.length, 10, 'recent 归并后取前 10（旧版单库同样是 LIMIT 10）')
  assert.equal(out.approximateRecent, true, '多台服的 recent 是近似，必须标注')
  assert.equal(out.scope, 'all-servers')
  assert.equal(out.filtered, false, '没有任何筛选参数时 filtered=false')
  assert.equal(out.timeBasis, 'server-local')
  assert.equal(out.perServer.length, 2)
  assert.deepEqual(out.perServer.map((s) => [s.id, s.ok, s.total, s.today]), [['s1', true, 10, 1], ['s2', true, 20, 2]])
  // recent 的每一行都要带 serverId，否则界面上分不清是哪台服的命中
  assert.ok(out.recent.every((r) => r.serverId === 's1' || r.serverId === 's2'))
})

test('queryLogStats：filtered 只由"真筛选参数"决定（page/pageSize 不算），scope 随台数变化', async () => {
  const ops = makeOps({ list: { s1: { total: 1, today: 1, byCategory: {}, byMethod: {}, recent: [] } } })
  const bare = await queryLogStats({ servers: [SERVERS[0].raw], gameOps: ops, query: { page: 3, pageSize: 10 } })
  assert.equal(bare.filtered, false, '翻页不是筛选（统计卡不该因此标注"已筛选"）')
  assert.equal(bare.scope, 'single-server')
  assert.equal(bare.approximateRecent, false, '单台服的 recent 是精确的')

  for (const q of [{ category: 'item' }, { method: 'kick' }, { player: '甲' }, { q: '剑' }, { timeFrom: '2026-01-01' }, { timeTo: '2026-01-01' }]) {
    const out = await queryLogStats({ servers: [SERVERS[0].raw], gameOps: ops, query: q })
    assert.equal(out.filtered, true, `${JSON.stringify(q)} 应让 filtered=true（旧版 D-25：统计不跟随筛选）`)
  }
  // 筛选参数必须真的透传给服端（否则"联动"只是文案）
  assert.equal(ops.calls.at(-1).query.timeTo, '2026-01-01 23:59:59')
})

test('queryLogStats：失败服在 perServer 里 ok:false + note 点名，且明说数字不含它们', async () => {
  const ops = makeOps({
    list: { s1: { total: 5, today: 2, byCategory: { item: 5 }, byMethod: { log: 5 }, recent: [{ id: 1, time: '2026-01-01 10:00:00', category: 'item' }] } },
    fail: { s2: halfMissing('二服') },
  })
  const out = await queryLogStats({ servers: SERVERS.map((s) => s.raw), gameOps: ops, query: {} })
  assert.equal(out.total, 5)
  assert.equal(out.today, 2)
  const bad = out.perServer.find((s) => s.id === 's2')
  assert.equal(bad.ok, false)
  assert.equal(bad.serverHalfMissing, true)
  assert.equal(bad.total, 0)
  assert.equal(bad.today, 0)
  assert.ok(bad.error.includes('AntiCheat.dll'), bad.error)
  assert.ok(out.note.includes('二服'), out.note)
  assert.ok(out.note.includes('不含它们'), out.note)
  assert.equal(out.error, '')
})

// ═══════════════════════ 8. 日志服务对外契约（不许私有化）═══════════════════════

test('源码断言（剥注释）：AntiCheatLogService 的 record/query/stats 只是转调内部实现，与路由同一实现', async () => {
  const code = stripComments(await readFile(new URL('../index.js', import.meta.url), 'utf8'))
  // 服务不是"第二份实现"：它把调用转给 AntiCheatService 的同名能力（index.js:119-131），
  // 而路由也是调这几个方法（index.js:816、840）——两条路必须永远同源。
  assert.ok(code.includes('return this._svc.record(serverId, entry)'), 'record 必须转调内部实现')
  assert.ok(code.includes('return this._svc.queryLogs(query)'), 'query 必须转调 queryLogs（与 /logs 路由同一实现）')
  assert.ok(code.includes('return this._svc.queryLogStats(query)'), 'stats 必须转调 queryLogStats（与 /logs/stats 同一实现）')
  // 服务名是模块常量，别处（文档/其它插件）都引它
  assert.ok(code.includes("export const LOG_SERVICE_NAME = 'anticheatLog'"))
})

test('源码断言（剥注释）：logs.js 不做 category 白名单过滤（任何分类都原样透出）', async () => {
  const code = stripComments(await readFile(new URL('../logs.js', import.meta.url), 'utf8'))
  // 这条挡的是什么：旧 AntiCheatLog.cs:15 自述这张表同时承载
  // 「物品违禁 / 弹幕违禁 / 粒子恶意 / 粒子超频丢弃」，将来的粒子防线插件是**另一个插件**。
  // 一旦宿主在这里写死 `category` 只允许 item/proj，粒子日志就会静默消失
  // （写入端还在写、查询端永远查不到，这类"半边失联"最难排查）。
  assert.equal(
    /category\s*(===|==|!==|!=)\s*['"](item|proj)['"]/.test(code),
    false,
    'logs.js 不得把 category 与 item/proj 做等值判定（那就是白名单）',
  )
  assert.equal(
    /\[\s*['"]item['"]\s*,\s*['"]proj['"]\s*\]/.test(code),
    false,
    'logs.js 不得出现 [item, proj] 形态的分类白名单常量',
  )
  assert.equal(
    code.includes('CATEGORIES'),
    false,
    'logs.js 不得定义分类闭集（分类是开放的：particle 以及将来的新分类都要能透出）',
  )
  // 正向对照：category 确实被读取并且只做字符串归一（不是被过滤掉）
  assert.ok(code.includes("const category = String(r.category ?? '')"), 'category 应只做读取与归一')
})

test('日志服务：LOG_SERVICE_NAME 与 ctx.anticheatLog / ctx.get("anticheatLog") 都能取到，且是同一实现', async () => {
  const { host, dispose } = await boot({ servers: [SERVERS[0]] })
  try {
    assert.equal(LOG_SERVICE_NAME, 'anticheatLog')
    const direct = host.ctx.anticheatLog
    const fetched = host.ctx.get('anticheatLog')
    // 假宿主用的是真实 cordis Context（fake-host.mjs:29-39），所以"两者都能取到"就是
    // "别的插件 inject: ['anticheatLog'] 后能拿到"的等价证据（真实多 fiber 时序本机测不了）。
    assert.ok(direct, 'ctx.anticheatLog 必须存在（服务不许私有化）')
    assert.ok(fetched, 'ctx.get("anticheatLog") 必须能取到')
    assert.ok(direct instanceof AntiCheatLogService, 'ctx.anticheatLog 必须是 AntiCheatLogService 实例')
    assert.ok(fetched instanceof AntiCheatLogService, 'ctx.get 取到的也必须是 AntiCheatLogService 实例')
    assert.equal(direct.name, LOG_SERVICE_NAME)
    assert.equal(fetched.name, LOG_SERVICE_NAME)
    // 两者是同一个底层实现（cordis 按 fiber 包了一层访问代理，所以对象本身可能不是同一个引用，
    // 但 _svc 必须是同一个 AntiCheatService —— 否则两条路会各自持一份状态）
    assert.equal(direct._svc, fetched._svc, '两个入口必须指向同一个底层实现')
    for (const fn of ['record', 'query', 'stats']) {
      assert.equal(typeof direct[fn], 'function', `服务应提供 ${fn}()`)
      assert.equal(typeof fetched[fn], 'function')
    }
  } finally {
    dispose()
  }
})

test('日志服务 record()：走 POST /data/anticheat/log，参数恰好 8 个键，回 {serverId, serverName, recorded, id}', async () => {
  const { host, gameHalf, dispose } = await boot({ servers: [SERVERS[0]] })
  try {
    const out = await host.ctx.anticheatLog.record('s1', {
      category: 'particle',
      method: 'drop',
      detail: '粒子超频丢弃',
      playerName: '玩家P',
      playerId: 7,
      itemId: 267,
      itemName: '可疑物品',
      projId: 108,
    })
    assert.deepEqual(out, { serverId: 's1', serverName: '一服', recorded: true, id: 1 })
    const call = host.calls.filter((c) => c.pathname === '/data/anticheat/log').at(-1)
    assert.ok(call, '必须真的调到服端')
    assert.equal(call.via, 'postFor', '写入走 POST + form body（detail 可能很长，不该进 URL）')
    assert.equal(call.serverId, 's1')
    assert.deepEqual(
      Object.keys(call.params).sort(),
      ['category', 'detail', 'itemId', 'itemName', 'method', 'playerId', 'playerName', 'projId'],
      '参数键必须与服端端点逐字对齐',
    )
    assert.equal(call.params.category, 'particle')
    assert.equal(call.params.method, 'drop')
    assert.equal(call.params.detail, '粒子超频丢弃')
    assert.equal(call.params.playerId, '7')
    assert.equal(call.params.itemId, '267')
    assert.equal(call.params.projId, '108')
    assert.equal(gameHalf.recordCalls.length, 1)
  } finally {
    dispose()
  }
})

test('日志服务 record()：目标服务器不存在或未启用 → 抛错且 err.status=404（不是静默丢弃）', async () => {
  const { host, dispose } = await boot({ servers: [SERVERS[0]] })
  try {
    await assert.rejects(
      () => host.ctx.anticheatLog.record('nope', { category: 'particle', method: 'drop' }),
      (err) => {
        assert.equal(err.status, 404)
        assert.ok(err.message.includes('不存在或未启用'), err.message)
        return true
      },
    )
    // 未启用的服同样不可写
    host.setRaw('s1', { enabled: false })
    await assert.rejects(
      () => host.ctx.anticheatLog.record('s1', { category: 'particle', method: 'drop' }),
      (err) => err.status === 404,
    )
    assert.equal(host.calls.filter((c) => c.pathname === '/data/anticheat/log').length, 0, '被拒的写入不该打到服端')
  } finally {
    dispose()
  }
})

test('particle 分类与统计卡始终可用：能落库、能按 category=particle 查到、统计里必须有它', async () => {
  const { host, gameHalf, dispose } = await boot({ servers: [SERVERS[0]] })
  try {
    const svc = host.ctx.anticheatLog
    // 模拟"将来的粒子防线插件"：它不引用 AntiCheat.dll，也不认识 item/proj 两分类
    await svc.record('s1', { category: 'particle', method: 'drop', detail: '粒子恶意：超频丢弃' })
    await svc.record('s1', { category: 'particle', method: 'log', detail: '粒子超频' })
    await svc.record('s1', { category: 'item', method: 'ban', detail: '物品违禁', itemId: 267 })

    const q = await svc.query({ category: 'particle' })
    assert.equal(q.total, 2, 'particle 分类必须能查到')
    assert.ok(q.rows.every((r) => r.category === 'particle'), JSON.stringify(q.rows))
    assert.equal(q.rows[0].serverId, 's1')
    assert.equal(q.rows[0].serverName, '一服')
    assert.ok(q.rows.some((r) => r.detail === '粒子恶意：超频丢弃'))

    const all = await svc.query({})
    assert.equal(all.total, 3, '不筛分类时三类都在（宿主持有全部日志，不按分类过滤）')

    const st = await svc.stats({})
    assert.ok(st.byCategory.particle >= 1, `统计卡必须保留 particle 位置：${JSON.stringify(st.byCategory)}`)
    assert.equal(st.byCategory.particle, 2)
    assert.equal(st.byCategory.item, 1)
    assert.equal(st.total, 3)
    assert.equal(st.today, 3)
    assert.ok(Array.isArray(st.recent) && st.recent.length >= 1)
    assert.equal(st.scope, 'single-server')
    assert.equal(st.perServer[0].ok, true)
    // 服端确实收到了这三次写入（不是宿主自己内存里骗自己）
    assert.equal(gameHalf.logs.get('s1').filter((r) => r.category === 'particle').length, 2)
  } finally {
    dispose()
  }
})

test('日志服务 stats()：形状稳定（数字/对象/数组），空库也要给得出统计卡', async () => {
  const { host, dispose } = await boot({ servers: [SERVERS[0]] })
  try {
    const st = await host.ctx.anticheatLog.stats({})
    assert.equal(typeof st.total, 'number')
    assert.equal(typeof st.today, 'number')
    assert.equal(st.total, 0)
    assert.equal(st.today, 0)
    assert.equal(typeof st.byCategory, 'object')
    assert.equal(Array.isArray(st.byCategory), false)
    assert.deepEqual(st.byCategory, {})
    assert.deepEqual(st.byMethod, {})
    assert.ok(Array.isArray(st.recent))
    assert.deepEqual(st.recent, [])
    assert.equal(st.filtered, false)
    assert.equal(st.scope, 'single-server')
    assert.ok(Array.isArray(st.perServer))
    assert.equal(st.perServer[0].ok, true)
    assert.equal(st.perServer[0].total, 0)
    assert.equal(st.error, '')
  } finally {
    dispose()
  }
})

// ═══════════════════════ 9. resolveLogTargets ═══════════════════════

test('resolveLogTargets：零台启用服 → error 非空且不给任何目标', async () => {
  const { svc, dispose } = await boot({ servers: [] })
  try {
    const r = await svc.resolveLogTargets({})
    assert.deepEqual(r.servers, [])
    assert.equal(r.aggregate, false)
    assert.ok(r.error.includes('没有启用中的服务器'), r.error)
    // 查询与统计都要如实回这个错误，而不是回一个"空列表当成功"
    const q = await svc.queryLogs({})
    assert.equal(q.total, 0)
    assert.ok(q.error.includes('没有启用中的服务器'), q.error)
    const s = await svc.queryLogStats({})
    assert.equal(s.total, 0)
    assert.ok(s.error.includes('没有启用中的服务器'), s.error)
    assert.deepEqual(s.perServer, [])
  } finally {
    dispose()
  }
})

test('resolveLogTargets：单台启用服 → 用它且 aggregate=false（精确模式）', async () => {
  const { svc, dispose } = await boot({ servers: [SERVERS[0]] })
  try {
    const r = await svc.resolveLogTargets({})
    assert.equal(r.servers.length, 1)
    assert.equal(String(r.servers[0].id), 's1')
    assert.equal(r.aggregate, false)
    assert.equal(r.error, '')
    // 单台时即使显式指定同一台，也仍然是精确模式
    const one = await svc.resolveLogTargets({ serverId: 's1', aggregate: true })
    assert.equal(one.servers.length, 1)
    assert.equal(one.aggregate, false, '指定了单台就不是聚合模式')
    assert.equal(one.error, '')
  } finally {
    dispose()
  }
})

test('resolveLogTargets：多台未指定 → 全部启用服；aggregate 由入参决定（路由会显式传解析结果）', async () => {
  const { svc, dispose } = await boot()
  try {
    const agg = await svc.resolveLogTargets({ aggregate: true })
    assert.equal(agg.servers.length, 2)
    assert.equal(agg.aggregate, true)
    assert.deepEqual(agg.servers.map((s) => String(s.id)).sort(), ['s1', 's2'])
    assert.equal(agg.error, '')
    // 不传 aggregate 时按签名默认 false（index.js:559 的默认值）；真正"是否聚合"的判定
    // 落点在 logs.js:207（servers.length === 1 才精确），所以调用方必须显式传，路由确实这么做了。
    const dflt = await svc.resolveLogTargets({})
    assert.equal(dflt.servers.length, 2)
    assert.equal(dflt.aggregate, false)
    // 指定其中一台 → 精确模式
    const one = await svc.resolveLogTargets({ serverId: 's2', aggregate: true })
    assert.deepEqual(one.servers.map((s) => String(s.id)), ['s2'])
    assert.equal(one.aggregate, false)
  } finally {
    dispose()
  }
})

test('resolveLogTargets：指定不存在或已停用的 serverId → error 含「不存在或未启用」', async () => {
  const { host, svc, dispose } = await boot()
  try {
    const nope = await svc.resolveLogTargets({ serverId: 'nope' })
    assert.deepEqual(nope.servers, [])
    assert.ok(nope.error.includes('不存在或未启用'), nope.error)
    assert.ok(nope.error.includes('nope'), nope.error)

    host.setRaw('s2', { enabled: false })
    const disabled = await svc.resolveLogTargets({ serverId: 's2' })
    assert.deepEqual(disabled.servers, [])
    assert.ok(disabled.error.includes('不存在或未启用'), disabled.error)

    // 停用一台之后，剩下的只有一台 → 精确模式
    const rest = await svc.resolveLogTargets({})
    assert.equal(rest.servers.length, 1)
    assert.equal(rest.aggregate, false)
  } finally {
    dispose()
  }
})
