/**
 * 默认违禁清单的迁移差异断言（**防日后静默改数据**）
 *
 * ══════════ 为什么必须有这个文件 ══════════
 * `plugins/anti-cheat/resources/{物品违禁,弹幕违禁}.json` 是**唯一权威默认清单**：
 * 管理员在界面上点「应用默认配置」时，整份清单会被它替换（defaults.js:258-267）。
 * 也就是说这两份 JSON 是**会真的改变线上行为**的数据（会踢人、会封人、会执行自定义命令），
 * 而它们又是从旧版逐条移植来的——移植过程里只要有一条 `method` 从 `log` 变成 `ban`，
 * 或者某个高进度档的条目悄悄消失，界面上**完全看不出来**，下一次「应用默认配置」就出事。
 *
 * 所以这里以**旧版权威文件**为基准做差异断言：
 *   `C:\Users\lyt\Documents\GitHub\TsWeb\TsWeb\backend\resources\默认配置\{物品违禁,弹幕违禁}.json`
 *   （旧后端 `anticheatDefaults.js` 读取下发的就是这两份；实测 **物品 19 档/119 条、弹幕 11 档/53 条**）
 *
 * 判定规则（**除声明外的任何差异都必须让测试失败**，逐条对应任务书的三点要求）：
 *   ① 旧版每一条 `id/stack/method`（物品侧）或 `id/method`（弹幕侧）**一条不少**；
 *   ② 相对旧版的差异**只能是** `defaults.js` 的 `APPLIED_DATA_FIXES` 里逐条声明的那几项
 *      （见下方 `DECLARED_ADDITIONS`；它与 `APPLIED_DATA_FIXES` 的 id 集合必须一一对应）；
 *   ③ `method` 取值集合与旧版**完全一致**（`ban`/`kick`/`log`）。
 *   另有两条同源加固：旧版条目的**相对顺序必须被保留**（只允许"插入"，不允许"重排"）、
 *   以及**不允许出现任何 `method:'command'` 的条目**（那等于在默认清单里塞进一条
 *   以服务器身份执行的任意命令，是旧版 D-34 的入口）。
 *
 * ══════════ 本文件在本次交付里发现的真缺陷（已修，见交付报告）══════════
 * 弹幕清单原本有 **3 个档位的条目顺序被静默重排**（相对旧版权威文件）：
 *   世纪之花 [302,356,132] → [132,302,356]；拜月教教徒、月亮领主同型（全部按 id 升序排过）。
 * 物品清单**没有**这个问题（它逐条保持了旧版顺序），所以这是移植时的一处不一致。
 * 重排不在 `APPLIED_DATA_FIXES` 的声明范围内，因此按"只允许插入、不允许重排"的规则
 * 把 3 个档位恢复成权威顺序（条目一条没变，只改相对次序），使真实差异**恰好等于**声明的那几项。
 * ★ 这条已被下面的 `旧版条目的相对顺序被完整保留` 用例永久钉住。
 *
 * ══════════ 本机与运行期限制（如实说明）══════════
 *   本机没有 TShock、没有游戏服。本文件验证的是**清单数据的形状与来源**，
 *   以及宿主归一（`normalizeConfig`）不会在装载时丢掉条目。
 *   它**不能**证明这些条目在真实 TShock 上按预期命中/阻断（那要真实服务器），
 *   也不能证明 `data-items` / `data-projectiles` 字典里这些 ID 确实存在（本机没有那两份字典的运行期实例）。
 *
 * 运行：node test/defaults-migration.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile, stat } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

import {
  APPLIED_DATA_FIXES,
  DEFERRED_DATA_DECISIONS,
  ITEM_DEFAULT_FILE,
  PROJ_DEFAULT_FILE,
  RESOURCES_DIR,
  loadDefaults,
} from '../defaults.js'
import { DEFAULT_ITEM_SWITCHES, DEFAULT_PROJ_SWITCHES, ENTRY_KEY } from '../config.js'

const here = path.dirname(fileURLToPath(import.meta.url))

/**
 * 旧版权威文件所在目录。
 * 路径推导：本文件在 `…/TsWeb/tsweb-cordis/plugins/anti-cheat/test/`，
 * 上溯四级是 `…/TsWeb/`（外层的 TsWeb），旧后端在 `…/TsWeb/TsWeb/backend/resources/默认配置/`。
 */
const OLD_DIR = path.resolve(here, '..', '..', '..', '..', 'TsWeb', 'backend', 'resources', '默认配置')

/** 旧版权威文件的实测基线（任务书逐字给出；任何漂移都要显式失败，防止"基线被悄悄改掉"） */
const OLD_BASELINE = {
  item: { file: '物品违禁.json', tiers: 19, entries: 119, methods: ['ban', 'kick', 'log'] },
  proj: { file: '弹幕违禁.json', tiers: 11, entries: 53, methods: ['ban', 'kick', 'log'] },
}

/** 新清单的基线（= 旧版 + 下面声明的补充） */
const NEW_BASELINE = {
  item: { tiers: 20, entries: 120 },
  proj: { tiers: 11, entries: 61 },
}

/**
 * 声明允许的差异 —— **本表的 `fixId` 集合必须与 `defaults.js` 的 `APPLIED_DATA_FIXES` 一一对应**
 * （由用例 `声明的差异与 APPLIED_DATA_FIXES 严格一一对应` 强制）。
 *
 * `address` 是逐条写死的期望值（不是从 `APPLIED_DATA_FIXES` 的散文里解析出来的）：
 * 这是有意的——测试必须能独立判定"数据对不对"，而不是跟着实现自己的声明走。
 * 若将来真要改默认清单的数据，必须先改 `APPLIED_DATA_FIXES` 与本表**两处**，
 * 于是"改数据"这件事永远会留下可见的痕迹。
 */
const DECLARED_ADDITIONS = {
  item: {
    fixId: 'D-28',
    /** 新增档位（含档位名与它该出现的相邻位置） */
    tiers: [
      {
        name: '巨鹿',
        entryIds: [3037],
        why: '规格 B §4.6 D-28：独眼巨鹿档整体缺失；插在「蜂后」与「骷髅王」之间，与旧 GetWorldInfo.cs:48-65 BossOrder 一致',
        after: '蜂后',
        before: '骷髅王',
      },
    ],
    /** 既有档位里新增的条目 */
    entries: {},
  },
  proj: {
    fixId: 'D-32',
    tiers: [],
    entries: {
      始终生效: {
        entryIds: [28, 29, 30, 133, 139, 140],
        fixIds: ['D-32'],
        why: '规格 B §4.6 D-32：始终生效档爆炸物不完整（只有 II/IV 级），补 I/III 级与炸弹/雷管/手榴弹',
      },
      光之女皇: {
        entryIds: [927, 946],
        fixIds: ['D-27', 'D-30'],
        why: '规格 B §4.6 D-27（弹幕 927 星光缺失）/ D-30（弹幕 946 泰拉棱镜档位错放），物品侧已拦而弹幕侧漏',
      },
    },
  },
}

/** 每个条目都要多出来的字段（本次移植统一补上 `command`，见 config.js:42-46 的 `method` 闭集说明） */
const DECLARED_FIELD_ADDITIONS = ['command']

/** 条目字段的期望形状（顺序无关，用排序后的键名比较） */
const ENTRY_KEYS = {
  item: ['command', 'id', 'method', 'stack'],
  proj: ['command', 'id', 'method'],
}

const entryKey = (kind) => ENTRY_KEY[kind]

/** 该侧条目的"身份键"：物品侧含 stack，弹幕侧没有 stack（旧 RestrictedProj 没有该字段） */
function identityOf(kind, entry) {
  return kind === 'item'
    ? `${entry.id}/${entry.stack}/${entry.method}`
    : `${entry.id}/${entry.method}`
}

function entriesOf(kind, side) {
  return (side.限制列表 || []).flatMap((t) => t[entryKey(kind)] || [])
}

function countEntries(kind, side) {
  return entriesOf(kind, side).length
}

function tiersOf(side) {
  return (side.限制列表 || []).map((t) => t.进度)
}

function idsInTier(kind, side, tierName) {
  const tier = (side.限制列表 || []).find((t) => t.进度 === tierName)
  return tier ? (tier[entryKey(kind)] || []).map((e) => e.id) : null
}

// ═══════════════════════ 夹具：读旧版与新版 ═══════════════════════

/** 旧版权威文件是否可用（不可用就 skip 并说明"未做任何验证"，绝不伪装成通过） */
let oldAvailable = true
let oldError = ''
const OLD = {}
const NEW = {}

try {
  await stat(OLD_DIR)
  for (const kind of ['item', 'proj']) {
    OLD[kind] = JSON.parse(await readFile(path.join(OLD_DIR, OLD_BASELINE[kind].file), 'utf8'))
  }
} catch (err) {
  oldAvailable = false
  oldError = `旧版权威清单不可用：${OLD_DIR}（${err.code || err.message}）`
}

let newRaw = {}
for (const kind of ['item', 'proj']) {
  const file = path.join(RESOURCES_DIR, kind === 'item' ? ITEM_DEFAULT_FILE : PROJ_DEFAULT_FILE)
  const raw = await readFile(file, 'utf8')
  newRaw[kind] = raw
  NEW[kind] = JSON.parse(raw)
}

const skipReason = oldAvailable ? false : `${oldError}（本文件所有"相对旧版"的用例都未做任何验证）`

// ═══════════════════════ ① 基线与文件形态 ═══════════════════════

test('旧版权威文件存在，且计数与任务书的基线一致（基线漂移必须显式失败）', { skip: skipReason }, () => {
  for (const kind of ['item', 'proj']) {
    const side = OLD[kind]
    assert.equal(tiersOf(side).length, OLD_BASELINE[kind].tiers,
      `旧版 ${kind} 档位数不是基线值（实测应为 ${OLD_BASELINE[kind].tiers}）——基线被改过，需先复核基准文件`)
    assert.equal(countEntries(kind, side), OLD_BASELINE[kind].entries,
      `旧版 ${kind} 条数不是基线值（实测应为 ${OLD_BASELINE[kind].entries}）——基线被改过，需先复核基准文件`)
  }
})

test('新清单就在插件内 resources/ 下（放 data/ 会被打包器丢掉），且计数与声明一致', () => {
  for (const kind of ['item', 'proj']) {
    assert.equal(tiersOf(NEW[kind]).length, NEW_BASELINE[kind].tiers, `新 ${kind} 档位数不符`)
    assert.equal(countEntries(kind, NEW[kind]), NEW_BASELINE[kind].entries, `新 ${kind} 条数不符`)
  }
  // 文件必须在插件内 resources/（publics 打包器 SKIP_DIRS 排除 data/，放 data/ 装到用户机器上就不存在）
  const rel = path.relative(path.resolve(here, '..'), RESOURCES_DIR).replace(/\\/g, '/')
  assert.equal(rel, 'resources', `默认清单必须在插件内 resources/ 下（现在解析到 ${rel}）`)
})

test('两份清单的 JSON 文本是"规范化形态"（2 空格缩进 + 单个结尾换行），让日后的 diff 可读', () => {
  for (const kind of ['item', 'proj']) {
    const pretty = JSON.stringify(NEW[kind], null, 2) + '\n'
    assert.equal(newRaw[kind], pretty,
      `${kind} 清单的文件形态与 JSON.stringify(obj, null, 2) + "\\n" 不一致。\n`
      + '  这条不是为了好看：清单是一份需要被逐条 review 的数据文件，'
      + '  非规范格式会让"真正的数据改动"淹没在整文件重排的 diff 里。')
  }
})

// ═══════════════════════ ② 一条不少 + 字段一致 + 顺序保留 ═══════════════════════

test('旧版每一条 id/stack/method（弹幕侧 id/method）一条不少，且逐条字段值一致', { skip: skipReason }, () => {
  const missing = []
  const changed = []
  for (const kind of ['item', 'proj']) {
    const oldSide = OLD[kind]
    const newSide = NEW[kind]
    for (const tier of oldSide.限制列表 || []) {
      const tierName = tier.进度
      const newTierIds = idsInTier(kind, newSide, tierName)
      if (newTierIds === null) {
        missing.push(`${kind} 档位整体缺失：${tierName}（旧版有 ${(tier[entryKey(kind)] || []).length} 条）`)
        continue
      }
      const newById = new Map()
      const newTier = (newSide.限制列表 || []).find((t) => t.进度 === tierName)
      for (const e of newTier[entryKey(kind)] || []) newById.set(`${e.id}`, e)
      for (const oe of tier[entryKey(kind)] || []) {
        const ne = newById.get(`${oe.id}`)
        if (!ne) {
          missing.push(`${kind} 档位「${tierName}」缺条目 id=${oe.id}（旧版 ${identityOf(kind, oe)}）`)
          continue
        }
        if (kind === 'item' && ne.stack !== oe.stack) {
          changed.push(`${kind} 档位「${tierName}」id=${oe.id} 的 stack：旧 ${oe.stack} → 新 ${ne.stack}`)
        }
        if (ne.method !== oe.method) {
          changed.push(`${kind} 档位「${tierName}」id=${oe.id} 的 method：旧 ${oe.method} → 新 ${ne.method}`)
        }
      }
    }
  }
  assert.deepEqual(missing, [],
    '默认清单相对旧版权威文件**丢了条目**。丢条目意味着"本来会被拦的东西现在不拦了"，\n'
    + '  而这在界面上完全看不出来——下一次「应用默认配置」就静默生效。缺的是：\n'
    + missing.map((s) => `    - ${s}`).join('\n'))
  assert.deepEqual(changed, [],
    '默认清单相对旧版权威文件**改了逐条字段**（stack/method）。这会直接改变处置力度\n'
    + '  （例如 log → ban 就是"只记账"变成"封号"），必须由 APPLIED_DATA_FIXES 显式声明才允许。改了的是：\n'
    + changed.map((s) => `    - ${s}`).join('\n'))
})

test('没有任何条目被删除（新旧档位逐一对齐，旧档位必须都还在）', { skip: skipReason }, () => {
  for (const kind of ['item', 'proj']) {
    const oldTierNames = tiersOf(OLD[kind])
    const newTierNames = new Set(tiersOf(NEW[kind]))
    const dropped = oldTierNames.filter((t) => !newTierNames.has(t))
    assert.deepEqual(dropped, [],
      `${kind} 侧丢掉了旧版档位：${dropped.join('、')}。`
      + '档位消失会让该进度段的违禁规则整体失效（旧版最严重的"保存静默删除档位"就是这一类）。')
  }
})

test('旧版条目的相对顺序被完整保留（只允许"插入"，不允许"重排"）', { skip: skipReason }, () => {
  const bad = []
  for (const kind of ['item', 'proj']) {
    for (const tier of OLD[kind].限制列表 || []) {
      const tierName = tier.进度
      const oldIds = (tier[entryKey(kind)] || []).map((e) => e.id)
      const newIds = idsInTier(kind, NEW[kind], tierName) || []
      const oldSet = new Set(oldIds)
      // 只看"旧条目"在新序列里的相对次序：必须与旧版逐位一致（= 旧序列是新序列的子序列）
      const projected = newIds.filter((id) => oldSet.has(id))
      let i = 0
      for (const id of projected) {
        if (i < oldIds.length && oldIds[i] === id) i += 1
      }
      if (i !== oldIds.length) {
        bad.push(`${kind} 档位「${tierName}」：旧 ${JSON.stringify(oldIds)} → 新（只取旧条目）${JSON.stringify(projected)}`)
      }
    }
  }
  assert.deepEqual(bad, [],
    '默认清单相对旧版权威文件**重排了条目**。重排不改集合、不改判定语义，但会改变\n'
    + '  「违禁清单」页上管理员看到的顺序，而且它**不在 APPLIED_DATA_FIXES 的声明范围内**。\n'
    + '  本次交付前，弹幕清单的「世纪之花」「拜月教教徒」「月亮领主」三档就被整体按 id 升序重排过\n'
    + '  （物品清单没有这个问题），已恢复为权威顺序。重排的是：\n'
    + bad.map((s) => `    - ${s}`).join('\n'))
})

// ═══════════════════════ ③ 差异恰好等于声明的那几项 ═══════════════════════

test('新增条目恰好是 APPLIED_DATA_FIXES 声明的那几项（多一条少一条都失败）', { skip: skipReason }, () => {
  for (const kind of ['item', 'proj']) {
    const oldSide = OLD[kind]
    const newSide = NEW[kind]

    // 期望：档位 → 该档位允许新增的 id 集合
    const expectedByTier = new Map()
    for (const t of DECLARED_ADDITIONS[kind].tiers || []) {
      expectedByTier.set(t.name, new Set(t.entryIds))
    }
    for (const [tierName, spec] of Object.entries(DECLARED_ADDITIONS[kind].entries || {})) {
      expectedByTier.set(tierName, new Set(spec.entryIds))
    }

    const unexpected = []
    const notFound = []
    const seen = new Map()

    for (const tier of newSide.限制列表 || []) {
      const tierName = tier.进度
      const oldIds = idsInTier(kind, oldSide, tierName)
      const allowed = expectedByTier.get(tierName) || new Set()
      for (const e of tier[entryKey(kind)] || []) {
        const isNew = oldIds === null || !oldIds.includes(e.id)
        if (!isNew) continue
        seen.set(tierName, (seen.get(tierName) || 0) + 1)
        if (!allowed.has(e.id)) {
          unexpected.push(`${kind} 档位「${tierName}」多出条目 id=${e.id}（${identityOf(kind, e)}）—— 未在 APPLIED_DATA_FIXES 里声明`)
        }
      }
    }
    for (const [tierName, allowed] of expectedByTier) {
      const ids = idsInTier(kind, newSide, tierName)
      if (ids === null) {
        notFound.push(`${kind} 档位「${tierName}」不存在（声明里说要补 ${[...allowed].join('/')}）`)
        continue
      }
      for (const id of allowed) {
        if (!ids.includes(id)) notFound.push(`${kind} 档位「${tierName}」缺少声明新增的 id=${id}`)
      }
    }

    assert.deepEqual(unexpected, [],
      '默认清单里出现了**未被声明的**新增条目。这是本文件存在的主要理由——\n'
      + '  静默新增一条 method 为 ban 的条目，等于静默增加一处封号规则。未声明的是：\n'
      + unexpected.map((s) => `    - ${s}`).join('\n')
      + '\n  若这是有意改动：请同步改 defaults.js 的 APPLIED_DATA_FIXES 与本文件的 DECLARED_ADDITIONS。')
    assert.deepEqual(notFound, [],
      '声明要补的条目没有真的补上（声明与数据不一致）：\n' + notFound.map((s) => `    - ${s}`).join('\n'))
  }
})

test('声明的差异与 APPLIED_DATA_FIXES 严格一一对应（改一处必须改另一处）', { skip: skipReason }, () => {
  const fixIds = new Set(APPLIED_DATA_FIXES.map((f) => f.id))
  const declaredIds = new Set()
  for (const kind of ['item', 'proj']) {
    const spec = DECLARED_ADDITIONS[kind]
    if (spec.fixId) declaredIds.add(spec.fixId)
    for (const t of spec.tiers || []) if (t.fixId) declaredIds.add(t.fixId)
    for (const e of Object.values(spec.entries || {})) {
      for (const id of e.fixIds || []) declaredIds.add(id)
    }
  }
  assert.deepEqual([...declaredIds].sort(), [...fixIds].sort(),
    'defaults.js 的 APPLIED_DATA_FIXES 与本文件 DECLARED_ADDITIONS 声明覆盖的数据缺陷不是同一组。\n'
    + `  APPLIED_DATA_FIXES：${[...fixIds].sort().join(', ')}\n`
    + `  DECLARED_ADDITIONS：${[...declaredIds].sort().join(', ')}\n`
    + '  这两处必须同步：新增一条数据补充时，两边都要写清"补了什么"，'
    + '否则"相对旧版的差异"就无从核对。')

  // 每个声明项都要有 why（可追溯依据），且 deferred 决策要留痕
  for (const f of APPLIED_DATA_FIXES) {
    assert.ok(typeof f.what === 'string' && f.what.length > 10, `APPLIED_DATA_FIXES 的 ${f.id} 缺 what（补了什么）`)
    assert.ok(typeof f.why === 'string' && f.why.length > 10, `APPLIED_DATA_FIXES 的 ${f.id} 缺 why（依据）`)
    assert.ok(['item', 'proj'].includes(f.scope), `APPLIED_DATA_FIXES 的 ${f.id} scope 必须是 item/proj`)
  }
  assert.ok(DEFERRED_DATA_DECISIONS.length >= 3, '未采纳的数据缺陷必须逐条留痕（否则"补齐了哪些"无从核对）')
  for (const d of DEFERRED_DATA_DECISIONS) {
    assert.ok(typeof d.decision === 'string' && d.decision !== '', `DEFERRED_DATA_DECISIONS 的 ${d.id} 缺 decision`)
    assert.ok(typeof d.detail === 'string' && d.detail.length > 10, `DEFERRED_DATA_DECISIONS 的 ${d.id} 缺 detail`)
  }
})

test('新增档位的位置符合声明（「巨鹿」必须插在「蜂后」与「骷髅王」之间）', { skip: skipReason }, () => {
  for (const kind of ['item', 'proj']) {
    for (const spec of DECLARED_ADDITIONS[kind].tiers || []) {
      const names = tiersOf(NEW[kind])
      const idx = names.indexOf(spec.name)
      assert.ok(idx >= 0, `${kind} 侧缺声明新增的档位「${spec.name}」`)
      if (spec.after) {
        const ai = names.indexOf(spec.after)
        assert.ok(ai >= 0 && ai < idx,
          `「${spec.name}」必须排在「${spec.after}」之后（现在是 ${ai} vs ${idx}）—— ${spec.why}`)
      }
      if (spec.before) {
        const bi = names.indexOf(spec.before)
        assert.ok(bi >= 0 && bi > idx,
          `「${spec.name}」必须排在「${spec.before}」之前（现在是 ${idx} vs ${bi}）—— ${spec.why}`)
      }
    }
  }
  // 档位顺序本身也是数据：旧版档位在新版里的相对顺序必须不变（插入不改次序）
  for (const kind of ['item', 'proj']) {
    const oldNames = tiersOf(OLD[kind])
    const newNames = tiersOf(NEW[kind]).filter((n) => oldNames.includes(n))
    assert.deepEqual(newNames, oldNames,
      `${kind} 侧旧档位的相对顺序被改了（档位顺序决定界面上的卡片顺序与宿主 progressOrder 的追加顺序）`)
  }
})

test('条目字段：形状恰好是声明的键集合，每条都补齐了 command 且值为空串', { skip: skipReason }, () => {
  for (const kind of ['item', 'proj']) {
    const badShape = []
    const badCommand = []
    for (const tier of NEW[kind].限制列表 || []) {
      for (const e of tier[entryKey(kind)] || []) {
        const keys = Object.keys(e).sort()
        if (keys.join('|') !== ENTRY_KEYS[kind].join('|')) {
          badShape.push(`${kind} 档位「${tier.进度}」id=${e.id} 的键是 ${keys.join(',')}，期望 ${ENTRY_KEYS[kind].join(',')}`)
        }
        if (!DECLARED_FIELD_ADDITIONS.includes('command')) continue
        if (e.command !== '') {
          badCommand.push(`${kind} 档位「${tier.进度}」id=${e.id} 的 command 非空：${JSON.stringify(e.command)}`)
        }
      }
    }
    assert.deepEqual(badShape, [],
      '默认清单条目的字段集合变了。物品侧必须是 {id,stack,method,command}，\n'
      + '  弹幕侧必须是 {id,method,command}（旧 RestrictedProj 没有 stack，多出 stack 会让服端解析出意外行为）：\n'
      + badShape.map((s) => `    - ${s}`).join('\n'))
    assert.deepEqual(badCommand, [],
      '默认清单里出现了**非空 command**。command 只有在 method 为 command 时才被执行，\n'
      + '  而它是以服务器身份运行的任意命令——默认清单里必须全部为空，\n'
      + '  否则等于"装好插件就自带一条命令注入"。非空的是：\n'
      + badCommand.map((s) => `    - ${s}`).join('\n'))
  }
})

test('不允许出现任何 method=command 的默认条目（旧版 D-34"任意命令执行"入口）', { skip: skipReason }, () => {
  for (const kind of ['item', 'proj']) {
    const offenders = []
    for (const tier of NEW[kind].限制列表 || []) {
      for (const e of tier[entryKey(kind)] || []) {
        if (e.method === 'command') offenders.push(`${kind} 档位「${tier.进度}」id=${e.id}`)
      }
    }
    assert.deepEqual(offenders, [],
      `${kind} 默认清单里出现了 method='command' 的条目：${offenders.join('、')}。\n`
      + '  默认清单会被「应用默认配置」一键铺到所有服上；里面出现 command 条目意味着\n'
      + '  管理员在不知情的情况下让服务端执行了自定义命令（config.js:38-46 的 D-34 说明）。')
  }
})

// ═══════════════════════ ④ method 闭集与取值域 ═══════════════════════

test('method 取值集合与旧版完全一致（ban/kick/log），不多不少', { skip: skipReason }, () => {
  for (const kind of ['item', 'proj']) {
    const oldSet = [...new Set(entriesOf(kind, OLD[kind]).map((e) => e.method))].sort()
    const newSet = [...new Set(entriesOf(kind, NEW[kind]).map((e) => e.method))].sort()
    assert.deepEqual(newSet, oldSet,
      `${kind} 侧 method 取值集合与旧版不一致。旧 ${JSON.stringify(oldSet)} → 新 ${JSON.stringify(newSet)}。\n`
      + '  新增取值（例如出现 drop）会改变处置力度；消失取值会让原本被处置的条目变成别的方式。')
    assert.deepEqual(newSet, OLD_BASELINE[kind].methods,
      `${kind} 侧 method 取值集合与基线 ${JSON.stringify(OLD_BASELINE[kind].methods)} 不一致`)
  }
})

test('取值域合法：id ∈ [1,65535] 且为整数，物品侧 stack 是 >=1 的整数', { skip: skipReason }, () => {
  const bad = []
  for (const kind of ['item', 'proj']) {
    for (const tier of NEW[kind].限制列表 || []) {
      for (const e of tier[entryKey(kind)] || []) {
        if (!Number.isInteger(e.id) || e.id < 1 || e.id > 65535) {
          bad.push(`${kind} 档位「${tier.进度}」id 非法：${JSON.stringify(e.id)}`)
        }
        if (kind === 'item' && (!Number.isInteger(e.stack) || e.stack < 1)) {
          bad.push(`item 档位「${tier.进度}」id=${e.id} 的 stack 非法：${JSON.stringify(e.stack)}`)
        }
        if (!['log', 'kick', 'ban', 'drop', 'command'].includes(e.method)) {
          bad.push(`${kind} 档位「${tier.进度}」id=${e.id} 的 method 不在闭集内：${JSON.stringify(e.method)}`)
        }
      }
    }
  }
  assert.deepEqual(bad, [], `默认清单里有非法取值（宿主 config.js 的 ID_MIN/ID_MAX 是 1/65535）：\n${bad.map((s) => `  - ${s}`).join('\n')}`)
})

test('没有重复 id（同档位内）—— 重复会让同一条规则出现两次，容易被误当成"两条独立规则"维护', { skip: skipReason }, () => {
  const dup = []
  for (const kind of ['item', 'proj']) {
    for (const tier of NEW[kind].限制列表 || []) {
      const ids = (tier[entryKey(kind)] || []).map((e) => e.id)
      const seen = new Set()
      for (const id of ids) {
        if (seen.has(id)) dup.push(`${kind} 档位「${tier.进度}」id=${id} 出现两次`)
        seen.add(id)
      }
    }
  }
  // 宿主是"宽容合并"（重复即保留，config.js:411-422 的旧版语义），所以这里只作为**数据卫生**断言
  assert.deepEqual(dup, [], `默认清单同档位内有重复 id（宿主会保留重复，但默认清单本身不该有）：\n${dup.map((s) => `  - ${s}`).join('\n')}`)
})

// ═══════════════════════ ⑤ 顶层开关（旧版矛盾的收口点）══════════════════════

test('顶层键差异只有 item 的「没收违禁物品」，且值为默认 false', { skip: skipReason }, () => {
  for (const kind of ['item', 'proj']) {
    const oldKeys = Object.keys(OLD[kind]).sort()
    const newKeys = Object.keys(NEW[kind]).sort()
    const extra = newKeys.filter((k) => !oldKeys.includes(k))
    const lost = oldKeys.filter((k) => !newKeys.includes(k))
    assert.deepEqual(lost, [], `${kind} 清单丢了顶层键：${lost.join('、')}`)
    if (kind === 'item') {
      assert.deepEqual(extra, ['没收违禁物品'],
        `item 清单的顶层键差异必须恰好是「没收违禁物品」这一项。\n`
        + '  理由（config.js:33-36 逐字）：旧版后端资源 JSON 没有该键，导致旧版「应用默认配置」\n'
        + '  会把它静默重置为 false（管理员已开启的没收被悄悄关掉）。本件补上该键是**有意的结构修复**。\n'
        + `  实际多出来的键：${extra.join('、') || '（无）'}`)
      assert.equal(NEW.item.没收违禁物品, false,
        '资源里的「没收违禁物品」必须是 false（默认清单不得替管理员打开"直接删掉违禁物品"这种破坏性动作）')
    } else {
      assert.deepEqual(extra, [], `proj 清单不应有额外的顶层键，实际多出：${extra.join('、')}`)
    }
  }
})

test('开关取值与旧版逐项一致，且等于宿主的权威默认值（旧版三套矛盾默认值的收口结果）', { skip: skipReason }, () => {
  // 旧版有三套互相矛盾的默认值（类初始化器 false/600、首次落盘 true/10、后端资源 true/10），
  // 本件收口为一份（config.js:23-36）。资源文件必须是收口后的那一份，否则"默认值"又分叉了。
  const itemSwitches = {
    启用: NEW.item.启用,
    自动扫描: NEW.item.自动扫描,
    扫描间隔: NEW.item.扫描间隔,
    没收违禁物品: NEW.item.没收违禁物品,
  }
  assert.deepEqual(itemSwitches, DEFAULT_ITEM_SWITCHES,
    'item 清单的开关与 config.js 的 DEFAULT_ITEM_SWITCHES 不一致——默认值又分叉了')
  assert.deepEqual({ 启用: NEW.proj.启用, 伤害上限: NEW.proj.伤害上限 }, DEFAULT_PROJ_SWITCHES,
    'proj 清单的开关与 config.js 的 DEFAULT_PROJ_SWITCHES 不一致')

  // 与旧版逐项比对：除"新增的 没收违禁物品"外，其余键的值必须一字不差
  for (const kind of ['item', 'proj']) {
    for (const [k, v] of Object.entries(OLD[kind])) {
      if (k === '限制列表') continue
      assert.equal(NEW[kind][k], v,
        `${kind} 清单的顶层字段「${k}」相对旧版被改了：旧 ${JSON.stringify(v)} → 新 ${JSON.stringify(NEW[kind][k])}`)
    }
  }
  // 默认必须是"未启用"：默认清单被一键铺到所有服上时不应立刻开始踢人
  assert.equal(NEW.item.启用, false, 'item 默认必须是未启用（默认清单不得让检测一上线就生效）')
  assert.equal(NEW.proj.启用, false, 'proj 默认必须是未启用')
})

// ═══════════════════════ ⑥ 装载路径不丢条目 ═══════════════════════

test('loadDefaults() 归一后条目一条不少，且清单本身不产生任何警告（清单必须是干净的）', async () => {
  const d = await loadDefaults()
  assert.equal(d.error, '', `默认清单装载报错：${d.error}`)
  assert.deepEqual(d.stats, {
    itemTiers: NEW_BASELINE.item.tiers,
    itemEntries: NEW_BASELINE.item.entries,
    projTiers: NEW_BASELINE.proj.tiers,
    projEntries: NEW_BASELINE.proj.entries,
  }, 'loadDefaults() 统计与磁盘上的清单不一致（归一过程丢档位/条目了？）')

  // ★ 这条是"归一不吞数据"的正面证据：磁盘上的每一条都必须在归一结果里找得到
  const lost = []
  for (const kind of ['item', 'proj']) {
    const onDisk = new Set(entriesOf(kind, NEW[kind]).map((e) => identityOf(kind, e)))
    const afterNorm = new Set(entriesOf(kind, d.config[kind]).map((e) => identityOf(kind, e)))
    for (const key of onDisk) if (!afterNorm.has(key)) lost.push(`${kind} ${key}`)
  }
  assert.deepEqual(lost, [],
    'normalizeConfig 在装载默认清单时丢掉了条目（这会让「应用默认配置」比资源文件少一些规则）：\n'
    + lost.map((s) => `    - ${s}`).join('\n'))

  // 归一不该对"已符合规范"的清单产生任何警告——有警告说明资源文件里写了宿主不认的东西
  assert.deepEqual(d.warnings, [],
    '默认清单被宿主归一判定出警告（说明资源文件里有宿主不认的字段/取值，会被静默修正）：\n'
    + d.warnings.map((s) => `    - ${s}`).join('\n'))
  assert.equal(d.files.item, path.join(RESOURCES_DIR, ITEM_DEFAULT_FILE))
  assert.equal(d.files.proj, path.join(RESOURCES_DIR, PROJ_DEFAULT_FILE))
})

test('「应用默认配置」会把这两份清单原样铺开（条目数与档位数都与磁盘一致）', async () => {
  const d = await loadDefaults()
  const { applyDefaults } = await import('../defaults.js')
  // 从一份"管理员自定义过"的配置出发，应用默认清单后必须回到资源文件的内容
  const custom = {
    item: { 启用: true, 自动扫描: false, 扫描间隔: 99, 没收违禁物品: true, 限制列表: [{ 进度: '自定义档位X', 限制物品: [{ id: 5, stack: 2, method: 'ban', command: '' }] }] },
    proj: { 启用: true, 伤害上限: 5, 限制列表: [{ 进度: '自定义档位Y', 限制弹幕: [{ id: 6, method: 'kick', command: '' }] }] },
  }
  const r = applyDefaults(custom, d.config, { scope: 'both' })
  assert.deepEqual(
    r.config.item.限制列表.map((t) => t.进度),
    NEW.item.限制列表.map((t) => t.进度),
    '应用默认配置后 item 档位序列必须与资源文件一致（含新增的「巨鹿」）')
  assert.deepEqual(
    r.config.proj.限制列表.map((t) => t.进度),
    NEW.proj.限制列表.map((t) => t.进度),
    '应用默认配置后 proj 档位序列必须与资源文件一致')
  assert.equal(countEntries('item', r.config.item), NEW_BASELINE.item.entries)
  assert.equal(countEntries('proj', r.config.proj), NEW_BASELINE.proj.entries)
  // 默认不动开关（旧版会把「没收违禁物品」静默重置为 false，这是被修掉的缺陷）
  assert.equal(r.config.item.启用, true, 'applyDefaults 默认不得改动开关（管理员已开的检测不能被静默关掉）')
  assert.equal(r.config.item.没收违禁物品, true, 'applyDefaults 默认不得改动「没收违禁物品」（旧版正是把它静默重置为 false）')
  assert.equal(r.config.proj.伤害上限, 5, 'applyDefaults 默认不得改动「伤害上限」')
})
