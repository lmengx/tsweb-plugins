/**
 * anti-cheat 发行目录同步测试（本仓既有约定：见 plugins/task-scheduler/test/dist-sync.test.mjs
 * 与 plugins/status-panel/test/dist-sync.test.mjs）
 *
 * ══════════ 为什么需要这个文件 ══════════
 *   本仓要求"每改一个文件都要同步到 tsweb-dist-lite/plugins/anti-cheat/，并校验 SHA256 一致"。
 *   一次性手工核对过不算数——下次改完源码忘了同步、或者只同步了一半（例如只改了 client/ 没改
 *   宿主半），没人会知道，而用户拿到的就是那份半新半旧的目录。
 *   本文件把这条要求变成可复跑的断言：
 *     ① 源码插件目录里每个文件，发行目录里都有一份**逐字节相同**的副本
 *        （缺失与"内容不一致"**分开报告**，因为两者原因不同：没同步 vs 同步后又改了源码）
 *     ② 发行目录里不得有源码目录没有的多余文件（否则会下发一份"来历不明"的旧文件）
 *     ③ 列出时排除 bin/ obj/ node_modules，且发行目录里不得出现这些目录（中间产物不进发行包）
 *     ④ 关键文件确实在发行目录里，且发行侧 package.json 的关键字段也对
 *     ⑤ test/ 下的每个 .test.mjs 也在发行目录里（新增测试文件也必须同步；清单**动态发现**，不硬编码）
 *     ⑥ 用来做一致性判定的 SHA256 本身可靠（防"hash 算错导致永远相等"的假通过）
 *   另外：发行目录不存在时，每个用例都以 skip 形式跳过并明确写出"本用例未做任何验证"
 *   （跳过理由就在 skip 文案里；不写成静默 return —— 那会"记 pass 但什么都没验证"）。
 *
 * ══════════ 本机限制（如实说明，不含糊）══════════
 *   本机**没有 TShock**，也没有能加载 AntiCheat.dll 的服务器运行环境。本文件只能证明
 *   "发行目录与源码目录逐字节一致、且不会多出或少掉文件"，**不能**证明同步过去的那一份在真实
 *   TShock 上能加载、能阻断违禁物品/弹幕。本文件与 pack-freshness.test.mjs 合起来覆盖的是
 *   "会被下发的到底是哪一份东西、内容对不对"，不是"插件在服务器上跑得起来"。
 *
 * 运行：cd plugins/anti-cheat && node test/dist-sync.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readdir, readFile, stat, mkdtemp, writeFile, rm } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { tmpdir } from 'node:os'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
/** 源码侧插件目录：plugins/anti-cheat */
const srcDir = path.resolve(here, '..')
/** 发行侧插件目录：tsweb-dist-lite/plugins/anti-cheat */
const distDir = path.resolve(srcDir, '..', '..', 'tsweb-dist-lite', 'plugins', 'anti-cheat')

/** 递归列出相对路径（跳过 bin/obj/node_modules：构建中间产物不进发行目录） */
async function listFiles(root, base = root) {
  const out = []
  let entries
  try {
    entries = await readdir(root, { withFileTypes: true })
  } catch (err) {
    if (err.code === 'ENOENT') return null
    throw err
  }
  for (const e of entries) {
    const abs = path.join(root, e.name)
    const rel = path.relative(base, abs).replace(/\\/g, '/')
    if (e.isDirectory()) {
      if (e.name === 'bin' || e.name === 'obj' || e.name === 'node_modules') continue
      out.push(...(await listFiles(abs, base)))
    } else {
      out.push(rel)
    }
  }
  return out
}

function sha256(buf) {
  return createHash('sha256').update(buf).digest('hex')
}

/** 逐文件比较两侧内容，缺失与"内容不一致"分开收集（两者的原因和修法不同） */
async function compareSide(rels) {
  const missing = []
  const differing = []
  for (const rel of rels) {
    let buf
    try {
      buf = await readFile(path.join(distDir, rel))
    } catch (err) {
      if (err.code === 'ENOENT') { missing.push(rel); continue }
      throw err
    }
    const a = sha256(await readFile(path.join(srcDir, rel)))
    const b = sha256(buf)
    if (a !== b) differing.push(`${rel}（源码 ${a.slice(0, 12)}… / 发行 ${b.slice(0, 12)}…）`)
  }
  return { missing, differing }
}

let distExists = false
try {
  distExists = (await stat(distDir)).isDirectory()
} catch (err) {
  if (err.code !== 'ENOENT') throw err
}

/** 发行目录缺失时的跳过文案：必须写明"未做任何验证"，不能伪装成通过 */
const skipNoDist = distExists ? false : `发行目录不存在：${distDir}（本用例未做任何验证）`

test('发行目录存在且是目录（不存在就跳过，并说明"未验证"）', { skip: skipNoDist }, () => {
  assert.ok(distExists)
})

test('① 源码目录里的每个文件在发行目录里都有一份逐字节（SHA256）相同的副本', { skip: skipNoDist }, async () => {
  const src = await listFiles(srcDir)
  assert.ok(src && src.length > 0, '源码目录应能列出文件')
  assert.equal(
    src.some((f) => f.split('/').some((seg) => seg === 'bin' || seg === 'obj')),
    false,
    '列出时不应包含 bin/obj 中间产物',
  )

  const { missing, differing } = await compareSide(src)
  assert.deepEqual(missing, [], `发行目录缺少这些文件（说明没同步）：${missing.join('、')}`)
  assert.deepEqual(
    differing, [],
    `这些文件两边内容不一致（说明同步过一次之后又改了源码，或只同步了一半）：${differing.join('、')}`,
  )
})

test('② 发行目录里没有源码目录没有的多余文件（幽灵文件会让用户拿到来历不明的旧文件）', { skip: skipNoDist }, async () => {
  const dist = await listFiles(distDir)
  const src = new Set(await listFiles(srcDir))
  const extra = (dist || []).filter((f) => !src.has(f))
  assert.deepEqual(
    extra, [],
    `发行目录里有源码目录不存在的文件（已删除的旧文件没清掉，或同步时多带了文件）：${extra.join('、')}`,
  )
})

test('③ 发行目录里不得出现构建中间产物（bin/ obj/ 目录）', { skip: skipNoDist }, async () => {
  const all = []
  async function walk(root, base) {
    for (const e of await readdir(root, { withFileTypes: true })) {
      const abs = path.join(root, e.name)
      if (e.isDirectory()) {
        all.push(path.relative(base, abs).replace(/\\/g, '/'))
        await walk(abs, base)
      }
    }
  }
  await walk(distDir, distDir)
  const bad = all.filter((d) => /(^|\/)(bin|obj|node_modules)(\/|$)/.test(d))
  assert.deepEqual(bad, [], `发行目录不应包含构建中间产物目录：${bad.join('、')}`)
})

test('④ 关键文件确实在发行目录里，且发行侧 package.json 的关键字段也对', { skip: skipNoDist }, async () => {
  const required = [
    'package.json',
    'index.js',
    'config.js',
    'store.js',
    'defaults.js',
    'logs.js',
    'audit.js',
    'gameOps.js',
    'client/anti-cheat.js',
    'client/shared/api.js',
    'plugin/AntiCheat.dll',
    'resources/物品违禁.json',
    'resources/弹幕违禁.json',
    'test/support/fake-host.mjs',
  ]
  for (const rel of required) {
    const s = await stat(path.join(distDir, rel))
    assert.ok(s.isFile(), `发行目录缺少 ${rel}`)
  }

  // package.json 是 loader/市场认插件的入口，发行侧这几个字段必须与源码侧一致
  // （字段含义见源码 package.json 与 scripts/pack-plugin.mjs:346-412 的校验）
  const pkg = JSON.parse(await readFile(path.join(distDir, 'package.json'), 'utf8'))
  assert.equal(pkg.name, 'anti-cheat', '市场与 loader 按 name/目录名匹配，写错会"装了但找不到"')
  assert.equal(pkg.tsweb.client, './client/anti-cheat.js', '前端入口必须指向发行目录里真实存在的那份')
  assert.deepEqual(pkg.tsweb.dll, ['./plugin/*.dll'], 'C# 半的下发 glob 必须保持 ./plugin/*.dll')
  assert.deepEqual(pkg.tsweb.tags, ['反作弊'], '市场筛选分类必须与源码侧一致（分类是闭集）')
  assert.equal(pkg.tsweb.deploy, 'all', '清单要自动下发到所有已启用服务器')
})

test('⑤ test/ 下的每个 .test.mjs 在发行目录里都有逐字节相同的副本（动态发现，不硬编码清单）', { skip: skipNoDist }, async () => {
  // 这条的要求是"新增的测试文件也要同步"。**动态列出**源码 test/ 下的 .test.mjs，
  // 不写死文件名——否则以后新增的测试文件不会被这条抓到，正是本用例要防的失效方式。
  const srcTestDir = path.join(srcDir, 'test')
  const entries = await readdir(srcTestDir, { withFileTypes: true })
  const testFiles = entries
    .filter((e) => e.isFile() && e.name.endsWith('.test.mjs'))
    .map((e) => `test/${e.name}`)
    .sort()

  assert.ok(testFiles.length >= 2, `test/ 下应当至少有 2 个 .test.mjs：实际 ${testFiles.length} 个 —— ${testFiles.join('、')}`)
  // 自证"动态发现"这条路径确实在工作：本文件自身就应该被发现
  assert.ok(testFiles.includes('test/dist-sync.test.mjs'), '动态发现必须至少发现本文件自身')
  assert.ok(testFiles.includes('test/pack-freshness.test.mjs'), '动态发现必须发现打包/新鲜度测试')

  const { missing, differing } = await compareSide(testFiles)
  assert.deepEqual(missing, [], `发行目录缺少这些测试文件（新增测试后没同步过去）：${missing.join('、')}`)
  assert.deepEqual(differing, [], `这些测试文件两边内容不一致（同步之后又改过）：${differing.join('、')}`)
})

test('⑥ SHA256 计算方式可靠：同一份文件算两次一致，差一个字节的合成文件摘要不同', async () => {
  const dir = await mkdtemp(path.join(tmpdir(), 'anti-cheat-hash-'))
  try {
    const a = path.join(dir, 'a.bin')
    const b = path.join(dir, 'b.bin')
    await writeFile(a, Buffer.from([0x41, 0x42, 0x43]))
    await writeFile(b, Buffer.from([0x41, 0x42, 0x44]))

    const digestA = sha256(await readFile(a))
    assert.match(digestA, /^[0-9a-f]{64}$/, 'SHA256 摘要必须是 64 位十六进制')
    assert.equal(digestA, sha256(await readFile(a)), '同一份文件算两次必须一致')
    assert.notEqual(
      digestA, sha256(await readFile(b)),
      '只差一个字节的内容必须算出不同摘要——否则上面几条一致性断言会永远为真（hash 写错导致的假通过）',
    )
    // 对照已知值：SHA256("ABC") = b5d4045c3f466fa91fe2cc6abe79232a1a57cdf104f7a26e716e0a1e2789df78
    assert.equal(digestA, 'b5d4045c3f466fa91fe2cc6abe79232a1a57cdf104f7a26e716e0a1e2789df78',
      '摘要必须等于标准 SHA256 值，而不是某种截断/异或的变体')
  } finally {
    await rm(dir, { recursive: true, force: true })
  }
})
