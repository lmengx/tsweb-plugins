/**
 * 反作弊（anti-cheat）宿主半 —— REST 端点契约测试
 *
 * ══════════ 为什么需要这个文件 ══════════
 * `plugins/anti-cheat/index.js` 是本插件的**唯一宿主入口**：12 条路由、鉴权接线、配置落盘、
 * 下发调度（变更即推 / 连接恢复补推 / 退避重试 / 周期对账）、probe 自证、跨服日志查询与审计。
 * 这些行为一旦坏掉，症状恰恰都是**静默的**（旧版 TsWeb 的教训就在本插件的既有注释里：
 * 「界面显示已启用、实际没生效」、「保存成功但下发永远失败」）。所以本文件把"宿主对外承诺什么"
 * 逐条钉成断言，重点覆盖三类**看不出来就完蛋**的东西：
 *   1. **鉴权接线**：12 条路由必须全部挂 `[verifyAuth(), requireAdmin()]`，且被拒时**业务不执行**
 *      （只断言状态码是不够的：一个"先执行业务再回 403"的实现照样能过状态码断言）。
 *   2. **写路径的完整性**：校验失败必须 400 且**不落盘**；成功必须**落盘 + 归一 + 下发**三件事都发生
 *      （只回 200 不算成功）。
 *   3. **多服语义**：单服动作（scan / check-anomaly / scan-by-id）在"零台/多台且未指定 serverId"时
 *      必须显式失败，绝不替管理员随机挑一台。
 *
 * ══════════ 本机限制（本文件验证不到什么，如实写在这里）══════════
 *   - **没有 TShock / 没有游戏服进程**：所有"服端"行为都来自 `test/support/fake-host.mjs` 的
 *     `makeGameHalf`。因此"服端真的按这份清单去拦包/踢人"这类**运行期事实**无法在这里验证，
 *     本文件只验证**契约层**：宿主发了什么参数（`host.calls`）、拿到服端回包后翻译成什么状态码、
 *     以及宿主自己那一半的账（落盘/审计/版本号/待重试集合）。
 *   - **没有数据库**：检测日志来自假服端的内存数组，SQL 的分页/排序口径不在本文件范围内
 *     （`ORDER BY Id DESC` 只按 C# 侧源码与假服端的行为对齐）。
 *   - **没有浏览器**：`client/` 前端半不在本文件范围内。
 *   - **真实多 fiber 的 inject 时序无法验证**：假宿主用的是真实 cordis `Context`（见 fake-host.mjs:29-39），
 *     但 `inject: ['webServer','auth','servers','tshock','paths']` 的延迟执行顺序、
 *     以及"另一个插件 inject anticheatLog 后能否拿到"的时序，本机无法复现。
 *   - **默认清单资源不可改**：`GET /api/anticheat/defaults` 的 501 分支（index.js:744）要求
 *     `resources/` 读取失败，而本任务不许改生产代码/资源，故该分支**只做源码静态断言**（见下）。
 *
 * 运行：`node test/host-api.test.mjs`（**不要**用 `node --test test/`：本机沙箱不允许管道捕获子进程）
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { access, mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { ACTIONS } from '../audit.js'
import { METHOD_VALUES, PROGRESS_ORDER } from '../config.js'
import { apply, PUSH_DEFAULTS } from '../index.js'
import { makeConfig, makeFakeHost, makeGameHalf, waitFor } from './support/fake-host.mjs'

/** 12 条路由（8 GET + 4 POST）—— index.js:693-904 的注册清单 */
const ROUTES = [
  { method: 'get', path: '/api/anticheat/config' },
  { method: 'get', path: '/api/anticheat/defaults' },
  { method: 'get', path: '/api/anticheat/status' },
  { method: 'get', path: '/api/anticheat/logs' },
  { method: 'get', path: '/api/anticheat/logs/stats' },
  { method: 'get', path: '/api/anticheat/check-anomaly' },
  { method: 'get', path: '/api/anticheat/audit' },
  { method: 'get', path: '/api/anticheat/scan-by-id' },
  { method: 'post', path: '/api/anticheat/config' },
  { method: 'post', path: '/api/anticheat/apply-defaults' },
  { method: 'post', path: '/api/anticheat/push' },
  { method: 'post', path: '/api/anticheat/scan' },
]

const SERVERS = [
  { raw: { id: 's1', name: '一服', host: '127.0.0.1', port: 7777, token: 't1', enabled: true } },
  { raw: { id: 's2', name: '二服', host: '127.0.0.1', port: 7778, token: 't2', enabled: true } },
]

/** apply 的 options.push：reconcileIntervalMs=0 关掉周期对账定时器（index.js:231-234 返回 false） */
const NO_RECONCILE = { reconcileIntervalMs: 0 }

const SNAPSHOT = '/data/anticheat/snapshot'
const LOGS_PATH = '/data/anticheat/logs'
const LOG_PATH = '/data/anticheat/log'

let dir
let seq = 0
/** 每个 boot 都登记 dispose，after 里兜底清掉没被 finally 覆盖的定时器 */
const disposers = []

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), 'anticheat-api-'))
})

after(async () => {
  for (const d of disposers) {
    try {
      d()
    } catch {
      // 清理阶段的异常不该掩盖测试结果
    }
  }
  await rm(dir, { recursive: true, force: true })
})

// ═══════════════════════ 局部辅助（不改共享夹具） ═══════════════════════

/**
 * 包一层假服端的 fetchFor，用于注入共享夹具没有的行为。
 *
 * 为什么需要它：`fake-host.mjs` 的 `makeGameHalf` 只让 `badRequest` 模式对
 * `/data/anticheat/snapshot` 生效（fake-host.mjs:411），而本文件要验证
 * "服端 400 → 宿主 400 且带服端原文"必须能在 `check-anomaly` 上造出 400 才能验证。
 * 任务书允许"在自己的测试文件里写局部辅助函数（例如包一层 postFor 注入行为）"，
 * 所以这里包一层而**不动共享夹具**（其它 agent 也在用它）。
 *
 * @param {object} game      makeGameHalf 的返回值
 * @param {object} overrides { serverId: { pathname: result | (server, params) => result } }
 */
function fetchForWith(game, overrides = {}) {
  return async (server, pathname, params) => {
    const one = overrides[String(server.id)]
    const o = one ? one[pathname] : undefined
    if (o !== undefined) return typeof o === 'function' ? o(server, params) : o
    return game.fetchFor(server, pathname, params)
  }
}

/**
 * 剥掉 JS 源码里的注释（行注释 + 块注释），**保留字符串字面量与模板字面量原文**。
 *
 * 为什么要"剥注释"而不是直接 `src.includes('requireManager')`：
 * 本插件的注释里**故意**提到旧版的 `requireManager`（index.js 的鉴权说明与旧版越权缺陷对照），
 * 直接用 `includes` 会把"注释里的说明文字"当成"代码里用了它"，于是断言既可能假失败、
 * 也可能被"把违规写法藏进注释"误导。剥注释之后断言才是对**代码**的断言。
 *
 * 剥法：字符级扫描 + 模式栈（code / 单引号 / 双引号 / 模板）。
 *   - 模板字面量里遇到 `${` 压入 code 帧，其 `}`（花括号深度归零）弹回模板帧 —— 这是 index.js 里
 *     真实存在的形态（index.js:197 有嵌套模板），naive 的"数反引号"实现会被它带偏；
 *   - 字符串内部的 `//`（例如 URL）在引号帧里被原样保留，不会被当注释。
 *
 * 已知边界：**不处理正则字面量**。被测的 `index.js` 里没有任何包含 `//` 或引号的正则
 * （已逐处核对），所以这里不引入正则识别；若将来源码里出现这类正则，本函数需要同步升级。
 */
function stripComments(src) {
  let out = ''
  /** 帧：code { brace } / sq / dq / tpl */
  const stack = [{ type: 'code', brace: 0 }]
  let i = 0

  while (i < src.length) {
    const f = stack[stack.length - 1]
    const c = src[i]
    const two = src.slice(i, i + 2)

    if (f.type === 'code') {
      if (two === '//') {
        while (i < src.length && src[i] !== '\n') i += 1
        continue
      }
      if (two === '/*') {
        i += 2
        while (i < src.length && src.slice(i, i + 2) !== '*/') {
          if (src[i] === '\n') out += '\n'
          i += 1
        }
        i += 2
        continue
      }
      if (c === "'" || c === '"') {
        stack.push({ type: c === "'" ? 'sq' : 'dq' })
        out += c
        i += 1
        continue
      }
      if (c === '`') {
        stack.push({ type: 'tpl' })
        out += c
        i += 1
        continue
      }
      if (c === '{') {
        f.brace += 1
        out += c
        i += 1
        continue
      }
      if (c === '}') {
        if (f.brace === 0 && stack.length > 1) {
          stack.pop()
          out += c
          i += 1
          continue
        }
        f.brace -= 1
        out += c
        i += 1
        continue
      }
      out += c
      i += 1
      continue
    }

    if (f.type === 'sq' || f.type === 'dq') {
      if (c === '\\') {
        out += c + (src[i + 1] || '')
        i += 2
        continue
      }
      if ((f.type === 'sq' && c === "'") || (f.type === 'dq' && c === '"')) {
        stack.pop()
        out += c
        i += 1
        continue
      }
      out += c
      i += 1
      continue
    }

    // tpl
    if (c === '\\') {
      out += c + (src[i + 1] || '')
      i += 2
      continue
    }
    if (two === '${') {
      stack.push({ type: 'code', brace: 0 })
      out += two
      i += 2
      continue
    }
    if (c === '`') {
      stack.pop()
      out += c
      i += 1
      continue
    }
    out += c
    i += 1
  }
  return out
}

let indexSource = null
/** index.js 的**剥注释后**源码（本文件里所有"源码断言"都用它） */
async function indexCode() {
  if (indexSource === null) {
    const raw = await readFile(new URL('../index.js', import.meta.url), 'utf8')
    indexSource = stripComments(raw)
  }
  return indexSource
}

async function fileExists(p) {
  try {
    await access(p)
    return true
  } catch {
    return false
  }
}

const snapshotCalls = (host) => host.calls.filter((c) => c.pathname === SNAPSHOT)
const callsOf = (host, pathname) => host.calls.filter((c) => c.pathname === pathname)
const configPath = (dataDir) => path.join(dataDir, 'anti-cheat', 'config.json')
const readDiskConfig = async (dataDir) => JSON.parse(await readFile(configPath(dataDir), 'utf8'))

/**
 * 起一个完整的插件实例（照 plugins/task-scheduler/test/host-api.test.mjs:42-49 的装配方式）。
 *
 * `await settleStartup(...)` 是必须的：`index.js:204` 的"宿主启动对账"是**不 await 的异步下发**，
 * 不等它落定就取 `host.calls` 基线，会把启动对账的那几次 `/snapshot` 误算进"本次动作下发了"。
 */
async function boot({ servers = SERVERS, services = {}, fetchOverrides, prep } = {}) {
  seq += 1
  const dataDir = path.join(dir, `case-${seq}`)
  const gameHalf = makeGameHalf({ serverIds: servers.map((s) => s.raw.id) })
  if (prep) prep(gameHalf)
  const host = makeFakeHost({
    dataDir,
    servers,
    postFor: gameHalf.postFor.bind(gameHalf),
    fetchFor: fetchForWith(gameHalf, fetchOverrides),
    services,
  })
  const dispose = await apply(host.ctx, { push: NO_RECONCILE })
  disposers.push(dispose)
  await settleStartup(host, servers.length)
  return { dataDir, host, gameHalf, dispose, svc: host.ctx.anticheatLog._svc }
}

/** 等"宿主启动对账"那次下发落定（每台启用服都会有一次 /snapshot 调用） */
async function settleStartup(host, serverCount) {
  await waitFor(() => snapshotCalls(host).length >= serverCount && host.ctx.anticheatLog._svc.pushStatus.size >= serverCount, {
    label: '宿主启动对账下发完成',
  })
}

// ═══════════════════════ A. 路由清单与鉴权 ═══════════════════════

test('路由清单：恰好 12 条（8 GET + 4 POST），集合与注册列表完全相等', async () => {
  const { host, dispose } = await boot()
  try {
    const got = host.routePaths()
    const expected = {
      get: ROUTES.filter((r) => r.method === 'get').map((r) => r.path),
      post: ROUTES.filter((r) => r.method === 'post').map((r) => r.path),
    }
    // 双向比较：多注册一条（例如调试用的临时端点）也要失败
    assert.deepEqual([...got.get].sort(), [...expected.get].sort(), 'GET 路由集合必须完全相等')
    assert.deepEqual([...got.post].sort(), [...expected.post].sort(), 'POST 路由集合必须完全相等')
    assert.equal(got.get.length, 8)
    assert.equal(got.post.length, 4)
    assert.equal(got.get.length + got.post.length, 12)
    for (const r of ROUTES) assert.ok(host.hasRoute(r.method, r.path), `应注册 ${r.method.toUpperCase()} ${r.path}`)
  } finally {
    dispose()
  }
})

test('路由清单：每条处理函数链长度 >= 3 且前两个是中间件函数（verifyAuth + requireAdmin）', async () => {
  const { host, dispose } = await boot()
  try {
    for (const r of ROUTES) {
      const handlers = host.routeHandlers(r.method, r.path)
      assert.ok(Array.isArray(handlers), `${r.path} 应有处理函数数组`)
      assert.ok(handlers.length >= 3, `${r.method.toUpperCase()} ${r.path} 应是 [verifyAuth, requireAdmin, wrap(fn)] 三段，实际 ${handlers.length} 段`)
      assert.equal(typeof handlers[0], 'function', `${r.path} 第 1 段应是鉴权中间件`)
      assert.equal(typeof handlers[1], 'function', `${r.path} 第 2 段应是鉴权中间件`)
      assert.equal(typeof handlers[handlers.length - 1], 'function', `${r.path} 最后一段应是业务处理函数`)
    }
  } finally {
    dispose()
  }
})

test('剥注释的剥离器自身可信：注释里的 requireManager 被剥掉、字符串里的 // 不被误伤', () => {
  const sample = [
    "const url = 'http://example.com//path'",
    '// 这里说明为什么不用 requireManager',
    '/* requireManager 是旧版更宽的链 */',
    'const t = `外层 ${flag ? `内层` : 0}` // requireManager',
  ].join('\n')
  const code = stripComments(sample)
  assert.equal(code.includes('requireManager'), false, '注释里的出现必须被剥掉（否则"剥注释"就白做了）')
  assert.ok(code.includes("'http://example.com//path'"), '字符串里的 // 不能被当成注释')
  assert.ok(code.includes('内层'), '嵌套模板字面量的内容不能被吃掉')
  assert.ok(code.includes('外层'), '模板字面量原文必须保留')
})

test('源码断言（剥注释后）：admin 链是 verifyAuth + requireAdmin，12 条注册行都挂了 ...admin', async () => {
  const code = await indexCode()

  // ① 唯一的鉴权链定义（index.js:652）
  assert.ok(
    code.includes('const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]'),
    'admin 链必须是 [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]',
  )

  // ② 每一条 app.get/app.post 注册行都必须出现 ...admin
  const found = []
  for (const m of code.matchAll(/app\.(get|post)\('([^']+)'/g)) {
    const nl = code.indexOf('\n', m.index)
    found.push({ method: m[1], path: m[2], line: code.slice(m.index, nl === -1 ? undefined : nl) })
  }
  assert.equal(found.length, 12, `index.js 里应恰好有 12 处 app.get/app.post 注册，实际 ${found.length}`)
  assert.deepEqual(
    found.map((f) => `${f.method} ${f.path}`).sort(),
    ROUTES.map((r) => `${r.method} ${r.path}`).sort(),
  )
  for (const f of found) {
    assert.ok(f.line.includes('...admin'), `${f.method.toUpperCase()} ${f.path} 的注册行必须挂 ...admin：${f.line.trim()}`)
  }

  // ③ 剥注释后的代码里不得出现旧版更宽的 requireManager
  //    （这条正是"剥注释"的意义：注释里**故意**留着对旧版 requireManager 的说明文字）
  assert.equal(code.includes('requireManager'), false, '代码里不得出现 requireManager（注释里提到可以，代码里用它会放子管理员进来）')
})

test('403：/api/anticheat/config 的鉴权在中间件层短路，业务处理函数不执行', async () => {
  const { host, dispose } = await boot()
  try {
    const p = '/api/anticheat/config'
    host.setDeny({ admin: true })
    const res = await host.call('get', p)
    assert.equal(res.status, 403)
    assert.equal(res.data.ok, false)
    assert.ok(String(res.data.error).length > 0, '被拒也要有 error 文案')
    assert.equal(res.businessRan, false, 'requireAdmin 拒绝后业务处理函数不得执行')
    assert.equal(host.businessCount('get', p), 0)

    // 复位后必须恢复正常（证明上面的 403 来自鉴权开关，而不是路由本来就坏）
    host.setDeny({ admin: false, verify: false })
    const back = await host.call('get', p)
    assert.equal(back.status, 200)
    assert.equal(back.data.ok, true)
    assert.equal(back.businessRan, true)
    assert.equal(host.businessCount('get', p), 1)
  } finally {
    dispose()
  }
})

test('403：12 条路由逐条都必须在鉴权层短路（业务一次都不执行）', async () => {
  const { host, dispose } = await boot()
  try {
    host.setDeny({ admin: true })
    const baseline = host.calls.length
    for (const r of ROUTES) {
      const tag = `${r.method.toUpperCase()} ${r.path}`
      const res = await host.call(r.method, r.path, { body: {}, query: {} })
      assert.equal(res.status, 403, `${tag} 应回 403`)
      assert.equal(res.data.ok, false, `${tag} 应回 ok:false`)
      assert.equal(res.businessRan, false, `${tag} 的业务处理函数不得被执行`)
    }
    for (const r of ROUTES) {
      assert.equal(host.businessCount(r.method, r.path), 0, `${r.method.toUpperCase()} ${r.path} 的业务一次都不该跑`)
    }
    // 全程没有**新增**对游戏服的调用（业务没跑的自然结果，顺手钉住）。
    // 基线要取"启动对账"之后的：那一次下发发生在 apply 里（index.js:204），与鉴权无关。
    assert.equal(host.calls.length, baseline, '鉴权全拒时不该有任何新的游戏服调用')
  } finally {
    dispose()
  }
})

test('401：12 条路由逐条都必须在 verifyAuth 层短路（业务一次都不执行）', async () => {
  const { host, dispose } = await boot()
  try {
    host.setDeny({ verify: true, admin: false })
    for (const r of ROUTES) {
      const tag = `${r.method.toUpperCase()} ${r.path}`
      const res = await host.call(r.method, r.path, { body: {}, query: {} })
      assert.equal(res.status, 401, `${tag} 应回 401`)
      assert.equal(res.data.ok, false)
      assert.equal(res.businessRan, false, `${tag} 未登录时业务不得执行`)
      assert.equal(host.businessCount(r.method, r.path), 0)
    }
    host.setDeny({ verify: false })
  } finally {
    dispose()
  }
})

// ═══════════════════════ B1. GET /api/anticheat/config ═══════════════════════

test('GET /config：回全部界面所需字段（清单/统计/进度/默认清单/软依赖/处置方式/快捷命令）', async () => {
  const { host, dispose } = await boot()
  try {
    const res = await host.call('get', '/api/anticheat/config')
    assert.equal(res.status, 200)
    const d = res.data
    assert.equal(d.ok, true)
    for (const k of ['config', 'configFile', 'configError', 'defaultsError', 'warnings', 'stats', 'progressOrder',
      'knownProgress', 'defaults', 'dependencies', 'methodValues', 'methodLabels', 'quickCommands', 'commandPlaceholders']) {
      assert.ok(k in d, `响应应含 ${k}`)
    }
    assert.equal(d.config.item.启用, false, '未配置过时按默认（检测未启用，安全方向）')
    assert.ok(d.configFile.endsWith(path.join('anti-cheat', 'config.json')), d.configFile)
    assert.equal(d.configError, '')
    assert.equal(d.defaultsError, '')
    assert.ok(Array.isArray(d.warnings))
    // 物品与弹幕都未启用 → 必须有一条"检测不会有新记录"的配置级警告（config.js:673-675）
    assert.ok(d.warnings.some((w) => w.includes('都未启用')), JSON.stringify(d.warnings))
    for (const k of ['itemTiers', 'itemEntries', 'projTiers', 'projEntries', 'commandEntries']) {
      assert.equal(typeof d.stats[k], 'number', `stats.${k} 应是数字`)
    }
    assert.equal(d.stats.itemTiers, 0)
    assert.equal(d.stats.itemEntries, 0)
  } finally {
    dispose()
  }
})

test('GET /config：defaults.stats 与 resources/ 里的两份默认清单一致（物品 20 档/120 条、弹幕 11 档/61 条）', async () => {
  const { host, dispose } = await boot()
  try {
    const d = (await host.call('get', '/api/anticheat/config')).data
    const itemFile = JSON.parse(await readFile(new URL('../resources/物品违禁.json', import.meta.url), 'utf8'))
    const projFile = JSON.parse(await readFile(new URL('../resources/弹幕违禁.json', import.meta.url), 'utf8'))
    const count = (json, key) => {
      const tiers = json.限制列表 || []
      return { tiers: tiers.length, entries: tiers.reduce((n, t) => n + ((t[key] || []).length), 0) }
    }
    const item = count(itemFile, '限制物品')
    const proj = count(projFile, '限制弹幕')

    assert.deepEqual(d.defaults.stats, {
      itemTiers: item.tiers, itemEntries: item.entries, projTiers: proj.tiers, projEntries: proj.entries,
    }, 'defaults.stats 必须由 resources/ 实读而来（改资源文件而不改统计即为失败）')
    // 硬编码一份：清单规模被误删时上面那条 deepEqual 会跟着变，这一条不会
    assert.equal(d.defaults.stats.itemTiers, 20)
    assert.equal(d.defaults.stats.itemEntries, 120)
    assert.equal(d.defaults.stats.projTiers, 11)
    assert.equal(d.defaults.stats.projEntries, 61)
    assert.equal(d.defaults.error, '')
    assert.ok(d.defaults.files.item.endsWith('物品违禁.json'), d.defaults.files.item)
    assert.ok(d.defaults.files.proj.endsWith('弹幕违禁.json'), d.defaults.files.proj)
  } finally {
    dispose()
  }
})

test('GET /config：methodValues 是闭集且与 config.js 同源（methodLabels / quickCommands / 占位符配套）', async () => {
  const { host, dispose } = await boot()
  try {
    const d = (await host.call('get', '/api/anticheat/config')).data
    assert.deepEqual(d.methodValues, ['log', 'kick', 'ban', 'drop', 'command'])
    assert.deepEqual(d.methodValues, METHOD_VALUES.slice())
    for (const v of d.methodValues) assert.equal(typeof d.methodLabels[v], 'string', `methodLabels 应含 ${v}`)
    assert.equal(d.quickCommands.length, 4)
    for (const q of d.quickCommands) {
      assert.ok(typeof q.method === 'string' && typeof q.label === 'string' && typeof q.template === 'string')
      assert.ok(d.methodValues.includes(q.method), `快捷命令的 method 必须在闭集内：${q.method}`)
    }
    assert.deepEqual(d.commandPlaceholders, ['{playername}', '{itemname}', '{itemid}', '{projid}'])
  } finally {
    dispose()
  }
})

test('GET /config：knownProgress 与 config.js 的 PROGRESS_ORDER 逐项相等，首项是「始终生效」', async () => {
  const { host, dispose } = await boot()
  try {
    const d = (await host.call('get', '/api/anticheat/config')).data
    assert.deepEqual(d.knownProgress, PROGRESS_ORDER.slice())
    assert.equal(d.knownProgress[0], '始终生效')
    // progressOrder（本次配置派生的顺序）必须以权威顺序开头；"始终生效"语义上永远排第一
    assert.equal(d.progressOrder[0], '始终生效')
    assert.ok(d.progressOrder.length >= d.knownProgress.length)
  } finally {
    dispose()
  }
})

test('GET /config：dependencies 如实反映 itemData/projectileData 是否就绪（软依赖不许写进 inject）', async () => {
  const a = await boot()
  try {
    const d = (await a.host.call('get', '/api/anticheat/config')).data
    assert.deepEqual(d.dependencies, { itemData: false, projectileData: false }, '未注册时必须是 false')
  } finally {
    a.dispose()
  }

  const b = await boot({
    services: {
      itemData: { nameOf: async () => '物品名' },
      projectileData: { nameOf: async () => '弹幕名' },
    },
  })
  try {
    const d = (await b.host.call('get', '/api/anticheat/config')).data
    assert.deepEqual(d.dependencies, { itemData: true, projectileData: true }, '注入后必须是 true')
  } finally {
    b.dispose()
  }
})

// ═══════════════════════ B2. POST /api/anticheat/config ═══════════════════════

test('POST /config：校验失败 → 400 + ok:false + errors 数组 + 文案含「清单校验未通过」，且不落盘', async () => {
  const { dataDir, host, dispose } = await boot()
  try {
    const res = await host.call('post', '/api/anticheat/config', {
      body: { item: { 限制列表: [{ 进度: '始终生效', 限制物品: [{ id: 0, stack: 1, method: 'log' }] }] } },
    })
    assert.equal(res.status, 400)
    assert.equal(res.data.ok, false)
    assert.ok(Array.isArray(res.data.errors) && res.data.errors.length >= 1, JSON.stringify(res.data.errors))
    assert.ok(res.data.errors[0].path.includes('id'), JSON.stringify(res.data.errors[0]))
    assert.ok(res.data.error.includes('清单校验未通过'), res.data.error)
    assert.equal(await fileExists(configPath(dataDir)), false, '校验失败绝不能落盘')
    assert.equal(snapshotCalls(host).length, SERVERS.length, '校验失败绝不能下发（只应有启动对账那几次）')
  } finally {
    dispose()
  }
})

test('POST /config：成功 → 200 + 回 config/warnings/push，并且落盘（内容已归一）', async () => {
  const { dataDir, host, dispose } = await boot()
  try {
    const res = await host.call('post', '/api/anticheat/config', {
      body: {
        item: {
          启用: true,
          自动扫描: true,
          扫描间隔: '10',
          没收违禁物品: false,
          限制列表: [{ 进度: '始终生效', 限制物品: [{ id: 267, stack: '2', method: 'LOG', command: '' }] }],
        },
        proj: { 启用: false, 伤害上限: 20000, 限制列表: [{ 进度: '蜂后', 限制弹幕: [{ id: 108, method: 'ban' }] }] },
      },
    })
    assert.equal(res.status, 200)
    for (const k of ['config', 'warnings', 'push']) assert.ok(k in res.data, `响应应含 ${k}`)
    assert.ok(Array.isArray(res.data.warnings))

    // 归一：'10' → 10、'2' → 2、'LOG' → 'log'
    const cfg = res.data.config
    assert.equal(cfg.item.扫描间隔, 10)
    assert.equal(cfg.item.限制列表[0].限制物品[0].stack, 2)
    assert.equal(cfg.item.限制列表[0].限制物品[0].method, 'log')
    assert.equal(cfg.item.启用, true)

    // 落盘：文件内容与响应里的 config 完全一致（保存响应 = 磁盘真值）
    const disk = await readDiskConfig(dataDir)
    assert.deepEqual(disk, cfg, '落盘内容必须与响应里的归一结果一致')
    assert.equal(disk.item.限制列表.length, 1)

    // 下发：每台启用服都被推了一次（在启动对账之外）
    assert.equal(snapshotCalls(host).length, SERVERS.length * 2, '保存必须立即下发（变更即推）')
    assert.equal(res.data.push.ok, true)
    assert.equal(res.data.push.total, SERVERS.length)
    assert.equal(res.data.push.pendingCount, 0)
    for (const r of res.data.push.results) assert.equal(r.ok, true, `${r.name} 应确认生效`)
    const last = snapshotCalls(host).at(-1)
    assert.equal(typeof last.params.item, 'string', '载荷里的 item 必须是 JSON 字符串（走 form body，不走 URL）')
    assert.ok(JSON.parse(last.params.item).限制列表.length === 1)
    assert.equal(last.params.version, String(res.data.push.version))

    // 统计随之更新（configStats 只在真落盘后重算）
    const st = (await host.call('get', '/api/anticheat/config')).data
    assert.deepEqual(st.stats, { itemTiers: 1, itemEntries: 1, projTiers: 1, projEntries: 1, commandEntries: 0 })

    // 审计：写入动作名与"改了哪些顶层字段"
    const audit = (await host.call('get', '/api/anticheat/audit')).data
    const rec = audit.rows.find((r) => r.action === ACTIONS.configSet)
    assert.ok(rec, JSON.stringify(audit.rows))
    assert.equal(rec.actor, 'tester')
    assert.ok(rec.changedKeys.includes('item.启用'), JSON.stringify(rec.changedKeys))
    assert.ok(rec.after && typeof rec.after.itemEntries === 'number')
  } finally {
    dispose()
  }
})

test('POST /config：body 才是配置来源，query 里的 config 完全不生效（旧版 D-8 的修法）', async () => {
  const { dataDir, host, dispose } = await boot()
  try {
    const queryConfig = JSON.stringify({
      item: { 启用: true, 限制列表: [{ 进度: '始终生效', 限制物品: [{ id: 267, stack: 1, method: 'ban' }] }] },
    })
    const res = await host.call('post', '/api/anticheat/config', {
      query: { config: queryConfig, item: queryConfig },
      body: {},
    })
    assert.equal(res.status, 200)
    assert.equal(res.data.config.item.启用, false, 'query 里的 启用=true 不得生效')
    assert.equal(res.data.config.item.限制列表.length, 0, 'query 里的清单不得生效')
    const disk = await readDiskConfig(dataDir)
    assert.equal(disk.item.启用, false)
    assert.equal(disk.item.限制列表.length, 0)
  } finally {
    dispose()
  }
})

test('POST /config：旧版裸命令模板要迁移成 method=command 且命令文本必须保留（见报告 D-A）', async () => {
  const { dataDir, host, dispose } = await boot()
  try {
    const res = await host.call('post', '/api/anticheat/config', {
      body: { item: { 限制列表: [{ 进度: '始终生效', 限制物品: [{ id: 267, stack: 1, method: 'bc hello' }] }] } },
    })
    assert.equal(res.status, 200)
    // 迁移警告必须先出现（否则下面的断言失败会让人误以为是"根本没迁移"）
    assert.ok(res.data.warnings.some((w) => w.includes('旧版自由文本')), JSON.stringify(res.data.warnings))

    const entry = (await readDiskConfig(dataDir)).item.限制列表[0].限制物品[0]
    assert.equal(entry.method, 'command', '非闭集 method 必须收敛为 command')
    // 正确行为：旧版裸模板 '/bc hello' 必须被保留进 command（config.js:437-438 的迁移就是为它设计的）。
    // 当前实现取的是 entry.command（提交里没有这个字段）而不是迁移结果 m.command，于是命令文本被丢掉，
    // 而警告文案却声称"已迁移为 command=\"bc hello\""（config.js:432-435）——文案与落盘不一致。
    assert.equal(entry.command, '/bc hello', '迁移后的命令文本不得丢失（normalizeCommand 会同时补上 /）')
  } finally {
    dispose()
  }
})

// ═══════════════════════ B3. GET /api/anticheat/defaults ═══════════════════════

test('GET /defaults：回 stats/files/fixes/deferred/warnings/preview，数据修复与延后决策逐条留痕', async () => {
  const { host, dispose } = await boot()
  try {
    const res = await host.call('get', '/api/anticheat/defaults')
    assert.equal(res.status, 200)
    const d = res.data
    for (const k of ['stats', 'files', 'fixes', 'deferred', 'warnings', 'error', 'preview']) {
      assert.ok(k in d, `响应应含 ${k}`)
    }
    assert.equal(d.error, '')
    assert.equal(d.stats.itemTiers, 20)
    assert.equal(d.stats.projEntries, 61)
    assert.deepEqual(d.fixes.map((f) => f.id), ['D-28', 'D-32', 'D-27', 'D-30'], '本次补齐的数据缺陷必须逐条可见')
    assert.deepEqual(d.deferred.map((f) => f.id), ['D-29', 'D-31', 'D-33'], '未采纳的必须留痕（否则无从核对"补齐了哪些"）')
    for (const f of d.fixes) {
      assert.ok(typeof f.scope === 'string' && typeof f.what === 'string' && typeof f.why === 'string', JSON.stringify(f))
    }
    for (const f of d.deferred) {
      assert.ok(typeof f.decision === 'string' && typeof f.detail === 'string', JSON.stringify(f))
    }
    assert.ok(Array.isArray(d.warnings))

    // preview：两侧都在（默认 scope=both）。
    // 注意：需求书写的是 preview.scope==='both'，而实现里 previewDefaults（defaults.js:205-208）
    // 返回的是 normalizeScope() 的**结果数组**，both 即 ['item','proj']。按实现的契约断言，
    // 并把 kinds 的两侧键一起钉住，语义上与"both"等价。
    assert.deepEqual(d.preview.scope, ['item', 'proj'])
    assert.deepEqual(Object.keys(d.preview.kinds).sort(), ['item', 'proj'])
    assert.deepEqual(d.preview.kinds.item.档位_应用后.length, 20)
    assert.ok(Array.isArray(d.preview.kinds.item.新增档位))
    assert.deepEqual(d.preview.kinds.item.开关变化, [], '默认预览不动开关，开关变化必须是空数组')
    assert.ok(Array.isArray(d.preview.progressOrder))
  } finally {
    dispose()
  }
})

test('源码断言：GET /defaults 与 POST /apply-defaults 都有「默认清单不可用 → 501」的明确失败分支', async () => {
  // 为什么只能静态断言：触发 501 需要 resources/ 两份清单读失败（defaults.js:144-171），
  // 而 resources/ 是只读资源、本任务禁止改生产代码，运行期造不出这个状态。
  // 于是这里断言"分支确实存在且文案正确"，并在交付报告里如实声明这条只做了静态验证。
  const code = await indexCode()
  const hits = code.split('httpError(501,').length - 1
  assert.equal(hits, 2, 'GET /defaults 与 POST /apply-defaults 各应有一处 501 分支')
  let idx = code.indexOf('httpError(501,')
  while (idx !== -1) {
    const around = code.slice(idx, idx + 60)
    assert.ok(around.includes('默认清单不可用'), `501 的文案必须写明原因：${around}`)
    idx = code.indexOf('httpError(501,', idx + 1)
  }
  // 绝不回一个"空清单"让管理员点下去把配置清空（index.js:743-745 的注释就是这条）：
  // 501 分支必须是 throw，而不是"回一个 error 字段但继续往下走"。
  assert.equal(code.includes('throw httpError(501,'), true, '读不到默认清单必须抛错打断，绝不能带着空清单继续')
})

// ═══════════════════════ B4. POST /api/anticheat/apply-defaults ═══════════════════════

test('POST /apply-defaults：不传 confirm → 只预览（不写盘、不下发），note 说明这是预览', async () => {
  const { dataDir, host, dispose } = await boot()
  try {
    const before = snapshotCalls(host).length
    const res = await host.call('post', '/api/anticheat/apply-defaults', { body: { scope: 'item' } })
    assert.equal(res.status, 200)
    assert.equal(res.data.applied, false)
    assert.ok(res.data.note.includes('预览'), res.data.note)
    assert.ok(res.data.preview, '预览内容必须回给管理员看')
    assert.deepEqual(res.data.preview.scope, ['item'])
    assert.equal(await fileExists(configPath(dataDir)), false, '预览不得写盘')
    assert.equal(snapshotCalls(host).length, before, '预览不得下发')
    assert.equal(res.data.changes, undefined, '预览不该给出 changes（那是应用后的改动摘要）')
  } finally {
    dispose()
  }
})

test('POST /apply-defaults：confirm=true → applied + changes 摘要 + 落盘 + 立即下发', async () => {
  const { dataDir, host, dispose } = await boot()
  try {
    const before = snapshotCalls(host).length
    const res = await host.call('post', '/api/anticheat/apply-defaults', { body: { scope: 'item', confirm: true } })
    assert.equal(res.status, 200)
    assert.equal(res.data.applied, true)
    assert.ok(Array.isArray(res.data.changes) && res.data.changes.length >= 1, JSON.stringify(res.data.changes))
    const chg = res.data.changes.find((c) => c.kind === 'item')
    assert.ok(chg, JSON.stringify(res.data.changes))
    assert.equal(chg.档位, '0 → 20')
    assert.equal(chg.条数, '0 → 120')

    const disk = await readDiskConfig(dataDir)
    assert.equal(disk.item.限制列表.length, 20)
    assert.equal(disk.item.限制列表.reduce((n, t) => n + t.限制物品.length, 0), 120)
    assert.equal(snapshotCalls(host).length, before + SERVERS.length, '应用默认配置必须立即下发到每台启用服')
    assert.equal(res.data.push.total, SERVERS.length)

    const audit = (await host.call('get', '/api/anticheat/audit')).data
    const rec = audit.rows.find((r) => r.action === ACTIONS.configApplyDefaults)
    assert.ok(rec, JSON.stringify(audit.rows))
    assert.deepEqual(rec.scope, ['item'])
    assert.equal(rec.includeSwitches, false)
    assert.deepEqual(rec.dataFixes, ['D-28', 'D-32', 'D-27', 'D-30'])
    assert.ok(rec.defaultsStats && rec.defaultsStats.itemEntries === 120)
  } finally {
    dispose()
  }
})

test('POST /apply-defaults：scope=item 时弹幕侧原样保留（旧版是两侧独立下发）', async () => {
  const { dataDir, host, dispose } = await boot()
  try {
    const submitted = makeConfig({
      item: { 启用: true },
      proj: { 启用: true, 伤害上限: 12345, 限制列表: [{ 进度: '始终生效', 限制弹幕: [{ id: 108, method: 'ban' }] }] },
    })
    const saved = await host.call('post', '/api/anticheat/config', { body: submitted })
    assert.equal(saved.status, 200)
    const projBefore = saved.data.config.proj

    const res = await host.call('post', '/api/anticheat/apply-defaults', { body: { scope: 'item', confirm: true } })
    assert.equal(res.data.applied, true)
    const disk = await readDiskConfig(dataDir)
    assert.deepEqual(disk.proj, projBefore, 'scope=item 时弹幕侧必须逐字段原样保留')
    assert.equal(disk.item.限制列表.length, 20, '物品侧应被默认清单替换')
  } finally {
    dispose()
  }
})

test('POST /apply-defaults：默认不动开关（旧版会把没收违禁物品静默关掉），includeSwitches=true 才动', async () => {
  const { dataDir, host, dispose } = await boot()
  try {
    await host.call('post', '/api/anticheat/config', {
      body: makeConfig({ item: { 启用: true, 没收违禁物品: true, 扫描间隔: 30 }, proj: { 启用: true } }),
    })

    // ① 预览必须先说明"开关会变"（before includeSwitches 生效之前取，否则看不出差异）
    const pvOff = await host.call('post', '/api/anticheat/apply-defaults', { body: {} })
    assert.deepEqual(pvOff.data.preview.kinds.item.开关变化, [], '默认预览不列开关变化（因为默认不动开关）')
    const pvOn = await host.call('post', '/api/anticheat/apply-defaults', { body: { includeSwitches: true } })
    assert.equal(pvOn.data.applied, false)
    assert.ok(pvOn.data.preview.kinds.item.开关变化.length >= 1, JSON.stringify(pvOn.data.preview.kinds.item))
    assert.ok(
      pvOn.data.preview.kinds.item.开关变化.some((d) => d.字段 === '启用' && d.现在 === true && d.应用后 === false),
      JSON.stringify(pvOn.data.preview.kinds.item.开关变化),
    )

    // ② 默认应用：开关保持现值（只有限制列表被替换）
    await host.call('post', '/api/anticheat/apply-defaults', { body: { confirm: true } })
    let disk = await readDiskConfig(dataDir)
    assert.equal(disk.item.启用, true)
    assert.equal(disk.item.没收违禁物品, true, '已开启的没收不得被静默重置（旧版 D-6 的形态）')
    assert.equal(disk.item.扫描间隔, 30)
    assert.equal(disk.proj.启用, true)

    // ③ includeSwitches=true：这才按默认清单改开关，并且改动必须出现在 changes 里
    const res = await host.call('post', '/api/anticheat/apply-defaults', { body: { confirm: true, includeSwitches: true } })
    disk = await readDiskConfig(dataDir)
    assert.equal(disk.item.启用, false)
    assert.equal(disk.item.没收违禁物品, false)
    assert.equal(disk.item.扫描间隔, 10)
    const sw = res.data.changes.filter((c) => c.字段)
    assert.ok(sw.some((c) => c.字段 === '启用' && c.从 === true && c.到 === false), JSON.stringify(res.data.changes))
  } finally {
    dispose()
  }
})

// ═══════════════════════ B5. GET /api/anticheat/status ═══════════════════════

test('GET /status：回状态卡的完整字段，servers 按名称排序', async () => {
  const { host, dispose } = await boot()
  try {
    const res = await host.call('get', '/api/anticheat/status')
    assert.equal(res.status, 200)
    const d = res.data
    for (const k of ['desiredVersion', 'configRevision', 'configFile', 'configError', 'defaultsError', 'warnings',
      'stats', 'progressOrder', 'intervals', 'servers', 'pendingCount', 'pendingServerIds', 'retryScheduled', 'probe']) {
      assert.ok(k in d, `响应应含 ${k}`)
    }
    assert.equal(d.pendingCount, 0)
    assert.deepEqual(d.pendingServerIds, [])
    assert.equal(d.retryScheduled, false)
    assert.equal(d.desiredVersion >= 1, true, '启动对账已经下发过一次')
    // reconcileIntervalMs 被 apply 的 options.push 覆盖成 0（关掉周期对账），如实回显
    assert.equal(d.intervals.reconcileIntervalMs, 0)
    assert.equal(d.intervals.retryIntervalMs, 60000)

    const names = d.servers.map((s) => s.name)
    assert.equal(names.length, SERVERS.length)
    assert.deepEqual(names, [...names].sort((a, b) => String(a).localeCompare(String(b))), 'servers 必须按 name 排序')
    for (const s of d.servers) {
      assert.ok(s.id && s.name && typeof s.ok === 'boolean')
    }
  } finally {
    dispose()
  }
})

test('GET /status：probe 自证——服端与宿主一致时 match=true 且 diff 为空；被改坏时 diff 点名差异', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    // ① 保存一份配置（会立即下发），服端此刻与宿主一致
    await host.call('post', '/api/anticheat/config', { body: makeConfig({ item: { 启用: true, 扫描间隔: 20 } }) })
    let d = (await host.call('get', '/api/anticheat/status')).data
    assert.equal(d.probe.servers.length, 2)
    for (const s of d.probe.servers) {
      assert.equal(s.ok, true)
      assert.equal(s.match, true, `${s.name} 应判定为一致：${JSON.stringify(s.diff)}`)
      assert.deepEqual(s.diff, [])
      assert.equal(s.error, '')
      assert.equal(s.source, 'rest', '服端自证来源：REST 下发')
      assert.ok(s.file.endsWith('config.json'))
    }

    // ② 手工把服端配置改成别的（模拟"服端配置文件被人删改/重置"）
    gameHalf.setAppliedConfig('s1', { item: { 启用: true, 扫描间隔: 99, 限制列表: [] }, proj: { 启用: false, 伤害上限: 20000, 限制列表: [] } })
    d = (await host.call('get', '/api/anticheat/status')).data
    const s1 = d.probe.servers.find((s) => s.id === 's1')
    const s2 = d.probe.servers.find((s) => s.id === 's2')
    assert.equal(s1.match, false)
    assert.ok(s1.diff.length >= 1, JSON.stringify(s1.diff))
    assert.ok(s1.diff.some((x) => x.includes('扫描间隔')), JSON.stringify(s1.diff))
    assert.ok(s1.diff.some((x) => x.includes('清单不一致')), JSON.stringify(s1.diff))
    assert.equal(s2.match, true, '没被改的那台不该被牵连')
  } finally {
    dispose()
  }
})

test('GET /status：serverIds 过滤 probe 目标（逗号分隔）', async () => {
  const { host, dispose } = await boot()
  try {
    const d = (await host.call('get', '/api/anticheat/status', { query: { serverIds: 's2' } })).data
    assert.deepEqual(d.probe.servers.map((s) => s.id), ['s2'])
    // 但状态卡本身仍是全量（probe 只是"自证"，不改变状态语义）
    assert.equal(d.servers.length, 2)
  } finally {
    dispose()
  }
})

// ═══════════════════════ B6. POST /api/anticheat/push ═══════════════════════

test('POST /push：serverIds 超过 50 台 → 400 + 文案含「上限」', async () => {
  const { host, dispose } = await boot()
  try {
    const res = await host.call('post', '/api/anticheat/push', {
      body: { serverIds: Array.from({ length: 51 }, (_, i) => `x${i}`) },
    })
    assert.equal(res.status, 400)
    assert.equal(res.data.ok, false)
    assert.ok(res.data.error.includes('上限'), res.data.error)
    assert.equal(snapshotCalls(host).length, SERVERS.length, '被拒绝的请求不得下发')
  } finally {
    dispose()
  }
})

test('POST /push：serverIds=[] 的语义是「明确不下发」（见报告 D-B）', async () => {
  const { host, dispose } = await boot()
  try {
    const before = snapshotCalls(host).length
    const res = await host.call('post', '/api/anticheat/push', { body: { serverIds: [] } })
    assert.equal(res.status, 200)
    // index.js:804 的注释明确写「[] = 明确"不下发"」，与宿主侧既有的空数组语义一致。
    // 当前实现把 [] 当成"未指定"（index.js:310 的 serverIds.length > 0 判定），于是推给了全部启用服。
    assert.equal(snapshotCalls(host).length, before, 'serverIds=[] 不得下发到任何服务器')
    assert.equal(res.data.push.total, 0, '回包也必须如实说"一台都没推"')
  } finally {
    dispose()
  }
})

test('POST /push：不传 serverIds → 下发给全部启用服，并逐服回结果', async () => {
  const { host, dispose } = await boot()
  try {
    const before = snapshotCalls(host).length
    const res = await host.call('post', '/api/anticheat/push', { body: {} })
    assert.equal(res.status, 200)
    assert.equal(res.data.push.total, 2)
    assert.equal(res.data.push.ok, true)
    assert.deepEqual(res.data.push.results.map((r) => r.id).sort(), ['s1', 's2'])
    assert.equal(snapshotCalls(host).length, before + 2)
    // 只推指定的几台
    const one = await host.call('post', '/api/anticheat/push', { body: { serverIds: ['s2'] } })
    assert.deepEqual(one.data.push.results.map((r) => r.id), ['s2'])
    assert.equal(one.data.push.total, 1)
  } finally {
    dispose()
  }
})

test('POST /push：onlyPending=true 只推未确认的服务器（失败的那台）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setBehavior('s2', 'missing')
    const all = await host.call('post', '/api/anticheat/push', { body: {} })
    assert.equal(all.data.push.pendingCount, 1)
    const failed = all.data.push.results.find((r) => r.id === 's2')
    assert.equal(failed.ok, false)
    assert.equal(failed.serverHalfMissing, true)
    assert.ok(failed.error.includes('AntiCheat.dll'), failed.error)

    const before = snapshotCalls(host).length
    const res = await host.call('post', '/api/anticheat/push', { body: { onlyPending: true } })
    assert.equal(res.status, 200)
    assert.deepEqual(res.data.push.results.map((r) => r.id), ['s2'], '只该补推未确认的那台')
    assert.equal(snapshotCalls(host).length, before + 1, '已确认的 s1 不该被再推一次')
  } finally {
    dispose()
  }
})

// ═══════════════════════ B7. GET /api/anticheat/logs ═══════════════════════

test('GET /logs：传给服端的参数形状恰好是旧版协议那 8 个键', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.addLog('s1', { id: 1, category: 'item' })
    gameHalf.addLog('s2', { id: 2, category: 'proj' })
    const res = await host.call('get', '/api/anticheat/logs', {
      query: { page: '2', pageSize: '10', category: 'item', method: 'log', player: '玩家A', q: 'x', timeFrom: '2026-01-01', timeTo: '2026-01-02' },
    })
    assert.equal(res.status, 200)
    const calls = callsOf(host, LOGS_PATH)
    assert.equal(calls.length, 2, '两台启用服各查一次')
    assert.ok(calls.every((c) => c.via === 'fetchFor'), '日志查询走 GET（fetchFor）')
    for (const c of calls) {
      assert.deepEqual(
        Object.keys(c.params).sort(),
        ['category', 'method', 'page', 'pageSize', 'player', 'q', 'timeFrom', 'timeTo'],
        '参数键必须与服端 GetLogsApi 逐字对齐（多一个少一个都不行）',
      )
      assert.equal(c.params.page, 2)
      assert.equal(c.params.pageSize, 10)
      assert.equal(c.params.category, 'item')
      assert.equal(c.params.method, 'log')
      assert.equal(c.params.player, '玩家A')
      assert.equal(c.params.q, 'x')
      // 只给日期时必须补时分秒，否则当天记录会被整段排除（logs.js:132-147）
      assert.equal(c.params.timeFrom, '2026-01-01 00:00:00')
      assert.equal(c.params.timeTo, '2026-01-02 23:59:59')
    }
    assert.equal(res.data.range.expanded, true)
  } finally {
    dispose()
  }
})

test('GET /logs：aggregate=0 / false 视为「关」，其余（含未传）按聚合处理', async () => {
  const { host, svc, dispose } = await boot()
  try {
    // 直接观测路由解析出来的 aggregate（不是看响应文案）：
    // 路由把解析结果交给 service.queryLogs（index.js:816-827），这里包一层记录入参。
    const orig = svc.queryLogs.bind(svc)
    const seen = []
    svc.queryLogs = async (query) => {
      seen.push(query)
      return orig(query)
    }
    try {
      await host.call('get', '/api/anticheat/logs', { query: { aggregate: '0' } })
      await host.call('get', '/api/anticheat/logs', { query: { aggregate: 'false' } })
      await host.call('get', '/api/anticheat/logs', { query: { aggregate: '1' } })
      await host.call('get', '/api/anticheat/logs', {})
    } finally {
      svc.queryLogs = orig
    }
    assert.equal(seen[0].aggregate, false, 'aggregate=0 视为关')
    assert.equal(seen[1].aggregate, false, 'aggregate=false 视为关')
    assert.equal(seen[2].aggregate, true, 'aggregate=1 视为开')
    assert.equal(seen[3].aggregate, false, '未传时按 false（随后由 resolveLogTargets/logs.js 按台数决定是否聚合）')

    // 多台服时结果固定标注为近似（scatter-gather），界面必须能标出来
    const multi = (await host.call('get', '/api/anticheat/logs', {})).data
    assert.equal(multi.approximate, true)
    assert.equal(multi.orderBasis, 'time-merge')
    assert.equal(multi.timeBasis, 'server-local')
    assert.ok(multi.note.includes('已合并 2 台'), multi.note)
    assert.equal(multi.servers.length, 2)
  } finally {
    dispose()
  }
})

test('GET /logs：指定 serverId → 单服精确（approximate=false，orderBasis=Id），并写审计', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.addLog('s1', { id: 1, category: 'item' })
    gameHalf.addLog('s2', { id: 9, category: 'item' })
    const res = await host.call('get', '/api/anticheat/logs', { query: { serverId: 's1', category: 'item' } })
    assert.equal(res.status, 200)
    assert.equal(res.data.approximate, false)
    assert.equal(res.data.orderBasis, 'Id')
    assert.equal(res.data.timeBasis, 'server-local')
    assert.equal(res.data.rows.length, 1)
    assert.equal(res.data.rows[0].serverId, 's1')
    assert.equal(callsOf(host, LOGS_PATH).length, 1, '指定单服时只查那一台')

    // 查询本身会暴露全服玩家行为 → 必须留痕（index.js:829-834）
    await waitFor(async () => {
      const a = await host.call('get', '/api/anticheat/audit')
      return a.data.rows.some((r) => r.action === ACTIONS.logsQuery)
    }, { label: '日志查询审计写入' })
    const audit = (await host.call('get', '/api/anticheat/audit')).data
    const rec = audit.rows.find((r) => r.action === ACTIONS.logsQuery)
    assert.equal(rec.actor, 'tester')
    assert.equal(rec.serverId, 's1')
    assert.equal(rec.total, 1)
    assert.equal(rec.filters.category, 'item')
    assert.equal(rec.filters.method, '')
    assert.equal(rec.filters.hasPlayer, false)
    assert.equal(rec.filters.timeFrom, '')
  } finally {
    dispose()
  }
})

// ═══════════════════════ B8. GET /api/anticheat/logs/stats ═══════════════════════

test('GET /logs/stats：字段齐全，多台服逐服求和，scope 如实标注', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.addLog('s1', { id: 1, category: 'item', method: 'log' })
    gameHalf.addLog('s1', { id: 2, category: 'item', method: 'kick' })
    gameHalf.addLog('s2', { id: 1, category: 'proj', method: 'ban' })
    const res = await host.call('get', '/api/anticheat/logs/stats', {})
    assert.equal(res.status, 200)
    const d = res.data
    for (const k of ['total', 'today', 'byCategory', 'byMethod', 'recent', 'perServer', 'filtered', 'scope']) {
      assert.ok(k in d, `响应应含 ${k}`)
    }
    assert.equal(d.total, 3)
    assert.equal(d.today, 3)
    assert.deepEqual(d.byCategory, { item: 2, proj: 1 })
    assert.deepEqual(d.byMethod, { log: 1, kick: 1, ban: 1 })
    assert.ok(Array.isArray(d.recent) && d.recent.length >= 1)
    assert.equal(d.scope, 'all-servers')
    assert.equal(d.filtered, false, '没有任何筛选参数时 filtered 为 false')
    assert.equal(d.approximateRecent, true, '多台服的 recent 是近似（各服最近 10 条归并）')
    assert.equal(d.perServer.length, 2)

    const filtered = (await host.call('get', '/api/anticheat/logs/stats', { query: { category: 'item' } })).data
    assert.equal(filtered.filtered, true)
    assert.equal(filtered.total, 2)
    assert.deepEqual(filtered.byCategory, { item: 2 })
  } finally {
    dispose()
  }
})

// ═══════════════════════ B9. GET /api/anticheat/check-anomaly ═══════════════════════

test('GET /check-anomaly：id 缺失/非正整数 → 400 且文案点名 id', async () => {
  const { host, dispose } = await boot({ servers: [SERVERS[0]] })
  try {
    for (const query of [{}, { id: 'abc', stack: '1' }, { id: '0', stack: '1' }, { id: '-3', stack: '1' }, { id: '1.5', stack: '1' }]) {
      const res = await host.call('get', '/api/anticheat/check-anomaly', { query })
      assert.equal(res.status, 400, JSON.stringify(query))
      assert.ok(res.data.error.includes('id'), res.data.error)
      assert.equal(res.data.ok, false)
    }
    assert.equal(callsOf(host, '/data/anticheat/check-anomaly').length, 0, '参数不合法时不该打扰游戏服')
  } finally {
    dispose()
  }
})

test('GET /check-anomaly：stack 缺失/负数 → 400', async () => {
  const { host, dispose } = await boot({ servers: [SERVERS[0]] })
  try {
    for (const query of [{ id: '267' }, { id: '267', stack: 'abc' }, { id: '267', stack: '-1' }]) {
      const res = await host.call('get', '/api/anticheat/check-anomaly', { query })
      assert.equal(res.status, 400, JSON.stringify(query))
      assert.ok(res.data.error.includes('stack'), res.data.error)
    }
    assert.equal(callsOf(host, '/data/anticheat/check-anomaly').length, 0)
  } finally {
    dispose()
  }
})

test('GET /check-anomaly：多台启用服且未指定 serverId → 400，文案要求显式指定', async () => {
  const { host, dispose } = await boot()
  try {
    const res = await host.call('get', '/api/anticheat/check-anomaly', { query: { id: '267', stack: '3' } })
    assert.equal(res.status, 400)
    assert.ok(res.data.error.includes('请显式指定 serverId'), res.data.error)
    assert.ok(res.data.error.includes('2'), res.data.error)
    assert.equal(callsOf(host, '/data/anticheat/check-anomaly').length, 0, '不得替管理员随机挑一台')
  } finally {
    dispose()
  }
})

test('GET /check-anomaly：指定 serverId → 透传服端真实判定，并附 serverId/serverName', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setAnomaly(267, { allowedStack: 1, method: 'ban', progress: ['始终生效'], itemName: '可疑物品' })
    const res = await host.call('get', '/api/anticheat/check-anomaly', { query: { id: '267', stack: '3', serverId: 's1' } })
    assert.equal(res.status, 200)
    const d = res.data
    assert.equal(d.id, 267)
    assert.equal(d.stack, 3)
    assert.equal(d.anomaly, true, '旧版这个端点恒 false（C# 从未注册），本件必须回真实判定')
    assert.equal(d.inConfig, true)
    assert.equal(d.allowedStack, 1)
    assert.equal(d.method, 'ban')
    assert.equal(d.itemName, '可疑物品')
    assert.deepEqual(d.progress, ['始终生效'])
    assert.equal(d.matched.length, 1)
    assert.equal(d.matched[0].进度, '始终生效')
    assert.equal(d.effectiveEntries, 1)
    assert.equal(d.serverId, 's1')
    assert.equal(d.serverName, '一服')
    const call = callsOf(host, '/data/anticheat/check-anomaly').at(-1)
    assert.equal(call.via, 'fetchFor')
    assert.deepEqual(call.params, { id: '267', stack: '3' })
    assert.equal(call.serverId, 's1')

    // 不在清单里：allowedStack/method 必须是 null（而不是 0/"log"，那会被误读成"限制 0 个"）
    const none = await host.call('get', '/api/anticheat/check-anomaly', { query: { id: '999', stack: '3', serverId: 's1' } })
    assert.equal(none.data.anomaly, false)
    assert.equal(none.data.inConfig, false)
    assert.equal(none.data.allowedStack, null)
    assert.equal(none.data.method, null)
    assert.equal(none.data.itemName, null)
  } finally {
    dispose()
  }
})

test('GET /check-anomaly：服端 400 → 宿主 400 且带服端原文（不让管理员只看到"游戏服返回异常"）', async () => {
  const { host, dispose } = await boot({
    servers: [SERVERS[0]],
    fetchOverrides: {
      s1: {
        '/data/anticheat/check-anomaly': { ok: false, status: 400, data: { error: 'stack 超出上限（服端原文）' } },
      },
    },
  })
  try {
    const res = await host.call('get', '/api/anticheat/check-anomaly', { query: { id: '267', stack: '99999', serverId: 's1' } })
    assert.equal(res.status, 400)
    assert.equal(res.data.ok, false)
    assert.ok(res.data.error.includes('stack 超出上限（服端原文）'), res.data.error)
  } finally {
    dispose()
  }
})

// ═══════════════════════ B10. GET /api/anticheat/audit ═══════════════════════

test('GET /audit：limit 生效（limit=1 只回 1 条），无 limit 默认 50', async () => {
  const { host, svc, dispose } = await boot()
  try {
    // 直接用插件自己的 AuditLog 追加 60 条（避免为了造数据而做 60 次配置保存 + 下发）
    for (let i = 0; i < 60; i += 1) {
      await svc.audit.append(ACTIONS.configSet, { actor: `t${i}`, seq: i })
    }
    const one = await host.call('get', '/api/anticheat/audit', { query: { limit: '1' } })
    assert.equal(one.status, 200)
    assert.equal(one.data.rows.length, 1)
    const all = await host.call('get', '/api/anticheat/audit')
    assert.equal(all.data.rows.length, 50, '无 limit 默认 50（audit.js:73 的上限是 1000）')
    assert.ok(all.data.rows[0].t, '审计行必须带时间戳')
    assert.equal(all.data.rows[0].action, ACTIONS.configSet)
  } finally {
    dispose()
  }
})

// ═══════════════════════ B11. POST /api/anticheat/scan ═══════════════════════

test('POST /scan：多台未指定 serverId → 400；serverId 不存在 → 404', async () => {
  const { host, dispose } = await boot()
  try {
    const many = await host.call('post', '/api/anticheat/scan', { body: {} })
    assert.equal(many.status, 400)
    assert.ok(many.data.error.includes('请显式指定 serverId'), many.data.error)
    assert.equal(callsOf(host, '/data/anticheat/scan').length, 0)

    const nope = await host.call('post', '/api/anticheat/scan', { body: { serverId: 'nope' } })
    assert.equal(nope.status, 404)
    assert.ok(nope.data.error.includes('不存在'), nope.data.error)
    assert.equal(callsOf(host, '/data/anticheat/scan').length, 0)
  } finally {
    dispose()
  }
})

test('POST /scan：成功 → 回 scan 结构 + serverId/serverName，并写审计（这个动作会真的执行处置）', async () => {
  const { host, dispose } = await boot()
  try {
    const res = await host.call('post', '/api/anticheat/scan', { body: { serverId: 's1' } })
    assert.equal(res.status, 200)
    assert.equal(res.data.serverId, 's1')
    assert.equal(res.data.serverName, '一服')
    assert.equal(res.data.scan.scannedPlayers, 2)
    assert.equal(res.data.scan.violationCount, 2)
    assert.equal(res.data.scan.count, 2)
    assert.ok(Array.isArray(res.data.scan.players))
    assert.equal(typeof res.data.scan.durationMs, 'number')
    const call = callsOf(host, '/data/anticheat/scan').at(-1)
    assert.equal(call.via, 'fetchFor')
    assert.equal(call.serverId, 's1')

    const audit = (await host.call('get', '/api/anticheat/audit')).data
    const rec = audit.rows.find((r) => r.action2 === 'scan')
    assert.ok(rec, JSON.stringify(audit.rows))
    assert.equal(rec.serverId, 's1')
    assert.equal(rec.scannedPlayers, 2)
    assert.equal(rec.violationCount, 2)
    assert.equal(rec.action, ACTIONS.configSet, '动作名仍是 config.set，scan 只作为附加标记 action2')
  } finally {
    dispose()
  }
})

// ═══════════════════════ B12. GET /api/anticheat/scan-by-id ═══════════════════════

test('GET /scan-by-id：itemId 非法 → 400；成功 → 回 players/count/scannedPlayers/durationMs', async () => {
  const { host, gameHalf, dispose } = await boot({ servers: [SERVERS[0]] })
  try {
    for (const itemId of [undefined, '', 'abc', '0', '-1', '1.5']) {
      const res = await host.call('get', '/api/anticheat/scan-by-id', { query: { itemId, serverId: 's1' } })
      assert.equal(res.status, 400, String(itemId))
      assert.ok(res.data.error.includes('itemId'), res.data.error)
    }
    assert.equal(callsOf(host, '/data/anticheat/scan-by-id').length, 0)

    const ok = await host.call('get', '/api/anticheat/scan-by-id', { query: { itemId: '267', serverId: 's1' } })
    assert.equal(ok.status, 200)
    assert.equal(ok.data.serverId, 's1')
    assert.equal(ok.data.serverName, '一服')
    assert.equal(ok.data.count, 1)
    assert.equal(ok.data.scannedPlayers, 2)
    assert.equal(ok.data.durationMs, 7)
    assert.deepEqual(ok.data.players, [{ name: '玩家A', count: 3, slots: [0, 5] }])
    const call = callsOf(host, '/data/anticheat/scan-by-id').at(-1)
    assert.equal(call.params.itemId, '267')
    assert.equal(gameHalf.behavior.get('s1'), 'ok')
  } finally {
    dispose()
  }
})

// ═══════════════════════ 统一错误包装 / 多服零服语义 ═══════════════════════

test('统一错误包装：服端 404 → 501 + serverHalfMissing；服端 401/403 → 502（见报告 D-D）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setBehavior('s1', 'missing')
    const missing = await host.call('post', '/api/anticheat/scan', { body: { serverId: 's1' } })
    assert.equal(missing.status, 501)
    assert.equal(missing.data.ok, false)
    assert.equal(missing.data.serverHalfMissing, true)
    assert.equal(missing.data.dllName, 'AntiCheat.dll')
    assert.ok(missing.data.error.includes('AntiCheat.dll'), missing.data.error)
    assert.ok(missing.data.hint.length > 0, '必须给出可操作提示')

    // token 权限不足/无效：gameOps.js:25-30 的错误语义表写的是「401/403 → 502」
    // （对前端而言这是"宿主的服务器配置/游戏服权限"问题，不是"你自己没登录"或"你没权限"）。
    // 当前实现把服端状态码放进了 extra.status，覆盖了 httpError(502, ...) 的 502，
    // 于是宿主张口把 403/401 当自己的状态码回给浏览器 —— 401 那条尤其危险：
    // 前端会把它当成"宿主登录态失效"，可能把管理员踢去重新登录。
    gameHalf.setBehavior('s1', 'forbidden')
    const forbidden = await host.call('post', '/api/anticheat/scan', { body: { serverId: 's1' } })
    assert.equal(forbidden.status, 502, '服端 403 必须翻成宿主 502，而不是把 403 原样回给前端')
    assert.equal(forbidden.data.ok, false)
    assert.ok(forbidden.data.error.includes('data.rest.invsee'), forbidden.data.error)

    gameHalf.setBehavior('s1', 'unauthorized')
    const unauthorized = await host.call('post', '/api/anticheat/scan', { body: { serverId: 's1' } })
    assert.equal(unauthorized.status, 502, '服端 401（token 无效）绝不能变成宿主 401')

    // 服端 5xx：unwrap 的意图同样是 502（"上游游戏服异常"）
    gameHalf.setBehavior('s1', 'serverError')
    const broken = await host.call('post', '/api/anticheat/scan', { body: { serverId: 's1' } })
    assert.equal(broken.status, 502)
    assert.equal(broken.data.ok, false)
    assert.ok(String(broken.data.error).length > 0)

    // 恢复后必须真的能用（证明上面的失败来自服端行为，不是路由坏了）
    gameHalf.setBehavior('s1', 'ok')
    assert.equal((await host.call('post', '/api/anticheat/scan', { body: { serverId: 's1' } })).status, 200)
  } finally {
    dispose()
  }
})

test('零台启用服：单服动作（scan / check-anomaly / scan-by-id）一律 400 且说明"没有启用中的服务器"', async () => {
  const { host, dispose } = await boot({ servers: [] })
  try {
    const scan = await host.call('post', '/api/anticheat/scan', { body: {} })
    assert.equal(scan.status, 400)
    assert.ok(scan.data.error.includes('没有启用中的服务器'), scan.data.error)

    const anomaly = await host.call('get', '/api/anticheat/check-anomaly', { query: { id: '267', stack: '1' } })
    assert.equal(anomaly.status, 400)
    assert.ok(anomaly.data.error.includes('没有启用中的服务器'), anomaly.data.error)

    const byId = await host.call('get', '/api/anticheat/scan-by-id', { query: { itemId: '267' } })
    assert.equal(byId.status, 400)
    assert.ok(byId.data.error.includes('没有启用中的服务器'), byId.data.error)

    assert.equal(host.calls.length, 0, '零服时不该有任何游戏服调用')

    // 下发与状态在零服下也必须能正常回（不是错误，只是"没人可推"）
    const push = await host.call('post', '/api/anticheat/push', { body: {} })
    assert.equal(push.status, 200)
    assert.equal(push.data.push.total, 0)
    assert.equal(push.data.push.ok, true)
    const st = await host.call('get', '/api/anticheat/status')
    assert.deepEqual(st.data.probe.servers, [])
    assert.equal(st.data.pendingCount, 0)
  } finally {
    dispose()
  }
})

test('停用的服务器不算目标：单服动作只用启用中的那台，且不推给停用服', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    host.setRaw('s2', { enabled: false })
    const res = await host.call('post', '/api/anticheat/scan', { body: {} })
    assert.equal(res.status, 200, '只剩一台启用服时不需要显式指定 serverId')
    assert.equal(res.data.serverId, 's1')
    const before = snapshotCalls(host).length
    const push = await host.call('post', '/api/anticheat/push', { body: {} })
    assert.deepEqual(push.data.push.results.map((r) => r.id), ['s1'])
    assert.equal(snapshotCalls(host).length, before + 1, '停用的 s2 不该被推')
    assert.equal(gameHalf.behavior.get('s2'), 'ok')
  } finally {
    dispose()
  }
})

// ═══════════════════════ 生命周期与事件 ═══════════════════════

test('生命周期：dispose 是函数，调用后重试定时器停掉（retryScheduled=false）', async () => {
  const { host, gameHalf, dispose } = await boot()
  assert.equal(typeof dispose, 'function')
  try {
    gameHalf.setBehavior('s2', 'missing')
    const pushed = await host.call('post', '/api/anticheat/push', { body: {} })
    assert.equal(pushed.data.push.pendingCount, 1)
    assert.equal((await host.call('get', '/api/anticheat/status')).data.retryScheduled, true, '失败后应安排退避重试')
  } finally {
    dispose()
  }
  const after = await host.call('get', '/api/anticheat/status')
  assert.equal(after.data.retryScheduled, false, 'dispose 必须停掉重试定时器（否则卸载后还在打游戏服）')
})

test('生命周期：reconcileIntervalMs<=0 时 startReconcile() 返回 false，stopReconcile() 幂等', async () => {
  const { svc, dispose } = await boot()
  try {
    assert.equal(typeof svc.startReconcile, 'function')
    assert.equal(svc.startReconcile(), false, '间隔 <= 0 表示不启用周期对账（index.js:233-234）')
    svc.stopReconcile()
    svc.stopReconcile()
    assert.equal(PUSH_DEFAULTS.reconcileIntervalMs, 900000, '默认节奏不写进配置文件，只作模块常量')
    assert.equal(PUSH_DEFAULTS.retryIntervalMs, 60000)
    assert.equal(PUSH_DEFAULTS.retryMaxIntervalMs, 900000)
  } finally {
    dispose()
  }
})

test('连接恢复补推：订阅了 push/connected 与 servers/loaded，事件触发后只补推未确认的服', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    assert.ok(host.listenerCount('push/connected') >= 1, '必须订阅 push/connected（连接恢复补推，index.js:914）')
    assert.ok(host.listenerCount('servers/loaded') >= 1, '必须订阅 servers/loaded（index.js:915）')

    gameHalf.setBehavior('s2', 'missing')
    await host.call('post', '/api/anticheat/push', { body: {} })
    const before = snapshotCalls(host).length
    host.fire('push/connected', {})
    await waitFor(() => snapshotCalls(host).length > before, { label: '连接恢复补推' })
    const added = snapshotCalls(host).slice(before)
    assert.deepEqual(added.map((c) => c.serverId), ['s2'], '只该补推未确认的 s2')
  } finally {
    dispose()
  }
})
