/**
 * 源码层断言：反作弊插件的配置契约 / 检测与处置语义 / 日志库契约 / 宿主与服端字段同源
 *
 * 为什么需要这个文件（与 test/dll-content.test.mjs 的分工）：
 *   - dll-content.test.mjs 证明"这段代码进了将被打包下发的 AntiCheat.dll"（字节层）；
 *   - 本文件证明"这段代码的语义就是规格要求的那样"（源码层）：
 *     路由与权限的**配对**、method 闭集与宿主 config.js 的**同源同值**、配置字段名的**两端一致**、
 *     建表列与索引的**逐字契约**、日志队列的**上限与节拍常量**、时间区间归一的**两个边界**。
 *   字节层只能证明"串在里面"，证明不了"绑在正确的语义上"——例如 DLL 里同时有 'data.rest.invsee'
 *   与 'tshock.admin'，但哪个路由配哪个权限只有读源码才能判定；本文件就做这件事。
 *   两者都不能替代运行期验证（见下面的局限）。
 *
 * 局限（如实说明，不要当成运行期保证）：本机**没有 TShock 运行环境**，
 *   所以这里断言的是"代码就是这么写的"（编译层语义），**不是**"在真实服务器上跑起来会怎样"：
 *   包钩子是否真的拦得住包、离线存档写回是否真的生效、SQLite 在服务器上能否打开，
 *   都需要真实 TShock + 真实存档才能验证。同样地，"日志库能落库"只证明代码路径完整，
 *   不证明游戏服上确实能解析到 Microsoft.Data.Sqlite（csproj:29-31 自述这一点未经运行期验证）。
 *
 * 扫描范围：plugins/anti-cheat 下全部 .js / .mjs / .cjs / .cs / .csproj / .json，
 *   **排除** bin / obj（构建产物不是实现）。与 task-scheduler 的源码扫描有一处**刻意的差异**：
 *   这里**包含 test/ 自身**（任务书要求），因为 emoji 禁令要覆盖测试文件（测试文件里出现 emoji
 *   同样是违反本仓约定），而且本文件用 \u{...} 转义写阳性对照，文件里不会真的出现 emoji 字符。
 *
 * 引用约定：注释里的位置一律写 `文件:行号`（本仓约定）。
 *
 * 运行：node test/dll-source.test.mjs   （本机不可用 `node --test test/`）
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile, readdir } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginRoot = path.resolve(here, '..')

/** 排除目录：构建产物与依赖（不是实现） */
const SKIP_DIRS = new Set(['bin', 'obj', 'node_modules', '.git'])
const EXTS = new Set(['.js', '.mjs', '.cjs', '.cs', '.csproj', '.json'])

/** 递归收集本插件的源码文件（含 resources/ 与 test/，不含 bin/obj） */
async function collect(dir) {
  const out = []
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.')) continue
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue
      out.push(...await collect(full))
      continue
    }
    if (!EXTS.has(path.extname(entry.name).toLowerCase())) continue
    out.push(full)
  }
  return out
}

let cached = null

/** 读出所有源码文件的行（带 文件:行号，便于报告里引用） */
async function sources() {
  if (cached) return cached
  const files = await collect(pluginRoot)
  const rows = []
  for (const f of files) {
    const content = await readFile(f, 'utf8')
    const rel = path.relative(pluginRoot, f).replace(/\\/g, '/')
    content.split(/\r?\n/).forEach((line, i) => rows.push({ file: rel, line: i + 1, text: line }))
  }
  cached = { files, rows }
  return cached
}

/** 读单个源文件（相对于本插件根） */
async function readSrc(rel) {
  return readFile(path.join(pluginRoot, rel), 'utf8')
}

/** 注释与代码的区分：注释里出现表名/方法名不算"实现里有这段代码" */
function stripComment(text) {
  const t = text.trim()
  if (t.startsWith('//') || t.startsWith('*') || t.startsWith('/*') || t.startsWith('///')) return ''
  const i = text.indexOf('//')
  return i >= 0 ? text.slice(0, i) : text
}

/** 整份源码的"去注释版" */
function codeOnly(src) {
  return src.split(/\r?\n/).map(stripComment).join('\n')
}

/** 从 `export const NAME = { a: 1, b: 2 }` 里抽出键名（宿主侧开关对象的键） */
function objectKeysOf(src, constName) {
  const m = src.match(new RegExp(`export const ${constName} = \\{([\\s\\S]*?)\\n\\}`))
  assert.ok(m, `config.js 里找不到 ${constName} 的对象字面量（扫描判据失效）`)
  return [...m[1].matchAll(/^\s*([^\s:{}]+)\s*:/gm)].map((x) => x[1])
}

/** 从 `export const NAME = ['a', 'b']` 里抽出字符串数组（宿主侧闭集） */
function stringArrayOf(src, constName) {
  const m = src.match(new RegExp(`export const ${constName} = \\[([^\\]]*)\\]`))
  assert.ok(m, `config.js 里找不到 ${constName} 的数组字面量（扫描判据失效）`)
  return [...m[1].matchAll(/'([^']*)'/g)].map((x) => x[1])
}

/** 抽出 C# 里全部 [JsonProperty("名字")] 的名字（本插件所有 .cs） */
function jsonPropertyNames(csTexts) {
  const names = []
  for (const t of csTexts) {
    for (const m of t.matchAll(/\[JsonProperty\("([^"]+)"\)\]/g)) names.push(m[1])
  }
  return names
}

/**
 * 允许的几何 / 排版字符（本项目既有文案字符，**不得**判成 emoji）。
 * 逐字符给出理由，并标注它在不在 emoji 区间内（这决定了它是"必须豁免"还是"天然不命中"）：
 *   ✕ U+2715  删除按钮（client 里 5 处）。**落在 U+2600-U+27BF 内 -> 必须显式豁免**
 *   ★ U+2605  C# 注释的章节标记（本插件 58 处）。**落在 U+2600-U+27BF 内 -> 必须显式豁免**
 *   ＋ U+FF0B  全角加号，新建按钮（3 处）。在 U+FF00-U+FFEF 半角及全角形式块，天然不命中
 *   ▶ U+25B6  界面展开/播放符号（1 处）。在 U+25A0-U+25FF Geometric Shapes 块，天然不命中
 *   ⠿ U+283F  Braille 拖拽手柄（1 处）。在 U+2800-U+28FF Braille Patterns 块，天然不命中
 *   − U+2212  数学减号（3 处）。在 U+2200-U+22FF Mathematical Operators 块，天然不命中
 *   — U+2014  破折号（314 处）。在 U+2000-U+206F General Punctuation 块，天然不命中
 *   → U+2192  箭头（183 处）。在 U+2190-U+21FF Arrows 块 —— **本文件刻意不把这一块计入 emoji**
 *             （理由见 EMOJI_RE 的注释）
 * 下面那条"emoji 判定有区分度"的用例会断言：★ 与 ✕ **确实**落在 emoji 区间内（豁免是必要的），
 * 其余 6 个**确实**天然不命中（豁免只是文档），并且这 8 个字符在本插件源码里都真的存在（白名单不是空转）。
 */
const ALLOWED_GEOMETRY_CHARS = ['✕', '＋', '▶', '⠿', '★', '−', '—', '→']
const ALLOWED_GEOMETRY = /[✕＋▶⠿★−—→]/gu

/**
 * 真 emoji 的码点区间，逐段说明为什么收进来：
 *   U+1F000-U+1FAFF  Emoji 主体块（U+1F300-U+1F5FF 符号与象形、U+1F600-U+1F64F 表情、
 *                    U+1F680-U+1F6FF 交通、U+1F900-U+1F9FF 补充符号、U+1FA70-U+1FAFF 扩展 A）
 *   U+1F1E6-U+1F1FF  区域指示符（两个连写构成国旗，例如 U+1F1E8 U+1F1F3）
 *   U+2600-U+27BF    Miscellaneous Symbols and Dingbats（U+2705、U+26A0 真 emoji 变体住在这里；
 *                    ★ U+2605 与 ✕ U+2715 也住在这里，所以必须靠 ALLOWED_GEOMETRY 显式豁免）
 *   U+2B00-U+2BFF    Miscellaneous Symbols and Arrows（U+2B50 星、U+2B55 圈等）
 *   U+FE0F           变体选择符-16（把文字形态变 emoji 形态，例如 U+26A0 U+FE0F）
 *   U+200D           零宽连接符 ZWJ（emoji 序列的粘合剂，例如 人+ZWJ+笔记本 的合成表情）
 *
 * 刻意**不**收 U+2190-U+21FF（Arrows）与 U+2460-U+24FF（Enclosed Alphanumerics）：
 *   本插件 UI 大量使用 →（U+2192，183 处）、←（5 处）、↔（2 处）、⇄（1 处）、⇒（2 处）
 *   以及 ①-⑩ 序号（用户可见的既有文案），而这两块里本插件没有任何真 emoji 用法。
 *   把它们收进来只会制造误判 —— 判定边界宁窄勿宽，真 emoji 的写法在本仓有更明确的形态
 *   （带 U+FE0F、或在 U+1F000 以上、或是国旗/ZWJ 序列）。
 *
 * 为什么**不**用"把任意 PE 字节按 UTF-16 解码再扫 emoji"的做法（口径照
 * plugins/task-scheduler/test/dll-content.test.mjs:39-42 的逐字说明）：那样会把长度前缀、
 * 元数据字节的巧合一并解成码点，实测能造出上百个落在 U+2600-U+27BF / U+2B00-U+2BFF 的**假码点**
 * （例如 U+2700、U+2B2F、U+2728 之类），判据完全没有区分度 —— 既会把干净的 DLL 判成"有 emoji"，
 * 也会让真正的 emoji 淹没在噪声里。所以 emoji 禁令只在**源码层**（有明确语义的文本）断言。
 */
const EMOJI_RE = /[\u{1F000}-\u{1FAFF}\u{1F1E6}-\u{1F1FF}\u{2B00}-\u{2BFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]/u

/** 去掉允许的几何字符之后再判 emoji（保证"既有排版字符"不被误判） */
function hasEmoji(text) {
  return EMOJI_RE.test(text.replace(ALLOWED_GEOMETRY, ''))
}

/**
 * AntiCheatLog.cs 建表语句的 11 个列定义，**逐字**（含对齐用的多个空格），
 * 顺序与 AntiCheatLog.cs:234-246 一致。
 */
const DDL_COLUMNS_VERBATIM = [
  'Id         INTEGER PRIMARY KEY AUTOINCREMENT,',
  'Time       TEXT    NOT NULL,',
  "PlayerName TEXT    NOT NULL DEFAULT '',",
  'PlayerId   INTEGER NOT NULL DEFAULT 0,',
  "Category   TEXT    NOT NULL DEFAULT '',",
  'ItemId     INTEGER NOT NULL DEFAULT 0,',
  "ItemName   TEXT    NOT NULL DEFAULT '',",
  'ProjId     INTEGER NOT NULL DEFAULT 0,',
  "Method     TEXT    NOT NULL DEFAULT '',",
  "Detail     TEXT    NOT NULL DEFAULT '',",
  "WorldId    TEXT    NOT NULL DEFAULT ''",
]

/** 任务要求逐项断言的 11 个列名（与上面的逐字定义交叉校验） */
const DDL_COLUMN_NAMES = [
  'Id', 'Time', 'PlayerName', 'PlayerId', 'Category', 'ItemId',
  'ItemName', 'ProjId', 'Method', 'Detail', 'WorldId',
]

/**
 * 本件注册的 15 条路由与权限常量、处理器的**完整三元组**，顺序与 AntiCheatPlugin.cs:97-121 一致。
 * 权限只有两个来源：ProtocolPermission（= data.rest.invsee，新协议 8 条）
 * 与 AdminPermission（= tshock.admin，旧版别名 7 条，逐字照旧版 TsWeb/plugin/Main.cs:133-139）。
 */
const ROUTE_TRIPLES = [
  ['/data/anticheat/snapshot', 'ProtocolPermission', 'AntiCheatEndpoints.Snapshot'],
  ['/data/anticheat/status', 'ProtocolPermission', 'AntiCheatEndpoints.Status'],
  ['/data/anticheat/logs', 'ProtocolPermission', 'AntiCheatEndpoints.Logs'],
  ['/data/anticheat/logs/stats', 'ProtocolPermission', 'AntiCheatEndpoints.LogStats'],
  ['/data/anticheat/log', 'ProtocolPermission', 'AntiCheatEndpoints.RecordLog'],
  ['/data/anticheat/check-anomaly', 'ProtocolPermission', 'AntiCheatEndpoints.CheckAnomaly'],
  ['/data/anticheat/scan', 'ProtocolPermission', 'AntiCheatEndpoints.ScanAll'],
  ['/data/anticheat/scan-by-id', 'ProtocolPermission', 'AntiCheatEndpoints.ScanById'],
  ['/data/anticheat/item-config/getitemconfig', 'AdminPermission', 'AntiCheatEndpoints.LegacyGetItemConfig'],
  ['/data/anticheat/proj-config/getprojconfig', 'AdminPermission', 'AntiCheatEndpoints.LegacyGetProjConfig'],
  ['/data/anticheat/item-config/saveitemconfig', 'AdminPermission', 'AntiCheatEndpoints.LegacySaveItemConfig'],
  ['/data/anticheat/proj-config/saveprojconfig', 'AdminPermission', 'AntiCheatEndpoints.LegacySaveProjConfig'],
  ['/data/anticheat/item-config/scanall', 'AdminPermission', 'AntiCheatEndpoints.ScanAll'],
  ['/data/anticheat/item-config/scan-by-id', 'AdminPermission', 'AntiCheatEndpoints.ScanById'],
  ['/data/anticheat/enable', 'AdminPermission', 'AntiCheatEndpoints.Enable'],
]

/** 两端都必须存在的配置字段名（宿主 config.js / resources/*.json 与服端 [JsonProperty]） */
const SHARED_FIELD_NAMES = [
  '启用', '自动扫描', '扫描间隔', '没收违禁物品', '限制列表', '伤害上限',
  '进度', 'id', 'stack', 'method', 'command',
]

test('扫描范围健全：本插件的 C# / JS / 配置源文件都被纳入（不是扫了个空集）', async () => {
  const { files, rows } = await sources()
  assert.ok(
    files.length > 20,
    `扫描到的文件太少（${files.length} 个）—— 判据可能只覆盖了一小部分实现，`
    + '本插件的源码文件（含 client/、resources/、test/）应远多于 20 个',
  )
  const set = new Set(rows.map((r) => r.file))
  for (const must of [
    'plugin/AntiCheat.csproj',
    'plugin/AntiCheat.cs',
    'plugin/AntiCheatPlugin.cs',
    'plugin/AntiCheatEndpoints.cs',
    'plugin/AntiCheatDetection.cs',
    'plugin/AntiCheatExecutor.cs',
    'plugin/AntiCheatConfig.cs',
    'plugin/AntiCheatLog.cs',
    'plugin/WorldProgress.cs',
    'config.js',
    'index.js',
    'gameOps.js',
    'logs.js',
    'store.js',
    'defaults.js',
    'audit.js',
    'resources/物品违禁.json',
    'resources/弹幕违禁.json',
    'test/dll-content.test.mjs',
    'test/dll-source.test.mjs',
  ]) {
    assert.ok(set.has(must), `扫描范围缺少 ${must}（源码扫描必须覆盖全部实现文件与两份默认清单）`)
  }
  // 构建产物必须被排除（否则判据会被 build 出来的中间文件污染）
  for (const r of rows) {
    assert.doesNotMatch(r.file, /(^|\/)(bin|obj)\//, `扫描范围不该包含构建产物：${r.file}`)
  }
})

test('插件身份与构建布局：程序集名 / 命名空间 / 目标框架 / 入口类 / 日志前缀 / DLL 名同源', async () => {
  const csproj = await readSrc('plugin/AntiCheat.csproj')
  assert.match(csproj, /<AssemblyName>AntiCheat<\/AssemblyName>/,
    '程序集名必须是 AntiCheat（决定 DLL 文件名，AntiCheat.csproj:7）')
  assert.match(csproj, /<RootNamespace>TsWebAntiCheat<\/RootNamespace>/,
    '根命名空间必须是 TsWebAntiCheat（AntiCheat.csproj:8）')
  assert.match(csproj, /<TargetFramework>net9\.0<\/TargetFramework>/, '目标框架必须是 net9.0')
  assert.match(csproj, /<OutputPath>bin\\\$\(Configuration\)\\<\/OutputPath>/,
    'OutputPath 必须是 bin\\$(Configuration)\\（产物落在 bin/Release/net9.0/，由打包器回拷到 plugin/；'
    + 'AntiCheat.csproj:12-13 说明了刻意不用 OutputPath=. 的理由）')
  assert.match(csproj, /<ExcludeAssets>runtime<\/ExcludeAssets>/,
    'Microsoft.Data.Sqlite 必须 ExcludeAssets=runtime（AntiCheat.csproj:20-27：TShock 自带这些程序集，'
    + '本插件随身携带会把几百 KB 托管程序集与原生库下发到每台游戏服）')

  const plugin = await readSrc('plugin/AntiCheatPlugin.cs')
  assert.match(plugin, /namespace TsWebAntiCheat/, '命名空间必须是 TsWebAntiCheat')
  assert.match(plugin, /\[ApiVersion\(2, 1\)\]/, '必须声明 [ApiVersion(2, 1)]（TShock 插件 API 版本）')
  assert.match(plugin, /public class AntiCheatPlugin : TerrariaPlugin/, '入口类必须继承 TerrariaPlugin')
  assert.match(plugin, /public override string Name => "AntiCheat";/, '插件名必须是 AntiCheat')
  assert.match(plugin, /public override string Author => "TSWeb";/, '作者必须是 TSWeb')
  assert.match(plugin, /public override Version Version => new\(0, 1, 0\);/, '版本必须是 0.1.0')

  const ac = await readSrc('plugin/AntiCheat.cs')
  assert.match(ac, /public const string LogPrefix = "\[AntiCheat\]";/,
    '日志前缀常量必须是 [AntiCheat]（AntiCheat.cs:27，独立插件身份，不要用全局 TSWeb 前缀）')

  // DLL 名三处必须同源：csproj 的 AssemblyName、package.json 的 dll glob、gameOps.js 的 DLL_NAME
  const pkg = JSON.parse(await readSrc('package.json'))
  assert.deepEqual(pkg.tsweb.dll, ['./plugin/*.dll'],
    'package.json 的 dll glob 必须是 ./plugin/*.dll（打包下发的东西就是它，package.json:15-17）')
  const gameOps = await readSrc('gameOps.js')
  assert.match(gameOps, /export const DLL_NAME = 'AntiCheat\.dll'/,
    'gameOps.js:38 的 DLL_NAME 必须是 AntiCheat.dll（与 csproj 的 AssemblyName 同名）')
})

test('日志库契约：CheatLog 表名、DDL 11 列逐字、4 个索引、幂等建表、旧库补列', async () => {
  const log = await readSrc('plugin/AntiCheatLog.cs')

  // 表名：本件与旧版一样是**内联字面量**（旧 AntiCheatLog.cs:61-78 逐字），没有 Table 常量。
  // 这里断言的是"表名在 SQL 位置逐字出现"，而不是断言一个不存在的常量。
  assert.match(log, /CREATE TABLE IF NOT EXISTS CheatLog \(/,
    '建表语句必须是 CREATE TABLE IF NOT EXISTS CheatLog (（幂等：存量库上是 no-op，旧表与历史记录原样保留；'
    + 'AntiCheatLog.cs:233-251 是 @"..." 逐字字符串，非插值）')
  // 注意：本件的表名是**内联字面量**（与旧版一致），**没有** TaskSchedulerLogStore 那种 Table 常量。
  // task-scheduler 那边是 `CREATE TABLE IF NOT EXISTS {Table} (`（插值），断言的是常量；
  // 这里若照抄那条判据会永久失败 —— 那是把别的插件的结构套过来，不是本件缺了什么。
  assert.equal(
    /\{Table\}|Table\s*=\s*"CheatLog"/.test(log), false,
    'AntiCheatLog.cs 里既不该有 {Table} 插值、也没有 Table 常量：本件的表名是逐字内联的 CheatLog'
    + '（旧版 AntiCheatLog.cs:61-78 的形态）。出现常量说明有人重构了表名来源，需要同步更新上面这些逐字断言。',
  )
  // 11 个列定义逐字（含对齐空格）
  for (const col of DDL_COLUMNS_VERBATIM) {
    assert.ok(log.includes(col), `建表语句缺少列定义（必须逐字沿用旧版）：${col}`)
  }
  assert.equal(DDL_COLUMNS_VERBATIM.length, 11, '建表语句必须是 11 列（旧 AntiCheatLog.cs:61-78）')
  for (const name of DDL_COLUMN_NAMES) {
    assert.match(
      log, new RegExp(`^\\s*${name}\\s`, 'm'),
      `建表语句缺少列名 ${name}（列名逐字沿用旧版，历史检测记录才能继续读出来）`,
    )
  }
  // 4 个索引名与索引列，**逐字整条**（第 4 个是修旧版缺陷 §7 #30 新增的）
  for (const [literal, why] of [
    ['CREATE INDEX IF NOT EXISTS idx_cheatlog_time ON CheatLog (Time DESC);', '按时间倒序分页'],
    ['CREATE INDEX IF NOT EXISTS idx_cheatlog_player ON CheatLog (PlayerName);', '按玩家名筛选'],
    ['CREATE INDEX IF NOT EXISTS idx_cheatlog_category ON CheatLog (Category);', '按分类筛选与 GROUP BY'],
    ['CREATE INDEX IF NOT EXISTS idx_cheatlog_method ON CheatLog (Method);',
      '本件新增：旧版 Method 列被等值筛选与 GROUP BY 却完全没有索引（旧版缺陷 §7 #30）'],
  ]) {
    assert.ok(log.includes(literal), `建索引语句必须逐字照约定（${why}）：${literal}\n  索引缺失会让日志页与统计全表扫`)
  }
  // 旧库补列：SQLite 不支持 ADD COLUMN IF NOT EXISTS
  assert.match(log, /TryAddColumn\(conn, "PlayerId", "INTEGER NOT NULL DEFAULT 0"\);/,
    '启动时必须补列 PlayerId（旧库没有这一列，AntiCheatLog.cs:256）')
  assert.match(log, /TryAddColumn\(conn, "ProjId", "INTEGER NOT NULL DEFAULT 0"\);/,
    '启动时必须补列 ProjId（AntiCheatLog.cs:257）')
  assert.match(log, /alter\.CommandText = \$"ALTER TABLE CheatLog ADD COLUMN \{column\} \{def\}";/,
    '补列语句必须是 ALTER TABLE CheatLog ADD COLUMN {column} {def}（AntiCheatLog.cs:265）')
  // 补列失败只吞"列已存在"，真实迁移失败必须被记下来（旧版是裸 catch{} 全吞）
  assert.match(log, /duplicate column/,
    '补列必须只把 duplicate column 当"已存在"（AntiCheatLog.cs:272），'
    + '其余失败要进 _lastError：旧版裸 catch{} 全吞，分不清"列已存在"与"真实迁移失败"')
})

test('日志库常量与查询契约：页大小 200 / 队列 20000 / 节拍 1000 / 批 500 / ORDER BY Id DESC / 区间归一 / particle 分类', async () => {
  const log = await readSrc('plugin/AntiCheatLog.cs')

  assert.match(log, /public const int MaxQueryPageSize = 200;/,
    '单页查询上限必须是 200（逐字照旧旧 AntiCheatLog.cs:31；AntiCheatLog.cs:78）')
  assert.match(log, /pageSize = Math\.Clamp\(pageSize, 1, MaxQueryPageSize\);/,
    '查询必须真的按 MaxQueryPageSize 收敛（常量被真正使用，不是死代码；AntiCheatLog.cs:490）')
  assert.match(log, /private const int MaxQueueDepth = 20000;/,
    '日志队列上限必须是 20000（AntiCheatLog.cs:89；超过就丢弃并计数，绝不让内存无限增长）')
  assert.match(log, /private const int FlushIntervalMs = 1000;/,
    '后台写库节拍必须是 1000 毫秒（AntiCheatLog.cs:92）')
  assert.match(log, /private const int MaxBatchSize = 500;/,
    '单次事务批上限必须是 500（AntiCheatLog.cs:95，避免一个事务长时间持有写锁）')
  assert.match(log, /public const int QueueLimit = MaxQueueDepth;/,
    '对外必须暴露 QueueLimit = MaxQueueDepth（/status 与外部写入端点靠它判断队列满；AntiCheatLog.cs:136）')

  // 排序依据：照 SQL 行为（Id DESC），并在回包里带 orderBasis 说明旧版注释与 SQL 不一致。
  // 断言方式说明：`ORDER BY Id DESC` 在源码里出现 3 处（分页查询 :545、统计的最近 10 条 :690，
  // 以及保留策略的子查询 :446），另有若干注释提到它 —— 所以不去数总数，而是逐条断言"这两条查询确实按 Id 排"。
  const logCode = codeOnly(log)
  const pagingIdx = logCode.indexOf('SELECT Id, Time, PlayerName, PlayerId, Category, ItemId, ItemName, ProjId, Method, Detail, WorldId')
  assert.ok(pagingIdx > 0, '找不到分页查询的 SELECT 列表（AntiCheatLog.cs:542，扫描判据失效）')
  assert.match(
    logCode.slice(pagingIdx, pagingIdx + 400), /ORDER BY Id DESC/,
    '分页查询必须按 ORDER BY Id DESC 排序（旧版注释写「Time DESC」而 SQL 是 Id DESC，见 §7 #13；'
    + '本件照 SQL 行为：Time 是文本列，Id 才是自增主键与稳定排序键）',
  )
  const recentIdx = logCode.indexOf('SELECT Id, Time, PlayerName, Category, ItemName, ProjId, Method, Detail')
  assert.ok(recentIdx > 0, '找不到统计页"最近 10 条"的 SELECT（AntiCheatLog.cs:687）')
  assert.match(
    logCode.slice(recentIdx, recentIdx + 400), /ORDER BY Id DESC/,
    '统计页的"最近 10 条"也必须按 ORDER BY Id DESC（与分页查询同一口径）',
  )
  assert.doesNotMatch(
    logCode, /ORDER BY Time/,
    'SQL 里不得出现 ORDER BY Time —— 那正是旧版注释与实现不一致的地方（§7 #13）。'
    + '索引里的 `Time DESC` 是 CREATE INDEX 的列定义，不是排序语句。',
  )
  assert.match(log, /orderBasis = "Id",/, '分页回包必须带 orderBasis = "Id"（让界面如实说明排序依据）')

  // 时间区间归一：只给日期时补 00:00:00 / 23:59:59
  const expand = log.slice(log.indexOf('internal static (string From, string To, bool Expanded) ExpandRange'))
  assert.match(expand, /f \+= " 00:00:00";/,
    'ExpandRange 必须把只给日期的 timeFrom 补成 00:00:00（AntiCheatLog.cs:844）')
  assert.match(expand, /t \+= " 23:59:59";/,
    'ExpandRange 必须把只给日期的 timeTo 补成 23:59:59（AntiCheatLog.cs:849）。'
    + '不补的话字符串比较下 Time <= "2026-01-01" 会把当天记录**全部排除**，看起来像"这天没有检测记录"')
  assert.match(expand, /f\.Length == 10 && f\[4\] == '-' && f\[7\] == '-'/,
    '区间归一的判据必须是"长度 10 且第 5、8 位是 -"（只给日期才补，给了时分秒就不动）')

  // 保留策略：两条 DELETE + VACUUM
  assert.match(log, /cmd\.CommandText = "DELETE FROM CheatLog WHERE Time < @cutoff";/,
    '按天清理必须是 DELETE FROM CheatLog WHERE Time < @cutoff（AntiCheatLog.cs:436）')
  assert.match(log, /"DELETE FROM CheatLog WHERE Id NOT IN \(SELECT Id FROM CheatLog ORDER BY Id DESC LIMIT @keep\)"/,
    '按条数清理必须保留 Id 最大的 MaxRows 条（AntiCheatLog.cs:446）')
  assert.match(log, /vacuum\.CommandText = "VACUUM";/,
    '有删除时必须做 VACUUM（AntiCheatLog.cs:461），否则删了行文件也不会瘦身')

  // 分类：particle 必须保留（日志通道不私有化）
  assert.match(log, /public const string Item = "item";/, 'Categories.Item 必须是 "item"（AntiCheatLog.cs:83）')
  assert.match(log, /public const string Proj = "proj";/, 'Categories.Proj 必须是 "proj"（AntiCheatLog.cs:84）')
  assert.match(log, /public const string Particle = "particle";/,
    'Categories.Particle 必须是 "particle"（AntiCheatLog.cs:85）：这是给将来的粒子防线插件预留的分类，'
    + '删掉它会让别的插件写进 CheatLog 的日志全部丢分类')

  // 「绝不抛」承诺：写入路径必须吞异常并记 _lastError（日志失败不得影响检测主流程）
  assert.match(log, /反作弊日志入队失败/, '入队失败必须记日志（AntiCheatLog.cs:332），不许静默')
  assert.match(log, /反作弊日志写入失败/, '批量写库失败必须记日志并计数（AntiCheatLog.cs:414）')
})

test('日志库只碰自己的表与 TShock 存档表：C# 侧的 SQL 表标识符只能是 cheatlog / tscharacter / if', async () => {
  const { rows } = await sources()
  const captured = new Set()
  for (const r of rows) {
    if (!r.file.startsWith('plugin/') || !r.file.endsWith('.cs')) continue
    for (const m of stripComment(r.text).matchAll(/\b(?:FROM|INTO|UPDATE|TABLE)\s+([A-Za-z_][A-Za-z0-9_]*)/gi)) {
      captured.add(m[1].toLowerCase())
    }
  }
  // 说明：
  //   cheatlog   —— 本件的检测日志表（AntiCheatLog.cs）
  //   tscharacter—— TShock 自己的角色存档表：离线玩家背包读取走 TShock.CharacterDB.GetPlayerData，
  //                 而"没收离线玩家的违禁物品"是直接 UPDATE tsCharacter（AntiCheatDetection.cs:842，
  //                 逐字照旧版 item-restrict.cs:440-478）。这是 TShock 的表，不是别的插件的表。
  //   if         —— 来自 "CREATE TABLE IF NOT EXISTS" 里的 IF（正则的捕获副作用，不是表名）
  assert.deepEqual(
    [...captured].sort(), ['cheatlog', 'if', 'tscharacter'],
    `C# 侧 SQL 位置出现的表标识符只允许 cheatlog / tscharacter / if，实际：${[...captured].join(', ')}\n`
    + '  出现别的表名说明有人硬编码了库表（本件只允许操作自己的 CheatLog 与 TShock 的 tsCharacter）。',
  )
  // CREATE TABLE 只允许出现在日志库这一处，且必须是幂等写法。
  // ★ 判定范围必须是**实现文件**（plugin/*.cs），不能含 test/：本仓要求 emoji 扫描覆盖 test/ 自身，
  //   于是扫描集里必然包含测试文件，而测试文件里写着 'CREATE TABLE IF NOT EXISTS CheatLog' 这类断言文本 ——
  //   把断言文本当"实现"来判定是无效判据（task-scheduler 的 dll-source 做法是整体排除 test/，
  //   本件只在 emoji 那两条用例里纳入 test/，语义判据一律限定在实现文件上）。
  const implCreateLines = rows.filter(
    (r) => r.file.startsWith('plugin/') && r.file.endsWith('.cs') && /CREATE\s+TABLE/i.test(stripComment(r.text)),
  )
  assert.equal(
    implCreateLines.length, 1,
    `实现代码里 CREATE TABLE 只允许出现一次，实际 ${implCreateLines.length} 处：`
    + implCreateLines.map((r) => `${r.file}:${r.line}`).join('、'),
  )
  assert.ok(implCreateLines[0].file.endsWith('AntiCheatLog.cs'), '建表语句必须在 AntiCheatLog.cs 里')
  assert.match(stripComment(implCreateLines[0].text), /CREATE TABLE IF NOT EXISTS CheatLog/, '唯一的建表语句必须是幂等写法')
})

test('REST 路由：Routes 恰好 15 条，且"路由 -> 权限 -> 处理器"逐条配对正确（8 新协议 + 7 旧别名）', async () => {
  const plugin = await readSrc('plugin/AntiCheatPlugin.cs')

  assert.match(plugin, /private const string ProtocolPermission = "data\.rest\.invsee";/,
    'ProtocolPermission 必须是 "data.rest.invsee"（AntiCheatPlugin.cs:78，宿主<->游戏服通道的统一口径）')
  assert.match(plugin, /private const string AdminPermission = "tshock\.admin";/,
    'AdminPermission 必须是 "tshock.admin"（AntiCheatPlugin.cs:84，逐字照旧版 TsWeb/plugin/Main.cs:133-139；'
    + '改档会让旧调用方的 token 全部 403）')

  const start = plugin.indexOf('(string Route, string Permission, RestCommandD Handler)[] Routes =')
  assert.ok(start > 0, '找不到 Routes 数组的声明（扫描边界失效）')
  const block = plugin.slice(start, plugin.indexOf('};', start))
  const triples = [...block.matchAll(
    /\(\s*"([^"]+)"\s*,\s*(ProtocolPermission|AdminPermission)\s*,\s*([A-Za-z0-9_.]+)\s*\)/g,
  )].map((m) => [m[1], m[2], m[3]])

  assert.equal(triples.length, 15, `Routes 必须恰好 15 条（8 条新协议 + 7 条旧版别名），实际提取到 ${triples.length} 条`)
  assert.deepEqual(triples, ROUTE_TRIPLES,
    '路由与权限的配对不符合约定。逐条核对（正则从 Routes 初始化块里抽 ("路径", 权限常量, 处理器) 三元组）：\n'
    + '  约定：8 条新协议端点用 ProtocolPermission（data.rest.invsee），'
    + '7 条旧版别名用 AdminPermission（tshock.admin）——\n'
    + '  旧调用方的 token 带的是 tshock.admin，新宿主带的是 data.rest.invsee，配错任何一条都会让一侧 403。')

  assert.equal(triples.filter((t) => t[1] === 'ProtocolPermission').length, 8, '新协议端点必须是 8 条')
  assert.equal(triples.filter((t) => t[1] === 'AdminPermission').length, 7, '旧版别名必须是 7 条')

  // 注册与反注册必须共用同一份清单（不可能出现"注册了但没反注册"）
  assert.match(plugin, /TShock\.RestApi\.Register\(new SecureRestCommand\(route\.Route, Wrap\(route\.Route, route\.Handler\), route\.Permission\)\);/,
    '注册必须遍历 Routes 并用 route.Permission（权限与路由同源，不能手写第二份）')
  assert.match(plugin, /var set = new HashSet<string>\(Routes\.Select\(r => r\.Route\), StringComparer\.OrdinalIgnoreCase\);/,
    '反注册必须用同一份 Routes 清单（AntiCheatPlugin.cs:360）')
  // 别名必须与主端点指向同一实现（旧路径 = 新路径的别名，不是第二套逻辑）
  const aliasMap = new Map(triples.map(([r, , h]) => [`${r} -> ${h}`, true]))
  for (const pair of [
    ['/data/anticheat/item-config/scanall -> AntiCheatEndpoints.ScanAll', '/data/anticheat/scan'],
    ['/data/anticheat/item-config/scan-by-id -> AntiCheatEndpoints.ScanById', '/data/anticheat/scan-by-id'],
  ]) {
    assert.ok(aliasMap.has(pair[0]), `别名必须复用主端点的实现：期望 ${pair[0]}`)
  }
})

test('method 闭集：AntiCheatConfig.cs 的 ViolationMethods 与宿主 config.js 的 METHOD_VALUES 同源同值', async () => {
  const config = await readSrc('plugin/AntiCheatConfig.cs')
  const host = await readSrc('config.js')

  // ── 服端：先把 ViolationMethods 类里那 5 个常量读出来，再按 All 的**顺序**取值 ──
  const clsStart = config.indexOf('public static class ViolationMethods')
  const clsEnd = config.indexOf('public class RestrictedItem')
  assert.ok(clsStart > 0 && clsEnd > clsStart, '找不到 ViolationMethods 类体（扫描边界失效）')
  const cls = config.slice(clsStart, clsEnd)

  const consts = Object.fromEntries(
    [...cls.matchAll(/public const string (\w+) = "([^"]*)";/g)].map((m) => [m[1], m[2]]),
  )
  const allMatch = cls.match(/public static readonly string\[\] All = \{([^}]*)\};/)
  assert.ok(allMatch, '找不到 ViolationMethods.All 闭集数组')
  const allNames = allMatch[1].split(',').map((s) => s.trim()).filter(Boolean)
  const serverValues = allNames.map((n) => {
    assert.ok(n in consts, `ViolationMethods.All 引用了未定义的常量 ${n}`)
    return consts[n]
  })

  // ── 宿主：config.js 的 METHOD_VALUES ──
  const hostValues = stringArrayOf(host, 'METHOD_VALUES')

  assert.deepEqual(
    serverValues, hostValues,
    '服端的 method 闭集与宿主的 METHOD_VALUES 不同源同值：\n'
    + `  服端 ViolationMethods.All 求值为 ${JSON.stringify(serverValues)}（AntiCheatConfig.cs:36-45）\n`
    + `  宿主 METHOD_VALUES 是 ${JSON.stringify(hostValues)}（config.js:59）\n`
    + '  两端不一致的后果：宿主编好的清单下发到服端后，method 被 ViolationMethods.Parse 降级成 log'
    + '（AntiCheatConfig.cs:62-70 的既定回落），管理员以为会踢人/封禁，实际只记了一条日志。',
  )
  assert.deepEqual(Object.values(consts).sort(), hostValues.slice().sort(),
    'ViolationMethods 的 5 个常量值必须与 METHOD_VALUES 完全一致（不能多也不能少）')

  // 解析映射必须覆盖那 4 个"非默认"档（漏一个就会被静默降级成 log）。
  // ★ 注意 log 这一档**没有**显式分支：它是 Default 回落（AntiCheatConfig.cs:69 `return ViolationAction.Log;`）。
  //   这恰恰是要害 —— 旧版把"不在闭集里的任意字符串"当**自定义命令**执行，
  //   本件的回落方向必须是 log（只记录），绝不能是 Command（执行命令）。
  for (const name of ['Kick', 'Ban', 'Drop', 'Command']) {
    assert.ok(
      cls.includes(`string.Equals(m, ${name}, StringComparison.OrdinalIgnoreCase)`),
      `ViolationMethods.Parse 必须显式识别 ${name}（"${consts[name]}"）—— 漏掉的那一档会被静默降级成 log，`
      + '管理员以为会踢人/封禁，实际只记了一条日志',
    )
  }
  // Parse 的返回序列必须恰好是 Kick / Ban / Drop / Command / Log（最后一个 Log 是**回落**）。
  // 这是修旧版"配置权限即命令执行权限"的要害一条：旧版把不在闭集里的任意字符串当**自定义命令**执行，
  // 本件的回落方向必须是 log（只记录），绝不能是 Command（执行命令）。
  // 边界取到下一个方法（ToWire）的声明处；注意不要用文档注释当边界 ——
  // 那句注释里是 →（U+2192）而不是 ASCII 的 ->，用错字符会让 indexOf 返回 -1、切片失控。
  const parseBody = cls.slice(
    cls.indexOf('public static ViolationAction Parse('),
    cls.indexOf('public static string ToWire('),
  )
  assert.ok(parseBody.length > 0, '找不到 ViolationMethods.Parse 的方法体（扫描边界失效）')
  assert.deepEqual(
    [...parseBody.matchAll(/return ViolationAction\.(\w+);/g)].map((m) => m[1]),
    ['Kick', 'Ban', 'Drop', 'Command', 'Log'],
    'Parse 的返回序列必须是 显式识别 Kick/Ban/Drop/Command 之后**回落 Log**（AntiCheatConfig.cs:62-70）。\n'
    + '  任何其它形态都意味着"未知 method"的处置方向变了：若回落成 Command，就等于把旧版缺陷'
    + '（任意字符串被当服务端命令执行）原样搬回来。',
  )
  assert.doesNotMatch(parseBody, /default\s*:/,
    'Parse 不该有 default 分支：四个显式分支之后直接落到最后的 Log（多一个 default 会让上面那条顺序断言失效）')
})

test('伤害上限：服端默认 20000、宿主默认 20000、默认清单 20000 三处一致（弹幕判定的阈值来源）', async () => {
  const config = await readSrc('plugin/AntiCheatConfig.cs')
  const host = await readSrc('config.js')
  const projJson = JSON.parse(await readSrc('resources/弹幕违禁.json'))

  assert.match(config, /\[JsonProperty\("伤害上限"\)\]\s*\r?\n\s*public int DamageLimit \{ get; set; \} = 20000;/,
    '服端 伤害上限 的默认值必须是 20000（AntiCheatConfig.cs:212-213，逐字照旧 proj-restrict.cs:15）')
  assert.match(host, /export const DAMAGE_LIMIT_DEFAULT = 20000/,
    '宿主 config.js:94 的 DAMAGE_LIMIT_DEFAULT 必须是 20000')
  assert.equal(projJson.伤害上限, 20000,
    'resources/弹幕违禁.json 的 伤害上限 必须是 20000（默认清单与两端默认值三处一致）')
  // 判定方向：damage > DamageLimit 才是异常（>= 会把上限值本身判成违规）
  assert.match(config, /任何 &lt;= 0 的值都会让\*\*每一条\*\*弹幕都"伤害异常"/,
    '注释必须写明"伤害上限 <= 0 会让每条弹幕都判定异常"（这是 Normalize 钳到 >=1 的存在理由）')
})

test('宿主/服端字段名同源：ENTRY_KEY / resources 两份清单 / 服端 [JsonProperty] 三处交叉一致', async () => {
  const host = await readSrc('config.js')
  const itemJson = JSON.parse(await readSrc('resources/物品违禁.json'))
  const projJson = JSON.parse(await readSrc('resources/弹幕违禁.json'))
  const { rows } = await sources()
  const csTexts = []
  for (const r of rows) {
    if (r.file.startsWith('plugin/') && r.file.endsWith('.cs')) csTexts.push(r.text)
  }

  // ── 宿主侧：ENTRY_KEY（条目数组的字段名）──
  const entryKeyRaw = host.match(/export const ENTRY_KEY = \{ item: '([^']+)', proj: '([^']+)' \}/)
  assert.ok(entryKeyRaw, 'config.js:169 的 ENTRY_KEY 必须形如 { item: "限制物品", proj: "限制弹幕" }')
  const entryKey = { item: entryKeyRaw[1], proj: entryKeyRaw[2] }
  assert.deepEqual(entryKey, { item: '限制物品', proj: '限制弹幕' }, 'ENTRY_KEY 的两个字段名必须逐字是 限制物品 / 限制弹幕')

  // ── resources 两份默认清单的结构 ──
  assert.deepEqual(
    Object.keys(itemJson), [...objectKeysOf(host, 'DEFAULT_ITEM_SWITCHES'), '限制列表'],
    'resources/物品违禁.json 的顶层键必须等于 宿主默认开关键 + 限制列表',
  )
  assert.deepEqual(
    Object.keys(projJson), [...objectKeysOf(host, 'DEFAULT_PROJ_SWITCHES'), '限制列表'],
    'resources/弹幕违禁.json 的顶层键必须等于 宿主弹幕默认开关键 + 限制列表',
  )
  assert.ok(itemJson.限制列表.length > 0, 'resources/物品违禁.json 的 限制列表 不能是空的（默认清单就是它的内容）')
  assert.deepEqual(Object.keys(itemJson.限制列表[0]), ['进度', entryKey.item],
    `物品清单每档的键必须是 [进度, ${entryKey.item}]（与 ENTRY_KEY.item 同源）`)
  assert.deepEqual(Object.keys(projJson.限制列表[0]), ['进度', entryKey.proj],
    `弹幕清单每档的键必须是 [进度, ${entryKey.proj}]（与 ENTRY_KEY.proj 同源）`)
  const itemEntryKeys = Object.keys(itemJson.限制列表[0][entryKey.item][0])
  const projEntryKeys = Object.keys(projJson.限制列表[0][entryKey.proj][0])
  assert.deepEqual(itemEntryKeys, ['id', 'stack', 'method', 'command'],
    '物品条目的字段必须是 id / stack / method / command（RestrictedItem，AntiCheatConfig.cs:115-133）')
  assert.deepEqual(projEntryKeys, ['id', 'method', 'command'],
    '弹幕条目的字段必须是 id / method / command —— **没有 stack**（RestrictedProj，AntiCheatConfig.cs:177-187）')

  // ── 服端：全部 [JsonProperty] 名字 ──
  const props = jsonPropertyNames(csTexts)
  for (const name of SHARED_FIELD_NAMES) {
    assert.ok(props.includes(name),
      `服端没有任何 [JsonProperty("${name}")] —— 这个字段名在宿主与默认清单里都有，服端少了它就等于"看不懂宿主的配置"`)
    assert.ok(
      Object.keys(itemJson).includes(name) || Object.keys(projJson).includes(name)
      || itemEntryKeys.includes(name) || projEntryKeys.includes(name)
      || itemJson.限制列表.some((t) => t[name] !== undefined)
      || projJson.限制列表.some((t) => t[name] !== undefined),
      `默认清单（resources/*.json）里没有字段名 ${name} —— 两端不同源`,
    )
  }
  for (const key of [entryKey.item, entryKey.proj]) {
    assert.ok(props.includes(key), `服端必须能解析档位里的条目数组字段名 ${key}（[JsonProperty] 里没有它）`)
  }
  // 反面：服端不得出现宿主侧不存在的字段名（自造字段名会让"下发 -> 生效"静默丢字段）
  const allowedExtra = ['保留天数', '最大条数'] // 日志保留策略只在本件自己的配置文件里，不在旧版清单
  const known = new Set([...SHARED_FIELD_NAMES, entryKey.item, entryKey.proj, '限制物品', '限制弹幕', ...allowedExtra])
  const unknown = [...new Set(props)].filter((p) => !known.has(p))
  assert.deepEqual(unknown, [],
    `服端出现了清单/宿主侧没有定义的 [JsonProperty] 字段名：${unknown.join('、')}\n`
    + '  配置字段名是宿主与服端之间的契约（旧版字段名必须逐字沿用），自造字段名只会静默丢字段。')
})

test('配置下发语义：version 单调拒旧、缺字段沿用旧值、先原子落盘再换引用、保留策略真的跟着生效', async () => {
  const config = await readSrc('plugin/AntiCheatConfig.cs')

  // ── 1. version 单调：更旧的载荷必须被拒且**不覆盖** ──
  assert.match(config, /if \(version > 0 && version < current\.Version\)/,
    '必须先判 version 单调（AntiCheatConfig.cs:515）：乱序到达的旧载荷不能把新配置顶掉')
  assert.match(config, /Applied = false,\s*\r?\n\s*Stale = true,/,
    '被拒的载荷必须回 Applied=false + Stale=true（宿主靠它把"没生效"与"生效了"区分开）')
  assert.match(config, /收到的 version=\{version\} 早于当前 version=\{current\.Version\}，已忽略本次下发/,
    '拒旧时必须留下可读原因（进 notes，回给宿主，绝不静默）')

  // ── 2. 缺字段沿用服端旧值，而不是清空 ──
  assert.match(config, /notes\.Add\("下发载荷未带 item（或为空），物品侧沿用服端当前值"\);/,
    '载荷未带 item 时必须沿用当前值并记 note（AntiCheatConfig.cs:534）——'
    + '旧版缺字段就置空的形态会让"宿主某次少传一个字段"变成"全服清单被清空"')
  assert.match(config, /notes\.Add\("下发载荷未带 proj（或为空），弹幕侧沿用服端当前值"\);/,
    '载荷未带 proj 时必须沿用当前值并记 note（AntiCheatConfig.cs:545）')

  // ── 3. 先原子落盘、再原子换引用（顺序本身是语义：崩在中间不会丢配置）──
  const applyBody = config.slice(
    config.indexOf('public static ApplyOutcome Apply('),
    config.indexOf('internal static string Publish('),
  )
  assert.ok(applyBody.length > 0, '找不到 Apply 的方法体（扫描边界失效）')
  const saveIdx = applyBody.indexOf('var saveError = SaveToDisk(snapshot);')
  const swapIdx = applyBody.indexOf('Volatile.Write(ref _current, snapshot);')
  assert.ok(saveIdx > 0, 'Apply 必须先落盘（var saveError = SaveToDisk(snapshot)）')
  assert.ok(swapIdx > 0, 'Apply 必须原子换引用（Volatile.Write(ref _current, snapshot)）')
  assert.ok(
    saveIdx < swapIdx,
    'Apply 必须"先落盘再换引用"（AntiCheatConfig.cs:573 在 :587 之前）：\n'
    + '  顺序反了的话，换引用之后进程崩溃就得到"内存里生效过、文件里没有"的结果，下次重启配置回退，'
    + '而宿主以为已经 durable。注释里也写明了这条顺序（AntiCheatConfig.cs:503-507）。',
  )
  const publishBody = config.slice(config.indexOf('internal static string Publish('))
  const pSave = publishBody.indexOf('var saveError = SaveToDisk(snapshot);')
  const pSwap = publishBody.indexOf('Volatile.Write(ref _current, published);')
  assert.ok(pSave > 0 && pSwap > 0 && pSave < pSwap,
    'Publish 也必须"先落盘再换引用"（与 Apply 同一条语义；轻量开关 /enable 走的就是它）')

  // ── 4. 日志保留策略必须真的交给日志库（Apply 曾在这一点与 Publish 不一致）──
  assert.match(applyBody, /AntiCheatLog\.ApplyRetention\(snapshot\.Log\);/,
    'Apply 必须调用 AntiCheatLog.ApplyRetention（AntiCheatConfig.cs:594）：\n'
    + '  保留策略只写进快照与配置文件是不够的 —— 后台清理线程读的是 AntiCheatLog 内部那份 _retention，'
    + '漏了这行就等于"管理员把保留天数从 30 改成 7，服端毫无效果"（源码注释 AntiCheatConfig.cs:590-593 记了这处修复）。')
  assert.match(publishBody, /AntiCheatLog\.ApplyRetention\(published\.Log\);/, 'Publish 同样必须应用保留策略（AntiCheatConfig.cs:621）')

  // ── 5. 落盘必须是"写临时文件 + 原子替换 + 留备份"，且串行化 ──
  const save = config.slice(config.indexOf('internal static string SaveToDisk('))
  assert.match(save, /lock \(WriteLock\)/, '落盘必须在锁内（两条路径并发落盘会互相覆盖）')
  assert.match(save, /var tmp = FilePath \+ "\.tmp";/, '落盘必须先写 .tmp（直接覆盖写会在掉电时留下半个文件）')
  assert.match(save, /File\.Replace\(tmp, FilePath, bak, true\);/,
    '必须用 File.Replace 原子替换，并把原文件留成 .bak（人工回退手段）')
  assert.match(save, /File\.Copy\(tmp, FilePath, true\);/, 'File.Replace 不可用时必须退化为"复制覆盖"而不是直接失败')
  assert.match(save, /File\.Move\(tmp, FilePath\);/, '首次落盘（目标不存在）必须走 File.Move')
  assert.match(save, /Directory\.CreateDirectory\(dir\)/, '落盘前必须确保目录存在（否则首次启动就落盘失败）')
  assert.match(save, /return ex\.Message;/, '落盘失败必须把错误文本回给调用方（由回包带给宿主，绝不静默）')
})

test('禁止 emoji：本插件全部 .cs / .js / .mjs / .cjs / .csproj / .json（含 test/ 与 resources/）零命中', async () => {
  const { files, rows } = await sources()
  assert.ok(files.length > 20, `扫描到的文件太少（${files.length} 个）—— emoji 扫描等于空跑`)

  const bad = []
  for (const r of rows) {
    if (hasEmoji(r.text)) bad.push(`${r.file}:${r.line}  ${r.text.trim()}`)
  }
  assert.deepEqual(
    bad, [],
    '源码里不得出现 emoji（本仓硬性约定；允许的 8 个几何字符见 ALLOWED_GEOMETRY_CHARS）：\n' + bad.join('\n'),
  )
  // 反向自证：白名单不是空转 —— 8 个允许字符在本插件源码里都真的存在
  const text = rows.map((r) => r.text).join('\n')
  for (const ch of ALLOWED_GEOMETRY_CHARS) {
    assert.ok(text.includes(ch), `白名单字符 "${ch}" 在本插件源码里必须真的存在（否则这个豁免项是无意义的）`)
  }
})

test('emoji 判定有区分度：真 emoji 必被抓到，8 个既有几何字符不被误判（★ / ✕ 是真实判定边界）', async () => {
  // ── 正向对照：真正的 emoji 必须命中（用码点构造，文件里不出现 emoji 字符本身）──
  const mustCatch = [
    ['\u{1F600}', 'U+1F600 笑脸（Emoji 主体块）'],
    ['\u{1F525}', 'U+1F525 火（Emoji 主体块）'],
    ['\u{2705}', 'U+2705 白色粗勾（落在 U+2600-U+27BF Dingbats，且 Emoji_Presentation=Yes）'],
    ['\u{26A0}\u{FE0F}', 'U+26A0 U+FE0F 警告（裸 U+26A0 是文字形态，靠变体选择符变 emoji）'],
    ['\u{1F1E8}\u{1F1F3}', 'U+1F1E8 U+1F1F3 国旗（区域指示符成对）'],
    ['\u{1F468}\u{200D}\u{1F469}\u{200D}\u{1F467}', 'ZWJ 合成序列（家庭），证明零宽连接符被覆盖'],
    ['\u{2B50}', 'U+2B50 白星（U+2B00-U+2BFF 块；注意与 ★ U+2605 不是同一个字符）'],
  ]
  for (const [s, why] of mustCatch) {
    assert.equal(hasEmoji(s), true, `emoji 判定抓不到 ${why} —— 扫描无效（不是永远返回 false 就是区间写错了）`)
  }

  // ── 反向对照：本仓既有的几何 / 排版字符不得被误判 ──
  for (const ch of ALLOWED_GEOMETRY_CHARS) {
    assert.equal(hasEmoji(ch), false, `既有排版字符 "${ch}" 被误判成 emoji（本插件 UI 与注释里大量使用它）`)
  }
  assert.equal(hasEmoji(ALLOWED_GEOMETRY_CHARS.join('')), false, '8 个允许字符连起来也不得命中')
  assert.equal(hasEmoji('普通中文注释、ASCII 代码与全角标点（，。）'), false, '普通文本不得命中')

  // ── 边界自证：★ 与 ✕ 确实落在 emoji 区间内，所以豁免是**必要的**而不是随手加的 ──
  assert.equal(EMOJI_RE.test('★'), true,
    '★（U+2605）应落在 U+2600-U+27BF 内 —— 这正是"必须显式豁免它"的理由'
    + '（它是 C# 注释的章节标记，本插件用了 58 处；task-scheduler 的 dll-content.test.mjs:143-150 记了同一处边界）')
  assert.equal(EMOJI_RE.test('✕'), true,
    '✕（U+2715）应落在 U+2600-U+27BF 内 —— 它是删除按钮的既有符号（本插件 5 处），同样必须豁免')
  // 其余 6 个天然不命中（豁免只是文档，但也断言下来，防止有人顺手把区间扩到 Arrows / Geometric Shapes）
  for (const ch of ALLOWED_GEOMETRY_CHARS) {
    if (ch === '★' || ch === '✕') continue
    assert.equal(
      EMOJI_RE.test(ch), false,
      `"${ch}" 不该落在 emoji 区间内：▶ 在 U+25A0-U+25FF Geometric Shapes、⠿ 在 U+2800-U+28FF Braille、`
      + '− 在 U+2200-U+22FF 数学运算符、— 在 U+2000-U+206F 通用标点、＋ 在 U+FF00-U+FFEF 全角块、'
      + '→ 在 U+2190-U+21FF Arrows（本文件刻意不把箭头块计入 emoji，因为 → 有 183 处既有用法且块内无真 emoji 用法）。'
      + '命中说明有人把 emoji 区间放宽到了会误判既有文案的范围。',
    )
  }

  // ── 真实语料反向对照：本插件里那些既有符号与序号必须整体不命中 ──
  const { rows } = await sources()
  const text = rows.map((r) => r.text).join('\n')
  for (const ch of ['→', '←', '↔', '⇄', '⇒', '①', '②', '⑩', '─', '═', '§', '×', '–', '…']) {
    if (!text.includes(ch)) continue // 只断言本插件真的用到的那些
    assert.equal(hasEmoji(ch), false, `本插件既有的排版字符 "${ch}" 被误判成 emoji`)
  }
})

test('中文注释与出处引用（本仓约定：注释用中文，引用位置写 文件:行号，并写明与旧版的差异）', async () => {
  const { rows } = await sources()
  const commentLines = rows.filter((r) => /^\s*(\/\/|\/\*|\*|\/\*)/.test(r.text))
  assert.ok(commentLines.length >= 300, `注释行太少（${commentLines.length} 行），本仓要求实现处写明理由`)
  const text = rows.map((r) => r.text).join('\n')
  assert.match(text, /[\u4e00-\u9fff]/, '源码里必须有中文（本仓约定：注释与文案用中文）')

  // 引用位置必须写 "文件:行号"（例如 item-restrict.cs:588-621），全插件的引用点远多于 50 处
  const refs = [...text.matchAll(/[A-Za-z_][\w.-]*\.(?:cs|js|json|vue|mjs):\d+(?:-\d+)?/g)]
  assert.ok(
    refs.length >= 50,
    `"文件:行号"形式的引用只有 ${refs.length} 处 —— 本仓约定引用位置要写成 文件:行号（便于逐条核对旧版行为）`,
  )
  // 必须写明与旧版的关系（本件是旧版功能的插件化，差异必须逐条可查）
  assert.match(text, /旧版/, '注释里必须引用旧版实现位置（本件的语义逐条对照旧版）')
})
