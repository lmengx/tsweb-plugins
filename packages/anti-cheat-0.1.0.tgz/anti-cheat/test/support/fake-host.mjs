/**
 * 测试用的最小宿主（假 ctx）+ 假游戏服半 —— 不启动任何服务进程、不依赖 express / cordis。
 *
 * 为什么自己搓一个（与 plugins/task-scheduler/test/support/fake-host.mjs、
 * plugins/promotion/test/support/fake-host.mjs 同一理由）：
 *   本机 `node --test test/` 会因 `spawn EPERM`（沙箱不允许管道捕获子进程）整体失败，
 *   测试必须能逐个 `node test/<名>.test.mjs` 跑；同时"不启动/重启任何服务进程"是本次任务的
 *   硬约定，所以**不引入真实 HTTP 监听**，而是直接调用插件注册在 app.get/app.post 上的
 *   处理函数（与真实 express 的用法一致：插件只用 (req,res) 两个参数）。
 *
 * ★ 本件比 task-scheduler 的同类文件多两处能力，都是被测对象逼出来的：
 *   1. **保存完整中间件数组**（不只是最后一个处理函数）。anti-cheat 的 12 条路由都是
 *      `app.get(path, ...admin, wrap(fn))` 形态（index.js:652、:693-904），要断言"每条路由
 *      都挂了 admin 链"、并且要**真的把中间件链跑一遍**验证"403 时业务不执行"，
 *      就必须拿到数组本身，而不是只留最后一个。
 *   2. **鉴权中间件可切到"拒绝"**。假宿主默认放行（本件多数用例只关心业务逻辑），
 *      但 `setDeny({ admin: true })` 之后 verifyAuth/requireAdmin 会真的回 401/403 而不调 next()，
 *      于是"中间件短路 ⇒ 业务处理函数一次都没被调用"这件事可以被直接观测（业务计数见 call().businessRan）。
 *
 * 覆盖到的宿主契约（plugins/anti-cheat/index.js 依赖的全部服务）：
 *   webServer.app.get/post、auth.verifyAuth/requireAdmin、servers.list/getRaw、
 *   tshock.postFor（**优先**，index.js 走它）/ tshock.fetchFor（退化路径）、paths.dataOf、
 *   ctx.get(name)（软依赖 itemData / projectileData）、ctx.on（连接恢复补推靠它触发）
 */
import path from 'node:path'

import { Context } from '@deepseek-ai/cordis'

/**
 * 造一个假宿主。
 *
 * ctx 是**真实的 cordis `Context`**（照 plugins/qq-bind/test/apply.test.mjs:47-83 的做法：
 * 在真实 Context 实例上直接赋值宿主服务）。为什么不能用普通对象：
 * `plugins/anti-cheat/index.js:107` 的 `AntiCheatLogService extends Service`，而 cordis 的
 * `Service` 构造函数第一步就是 `self.ctx.reflect.provide(name, self, check)`
 * （node_modules/@deepseek-ai/cordis/lib/index.js:1781）——普通对象没有 `reflect`，
 * 会在 **apply 中途抛错**，于是 `ctx.anticheatLog` 这个"日志服务不许私有化"的对外契约
 * 根本测不到。真实 Context 的 `on`/`emit`/`get` 也都在，
 * 连接恢复补推（index.js:913-919 的 `ctx.on('push/connected')`）才能被真的触发。
 *
 * @param {object} p
 * @param {string} p.dataDir     ctx.paths.dataOf 的根（测试自己给临时目录）
 * @param {Array}  [p.servers]   服务器记录：[{ id, name, enabled, raw }]；raw 缺省时用同名字段合成
 * @param {Function} [p.postFor] 游戏服 POST 实现 (server, pathname, params) => result
 * @param {Function} [p.fetchFor] 游戏服 GET 实现  (server, pathname, params) => result
 * @param {boolean} [p.withPostFor] 是否给 ctx.tshock 挂 postFor（false 用于测"退化 GET+query"路径）
 * @param {object} [p.services]  ctx.get(name) 的服务表（itemData / projectileData），经 cordis 的
 *                               `ctx.provide` 注册（不是覆盖 ctx.get，理由见下方注释）
 */
export function makeFakeHost({
  dataDir,
  servers = [],
  postFor,
  fetchFor,
  withPostFor = true,
  services = {},
} = {}) {
  /** method → Map<path, handlers[]>（**完整数组**，鉴权断言与中间件链都靠它） */
  const routes = { get: new Map(), post: new Map() }
  const events = []
  /** 全部游戏服调用（含参数），供"下发确实发生/参数正确"类断言 */
  const calls = []
  /** 中间件短路开关（默认全放行） */
  const deny = { verify: false, admin: false }
  /** 业务处理函数被真正执行的次数（按 method+path 计） */
  const businessRuns = new Map()

  const raw = new Map()
  for (const s of servers) {
    const rec = s.raw ? { ...s.raw } : { ...s }
    if (rec.id === undefined) rec.id = s.id
    if (rec.name === undefined) rec.name = s.name !== undefined ? s.name : String(rec.id)
    if (rec.enabled === undefined) rec.enabled = s.enabled !== undefined ? s.enabled : true
    raw.set(String(rec.id), rec)
  }

  /** 记录一次路由注册；handlers 是完整数组（含中间件） */
  const register = (method) => (routePath, ...handlers) => {
    routes[method].set(routePath, handlers)
  }

  const app = { get: register('get'), post: register('post') }

  const ctx = new Context()
  ctx.webServer = { app }
  ctx.auth = {
    verifyAuth: () => (req, res, next) => {
      if (deny.verify) {
        res.status(401).json({ ok: false, error: '未登录（假宿主）' })
        return
      }
      next()
    },
    requireAdmin: () => (req, res, next) => {
      if (deny.admin) {
        res.status(403).json({ ok: false, error: '需要管理员权限（假宿主）' })
        return
      }
      next()
    },
  }
  ctx.paths = { dataOf: (n) => path.join(dataDir, n) }
  ctx.logger = { info() {}, warn() {}, error() {} }
  ctx.servers = {
    list: async () => [...raw.values()].map((s) => ({ ...s })),
    getRaw: (id) => (raw.has(String(id)) ? { ...raw.get(String(id)) } : null),
  }

  /**
   * 软依赖服务（itemData / projectileData）用 **cordis 自己的 `ctx.provide`** 注册，
   * 让 `ctx.get(name)` 保持 cordis 的原生语义（未注册 → undefined，与 index.js:614-620 的
   * `_service` 预期一致）。
   *
   * ★ 为什么不能"直接覆盖 ctx.get"（实测踩过）：覆盖之后 cordis 的 Service 注册会**静默失效**——
   *   `ctx.anticheatLog` 与 `ctx.get('anticheatLog')` 都变成 undefined，而 apply 全程不报错
   *   （根因在 node_modules/@deepseek-ai/cordis/lib/index.js:799-815 的 provide 与
   *    :699-718 的 set 陷阱：赋值 `ctx.get = ...` 会在这套反射层上留下不一致状态）。
   *   本件因此改成"只走 provide"，`ctx.get` 保持原生实现。
   */
  for (const [svcName, svcValue] of Object.entries(services)) {
    if (svcValue === undefined || svcValue === null) continue
    ctx.provide(svcName, svcValue)
  }

  /**
   * 事件订阅计数。
   *
   * cordis 的 Context **没有** `listenerCount`（实测 lib/index.js 的 events 服务的原型上只有
   * on/once/emit/parallel/serial/bail/waterfall/register/unregister/dispatch），
   * 而"连接恢复补推有没有真的订阅 `push/connected` / `servers/loaded`"
   * （index.js:913-919）是本件必须断言的一条，所以在这里自己数。
   * 覆盖 `ctx.on` 是安全的（与 `ctx.get` 不同，实测不会破坏 Service 注册）。
   */
  const subscribed = new Map()
  const origOn = ctx.on.bind(ctx)
  ctx.on = (eventName, fn) => {
    subscribed.set(eventName, (subscribed.get(eventName) || 0) + 1)
    return origOn(eventName, fn)
  }

  const tshock = {}
  if (withPostFor) {
    tshock.postFor = async (server, pathname, params) => {
      calls.push({ via: 'postFor', serverId: server.id, pathname, params: { ...params } })
      if (!postFor) throw new Error(`假宿主未提供 postFor 实现：${pathname}`)
      return postFor(server, pathname, params)
    }
  }
  tshock.fetchFor = async (server, pathname, params) => {
    calls.push({ via: 'fetchFor', serverId: server.id, pathname, params: { ...params } })
    if (!fetchFor) throw new Error(`假宿主未提供 fetchFor 实现：${pathname}`)
    return fetchFor(server, pathname, params)
  }
  ctx.tshock = tshock

  return {
    ctx,
    /** 全部游戏服调用（含参数与走的是 postFor 还是 fetchFor） */
    calls,
    /** 插件 emit 的事件 */
    events,
    /** 中间件短路开关：setDeny({ verify:true }) / setDeny({ admin:true }) */
    setDeny(patch = {}) {
      Object.assign(deny, patch)
    },
    /** 改假服务器记录（例如临时置 enabled=false） */
    setRaw(id, patch) {
      raw.set(String(id), { ...(raw.get(String(id)) || {}), ...patch })
    },
    /** 删掉一台服（测"启用中的服被移除"） */
    dropServer(id) {
      raw.delete(String(id))
    },
    /** 触发宿主事件（连接恢复补推靠它）——走真实 cordis Context 的事件总线 */
    fire(name, payload) {
      const hits = subscribed.get(name) || 0
      events.push({ name, payload })
      ctx.emit(name, payload)
      return hits > 0
    },
    /** 某个宿主事件被订阅了几次（判断"插件确实挂上了这个事件"） */
    listenerCount: (name) => subscribed.get(name) || 0,
    /** 某个路由注册的**完整**处理函数数组（鉴权断言用；未注册返回 null） */
    routeHandlers: (method, routePath) => {
      const arr = routes[method].get(routePath)
      return arr ? arr.slice() : null
    },
    /** 只取"插件实际注册的路由清单" */
    routePaths: () => ({ get: [...routes.get.keys()], post: [...routes.post.keys()] }),
    hasRoute: (method, routePath) => routes[method].has(routePath),
    /** 某条路由的业务处理函数被执行了几次 */
    businessCount: (method, routePath) => businessRuns.get(`${method} ${routePath}`) || 0,

    /**
     * 直接调用插件注册的某个端点（不经网络），**按 express 的语义顺序跑完整条中间件链**：
     * 任一中间件不调 next()（例如鉴权拒绝）就立即停住，后面的业务处理函数不会被执行。
     *
     * @returns {Promise<{status:number, data:any, businessRan:boolean, headers:object}>}
     */
    async call(method, url, { query = {}, body = {}, headers = {}, user } = {}) {
      const u = new URL(url, 'http://localhost')
      const mergedQuery = { ...Object.fromEntries(u.searchParams.entries()), ...query }
      const handlers = routes[method].get(u.pathname)
      if (!handlers) throw new Error(`插件未注册该路由: ${method.toUpperCase()} ${u.pathname}`)

      let data = null
      let status = 200
      let businessRan = false
      const res = {
        headersSent: false,
        status(code) {
          status = code
          return res
        },
        json(payload) {
          data = payload
          res.headersSent = true
          return res
        },
      }
      const req = {
        method: method.toUpperCase(),
        url: u.pathname + (u.search || ''),
        originalUrl: u.pathname + (u.search || ''),
        path: u.pathname,
        query: mergedQuery,
        body,
        headers,
        user: user === undefined ? { username: 'tester' } : user,
      }

      let i = 0
      while (i < handlers.length) {
        const h = handlers[i]
        const isLast = i === handlers.length - 1
        i += 1
        let advanced = false
        await h(req, res, () => {
          advanced = true
        })
        if (isLast) {
          businessRan = true
          businessRuns.set(`${method} ${u.pathname}`, (businessRuns.get(`${method} ${u.pathname}`) || 0) + 1)
          break
        }
        if (!advanced) break
      }
      return { status, data, businessRan, headers: res.__headers || {} }
    },
  }
}

/** 轮询等待条件成立（用于等异步下发/重试完成）；超时抛错，不静默通过 */
export async function waitFor(cond, { timeoutMs = 3000, intervalMs = 10, label = '条件' } = {}) {
  const started = Date.now()
  for (;;) {
    const v = await cond()
    if (v) return v
    if (Date.now() - started > timeoutMs) throw new Error(`等待超时：${label}`)
    await new Promise((r) => setTimeout(r, intervalMs))
  }
}

/**
 * 假游戏服半（AntiCheat.dll 的 8 个协议端点行为）。
 *
 * 逐服可设行为（对齐 plugin/AntiCheatEndpoints.cs 的真实返回）：
 *   ok          正常应用并回报 applied=true
 *   missing     未安装 DLL（404，映射成宿主 501 + serverHalfMissing）
 *   forbidden   REST token 权限不足（403，映射成宿主 502）
 *   unauthorized token 无效（401，映射成宿主 502）
 *   badRequest  参数被拒（400，宿主原样透传 400 + 服端原文）
 *   serverError 服端 500
 *   stale       服端已有更新版本 → HTTP 200 + applied=false + stale=true
 *   saveFail    应用了但落盘失败（saveError 非空、durable=false）
 *   emptyPayload 收到的 item/proj 为空串 → 沿用服端旧值（真实服端语义）
 *   raise        postFor/fetchFor 自身抛错（服务器记录损坏等）
 *
 * 端点与参数形态与 plugin/AntiCheatEndpoints.cs 逐字对齐：
 *   POST /data/anticheat/snapshot     参数 version / item / proj / ts
 *   GET  /data/anticheat/status       无参
 *   GET  /data/anticheat/logs         参数 page / pageSize / category / method / player / q / timeFrom / timeTo
 *   GET  /data/anticheat/logs/stats   同上（无分页）
 *   POST /data/anticheat/log          参数 playerName / playerId / category / method / detail / itemId / itemName / projId
 *   GET  /data/anticheat/check-anomaly 参数 id / stack
 *   GET  /data/anticheat/scan         无参
 *   GET  /data/anticheat/scan-by-id   参数 itemId
 */
export function makeGameHalf({ serverIds = [] } = {}) {
  const ids = serverIds.map(String)
  const behavior = new Map(ids.map((id) => [id, 'ok']))
  /** 服端当前 version（单调判定用） */
  const serverVersion = new Map(ids.map((id) => [String(id), 0]))
  /** 服端当前生效的配置（缺字段沿用语义的落点） */
  const applied = new Map(ids.map((id) => [String(id), { item: null, proj: null }]))
  /** 服端日志库（供 /logs 与 /logs/stats） */
  const logs = new Map(ids.map((id) => [String(id), []]))
  /** 服端收到的外部写日志调用（供断言参数形状） */
  const recordCalls = []
  /** 服端收到的 snapshot 调用（供断言 version 单调性） */
  const snapshotCalls = []
  /** 服端 source（rest / legacy / file / default） */
  const source = new Map(ids.map((id) => [String(id), 'default']))
  /** 异常物品判定表：`id` → { allowedStack, method, progress } */
  const anomalyTable = new Map()
  /** 上次下发时间（/status 回显） */
  const updatedAt = new Map(ids.map((id) => [String(id), '']))
  /** 累计处理过的 snapshot 次数（供断言"重试真的又推了一次"） */
  const snapshotCount = new Map(ids.map((id) => [String(id), 0]))

  const num = (v, def) => {
    const n = Number(v)
    return Number.isFinite(n) ? n : def
  }

  /** 造一条服端日志行（字段名逐字对齐旧 AntiCheatLog.cs:238-251 的匿名对象） */
  function makeRow(patch = {}) {
    return {
      id: num(patch.id, 1),
      time: patch.time || '2026-01-01 10:00:00',
      playerName: patch.playerName || '玩家A',
      playerId: num(patch.playerId, 1),
      category: patch.category || 'item',
      itemId: num(patch.itemId, 0),
      itemName: patch.itemName || '',
      projId: num(patch.projId, 0),
      method: patch.method || 'log',
      detail: patch.detail || '',
      worldId: patch.worldId || '1',
    }
  }

  /** 按筛选条件过滤（与 C# GetLogsApi 的 WHERE 口径一致：等值 + LIKE 模糊 + 字符串区间） */
  function filterRows(list, params) {
    let out = list.slice()
    const category = String(params.category || '')
    const method = String(params.method || '')
    const player = String(params.player || '')
    const q = String(params.q || '')
    const from = String(params.timeFrom || '')
    const to = String(params.timeTo || '')
    if (category !== '') out = out.filter((r) => r.category === category)
    if (method !== '') out = out.filter((r) => r.method === method)
    if (player !== '') out = out.filter((r) => r.playerName.includes(player))
    if (q !== '') {
      out = out.filter((r) => r.playerName.includes(q) || r.itemName.includes(q) || r.detail.includes(q))
    }
    if (from !== '') out = out.filter((r) => r.time >= from)
    if (to !== '') out = out.filter((r) => r.time <= to)
    return out
  }

  return {
    behavior,
    serverVersion,
    applied,
    logs,
    recordCalls,
    snapshotCalls,
    source,
    anomalyTable,
    updatedAt,
    snapshotCount,
    setBehavior(id, mode) {
      behavior.set(String(id), mode)
    },
    setServerVersion(id, v) {
      serverVersion.set(String(id), Number(v))
    },
    setSource(id, s) {
      source.set(String(id), s)
    },
    setUpdatedAt(id, t) {
      updatedAt.set(String(id), t)
    },
    /** 预置服端已生效配置（测"缺字段沿用旧值"时把它当旧值） */
    setAppliedConfig(id, cfg) {
      applied.set(String(id), { ...(cfg || {}) })
    },
    /** 预置服端日志行 */
    addLog(id, patch) {
      const list = logs.get(String(id)) || []
      list.push(makeRow(patch))
      logs.set(String(id), list)
    },
    /** 清空服端日志行 */
    clearLogs(id) {
      logs.set(String(id), [])
    },
    /** 预置异常物品判定结果 */
    setAnomaly(id, patch) {
      anomalyTable.set(String(id), patch || null)
    },
    makeRow,

    /** 统一的"服端端点实现"（postFor 与 fetchFor 共用同一份，因为 TShock 合并 query 与 form body） */
    handle(server, pathname, params) {
      const id = String(server.id)
      const mode = behavior.get(id) || 'ok'
      const p = params || {}

      if (mode === 'raise') throw new Error('服务器记录损坏（假）')
      if (mode === 'missing') return { ok: false, status: 404, data: { error: 'no such route' } }
      if (mode === 'forbidden') return { ok: false, status: 403, data: { error: 'forbidden' } }
      if (mode === 'unauthorized') return { ok: false, status: 401, data: { error: 'unauthorized' } }
      // serverError 对**所有**端点生效：否则只有 snapshot 会 500、status 却成功，
      // 造出"一边失败一边成功"的假象，测不出真实映射（照 task-scheduler 假服半的同一条理由）
      if (mode === 'serverError') return { ok: false, status: 500, data: { error: '服务器内部错误（假）' } }

      if (pathname === '/data/anticheat/snapshot') {
        if (mode === 'badRequest') return { ok: false, status: 400, data: { error: 'version 必须是正整数' } }
        const version = num(p.version, 0)
        if (!(version > 0)) return { ok: false, status: 400, data: { error: 'version 必须是正整数' } }
        snapshotCalls.push({ serverId: id, version, item: p.item, proj: p.proj, ts: p.ts })
        snapshotCount.set(id, (snapshotCount.get(id) || 0) + 1)

        const cur = serverVersion.get(id) || 0
        if (version < cur || (mode === 'stale' && version <= cur)) {
          return {
            ok: true,
            status: 200,
            data: {
              ok: true,
              applied: false,
              stale: true,
              acceptedVersion: version,
              version: cur,
              updatedAt: updatedAt.get(id) || '',
              source: source.get(id) || 'default',
              saveError: '',
              durable: true,
              notes: [`收到的 version=${version} 早于当前 version=${cur}，本次载荷被忽略`],
            },
          }
        }

        // 缺字段沿用服端旧值（真实服端语义：空串 → 沿用当前值，并把原因写进 notes）
        const notes = []
        const prev = applied.get(id) || { item: null, proj: null }
        let nextItem = prev.item
        let nextProj = prev.proj
        if (typeof p.item === 'string' && p.item !== '') {
          try {
            nextItem = JSON.parse(p.item)
          } catch (err) {
            notes.push(`item 不是合法 JSON，沿用服端当前值：${err.message}`)
          }
        } else {
          notes.push(mode === 'emptyPayload' ? '未收到 item，已沿用服端当前值' : '未收到 item，已沿用服端当前值')
        }
        if (typeof p.proj === 'string' && p.proj !== '') {
          try {
            nextProj = JSON.parse(p.proj)
          } catch (err) {
            notes.push(`proj 不是合法 JSON，沿用服端当前值：${err.message}`)
          }
        } else {
          notes.push('未收到 proj，已沿用服端当前值')
        }

        serverVersion.set(id, version)
        source.set(id, 'rest')
        updatedAt.set(id, '2026-01-01T00:00:00')
        applied.set(id, { item: nextItem, proj: nextProj })

        const countEntries = (side, key) => {
          if (!side || !Array.isArray(side['限制列表'])) return 0
          return side['限制列表'].reduce((n, t) => n + ((t[key] || []).length), 0)
        }

        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            applied: true,
            stale: false,
            acceptedVersion: version,
            version,
            updatedAt: '2026-01-01T00:00:00',
            source: 'rest',
            saveError: mode === 'saveFail' ? '磁盘只读（假）' : '',
            durable: mode !== 'saveFail',
            notes,
            item: nextItem,
            proj: nextProj,
            counts: {
              itemConfigured: countEntries(nextItem, '限制物品'),
              projConfigured: countEntries(nextProj, '限制弹幕'),
              itemEffective: countEntries(nextItem, '限制物品'),
              projEffective: countEntries(nextProj, '限制弹幕'),
              activeProgressTiers: 1,
            },
            importedLegacy: false,
            importNotes: [],
          },
        }
      }

      if (pathname === '/data/anticheat/status') {
        const cur = applied.get(id) || { item: null, proj: null }
        const countEntries = (side, key) => {
          if (!side || !Array.isArray(side['限制列表'])) return 0
          return side['限制列表'].reduce((n, t) => n + ((t[key] || []).length), 0)
        }
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            version: serverVersion.get(id) || 0,
            updatedAt: updatedAt.get(id) || '',
            source: source.get(id) || 'default',
            file: 'X:/tshock/TSWeb/AntiCheat/config.json',
            legacyFiles: ['X:/tshock/TSWeb/AntiCheat/物品违禁.json', 'X:/tshock/TSWeb/AntiCheat/弹幕违禁.json'],
            saveError: mode === 'saveFail' ? '磁盘只读（假）' : '',
            importedLegacy: false,
            importNotes: [],
            item: cur.item,
            proj: cur.proj,
            counts: {
              itemConfigured: countEntries(cur.item, '限制物品'),
              projConfigured: countEntries(cur.proj, '限制弹幕'),
              itemEffective: countEntries(cur.item, '限制物品'),
              projEffective: countEntries(cur.proj, '限制弹幕'),
              activeProgressTiers: 1,
            },
            detection: { hooks: true, autoScan: true, scanInterval: 10 },
            logStore: { ready: true, rows: (logs.get(id) || []).length, dropped: 0, queueDepth: 0 },
            trigger: 'rest',
            hooks: ['ItemDrop', 'ChestItemChange', 'NewProjectile'],
          },
        }
      }

      if (pathname === '/data/anticheat/logs') {
        const all = logs.get(id) || []
        const filtered = filterRows(all, p)
        const page = Math.max(1, num(p.page, 1))
        const pageSize = Math.min(Math.max(1, num(p.pageSize, 50)), 200)
        const start = (page - 1) * pageSize
        // 与 C# 一致：ORDER BY Id DESC
        const ordered = filtered.slice().sort((a, b) => Number(b.id) - Number(a.id))
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            rows: ordered.slice(start, start + pageSize),
            total: filtered.length,
            page,
            pageSize,
            totalPages: pageSize > 0 ? Math.ceil(filtered.length / pageSize) : 0,
            orderBasis: 'Id',
            timeBasis: 'server-local',
            timeFrom: String(p.timeFrom || ''),
            timeTo: String(p.timeTo || ''),
            rangeExpanded: false,
          },
        }
      }

      if (pathname === '/data/anticheat/logs/stats') {
        const all = logs.get(id) || []
        const filtered = filterRows(all, p)
        const byCategory = {}
        const byMethod = {}
        for (const r of filtered) {
          byCategory[r.category] = (byCategory[r.category] || 0) + 1
          byMethod[r.method] = (byMethod[r.method] || 0) + 1
        }
        const todayStart = '2026-01-01 00:00:00'
        const today = filtered.filter((r) => r.time >= todayStart).length
        const recent = filtered.slice().sort((a, b) => Number(b.id) - Number(a.id)).slice(0, 10)
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            total: filtered.length,
            today,
            byCategory,
            byMethod,
            recent,
            filtered: Object.keys(p).length > 0 && String(p.category || p.method || p.player || p.q || p.timeFrom || p.timeTo || '') !== '',
            scope: 'server',
          },
        }
      }

      if (pathname === '/data/anticheat/log') {
        recordCalls.push({ serverId: id, params: { ...p } })
        // 真实服端：category 为空 → 400（只拒绝空值，不做分类白名单）
        if (String(p.category || '') === '') {
          return { ok: false, status: 400, data: { error: 'category 不能为空（item / proj / particle）' } }
        }
        const list = logs.get(id) || []
        const row = makeRow({
          id: list.length + 1,
          playerName: String(p.playerName || ''),
          playerId: num(p.playerId, 0),
          category: String(p.category),
          itemId: num(p.itemId, 0),
          itemName: String(p.itemName || ''),
          projId: num(p.projId, 0),
          method: String(p.method || ''),
          detail: String(p.detail || ''),
        })
        list.push(row)
        logs.set(id, list)
        return { ok: true, status: 200, data: { ok: true, recorded: true, id: row.id } }
      }

      if (pathname === '/data/anticheat/check-anomaly') {
        const iid = num(p.id, 0)
        const stack = num(p.stack, 0)
        if (!(iid > 0)) return { ok: false, status: 400, data: { error: '缺少有效的 id 参数（物品 ID）' } }
        if (stack < 0) return { ok: false, status: 400, data: { error: '缺少有效的 stack 参数（持有数量）' } }
        const hit = anomalyTable.get(String(iid)) || anomalyTable.get(`${id}:${iid}`) || null
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            id: iid,
            stack,
            anomaly: hit ? stack >= Number(hit.allowedStack || 1) : false,
            inConfig: hit !== null,
            allowedStack: hit ? Number(hit.allowedStack || 1) : null,
            method: hit ? String(hit.method || 'log') : null,
            command: hit ? String(hit.command || '') : '',
            itemName: hit ? String(hit.itemName || '') : null,
            progress: hit ? (hit.progress || ['始终生效']) : [],
            matched: hit
              ? [{
                进度: String((hit.progress || ['始终生效'])[0]),
                id: iid,
                stack: Number(hit.allowedStack || 1),
                method: String(hit.method || 'log'),
                command: String(hit.command || ''),
              }]
              : [],
            effectiveEntries: hit ? 1 : 0,
          },
        }
      }

      if (pathname === '/data/anticheat/scan') {
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            players: [{ name: '玩家A', violations: 2 }, { name: '玩家B', violations: 0 }],
            count: 2,
            scannedPlayers: 2,
            violationCount: 2,
            durationMs: 12,
          },
        }
      }

      if (pathname === '/data/anticheat/scan-by-id') {
        const itemId = num(p.itemId, 0)
        if (!(itemId > 0)) return { ok: false, status: 400, data: { error: '缺少有效的 itemId 参数' } }
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            players: [{ name: '玩家A', count: 3, slots: [0, 5] }],
            count: 1,
            scannedPlayers: 2,
            durationMs: 7,
          },
        }
      }

      return { ok: false, status: 500, data: { error: `未预期的路径 ${pathname}` } }
    },

    /** ctx.tshock.postFor 的落点 */
    postFor(server, pathname, params) {
      return this.handle(server, pathname, params)
    },

    /** ctx.tshock.fetchFor 的落点 */
    fetchFor(server, pathname, params) {
      return this.handle(server, pathname, params)
    },
  }
}

/**
 * 造一份"宿主侧形态"的配置（中文键，与 plugins/anti-cheat/config.js 逐字一致）。
 * 用于下发协议用例：断言"发下去的是整份配置、字段名对得上"。
 */
export function makeConfig(patch = {}) {
  return {
    item: {
      启用: false,
      自动扫描: true,
      扫描间隔: 10,
      没收违禁物品: false,
      限制列表: [
        { 进度: '始终生效', 限制物品: [{ id: 267, stack: 1, method: 'ban', command: '' }] },
        { 进度: '蜂后', 限制物品: [{ id: 1132, stack: 1, method: 'kick', command: '' }] },
      ],
      ...(patch.item || {}),
    },
    proj: {
      启用: false,
      伤害上限: 20000,
      限制列表: [
        { 进度: '始终生效', 限制弹幕: [{ id: 108, method: 'ban', command: '' }] },
      ],
      ...(patch.proj || {}),
    },
  }
}
