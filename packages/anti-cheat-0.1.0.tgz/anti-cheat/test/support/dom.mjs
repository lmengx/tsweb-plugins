/**
 * 极简 DOM + 假宿主 `window.tsweb` —— anti-cheat 前端半的行为测试底座
 *
 * 为什么需要：本机没有浏览器，而前端半有一批**只能真跑才能证明**的性质：
 *   - 三个页面与一个玩家详情区块真的能挂载、真的能渲染（有没有"未定义标识符"这类
 *     只在渲染路径上才炸的问题）；
 *   - 破坏性动作（删除条目 / 应用默认清单 / 放弃修改）真的有确认守卫；
 *   - `[data-ac-pushpanel]` / `[data-ac-savebar]` 真的是**局部重绘**而不是整页重绘；
 *   - 渲染结果里的文案是逐字旧版（规格 B §3.6(b) 与 §3.7 的文案表）。
 *
 * 来源：本文件是把一次性核查脚本 `tmp/ac-verify.mjs` 的极简 DOM（原脚本 :31-163）
 * 提升为**交付物**。原脚本不属于插件交付物、随时可删，所以它抓到的两个真缺陷
 * （`log.js` 曾把 `./shared/api.js` 写成 `./api.js`；`tier-editor.js` 曾读
 * `tier[entryKey]` 而 `buildTierList` 回的是 `tier.entries`）必须由本目录的测试长期守着
 * —— 见 test/client-ui.test.mjs 的两条"回归"用例。
 *
 * 设计要点（都是踩过的坑）：
 *   1. `innerHTML` 的读法**必须**把 `appendChild` 进来的子节点一并序列化出来，
 *      否则"先建节点再挂载"的写法在这个假 DOM 上读不出内容，会误报成缺陷（原脚本 :43-52）。
 *   2. 事件一律走 `fireAct()`：真实浏览器里点的是带 `data-ac-act` 的子节点、由容器的
 *      委托监听器接住，所以这里给一个"`closest()` 能命中"的代理 target 才走得到业务分支
 *      （原脚本 :107-117）。`data-dlg` 同理（shared/search.js:324 用 `closest('[data-dlg]')`）。
 *   3. `querySelector` 只支持本插件真正用到的几个选择器：`[data-ac-pushpanel]`、
 *      `[data-ac-savebar]`。真实浏览器会从 innerHTML 解析出节点，这里退化成
 *      "innerHTML 里含该属性即返回一个代理节点"，代理节点的 innerHTML 写入会被记下来，
 *      供断言检查"面板是否被局部重绘"。
 *   4. `window.confirm` 的返回值可切换并记录调用（破坏性动作守卫的测试要用）。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import { setTimeout as realSetTimeout, clearTimeout as realClearTimeout, setInterval as realSetInterval, clearInterval as realClearInterval } from 'node:timers'

/** 造一个极简元素。字段够本插件的前端半用即可（不追求 DOM 完备） */
export function makeEl(tag) {
  const el = {
    tagName: String(tag || 'div').toUpperCase(),
    _html: '',
    children: [],
    attrs: {},
    listeners: {},
    style: {},
    value: '',
    checked: false,
    disabled: false,
    parentNode: null,
    get innerHTML() {
      // 像浏览器一样：把已 appendChild 的子节点一并序列化出来（否则"先建节点再 appendChild"
      // 的写法在这个假 DOM 上读不出内容，会误报成缺陷）
      let s = this._html
      for (const c of this.children) {
        const t = String(c.tagName || 'div').toLowerCase()
        s += '<' + t + (c.className ? ' class="' + c.className + '"' : '') + '>' + c.innerHTML + '</' + t + '>'
      }
      return s
    },
    set innerHTML(v) { this._html = String(v) },
    textContent: '',
    className: '',
    setAttribute(k, v) { this.attrs[k] = String(v) },
    getAttribute(k) { return Object.prototype.hasOwnProperty.call(this.attrs, k) ? this.attrs[k] : null },
    hasAttribute(k) { return Object.prototype.hasOwnProperty.call(this.attrs, k) },
    removeAttribute(k) { delete this.attrs[k] },
    appendChild(c) { this.children.push(c); c.parentNode = this; return c },
    removeChild(c) { this.children = this.children.filter((x) => x !== c); c.parentNode = null; return c },
    replaceChild(newEl, oldEl) {
      const i = this.children.indexOf(oldEl)
      if (i >= 0) { this.children[i] = newEl; newEl.parentNode = this; oldEl.parentNode = null }
      return oldEl
    },
    addEventListener(t, fn) { (this.listeners[t] = this.listeners[t] || []).push(fn) },
    removeEventListener(t, fn) { this.listeners[t] = (this.listeners[t] || []).filter((x) => x !== fn) },
    /**
     * 极简选择器：只支持本插件用到的两种局部重绘选择器。
     * 返回的代理节点把 innerHTML 的写入记到宿主元素的 `_panelHtml` / `_saveBarHtml` 上，
     * 断言据此判断"面板是否被局部刷新"（而不是整页重绘）。
     */
    querySelector(sel) {
      const mk = (prop) => {
        const self = this
        if (!this[prop]) {
          this[prop] = makeEl('div')
          Object.defineProperty(this[prop], 'innerHTML', {
            get() { return self._html },
            set(v) { this._html = String(v); self[prop + 'Value'] = String(v) },
          })
        }
        return this[prop]
      }
      if (sel === '[data-ac-pushpanel]' && this._html.includes('data-ac-pushpanel')) return mk('_panelProxy')
      if (sel === '[data-ac-savebar]' && this._html.includes('data-ac-savebar')) return mk('_saveProxy')
      return null
    },
    querySelectorAll() { return [] },
    closest() { return null },
    focus() {},
    blur() {},
    setSelectionRange() {},
    /** 供测试：把已绑定的监听器都调一遍（target 就是本元素） */
    fire(type, ev) {
      const ls = (this.listeners[type] || []).slice()
      for (const fn of ls) fn(Object.assign({ target: this, preventDefault() {}, stopPropagation() {} }, ev || {}))
      return ls.length
    },
    listenerCount(type) { return (this.listeners[type] || []).length },
    contains() { return true },
    /**
     * 模拟"点击某个带 data-ac-act / data-dlg 的子节点"：让 closest() 能命中，
     * 从而走到事件委托分支（对应真实页面上点按钮的那条路径）。
     */
    fireAct(type, act, attrs) {
      const target = makeActTarget(attrs ? Object.assign({ 'data-ac-act': act }, attrs) : { 'data-ac-act': act })
      const ls = (this.listeners[type] || []).slice()
      for (const fn of ls) fn({ target, preventDefault() {}, stopPropagation() {} })
      return ls.length
    },
    /** 同 fireAct，但属性是 data-dlg（search.js:324 的分支） */
    fireDlg(type, dlg, attrs) {
      const target = makeActTarget(Object.assign({ 'data-dlg': dlg }, attrs || {}))
      const ls = (this.listeners[type] || []).slice()
      for (const fn of ls) fn({ target, preventDefault() {}, stopPropagation() {} })
      return ls.length
    },
    /** 同 fireAct，但用来读输入框的值（input 事件） */
    fireInput(act, attrs, value) {
      const target = makeActTarget(Object.assign({ 'data-ac-act': act }, attrs || {}))
      if (value !== undefined) target.value = String(value)
      const ls = (this.listeners['input'] || []).slice()
      for (const fn of ls) fn({ target, preventDefault() {}, stopPropagation() {} })
      return ls.length
    },
  }
  return el
}

/** 造一个"能命中 closest() 的 target"：attrs 里有的属性名都能被 closest('[attr]') 命中 */
function makeActTarget(attrs) {
  const t = {
    attrs: attrs || {},
    value: '',
    checked: false,
    getAttribute(k) { return Object.prototype.hasOwnProperty.call(this.attrs, k) ? this.attrs[k] : null },
    hasAttribute(k) { return Object.prototype.hasOwnProperty.call(this.attrs, k) },
    closest(sel) {
      const m = /^\[([a-zA-Z0-9_-]+)(?:="([^"]*)")?\]$/.exec(String(sel))
      if (!m) return null
      if (!Object.prototype.hasOwnProperty.call(this.attrs, m[1])) return null
      if (m[2] !== undefined && String(this.attrs[m[1]]) !== m[2]) return null
      return this
    },
  }
  return t
}

/**
 * 造一个假宿主环境。
 *
 * @param {{hash?: string, api?: Function, confirm?: boolean}} [opts]
 * @returns 见下方返回对象；`install()` 把 window/document/location 装到 globalThis 上
 *          （**必须在 import 前端半之前调用**：item.js:65、proj.js:57 这类模块级
 *          `var tsw = window.tsweb` 在模块加载时就读全局）。
 */
export function makeDom(opts) {
  const o = opts || {}
  const head = makeEl('head')
  const body = makeEl('body')
  const documentStub = {
    head,
    body,
    createElement: (t) => makeEl(t),
    addEventListener() {},
    removeEventListener() {},
    querySelector() { return null },
    querySelectorAll() { return [] },
  }
  const locationStub = { hash: o.hash || '#/s/anticheat-item' }

  /** 宿主 `window.tsweb.api` 收到的每一次调用（形状断言的数据源） */
  const requests = []
  /** 注册面：三个视图 + 一个玩家详情区块（+ 可选的玩家列表列） */
  const registered = { views: [], sections: [], columns: [] }
  /** `window.confirm` 的调用记录与返回值开关 */
  const confirms = []
  const windowListeners = {}
  let apiImpl = typeof o.api === 'function' ? o.api : async () => ({ ok: true, status: 200, data: {} })
  let confirmAnswer = o.confirm === undefined ? true : o.confirm === true

  const win = {
    document: documentStub,
    location: locationStub,
    addEventListener(t, fn) { (windowListeners[t] = windowListeners[t] || []).push(fn) },
    removeEventListener(t, fn) { windowListeners[t] = (windowListeners[t] || []).filter((x) => x !== fn) },
    confirm(msg) { confirms.push(String(msg)); return confirmAnswer },
    setTimeout: realSetTimeout,
    clearTimeout: realClearTimeout,
    setInterval: realSetInterval,
    clearInterval: realClearInterval,
    requestAnimationFrame(fn) { return realSetTimeout(() => fn(Date.now()), 0) },
    cancelAnimationFrame(id) { realClearTimeout(id) },
    tsweb: {
      api: async (path, opts) => {
        requests.push({ path: String(path), opts })
        return apiImpl(String(path), opts)
      },
      getServerId: () => (o.serverId === undefined ? 'srv-1' : o.serverId),
      registerView: (v) => { registered.views.push(v) },
      registerPlayerDetailSection: (s) => { registered.sections.push(s) },
      registerPlayerListColumn: (c) => { registered.columns.push(c) },
    },
  }

  return {
    head,
    body,
    document: documentStub,
    location: locationStub,
    window: win,
    requests,
    registered,
    confirms,
    makeEl,
    /** 装到 globalThis（import 前端半之前必须调一次） */
    install() {
      globalThis.window = win
      globalThis.document = documentStub
      globalThis.location = locationStub
      return this
    },
    /** 换 api 实现（不改已记录的 requests） */
    setApi(fn) { apiImpl = fn; return this },
    /** 换 confirm 的返回值（破坏性动作守卫的测试用） */
    setConfirm(v) { confirmAnswer = v === true; return this },
    confirmCalls() { return confirms.slice() },
    clearConfirms() { confirms.length = 0; return this },
    /** 已记录请求里筛选（path 前缀匹配；默认去掉 query 后比较） */
    callsTo(prefix) { return requests.filter((r) => r.path === prefix || r.path.startsWith(prefix + '?')) },
    /** 火一个 window 级事件（log.js:577 注册的 hashchange 等） */
    fireWindow(type, ev) {
      const ls = (windowListeners[type] || []).slice()
      for (const fn of ls) fn(Object.assign({ preventDefault() {}, stopPropagation() {} }, ev || {}))
      return ls.length
    },
    windowListenerCount(type) { return (windowListeners[type] || []).length },
  }
}

/** 等事件循环跑几轮（前端半的渲染是 async 的：loadConfig 之后才渲染） */
export function sleep(ms) {
  return new Promise((resolve) => realSetTimeout(resolve, ms === undefined ? 30 : ms))
}
