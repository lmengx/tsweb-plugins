/**
 * DLL 内容断言（防"DLL 里其实没有这段代码"）
 *
 * 为什么必须有这条测试：
 *   本仓实测发生过这种缺陷 —— plugins/qq-bind/plugin/QqBind.dll（27136 B）的**二进制里根本没有**
 *   QqPromotion / TryPromoteOnLogin，而同目录 obj/Release/QqBind.dll 里是有的。也就是说
 *   "会被打包下发的 DLL 里没有这段代码"，而构建、打包、`--check` 全程没有任何报错（根因是打包器
 *   从 bin/Release/<tfm>/ 回拷时用了陈旧产物）。本插件的 csproj（plugin/AntiCheat.csproj:9-15）
 *   正是为这件事写下"刻意不用 OutputPath=. 那种布局"的注释，本文件就是它的守门人：
 *   **编译通过 != 功能在包里**。所以这里对**实际会被打包的那个文件**
 *   （plugins/anti-cheat/plugin/AntiCheat.dll，package.json:15-17 的 dll glob 是 ./plugin/*.dll）
 *   做字节层断言，而不是对 bin/ 或 obj/ 里的副本。
 *
 * 判据设计：
 *   - 阳性对照：几个与本功能无关、但必然存在的元数据字符串（基类名 / 覆写方法名 / 框架类型名）。
 *     只要有一个没命中，说明扫错了文件或扫描本身失效，测试直接失败（这不是"缺功能"）。
 *   - 目标串：入口类型 / 端点实现 / 检测与处置类型 / 配置模型 / 日志库 / 15 条路由与权限 /
 *     回包字段名 / CheatLog 建表 SQL 与 4 个索引 / 日志文案。
 *   - 阴性对照：
 *       1. 编造的哨兵串必须扫不到（证明"扫得到"这件事本身有区分度）；
 *       2. 别的插件的表名 / 类型名 / 协议名必须扫不到（证明没有从 promotion、task-scheduler、
 *          status-panel、online-stats 复制粘贴，也没有把别人的表写进自己的库）。
 *
 * ★★ 本插件在字节层的四处事实（都是实测结论，逐条写明理由；不要当成"偷懒"）★★
 *
 *   1. **必须双编码扫描（UTF-8 + UTF-16LE）**，因为同一个 DLL 里两类信息的落点不同：
 *        - 类型名 / 方法名 / 字段名等**元数据** -> #Strings 堆，**UTF-8**；
 *        - 代码里的**字符串字面量**（路由、权限、SQL、日志文案）-> #US 堆，**UTF-16LE**。
 *      本机实测（读 plugin/AntiCheat.dll 逐字节 indexOf）：
 *        'TerrariaPlugin' / 'AntiCheatPlugin' / 'EnsureTable' / 'MaxQueryPageSize'
 *          只以 UTF-8 命中（它们是纯元数据，从不作为字符串字面量出现在代码里）；
 *        '/data/anticheat/snapshot' / 'tshock.admin' / '[AntiCheat]' / 'VACUUM'
 *          只以 UTF-16LE 命中（它们是纯字面量）。
 *      => 只扫一种编码，就会把另一半判成"缺失"，得到一堆假失败；只扫另一种，则得到假通过。
 *      另外实测到一个**跨堆的坑**：`[JsonProperty("中文名")]` 的特性参数不是 #US 字面量，
 *      而是 #Blob 堆里的 SerString（**UTF-8**）。证据：'限制物品'、'限制弹幕'、'没收违禁物品'、
 *      '限制列表' 这四个**只**出现在 [JsonProperty] 里的名字，在本 DLL 里**只以 UTF-8 命中**
 *      （它们连续排在 #Blob 堆同一段：id/stack/method/command/进度/限制物品/启用/自动扫描/
 *      扫描间隔/没收违禁物品/限制列表/限制弹幕/伤害上限/保留天数/最大条数）；
 *      而 '始终生效'（AntiCheatConfig.cs:143 的属性初始化器默认值，是真正的 ldstr 字面量）
 *      **只以 UTF-16LE 命中**；'伤害上限' 两者都命中（[JsonProperty] 键走 UTF-8 + 日志文案走 UTF-16）。
 *      所以"配置字段名在不在包里"这个问题，只有双编码扫描才能回答。
 *
 *   2. **必须双对齐解码**。字符串字面量在 #US 堆里、每个 blob 前面有一个压缩长度前缀，
 *      于是 blob 起点**不保证是偶数**。实测本 DLL：整段建表 + 建索引的 CommandText 是**一个**
 *      连续 blob，起始偏移是**奇数**（本机 150528 B 的产物上是 129989）。只按 offset 0 解一次，
 *      这一段会整段解成乱码 —— 断言就变成"永远命中不了"或"断言了空集"（假通过）。
 *      所以 decodedSqlTexts() 同时给出 `buf.toString('utf16le')` 与 `buf.subarray(1).toString('utf16le')`
 *      两条对齐（照 plugins/task-scheduler/test/dll-content.test.mjs:342-348 的做法）。
 *
 *   3. **建表 DDL 在 DLL 里是连续的**（这条与 task-scheduler 相反，所以更要实测）。
 *      AntiCheatLog.cs:233-251 的 SQL 是**逐字字符串** `@"..."`，**不是**插值字符串
 *      （插值洞会被 Roslyn 切成多段 blob）-> 实测整段 DDL（CREATE TABLE + 4 个 CREATE INDEX）
 *      作为**一个连续**的 UTF-16LE 字面量存在，`CREATE TABLE IF NOT EXISTS CheatLog (`
 *      这一串可以逐字命中（不需要 task-scheduler 那种"归一化正则 + 顺序"的等价判据）。
 *      唯一例外是补列语句：AntiCheatLog.cs:265 是 `$"ALTER TABLE CheatLog ADD COLUMN {column} {def}"`，
 *      插值洞之前的那半段 'ALTER TABLE CheatLog ADD COLUMN' 仍可逐字命中。
 *
 *   4. **emoji 不在字节层断言**（口径照 plugins/task-scheduler/test/dll-content.test.mjs:39-42）：
 *      把任意 PE 字节按 UTF-16 解码会造出成百上千个落在 U+2600-U+27BF / U+2B00-U+2BFF 的**假码点**
 *      （长度前缀、元数据字节的巧合），那个判据没有区分度。emoji 禁令改在源码层断言
 *      （test/dll-source.test.mjs，覆盖本插件全部 .cs / .js / .mjs / .csproj / .json）。
 *
 * 局限（如实说明，不要当成运行期保证）：本机**没有 TShock 运行环境**，这条测试只能证明
 *   "这段代码在 DLL 的元数据/字符串堆里"，**不能**证明它在真实 TShock 上按预期拦截、判定或落库。
 *   语义层的证据在 test/dll-source.test.mjs（源码层），运行期行为需要真实服务器才能验证。
 *
 * 运行：node test/dll-content.test.mjs   （本机不可用 `node --test test/`）
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile, readdir, stat } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginDir = path.join(here, '..', 'plugin')

/** 本插件程序集名（plugin/AntiCheat.csproj:7 的 <AssemblyName>AntiCheat</AssemblyName>） */
const ASSEMBLY = 'AntiCheat'

/** 构建提示（DLL 不存在/过期时直接用得上；不要写不可执行的建议） */
const BUILD_HINT = '  node scripts/pack-plugin.mjs anti-cheat --check\n'
  + '  （或 dotnet build plugins/anti-cheat/plugin/AntiCheat.csproj -c Release）'

/**
 * 阳性对照：与本功能无关但必然出现在本程序集元数据里的名字。
 * 'TerrariaPlugin' 是基类名、'Dispose'/'Initialize' 是覆写方法名、'SecureRestCommand' 是框架类型名
 * （AntiCheatPlugin.cs:319 用它注册路由）——它们的存在只说明"这确实是一个编译好的 TShock 插件程序集"。
 */
const POSITIVE_CONTROLS = ['TerrariaPlugin', 'Initialize', 'Dispose', 'SecureRestCommand']

/**
 * 目标串（元数据类型名 / 方法名 / 常量名；双编码扫描）。
 * 每条都是"这个功能真的进了将被打包下发的 DLL"的正面证据。
 */
const TARGETS = [
  // ── 入口与端点 ──
  ['AntiCheatPlugin', '插件入口类型（AntiCheatPlugin.cs:66，注册 15 条路由并挂全部钩子）'],
  ['AntiCheatEndpoints', 'REST 端点实现（AntiCheatEndpoints.cs:96）'],
  ['TsWebAntiCheat', '根命名空间（AntiCheat.csproj:8 的 RootNamespace）'],
  ['AntiCheat', '程序集名 / 插件名（决定 DLL 文件名）'],

  // ── 检测与处置（游戏服半的实现本体）──
  ['Detection', '生效索引与档位解析（AntiCheatDetection.cs:84）'],
  ['ItemDetection', '物品违禁：ItemDrop + ChestItemChange 钩子 + 自动扫描（AntiCheatDetection.cs:273）'],
  ['ProjDetection', '弹幕违禁：NewProjectile 钩子 + 伤害上限判定（AntiCheatDetection.cs:945）'],
  ['InventoryScan', '背包枚举（在线 / 离线存档两路，AntiCheatDetection.cs:208）'],
  ['InventorySlot', '背包单格模型（AntiCheatDetection.cs:14）'],
  ['ProgressIndex', '按世界进度过滤后的生效清单（AntiCheatDetection.cs:47）'],
  ['ViolationExecutor', '处置执行器：log / kick / ban / drop / command（AntiCheatExecutor.cs:68）'],
  ['ViolationMethods', 'method 闭集与解析（AntiCheatConfig.cs:36，修旧版"任意字符串被当命令执行"）'],
  ['ViolationAction', '处置动作枚举（AntiCheatConfig.cs:22）'],
  ['CheatResult', '单条处置结果模型（AntiCheatExecutor.cs:12）'],
  ['ScanReport', '扫描报告模型（AntiCheatExecutor.cs:26）'],
  ['ViolationEntry', '一次违规的记录模型（AntiCheatExecutor.cs:35）'],
  ['WorldProgress', '世界进度判定（WorldProgress.cs:36，档位过滤依赖它）'],
  ['ItemDrop', 'GetDataHandlers.ItemDrop 包钩子（丢出物品被拦）'],
  ['ChestItemChange', 'GetDataHandlers.ChestItemChange 包钩子（存入箱子被拦 + 回滚槽位）'],
  ['NewProjectile', 'GetDataHandlers.NewProjectile 包钩子（弹幕检测 + 伤害上限判定）'],

  // ── 配置模型与存储 ──
  ['AntiCheatConfig', '物品侧配置模型（AntiCheatConfig.cs:158）'],
  ['AntiCheatConfigStore', '服端配置存储：落盘 + 旧版文件迁移（AntiCheatConfig.cs:307）'],
  ['AntiCheatSnapshot', '一次完整生效的不可变配置快照（AntiCheatConfig.cs:245）'],
  ['RestrictedItem', '单条违禁物品规则（AntiCheatConfig.cs:115）'],
  ['ProgressRestriction', '按进度分组的一档物品限制（AntiCheatConfig.cs:140）'],
  ['RestrictedProj', '单条违禁弹幕规则（AntiCheatConfig.cs:177，注意它没有 stack）'],
  ['ProjRestriction', '按进度分组的一档弹幕限制（AntiCheatConfig.cs:190）'],
  ['ProjRestrictionConfig', '弹幕侧配置模型（AntiCheatConfig.cs:203，含伤害上限）'],
  ['LogRetentionConfig', '日志保留策略（AntiCheatConfig.cs:226）'],
  ['ApplyOutcome', '一次配置应用的结果（AntiCheatConfig.cs:281）'],

  // ── 日志库（CheatLog）──
  ['AntiCheatLog', '检测日志（CheatLog 表 + 有界队列 + 后台批量写，AntiCheatLog.cs:69）'],
  ['PendingLog', '待落库的一条日志（AntiCheatLog.cs:16，字段与 CheatLog 列一一对应）'],
  ['Categories', '日志分类的唯一定义处（AntiCheatLog.cs:81）'],

  // ── 方法（检测/落库/查询的入口）──
  ['EnsureTable', '建表入口（幂等：存量库上是 no-op，AntiCheatLog.cs:224）'],
  ['TryAddColumn', '旧库补列 PlayerId / ProjId（SQLite 不支持 ADD COLUMN IF NOT EXISTS，AntiCheatLog.cs:260）'],
  ['FlushQueue', '把队列整批写进一个事务（AntiCheatLog.cs:360，修旧版"每包一次同步磁盘写 + 全局锁"）'],
  ['GetLogsApi', '分页查询检测日志（AntiCheatLog.cs:484）'],
  ['GetStatsApi', '统计（AntiCheatLog.cs:603，修旧版"统计不接受筛选参数"）'],
  ['ExpandRange', '时间区间归一：只给日期时补 00:00:00 / 23:59:59（AntiCheatLog.cs:837）'],
  ['ApplyRetention', '应用日志保留策略（AntiCheatLog.cs:186）'],
  ['MaxQueryPageSize', '单页查询上限常量（AntiCheatLog.cs:78，逐字照旧版 200）'],
  ['RestartAutoScan', '自动扫描定时器重启（幂等，AntiCheat.cs:145 / AntiCheatPlugin.cs:170）'],
  ['RebuildIndex', '生效清单重建（世界进度变化后重算）'],
  ['ScanOnlinePlayer', '扫描在线玩家背包（AntiCheatDetection.cs）'],
  ['ScanOfflinePlayer', '扫描离线玩家存档（AntiCheatDetection.cs）'],
  ['ScanAllPlayers', '全服在线扫描（AntiCheatDetection.cs，会执行处置）'],
  ['HandleScanCommand', '/scan 聊天命令（AntiCheat.cs:301）'],
  ['CheckAnomalyApi', '异常物品判定（AntiCheat.cs:198，旧版从未注册过这个端点）'],
  ['SetEnableApi', '轻量开关（AntiCheat.cs:86，旧 AntiCheat.cs:376-405）'],
  ['GetItemName', '物品 ID -> 名称（AntiCheat.cs:35，取不到回落 Item_{id}）'],
  ['GetProjectileName', '弹幕 ID -> 名称（AntiCheat.cs:52，回落 弹幕ID:{id}）'],
]

/**
 * 中文键与配置文件名（双编码扫描）。
 * ★ 注意编码分工（见文件头第 1 条实测）：纯 [JsonProperty] 键（限制物品 / 限制弹幕 /
 *   没收违禁物品 / 限制列表）在本 DLL 里**只以 UTF-8 命中**（#Blob 的 SerString），
 *   所以这一组只能用 containsString（双编码），不能用 containsUtf16。
 */
const CONFIG_KEY_TARGETS = [
  ['限制物品', '物品侧档位里的条目数组字段名（AntiCheatConfig.cs:145，与宿主 config.js:169 的 ENTRY_KEY.item 同源）'],
  ['限制弹幕', '弹幕侧档位里的条目数组字段名（AntiCheatConfig.cs:195，与 ENTRY_KEY.proj 同源）'],
  ['限制列表', '档位数组字段名（AntiCheatConfig.cs:172 / :215）'],
  ['没收违禁物品', '物品侧开关（AntiCheatConfig.cs:169）'],
  ['启用', '两侧总开关（AntiCheatConfig.cs:160 / :205）'],
  ['自动扫描', '物品侧开关（AntiCheatConfig.cs:163）'],
  ['扫描间隔', '物品侧开关（AntiCheatConfig.cs:166）'],
  ['伤害上限', '弹幕侧伤害上限（AntiCheatConfig.cs:212，默认 20000；也是日志文案里的字面量）'],
  ['进度', '档位名（AntiCheatConfig.cs:142 / :192）'],
  ['始终生效', '「始终生效」档名（AntiCheatConfig.cs:143 的属性初始化器默认值，实测只以 UTF-16LE 命中）'],
  ['保留天数', '日志保留策略（AntiCheatConfig.cs:229）'],
  ['最大条数', '日志保留策略（AntiCheatConfig.cs:233）'],
  ['物品违禁.json', '旧版物品清单文件名（迁移时只读，AntiCheatConfig.cs 的旧路径拼接）'],
  ['弹幕违禁.json', '旧版弹幕清单文件名（同上）'],
  ['anticheat-config.json', '本件自己的配置文件（TShock.SavePath 下）'],
]

/**
 * 路由与权限：15 条（8 条新协议 data.rest.invsee + 7 条旧版别名 tshock.admin），
 * 逐字来自 AntiCheatPlugin.cs:97-121 的 Routes 清单。
 */
const ROUTES = [
  ['/data/anticheat/snapshot', 'POST 接收宿主下发的整份配置'],
  ['/data/anticheat/status', 'GET 服端自证探针（版本/来源/落盘错误/检测/日志库/钩子）'],
  ['/data/anticheat/logs', 'GET 分页查询检测日志'],
  ['/data/anticheat/logs/stats', 'GET 统计（与列表同一套筛选口径）'],
  ['/data/anticheat/log', 'POST 外部写日志通道（给粒子防线插件用；日志不私有化）'],
  ['/data/anticheat/check-anomaly', 'GET 异常物品判定（旧版从未注册过）'],
  ['/data/anticheat/scan', 'GET 全服在线扫描'],
  ['/data/anticheat/scan-by-id', 'GET 按物品 ID 查持有者'],
  ['/data/anticheat/item-config/getitemconfig', '旧版别名：读物品侧配置'],
  ['/data/anticheat/proj-config/getprojconfig', '旧版别名：读弹幕侧配置'],
  ['/data/anticheat/item-config/saveitemconfig', '旧版别名：写物品侧配置'],
  ['/data/anticheat/proj-config/saveprojconfig', '旧版别名：写弹幕侧配置'],
  ['/data/anticheat/item-config/scanall', '旧版别名：= /scan'],
  ['/data/anticheat/item-config/scan-by-id', '旧版别名：= /scan-by-id'],
  ['/data/anticheat/enable', '旧版别名：轻量开关'],
]

/** 权限名（route 的权限必须与之一致；注册点 AntiCheatPlugin.cs:319） */
const PERMISSIONS = [
  ['data.rest.invsee', '新协议端点的权限（AntiCheatPlugin.cs:78 的 ProtocolPermission）'],
  ['tshock.admin', '旧版兼容端点与聊天命令的权限（AntiCheatPlugin.cs:84 的 AdminPermission，逐字照旧版）'],
]

/**
 * 日志文案（必须逐字来自源码，**不要编**）。
 * 每条的来源行号都写出来，便于核对。这些是代码里的字符串字面量 -> #US 堆 UTF-16LE。
 */
const CHINESE_LOGS = [
  ['[AntiCheat]', '日志前缀常量（AntiCheat.cs:27 public const string LogPrefix）'],
  ['检测日志已初始化', 'AntiCheatLog.cs:158 启动日志正文（含库路径与队列上限）'],
  ['检测日志队列已满', 'AntiCheatLog.cs:343 队列溢出告警（丢日志必须让管理员看见）'],
  ['正在丢弃新日志', 'AntiCheatLog.cs:343 同一句的后半段'],
  ['反作弊日志写入失败', 'AntiCheatLog.cs:414 批量写库失败（失败永不静默）'],
  ['拒绝陈旧配置', 'AntiCheatEndpoints.cs:305 version 更旧的载荷被拒（不覆盖新配置）'],
  ['收到配置下发', 'AntiCheatEndpoints.cs:315 配置下发成功日志'],
  ['已原子落盘', 'AntiCheatEndpoints.cs:320 落盘成功的自证文案'],
  ['version 必须是正整数', 'AntiCheatEndpoints.cs:289 参数校验文案（逐字取自源码：这里就是小写 version 前缀，'
    + '任务书里写的「版本必须是正整数」在源码与产物里都不存在）'],
  ['Failed to save config', 'AntiCheatEndpoints.cs:916/:973 旧版别名写配置失败时的英文文案（旧版契约逐字）'],
  ['迁移', 'AntiCheatConfig.cs 旧版文件迁移的日志用词（迁移提示 / 迁移来源）'],
  ['物品违禁.json', '迁移路径拼接（AntiCheatConfig.cs，只读旧文件）'],
]

/**
 * 回包字段名 / 路由参数名 —— 宿主 gameOps.js / index.js 与前端真的会读这些键，
 * 改名就是"页面显示暂无日志"这类静默失效（旧版 WebRestServer.cs:325 恒回 200 的老坑）。
 */
const WIRE_FIELDS = [
  ['acceptedVersion', 'snapshot 回包：服端接受的版本号（AntiCheatEndpoints.cs:328）'],
  ['durable', 'snapshot/status 回包：这份配置是否已原子落盘（AntiCheatEndpoints.cs:334 / :375）'],
  ['applied', 'snapshot 回包：是否已应用（AntiCheatEndpoints.cs:326）'],
  ['stale', 'snapshot 回包：是否因版本更旧被拒（AntiCheatEndpoints.cs:327）'],
  ['saveError', '落盘错误原因（空串=成功，AntiCheatConfig.cs:250）'],
  ['importedLegacy', '是否从旧版文件迁移过来（AntiCheatConfig.cs:251）'],
  ['counts', '两侧计数块（配置条数 / 生效条数，AntiCheatEndpoints.cs:240）'],
  ['itemConfigured', 'counts 里物品侧已配置条数（AntiCheatEndpoints.cs:244）'],
  ['itemEffective', 'counts 里当前世界进度下生效的物品条数（AntiCheatEndpoints.cs:246）'],
  ['orderBasis', 'logs 回包：排序依据 = "Id"（AntiCheatLog.cs:580，照 SQL 行为而不是旧注释）'],
  ['timeBasis', 'logs 回包：时间基准 = "server-local"（AntiCheatLog.cs:581）'],
  ['rangeExpanded', 'logs 回包：时间区间是否被补全（AntiCheatLog.cs:584）'],
  ['queueDepth', '日志队列当前深度（AntiCheatLog.cs:734 / AntiCheatEndpoints.cs:619）'],
  ['dropped', '累计丢弃条数（AntiCheatLog.cs:737）'],
  ['logStore', '日志库自证块，进 /status（AntiCheatEndpoints.cs:377）'],
]

/** 日志库身份（库路径与连接串必须逐字照旧版，改了就"历史日志看不见"或文件被锁） */
const LOG_STORE = [
  ['AntiCheatLog.sqlite', '检测日志库文件名（AntiCheatLog.cs:72，逐字照旧 AntiCheatLog.cs:27）'],
  ['Pooling=false', '连接串片段（AntiCheatLog.cs:75；为的是避免连接池句柄占用导致文件锁）'],
]

/**
 * 阴性对照：任何情况下都不该出现在本 DLL 里的串。
 * 1. 编造的哨兵串：证明扫描本身有区分度（不是"什么都命中"）；
 * 2. 别的插件的表 / 类型 / 协议名：证明没有从 promotion、task-scheduler、status-panel、
 *    online-stats 复制粘贴，也没有把别人的表写进自己的库。
 */
const NEGATIVE_CONTROLS = [
  ['AC_SENTINEL_9F3A_DO_NOT_MATCH', '编造的哨兵串（阴性对照：证明命中是有区分度的）'],
  ['HMACSHA256', '旧自研协议用的签名算法（本件不得重建它，反作弊走 TShock 原生 REST 权限）'],
  ['player_daily_stat', 'promotion 插件的表（本件不得写别人的表）'],
  ['daily_min', 'promotion 插件的字段'],
  ['task_execution_logs', 'task-scheduler 插件的表'],
  ['StatusPacket', 'status-panel 插件的类型'],
  ['hourly_online_snapshot', 'online-stats 插件的表'],
]

/**
 * 建表语句的 11 个列定义（空白归一成单空格后的形态，顺序与源码 AntiCheatLog.cs:234-246 一致）。
 * 之所以用"归一化 + 逐条按顺序命中"而不是逐字串：源码为了对齐排版在列名后补了多个空格
 * （`Time       TEXT    NOT NULL`），逐字断言会把"改排版"误判成"改表结构"。
 */
const DDL_COLUMNS = [
  'Id INTEGER PRIMARY KEY AUTOINCREMENT',
  'Time TEXT NOT NULL',
  "PlayerName TEXT NOT NULL DEFAULT ''",
  'PlayerId INTEGER NOT NULL DEFAULT 0',
  "Category TEXT NOT NULL DEFAULT ''",
  'ItemId INTEGER NOT NULL DEFAULT 0',
  "ItemName TEXT NOT NULL DEFAULT ''",
  'ProjId INTEGER NOT NULL DEFAULT 0',
  "Method TEXT NOT NULL DEFAULT ''",
  "Detail TEXT NOT NULL DEFAULT ''",
  "WorldId TEXT NOT NULL DEFAULT ''",
]

/** 任务要求逐项断言的 11 个列名（与上面的定义表交叉校验用） */
const DDL_COLUMN_NAMES = [
  'Id', 'Time', 'PlayerName', 'PlayerId', 'Category', 'ItemId',
  'ItemName', 'ProjId', 'Method', 'Detail', 'WorldId',
]

/**
 * 4 个索引，**顺序与源码 AntiCheatLog.cs:247-250 一致**（第 4 个是修旧版缺陷补的）。
 * 每项是三元组 [索引名, 索引列子句, 为什么]：第 2 项必须与源码逐字一致（会被拼成完整的建索引语句）。
 */
const DDL_INDEXES = [
  ['idx_cheatlog_time', 'ON CheatLog (Time DESC)', '按时间倒序分页的主索列（旧版就有）'],
  ['idx_cheatlog_player', 'ON CheatLog (PlayerName)', '按玩家名筛选（旧版就有）'],
  ['idx_cheatlog_category', 'ON CheatLog (Category)', '按分类筛选与 GROUP BY（旧版就有）'],
  ['idx_cheatlog_method', 'ON CheatLog (Method)',
    '本件新增：旧版 Method 列被等值筛选与 GROUP BY 却完全没有索引（旧版缺陷 §7 #30）'],
]

async function findDll() {
  let entries = []
  try {
    entries = await readdir(pluginDir)
  } catch (err) {
    assert.fail(`读不到 plugin 目录：${pluginDir}（${err.message}）`)
  }
  const dlls = entries.filter((f) => f.toLowerCase().endsWith('.dll'))
  assert.ok(
    dlls.length > 0,
    `plugin/ 下没有任何 .dll —— 会被打包下发的产物不存在。请先构建：\n${BUILD_HINT}`,
  )
  assert.equal(
    dlls.length, 1,
    `plugin/ 下应只有本插件自己的 DLL（package.json:15-17 的 glob 是 ./plugin/*.dll，`
    + `多出来的 .dll 会被一起下发到每一台游戏服），实际有：${dlls.join(', ')}`,
  )
  assert.equal(dlls[0], `${ASSEMBLY}.dll`, `DLL 文件名必须是 ${ASSEMBLY}.dll（gameOps.js:38 的 DLL_NAME 就是它）`)
  return path.join(pluginDir, dlls[0])
}

/**
 * 在字节里找 .NET 的字符串 —— **必须同时扫两种编码**，否则会得出错误结论（见文件头第 1 条实测）：
 *   - 类型名 / 方法名 / 字段名等元数据字符串 -> #Strings 堆，**UTF-8**；
 *   - 字符串字面量（路由、权限、SQL、日志文案）-> #US 堆，**UTF-16LE**；
 *   - [JsonProperty("中文")] 的特性参数 -> #Blob 堆的 SerString，**UTF-8**。
 *
 * 另有一条历史教训（照 plugins/promotion/test/dll-content.test.mjs 记下来）：先用 PowerShell 的
 * `[Encoding]::UTF8.GetString(...).IndexOf('owner')` 扫竟然"命中"过 —— 因为 UTF-16LE 的
 * "o\0w\0n\0e\0r" 解码后含 NUL，而 .NET 的 String.IndexOf(string) 默认是**文化敏感**比较、
 * 会忽略零权字符（NUL），于是给出了假阳性。所以这里用 Node 按字节扫，并显式覆盖两种编码。
 */
function containsString(buf, s) {
  return buf.indexOf(Buffer.from(s, 'utf8')) >= 0 || buf.indexOf(Buffer.from(s, 'utf16le')) >= 0
}

/** 只按 UTF-16LE 找（代码里的字符串字面量必然在 #US 堆里；用于短中文串，避免字节巧合造成假阳性） */
function containsUtf16(buf, s) {
  return buf.indexOf(Buffer.from(s, 'utf16le')) >= 0
}

/** 该串在字节里的位置（找不到返回 -1；报错文案里用来指明"在哪"，排障时省一轮） */
function offsetOf(buf, s) {
  return buf.indexOf(Buffer.from(s, 'utf16le'))
}

/**
 * 把 DLL 字节按**双编码 × 双对齐**解成文本，并把非 ASCII 归一成空格。
 *
 * 为什么必须双对齐：字符串字面量在 #US 堆里是 UTF-16LE，而该堆里每个 blob 前面有压缩长度前缀、
 * blob 起点**不保证是偶数**（实测本 DLL 的整段建表 + 建索引 CommandText 就在**奇**偏移上）。
 * 只按 offset 0 解一次，那一段会整段解成乱码，于是"抽不到建表语句"而让断言变成空断言（假通过）。
 *
 * 为什么可以归一去非 ASCII：#US 堆里 blob 之间的长度前缀会被解码成孤立的高位字符，
 * 而本插件的 SQL（表名 + 列名 + 类型 + 占位符）**全为 ASCII**，所以把非 ASCII 压成空格后，
 * "片段之间的先后顺序"依然可判定，且不会被长度前缀干扰。
 */
function decodedSqlTexts(buf) {
  return [
    buf.toString('latin1'),
    buf.toString('utf16le').replace(/\u0000/g, ''),
    buf.subarray(1).toString('utf16le').replace(/\u0000/g, ''),
  ].map((t) => t.replace(/[^\x20-\x7e]+/g, ' '))
}

/** 归一化文本：非 ASCII 已压成空格，这里再把连续空白压成一个空格，便于断言"列定义"这种含排版的片段 */
function normalizedTexts(buf) {
  return decodedSqlTexts(buf).map((t) => t.replace(/\s+/g, ' '))
}

/**
 * 从 DLL 字节里抽 SQL 语句片段（照 plugins/task-scheduler/test/dll-content.test.mjs:358-369 的做法）。
 *
 * 抽取范围：以 SELECT/INSERT/UPDATE/DELETE/CREATE 开头、到串尾或 240 字符的一段；
 * 只保留真的像 SQL 的片段（含 FROM / INTO / TABLE / SET 之类）。
 * 用途：1) 证明"SQL 确实在字节里"（而不是断言了别的东西）；2) 让"必须能抽到"成为非空断言
 * （抽不到 0 条时，后面的反面断言等于空断言）。
 */
function extractSqlStatements(buf) {
  const out = []
  for (const text of decodedSqlTexts(buf)) {
    const re = /\b(?:SELECT|INSERT|UPDATE|DELETE|CREATE)\b[^\u0000]{0,240}/gi
    let m
    while ((m = re.exec(text)) !== null) {
      const sql = m[0].replace(/[\u0000-\u001f]+/g, ' ').trim()
      if (/\b(FROM|INTO|TABLE|SET)\b/i.test(sql)) out.push(sql)
    }
  }
  return out
}

test('插件 DLL 存在且体积合理（空文件 / 半截文件直接失败）', async () => {
  const dll = await findDll()
  const st = await stat(dll)
  assert.ok(
    st.size > 4096,
    `DLL 体积异常小（${st.size} B），疑似构建失败或占位文件：${dll}\n  请重新构建：\n${BUILD_HINT}`,
  )
  const buf = await readFile(dll)
  assert.equal(buf.subarray(0, 2).toString('latin1'), 'MZ', '不是合法的 PE 文件（应以 MZ 开头）')
})

test('DLL 新鲜度：plugin/ 下恰好一个 AntiCheat.dll，且不得早于任何 .cs / .csproj', async () => {
  const dll = await findDll()
  const dllStat = await stat(dll)
  const sources = (await readdir(pluginDir)).filter((f) => /\.(cs|csproj)$/i.test(f))
  assert.ok(sources.length >= 5, `plugin/ 下的源码文件太少（${sources.length} 个），目录结构可疑`)

  const newer = []
  for (const f of sources) {
    const st = await stat(path.join(pluginDir, f))
    if (st.mtimeMs > dllStat.mtimeMs) newer.push(`${f}（${st.mtime.toISOString()}）`)
  }
  assert.deepEqual(
    newer, [],
    '会被打包下发的 DLL 比源码旧：这个文件比 '
    + `${path.basename(dll)}（${dllStat.mtime.toISOString()}）更新：\n`
    + newer.map((s) => `    - ${s}`).join('\n')
    + '\n  也就是说"源码改了但 DLL 没重建" —— package.json:15-17 的 glob 是 ./plugin/*.dll，'
    + '下发的就是这份旧 DLL，服务器上跑的是旧代码（本仓 qq-bind 实测踩过同一个坑）。\n'
    + `  修复：删掉 plugin/bin 与 plugin/obj 后重建，并重新打包：\n${BUILD_HINT}`,
  )
  // 防打包陈旧副本：只允许一个 .dll，且文件名与 DLL_NAME 一致（findDll 已断言，这里再钉一次）
  assert.equal(path.basename(dll), `${ASSEMBLY}.dll`, 'DLL 文件名必须是 AntiCheat.dll')
})

test('阳性对照：与本功能无关的元数据字符串必须命中（证明扫描有效、扫的是插件程序集）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const missing = POSITIVE_CONTROLS.filter((s) => !containsString(buf, s))
  assert.deepEqual(
    missing, [],
    `阳性对照未命中：${missing.join('、')} —— 说明扫描本身失效或扫错了文件，`
    + '此时"目标串命中"没有任何意义（先修扫描，再谈功能缺失）',
  )
})

test('目标串：入口/检测/处置/配置/日志库的类型与方法必须都在 DLL 里（双编码）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const missing = TARGETS.filter(([s]) => !containsString(buf, s))
  assert.deepEqual(
    missing.map(([s]) => s), [],
    '反作弊的实现没有真正进到将被打包下发的 DLL 里（这正是 qq-bind 实测踩过的缺陷：\n'
    + '  plugin/QqBind.dll 里没有 QqPromotion/TryPromoteOnLogin，而 obj/Release 里有）。\n'
    + '  缺的是：\n'
    + missing.map(([s, why]) => `    - ${s}：${why}`).join('\n')
    + `\n  修复方向：删掉 plugin/bin、plugin/obj 后重建（或加 --rebuild）：\n${BUILD_HINT}`,
  )
})

test('源文件名不是类型名：断言 AntiCheatDetection/AntiCheatExecutor 两文件的真实类型名（实测依据）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)

  // 实测（本机逐字节扫这份 150528 B 的产物）：'AntiCheatDetection' 与 'AntiCheatExecutor'
  // 在**任何编码下都不命中**。原因是它们只是**源文件名**：.cs 文件名只进 PDB，
  // DLL 的 #Strings 堆里只有 PDB 路径 'AntiCheat.pdb'（实测命中）。进堆的是**类型名**。
  // 所以这里断言的是这两个文件的真实类型名 —— 把文件名写进断言会永久失败，那是断言写错，不是代码缺陷。
  const realTypes = [
    ['Detection', 'AntiCheatDetection.cs:84（生效索引与档位解析）'],
    ['InventoryScan', 'AntiCheatDetection.cs:208（在线 / 离线背包枚举）'],
    ['ItemDetection', 'AntiCheatDetection.cs:273（物品违禁）'],
    ['ProjDetection', 'AntiCheatDetection.cs:945（弹幕违禁）'],
    ['InventorySlot', 'AntiCheatDetection.cs:14'],
    ['ProgressIndex', 'AntiCheatDetection.cs:47'],
    ['ViolationExecutor', 'AntiCheatExecutor.cs:68（处置执行）'],
    ['CheatResult', 'AntiCheatExecutor.cs:12'],
    ['ScanReport', 'AntiCheatExecutor.cs:26'],
    ['ViolationEntry', 'AntiCheatExecutor.cs:35'],
  ]
  const missing = realTypes.filter(([t]) => !containsString(buf, t))
  assert.deepEqual(
    missing.map(([t]) => t), [],
    'AntiCheatDetection.cs / AntiCheatExecutor.cs 里的类型名没有进 DLL：\n'
    + missing.map(([t, why]) => `    - ${t}：${why}`).join('\n'),
  )

  // 反面：文件名确实不在（证明上面"没命中"不是扫描失效，而是"文件名的确不进 DLL"）
  for (const f of ['AntiCheatDetection', 'AntiCheatExecutor']) {
    assert.equal(
      containsString(buf, f), false,
      `DLL 里竟然出现了源文件名 ${f} —— 这不影响功能，但说明扫描判据的前提（文件名不进 #Strings 堆）`
      + `在这份产物上不成立，需要重新核对本用例的注释。`,
    )
  }
  assert.equal(containsString(buf, 'AntiCheat.pdb'), true,
    'DLL 里应有 PDB 路径 AntiCheat.pdb（说明这是带调试信息的正常构建产物）')
})

test('日志文案必须以 UTF-16LE 命中（#US 堆字面量，排除字节巧合造成的假阳性）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  // 这些串短到"UTF-8 字节序列恰好被蒙中"是有可能的，短中文串尤其如此，
  // 所以专门断言它们作为 UTF-16LE 字面量存在（.NET 把代码里的字符串字面量放进 #US 堆）。
  // 实测：这些文案在本 DLL 里**只**以 UTF-16LE 命中（UTF-8 一路全 MISS），
  // 这也反过来证明"只扫 UTF-8 会把全部中文文案判成缺失"。
  const missing = CHINESE_LOGS.filter(([s]) => !containsUtf16(buf, s))
  assert.deepEqual(
    missing.map(([s]) => s), [],
    '以下文案没有以 UTF-16LE 字面量出现在 DLL 里（#US 堆）：\n'
    + missing.map(([s, why]) => `    - ${s}：${why}`).join('\n')
    + '\n  这通常说明文案被改写了、被挪到了别的程序集，或者整段代码没进产物。',
  )
  // 逐条给出偏移（排障时能直接定位；不影响断言结果）
  for (const [s] of CHINESE_LOGS) {
    assert.ok(offsetOf(buf, s) >= 0, `文案 ${s} 无法定位（上一行的命中判定与这里不一致）`)
  }
})

test('配置字段名与文件名：中文键必须命中（双编码；纯 [JsonProperty] 键实测只走 UTF-8）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const missing = CONFIG_KEY_TARGETS.filter(([s]) => !containsString(buf, s))
  assert.deepEqual(
    missing.map(([s]) => s), [],
    '以下配置字段名 / 文件名不在 DLL 里：\n'
    + missing.map(([s, why]) => `    - ${s}：${why}`).join('\n')
    + '\n  说明：'
    + '这几个是宿主与服端之间的**配置契约**（config.js:169 的 ENTRY_KEY 与 resources/*.json 的键名），'
    + '少一个就意味着"宿主编好的清单在服端认不出来"。\n'
    + '  注意编码分工（本文件头第 1 条的实测结论）：[JsonProperty("中文")] 的参数进 #Blob 堆的'
    + ' SerString（UTF-8），代码字面量进 #US 堆（UTF-16LE），所以本用例用 containsString 而不是 containsUtf16。',
  )

  // 「始终生效」是属性初始化器的默认值（AntiCheatConfig.cs:143），是真正的 ldstr 字面量，
  // 因此它必须**以 UTF-16LE**命中 —— 这条同时验证上面的编码分工结论。
  assert.equal(containsUtf16(buf, '始终生效'), true,
    '「始终生效」必须作为 UTF-16LE 字面量存在（它是 AntiCheatConfig.cs:143 的属性初始化器默认值）；'
    + '若它只以 UTF-8 命中，说明它只剩 #Blob 里的特性参数，代码里的默认值不见了')

  // 「伤害上限」两侧都要在：JsonProperty 键（UTF-8）与日志文案（UTF-16）
  assert.equal(containsString(buf, '伤害上限'), true, '伤害上限 必须存在（配置契约）')
  assert.equal(containsUtf16(buf, '伤害上限'), true,
    '伤害上限 还必须是 UTF-16LE 字面量：AntiCheatConfig.cs:746 / AntiCheatPlugin.cs:201 的日志与'
    + '启动自证摘要里都在用它，只有 JsonProperty 命中说明日志里那几处被删了')
})

test('SQL 建表语句：DDL 是**连续**字面量，11 列按源码顺序、4 个索引逐个命中（双编码 × 双对齐）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)

  // 1) 关键：本件的 DDL 是**逐字字符串**（AntiCheatLog.cs:233-251 的 `@"..."`，非插值），
  //    所以整段（CREATE TABLE + 4 个 CREATE INDEX）在 #US 堆里是**一个连续 blob**，
  //    `CREATE TABLE IF NOT EXISTS CheatLog (` 可以逐字命中。
  //    ★ 这与 task-scheduler 相反（那边是 `$@"..."` 插值，表名与模板被切成两段，只能断言"两段相邻"），
  //      所以本件**不需要**那个等价判据 —— 这是实测结论，不是假设。
  assert.equal(
    containsUtf16(buf, 'CREATE TABLE IF NOT EXISTS CheatLog ('), true,
    'DLL 里没有连续的 "CREATE TABLE IF NOT EXISTS CheatLog ("。\n'
    + '  实测本件 DDL 是 @"..." 逐字字符串（AntiCheatLog.cs:233-251，非插值），应当是**一个连续 blob**；\n'
    + '  若这里失败，说明建表语句被改写成了插值字符串（表名被切成独立 blob）、或整段没进 DLL。',
  )
  assert.equal(containsString(buf, 'CREATE TABLE IF NOT EXISTS'), true,
    'DLL 里没有 "CREATE TABLE IF NOT EXISTS" —— 建表语句缺失或不是幂等写法（存量库上会直接报错）')

  // 2) 归一化后的文本里，"建表头部 + 表名 + 左括号 + 11 个列定义"必须按源码顺序出现
  const texts = normalizedTexts(buf)
  const headRx = /CREATE TABLE IF NOT EXISTS CheatLog \( /
  const variant = texts.find((t) => headRx.test(t) && DDL_COLUMNS.every((d) => t.includes(d)))
  assert.ok(
    variant,
    'DLL 字节里没有一份可读文本同时包含建表头部与全部 11 个列定义，缺的是：\n'
    + DDL_COLUMNS.filter((d) => !texts.some((t) => t.includes(d))).map((d) => `    - ${d}`).join('\n')
    + '\n  CheatLog 的列结构是"旧版历史检测记录继续可见"的前提（列名必须逐字沿用旧版）。',
  )
  const colOffsets = DDL_COLUMNS.map((d) => variant.indexOf(d))
  for (let i = 1; i < colOffsets.length; i++) {
    assert.ok(
      colOffsets[i] > colOffsets[i - 1],
      `建表语句的列顺序与源码不一致：第 ${i + 1} 列「${DDL_COLUMNS[i]}」出现在第 ${i} 列`
      + `「${DDL_COLUMNS[i - 1]}」之前。\n`
      + '  列顺序变动意味着有人改过表结构；存量库上的 CREATE TABLE IF NOT EXISTS 是 no-op，'
      + '新列不会生效、旧表会对不上，必须复核。',
    )
  }

  // 3) 逐项断言任务要求的 11 个列名（用表头边界切出 DDL 段，避免被别的 SQL 里的同名片段误命中）
  const ddlSeg = variant.slice(variant.indexOf('CREATE TABLE IF NOT EXISTS CheatLog ('),
    variant.indexOf('CREATE INDEX IF NOT EXISTS idx_cheatlog_time'))
  const missingCols = DDL_COLUMN_NAMES.filter((c) => !new RegExp(`(^|\\s)${c}\\s`).test(ddlSeg))
  assert.deepEqual(missingCols, [], `建表语句缺少列：${missingCols.join('、')}`)

  // 4) 4 个索引名 + 索引列，**顺序与源码一致**（第 4 个 idx_cheatlog_method 是修旧版缺陷新增的）
  //    注意：这里断言的是**逐字**整条语句（含结尾分号）。源码里这 4 条与建表语句在同一个
  //    `@"..."` 里，所以它们在 #US 堆中是同一段连续文本 —— 逐字断言才抓得住"建索引被删/改列"。
  let cursor = -1
  for (const [idx, on, why] of DDL_INDEXES) {
    const literal = `CREATE INDEX IF NOT EXISTS ${idx} ${on};`
    assert.equal(containsUtf16(buf, literal), true,
      `DLL 里没有逐字的建索引语句：${literal}\n  这一条的作用：${why}`)
    const at = variant.indexOf(`CREATE INDEX IF NOT EXISTS ${idx} `)
    assert.ok(at >= 0, `归一化文本里找不到索引 ${idx}`)
    assert.ok(at > cursor, `索引顺序与源码不一致：${idx} 出现在前一个索引之前（AntiCheatLog.cs:247-250）`)
    cursor = at
  }

  // 5) 写入与保留策略语句
  assert.equal(containsUtf16(buf, 'INSERT INTO CheatLog (Time, PlayerName, PlayerId, Category, ItemId, ItemName, ProjId, Method, Detail, WorldId)'),
    true, 'DLL 里没有逐字的 INSERT INTO CheatLog（落库语句缺失 = 日志写不进去）')
  assert.equal(containsUtf16(buf, 'VALUES (@t, @p, @pid, @c, @iid, @iname, @proj, @m, @d, @w)'), true,
    'DLL 里没有 INSERT 的参数占位符（说明写入不是参数化 SQL，或者被改写过）')
  assert.equal(containsUtf16(buf, 'DELETE FROM CheatLog WHERE Time < @cutoff'), true,
    'DLL 里没有按天清理的 DELETE FROM CheatLog（旧版缺陷 §7 #32：日志库无限增长）')
  assert.equal(containsUtf16(buf, 'DELETE FROM CheatLog WHERE Id NOT IN (SELECT Id FROM CheatLog ORDER BY Id DESC LIMIT @keep)'), true,
    'DLL 里没有按条数清理的 DELETE（保留策略只按天数不按条数）')
  assert.equal(containsUtf16(buf, 'VACUUM'), true,
    'DLL 里没有 VACUUM —— 删了行之后文件不会瘦身（旧版缺陷的另一半）')
  assert.equal(containsUtf16(buf, 'ALTER TABLE CheatLog ADD COLUMN'), true,
    'DLL 里没有 ALTER TABLE CheatLog ADD COLUMN —— 旧库的 PlayerId / ProjId 补列缺失'
    + '（SQLite 不支持 ADD COLUMN IF NOT EXISTS，必须有这段容错补列，AntiCheatLog.cs:256-265）')
  assert.equal(containsUtf16(buf, 'ORDER BY Id DESC'), true,
    'DLL 里没有 ORDER BY Id DESC —— 分页排序依据缺失（旧版注释写 Time DESC 而 SQL 是 Id DESC，'
    + '本件照 SQL 行为并回包 orderBasis="Id"）')
})

test('SQL 语句抽取非空，且只碰本插件与 TShock 自己的表（抽不到任何 SQL 时反面断言不可信）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const sqls = extractSqlStatements(buf)
  assert.ok(
    sqls.length >= 4,
    '抽到的 SQL 片段太少（' + sqls.length + ' 条）—— 抽取逻辑失效（对齐/编码没覆盖到），'
    + '此时后面的反面断言等于空断言',
  )
  const ddl = sqls.filter((s) => /CREATE\s+TABLE/i.test(s))
  assert.ok(
    ddl.length >= 1,
    `抽不到建表语句（只抽到 ${sqls.length} 条片段）：\n` + sqls.map((s) => `    ${s.slice(0, 80)}`).join('\n'),
  )
  assert.ok(
    ddl.some((s) => /CREATE TABLE IF NOT EXISTS CheatLog \( Id\s+INTEGER PRIMARY KEY AUTOINCREMENT/.test(s)),
    '抽到的建表语句里没有"表名 + 第一列 Id 自增主键"紧跟建表头部：\n'
    + ddl.map((s) => `    ${s.slice(0, 120)}`).join('\n'),
  )
  // 反面：任何抽取出来的 SQL 都不许提到别的插件的表。
  // 注意 **tsCharacter 是允许的**：它是 TShock 自己的存档表（离线玩家背包读取与没收，
  // AntiCheatDetection.cs:842 逐字照旧版 item-restrict.cs:440-478），不是别的插件的表。
  for (const sql of sqls) {
    assert.doesNotMatch(
      sql, /player_daily_stat|hourly_online_snapshot|task_execution_logs/i,
      `DLL 的 SQL 片段里出现了别的插件的表：${sql.slice(0, 120)}`,
    )
  }
})

test('路由 15 条与权限名：必须以 UTF-16LE 逐字命中（字面量，不是元数据）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  assert.equal(ROUTES.length, 15, '本件注册 15 条路由（8 条新协议 + 7 条旧版别名）')

  const missing = ROUTES.filter(([r]) => !containsUtf16(buf, r))
  assert.deepEqual(
    missing.map(([r]) => r), [],
    '以下路由没有作为 UTF-16LE 字面量出现在 DLL 里：\n'
    + missing.map(([r, why]) => `    - ${r}：${why}`).join('\n')
    + '\n  路由是字符串字面量（AntiCheatPlugin.cs:97-121），只扫 UTF-8 会全判缺失；'
    + '缺哪条就意味着"那个端点没注册"，宿主调用会得到 404。',
  )
  for (const [p, why] of PERMISSIONS) {
    assert.equal(containsUtf16(buf, p), true,
      `DLL 里没有权限名 ${p}（${why}）—— 权限常量缺失会让 SecureRestCommand 建不出来，路由注册失败`)
  }
  // 反面（防"路由串是别的插件留下的"）：本件不得注册别的插件的路由前缀
  for (const other of ['/data/tasks/', '/data/promotion/', '/data/status-panel/', '/data/online-stats/']) {
    assert.equal(containsUtf16(buf, other), false,
      `DLL 里出现了别的插件的路由前缀 ${other} —— 说明路由清单被跨插件复制粘贴过`)
  }
})

test('回包字段名与日志库身份：宿主/前端真的会读这些键，必须都在 DLL 里', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const missing = WIRE_FIELDS.filter(([s]) => !containsString(buf, s))
  assert.deepEqual(
    missing.map(([s]) => s), [],
    '以下回包字段名不在 DLL 里：\n'
    + missing.map(([s, why]) => `    - ${s}：${why}`).join('\n')
    + '\n  这些键是宿主 gameOps.js / index.js 与前端读取的对象，改名 = 页面显示"暂无日志"'
    + '这类静默失效（旧版 WebRestServer.cs:325 恒回 200 的老坑）。',
  )
  for (const [s, why] of LOG_STORE) {
    assert.equal(containsUtf16(buf, s), true,
      `DLL 里没有日志库身份串 ${s}（${why}）。改库文件名会让历史检测记录"看不见"；`
      + '去掉 Pooling=false 会让连接池句柄占住文件、备份/清理失败。')
  }
})

test('日志分类：particle 与 item/proj 三个字面量都必须在（日志通道不私有化）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  // particle 是给将来的粒子防线插件预留的分类：AntiCheatLog.Categories.Particle = "particle"
  // （AntiCheatLog.cs:85），并且 /data/anticheat/log 允许别的插件以 category=particle 写入同一张表。
  // 删掉它 = 粒子插件写进来的日志全部丢失/落成空分类。
  assert.equal(containsUtf16(buf, 'particle'), true,
    'DLL 里没有 "particle" 分类字面量 —— Categories.Particle 被删了，'
    + '粒子防线插件写进 CheatLog 的日志会丢分类（旧 AntiCheatLog.cs:15 自述这张表承载四类）')
  for (const c of ['item', 'proj']) {
    assert.equal(containsUtf16(buf, c), true,
      `DLL 里没有 "${c}" 分类字面量（Categories.Item / Categories.Proj，AntiCheatLog.cs:83-84）`)
  }
  // 反面：不得出现别处定义过的分类值（分类只有 item / proj / particle 三个，
  // 多出来的值说明有人从别的插件抄了分类枚举）
  assert.equal(containsUtf16(buf, 'particle-guard'), false,
    'DLL 里出现了 particle-guard（旧粒子防线插件的名字）—— 本件刻意不实现粒子检测（见 AntiCheatPlugin.cs:50-55），'
    + '粒子防线是另一个插件')
})

test('★★ 阴性对照：哨兵串与别的插件的表/类型必须扫不到（证明命中是有区分度的）★★', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  for (const [s, why] of NEGATIVE_CONTROLS) {
    assert.equal(
      containsString(buf, s), false,
      `DLL 里出现了 "${s}"：${why}。\n`
      + '  第 1 条（哨兵串）命中说明扫描逻辑不再有区分度，本文件其余用例全部不可信；\n'
      + '  其余命中说明有人把别的插件的表/类型/协议复制粘贴进来了（同名表会被双写，'
      + '两条统计互相污染，这正是本仓反复出现的坑）。',
    )
  }
  // 反过来必须出现本件自己的身份（否则上面的"扫不到"可能是"扫错了文件"）
  assert.equal(containsString(buf, 'AntiCheatPlugin'), true, '本件入口类型 AntiCheatPlugin 必须存在')
  assert.equal(containsUtf16(buf, 'CheatLog'), true, '本件的检测日志表名 CheatLog 必须存在')
  assert.equal(containsUtf16(buf, 'anticheat-config.json'), true, '本件的配置文件名必须存在')
  assert.equal(containsUtf16(buf, '/data/anticheat/snapshot'), true, '本件的新协议路由必须存在')
})
