/**
 * 卫生检查：全插件树「禁用 emoji」+ 编码/行尾/JSON 可解析。
 *
 * 权威判据来自本仓自己的约定（client/shared/api.js:18）：
 *   「禁止 emoji（界面符号只用本仓既有几何字符 ✕ ＋ − — ⠿ ▶ ★ →）；中文注释；引用位置写 `文件:行号`。」
 * 所以本测试**不是**"随便扫一遍"，而是把那条约定变成可执行断言，并且把"既有几何字符"作为
 * 反面控制组钉死：真 emoji 必须被抓到，既有字符必须一个都不误报。
 *
 * 三个容易写成"永远绿"的坑，本文件逐条防住：
 *   1) 扫错目录 / 扩展名写漏 → 会有"扫了 0 个文件也全绿"。故先断言扫描范围本身（文件数、扩展名集合、
 *      必须含哪些文件），并断言 bin/obj 确实存在于磁盘上（证明排除规则不是空转）。
 *   2) 判据写成空集（emojiRanges 写错 → 什么都不报）→ 正向控制组必须触发。
 *   3) 判据过宽（把 ★ U+2605 / ✕ U+2715 也当 emoji → 满屏误报）→ 反面控制组必须放行，
 *      且断言这两个字符**确实还在仓库里**（否则白名单就是死代码）。
 *
 * 本文件自身也在扫描范围内，因此这里一律用 String.fromCodePoint 构造码点，不写字面量 emoji。
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PLUGIN_DIR = path.resolve(__dirname, '..')

/** 受管扩展名（规格第 10 条：.js/.mjs/.cs/.csproj/.json） */
const SCAN_EXT = new Set(['.js', '.mjs', '.cs', '.csproj', '.json'])

/** 排除目录：构建产物与依赖（plugin/obj、plugin/bin 由 dotnet 生成，不是源码） */
const SKIP_DIRS = new Set(['bin', 'obj', '.git', 'node_modules', 'data', '.vs'])

/** 递归收集受管文件（排除 SKIP_DIRS 中的任意一层） */
function walk(dir, out = []) {
  let entries
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true })
  } catch {
    return out
  }
  for (const e of entries) {
    if (e.isDirectory()) {
      if (SKIP_DIRS.has(e.name)) continue
      walk(path.join(dir, e.name), out)
    } else if (e.isFile() && SCAN_EXT.has(path.extname(e.name).toLowerCase())) {
      out.push(path.join(dir, e.name))
    }
  }
  return out
}

/** 不做排除的收集（只用于证明"排除规则确实排掉了东西"） */
function walkRaw(dir, out = []) {
  let entries
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true })
  } catch {
    return out
  }
  for (const e of entries) {
    if (e.isDirectory()) {
      if (e.name === '.git' || e.name === 'node_modules') continue
      walkRaw(path.join(dir, e.name), out)
    } else if (e.isFile() && SCAN_EXT.has(path.extname(e.name).toLowerCase())) {
      out.push(path.join(dir, e.name))
    }
  }
  return out
}

const FILES = walk(PLUGIN_DIR)

/**
 * emoji 码点区间。
 * 刻意**只**收真正的 emoji 区：
 *   U+1F000–U+1FAFF  麻将/多米诺/扑克 + Emoji 主体（含 0x1F1E6–0x1F1FF 区域指示符=国旗）
 *   U+2600–U+27BF    杂项符号 + Dingbats（警告符 U+26A0、白勾 U+2705、红叉 U+274C、闪光 U+2728
 *                    都在这里，这是最容易混进"状态提示文案"的一类）
 *   U+2B00–U+2BFF    星 U+2B50、方块 U+2B1B/U+2B1C
 *   另加三个组合/修饰符：U+FE0F 变体选择符、U+200D 零宽连接符、U+20E3 键帽符
 * 注意 U+2460–U+24FF（①..⑩）与 U+25A0–U+25FF（▶ U+25B6）**不在**区间内：它们是本仓在用的排版字符。
 */
const EMOJI_RANGES = [
  [0x1f000, 0x1faff],
  [0x2600, 0x27bf],
  [0x2b00, 0x2bff],
  [0xfe0f, 0xfe0f],
  [0x200d, 0x200d],
  [0x20e3, 0x20e3],
]

/**
 * 白名单：本仓既有几何字符里**落在上面的 emoji 区间内**的两个。
 *   U+2605 ★  在 U+2600–U+27BF 内 —— 本仓用作文档注释前缀（见 client/shared/api.js:18 的字符表）
 *   U+2715 ✕  在 U+2600–U+27BF 内 —— 本仓用作关闭/删除按钮字形
 * 不加白名单就会把这两个天天在用的字形全报成 emoji。测试里另有断言证明它们确实还在仓库里。
 */
const ALLOWED_CODEPOINTS = new Set([0x2605, 0x2715])

/** 单个码点是否为"被禁的 emoji" */
function isBannedEmoji(cp) {
  if (ALLOWED_CODEPOINTS.has(cp)) return false
  return EMOJI_RANGES.some(([lo, hi]) => cp >= lo && cp <= hi)
}

/**
 * 扫一段文本，返回违规位置。
 * 行/列按"人看的"算：行从 1 起，列按 UTF-16 码元从 1 起（与编辑器一致）。
 */
function scanText(text) {
  const hits = []
  let line = 1
  let col = 1
  for (let i = 0; i < text.length; ) {
    const cp = text.codePointAt(i)
    const width = cp > 0xffff ? 2 : 1
    if (isBannedEmoji(cp)) {
      hits.push({ line, col, cp, hex: 'U+' + cp.toString(16).toUpperCase().padStart(4, '0') })
    }
    if (cp === 0x0a) {
      line++
      col = 1
    } else {
      col += width
    }
    i += width
  }
  return hits
}

/** 读文件文本（去掉 BOM，避免 BOM 被当成一个字符算进列号） */
function readText(file) {
  const raw = fs.readFileSync(file)
  const text = raw.toString('utf8')
  return text.charCodeAt(0) === 0xfeff ? text.slice(1) : text
}

const rel = (f) => path.relative(PLUGIN_DIR, f).replace(/\\/g, '/')

// ═══════════════════════ 1. 扫描范围自证 ═══════════════════════

test('卫生：扫描范围自证 —— 文件数、扩展名覆盖、必扫文件，防"扫了 0 个也全绿"', () => {
  assert.ok(
    FILES.length >= 20,
    `扫描到的受管文件只有 ${FILES.length} 个，疑似 walk()/扩展名写错：${FILES.map(rel).join(', ')}`,
  )

  const byExt = new Map()
  for (const f of FILES) {
    const e = path.extname(f).toLowerCase()
    byExt.set(e, (byExt.get(e) || 0) + 1)
  }
  // 五类扩展名都必须真的扫到（否则"某类文件没查"是静默漏洞）
  for (const e of SCAN_EXT) {
    assert.ok((byExt.get(e) || 0) > 0, `扩展名 ${e} 一个文件都没扫到，规则覆盖不全`)
  }
  // 不允许杂类混进来（说明 SCAN_EXT 没生效）
  for (const e of byExt.keys()) {
    assert.ok(SCAN_EXT.has(e), `扫描到了非受管扩展名 ${e}`)
  }

  // 钉住几个必须被扫到的关键文件（这两个目录任何一边漏掉都是大漏洞）
  const names = new Set(FILES.map(rel))
  for (const must of [
    'index.js',
    'config.js',
    'logs.js',
    'defaults.js',
    'gameOps.js',
    'package.json',
    'resources/物品违禁.json',
    'resources/弹幕违禁.json',
    'plugin/AntiCheat.cs',
    'plugin/AntiCheat.csproj',
  ]) {
    assert.ok(names.has(must), `关键文件未被扫描：${must}`)
  }
  // 客户端 js 也要在内（本次交付的回归点就在 client/）
  assert.ok(
    [...names].some((n) => n.startsWith('client/') && n.endsWith('.js')),
    'client/ 下的前端 js 没被扫描',
  )
})

test('卫生：排除规则非空转 —— bin/obj 确实存在于磁盘且被排除在外', () => {
  const excluded = ['bin', 'obj'].map((d) => path.join(PLUGIN_DIR, 'plugin', d))
  const present = excluded.filter((d) => fs.existsSync(d) && fs.readdirSync(d).length > 0)

  // 无论构建产物在不在，都不能出现在扫描结果里
  for (const f of FILES) {
    const segs = path.relative(PLUGIN_DIR, f).split(path.sep)
    for (const s of segs) {
      assert.ok(!SKIP_DIRS.has(s), `扫描结果里混进了被排除目录：${rel(f)}`)
    }
  }

  if (present.length > 0) {
    // 有构建产物时，不做排除应当扫到更多文件 → 证明 SKIP_DIRS 真的在起作用
    const raw = walkRaw(PLUGIN_DIR)
    assert.ok(
      raw.length > FILES.length,
      `bin/obj 存在（${present.map((d) => path.basename(d)).join(',')}）却不做排除也扫到 ${raw.length} 个，` +
        `与排除后的 ${FILES.length} 个相同，说明排除规则没生效`,
    )
  } else {
    // 干净检出：明确说明本项没被验证，而不是假装通过
    console.log('ℹ plugin/bin 与 plugin/obj 不存在（干净检出），"排除生效"仅由路径断言覆盖')
  }
})

// ═══════════════════════ 2. 正题：全树禁用 emoji ═══════════════════════

test('卫生：全插件树无 emoji（.js/.mjs/.cs/.csproj/.json）', () => {
  const bad = []
  let bytes = 0
  for (const f of FILES) {
    const text = readText(f)
    bytes += Buffer.byteLength(text, 'utf8')
    for (const h of scanText(text)) {
      const src = text.split('\n')[h.line - 1] || ''
      bad.push(`${rel(f)}:${h.line}:${h.col}: ${h.hex} 「${src.trim().slice(0, 60)}」`)
    }
  }
  assert.ok(bytes > 50000, `总共只读了 ${bytes} 字节，疑似读取失败`)
  assert.deepEqual(
    bad,
    [],
    '发现 emoji（约定见 client/shared/api.js:18，界面符号只用既有几何字符）：\n' + bad.join('\n'),
  )
})

// ═══════════════════════ 3. 判据双向对照 ═══════════════════════

test('卫生：判据正向对照 —— 真 emoji 必须被抓到（判据不许写成空集）', () => {
  // 覆盖每个区间各取代表 + 三个组合/修饰符
  const mustCatch = [
    0x1f680, // 火箭（U+1F000–1FAFF）
    0x1f525, // 火焰
    0x1f44d, // 竖大拇指
    0x1f1e8, // 区域指示符 C（国旗半边）
    0x26a0, // 警告（U+2600–27BF）
    0x2705, // 白勾
    0x274c, // 红叉
    0x2728, // 闪光
    0x2b50, // 星（U+2B00–2BFF）
    0xfe0f, // 变体选择符
    0x200d, // 零宽连接符
    0x20e3, // 键帽符
  ]
  for (const cp of mustCatch) {
    assert.equal(
      isBannedEmoji(cp),
      true,
      `U+${cp.toString(16).toUpperCase()} 是 emoji，判据却放行了（emoji 区间写错？）`,
    )
  }

  // 端到端：合成文本（含换行以验证行号）必须被抓到，且报对行号/码点
  const synthetic = 'const a = 1\n// 提示 ' + String.fromCodePoint(0x1f680) + ' 发射\nconst b = 2\n'
  const hits = scanText(synthetic)
  assert.equal(hits.length, 1, '合成文本里的 emoji 应恰好被抓到 1 处')
  assert.equal(hits[0].line, 2)
  assert.equal(hits[0].cp, 0x1f680)
  assert.equal(hits[0].hex, 'U+1F680')

  // 代理对也要算对列号（emoji 占 2 个 UTF-16 码元）
  const lineTwo = 'ab' + String.fromCodePoint(0x1f525) + 'cd'
  const h2 = scanText(lineTwo)
  assert.equal(h2[0].col, 3, 'emoji 的列号应为它在行内的起始列')
})

test('卫生：判据反面对照 —— 本仓既有几何/排版字符一个都不许误报（白名单不许死掉）', () => {
  // 全仓实测码点普查结果（避免"对照组是编的"）
  const inUse = [
    0x2013, 0x2014, 0x2026, 0x2039, 0x203a, 0x203b, 0x2190, 0x2192, 0x2194, 0x21c4,
    0x21d2, 0x2208, 0x2212, 0x2460, 0x2461, 0x2462, 0x2463, 0x2464, 0x2465, 0x2466,
    0x2467, 0x2468, 0x2469, 0x2500, 0x2550, 0x25b6, 0x2605, 0x2715, 0x283f,
  ]
  for (const cp of inUse) {
    assert.equal(
      isBannedEmoji(cp),
      false,
      `U+${cp.toString(16).toUpperCase()} 是本仓在用的几何/排版字符，却被判成 emoji（误报会让规则没法用）`,
    )
  }
  // 一并验证"既有字符组"整串不报
  assert.deepEqual(scanText(inUse.map((c) => String.fromCodePoint(c)).join('')), [])

  // 上面两个白名单项必须**真的还在仓库里**，否则白名单是死代码、本测试在自欺
  const all = FILES.map(readText).join('')
  for (const cp of [0x2605, 0x2715]) {
    assert.ok(
      all.includes(String.fromCodePoint(cp)),
      `白名单 U+${cp.toString(16).toUpperCase()} 已不在仓库中：请把它从 ALLOWED_CODEPOINTS 删掉，` +
        `不要让白名单留下无人使用的例外`,
    )
  }
  // 对照组非空转：普查里的多数码点应确实出现在树里
  const present = inUse.filter((cp) => all.includes(String.fromCodePoint(cp)))
  assert.ok(
    present.length >= 15,
    `只有 ${present.length}/${inUse.length} 个对照码点真的出现在树里，对照组成立在空集上`,
  )
})

// ═══════════════════════ 4. 编码与格式卫生 ═══════════════════════

test('卫生：无 BOM、行尾一律 LF、无 CR', () => {
  const bom = []
  const crlf = []
  const cr = []
  for (const f of FILES) {
    const raw = fs.readFileSync(f)
    if (raw.length >= 3 && raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf) bom.push(rel(f))
    if (raw.includes(0x0d)) {
      cr.push(rel(f))
      if (raw.includes(0x0d) && raw.includes(0x0a)) crlf.push(rel(f))
    }
  }
  assert.deepEqual(bom, [], '以下文件带 UTF-8 BOM（会污染 JSON.parse 与首行注释）：\n' + bom.join('\n'))
  assert.deepEqual(cr, [], '以下文件含 CR（行尾不统一）：\n' + cr.join('\n'))
  assert.deepEqual(crlf, [], '以下文件是 CRLF：\n' + crlf.join('\n'))
})

test('卫生：全部 .json 可被 JSON.parse，两份默认清单结构正确', () => {
  const jsons = FILES.filter((f) => f.toLowerCase().endsWith('.json'))
  assert.ok(jsons.length >= 3, `只找到 ${jsons.length} 个 json 文件`)

  for (const f of jsons) {
    const text = readText(f)
    let parsed
    assert.doesNotThrow(() => {
      parsed = JSON.parse(text)
    }, `${rel(f)} 不是合法 JSON（BOM/尾逗号/注释都会让插件读盘失败）`)
    assert.equal(typeof parsed, 'object', `${rel(f)} 顶层不是对象`)
    assert.notEqual(parsed, null)
  }

  // package.json 的 name 必须与插件目录名一致（宿主按 name 定位）
  const pkg = JSON.parse(readText(path.join(PLUGIN_DIR, 'package.json')))
  assert.equal(pkg.name, 'anti-cheat')

  // 两份默认清单：必须是「档位数组」，每档含 进度 + 条目数组
  const item = JSON.parse(readText(path.join(PLUGIN_DIR, 'resources', '物品违禁.json')))
  const proj = JSON.parse(readText(path.join(PLUGIN_DIR, 'resources', '弹幕违禁.json')))
  assert.ok(Array.isArray(item.限制列表), '物品违禁.json 的 限制列表 不是数组')
  assert.ok(Array.isArray(proj.限制列表), '弹幕违禁.json 的 限制列表 不是数组')
  assert.ok(item.限制列表.length > 0 && proj.限制列表.length > 0, '默认清单档位为空')
  for (const t of [...item.限制列表, ...proj.限制列表]) {
    assert.equal(typeof t.进度, 'string', '档位缺少 进度 字段')
  }
})

test('卫生：本测试自身也在扫描范围内（自证不是"只查别人不查自己"）', () => {
  const self = path.join(PLUGIN_DIR, 'test', 'hygiene.test.mjs')
  assert.ok(fs.existsSync(self), 'hygiene.test.mjs 自身应存在')
  assert.ok(
    FILES.some((f) => path.resolve(f) === path.resolve(self)),
    '本文件没有被 walk() 收进来：说明扫描范围排除了 test/ 或 mjs',
  )
  // 且本文件确实不含被判禁的码点（用构造方式，故本文件自身必须全绿）
  assert.deepEqual(scanText(readText(self)), [])
})
