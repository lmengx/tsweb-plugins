/**
 * 配置模型 / 归一 / 校验测试（规格第 1 条）。
 *
 * 覆盖四层：
 *   A. 常量与闭集：METHOD_VALUES（config.js:59 的 5 项闭集）、值域常量、进度权威顺序、
 *      以及「各档位是**叠加 union 而非互斥**」这一条（config.js:123-124 逐字声明）。
 *   B. 归一 normalizeConfig/normalizeMethod/normalizeCommand（config.js:229-469）：永不抛错、
 *      旧值迁移、脏值钳制且**不静默**（每处修复都进 warnings）。
 *   C. 严格校验 validateConfig（config.js:487-602）：该拒绝的必须拒绝，且"可接受但要迁移"的
 *      **不**拒绝（旧配置兼容）。
 *   D. 派生与载荷：progressOrder / configStats / configWarnings / toGamePayload / configFingerprint。
 *
 * 运行：`node test\config.test.mjs`（本机 `node --test test/` 不可用）。
 * 本文件不依赖假宿主，纯函数测试（config.js 的导出面）。
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  METHOD_VALUES,
  METHOD_LABELS,
  COMMAND_PLACEHOLDERS,
  QUICK_COMMANDS,
  ID_MIN,
  ID_MAX,
  INTERVAL_MIN,
  INTERVAL_MAX,
  DAMAGE_LIMIT_DEFAULT,
  DEFAULT_ITEM_SWITCHES,
  DEFAULT_PROJ_SWITCHES,
  PROGRESS_ORDER,
  ALWAYS_PROGRESS,
  KNOWN_PROGRESS,
  MAX_TIERS,
  MAX_ENTRIES_PER_TIER,
  ENTRY_KEY,
  defaultConfig,
  defaultItemEntry,
  defaultProjEntry,
  normalizeMethod,
  normalizeCommand,
  normalizeConfig,
  validateConfig,
  progressOrder,
  configStats,
  configWarnings,
  toGamePayload,
  configFingerprint,
} from '../config.js'

/** 造一个"干净"的两侧配置（来自默认值），避免每个用例手写一遍 */
function cleanConfig() {
  return defaultConfig()
}

/** 造一个物品档位 */
function itemTier(progress, entries) {
  return { 进度: progress, [ENTRY_KEY.item]: entries }
}

/** 造一个弹幕档位 */
function projTier(progress, entries) {
  return { 进度: progress, [ENTRY_KEY.proj]: entries }
}

// ═══════════════════════ A. 常量与闭集 ═══════════════════════

test('闭集：METHOD_VALUES 恰好 5 项且顺序固定（多一项/少一项都是协议漂移）', () => {
  assert.deepEqual(METHOD_VALUES, ['log', 'kick', 'ban', 'drop', 'command'])
  assert.equal(new Set(METHOD_VALUES).size, METHOD_VALUES.length, '闭集里不得有重复项')
  for (const m of METHOD_VALUES) assert.equal(typeof m, 'string')
})

test('闭集：METHOD_LABELS 覆盖闭集每一项、都非空中文，且不多不少', () => {
  assert.deepEqual(Object.keys(METHOD_LABELS).sort(), [...METHOD_VALUES].sort())
  for (const [k, v] of Object.entries(METHOD_LABELS)) {
    assert.equal(typeof v, 'string', `${k} 的说明必须是字符串`)
    assert.ok(v.trim().length > 0, `${k} 的说明不得为空`)
  }
  // 界面按钮 title 与 /scanlist 输出都读它（config.js:61-68）
  assert.equal(METHOD_LABELS.command, '执行自定义命令')
})

test('常量：占位符恰好旧版的 4 个，且长度/值域常量与声明一致', () => {
  assert.deepEqual(COMMAND_PLACEHOLDERS, ['{playername}', '{itemname}', '{itemid}', '{projid}'])
  for (const p of COMMAND_PLACEHOLDERS) {
    assert.match(p, /^\{[a-z]+\}$/, `占位符形态应为 {name}：${p}`)
  }
  assert.equal(ID_MIN, 1)
  assert.equal(ID_MAX, 65535, 'Terraria 的 netID 是 short')
  assert.equal(INTERVAL_MIN, 1)
  assert.equal(INTERVAL_MAX, 86400)
  assert.equal(DAMAGE_LIMIT_DEFAULT, 20000)
  assert.ok(MAX_TIERS > 0 && MAX_ENTRIES_PER_TIER > 0)
  assert.deepEqual(ENTRY_KEY, { item: '限制物品', proj: '限制弹幕' })
})

test('快捷命令：4 条模板，method 都在闭集内，模板都自带引号（转义口径的依据）', () => {
  assert.equal(QUICK_COMMANDS.length, 4)
  for (const q of QUICK_COMMANDS) {
    assert.ok(METHOD_VALUES.includes(q.method), `快捷命令的 method 必须在闭集内：${q.method}`)
    assert.equal(typeof q.label, 'string')
    assert.ok(q.label.trim().length > 0)
    assert.match(q.template, /^\//, `模板必须是完整命令（以 / 开头）：${q.template}`)
  }
  // 逐字旧版（config.js:74-83）：模板自带引号，所以占位符转义只转义 \ 与 "
  assert.equal(QUICK_COMMANDS[0].template, '/banp "{playername}" "违规使用{itemname}"')
  const withPlaceholder = QUICK_COMMANDS.filter((q) => /\{(playername|itemname|itemid|projid)\}/.test(q.template))
  assert.equal(withPlaceholder.length, 4, '4 条模板都应含占位符')
})

test('默认值：两侧开关逐字（含「没收违禁物品」—— 旧默认清单缺此键曾导致静默重置）', () => {
  assert.deepEqual(DEFAULT_ITEM_SWITCHES, {
    启用: false,
    自动扫描: true,
    扫描间隔: 10,
    没收违禁物品: false,
  })
  assert.deepEqual(DEFAULT_PROJ_SWITCHES, { 启用: false, 伤害上限: 20000 })
  // 检测默认关闭：绝不因为"读不懂配置"就按启用乱踢人（index.js:189-191）
  assert.equal(DEFAULT_ITEM_SWITCHES.启用, false)
  assert.equal(DEFAULT_PROJ_SWITCHES.启用, false)
})

test('进度顺序：25 项、首项「始终生效」、无重复、含本次新增的「巨鹿」', () => {
  assert.equal(PROGRESS_ORDER[0], ALWAYS_PROGRESS)
  assert.equal(ALWAYS_PROGRESS, '始终生效')
  assert.equal(new Set(PROGRESS_ORDER).size, PROGRESS_ORDER.length, '权威顺序里不得有重复档位')
  assert.equal(PROGRESS_ORDER.length, 25, `权威顺序应是 25 项，实际 ${PROGRESS_ORDER.length}`)
  assert.ok(PROGRESS_ORDER.includes('巨鹿'), '本次新增的「巨鹿」档必须在权威顺序里')
  // 巨鹿插在 蜂后 与 骷髅王 之间（与 BossProgress.BossOrder 一致）
  assert.equal(PROGRESS_ORDER[PROGRESS_ORDER.indexOf('蜂后') + 1], '巨鹿')
  assert.equal(PROGRESS_ORDER[PROGRESS_ORDER.indexOf('巨鹿') + 1], '骷髅王')
  // KNOWN_PROGRESS 必须与权威顺序同集合
  assert.equal(KNOWN_PROGRESS.size, PROGRESS_ORDER.length)
  for (const p of PROGRESS_ORDER) assert.ok(KNOWN_PROGRESS.has(p))
})

test('档次语义：各档位是**叠加 union 而非互斥**（档位是列表而不是"进度到档位"的映射）', () => {
  // config.js:123-124 逐字：各档之间是叠加 union 而非互斥（旧 item-restrict.cs:129-141 把所有
  // 仍生效档位的物品合并成一张清单）。宿主侧的可观察推论：
  //   ① 「始终生效」与其它档位**并存**，不是二选一；
  //   ② 同一个条目可以同时出现在多个档位里（union 的两半），归一不得去重或互相覆盖；
  //   ③ 同名档位重复出现时不得被折叠（否则 union 会丢一半）。
  assert.equal(PROGRESS_ORDER[0], ALWAYS_PROGRESS, '「始终生效」必须是第一档且始终参与 union')

  const sameIdInTwoTiers = {
    item: {
      ...DEFAULT_ITEM_SWITCHES,
      限制列表: [
        itemTier('始终生效', [{ id: 267, stack: 1, method: 'ban', command: '' }]),
        itemTier('蜂后', [{ id: 267, stack: 1, method: 'kick', command: '' }]),
      ],
    },
    proj: { ...DEFAULT_PROJ_SWITCHES, 限制列表: [] },
  }
  const { config, warnings } = normalizeConfig(sameIdInTwoTiers)
  assert.equal(config.item.限制列表.length, 2, '两个档位都必须保留（union 的两半）')
  assert.equal(config.item.限制列表[0].限制物品[0].id, 267)
  assert.equal(config.item.限制列表[1].限制物品[0].id, 267)
  assert.deepEqual(
    warnings,
    [],
    '同一个 id 出现在两个档位是完全正常的 union 用法，不该有任何警告',
  )

  // 同名档位重复出现：保留（不去重）
  const dupTier = {
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [{ id: 1, stack: 1, method: 'log', command: '' }]), itemTier('蜂后', [{ id: 2, stack: 1, method: 'log', command: '' }])] },
    proj: { ...DEFAULT_PROJ_SWITCHES, 限制列表: [] },
  }
  assert.equal(normalizeConfig(dupTier).config.item.限制列表.length, 2, '同名档位不得被折叠')

  // 反证：这是"列表"而不是"按进度索引的映射"——否则两档会塌成一档
  const asMap = Object.fromEntries(normalizeConfig(sameIdInTwoTiers).config.item.限制列表.map((t) => [t.进度, t]))
  assert.equal(Object.keys(asMap).length, 2)
})

// ═══════════════════════ B. method / command 归一 ═══════════════════════

test('normalizeMethod：空值一律当标准档 log（旧版 `?? "log"` 的行为），且不标 migrated', () => {
  for (const raw of ['', '   ', null, undefined]) {
    const m = normalizeMethod(raw)
    assert.equal(m.method, 'log', `${JSON.stringify(raw)} 应归为 log`)
    assert.equal(m.command, '')
    assert.equal(m.migrated, false)
  }
})

test('normalizeMethod：闭集成员大小写不敏感、先 trim；非闭集值迁移为 command 且命令文本不丢（D-A 回归）', () => {
  for (const m of METHOD_VALUES) {
    const r = normalizeMethod(m)
    assert.equal(r.method, m)
    assert.equal(r.migrated, false)
    assert.equal(r.command, '')
  }
  // trim + 大小写宽容化（config.js:222-225 明确这是有意的）
  for (const raw of [' KICK ', 'Kick', 'ban', '\tBan\n', 'COMMAND']) {
    const r = normalizeMethod(raw)
    assert.equal(r.method, raw.trim().toLowerCase(), `${JSON.stringify(raw)} 应归一为小写闭集值`)
    assert.equal(r.migrated, false)
  }

  // 非闭集值：旧版会当命令模板执行（D-34 任意命令执行）→ 必须迁移，且**原文本必须保住**
  for (const raw of ['/say hi', 'jail 5', '  /bc 大家好  ', 'kill']) {
    const r = normalizeMethod(raw)
    assert.equal(r.method, 'command', `${JSON.stringify(raw)} 应迁移为 command`)
    assert.equal(r.migrated, true)
    assert.equal(r.command, String(raw).trim(), '迁移后的命令文本必须等于原值（trim 后），绝不能丢')
    assert.equal(r.raw, raw, 'raw 必须保留原始值（警告文案要用它）')
    assert.ok(r.command.length > 0)
  }
})

test('normalizeCommand：补斜杠要如实标记 prefixed（不能静默改值）', () => {
  assert.deepEqual(normalizeCommand(''), { command: '', prefixed: false })
  assert.deepEqual(normalizeCommand('   '), { command: '', prefixed: false })
  assert.deepEqual(normalizeCommand(null), { command: '', prefixed: false })
  assert.deepEqual(normalizeCommand(undefined), { command: '', prefixed: false })
  assert.deepEqual(normalizeCommand('/say hi'), { command: '/say hi', prefixed: false })
  assert.deepEqual(normalizeCommand('  /say hi  '), { command: '/say hi', prefixed: false })
  const prefixed = normalizeCommand('say hi')
  assert.equal(prefixed.command, '/say hi')
  assert.equal(prefixed.prefixed, true, '发生补斜杠时必须置 prefixed=true（要记警告）')
})

test('D-A 回归：旧版裸命令（method 是自由文本）归一后 command **不得为空**，且警告文案与落盘值一致', () => {
  const raw = {
    item: {
      ...DEFAULT_ITEM_SWITCHES,
      限制列表: [itemTier('蜂后', [{ id: 267, stack: 1, method: '/banp "玩家" "违规"', command: '' }])],
    },
    proj: { ...DEFAULT_PROJ_SWITCHES, 限制列表: [] },
  }
  const { config, warnings } = normalizeConfig(raw)
  const entry = config.item.限制列表[0].限制物品[0]
  assert.equal(entry.method, 'command')
  assert.equal(
    entry.command,
    '/banp "玩家" "违规"',
    'method 是旧版自由文本时，命令文本必须迁移进 command —— 落盘成 command:"" 等于静默丢命令',
  )
  // 迁移警告必须存在，并且**文案里的命令**要和真正落盘的那条一致（不能一个说 A 一个存 B）
  const w = warnings.find((s) => s.includes('旧版自由文本'))
  assert.ok(w, `必须有迁移警告，实际：${JSON.stringify(warnings)}`)
  assert.ok(w.includes(JSON.stringify(entry.command)), `警告文案里的命令必须与实际落盘值一致：${w}`)
})

test('归一时 method!=command 却带 command：**保留**命令但必须警告"当前不会执行"', () => {
  const raw = {
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [{ id: 267, stack: 1, method: 'ban', command: '/say hi' }])] },
    proj: { ...DEFAULT_PROJ_SWITCHES, 限制列表: [] },
  }
  const { config, warnings } = normalizeConfig(raw)
  const entry = config.item.限制列表[0].限制物品[0]
  assert.equal(entry.method, 'ban')
  assert.equal(entry.command, '/say hi', 'command 是"切回标准档前的草稿"，不得清空')
  assert.ok(
    warnings.some((s) => s.includes('当前处置不会执行该命令')),
    `必须让"它当前不会被使用"可见：${JSON.stringify(warnings)}`,
  )
})

test('归一时 command 不以 / 开头 → 补斜杠并警告（旧版 ExecuteCommand 同样会自动补）', () => {
  const raw = {
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [{ id: 267, stack: 1, method: 'command', command: 'say hi' }])] },
    proj: { ...DEFAULT_PROJ_SWITCHES, 限制列表: [] },
  }
  const { config, warnings } = normalizeConfig(raw)
  assert.equal(config.item.限制列表[0].限制物品[0].command, '/say hi')
  assert.ok(warnings.some((s) => s.includes('不以 / 开头')), `补斜杠必须记警告：${JSON.stringify(warnings)}`)
})

// ═══════════════════════ B2. 归一：宽容与钳制，且绝不静默 ═══════════════════════

test('normalizeConfig 永不抛错：畸形输入一律回落默认，且不修改输入对象', () => {
  const weird = [undefined, null, 42, '字符串', [], true, { item: 42, proj: 'x' }, { item: { 限制列表: 'x' } }]
  for (const raw of weird) {
    let out
    assert.doesNotThrow(() => {
      out = normalizeConfig(raw)
    }, `normalizeConfig(${JSON.stringify(raw)}) 不得抛错（读盘路径必须"读不懂也能起来"）`)
    assert.ok(out && out.config, '必须总是返回 config')
    assert.ok(Array.isArray(out.warnings), '必须总是返回 warnings 数组')
    assert.deepEqual(Object.keys(out.config).sort(), ['item', 'proj'])
    assert.equal(out.config.item.启用, false, '回落时必须是"检测未启用"，绝不乱踢人')
    assert.equal(out.config.proj.启用, false)
  }
  // 只有"非空且非对象"才记警告；undefined/null 是"文件不存在"，不算异常
  assert.deepEqual(normalizeConfig(undefined).warnings, [])
  assert.deepEqual(normalizeConfig(null).warnings, [])
  assert.ok(normalizeConfig(42).warnings.length > 0)
  assert.ok(normalizeConfig('x').warnings.some((s) => s.includes('不是 JSON 对象')))
})

test('normalizeConfig 不修改输入对象（深拷贝隔离）', () => {
  const raw = {
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [{ id: 267, stack: 1, method: 'ban', command: '' }])] },
    proj: { ...DEFAULT_PROJ_SWITCHES, 限制列表: [] },
  }
  const snapshot = JSON.parse(JSON.stringify(raw))
  const { config } = normalizeConfig(raw)
  assert.deepEqual(raw, snapshot, 'normalizeConfig 不得就地修改入参')
  // 改归一结果不得影响入参，也不得影响下一次 defaultConfig()
  config.item.限制列表[0].限制物品[0].id = 9999
  config.item.启用 = true
  assert.equal(raw.item.限制列表[0].限制物品[0].id, 267)
  assert.equal(raw.item.启用, false)
  assert.equal(defaultConfig().item.启用, false)
})

test('normalizeConfig 幂等：归一两次 == 归一一次', () => {
  const raw = {
    item: {
      启用: 'true',
      自动扫描: 'false',
      扫描间隔: '15',
      限制列表: [
        itemTier('蜂后', [{ id: '267', stack: '3', method: ' KICK ', command: 'say hi' }]),
        itemTier('未知档位X', [{ id: 5, stack: 1, method: '/custom cmd', command: '' }]),
      ],
    },
    proj: { 启用: true, 伤害上限: '15000', 限制列表: [projTier('始终生效', [{ id: 100, method: 'drop', command: '' }])] },
  }
  const once = normalizeConfig(raw).config
  const twice = normalizeConfig(once).config
  assert.deepEqual(twice, once, '归一必须是幂等的（否则每次读盘都会漂移）')
  // 第二次归一不得再做任何"修复"：迁移/补斜杠/钳制这三类警告必须消失
  // （"command 草稿不会被使用"那类警告是配置**状态**的如实描述，会每次都报，属正常）
  const second = normalizeConfig(once).warnings
  for (const kw of ['旧版自由文本', '不以 / 开头', '钳制', '回落', '已跳过']) {
    assert.ok(!second.some((s) => s.includes(kw)), `第二次归一不该再出现「${kw}」类修复警告：${JSON.stringify(second)}`)
  }
})

test('旧版单文件形态兼容：顶层即 启用/限制列表 → 按 item 读；顶层含 伤害上限 → 按 proj 读', () => {
  const oldItem = { 启用: true, 自动扫描: true, 扫描间隔: 10, 限制列表: [itemTier('蜂后', [{ id: 267, stack: 1, method: 'ban', command: '' }])] }
  const a = normalizeConfig(oldItem)
  assert.equal(a.config.item.启用, true, '旧「物品违禁.json」单文件形态必须被认出来')
  assert.equal(a.config.item.限制列表.length, 1)
  assert.equal(a.config.proj.启用, false)
  assert.ok(a.warnings.some((s) => s.includes('物品违禁') && s.includes('单文件形态')), `应记兼容警告：${JSON.stringify(a.warnings)}`)

  const oldProj = { 启用: true, 伤害上限: 15000, 限制列表: [projTier('始终生效', [{ id: 100, method: 'drop', command: '' }])] }
  const b = normalizeConfig(oldProj)
  assert.equal(b.config.proj.启用, true, '旧「弹幕违禁.json」单文件形态必须被认出来')
  assert.equal(b.config.proj.伤害上限, 15000)
  assert.equal(b.config.proj.限制列表.length, 1)
  assert.ok(b.warnings.some((s) => s.includes('弹幕违禁') && s.includes('单文件形态')), `应记兼容警告：${JSON.stringify(b.warnings)}`)
})

test('归一：布尔值宽容（字符串 true/false 认；其它回落默认）', () => {
  const cases = [
    [true, true],
    [false, false],
    ['true', true],
    ['TRUE', true],
    [' False ', false],
    ['yes', DEFAULT_ITEM_SWITCHES.启用],
    [1, DEFAULT_ITEM_SWITCHES.启用],
    [null, DEFAULT_ITEM_SWITCHES.启用],
  ]
  for (const [input, expected] of cases) {
    const cfg = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 启用: input }, proj: DEFAULT_PROJ_SWITCHES }).config
    assert.equal(cfg.item.启用, expected, `启用=${JSON.stringify(input)} 应归一为 ${expected}`)
  }
  // 三个布尔键都要走同一条宽容路径
  const cfg = normalizeConfig({
    item: { 启用: 'true', 自动扫描: 'false', 没收违禁物品: 'true' },
    proj: { 启用: 'false', 伤害上限: 20000 },
  }).config
  assert.deepEqual(
    { 启用: cfg.item.启用, 自动扫描: cfg.item.自动扫描, 没收违禁物品: cfg.item.没收违禁物品 },
    { 启用: true, 自动扫描: false, 没收违禁物品: true },
  )
})

test('归一：扫描间隔 —— 旧字段迁移、非法回落、越界钳制，三件事都必须记警告', () => {
  // 旧字段名迁移（旧 AntiCheat.cs:280-289）
  const legacy = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 扫描间隔: 0, '自动扫描间隔-秒': 30 }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(legacy.config.item.扫描间隔, 30)
  assert.ok(legacy.warnings.some((s) => s.includes('自动扫描间隔-秒')), `旧字段迁移必须记警告：${JSON.stringify(legacy.warnings)}`)

  // 非法值回落默认 10
  for (const bad of ['abc', {}, [], '1.5', ' ']) {
    const r = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 扫描间隔: bad }, proj: DEFAULT_PROJ_SWITCHES })
    assert.equal(r.config.item.扫描间隔, 10, `扫描间隔=${JSON.stringify(bad)} 应回落 10`)
    assert.ok(r.warnings.some((s) => s.includes('扫描间隔')), `非法值必须记警告：${JSON.stringify(r.warnings)}`)
  }

  // 越界钳制（0 会变成扫描风暴）
  const low = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 扫描间隔: 0 }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(low.config.item.扫描间隔, INTERVAL_MIN)
  assert.ok(low.warnings.some((s) => s.includes('钳制')), '钳制必须记警告，绝不静默改值')
  const high = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 扫描间隔: 999999 }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(high.config.item.扫描间隔, INTERVAL_MAX)

  // 数字字符串认（toInt 宽容），小数不认
  assert.equal(normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 扫描间隔: '15' }, proj: DEFAULT_PROJ_SWITCHES }).config.item.扫描间隔, 15)
})

test('归一：伤害上限 <=0 是最危险的配置事故（会让每条弹幕都判异常）→ 钳回默认并警告', () => {
  for (const bad of [0, -1, -99999]) {
    const r = normalizeConfig({ item: DEFAULT_ITEM_SWITCHES, proj: { ...DEFAULT_PROJ_SWITCHES, 伤害上限: bad } })
    assert.equal(r.config.proj.伤害上限, DAMAGE_LIMIT_DEFAULT, `伤害上限=${bad} 必须钳回默认`)
    assert.ok(
      r.warnings.some((s) => s.includes('伤害上限') && s.includes('异常伤害')),
      `必须说清后果：${JSON.stringify(r.warnings)}`,
    )
  }
  // 非法（非整数）→ 回落默认 + 警告
  const nan = normalizeConfig({ item: DEFAULT_ITEM_SWITCHES, proj: { ...DEFAULT_PROJ_SWITCHES, 伤害上限: 'x' } })
  assert.equal(nan.config.proj.伤害上限, DAMAGE_LIMIT_DEFAULT)
  assert.ok(nan.warnings.some((s) => s.includes('伤害上限')))
  // 正数正常保留（含 1）
  assert.equal(normalizeConfig({ item: DEFAULT_ITEM_SWITCHES, proj: { ...DEFAULT_PROJ_SWITCHES, 伤害上限: 1 } }).config.proj.伤害上限, 1)
  assert.equal(normalizeConfig({ item: DEFAULT_ITEM_SWITCHES, proj: { ...DEFAULT_PROJ_SWITCHES, 伤害上限: '12345' } }).config.proj.伤害上限, 12345)
})

test('归一：未知档位**保留而非删除**，但必须记警告（服端对它恒判不生效）', () => {
  const r = normalizeConfig({
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('自定义档位X', [{ id: 267, stack: 1, method: 'ban', command: '' }])] },
    proj: DEFAULT_PROJ_SWITCHES,
  })
  assert.equal(r.config.item.限制列表.length, 1, '未知档位必须原样保留（写侧不得把它删掉）')
  assert.equal(r.config.item.限制列表[0].进度, '自定义档位X')
  assert.equal(r.config.item.限制列表[0].限制物品.length, 1, '未知档位里的条目也必须保留')
  assert.ok(
    r.warnings.some((s) => s.includes('自定义档位X') && s.includes('未删除')),
    `未知档位必须记警告且说明"已保留"：${JSON.stringify(r.warnings)}`,
  )
  // 并且它会出现在派生的顺序末尾（前端按它画卡片，才不会一保存就丢）
  assert.ok(progressOrder(r.config).includes('自定义档位X'))
})

test('归一：档位/条目的结构性脏值 —— 跳过脏项、保留好项，逐条记警告', () => {
  const r = normalizeConfig({
    item: {
      ...DEFAULT_ITEM_SWITCHES,
      限制列表: [
        itemTier('蜂后', [{ id: 267, stack: 1, method: 'ban', command: '' }]),
        42, // 档位不是对象
        itemTier('', [{ id: 1, stack: 1, method: 'log', command: '' }]), // 进度为空 → 跳过整档
      ],
    },
    proj: DEFAULT_PROJ_SWITCHES,
  })
  assert.equal(r.config.item.限制列表.length, 1, '只有合法的那一档留下')
  assert.equal(r.config.item.限制列表[0].进度, '蜂后')
  assert.ok(r.warnings.some((s) => s.includes('不是对象')), `非对象档位要记警告：${JSON.stringify(r.warnings)}`)
  assert.ok(r.warnings.some((s) => s.includes('「进度」为空')), `空进度要记警告：${JSON.stringify(r.warnings)}`)

  // 限制列表本身不是数组
  const notArr = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: 'x' }, proj: DEFAULT_PROJ_SWITCHES })
  assert.deepEqual(notArr.config.item.限制列表, [])
  assert.ok(notArr.warnings.some((s) => s.includes('不是数组')))
  // 限制列表未提供 → 空数组，且**不**警告（缺省是正常的）
  assert.deepEqual(normalizeConfig({ item: DEFAULT_ITEM_SWITCHES, proj: DEFAULT_PROJ_SWITCHES }).warnings, [])

  // 档位里条目不是数组
  const badEntries = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [{ 进度: '蜂后', 限制物品: 'x' }] }, proj: DEFAULT_PROJ_SWITCHES })
  assert.deepEqual(badEntries.config.item.限制列表[0].限制物品, [])
  assert.ok(badEntries.warnings.some((s) => s.includes('条目不是数组')))

  // 条目不是对象 → 跳过
  const badEntry = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [1, null, { id: 5, stack: 1, method: 'log', command: '' }])] }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(badEntry.config.item.限制列表[0].限制物品.length, 1)
  assert.ok(badEntry.warnings.some((s) => s.includes('不是对象')))
})

test('归一：档位数与单档条目数超上限 —— 截断到上限并记警告（不静默丢）', () => {
  const manyTiers = []
  for (let i = 0; i < MAX_TIERS + 3; i++) manyTiers.push(itemTier(`档位${i}`, []))
  const t = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: manyTiers }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(t.config.item.限制列表.length, MAX_TIERS, `档位数必须截到 ${MAX_TIERS}`)
  assert.ok(t.warnings.some((s) => s.includes(String(MAX_TIERS))), `截断必须记警告：${JSON.stringify(t.warnings.slice(0, 3))}`)

  const many = []
  for (let i = 0; i < MAX_ENTRIES_PER_TIER + 2; i++) many.push({ id: i + 1, stack: 1, method: 'log', command: '' })
  const e = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', many)] }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(e.config.item.限制列表[0].限制物品.length, MAX_ENTRIES_PER_TIER, `单档条目必须截到 ${MAX_ENTRIES_PER_TIER}`)
  assert.ok(e.warnings.some((s) => s.includes(String(MAX_ENTRIES_PER_TIER))))
})

test('归一：id 必须落在 [1, 65535] —— 越界跳过并警告（脏 ID 会让合法物品被误判）', () => {
  const entries = [
    { id: 0, stack: 1, method: 'log', command: '' },
    { id: -1, stack: 1, method: 'log', command: '' },
    { id: 65536, stack: 1, method: 'log', command: '' },
    { id: 'abc', stack: 1, method: 'log', command: '' },
    { id: 267, stack: 1, method: 'log', command: '' },
    { id: '268', stack: 1, method: 'log', command: '' },
    { id: 65535, stack: 1, method: 'log', command: '' },
  ]
  const r = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', entries)] }, proj: DEFAULT_PROJ_SWITCHES })
  const kept = r.config.item.限制列表[0].限制物品
  assert.deepEqual(kept.map((e) => e.id), [267, 268, 65535], '只有合法 id 留下（数字字符串认，越界/非整数丢）')
  assert.equal(r.warnings.filter((s) => s.includes('不在')).length, 4, '每一条脏 id 都要有自己的警告')
})

test('D-F 回归：小数一律**不当整数**（不许静默截断成另一个物品/另一个扫描频率）', () => {
  // id=1.5 若被 Math.trunc 成 1，就是把规则悄悄指向 1 号物品（误伤且看不出原因）
  const idCase = normalizeConfig({
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [{ id: 1.5, stack: 1, method: 'log', command: '' }, { id: 267, stack: 1, method: 'log', command: '' }])] },
    proj: DEFAULT_PROJ_SWITCHES,
  })
  assert.deepEqual(idCase.config.item.限制列表[0].限制物品.map((e) => e.id), [267], 'id=1.5 必须被跳过，不得截成 1')
  assert.ok(idCase.warnings.some((s) => s.includes('1.5') && s.includes('不在')), `必须警告：${JSON.stringify(idCase.warnings)}`)

  // 扫描间隔 1.5 若被截成 1，扫描频率会变成预期的 10 倍
  const iv = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 扫描间隔: 1.5 }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(iv.config.item.扫描间隔, 10, '扫描间隔=1.5 必须回落默认，不得截成 1')
  assert.ok(iv.warnings.some((s) => s.includes('扫描间隔')), `必须警告：${JSON.stringify(iv.warnings)}`)

  // 伤害上限 / stack 同理
  assert.equal(normalizeConfig({ item: DEFAULT_ITEM_SWITCHES, proj: { ...DEFAULT_PROJ_SWITCHES, 伤害上限: 1.5 } }).config.proj.伤害上限, DAMAGE_LIMIT_DEFAULT)
  const st = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [{ id: 267, stack: 2.7, method: 'log', command: '' }])] }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(st.config.item.限制列表[0].限制物品[0].stack, 1, 'stack=2.7 必须回落 1（不是截成 2）')
  assert.ok(st.warnings.some((s) => s.includes('stack')), `stack 小数必须警告：${JSON.stringify(st.warnings)}`)

  // 严格校验路径同样必须**拒绝**小数（不能"校验通过然后悄悄改值"）
  const strict = validateConfig({
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [{ id: 1.5, stack: 1, method: 'log', command: '' }])] },
    proj: DEFAULT_PROJ_SWITCHES,
  })
  assert.equal(strict.config, null, 'id=1.5 必须被写盘校验拒绝')
  assert.ok(strict.errors.some((e) => e.path.endsWith('.id')), JSON.stringify(strict.errors))
  const strictIv = validateConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 扫描间隔: 1.5 }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(strictIv.config, null, '扫描间隔=1.5 必须被写盘校验拒绝（"必须是整数"要真的成立）')

  // 整数值的浮点写法仍要认（20000.0 就是 20000，不是"小数"）
  assert.equal(normalizeConfig({ item: DEFAULT_ITEM_SWITCHES, proj: { ...DEFAULT_PROJ_SWITCHES, 伤害上限: 20000.0 } }).config.proj.伤害上限, 20000)
  assert.equal(normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 扫描间隔: 10.0 }, proj: DEFAULT_PROJ_SWITCHES }).config.item.扫描间隔, 10)
})

test('归一：重复 id 全部保留（旧版重复即多档叠加），但记警告', () => {
  const list = [itemTier('蜂后', [{ id: 267, stack: 1, method: 'ban', command: '' }, { id: 267, stack: 1, method: 'kick', command: '' }])]
  const r = normalizeConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: list }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(r.config.item.限制列表[0].限制物品.length, 2, '重复项必须保留（不删除）')
  assert.ok(r.warnings.some((s) => s.includes('重复')), `重复必须记警告：${JSON.stringify(r.warnings)}`)
})

test('归一：item 的 stack 钳制（1 起），proj 侧没有 stack 字段（键集合精确）', () => {
  const mk = (stack) => normalizeConfig({
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [{ id: 267, stack, method: 'log', command: '' }])] },
    proj: DEFAULT_PROJ_SWITCHES,
  })
  assert.equal(mk(3).config.item.限制列表[0].限制物品[0].stack, 3)
  assert.equal(mk('3').config.item.限制列表[0].限制物品[0].stack, 3)
  assert.equal(mk(undefined).config.item.限制列表[0].限制物品[0].stack, 1, 'stack 缺省 = 1')
  for (const bad of [0, -1, 'x']) {
    const r = mk(bad)
    assert.equal(r.config.item.限制列表[0].限制物品[0].stack, 1, `stack=${JSON.stringify(bad)} 必须钳到 1`)
  }
  // stack<=0 是最危险的一类：任何数量（含持 0 个）都会命中
  assert.ok(mk(0).warnings.some((s) => s.includes('任意数量')), `stack=0 必须说清后果：${JSON.stringify(mk(0).warnings)}`)

  // 键集合精确：多一个字段就是协议漂移
  const itemEntry = normalizeConfig({
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [{ id: 1, stack: 1, method: 'log', command: '', extra: 'x' }])] },
    proj: DEFAULT_PROJ_SWITCHES,
  }).config.item.限制列表[0].限制物品[0]
  assert.deepEqual(Object.keys(itemEntry).sort(), ['command', 'id', 'method', 'stack'], 'item 条目必须恰好这 4 个字段')

  const projEntry = normalizeConfig({
    item: DEFAULT_ITEM_SWITCHES,
    proj: { ...DEFAULT_PROJ_SWITCHES, 限制列表: [projTier('始终生效', [{ id: 100, method: 'drop', command: '', stack: 9 }])] },
  }).config.proj.限制列表[0].限制弹幕[0]
  assert.deepEqual(Object.keys(projEntry).sort(), ['command', 'id', 'method'], 'proj 条目必须恰好这 3 个字段（弹幕侧没有 stack）')
})

test('归一：档位对象的键集合精确（进度 + 对应条目字段）', () => {
  const c = normalizeConfig({
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', []), { 进度: '蜂后', 限制物品: [], 其它: 1 }] },
    proj: { ...DEFAULT_PROJ_SWITCHES, 限制列表: [projTier('始终生效', [])] },
  }).config
  for (const tier of c.item.限制列表) {
    assert.deepEqual(Object.keys(tier).sort(), ['进度', ENTRY_KEY.item].sort(), '物品档位恰好 进度 + 限制物品')
  }
  assert.deepEqual(Object.keys(c.proj.限制列表[0]).sort(), ['进度', ENTRY_KEY.proj].sort(), '弹幕档位恰好 进度 + 限制弹幕')
})

// ═══════════════════════ C. validateConfig（严格校验）═══════════════════════

test('validateConfig：非对象请求体直接拒绝；合法配置通过且 warnings 里带上归一事实', () => {
  const bad = validateConfig('x')
  assert.equal(bad.config, null)
  assert.equal(bad.errors.length, 1)
  assert.equal(bad.errors[0].path, '')
  assert.match(bad.errors[0].message, /JSON 对象/)
  assert.equal(validateConfig(null).config, null)
  assert.equal(validateConfig([]).config, null)

  // item/proj 不是对象
  const t = validateConfig({ item: 42 })
  assert.equal(t.config, null)
  assert.ok(t.errors.some((e) => e.path === 'item' && e.message.includes('必须是对象')))

  const good = validateConfig({
    item: { 启用: true, 自动扫描: true, 扫描间隔: 10, 没收违禁物品: false, 限制列表: [itemTier('蜂后', [{ id: 267, stack: 1, method: 'ban', command: '' }])] },
    proj: { 启用: false, 伤害上限: 20000, 限制列表: [projTier('始终生效', [{ id: 100, method: 'drop', command: '' }])] },
  })
  assert.deepEqual(good.errors, [], `合法配置不该有任何 error：${JSON.stringify(good.errors)}`)
  assert.ok(good.config, '合法配置必须给出归一后的 config')
  assert.equal(good.config.item.限制列表[0].限制物品[0].id, 267)
  assert.ok(Array.isArray(good.warnings))
})

test('validateConfig 反面：id / stack / method 的非法值必须被拒绝，且 path 精确', () => {
  const mk = (entry) => validateConfig({
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [entry])] },
    proj: DEFAULT_PROJ_SWITCHES,
  })
  const base = { id: 267, stack: 1, method: 'ban', command: '' }

  for (const [bad, why] of [
    [{ ...base, id: 0 }, 'id=0'],
    [{ ...base, id: -5 }, 'id 负数'],
    [{ ...base, id: 65536 }, 'id 超上限'],
    [{ ...base, id: 'abc' }, 'id 非数字'],
    [{ ...base, id: undefined }, 'id 缺失'],
  ]) {
    const r = mk(bad)
    assert.equal(r.config, null, `${why} 必须被拒绝`)
    assert.ok(r.errors.some((e) => e.path.endsWith('.id')), `${why} 的 error path 必须指向 id：${JSON.stringify(r.errors)}`)
  }

  for (const [bad, why] of [
    [{ ...base, stack: 0 }, 'stack=0'],
    [{ ...base, stack: -1 }, 'stack 负数'],
    [{ ...base, stack: 'x' }, 'stack 非数字'],
  ]) {
    const r = mk(bad)
    assert.equal(r.config, null, `${why} 必须被拒绝`)
    assert.ok(r.errors.some((e) => e.path.endsWith('.stack')), `${why} 的 path 必须指向 stack：${JSON.stringify(r.errors)}`)
  }

  for (const [bad, why] of [
    [{ ...base, method: '' }, 'method 空串'],
    [{ ...base, method: '   ' }, 'method 空白'],
    [{ ...base, method: undefined }, 'method 缺失'],
    [{ ...base, method: null }, 'method=null'],
  ]) {
    const r = mk(bad)
    assert.equal(r.config, null, `${why} 必须被拒绝（本件要求显式写清 method）`)
    const e = r.errors.find((x) => x.path.endsWith('.method'))
    assert.ok(e, `${why} 的 path 必须指向 method：${JSON.stringify(r.errors)}`)
    assert.ok(e.message.includes('log'), `拒绝时要说清闭集：${e.message}`)
  }
})

test('validateConfig 反面：开关/间隔/伤害上限/结构的类型错误必须被拒绝', () => {
  const cases = [
    [{ item: { ...DEFAULT_ITEM_SWITCHES, 启用: 'true' }, proj: DEFAULT_PROJ_SWITCHES }, 'item.启用', '启用 必须是布尔值'],
    [{ item: { ...DEFAULT_ITEM_SWITCHES, 自动扫描: 1 }, proj: DEFAULT_PROJ_SWITCHES }, 'item.自动扫描', '自动扫描 必须是布尔值'],
    [{ item: { ...DEFAULT_ITEM_SWITCHES, 没收违禁物品: 'x' }, proj: DEFAULT_PROJ_SWITCHES }, 'item.没收违禁物品', '没收违禁物品 必须是布尔值'],
    [{ item: { ...DEFAULT_ITEM_SWITCHES, 扫描间隔: 'x' }, proj: DEFAULT_PROJ_SWITCHES }, 'item.扫描间隔', '扫描间隔 必须是整数'],
    [{ item: { ...DEFAULT_ITEM_SWITCHES, 扫描间隔: 0 }, proj: DEFAULT_PROJ_SWITCHES }, 'item.扫描间隔', '扫描间隔 必须在'],
    [{ item: { ...DEFAULT_ITEM_SWITCHES, 扫描间隔: 999999 }, proj: DEFAULT_PROJ_SWITCHES }, 'item.扫描间隔', '扫描间隔 必须在'],
    [{ item: DEFAULT_ITEM_SWITCHES, proj: { ...DEFAULT_PROJ_SWITCHES, 启用: 'x' } }, 'proj.启用', '启用 必须是布尔值'],
    [{ item: DEFAULT_ITEM_SWITCHES, proj: { ...DEFAULT_PROJ_SWITCHES, 伤害上限: 'x' } }, 'proj.伤害上限', '伤害上限 必须是整数'],
    [{ item: DEFAULT_ITEM_SWITCHES, proj: { ...DEFAULT_PROJ_SWITCHES, 伤害上限: 0 } }, 'proj.伤害上限', '伤害上限 必须 >= 1'],
    [{ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: 'x' }, proj: DEFAULT_PROJ_SWITCHES }, 'item.限制列表', '限制列表 必须是数组'],
    [{ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [42] }, proj: DEFAULT_PROJ_SWITCHES }, 'item.限制列表[0]', '档位必须是对象'],
    [{ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [{ 进度: '', 限制物品: [] }] }, proj: DEFAULT_PROJ_SWITCHES }, 'item.限制列表[0].进度', '进度 必须是非空字符串'],
    [{ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [{ 进度: '蜂后', 限制物品: 'x' }] }, proj: DEFAULT_PROJ_SWITCHES }, 'item.限制列表[0].限制物品', '限制物品 必须是数组'],
    [{ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [1])] }, proj: DEFAULT_PROJ_SWITCHES }, 'item.限制列表[0].限制物品[0]', '记录必须是对象'],
  ]
  for (const [raw, path, needle] of cases) {
    const r = validateConfig(raw)
    assert.equal(r.config, null, `${path}（${needle}）必须被拒绝`)
    const e = r.errors.find((x) => x.path === path)
    assert.ok(e, `必须有一条 path=${path} 的 error，实际：${JSON.stringify(r.errors)}`)
    assert.ok(e.message.includes(needle), `path=${path} 的文案应含「${needle}」，实际：${e.message}`)
  }
})

test('validateConfig 反面：档位数 / 单档条目数超上限必须被拒绝（不是截断）', () => {
  const manyTiers = []
  for (let i = 0; i < MAX_TIERS + 1; i++) manyTiers.push(itemTier(`档位${i}`, []))
  const t = validateConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: manyTiers }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(t.config, null)
  assert.ok(t.errors.some((e) => e.path === 'item.限制列表' && e.message.includes(String(MAX_TIERS))))

  const many = []
  for (let i = 0; i < MAX_ENTRIES_PER_TIER + 1; i++) many.push({ id: i + 1, stack: 1, method: 'log', command: '' })
  const e = validateConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', many)] }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(e.config, null, '超上限必须拒绝（写盘路径不能靠截断）')
  assert.ok(e.errors.some((x) => x.path === 'item.限制列表[0].限制物品' && x.message.includes(String(MAX_ENTRIES_PER_TIER))))
})

test('validateConfig：非闭集 method **不**拒绝（那正是旧配置的形态），归一后迁移为 command 并给警告', () => {
  const raw = {
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [{ id: 267, stack: 1, method: '/banp "x" "y"', command: '' }])] },
    proj: DEFAULT_PROJ_SWITCHES,
  }
  const r = validateConfig(raw)
  assert.deepEqual(r.errors, [], `旧配置的裸命令必须能被导入（否则老用户升级即报错）：${JSON.stringify(r.errors)}`)
  assert.ok(r.config)
  const entry = r.config.item.限制列表[0].限制物品[0]
  assert.equal(entry.method, 'command')
  assert.equal(entry.command, '/banp "x" "y"', '迁移必须保住命令文本（D-A 回归）')
  assert.ok(
    r.warnings.some((s) => s.includes('旧版自由文本')),
    `迁移必须作为 warning 回显给管理员（绝不静默）：${JSON.stringify(r.warnings)}`,
  )
})

test('validateConfig：写盘前的"可接受修复"都要出现在 warnings 里（脏值不静默）', () => {
  // 注意：stack<1 / 扫描间隔越界 / 伤害上限<=0 属于**必须拒绝**的 error（见上面两个用例），
  // 这里只测"能接受但必须回显"的那几类：未知档位、补斜杠、重复 id、旧 method 迁移。
  const raw = {
    item: {
      ...DEFAULT_ITEM_SWITCHES,
      限制列表: [
        itemTier('未知档位X', [
          { id: 267, stack: 2, method: 'command', command: 'say hi' },
          { id: 267, stack: 2, method: '/banp "x" "y"', command: '' },
        ]),
      ],
    },
    proj: DEFAULT_PROJ_SWITCHES,
  }
  const r = validateConfig(raw)
  assert.deepEqual(r.errors, [], `这几类都应当被接受（靠警告回显）：${JSON.stringify(r.errors)}`)
  assert.ok(r.config, '可接受的配置必须给出归一结果')
  const joined = r.warnings.join(' | ')
  assert.ok(joined.includes('未知档位X'), `未知档位要回显：${joined}`)
  assert.ok(joined.includes('不以 / 开头'), `补斜杠要回显：${joined}`)
  assert.ok(joined.includes('重复'), `重复 id 要回显：${joined}`)
  assert.ok(joined.includes('旧版自由文本'), `旧 method 迁移要回显：${joined}`)
  // 归一结果：补了斜杠、迁移了命令、重复项保留
  const entries = r.config.item.限制列表[0].限制物品
  assert.equal(entries.length, 2, '重复 id 必须保留（旧版重复即叠加）')
  assert.equal(entries[0].command, '/say hi')
  assert.equal(entries[1].method, 'command')
  assert.equal(entries[1].command, '/banp "x" "y"', '迁移必须保住命令文本（D-A 回归）')
})

// ═══════════════════════ D. 派生与载荷 ═══════════════════════

test('progressOrder：权威顺序打底 + 未知档位追加到末尾 + 不重复', () => {
  const empty = progressOrder(defaultConfig())
  assert.deepEqual(empty, PROGRESS_ORDER.slice(), '空配置时就是权威顺序')

  const cfg = normalizeConfig({
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('自定义A', []), itemTier('蜂后', [])] },
    proj: { ...DEFAULT_PROJ_SWITCHES, 限制列表: [projTier('自定义B', []), projTier('自定义A', [])] },
  }).config
  const order = progressOrder(cfg)
  // 已知档位仍在原位置
  assert.deepEqual(order.slice(0, PROGRESS_ORDER.length), PROGRESS_ORDER.slice())
  // 未知档位追加在末尾，且 item/proj 里同名的只出现一次
  assert.equal(order.length, PROGRESS_ORDER.length + 2, `应只多出 2 个未知档位：${order.join(',')}`)
  assert.ok(order.includes('自定义A') && order.includes('自定义B'))
  assert.equal(order.filter((x) => x === '自定义A').length, 1, '同名未知档位不得重复出现')
  assert.equal(new Set(order).size, order.length)

  // 非对象输入不抛错
  assert.doesNotThrow(() => progressOrder(null))
  assert.doesNotThrow(() => progressOrder('x'))
  assert.deepEqual(progressOrder(null), PROGRESS_ORDER.slice())
})

test('configStats：档位/条目/命令条数统计正确，空配置全 0', () => {
  const empty = configStats(defaultConfig())
  assert.deepEqual(empty, { itemTiers: 0, itemEntries: 0, projTiers: 0, projEntries: 0, commandEntries: 0 })

  const cfg = normalizeConfig({
    item: {
      ...DEFAULT_ITEM_SWITCHES,
      限制列表: [
        itemTier('蜂后', [{ id: 1, stack: 1, method: 'ban', command: '' }, { id: 2, stack: 1, method: 'command', command: '/say a' }]),
        itemTier('骷髅王', [{ id: 3, stack: 1, method: 'log', command: '' }]),
      ],
    },
    proj: {
      ...DEFAULT_PROJ_SWITCHES,
      限制列表: [projTier('始终生效', [{ id: 100, method: 'command', command: '/bc x' }])],
    },
  }).config
  assert.deepEqual(configStats(cfg), {
    itemTiers: 2,
    itemEntries: 3,
    projTiers: 1,
    projEntries: 1,
    commandEntries: 2,
  })
  // 非对象输入不抛错（回落默认 → 全 0）
  assert.doesNotThrow(() => configStats(null))
  assert.equal(configStats(null).itemTiers, 0)
})

test('configWarnings：6 类"会让管理员意外"的组合逐条触发，干净配置无警告', () => {
  const clean = { item: { ...DEFAULT_ITEM_SWITCHES, 启用: true, 限制列表: [itemTier('蜂后', [{ id: 1, stack: 1, method: 'ban', command: '' }])] }, proj: { ...DEFAULT_PROJ_SWITCHES, 启用: true, 限制列表: [projTier('始终生效', [{ id: 100, method: 'drop', command: '' }])] } }
  assert.deepEqual(configWarnings(clean), [], `干净配置不该有警告：${JSON.stringify(configWarnings(clean))}`)

  // ① 物品启用但清单为空
  assert.ok(configWarnings({ item: { ...DEFAULT_ITEM_SWITCHES, 启用: true, 限制列表: [] }, proj: { ...DEFAULT_PROJ_SWITCHES, 启用: false, 限制列表: [projTier('始终生效', [{ id: 1, method: 'log', command: '' }])] } })
    .some((s) => s.includes('物品检测已启用') && s.includes('空的')))
  // ② 弹幕启用但清单为空（只会按伤害上限判定）
  assert.ok(configWarnings({ item: { ...DEFAULT_ITEM_SWITCHES, 启用: false, 限制列表: [itemTier('蜂后', [{ id: 1, stack: 1, method: 'log', command: '' }])] }, proj: { ...DEFAULT_PROJ_SWITCHES, 启用: true, 限制列表: [] } })
    .some((s) => s.includes('弹幕检测已启用') && s.includes('伤害上限')))
  // ③ 有自定义命令 → 提示"每次改动都进审计"
  assert.ok(configWarnings(clean).length === 0 ? true : false)
  const cmd = configWarnings({ item: { ...DEFAULT_ITEM_SWITCHES, 启用: false, 限制列表: [itemTier('蜂后', [{ id: 1, stack: 1, method: 'command', command: '/say x' }])] }, proj: { ...DEFAULT_PROJ_SWITCHES, 启用: false, 限制列表: [] } })
  assert.ok(cmd.some((s) => s.includes('自定义命令') && s.includes('审计')), `命令警告应在：${JSON.stringify(cmd)}`)
  // ④ 两侧都未启用
  assert.ok(configWarnings({ item: { ...DEFAULT_ITEM_SWITCHES, 启用: false, 限制列表: [] }, proj: { ...DEFAULT_PROJ_SWITCHES, 启用: false, 限制列表: [] } })
    .some((s) => s.includes('都未启用') && s.includes('历史日志')))
  // ⑤ 自动扫描间隔过短
  assert.ok(configWarnings({ item: { ...DEFAULT_ITEM_SWITCHES, 启用: true, 自动扫描: true, 扫描间隔: 2, 限制列表: [itemTier('蜂后', [{ id: 1, stack: 1, method: 'log', command: '' }])] }, proj: { ...DEFAULT_PROJ_SWITCHES, 启用: true, 限制列表: [projTier('始终生效', [{ id: 1, method: 'log', command: '' }])] } })
    .some((s) => s.includes('自动扫描间隔只有 2 秒') && s.includes('游戏服线程')))
  // ⑥ 没收违禁物品开启（删除，不是退还）
  assert.ok(configWarnings({ item: { ...DEFAULT_ITEM_SWITCHES, 启用: true, 没收违禁物品: true, 限制列表: [itemTier('蜂后', [{ id: 1, stack: 1, method: 'ban', command: '' }])] }, proj: { ...DEFAULT_PROJ_SWITCHES, 启用: true, 限制列表: [projTier('始终生效', [{ id: 1, method: 'log', command: '' }])] } })
    .some((s) => s.includes('没收违禁物品') && s.includes('不是退还')))
  // 非对象不抛错
  assert.doesNotThrow(() => configWarnings(null))
})

test('toGamePayload：两个 JSON 串、字段名与服端一致、幂等，且发的是整份配置', () => {
  const cfg = normalizeConfig({
    item: { ...DEFAULT_ITEM_SWITCHES, 启用: true, 限制列表: [itemTier('蜂后', [{ id: 267, stack: 2, method: 'ban', command: '' }])] },
    proj: { ...DEFAULT_PROJ_SWITCHES, 启用: true, 伤害上限: 12345, 限制列表: [projTier('始终生效', [{ id: 100, method: 'command', command: '/bc x' }])] },
  }).config
  const p = toGamePayload(cfg)
  assert.deepEqual(Object.keys(p).sort(), ['item', 'proj'], '载荷恰好两侧')
  assert.equal(typeof p.item, 'string')
  assert.equal(typeof p.proj, 'string')
  const item = JSON.parse(p.item)
  const proj = JSON.parse(p.proj)
  // 服端按中文字段名取值（AntiCheatEndpoints.cs）
  assert.deepEqual(Object.keys(item).sort(), ['启用', '扫描间隔', '没收违禁物品', '自动扫描', '限制列表'].sort())
  assert.deepEqual(Object.keys(proj).sort(), ['启用', '伤害上限', '限制列表'].sort())
  assert.equal(item.限制列表[0].限制物品[0].id, 267)
  assert.equal(proj.伤害上限, 12345)
  // 幂等 + 与 normalizeConfig 一致（发出去的永远是归一后的权威形态）
  assert.equal(toGamePayload(cfg).item, p.item)
  assert.equal(toGamePayload(normalizeConfig(cfg).config).proj, p.proj)
  // 非对象也能产出合法载荷（默认配置）
  const d = toGamePayload(null)
  assert.deepEqual(JSON.parse(d.item).限制列表, [])
  assert.equal(JSON.parse(d.proj).伤害上限, DAMAGE_LIMIT_DEFAULT)
})

test('configFingerprint：与档位/条目顺序无关，但内容或开关变化必须改变指纹', () => {
  const a = normalizeConfig({
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [{ id: 1, stack: 1, method: 'ban', command: '' }, { id: 2, stack: 1, method: 'log', command: '' }]), itemTier('骷髅王', [])] },
    proj: DEFAULT_PROJ_SWITCHES,
  }).config
  // 档位顺序与条目顺序都调换，语义不变 → 指纹必须相同（对账才不会被顺序抖动干扰）
  const b = normalizeConfig({
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('骷髅王', []), itemTier('蜂后', [{ id: 2, stack: 1, method: 'log', command: '' }, { id: 1, stack: 1, method: 'ban', command: '' }])] },
    proj: DEFAULT_PROJ_SWITCHES,
  }).config
  assert.equal(configFingerprint(a), configFingerprint(b), '顺序无关：换顺序不该改变指纹')

  // 语义变化逐个都要改指纹
  const variants = [
    { ...a, item: { ...a.item, 启用: true } },
    { ...a, item: { ...a.item, 自动扫描: false } },
    { ...a, item: { ...a.item, 扫描间隔: 11 } },
    { ...a, item: { ...a.item, 没收违禁物品: true } },
    { ...a, item: { ...a.item, 限制列表: [itemTier('蜂后', [{ id: 1, stack: 1, method: 'kick', command: '' }, { id: 2, stack: 1, method: 'log', command: '' }])] } },
    { ...a, item: { ...a.item, 限制列表: [itemTier('蜂后', [{ id: 1, stack: 2, method: 'ban', command: '' }, { id: 2, stack: 1, method: 'log', command: '' }])] } },
  ]
  for (const [i, v] of variants.entries()) {
    assert.notEqual(configFingerprint(v), configFingerprint(a), `第 ${i} 个变体改了语义，指纹必须不同`)
  }
  // 弹幕侧同理
  const p1 = normalizeConfig({ item: DEFAULT_ITEM_SWITCHES, proj: { ...DEFAULT_PROJ_SWITCHES, 伤害上限: 1, 限制列表: [] } }).config
  const p2 = normalizeConfig({ item: DEFAULT_ITEM_SWITCHES, proj: { ...DEFAULT_PROJ_SWITCHES, 伤害上限: 2, 限制列表: [] } }).config
  assert.notEqual(configFingerprint(p1), configFingerprint(p2))

  // 同输入同输出（幂等）
  assert.equal(configFingerprint(a), configFingerprint(a))
  assert.doesNotThrow(() => configFingerprint(null))
})

test('defaultConfig / defaultItemEntry / defaultProjEntry：深拷贝 + 安全初值', () => {
  const a = defaultConfig()
  const b = defaultConfig()
  assert.notEqual(a, b, '每次调用必须是新对象')
  a.item.限制列表.push(itemTier('蜂后', []))
  a.item.启用 = true
  assert.equal(b.item.限制列表.length, 0, '默认配置的限制列表必须每次都是新的空数组')
  assert.equal(b.item.启用, false)
  assert.deepEqual(a.proj, b.proj, '两侧必须互不影响')
  assert.deepEqual(defaultConfig().item, { ...DEFAULT_ITEM_SWITCHES, 限制列表: [] })

  const ie = defaultItemEntry()
  assert.deepEqual(ie, { id: 0, stack: 1, method: 'log', command: '' })
  const pe = defaultProjEntry()
  assert.deepEqual(pe, { id: 0, method: 'log', command: '' }, '弹幕侧初值没有 stack')
  assert.ok(METHOD_VALUES.includes(ie.method) && METHOD_VALUES.includes(pe.method), '初值 method 必须在闭集内')
  // 注意：新条目 id=0 是"占位"，写盘前必须被 validateConfig 拒绝（避免 id=0 的脏规则生效）
  const r = validateConfig({ item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [itemTier('蜂后', [defaultItemEntry()])] }, proj: DEFAULT_PROJ_SWITCHES })
  assert.equal(r.config, null, 'id=0 的占位条目不得通过写盘校验')
  assert.ok(r.errors.some((e) => e.path.endsWith('.id')))
})
