/**
 * 下发协议（push）测试：规格第 4 条要求的六个点，逐个钉死。
 *
 *   ① 版本单调递增（index.js:321-323 每次下发尝试都自增；:156-159 说明为什么重试也必须带新版本）
 *   ② 缺字段沿用服端旧值 → 宿主侧的义务是"**永远整份发**、两个字段都在且都不是空串"
 *      （config.js:691-699 的 toGamePayload 注释；服端语义见 plugin/AntiCheatEndpoints.cs:279）
 *   ③ 不可变快照：推上去的是"推送那一刻"的字符串快照，不是活引用（config.js:696-697）
 *   ④ 先落盘后推送：index.js:536-537 先 saveConfigFile，再在 :556 pushConfig
 *   ⑤ 失败绝不静默：501（未装 DLL）/502（权限、服端错）/400（参数）原样透出，且每台服的失败
 *      都在 status 里可见（gameOps.js:130-162 的 unwrap；路由 wrap 在 index.js:661-677）
 *   ⑥ 退避重试 + 周期对账 + 重连补推（index.js:259-282 退避、:231-242 对账、:913-919 事件补推）
 *
 * 运行：`node test\push.test.mjs`（本机 `node --test test/` 不可用）。
 * 假宿主/假服半见 test/support/fake-host.mjs；所有游戏服调用都记在 host.calls 里，断言基于它。
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { makeFakeHost, makeGameHalf, waitFor, makeConfig } from './support/fake-host.mjs'
import { apply } from '../index.js'
import { normalizeConfig, toGamePayload } from '../config.js'

const TMP_ROOT = fs.mkdtempSync(path.join(os.tmpdir(), 'anticheat-push-'))

/**
 * 起一个用例：临时 dataDir + 假宿主 + 假服半 + 真实 apply()。
 * @returns {{host, gh, svc, dispose, dir, settle, configFile, snapCount}}
 */
async function setup({ servers, behaviors = {}, push = {}, postForWrap } = {}) {
  const dir = fs.mkdtempSync(path.join(TMP_ROOT, 'case-'))
  const list = servers || [
    { id: '1', name: '一服', enabled: true },
    { id: '2', name: '二服', enabled: true },
  ]
  const gh = makeGameHalf({ serverIds: list.map((s) => String(s.id)) })
  for (const [id, mode] of Object.entries(behaviors)) gh.setBehavior(id, mode)

  // postForWrap 用于"在服端收到 snapshot 的那一刻"观察宿主侧状态（先落盘后推送就靠它证明）
  const postFor = async (server, pathname, params) => {
    if (postForWrap) await postForWrap({ server, pathname, params, dir })
    return gh.handle(server, pathname, params)
  }
  const host = makeFakeHost({
    dataDir: dir,
    servers: list,
    postFor,
    fetchFor: (server, pathname, params) => gh.handle(server, pathname, params),
  })

  // 默认关掉周期对账，避免它污染"推了几次"的计数；需要它的用例自己传 push.reconcileIntervalMs
  const dispose = await apply(host.ctx, { push: { reconcileIntervalMs: 0, ...push } })
  const svc = host.ctx.anticheatLog._svc
  assert.ok(svc, 'apply 后必须能经 ctx.anticheatLog._svc 取到服务实例')

  /** 等启动对账那一次异步下发落定（**只在全部成功时**才有意义；有失败服时它会超时） */
  const settle = () => waitFor(() => svc.desiredVersion >= 1 && svc.pendingIds().length === 0, { label: '启动对账落定' })

  /**
   * 等"首轮下发**尝试完成**"：每个目标都写进了一条 pushStatus。
   * 失败场景里 settle() 永远不成立（pendingCount 清不掉），所以那些用例必须用这个。
   * 注意 gh.snapshotCalls 只记录**成功走到服端逻辑**的调用（失败模式在 fake-host.mjs:403-408 提前 return），
   * 要数"尝试次数"必须用 host.calls（postFor 的全部调用，含失败）。
   */
  const afterFirstPush = () =>
    waitFor(() => svc.pushStatus.size >= list.length, { timeoutMs: 5000, label: '首轮下发尝试完成' })

  /** host.calls 里某台服收到的全部 snapshot 尝试（含失败），按发生顺序 */
  const tries = (id) =>
    host.calls
      .filter((c) => c.pathname.endsWith('/snapshot') && String(c.serverId) === String(id))
      .map((c) => Number(c.params.version))

  return {
    host, gh, svc, dispose, dir, settle, afterFirstPush, tries,
    list,
    configFile: path.join(dir, 'anti-cheat', 'config.json'),
  }
}

/** 每个用例结束都收尾：停定时器，避免用例之间互相影响 */
async function withCase(opts, fn) {
  const c = await setup(opts)
  try {
    return await fn(c)
  } finally {
    c.dispose()
  }
}

// ═══════════════════════ ① 版本单调 + 启动对账 ═══════════════════════

test('启动对账：apply 后自动推给每台启用服，且全部确认（desiredVersion 从 1 起）', async () => {
  await withCase({}, async ({ gh, svc, settle }) => {
    await settle()
    assert.equal(gh.snapshotCount.get('1'), 1, '一服应收到 1 次 snapshot')
    assert.equal(gh.snapshotCount.get('2'), 1, '二服应收到 1 次 snapshot')
    assert.ok(svc.desiredVersion >= 1, 'desiredVersion 必须已自增')
    const st = svc.status()
    assert.equal(st.pendingCount, 0, '两台都确认后未确认数必须为 0')
    assert.equal(st.servers.length, 2)
    for (const row of st.servers) {
      assert.equal(row.ok, true, `${row.name} 应显示已生效`)
      assert.equal(row.error, '')
      assert.ok(row.version >= 1)
    }
  })
})

test('版本单调：每次下发尝试都自增（连续三次严格递增）', async () => {
  await withCase({}, async ({ svc, settle }) => {
    await settle()
    const v0 = svc.desiredVersion
    const r1 = await svc.pushConfig({ reason: '测试1' })
    const r2 = await svc.pushConfig({ reason: '测试2' })
    const r3 = await svc.pushConfig({ reason: '测试3' })
    assert.ok(r1.version > v0 && r2.version > r1.version && r3.version > r2.version,
      `版本必须严格递增：${v0} → ${r1.version} → ${r2.version} → ${r3.version}`)
    assert.equal(svc.desiredVersion, r3.version)
  })
})

test('版本单调：服端按 version 拒绝更旧的载荷（stale 必须可见、必须算未确认、必须安排重试）', async () => {
  await withCase({ push: { retryIntervalMs: 60000 } }, async ({ gh, svc, settle }) => {
    await settle()
    // 服端已有一个"未来版本"（模拟别的宿主/手工下发推过更高的版本）
    gh.setServerVersion('1', 9999)
    const r = await svc.pushConfig({ serverIds: ['1'], reason: '测试 stale' })
    assert.equal(r.total, 1)
    assert.equal(r.okCount, 0, '服端回 stale 时不得计入成功')
    const row = r.results[0]
    assert.equal(row.ok, false)
    assert.equal(row.stale, true)
    assert.ok(row.error && row.error.length > 0, 'stale 必须带可见原因，绝不静默当成功')
    assert.match(row.error, /9999|更新|忽略/, `stale 原因应说明服端版本更高：${row.error}`)
    assert.equal(svc.status().pendingCount, 1, '未确认台数必须包含这台')
    assert.equal(svc.status().retryScheduled, true, '必须安排重试')
  })
})

test('版本单调：重试带的是**新**版本号（否则一次乱序到达的旧请求会把新配置覆盖回去）', async () => {
  await withCase({ behaviors: { '1': 'missing' }, push: { retryIntervalMs: 1000, retryMaxIntervalMs: 1000 } },
    async ({ gh, svc, afterFirstPush, tries, settle }) => {
      await afterFirstPush()
      const before = tries('1')
      assert.ok(before.length >= 1, '失败的服也必须真的收到了那次尝试（数尝试要用 host.calls；gh.snapshotCalls 只记成功路径）')
      // 修好服端，等自动重试把它补上
      gh.setBehavior('1', 'ok')
      await waitFor(() => tries('1').length > before.length, { timeoutMs: 6000, label: '失败重试再次下发' })
      const after = tries('1')
      assert.ok(
        Math.max(...after) > Math.max(...before),
        `重试的 version 必须大于上一次（${before.join(',')} → ${after.join(',')}）：` +
        '否则一次乱序到达的旧请求会被服端当成"新配置"覆盖回去',
      )
    })
})

// ═══════════════════════ ② 载荷形状 / 整份发 ═══════════════════════

test('载荷形状：恰好 version/item/proj/ts 四个参数，version 为正整数字符串，ts 可解析，且走 POST+body', async () => {
  await withCase({}, async ({ host, settle }) => {
    await settle()
    const call = host.calls.find((c) => c.pathname.endsWith('/snapshot'))
    assert.ok(call, '必须发生了一次下发')
    assert.deepEqual(
      Object.keys(call.params).sort(),
      ['item', 'proj', 'ts', 'version'],
      '下发参数必须恰好是服端 AntiCheatEndpoints.cs:279 声明的那四个（多一个/少一个都是协议漂移）',
    )
    assert.match(String(call.params.version), /^[1-9]\d*$/, 'version 必须是正整数字符串')
    assert.ok(!Number.isNaN(Date.parse(call.params.ts)), `ts 必须是可解析的时间：${call.params.ts}`)
    assert.equal(call.via, 'postFor', '宿主提供 postFor 时必须走 POST+body（清单 16KB，走 query 会被反代截断）')
  })
})

test('整份发：item/proj 都是非空合法 JSON，且与权威配置逐字一致（不做补丁下发）', async () => {
  await withCase({}, async ({ ghConfig, gh, svc, settle }) => {
    await settle()
    const call = gh.snapshotCalls[0]
    assert.equal(typeof call.item, 'string')
    assert.equal(typeof call.proj, 'string')
    assert.ok(call.item.length > 0 && call.proj.length > 0, '两侧都不得发空串')

    const payload = toGamePayload(normalizeConfig(svc.config).config)
    assert.equal(call.item, payload.item, '发下去的 item 必须等于权威配置序列化结果')
    assert.equal(call.proj, payload.proj, '发下去的 proj 必须等于权威配置序列化结果')
  })
})

test('整份发：某一侧清单为空/未启用时，该侧字段**仍然存在**且是合法 JSON（服端才能"沿用旧值"）', async () => {
  await withCase({}, async ({ ghConfig, gh, svc, settle }) => {
    await settle()
    // 默认配置两侧 限制列表 都是空数组（config.js:196-201），仍未启用
    const call = gh.snapshotCalls[0]
    const item = JSON.parse(call.item)
    const proj = JSON.parse(call.proj)
    assert.equal(item.启用, false)
    assert.equal(proj.启用, false)
    assert.deepEqual(item.限制列表, [], '空清单也要如实发出去，而不是省略字段')
    assert.deepEqual(proj.限制列表, [])
    // 两侧的关键字段一个都不能少（服端按字段名取值）
    for (const k of ['启用', '自动扫描', '扫描间隔', '没收违禁物品', '限制列表']) {
      assert.ok(k in item, `item 缺字段 ${k}`)
    }
    for (const k of ['启用', '伤害上限', '限制列表']) {
      assert.ok(k in proj, `proj 缺字段 ${k}`)
    }
    assert.equal(proj.伤害上限, 20000)
  })
})

test('不可变快照：推送后改宿主配置，不影响已发出的那份载荷（快照而非活引用）', async () => {
  await withCase({}, async ({ ghConfig, gh, svc, settle }) => {
    await settle()
    const before = gh.snapshotCalls[0].item
    const parsedBefore = JSON.parse(before)
    assert.equal(parsedBefore.启用, false)

    // 直接改内存里的权威配置（不落盘、不下发）
    svc.config.item.启用 = true
    const stillSame = gh.snapshotCalls[0].item
    assert.equal(stillSame, before, '已记录的载荷必须原封不动')
    assert.equal(JSON.parse(stillSame).启用, false, '已发出的快照不得跟着内存改动变')

    // 下一次下发才反映新值 → 证明"快照取自推送时点"
    await svc.pushConfig({ reason: '改后下发' })
    const after = gh.snapshotCalls[gh.snapshotCalls.length - 1].item
    assert.equal(JSON.parse(after).启用, true)
    assert.notEqual(after, before)
  })
})

// ═══════════════════════ ③ 先落盘后推送 ═══════════════════════

test('先落盘后推送：服端收到 snapshot 的那一刻，磁盘上的配置**已经**是新的（index.js:536-537 → :556）', async () => {
  const observed = []
  await withCase(
    {
      postForWrap: ({ pathname, params, dir }) => {
        if (!pathname.endsWith('/snapshot')) return
        const file = path.join(dir, 'anti-cheat', 'config.json')
        observed.push({ item: params.item, disk: fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : null })
      },
    },
    async ({ svc, gh, settle }) => {
      await settle()
      const n0 = observed.length
      // 通过 setConfig 改配置（内部：先 saveConfigFile 再 pushConfig）
      const next = makeConfig()
      next.item.启用 = true
      next.item.自动扫描 = false
      await svc.setConfig(next, { actor: 'tester', changedKeys: ['item.启用'], detail: {} })

      const fresh = observed.slice(n0)
      assert.ok(fresh.length >= 1, '变更后必须发生下发')
      for (const o of fresh) {
        assert.ok(o.disk !== null, '推送发生时配置文件必须已经存在（先落盘）')
        const disk = JSON.parse(o.disk)
        assert.deepEqual(
          JSON.parse(o.item),
          disk.item,
          '推送的 item 载荷必须与此刻磁盘上的 item 完全一致（否则就是"先推后存"）',
        )
        assert.equal(disk.item.启用, true, '磁盘上必须是新值')
      }
    },
  )
})

test('先落盘后推送：落盘失败时**不发出**半截新配置（setConfig 抛错即不下发）', async () => {
  await withCase({}, async ({ svc, gh, settle }) => {
    await settle()
    const n0 = gh.snapshotCalls.length
    // 把配置文件路径指向一个不可能写入的位置：用一个**目录**占住 config.json
    fs.mkdirSync(svc.configFile, { recursive: true })
    const next = makeConfig()
    next.item.启用 = true
    await assert.rejects(
      () => svc.setConfig(next, { actor: 'tester', changedKeys: [], detail: {} }),
      (err) => err instanceof Error,
      '落盘失败必须抛错，绝不能"落盘失败但照样下发"',
    )
    assert.equal(gh.snapshotCalls.length, n0, '落盘失败后不得下发')
  })
})

// ═══════════════════════ ④ 失败绝不静默 ═══════════════════════

test('失败可见：未装 DLL → 501 + serverHalfMissing + dllName（单服动作，路由直接失败）', async () => {
  await withCase({ behaviors: { '1': 'missing' }, push: { retryIntervalMs: 60000 } },
    async ({ host, svc, afterFirstPush }) => {
      await afterFirstPush()
      const r = await host.call('post', '/api/anticheat/scan', { body: { serverId: '1' } })
      assert.equal(r.status, 501, `未装 DLL 必须回 501：${JSON.stringify(r.data)}`)
      assert.equal(r.data.ok, false)
      assert.equal(r.data.serverHalfMissing, true)
      assert.equal(r.data.dllName, 'AntiCheat.dll')
      assert.ok(r.data.error.includes('AntiCheat.dll'), '必须说清缺的是哪个 dll')
      assert.equal(r.businessRan, true)
      // 失败还必须留在 status 里可见（前端「下发状态」卡）
      const row = svc.status().servers.find((s) => s.id === '1')
      assert.equal(row.ok, false)
      assert.ok(row.error.length > 0, '失败必须在 status 里可见，不能只发生在某次请求里')
    })
})

test('失败可见：服端 403/401 → 宿主 502（不是 403/401），且下游 status 也是 502（D-D 回归）', async () => {
  for (const [mode, gameStatus] of [['forbidden', 403], ['unauthorized', 401]]) {
    await withCase({ behaviors: { '1': mode }, push: { retryIntervalMs: 60000 } },
      async ({ host, afterFirstPush }) => {
        await afterFirstPush()
        const r = await host.call('post', '/api/anticheat/scan', { body: { serverId: '1' } })
        assert.equal(
          r.status,
          502,
          `${mode}：宿主必须回 502（"网关后面的游戏服拒绝"），回 ${r.status} 会让前端误判——` +
          `403 会被读成"我没权限"、401 会被读成"我没登录"。实际：${JSON.stringify(r.data)}`,
        )
        assert.equal(r.data.ok, false)
        // 服端状态码要能从文案里看出来（wrap 只透出 error/serverHalfMissing 等固定字段，见 index.js:668-675）
        assert.ok(
          r.data.error.includes(`HTTP ${gameStatus}`),
          `错误文案必须带上服端状态码 HTTP ${gameStatus}：${r.data.error}`,
        )

        // D-D 的直接消费方：probeServers 的失败行用 err.status 当日志级状态（index.js:531）。
        // 若额外字段仍叫 status，这里会被污染成 403/401（那是服端的状态码，不是宿主的）。
        const st = await host.call('get', '/api/anticheat/status', { query: { serverIds: '1' } })
        assert.equal(st.status, 200)
        const row = st.data.probe.servers[0]
        assert.equal(row.ok, false)
        assert.equal(
          row.status,
          502,
          `probe 失败行必须报宿主的 502，而不是服端的 ${gameStatus}（D-D：extra.status 覆盖了 httpError 的状态码）`,
        )
      })
  }
})

test('失败可见：服端 500 → 502 且原因可见；服端 400 → 400 原样透传（unwrap 的两条映射）', async () => {
  await withCase({ behaviors: { '1': 'serverError' }, push: { retryIntervalMs: 60000 } },
    async ({ host, afterFirstPush }) => {
      await afterFirstPush()
      const r = await host.call('post', '/api/anticheat/scan', { body: { serverId: '1' } })
      assert.equal(r.status, 502)
      assert.equal(r.data.ok, false)
      assert.ok(r.data.error.includes('服务器内部错误（假）'), `必须带上服端原文：${r.data.error}`)
    })

  // 400 透传：unwrap 只在"服端明说参数错"时才回 400（gameOps.js:148-151），这里直接测这个映射
  await withCase({ behaviors: { '1': 'badRequest' }, push: { retryIntervalMs: 60000 } },
    async ({ svc, afterFirstPush }) => {
      await afterFirstPush()
      const servers = await svc.gameOps.enabledServers()
      const one = servers.find((s) => String(s.id) === '1')
      await assert.rejects(
        () => svc.gameOps.pushConfig(one, { version: 1, config: svc.config, ts: '' }),
        (err) => {
          assert.equal(err.status, 400, `服端 400 必须原样 400（不能被包成 502）：${err.message}`)
          assert.match(err.message, /version 必须是正整数/, '必须转发服端原文')
          return true
        },
      )
    })
})

test('失败可见：下发路由即使整体 200，也必须**逐服**给出失败原因（不是静默成功）', async () => {
  await withCase({ behaviors: { '1': 'badRequest' }, push: { retryIntervalMs: 60000 } },
    async ({ host, afterFirstPush }) => {
      await afterFirstPush()
      const r = await host.call('post', '/api/anticheat/push', { body: { serverIds: ['1'] } })
      // 下发是"逐服结果"语义：路由本身 200（其它服可能成功），但失败那台必须带原因
      assert.equal(r.status, 200, JSON.stringify(r.data))
      assert.equal(r.data.push.ok, false, '有失败的服时整体 ok 必须为 false')
      assert.equal(r.data.push.okCount, 0)
      assert.equal(r.data.push.total, 1)
      const row = r.data.push.results[0]
      assert.equal(row.ok, false)
      assert.ok(row.error.length > 0, '每一台服的失败都必须带原因')
      assert.match(row.error, /version 必须是正整数/, `必须转发服端原文：${row.error}`)
      assert.ok(r.data.push.pendingCount >= 1, '失败的服必须计进未确认')
    })
})

test('失败可见：postFor 自身抛错 → 502 且原因可见（不是静默算成功）', async () => {
  await withCase({ behaviors: { '1': 'raise' }, push: { retryIntervalMs: 60000 } },
    async ({ host, svc, afterFirstPush }) => {
      await afterFirstPush()
      const r = await host.call('post', '/api/anticheat/scan', { body: { serverId: '1' } })
      assert.equal(r.status, 502)
      assert.ok(r.data.error.includes('服务器记录损坏（假）'), `异常原因必须透出：${r.data.error}`)
      // 逐服可见
      const row = svc.status().servers.find((s) => s.id === '1')
      assert.equal(row.ok, false)
      assert.ok(row.error.length > 0)
    })
})

test('失败可见：服端"已应用但落盘失败"不得算成功（D-E 回归；C# 侧 AntiCheatConfig.cs:505-506 自述绝不静默）', async () => {
  await withCase({ behaviors: { '1': 'saveFail' }, push: { retryIntervalMs: 60000 } },
    async ({ gh, svc, afterFirstPush }) => {
      await afterFirstPush()
      const r = await svc.pushConfig({ serverIds: ['1'], reason: '落盘失败用例' })
      const row = r.results[0]
      assert.equal(row.applied, true, '服端确实应用了（内存生效）')
      assert.equal(
        row.ok,
        false,
        '落盘失败（durable=false）绝不能算成功：内存生效但重启会回滚，界面却显示"已生效"= 静默失败',
      )
      assert.equal(row.durable, false)
      assert.ok(row.error && row.error.includes('落盘'), `必须说明落盘失败：${row.error}`)
      assert.ok(svc.status().pendingCount >= 1, '必须留成未确认并安排重试')
    })
})

test('失败可见：失败会安排重试，成功后 pendingCount 归零并重置退避', async () => {
  await withCase({ behaviors: { '2': 'missing' }, push: { retryIntervalMs: 1000, retryMaxIntervalMs: 2000 } },
    async ({ gh, svc, afterFirstPush }) => {
      await afterFirstPush()
      assert.equal(svc.status().pendingCount, 1, '失败的那台必须留在未确认里')
      assert.equal(svc.status().retryScheduled, true)
      gh.setBehavior('2', 'ok')
      await waitFor(() => svc.status().pendingCount === 0, { timeoutMs: 5000, label: '重试把二服补上' })
      assert.equal(svc.status().retryScheduled, false, '全部确认后不该再有重试定时器')
      assert.equal(svc.status().servers.find((s) => s.id === '2').ok, true)
    })
})

// ═══════════════════════ ⑤ 退避 / 对账 / 重连补推 ═══════════════════════

test('退避：重试不早于 retryIntervalMs、逐步指数增长，且被 retryMaxIntervalMs 钳住', async () => {
  await withCase({ behaviors: { '1': 'missing', '2': 'missing' }, push: { retryIntervalMs: 1000, retryMaxIntervalMs: 2000 } },
    async ({ svc, afterFirstPush }) => {
      await afterFirstPush()
      assert.equal(svc._retryDelay, 1000, '首次退避必须等于 retryIntervalMs')
      const t0 = Date.now()
      await waitFor(() => svc.desiredVersion >= 2, { timeoutMs: 5000, label: '第 1 次重试' })
      const t1 = Date.now()
      await waitFor(() => svc.desiredVersion >= 3, { timeoutMs: 6000, label: '第 2 次重试' })
      const t2 = Date.now()
      await waitFor(() => svc.desiredVersion >= 4, { timeoutMs: 8000, label: '第 3 次重试' })
      const t3 = Date.now()
      const gap1 = t1 - t0
      const gap2 = t2 - t1
      const gap3 = t3 - t2

      // 每一次都不得早于下限：否则就是 0 延迟忙轮询，会把宿主单核打满
      for (const [i, gap] of [gap1, gap2, gap3].entries()) {
        assert.ok(gap >= 900, `第 ${i + 1} 次重试间隔 ${gap}ms 小于 retryIntervalMs(1000ms)：退化成忙轮询了`)
      }
      // 退避确实在增长，并且到上限就停住。
      // 注意实现有一格延迟：_retryDelay 的翻倍发生在这一次重试**跑完之后**（index.js:264-268 的 .then），
      // 而下一次定时器是在 pushConfig 内部就排好的（:380）——所以实际序列是 1s,1s,2s,2s…，
      // 而不是 1s,2s,4s。这里按**实际**序列断言（不美化），第 3 次才必须明显翻倍。
      assert.ok(gap3 >= 1700, `连续失败后必须明显退避（第 3 次应 ~2000ms）：实际 ${gap3}ms`)
      assert.equal(svc._retryDelay, 2000, `退避必须增长到 retryMaxIntervalMs 并停在那里：实际 ${svc._retryDelay}`)
      assert.ok(svc._retryDelay > svc.push.retryIntervalMs, '上限必须大于起始间隔，否则"退避"名存实亡')
    })
})

test('周期对账：无任何变更也会**无条件**重推（自愈"服端配置被删改/重置"）', async () => {
  await withCase({ push: { reconcileIntervalMs: 1200 } }, async ({ gh, ghConfig, svc }) => {
    await waitFor(() => gh.snapshotCount.get('1') >= 1, { label: '启动对账' })
    const n1 = gh.snapshotCount.get('1')
    await waitFor(() => gh.snapshotCount.get('1') > n1, { timeoutMs: 5000, label: '周期对账再推一次' })
    assert.ok(gh.snapshotCount.get('1') >= 2, '周期对账必须真的又推了一次')
    assert.equal(svc.status().pendingCount, 0, '服端正常时对账不该留下未确认')
    assert.equal(svc.status().intervals.reconcileIntervalMs, 1200, 'status 必须回显真实节奏')
  })
})

test('周期对账：reconcileIntervalMs<=0 时不启动；dispose 后定时器全停', async () => {
  const c = await setup({ push: { reconcileIntervalMs: 0 } })
  try {
    await c.settle()
    assert.equal(c.svc._reconcileTimer, null, 'reconcileIntervalMs=0 时不得启动对账定时器')
  } finally {
    c.dispose()
  }

  // 有对账 + 有重试的场景：dispose 后都停
  const c2 = await setup({ behaviors: { '1': 'missing' }, push: { reconcileIntervalMs: 1200, retryIntervalMs: 60000 } })
  try {
    await waitFor(() => c2.svc._retryTimer !== null, { timeoutMs: 5000, label: '失败后安排重试' })
    assert.notEqual(c2.svc._reconcileTimer, null, '应已启动对账定时器')
    const before = c2.gh.snapshotCount.get('1') || 0
    c2.dispose()
    assert.equal(c2.svc._reconcileTimer, null, 'dispose 必须停掉对账')
    assert.equal(c2.svc._retryTimer, null, 'dispose 必须停掉重试')
    await new Promise((r) => setTimeout(r, 1600))
    assert.equal(c2.gh.snapshotCount.get('1'), before, 'dispose 后不得再有任何下发')
  } finally {
    c2.dispose()
  }
})

test('重连补推：订阅了 push/connected 与 servers/loaded，且事件只补推**未确认**的服', async () => {
  await withCase({ behaviors: { '2': 'missing' }, push: { retryIntervalMs: 60000 } },
    async ({ host, gh, svc, afterFirstPush }) => {
      await afterFirstPush()
      assert.ok(
        host.listenerCount('push/connected') > 0,
        '必须订阅 push/connected，否则"服务器重连后补推"根本不成立',
      )
      assert.ok(host.listenerCount('servers/loaded') > 0, '必须订阅 servers/loaded')

      const n1 = gh.snapshotCount.get('1') // 一服已确认，不该被补推
      const n2 = gh.snapshotCount.get('2')
      gh.setBehavior('2', 'ok')
      const delivered = host.fire('push/connected', { serverId: '2' })
      assert.equal(delivered, true, '事件必须真的有订阅者')

      await waitFor(() => gh.snapshotCount.get('2') > n2, { timeoutMs: 3000, label: '补推二服' })
      await waitFor(() => svc.status().pendingCount === 0, { timeoutMs: 3000, label: '二服转为已确认' })
      assert.equal(
        gh.snapshotCount.get('1'),
        n1,
        '已确认的服不该被补推（补推只针对未确认的服，否则每次重连都全量重推）',
      )
    })
})

// ═══════════════════════ ⑥ 目标选择 / 路由参数 ═══════════════════════

test('目标选择：serverIds 传空数组 = **不下发任何服**（index.js:310 三态语义，D-B 回归）', async () => {
  await withCase({}, async ({ host, gh, svc, settle }) => {
    await settle()
    const n1 = gh.snapshotCount.get('1')
    const n2 = gh.snapshotCount.get('2')
    const r = await host.call('post', '/api/anticheat/push', { body: { serverIds: [] } })
    assert.equal(r.status, 200, JSON.stringify(r.data))
    assert.equal(r.data.push.total, 0, '空数组必须"一台都不推"，绝不能被当成"未指定=全部"')
    assert.equal(gh.snapshotCount.get('1'), n1, '一服不该收到推送')
    assert.equal(gh.snapshotCount.get('2'), n2, '二服不该收到推送')
  })
})

test('目标选择：不传 serverIds = 全部启用服；传指定 id 只推那一台', async () => {
  await withCase({}, async ({ host, gh, svc, settle }) => {
    await settle()
    const n1 = gh.snapshotCount.get('1')
    const n2 = gh.snapshotCount.get('2')

    const all = await host.call('post', '/api/anticheat/push', { body: {} })
    assert.equal(all.data.push.total, 2, '未指定 = 全部启用服')
    assert.equal(gh.snapshotCount.get('1'), n1 + 1)
    assert.equal(gh.snapshotCount.get('2'), n2 + 1)

    const one = await host.call('post', '/api/anticheat/push', { body: { serverIds: ['2'] } })
    assert.equal(one.data.push.total, 1, '指定 id 时只推那一台')
    assert.equal(gh.snapshotCount.get('1'), n1 + 1, '未被指定的服不得收到推送')
    assert.equal(gh.snapshotCount.get('2'), n2 + 2)
  })
})

test('目标选择：停用的服不在目标里（也不该把它的未确认算成"待重试"）', async () => {
  await withCase({}, async ({ host, gh, svc, settle }) => {
    await settle()
    host.setRaw('2', { enabled: false })
    const n2 = gh.snapshotCount.get('2')
    const r = await svc.pushConfig({ reason: '停用后下发' })
    assert.equal(r.total, 1, '只剩一服启用')
    assert.equal(gh.snapshotCount.get('2'), n2, '停用的服不得收到推送')
  })
})

test('目标选择：单次指定超过 PUSH_LIMIT(50) 台 → 400（防一次请求串行打完几十台）', async () => {
  await withCase({}, async ({ host, svc, settle }) => {
    await settle()
    const ids = Array.from({ length: 51 }, (_, i) => String(i + 1))
    const r = await host.call('post', '/api/anticheat/push', { body: { serverIds: ids } })
    assert.equal(r.status, 400, JSON.stringify(r.data))
    assert.match(r.data.error, /50/, `错误里要说清上限：${r.data.error}`)
  })
})

test('probe：GET /api/anticheat/status 的 serverIds 与下发同一套语义（空数组=不探任何服）', async () => {
  await withCase({}, async ({ host, gh, svc, settle }) => {
    await settle()
    const all = await host.call('get', '/api/anticheat/status')
    assert.equal(all.status, 200)
    assert.equal(all.data.probe.servers.length, 2, '未指定时探测全部启用服')

    const none = await host.call('get', '/api/anticheat/status', { query: { serverIds: ',' } })
    assert.equal(none.status, 200)
    assert.equal(
      none.data.probe.servers.length,
      0,
      '显式给了（空的）列表就一台都不探，不能退回"探全部"（index.js:450）',
    )

    const one = await host.call('get', '/api/anticheat/status', { query: { serverIds: '2' } })
    assert.equal(one.data.probe.servers.length, 1)
    assert.equal(String(one.data.probe.servers[0].id), '2')
  })
})

test('status 形状：版本/修订/未确认/节奏都齐全，且 desiredVersion 与 configRevision 分工不混', async () => {
  await withCase({}, async ({ svc, settle }) => {
    await settle()
    const st = svc.status()
    for (const k of [
      'desiredVersion', 'configRevision', 'configFile', 'warnings', 'stats', 'progressOrder',
      'intervals', 'servers', 'pendingCount', 'pendingServerIds', 'retryScheduled',
    ]) {
      assert.ok(k in st, `status() 缺字段 ${k}`)
    }
    assert.ok(Array.isArray(st.servers) && Array.isArray(st.pendingServerIds))
    assert.equal(typeof st.intervals.retryIntervalMs, 'number')

    // 仅下发（内容没变）时修订号不动、版本号动 —— 否则"单服补推"会把别的服误判成落后
    const rev0 = svc.status().configRevision
    const ver0 = svc.status().desiredVersion
    await svc.pushConfig({ reason: '仅下发' })
    assert.ok(svc.status().desiredVersion > ver0, '版本号必须自增')
    assert.equal(svc.status().configRevision, rev0, '内容没变时修订号必须不动')

    // 内容变了才动修订号
    const next = makeConfig()
    next.proj.伤害上限 = 12345
    await svc.setConfig(next, { actor: 'tester', changedKeys: ['proj.伤害上限'], detail: {} })
    assert.ok(svc.status().configRevision > rev0, '内容变更后修订号必须自增')
  })
})

test('变更即推：setConfig 之后服端 applied 的 content 就是新配置；pushOnChange=false 时明确跳过', async () => {
  await withCase({}, async ({ gh, svc, settle }) => {
    await settle()
    const next = makeConfig()
    next.item.启用 = true
    const res = await svc.setConfig(next, { actor: 'tester', changedKeys: ['item.启用'], detail: {} })
    assert.equal(res.push.skipped, undefined)
    assert.equal(res.push.total, 2, '变更后应推给 2 台')
    assert.equal(res.push.okCount, 2)
    assert.equal(gh.applied.get('1').item.启用, true, '服端实际生效的配置必须是新值')
  })

  await withCase({ push: { pushOnChange: false } }, async ({ gh, svc, settle }) => {
    await settle()
    const ver0 = svc.desiredVersion
    const next = makeConfig()
    next.item.启用 = true
    const res = await svc.setConfig(next, { actor: 'tester', changedKeys: ['item.启用'], detail: {} })
    assert.equal(res.push.skipped, true, '关闭"变更即推"后必须显式标记 skipped，而不是假装推了')
    assert.equal(res.push.total, 0)
    assert.equal(svc.desiredVersion, ver0, '关闭后不得自增版本号（没发生下发尝试）')
    // 服端仍停在启动对账时下发的那份旧配置（启用=false），没有被这次变更动过
    assert.equal(gh.applied.get('1').item.启用, false, '服端不该收到新内容')
    assert.equal(gh.applied.get('2').item.启用, false)
  })
})

test('probe 自证：服端配置与宿主不一致时 probe 必须列出差异（保存成功 != 服端生效）', async () => {
  await withCase({}, async ({ host, gh, svc, settle }) => {
    await settle()
    // 服端"被人改坏了"：预置一份不一致的生效配置
    gh.setAppliedConfig('1', {
      item: { 启用: true, 自动扫描: true, 扫描间隔: 99, 没收违禁物品: false, 限制列表: [] },
      proj: { 启用: false, 伤害上限: 20000, 限制列表: [] },
    })
    const r = await host.call('get', '/api/anticheat/status', { query: { serverIds: '1' } })
    assert.equal(r.status, 200)
    const s1 = r.data.probe.servers[0]
    assert.equal(s1.ok, true)
    assert.equal(s1.match, false, '服端与宿主不一致时 match 必须是 false（字段名见 index.js:506）')
    assert.ok(s1.diff.length >= 2, `必须列出差异项：${JSON.stringify(s1.diff)}`)
    assert.ok(s1.diff.join(' ').includes('扫描间隔'), `差异里应包含被改的字段：${s1.diff.join(' ')}`)
  })
})
