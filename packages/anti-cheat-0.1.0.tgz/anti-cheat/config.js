/**
 * anti-cheat 清单模型（宿主侧唯一权威）
 *
 * 本文件是「物品违禁 / 弹幕违禁」两份清单的**唯一权威定义**，结构与旧版 TsWeb 逐字对齐：
 *   item  ← 旧版 <TShock.SavePath>/TSWeb/AntiCheat/物品违禁.json（旧 AntiCheatConfig，AntiCheat.cs:15-31）
 *   proj  ← 旧版 <TShock.SavePath>/TSWeb/AntiCheat/弹幕违禁.json（旧 ProjRestrictionConfig，proj-restrict.cs:9-19）
 * 完整形态：
 *   {
 *     "item": { "启用": false, "自动扫描": true, "扫描间隔": 10, "没收违禁物品": false, "限制列表": [...] },
 *     "proj": { "启用": false, "伤害上限": 20000, "限制列表": [...] }
 *   }
 *
 * 字段名逐字来源（这是一切校验与前端渲染的依据）：
 *   AntiCheatConfig        旧 AntiCheat.cs:15-31（`启用` / `自动扫描` / `扫描间隔` / `没收违禁物品` / `限制列表`）
 *   ProgressRestriction    旧 AntiCheat.cs:33-40（`进度` / `限制物品`）
 *   RestrictedItem         旧 item-restrict.cs:14-24（`id` / `stack`(默认 1) / `method`(默认 "log")）
 *   ProjRestrictionConfig  旧 proj-restrict.cs:9-19（`启用` / `伤害上限`(默认 20000) / `限制列表`）
 *   ProjRestriction        旧 proj-restrict.cs:21-28（`进度`(默认 "始终生效") / `限制弹幕`）
 *   RestrictedProj         旧 proj-restrict.cs:30-37（`id` / `method`(默认 "log")，**没有 stack**）
 *   ※ 任务书写的类名 `PrognessRestriction` 在旧版源码里实际是 `ProgressRestriction`（AntiCheat.cs:33）；
 *     本件按旧版源码取名，差异已记入交付报告。
 *
 * ══════════ 唯一权威默认值（对应必改缺陷 #6「默认值不一致」）══════════
 * 旧版有**三套互相矛盾**的默认值：
 *   ① 类属性初始化器  `自动扫描=false` / `扫描间隔=600`（旧 AntiCheat.cs:21、:24）
 *   ② 首次运行落盘     `自动扫描=true`  / `扫描间隔=10` （旧 AntiCheat.cs:263-264）
 *   ③ 后端资源 JSON    `自动扫描=true`  / `扫描间隔=10` （旧 backend/resources/默认配置/物品违禁.json:3-4）
 * 本件**收口为一份**：取 ②③ 的 `true` / `10`。理由：
 *   - ②③ 是**两个互相独立**的来源却给出同一组值，①是孤例；
 *   - 旧版注释（AntiCheat.cs:259 逐字）「扫描间隔取 10 秒，与后端默认配置资源保持一致」明确点名 ③ 是权威；
 *   - ①只在异常兜底路径（旧 AntiCheat.cs:295 `_config = new AntiCheatConfig()`）生效，
 *     也就是说它一旦生效，行为会**静默地从"每 10 秒扫一次"变成"关闭自动扫描 + 600 秒"**（60 倍差异）。
 * 另一处旧版矛盾：后端资源 JSON **没有 `没收违禁物品` 键**（物品违禁.json 顶层只有
 * 启用/自动扫描/扫描间隔/限制列表），导致旧版「应用默认配置」会把它**静默重置为 false**
 * （管理员已开启的没收被悄悄关掉）。本件的 `resources/物品违禁.json` **补上了该键**，
 * 且「应用默认配置」默认**不碰开关**（见 defaults.js 的 applyDefaults）。
 *
 * ══════════ `method` 收敛为闭集（对应必改缺陷 #1 = 旧版 D-34）══════════
 * 旧版 `method` 是**自由字符串**，任何非 log/kick/ban 的值会被当作**自定义 TShock 命令模板**执行
 * （旧 item-restrict.cs:364-369 的 IsStandardMethod 判定，执行点 :332、:408、:613、:661；
 *  弹幕侧同构 proj-restrict.cs:56-62）→ 只授「配置违禁清单」权限的角色即可获得服务端任意命令执行。
 * 本件把 `method` 收敛为**闭集**，并把自定义命令拆成**独立结构化字段 `command`**：
 *   METHOD_VALUES = ['log','kick','ban','drop','command']
 *   - 只有 `method === 'command'` 时 `command` 才被使用；写入者是**显式**这么设的，且每次写入都进审计；
 *   - 导入旧配置时，旧的裸模板字符串会被**迁移**成 `{ method:'command', command:'<原模板>' }` 并记警告
 *     （不是丢弃、也不是静默继续当命令执行）——见 migrateLegacyMethod。
 *
 * `drop` 与 `exempt` 的取舍：旧版 `drop` 只出现在粒子防线、`exempt` 只出现在物品扫描的记账路径
 * （旧 item-restrict.cs:241），两者都不在 `AntiCheatConfig`/`ProjRestrictionConfig` 的值域文档里。
 * 本件**保留 `drop`**（语义=只阻断不处置，物品丢出/存箱与弹幕阻断天然有这个档），
 * **不保留 `exempt`**（它没有任何独立语义，等价于 `log`），差异已记入交付报告。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */

// ═══════════════════════ 常量 ═══════════════════════

/** `method` 闭集（唯一权威；服端 AntiCheatConfig.cs 的 ViolationMethods 与它同源同值） */
export const METHOD_VALUES = ['log', 'kick', 'ban', 'drop', 'command']

/** 处置方式的中文说明（前端按钮 title 与 /scanlist 输出用；旧版逐字：item-restrict.cs:151-157） */
export const METHOD_LABELS = {
  log: '仅记录日志',
  kick: '踢出玩家',
  ban: '封禁玩家',
  drop: '仅阻断（不踢不封）',
  command: '执行自定义命令',
}

/** 自定义命令模板的占位符（旧版 AntiCheat.cs:700-712 逐字 4 个） */
export const COMMAND_PLACEHOLDERS = ['{playername}', '{itemname}', '{itemid}', '{projid}']

/**
 * 旧版前端内置的 4 个快捷命令模板（旧 ItemRestrictView.vue:190-195、ProjRestrictView.vue:182）。
 * 逐字照搬。它们**自带引号**——这正是为什么占位符转义**只转义 `\` 与 `"`**：
 * 若再补一对引号会和这些模板自己的引号冲突（旧 AntiCheat.cs:681-683 注释逐字说明了这一点）。
 */
export const QUICK_COMMANDS = [
  { method: 'ban', label: '封禁玩家', template: '/banp "{playername}" "违规使用{itemname}"' },
  { method: 'kick', label: '踢出玩家', template: '/kick "{playername}" "违规使用{itemname}"' },
  { method: 'log', label: '广播公告', template: '/bc "{playername}违规使用{itemname}"' },
  { method: 'command', label: '清除物品', template: '/remove {playername} {itemid}' },
]

/** 物品 ID / 弹幕 ID 的合法范围（Terraria 的 netID 是 short；0 与负数都是脏数据） */
export const ID_MIN = 1
export const ID_MAX = 65535

/** `扫描间隔`（秒）的合法范围：下限 1 秒（0 会变成扫描风暴，旧版无钳制）、上限 1 天 */
export const INTERVAL_MIN = 1
export const INTERVAL_MAX = 86400

/** `伤害上限` 的合法范围（默认 20000，旧 proj-restrict.cs:15） */
export const DAMAGE_LIMIT_DEFAULT = 20000

/**
 * 唯一权威默认值。
 * `启用=false`：与旧版两处一致（旧 AntiCheat.cs:18、物品违禁.json:2）。
 * `扫描间隔=10` / `自动扫描=true`：见文件头「唯一权威默认值」的裁定。
 * `没收违禁物品=false`：旧版两处一致，且本次把它**补进** resources/物品违禁.json。
 */
export const DEFAULT_ITEM_SWITCHES = {
  启用: false,
  自动扫描: true,
  扫描间隔: 10,
  没收违禁物品: false,
}

/** 弹幕侧默认开关（旧 proj-restrict.cs:12、:15 与弹幕违禁.json:2-3 一致） */
export const DEFAULT_PROJ_SWITCHES = {
  启用: false,
  伤害上限: DAMAGE_LIMIT_DEFAULT,
}

/**
 * 世界进度名的**权威顺序**（前端卡片顺序、以及「进度档位」下拉的顺序都来自它）。
 *
 * 来源（不是凭空硬编码）：
 *   前三段 = 旧版默认清单 `物品违禁.json` 的档位顺序（旧文件里就是 UI 卡片顺序）
 *            + 本次新增的「巨鹿」档（插在 蜂后 与 骷髅王 之间，与 BossProgress.BossOrder 一致）
 *   后一段 = 旧 GetWorldInfo.cs:35-43 `EventNames` 里剩余的 5 个事件名
 *            （哥布林入侵 已在第一段，其余 5 个从未出现在默认清单里，但 GetWorldStatus 认它们）
 * 「始终生效」的语义见旧 GetWorldInfo.cs:273-276（直接 `return true`），且各档之间是
 * **叠加 union 而非互斥**（旧 item-restrict.cs:129-141 把所有仍生效档位的物品合并成一张清单）。
 */
export const PROGRESS_ORDER = [
  '始终生效',
  // ── 旧默认清单的物品档位顺序（BossProgress.BossOrder + 事件「哥布林入侵」）──
  '哥布林入侵',
  '史莱姆王',
  '克苏鲁之眼',
  '世界吞噬者',
  '克苏鲁之脑',
  '蜂后',
  '巨鹿',
  '骷髅王',
  '血肉墙',
  '史莱姆皇后',
  '毁灭者',
  '双子魔眼',
  '机械骷髅王',
  '世纪之花',
  '石巨人',
  '猪龙鱼公爵',
  '光之女皇',
  '拜月教教徒',
  '月亮领主',
  // ── 旧 EventNames 里未进默认清单的其余事件（GetWorldStatus 认，界面也允许选）──
  '海盗入侵',
  '火星人入侵',
  '日食',
  '冰雪女王',
  '南瓜王',
]

/** 「始终生效」档名（旧 GetWorldInfo.cs:275 的逐字字面量） */
export const ALWAYS_PROGRESS = '始终生效'

/** 已知进度名集合（用于「未知档位」的判定：未知档位**保留而非删除**，只记警告） */
export const KNOWN_PROGRESS = new Set(PROGRESS_ORDER)

/** 单份清单的档位上限 / 条数上限（防呆；旧版完全没有校验） */
export const MAX_TIERS = 64
export const MAX_ENTRIES_PER_TIER = 2000

// ═══════════════════════ 工具 ═══════════════════════

/** 取某档位数组里的条目数组字段名（物品侧 `限制物品`、弹幕侧 `限制弹幕`） */
export const ENTRY_KEY = { item: '限制物品', proj: '限制弹幕' }

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v)
}

/**
 * 取整数；**不接受非整数**（返回 null 交由调用方走"跳过 + 警告"或"钳制"）。
 *
 * ★ 这里刻意不对数字做 Math.trunc：整数是这个文件里所有数值字段的契约
 *   （id 是 Terraria netID、stack 是个数、扫描间隔是秒、伤害上限是整数），
 *   而静默截断会**改掉语义**：
 *     - `id: 1.5` → 截成 1，等于把规则悄悄指向**另一个物品**（1 号物品被误伤，而原意不明）；
 *     - `扫描间隔: 1.5` → 截成 1，扫描频率变成预期的 10 倍（全服背包遍历）；
 *   两者的字符串形态（'1.5'）本来就被下面的正则挡住，只有数字形态会被截断 —— 那种"看输入类型决定
 *   是拒绝还是静默改值"的不一致最难排查。统一成"非整数即非法"，让上层的警告如实报出来。
 */
function toInt(v) {
  if (typeof v === 'number' && Number.isFinite(v)) return Number.isInteger(v) ? v : null
  if (typeof v === 'string' && v.trim() !== '' && /^-?\d+$/.test(v.trim())) return Number(v.trim())
  return null
}

/** 构造带 status 的错误（宿主路由按 err.status 回状态码） */
export function httpError(status, message, extra = {}) {
  const err = new Error(message)
  err.status = status
  Object.assign(err, extra)
  return err
}

export function badRequest(message, extra = {}) {
  return httpError(400, message, extra)
}

// ═══════════════════════ 默认配置 ═══════════════════════

/** 默认配置（深拷贝，调用方可安全改）。**限制列表一律为空**：清单只来自 resources/ 或管理员编辑。 */
export function defaultConfig() {
  return {
    item: { ...DEFAULT_ITEM_SWITCHES, 限制列表: [] },
    proj: { ...DEFAULT_PROJ_SWITCHES, 限制列表: [] },
  }
}

/** 新增一条物品限制时的初值（旧前端 ItemRestrictView.vue:323-326 加空行后手填；此处给安全初值） */
export function defaultItemEntry() {
  return { id: 0, stack: 1, method: 'log', command: '' }
}

/** 新增一条弹幕限制时的初值（旧 RestrictedProj 没有 stack，见 proj-restrict.cs:30-37） */
export function defaultProjEntry() {
  return { id: 0, method: 'log', command: '' }
}

// ═══════════════════════ method 收敛与旧值迁移 ═══════════════════════

/**
 * 归一 `method`，并把**旧的裸命令模板**迁移进 `command`（必改缺陷 #1）。
 *
 * 迁移判据照旧版 `IsStandardMethod`（旧 item-restrict.cs:364-370）：null/空 或
 * log/kick/ban（序数忽略大小写）为标准档；**其余字符串在旧版会被当命令模板执行**。
 * 本件对这类值一律 `method='command'` + `command=<原字符串>`，并记一条警告。
 *
 * 注意 trim 口径：旧版判定用的是**未 trim 的原值**（`IsMethod` 内 `OrdinalIgnoreCase` 比较），
 * 但检测路径上 `RefreshRestrictedItems` 会先 `Method?.ToLower()`（旧 item-restrict.cs:137）。
 * 本件统一先 trim 再比较（`" kick "` 按 kick 处理）——这是**有意的宽容化**，因为它只会让
 * 「本来会走默认分支（=执行自定义命令）的值」变成标准档，方向上更安全，差异已记入报告。
 *
 * @returns {{ method: string, command: string, migrated: boolean, raw: string }}
 */
export function normalizeMethod(raw) {
  const text = raw == null ? '' : String(raw)
  const trimmed = text.trim()
  const normalized = { method: trimmed.toLowerCase(), command: '', migrated: false, raw: text }

  if (trimmed === '') {
    // 旧版：null/空 → 标准档 "log"（item-restrict.cs:89、proj-restrict.cs:89 的 `?? "log"`）
    normalized.method = 'log'
    return normalized
  }
  if (METHOD_VALUES.includes(normalized.method)) return normalized

  // 非闭集值 → 旧版会把它当自定义命令模板执行，这里迁移进独立字段
  normalized.method = 'command'
  normalized.command = trimmed
  normalized.migrated = true
  return normalized
}

/**
 * 归一自定义命令模板：trim；不以 `/` 开头则补上（旧版 ExecuteCommand 的做法，AntiCheat.cs:734-738）。
 * 返回 `{ command, prefixed }`，`prefixed=true` 表示发生了补斜杠（要记警告，不能静默改值）。
 */
export function normalizeCommand(raw) {
  const text = raw == null ? '' : String(raw).trim()
  if (text === '') return { command: '', prefixed: false }
  if (text.startsWith('/')) return { command: text, prefixed: false }
  return { command: '/' + text, prefixed: true }
}

// ═══════════════════════ 归一（宽容，读盘用） ═══════════════════════

/**
 * 把任意输入归一成合法配置。**永不抛错**（读盘路径必须是"读不懂也能起来"），
 * 所有异常事实（迁移、补斜杠、未知档位、越界值被钳制）都进 `warnings`。
 *
 * @param {any} raw 任意输入（可能来自旧配置文件、损坏文件、前端）
 * @returns {{ config: object, warnings: string[] }}
 */
export function normalizeConfig(raw) {
  const warnings = []
  const out = defaultConfig()
  const src = isPlainObject(raw) ? raw : {}
  if (!isPlainObject(raw)) {
    if (raw !== undefined && raw !== null) warnings.push('配置不是 JSON 对象，已整体回落默认配置')
    return { config: out, warnings }
  }

  // ── 顶层：旧版形态兼容（把顶层直接当 item 用）──
  // 旧版宿主/服端的配置文件里 item 与 proj 是**两份独立文件**；若有人把其中一份直接当本件配置
  // 丢进来（顶层就是 `启用/限制列表`），这里认出来并归到 item，避免"整份配置被当成空"。
  let itemRaw = src.item
  let projRaw = src.proj
  if (!isPlainObject(itemRaw) && (('限制列表' in src) || ('启用' in src) || ('自动扫描' in src))) {
    itemRaw = src
    warnings.push('检测到旧版「物品违禁」单文件形态（顶层即 启用/限制列表），已按 item 读取')
  }
  if (!isPlainObject(projRaw) && '伤害上限' in src) {
    projRaw = src
    warnings.push('检测到旧版「弹幕违禁」单文件形态（顶层即 启用/伤害上限），已按 proj 读取')
  }

  out.item = normalizeItem(itemRaw, warnings)
  out.proj = normalizeProj(projRaw, warnings)
  return { config: out, warnings }
}

function normalizeBool(v, fallback) {
  if (typeof v === 'boolean') return v
  if (typeof v === 'string') {
    const t = v.trim().toLowerCase()
    if (t === 'true') return true
    if (t === 'false') return false
  }
  return fallback
}

/** 归一物品侧（`启用/自动扫描/扫描间隔/没收违禁物品/限制列表`） */
function normalizeItem(raw, warnings) {
  const fallback = { ...DEFAULT_ITEM_SWITCHES, 限制列表: [] }
  if (!isPlainObject(raw)) return fallback

  const out = {
    启用: normalizeBool(raw.启用, DEFAULT_ITEM_SWITCHES.启用),
    自动扫描: normalizeBool(raw.自动扫描, DEFAULT_ITEM_SWITCHES.自动扫描),
    扫描间隔: DEFAULT_ITEM_SWITCHES.扫描间隔,
    没收违禁物品: normalizeBool(raw.没收违禁物品, DEFAULT_ITEM_SWITCHES.没收违禁物品),
    限制列表: [],
  }

  // 扫描间隔 + 旧字段名兼容（旧 AntiCheat.cs:280-289：新键 <=0 时读旧键「自动扫描间隔-秒」）
  let interval = toInt(raw.扫描间隔)
  if ((interval === null || interval <= 0) && '自动扫描间隔-秒' in raw) {
    const legacy = toInt(raw['自动扫描间隔-秒'])
    if (legacy !== null && legacy > 0) {
      interval = legacy
      warnings.push(`物品侧读到了旧字段「自动扫描间隔-秒」=${legacy}，已迁移为「扫描间隔」`)
    }
  }
  if (interval === null) {
    if (raw.扫描间隔 !== undefined) {
      warnings.push(`物品侧「扫描间隔」取值非法（${JSON.stringify(raw.扫描间隔)}），已回落默认 ${DEFAULT_ITEM_SWITCHES.扫描间隔}`)
    }
    interval = DEFAULT_ITEM_SWITCHES.扫描间隔
  } else if (interval < INTERVAL_MIN || interval > INTERVAL_MAX) {
    const clamped = Math.min(Math.max(interval, INTERVAL_MIN), INTERVAL_MAX)
    warnings.push(`物品侧「扫描间隔」=${interval} 超出 [${INTERVAL_MIN}, ${INTERVAL_MAX}]，已钳制为 ${clamped}`)
    interval = clamped
  }
  out.扫描间隔 = interval

  out.限制列表 = normalizeTiers(raw.限制列表, 'item', warnings, '物品侧')
  return out
}

/** 归一弹幕侧（`启用/伤害上限/限制列表`） */
function normalizeProj(raw, warnings) {
  const fallback = { ...DEFAULT_PROJ_SWITCHES, 限制列表: [] }
  if (!isPlainObject(raw)) return fallback

  const out = {
    启用: normalizeBool(raw.启用, DEFAULT_PROJ_SWITCHES.启用),
    伤害上限: DEFAULT_PROJ_SWITCHES.伤害上限,
    限制列表: [],
  }

  // 伤害上限：旧 proj-restrict.cs:108 的判定是 `damage > config.DamageLimit`，
  // 所以任何 <= 0 的值都会让**每一条**弹幕都"伤害异常"（必被 ban）。这是必须挡住的配置事故。
  let limit = toInt(raw.伤害上限)
  if (limit === null) {
    if (raw.伤害上限 !== undefined) {
      warnings.push(`弹幕侧「伤害上限」取值非法（${JSON.stringify(raw.伤害上限)}），已回落默认 ${DAMAGE_LIMIT_DEFAULT}`)
    }
    limit = DAMAGE_LIMIT_DEFAULT
  } else if (limit < 1) {
    warnings.push(`弹幕侧「伤害上限」=${limit} 会让所有弹幕都判定为异常伤害，已钳制为 ${DAMAGE_LIMIT_DEFAULT}`)
    limit = DAMAGE_LIMIT_DEFAULT
  }
  out.伤害上限 = limit

  out.限制列表 = normalizeTiers(raw.限制列表, 'proj', warnings, '弹幕侧')
  return out
}

/** 归一战位数组（`[{进度, 限制物品|限制弹幕: [...]}]`） */
function normalizeTiers(rawList, kind, warnings, where) {
  const entryKey = ENTRY_KEY[kind]
  const out = []
  if (!Array.isArray(rawList)) {
    if (rawList !== undefined) warnings.push(`${where}「限制列表」不是数组，已按空清单处理`)
    return out
  }
  if (rawList.length > MAX_TIERS) {
    warnings.push(`${where}「限制列表」档位数 ${rawList.length} 超过上限 ${MAX_TIERS}，仅保留前 ${MAX_TIERS} 档`)
  }
  for (const tier of rawList.slice(0, MAX_TIERS)) {
    if (!isPlainObject(tier)) {
      warnings.push(`${where}有一个档位不是对象，已跳过`)
      continue
    }
    const progress = tier.进度 == null ? ALWAYS_PROGRESS : String(tier.进度).trim()
    if (progress === '') {
      warnings.push(`${where}有一个档位的「进度」为空，已跳过该档`)
      continue
    }
    if (!KNOWN_PROGRESS.has(progress)) {
      warnings.push(`${where}档位「${progress}」不是已知进度名（服端 GetWorldStatus 对它恒判不生效）——已原样保留，未删除`)
    }
    const entries = normalizeEntries(tier[entryKey], kind, warnings, `${where}档位「${progress}」`)
    out.push({ 进度: progress, [entryKey]: entries })
  }
  return out
}

/** 归一单个档位里的条目数组 */
function normalizeEntries(rawEntries, kind, warnings, where) {
  const out = []
  if (!Array.isArray(rawEntries)) {
    if (rawEntries !== undefined) warnings.push(`${where}的条目不是数组，已按空处理`)
    return out
  }
  if (rawEntries.length > MAX_ENTRIES_PER_TIER) {
    warnings.push(`${where}条目数 ${rawEntries.length} 超过上限 ${MAX_ENTRIES_PER_TIER}，仅保留前 ${MAX_ENTRIES_PER_TIER} 条`)
  }
  const seen = new Set()
  for (const entry of rawEntries.slice(0, MAX_ENTRIES_PER_TIER)) {
    if (!isPlainObject(entry)) {
      warnings.push(`${where}有一条记录不是对象，已跳过`)
      continue
    }

    const id = toInt(entry.id)
    if (id === null || id < ID_MIN || id > ID_MAX) {
      warnings.push(`${where}有一条记录的 id=${JSON.stringify(entry.id)} 不在 [${ID_MIN}, ${ID_MAX}]，已跳过（脏 ID 会让合法物品被误判）`)
      continue
    }
    if (seen.has(id)) {
      warnings.push(`${where}的 id=${id} 重复出现（旧版允许重复且会重复生效），已保留全部重复项`) // 不删除：照旧版"重复即多档叠加"的行为
    }
    seen.add(id)

    const m = normalizeMethod(entry.method)
    // ★ 迁移出来的命令必须是**生效的那一条**：method 是旧版自由文本时，命令文本在 m.command 里，
    //   若这里仍读原始 entry.command（通常是空），就会落盘成 {method:"command", command:""} ——
    //   处置方式显示"执行自定义命令"但命令是空的，且与下面的警告文案自相矛盾（静默丢命令）。
    const c = normalizeCommand(m.migrated ? m.command : entry.command)
    if (m.migrated) {
      warnings.push(
        `${where}的 id=${id} 的 method 是旧版自由文本（${JSON.stringify(m.raw)}）——` +
        `旧版会把它当服务端命令执行（D-34）；已迁移为 method="command" + command=${JSON.stringify(c.command)}，请确认这条命令是你要的`,
      )
    }
    if (c.prefixed) {
      warnings.push(`${where}的 id=${id} 的 command 不以 / 开头，已补为 ${JSON.stringify(c.command)}（旧版 ExecuteCommand 同样会自动补）`)
    }
    // method !== 'command' 却带了 command：**保留**（不清空），因为它可能是管理员切回标准档前的草稿；
    // 但必须让"它当前不会被使用"这件事可见。
    if (m.method !== 'command' && c.command !== '') {
      warnings.push(`${where}的 id=${id} 设了 command 但 method=${m.method}——当前处置不会执行该命令（command 仅在 method="command" 时生效）`)
    }

    if (kind === 'item') {
      let stack = toInt(entry.stack)
      if (stack === null) {
        if (entry.stack !== undefined) {
          warnings.push(`${where}的 id=${id} 的 stack=${JSON.stringify(entry.stack)} 非法，已回落 1`)
        }
        stack = 1
      } else if (stack < 1) {
        // 旧版判定是 `stack >= candidate.Stack`（item-restrict.cs:187）。stack<=0 时**任何数量**都命中，
        // 包括持有 0 个（等价于"只要背包里出现该格就违规"），几乎必然是配置事故 → 钳到 1。
        warnings.push(`${where}的 id=${id} 的 stack=${stack} 会让任意数量（含 1 个）都违规，已钳制为 1`)
        stack = 1
      }
      out.push({ id, stack, method: m.method, command: c.command })
    } else {
      out.push({ id, method: m.method, command: c.command })
    }
  }
  return out
}

// ═══════════════════════ 严格校验（写盘用） ═══════════════════════

/**
 * 严格校验提交上来的配置（`POST /api/anticheat/config`）。
 *
 * 与 `normalizeConfig` 的分工：本函数是**权威校验**（旧版完全没有这一层，见旧 ItemConfigHandler.cs
 * 直接把客户端 JSON 反序列化后落盘；D-13 逐字「未验证 ID 范围、method 枚举值」）。
 * 它**不抛错**，而是把问题分成两类返回，由调用方决定：
 *   - `errors`   ：必须拒绝（非法 ID / stack / method / command 缺失 / 类型错误）
 *   - `warnings` ：可以接受但必须回显（旧 method 迁移、补斜杠、未知档位、重复 ID、脏值钳制）
 *
 * 之所以把"可接受的问题"也做成 error+warning 两分而不是一律 400：
 * 迁移与钳制是**必要的**（旧配置必须能被导入），但**绝不能静默**——两者都回显给管理员。
 *
 * @returns {{ config: object|null, errors: Array<{path:string,message:string}>, warnings: string[] }}
 */
export function validateConfig(raw) {
  const errors = []
  const warnings = []

  if (!isPlainObject(raw)) {
    return { config: null, errors: [{ path: '', message: '请求体必须是 JSON 对象' }], warnings }
  }
  for (const key of ['item', 'proj']) {
    if (raw[key] !== undefined && !isPlainObject(raw[key])) {
      errors.push({ path: key, message: `${key} 必须是对象` })
    }
  }
  if (errors.length > 0) return { config: null, errors, warnings }

  const { config, warnings: normWarnings } = normalizeConfig(raw)
  warnings.push(...normWarnings)

  // 归一之后再逐项做"硬校验"：归一不会拒绝任何东西，这里才拒绝
  checkItemStrict(raw.item, config, errors)
  checkProjStrict(raw.proj, config, errors)

  return { config: errors.length === 0 ? config : null, errors, warnings }
}

function checkItemStrict(rawItem, config, errors) {
  if (!isPlainObject(rawItem)) return
  for (const key of ['启用', '自动扫描', '没收违禁物品']) {
    if (rawItem[key] !== undefined && typeof rawItem[key] !== 'boolean') {
      errors.push({ path: `item.${key}`, message: `${key} 必须是布尔值` })
    }
  }
  checkIntervalStrict(rawItem, errors)
  checkTiersStrict(rawItem.限制列表, 'item', errors, 'item')
}

function checkIntervalStrict(rawItem, errors) {
  const interval = toInt(rawItem.扫描间隔)
  if (rawItem.扫描间隔 !== undefined && interval === null) {
    errors.push({ path: 'item.扫描间隔', message: '扫描间隔 必须是整数（秒）' })
    return
  }
  if (interval !== null && (interval < INTERVAL_MIN || interval > INTERVAL_MAX)) {
    errors.push({
      path: 'item.扫描间隔',
      message: `扫描间隔 必须在 [${INTERVAL_MIN}, ${INTERVAL_MAX}] 秒之间（收到 ${interval}）`,
    })
  }
}

function checkProjStrict(rawProj, config, errors) {
  if (!isPlainObject(rawProj)) return
  if (rawProj.启用 !== undefined && typeof rawProj.启用 !== 'boolean') {
    errors.push({ path: 'proj.启用', message: '启用 必须是布尔值' })
  }
  const limit = toInt(rawProj.伤害上限)
  if (rawProj.伤害上限 !== undefined && limit === null) {
    errors.push({ path: 'proj.伤害上限', message: '伤害上限 必须是整数' })
  } else if (limit !== null && limit < 1) {
    errors.push({ path: 'proj.伤害上限', message: `伤害上限 必须 >= 1（收到 ${limit}；<=0 会让所有弹幕都判定为异常伤害）` })
  }
  checkTiersStrict(rawProj.限制列表, 'proj', errors, 'proj')
}

/** 条目级硬校验：只检查"原始输入"里明显非法的东西（归一已把可修复的修好了） */
function checkTiersStrict(rawList, kind, errors, pathPrefix) {
  if (rawList === undefined) return
  if (!Array.isArray(rawList)) {
    errors.push({ path: `${pathPrefix}.限制列表`, message: '限制列表 必须是数组' })
    return
  }
  if (rawList.length > MAX_TIERS) {
    errors.push({ path: `${pathPrefix}.限制列表`, message: `限制列表 档位数不能超过 ${MAX_TIERS}` })
  }
  const entryKey = ENTRY_KEY[kind]
  rawList.forEach((tier, ti) => {
    const tierPath = `${pathPrefix}.限制列表[${ti}]`
    if (!isPlainObject(tier)) {
      errors.push({ path: tierPath, message: '档位必须是对象' })
      return
    }
    if (tier.进度 !== undefined && (typeof tier.进度 !== 'string' || tier.进度.trim() === '')) {
      errors.push({ path: `${tierPath}.进度`, message: '进度 必须是非空字符串' })
    }
    const entries = tier[entryKey]
    if (entries === undefined) return
    if (!Array.isArray(entries)) {
      errors.push({ path: `${tierPath}.${entryKey}`, message: `${entryKey} 必须是数组` })
      return
    }
    if (entries.length > MAX_ENTRIES_PER_TIER) {
      errors.push({ path: `${tierPath}.${entryKey}`, message: `${entryKey} 条数不能超过 ${MAX_ENTRIES_PER_TIER}` })
    }
    entries.forEach((entry, ei) => {
      const entryPath = `${tierPath}.${entryKey}[${ei}]`
      if (!isPlainObject(entry)) {
        errors.push({ path: entryPath, message: '记录必须是对象' })
        return
      }
      const id = toInt(entry.id)
      if (id === null || id < ID_MIN || id > ID_MAX) {
        errors.push({ path: `${entryPath}.id`, message: `id 必须是 [${ID_MIN}, ${ID_MAX}] 之间的整数（收到 ${JSON.stringify(entry.id)}）` })
      }
      if (kind === 'item' && entry.stack !== undefined) {
        const stack = toInt(entry.stack)
        if (stack === null || stack < 1) {
          errors.push({ path: `${entryPath}.stack`, message: `stack 必须是 >= 1 的整数（收到 ${JSON.stringify(entry.stack)}）` })
        }
      }
      // method：闭集。**注意**这里刻意允许"非闭集但非空"的值通过校验（会被归一迁移成 command），
      // 因为那正是旧配置的形态；但 method 缺失/空 必须拒绝（旧版缺失=log，这里要求显式写清）。
      if (entry.method === undefined || entry.method === null || String(entry.method).trim() === '') {
        errors.push({ path: `${entryPath}.method`, message: `method 不能为空（闭集：${METHOD_VALUES.join(' / ')}）` })
      }
    })
  })
}

// ═══════════════════════ 派生与载荷 ═══════════════════════

/**
 * 进度档位顺序：**从数据/配置派生**，不是前端硬编码的 19 项数组。
 *
 * 这是必改缺陷 #7 的第一半：旧版 `ItemRestrictView.vue` / `ProjRestrictView.vue` 各自
 * 硬编码 19 档（`fixedProgressOrder`），写侧只遍历该数组 → **集合外的档位"保存即被删除"**。
 * 本件改为：权威顺序（PROGRESS_ORDER）+ 配置里实际存在的**未知档位**（追加在末尾，原样保留）。
 *
 * @param {object} config 归一后的配置
 * @returns {string[]} 档位名数组（含未知档位）
 */
export function progressOrder(config) {
  const cfg = isPlainObject(config) ? config : {}
  const out = PROGRESS_ORDER.slice()
  const seen = new Set(out)
  for (const kind of ['item', 'proj']) {
    const tiers = Array.isArray(cfg[kind]?.限制列表) ? cfg[kind].限制列表 : []
    for (const tier of tiers) {
      const name = String(tier?.进度 ?? '')
      if (name !== '' && !seen.has(name)) {
        seen.add(name)
        out.push(name)
      }
    }
  }
  return out
}

/** 清单统计（前端徽标与状态页用） */
export function configStats(config) {
  const cfg = isPlainObject(config) ? config : defaultConfig()
  const count = (kind) => {
    const tiers = Array.isArray(cfg[kind]?.限制列表) ? cfg[kind].限制列表 : []
    const entries = tiers.reduce((n, t) => n + (Array.isArray(t[ENTRY_KEY[kind]]) ? t[ENTRY_KEY[kind]].length : 0), 0)
    return { tiers: tiers.length, entries }
  }
  const item = count('item')
  const proj = count('proj')
  const commands = ['item', 'proj'].reduce((n, kind) => {
    const tiers = Array.isArray(cfg[kind]?.限制列表) ? cfg[kind].限制列表 : []
    return n + tiers.reduce((m, t) => m + (t[ENTRY_KEY[kind]] || []).filter((e) => e.method === 'command').length, 0)
  }, 0)
  return {
    itemTiers: item.tiers,
    itemEntries: item.entries,
    projTiers: proj.tiers,
    projEntries: proj.entries,
    commandEntries: commands,
  }
}

/**
 * 配置级警告（照 promotion config.js:configWarnings 的做法：状态页直接显示"这份配置有问题"）。
 * 只报"会让管理员意外"的组合，不报纯风格问题。
 */
export function configWarnings(config) {
  const cfg = isPlainObject(config) ? config : defaultConfig()
  const out = []
  if (cfg.item?.启用 === true && (cfg.item.限制列表 || []).length === 0) {
    out.push('物品检测已启用，但物品限制清单是空的：不会有任何命中（请先「应用默认配置」或手动添加规则）')
  }
  if (cfg.proj?.启用 === true && (cfg.proj.限制列表 || []).length === 0) {
    out.push('弹幕检测已启用，但弹幕限制清单是空的：只会按「伤害上限」判定（请先「应用默认配置」或手动添加规则）')
  }
  const stats = configStats(cfg)
  if (stats.commandEntries > 0) {
    out.push(
      `有 ${stats.commandEntries} 条规则使用「自定义命令」处置：命中时服端会以服务器身份执行这些命令，` +
      '请逐条确认命令内容（每次在管理页改动都会写入审计流水）',
    )
  }
  if (cfg.item?.启用 === false && cfg.proj?.启用 === false) {
    out.push('物品与弹幕检测都未启用：检测日志不会有新记录（这不影响已存在的历史日志）')
  }
  const interval = Number(cfg.item?.扫描间隔)
  if (cfg.item?.自动扫描 === true && Number.isFinite(interval) && interval > 0 && interval < 5) {
    out.push(`自动扫描间隔只有 ${interval} 秒：扫描是全服背包遍历，过短会持续占用游戏服线程`)
  }
  if (cfg.item?.没收违禁物品 === true) {
    out.push('「没收违禁物品」已开启：命中时会把整个槽位清空（删除，不是退还），在线玩家即时同步、离线玩家直接 UPDATE tsCharacter')
  }
  return out
}

/**
 * 转成下发给服务端的载荷（两个 JSON 串，字段名与服端 AntiCheatEndpoints.cs 逐字对应）。
 * 之所以传**整份配置对象**而不是"补丁"：服端是"缺字段沿用旧值"的语义，整份发能保证幂等与可对账。
 */
export function toGamePayload(config) {
  const cfg = normalizeConfig(config).config
  return {
    item: JSON.stringify(cfg.item),
    proj: JSON.stringify(cfg.proj),
  }
}

/** 仅比较"清单内容"的规范化指纹（对账用；与顺序无关，因为档位顺序不影响判定语义） */
export function configFingerprint(config) {
  const cfg = normalizeConfig(config).config
  const tierKey = (kind, tier) => {
    const entries = (tier[ENTRY_KEY[kind]] || [])
      .map((e) => (kind === 'item' ? `${e.id}/${e.stack}/${e.method}/${e.command}` : `${e.id}/${e.method}/${e.command}`))
      .sort()
    return `${tier.进度}=[${entries.join(',')}]`
  }
  return JSON.stringify({
    item: {
      启用: cfg.item.启用,
      自动扫描: cfg.item.自动扫描,
      扫描间隔: cfg.item.扫描间隔,
      没收违禁物品: cfg.item.没收违禁物品,
      限制列表: (cfg.item.限制列表 || []).map((t) => tierKey('item', t)).sort(),
    },
    proj: {
      启用: cfg.proj.启用,
      伤害上限: cfg.proj.伤害上限,
      限制列表: (cfg.proj.限制列表 || []).map((t) => tierKey('proj', t)).sort(),
    },
  })
}
