/**
 * anti-cheat 前端半 —— 玩家详情页的「违禁物品告警」区块
 *
 * ══════════ 这一块修的是旧版哪个缺陷 ══════════
 * 旧 `UserDetailView.vue:13-23` 自己在**前端重算**了一遍违禁判定，但读的是 `config.items`，
 * 而真实配置结构是 `限制列表[].限制物品[].{id,stack,method}` —— 字段名根本不存在，
 * 于是**违禁告警永远为空**（规格 A §6.0/规格 B §3.5 双向核对逐字指出；
 * plugins/anti-cheat/index.js:856-859 也把这件缺陷写进了注释）。
 * 同源缺陷还有 `/api/anticheat/check-anomaly` 在前端与后端都有引用、但**旧 C# 从未注册该端点**，
 * 所以它恒返回 200 且恒 false（index.js:854-863）。
 *
 * ══════════ 本件的修法 ══════════
 *   1. **不再在前端重算生效档位**：哪些档位当前生效取决于**世界进度**（BossProgress.GetWorldStatus
 *      要读 NPC.downed* / 击杀计数），那是游戏服进程内的状态，宿主都不知道，前端更不可能知道。
 *      所以判定一律走宿主转发到服端的 `GET /api/anticheat/check-anomaly`（index.js:865-874），
 *      前端只负责把背包里的 netID 收集起来去问。
 *   2. **配置结构按真实字段读**：只从 `限制列表[].限制物品[].{id,stack,method}` 预筛
 *      "背包里出现了配置里提到的物品"，把请求量压到个位数；预筛本身不下任何结论
 *      （结论一定来自服端），所以不会再出现"字段读错 → 永远为空"。
 *   3. **不许静默为空**：旧版空态没有任何解释。本件把"为什么是空的"分开说清楚 ——
 *      背包里没有被配置提到的物品 / 没有选中服务器 / 该服没装 AntiCheat.dll / 查询失败，
 *      四种情况给四种文案，且失败时**明确显示失败**而不是显示成"无告警"。
 *
 * ══════════ 挂载方式（不修改 base）══════════
 * 走宿主既有扩展点 `window.tsweb.registerPlayerDetailSection({ id, title, order, render })`
 * （plugins/web/public/app.js:42-59），base 侧由 plugins/base/client/players.js:411-433 渲染，
 * 并且该处注释原文就写着「任意插件……可注册区块挂进详情页，**无需修改本文件**」。
 * render 的返回值被 base 当清理函数调用（players.js:454-456、:418-424）。
 * **本件不修改 base 的任何文件。**
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import {
  esc, get, errText, dataOf, API, itemNameOf, itemIconUrl,
  loadItemDict, currentServerId, reqTimed, bindImageFallback,
} from './shared/api.js'
import { injectStyle } from './shared/style.js'
// 处置方式文案：用 shared/method.js（宿主闭集）而不是 client/log.js 的日志映射
// （日志映射含 exempt/query 这类只在日志库出现的值，且从 log.js 导入会连带触发它注册视图）
import { methodLabel } from './shared/method.js'

/** 一次最多逐个向服端发起多少条判定（多余的在界面上如实说明，不假装全查过） */
export var MAX_CHECK_IDS = 8
/** 配置缓存 TTL（毫秒）：连续打开多个玩家详情页时不必重复拉配置（配置本身不大，但不是免费的） */
export var CONFIG_TTL_MS = 30000
/** 单条判定的超时（毫秒）。宿主 api() 不透传 AbortSignal，所以只能用 Promise.race 兜时间 */
export var CHECK_TIMEOUT_MS = 8000

var cfgCache = { at: 0, config: null, error: '' }
var styleDone = false

function injectStyleOnce() {
  if (styleDone) return
  styleDone = true
  injectStyle()
}

/**
 * 读取配置（带 TTL 缓存）。
 * 走 `GET /api/anticheat/config`（index.js:693-717），只取 `config.item`。
 * 失败时返回 { config: null, error }，**不抛**（区块渲染由 base 包在 try 里，
 * 但自己吞掉异常能让"配置读不到"显示成可读文案而不是"区块渲染失败"）。
 */
export async function loadConfigCached(now) {
  var t = typeof now === 'number' ? now : Date.now()
  if (cfgCache.config && (t - cfgCache.at) < CONFIG_TTL_MS) {
    return { config: cfgCache.config, error: '' }
  }
  var res = await get(API.config)
  if (!res.ok) {
    var msg = errText(res, '读取反作弊配置失败')
    cfgCache = { at: t, config: null, error: msg }
    return { config: null, error: msg }
  }
  var d = dataOf(res)
  cfgCache = { at: t, config: d && d.config ? d.config : null, error: '' }
  return { config: cfgCache.config, error: '' }
}

/** 只给测试/自检用：清掉配置缓存 */
export function clearConfigCache() {
  cfgCache = { at: 0, config: null, error: '' }
}

/**
 * 从配置里取"被限制的物品 id → 声称的上限与处置方式"。
 *
 * 结构出处：`plugins/anti-cheat/config.js` 的 `ENTRY_KEY.item = '限制物品'`
 * 与归一结果 `限制列表[].{进度,限制物品[]}`（config.js:441-460 一带）；
 * 旧前端读的 `config.items` **不存在**，这正是"永远为空"的根因。
 *
 * 注意：多档位可能提到同一个 id，上限取**最小值**（最严的一档）。这只是"预筛 + 展示参考"，
 * 真正的生效判定（哪个档位在当前世界进度下生效）由服端给。
 */
export function configItemIndex(config) {
  var out = {}
  var tiers = (config && Array.isArray(config.item && config.item['限制列表'])) ? config.item['限制列表'] : []
  for (var i = 0; i < tiers.length; i++) {
    var tier = tiers[i] || {}
    var progress = String(tier['进度'] == null ? '' : tier['进度'])
    var entries = Array.isArray(tier['限制物品']) ? tier['限制物品'] : []
    for (var j = 0; j < entries.length; j++) {
      var e = entries[j] || {}
      var id = Number(e.id)
      if (!Number.isInteger(id) || id <= 0) continue
      var stack = Number(e.stack)
      if (!Number.isInteger(stack) || stack < 1) stack = 1
      var cur = out[id]
      if (!cur) {
        out[id] = { id: id, stack: stack, method: String(e.method || ''), progress: [progress] }
      } else {
        if (stack < cur.stack) {
          cur.stack = stack
          cur.method = String(e.method || '')
        }
        if (cur.progress.indexOf(progress) < 0) cur.progress.push(progress)
      }
    }
  }
  return out
}

/**
 * 把背包（`doc.inventory`：`[{slot,netID,prefix,stack,favorited}]`，字段名出处
 * plugins/base/client/players.js:1122、:1287）按 netID 聚合。
 * 只看 netID > 0 的格子；同 id 多格**数量相加**（判定口径与服端扫描一致：看玩家持有总量）。
 */
export function groupInventory(inventory) {
  var list = Array.isArray(inventory) ? inventory : []
  var map = {}
  var order = []
  var filled = 0
  for (var i = 0; i < list.length; i++) {
    var it = list[i] || {}
    var id = Number(it.netID)
    if (!Number.isInteger(id) || id <= 0) continue
    var stack = Number(it.stack)
    if (!Number.isInteger(stack) || stack < 0) stack = 0
    filled += 1
    if (!map[id]) {
      map[id] = { id: id, stack: 0, slots: 0, favorited: false }
      order.push(id)
    }
    map[id].stack += stack
    map[id].slots += 1
    if (it.favorited === true) map[id].favorited = true
  }
  return { byId: map, ids: order, filled: filled }
}

function kvHtml(label, valueHtml) {
  return '<div style="display:flex;justify-content:space-between;gap:10px;align-items:baseline">' +
    '<span class="ac-muted" style="font-size:12px">' + esc(label) + '</span>' +
    '<span style="font-size:12.5px;text-align:right">' + valueHtml + '</span></div>'
}

function hintHtml(text) {
  return '<p class="ac-muted" style="font-size:11.5px;margin:10px 0 0;line-height:1.75">' + text + '</p>'
}

function methodText(m) {
  return m ? methodLabel(m) : '-'
}

/** 判定一行的展示 */
function rowHtml(item, check, fallback) {
  var id = item.id
  var name = (check && check.itemName) || itemNameOf(id) || ('物品 ID ' + id)
  var icon = itemIconUrl(id)
  var anomaly = check ? check.anomaly === true : null
  var badge = anomaly === null
    ? '<span class="ac-badge warn">未判定</span>'
    : (anomaly ? '<span class="ac-badge err">违禁</span>' : '<span class="ac-badge ok">未达阈值</span>')
  var allowed = check && check.allowedStack !== undefined && check.allowedStack !== null
    ? check.allowedStack
    : (fallback ? fallback.stack : '-')
  var mth = (check && check.method) || (fallback && fallback.method) || ''
  var prog = (check && check.progress) || (fallback && fallback.progress ? fallback.progress.join('、') : '')
  var html = '<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border,#2a2f3a)">'
  html += icon
    ? '<img src="' + esc(icon) + '" alt="" loading="lazy" style="width:26px;height:26px;object-fit:contain;flex:none">'
    : '<span class="ac-icon-ph">?</span>'
  html += '<div style="min-width:0;flex:1">'
  html += '<div style="font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' +
    esc(name + '（ID ' + id + '）') + '">' + esc(name) + '</div>'
  html += '<div class="ac-muted" style="font-size:11px">持有 ' + esc(item.stack) + '（' + esc(item.slots) + ' 格）' +
    '　上限 ' + esc(allowed) + '　处置 ' + esc(methodText(mth)) +
    (prog ? '　档位 ' + esc(prog) : '') + '</div>'
  html += '</div><div style="flex:none">' + badge + '</div>'
  html += '</div>'
  return html
}

/**
 * 玩家详情页区块的渲染函数（导出以便静态检查/测试）。
 * 返回清理函数：详情页重建或离开时由 base 调用（players.js:454-456）。
 */
export function renderAlertSection(container, account, doc) {
  if (!container) return function () { }
  injectStyleOnce()

  var cancelled = false
  bindImageFallback(container)
  container.innerHTML = '<p class="ac-muted" style="font-size:12px;margin:0">读取背包与配置中...</p>'

  var user = (account && (account.username || account.name)) ||
    (doc && doc.account && (doc.account.username || doc.account.name)) || ''
  var grouped = groupInventory(doc && doc.inventory)

  function done(html) {
    if (cancelled) return
    container.innerHTML = html
  }

  if (grouped.filled === 0) {
    done('<p class="ac-muted" style="font-size:12px;margin:0">该角色背包里没有任何物品，无需判定。</p>' +
      hintHtml('数据来自玩家详情接口的背包字段（plugins/base/client/players.js:1122 的 inventory）。'))
    return function () { cancelled = true }
  }

  loadConfigCached().then(function (r) {
    if (cancelled) return
    if (r.error) {
      // ★ 与旧版的关键差异：读不到配置时**明说读不到**，而不是显示"无告警"
      done('<p style="color:#ef4444;font-size:12px;margin:0">读取反作弊配置失败：' + esc(r.error) + '</p>' +
        hintHtml('此时无法判定是否违禁。旧版这里是"永远显示空告警"，请勿把这种情况当成"没有问题"。'))
      return
    }
    var index = configItemIndex(r.config)
    var hitIds = []
    for (var i = 0; i < grouped.ids.length; i++) {
      var id = grouped.ids[i]
      if (index[id]) hitIds.push(id)
    }

    if (!hitIds.length) {
      done('<p class="ac-muted" style="font-size:12px;margin:0">未发现违禁物品告警</p>' +
        hintHtml('判定依据：背包里共 ' + esc(grouped.filled) + ' 格物品，其中没有任何一件出现在物品违禁清单里。' +
          '（旧版这一栏**永远**是空的，因为它读的字段名根本不存在，见本文件头部说明。）' +
          '<br>要调整清单请到「服务器设置 → <a href="#/s/anticheat-item">物品违禁</a>」。'))
      return
    }

    var sid = currentServerId()
    var toCheck = hitIds.slice(0, MAX_CHECK_IDS)
    var rest = hitIds.length - toCheck.length

    var qs = toCheck.map(function (id) {
      // reqTimed：宿主 api() 不透传 options.signal（plugins/web/public/app.js:236-240），
      // 不能用 AbortController 兜超时，只能用 Promise.race（见 shared/api.js:155-186）。
      // 超时会返回 { ok:false, status:0, error:'请求超时…' }，与其它失败同一条展示路径。
      return reqTimed(API.checkAnomaly + '?id=' + encodeURIComponent(String(id)) +
        '&stack=' + encodeURIComponent(String(grouped.byId[id].stack)) +
        (sid ? '&serverId=' + encodeURIComponent(sid) : ''), { method: 'GET' }, CHECK_TIMEOUT_MS)
        .then(function (res) { return { id: id, res: res } })
        .catch(function (err) { return { id: id, err: (err && err.message) || String(err) } })
    })

    Promise.all(qs).then(function (results) {
      if (cancelled) return
      var byId = {}
      var errors = []
      var serverName = ''
      var halfMissing = false
      for (var k = 0; k < results.length; k++) {
        var one = results[k]
        if (one.err) {
          errors.push('ID ' + one.id + '：' + one.err)
          continue
        }
        if (!one.res || !one.res.ok) {
          var msg = errText(one.res, '判定失败')
          if (one.res && one.res.data && one.res.data.serverHalfMissing) halfMissing = true
          errors.push('ID ' + one.id + '：' + msg)
          continue
        }
        var d = dataOf(one.res) || {}
        byId[one.id] = d
        if (d.serverName) serverName = String(d.serverName)
        if (d.serverHalfMissing) halfMissing = true
      }

      var anomalous = 0
      var html = '<div style="display:flex;flex-direction:column;gap:2px">'
      for (var m = 0; m < toCheck.length; m++) {
        var iid = toCheck[m]
        var chk = byId[iid] || null
        if (chk && chk.anomaly === true) anomalous += 1
        html += rowHtml(grouped.byId[iid], chk, index[iid])
      }
      html += '</div>'

      html = '<div style="margin-bottom:2px">' + kvHtml('违禁判定',
        anomalous > 0
          ? '<span class="ac-badge err">' + esc(anomalous) + ' 项违禁</span>'
          : '<span class="ac-badge ok">未发现违禁</span>') + '</div>' + html

      if (serverName) html += kvHtml('判定来源', esc(serverName + '（服端按当前世界进度判定）'))
      else if (!sid) html += kvHtml('判定来源', '<span class="ac-muted">未指定服务器</span>')

      if (halfMissing) {
        html += '<p style="color:#d97706;font-size:11.5px;margin:6px 0 0;line-height:1.7">' +
          '该游戏服未安装 AntiCheat.dll：无法给出世界进度相关的判定结果。</p>'
      }
      if (!sid && errors.length) {
        html += '<p style="color:#d97706;font-size:11.5px;margin:6px 0 0;line-height:1.7">' +
          '未确定目标服务器：请看板顶部选中一台服务器后重试（宿主要求多台启用服时显式指定，' +
          'plugins/anti-cheat/index.js:677-690）。</p>'
      }
      if (errors.length) {
        html += '<p style="color:#ef4444;font-size:11.5px;margin:6px 0 0;line-height:1.7">' +
          esc(errors.slice(0, 3).join('；')) + (errors.length > 3 ? ' …' : '') + '</p>'
      }
      if (rest > 0) {
        html += '<p class="ac-muted" style="font-size:11.5px;margin:6px 0 0;line-height:1.7">' +
          '另有 ' + esc(rest) + ' 项在清单里的物品未逐个判定（每次最多判定 ' + MAX_CHECK_IDS +
          ' 项，避免详情页打开时连续打游戏服）。</p>'
      }
      html += hintHtml('判定请求发往宿主 <span class="ac-mono">/api/anticheat/check-anomaly</span>，' +
        '由宿主转发给游戏服按**当前世界进度**计算，前端不自行推断档位是否生效。用户：' + esc(user || '-') + '。')

      done(html)
    })
  }, function (err) {
    // loadConfigCached 自己吞异常，这里只是双保险
    done('<p style="color:#ef4444;font-size:12px;margin:0">读取配置异常：' + esc((err && err.message) || err) + '</p>')
  })

  return function () {
    // 清理：详情页会被重建（改名/改密等操作后），上一轮的请求可能还在路上，
    // 用 cancelled 丢弃过期结果，避免旧角色的数据盖到新区块上（qq-bind 同款做法，
    // plugins/qq-bind/client/players-section.js:158-159 也是这个理由）
    cancelled = true
  }
}

/** 区块注册元信息（导出便于静态核对） */
export var SECTION_META = {
  id: 'anticheat-item-alert',
  title: '违禁物品告警',
  // order 60 与 qq-bind 同档：都排在默认 100 之前，落在右栏靠上位置
  // （base 按 order 升序渲染，plugins/base/client/players.js:430-432）
  order: 60,
}

var tsw = typeof window !== 'undefined' ? window.tsweb : null

if (tsw && typeof tsw.registerPlayerDetailSection === 'function') {
  try {
    tsw.registerPlayerDetailSection(Object.assign({}, SECTION_META, { render: renderAlertSection }))
    // 物品字典异步预热：名称与图标能显示得更完整（失败只降级为"只显示 ID"）
    loadItemDict()
  } catch (err) {
    console.warn('[anti-cheat] 注册玩家详情「违禁物品告警」区块失败：' + ((err && err.message) || err))
  }
}
