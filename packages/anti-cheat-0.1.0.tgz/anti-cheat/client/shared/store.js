/**
 * anti-cheat 前端半 —— 配置状态仓库（物品页与弹幕页**共用一份**）
 *
 * ══════════ 为什么必须共用，而不是各页各存一份 ══════════
 *
 * 【契约事实】宿主 `POST /api/anticheat/config` 是**整份替换**，不是局部更新：
 *   plugins/anti-cheat/index.js:720-737 把请求体直接交给 validateConfig，
 *   再 `service.setConfig(config)`；setConfig 第一句就是
 *   `const next = normalizeConfig(config).config`（index.js:531）→ 归一结果**就是**新配置。
 *   而 normalizeConfig 对缺失的一侧会回落默认（config.js:291-292 调 normalizeItem/normalizeProj，
 *   缺失即 `{...DEFAULT_SWITCHES, 限制列表: []}`，config.js:308/346）。
 *   ⇒ **只提交一侧，另一侧的清单与开关会被静默清空**。
 *   旧版不存在这个问题，因为旧版两侧是**两个独立文件 + 两个端点**（/item-config、/proj-config），
 *   前端各自只提交自己那一侧。
 *
 * 【因此本件的做法】前端持有一份**完整配置**（item + proj 都在），任何一侧保存都提交整份；
 *   由本模块统一持状态，两个页面通过它读写同一份数据。这同时解决了另一个旧版缺陷：
 *   旧版两个页面各自 mount 时重新拉配置，会把本地编辑静默覆盖（规格 B §3.6(g) I-2）。
 *
 * ══════════ 修掉的旧版缺陷 #2（静默丢编辑）══════════
 *   旧版拨「启用检测」会 `await` 重新拉配置并整体覆盖本地编辑、把脏标记归零
 *   （规格 B §3.6(g) I-2，引旧 ItemRestrictView.vue:408-411 与 :285-289）。
 *   本件的规则：
 *     - `loadConfig()` 在**有未保存修改时默认不覆盖**，只更新元信息（进度表/method 文案/宿主警告），
 *       并如实回一句"已保留你未保存的修改"；要覆盖必须显式 `{ force: true }`（界面上的
 *       「放弃修改并重新载入」按钮），或者先保存/放弃。
 *     - 保存成功后基线同步为宿主回的配置，脏标记归零（此时再拉取也不会有损失）。
 *   这与 status-panel 处理同类问题的思路一致（plugins/status-panel/client/status-panel.js:579-600
 *   的 `loaded` 标记 + `editSeq` 局部编辑序号）。
 *
 * ══════════ 另一个关键取舍：前端内部**直接持有宿主形态**（中文键）══════════
 *   旧版在两页各写一对 mapItemConfigToFrontend / mapItemConfigToBackend
 *   （规格 B §3.6(c) :554-570、§3.7 :631），把中文键映射成 camelCase 再映射回去，
 *   这一层正是旧版字段名事故的温床（同类的 UserDetailView 读 `config.items` 而真名是
 *   `限制列表[].限制物品[].stack`，导致"违禁告警永远为空"，规格 B §3.5）。
 *   本件**取消这层映射**：编辑器直接编辑 `{启用, 自动扫描, 扫描间隔, 没收违禁物品, 限制列表:[{进度,限制物品:[...]}]}`
 *   这些原始键，保存时原样 POST。少一层映射就少一类"字段名写错/空串落盘"（旧版 I-5）事故。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import { API, get, post, errText } from './api.js'

/** 条目数组的字段名（与 plugins/anti-cheat/config.js:169 的 ENTRY_KEY 同源同值） */
export var ENTRY_KEY = { item: '限制物品', proj: '限制弹幕' }

/** 单份清单的档位/条数上限（与 config.js:163-164 一致，用于界面提示而非拦截 —— 权威校验在宿主） */
export var MAX_TIERS = 64
export var MAX_ENTRIES_PER_TIER = 2000

function clone(v) {
  try {
    return JSON.parse(JSON.stringify(v))
  } catch (e) {
    return v
  }
}

/** 结构化相等（配置是纯 JSON 数据；用它算脏标记，避免漏判"改回来了"） */
function same(a, b) {
  return JSON.stringify(a) === JSON.stringify(b)
}

/** 一份空的完整配置（宿主没读到时的兜底；开关与 config.js:102-113 的默认一致） */
export function emptyConfig() {
  return {
    item: { 启用: false, 自动扫描: true, 扫描间隔: 10, 没收违禁物品: false, 限制列表: [] },
    proj: { 启用: false, 伤害上限: 20000, 限制列表: [] },
  }
}

/**
 * 仓库状态（模块级单例 —— 两个页面共用）。
 * 不使用任何响应式框架，页面在每次 render 时读这里并整体重绘。
 */
var state = {
  /** 是否成功从宿主读到过配置（没读到之前**绝不允许保存**，否则会拿空配置覆盖线上清单） */
  loaded: false,
  loading: false,
  saving: false,
  /** 当前编辑中的完整配置（宿主形态） */
  config: null,
  /** 与宿主一致的快照（脏标记的基准） */
  baseline: null,
  dirty: false,
  /** 读取失败的可读原因（页面必须渲染出来，供重试） */
  error: '',
  /** 保存失败的可读原因 */
  saveError: '',
  /** 最近一次操作的提示 { kind, text } */
  notice: null,
  /** 宿主在 config 接口里回的全部元信息 */
  meta: {
    configFile: '',
    configError: '',
    defaultsError: '',
    warnings: [],
    stats: null,
    progressOrder: [],
    knownProgress: [],
    defaults: null,
    dependencies: { itemData: false, projectileData: false },
    methodValues: [],
    methodLabels: {},
    quickCommands: [],
    commandPlaceholders: [],
  },
  /** 读取时间戳（用于界面显示"数据来自何时"） */
  loadedAt: 0,
}

/** 订阅者（页面注册的"数据变了请重绘"回调） */
var listeners = []

export function subscribe(fn) {
  if (typeof fn !== 'function') return function () {}
  listeners.push(fn)
  return function () {
    listeners = listeners.filter(function (f) { return f !== fn })
  }
}

function notify() {
  for (var i = 0; i < listeners.length; i++) {
    try {
      listeners[i]()
    } catch (err) {
      console.warn('[anti-cheat] 订阅回调异常：' + ((err && err.message) || err))
    }
  }
}

/** 读状态（页面渲染用；**不要**直接改返回对象里的字段，改配置请用 mutate） */
export function getState() {
  return state
}

/** 取某一侧配置（item/proj）；未载入时给空配置的那一侧，保证调用方不必判空 */
export function side(kind) {
  var cfg = state.config || emptyConfig()
  return cfg[kind] || emptyConfig()[kind]
}

/** 取某一侧的档位数组 */
export function tiers(kind) {
  var s = side(kind)
  return Array.isArray(s['限制列表']) ? s['限制列表'] : []
}

/** 编辑配置：fn 直接改 state.config，改完自动重算脏标记并通知订阅者 */
export function mutate(fn) {
  if (!state.config) state.config = emptyConfig()
  try {
    fn(state.config)
  } catch (err) {
    console.warn('[anti-cheat] 本地编辑异常：' + ((err && err.message) || err))
  }
  state.dirty = state.baseline ? !same(state.config, state.baseline) : true
  // 用户一动，上一次的提示就过期了（避免"保存成功"的绿条一直挂着误导人）
  if (state.notice && state.notice.kind !== 'error') state.notice = null
  notify()
}

/**
 * 静默编辑：只改数据与脏标记，**不**通知订阅者。
 *
 * 为什么需要：输入框的每一次按键都调 `mutate` 并触发整页重绘，会把正在输入的
 * input 元素换掉 → 光标丢失、中文输入法组字被打断。所以逐字符编辑走本函数，
 * 由页面自己用**局部刷新**（刷新保存栏、刷新该行的图标与名称）反映变化。
 * 旧版没有这个问题（Vue 的 v-model 是增量绑定），本件用原生 DOM 必须自己处理。
 */
export function mutateSilent(fn) {
  if (!state.config) state.config = emptyConfig()
  try {
    fn(state.config)
  } catch (err) {
    console.warn('[anti-cheat] 本地编辑异常：' + ((err && err.message) || err))
  }
  state.dirty = state.baseline ? !same(state.config, state.baseline) : true
  if (state.notice && state.notice.kind !== 'error') state.notice = null
}

/** 设提示（页面上的内联提示条） */
export function setNotice(kind, text) {
  state.notice = text ? { kind: kind, text: text } : null
  notify()
}

/**
 * 从宿主读配置。
 *
 * @param {{force?: boolean, silent?: boolean}} [opts]
 *   force  —— 即使有未保存修改也覆盖（界面上的"放弃修改并重新载入"）
 *   silent —— 不写提示条（页面首次挂载时用，避免每次进页面都弹一句）
 * @returns {Promise<{ok:boolean, kept:boolean, error:string}>}
 */
export async function loadConfig(opts) {
  var o = opts || {}
  if (state.loading) return { ok: false, kept: false, error: '正在载入中' }
  state.loading = true
  state.error = ''
  notify()

  var res = await get(API.config)
  state.loading = false

  if (!res.ok || !res.data || !res.data.config) {
    // 读不到就**明确失败**并保留已有状态：绝不拿默认配置顶上去（那会诱导管理员保存后清空线上清单）
    state.error = errText(res, '读取反作弊清单失败')
    notify()
    return { ok: false, kept: true, error: state.error }
  }

  var d = res.data
  // 元信息每次都更新（进度表 / method 文案 / 快捷命令 / 宿主警告 —— 它们不是"用户的编辑"）
  state.meta = {
    configFile: String(d.configFile || ''),
    configError: String(d.configError || ''),
    defaultsError: String(d.defaultsError || ''),
    warnings: Array.isArray(d.warnings) ? d.warnings.slice() : [],
    stats: d.stats || null,
    progressOrder: Array.isArray(d.progressOrder) ? d.progressOrder.slice() : [],
    knownProgress: Array.isArray(d.knownProgress) ? d.knownProgress.slice() : [],
    defaults: d.defaults || null,
    dependencies: d.dependencies || { itemData: false, projectileData: false },
    methodValues: Array.isArray(d.methodValues) ? d.methodValues.slice() : [],
    methodLabels: d.methodLabels && typeof d.methodLabels === 'object' ? Object.assign({}, d.methodLabels) : {},
    quickCommands: Array.isArray(d.quickCommands) ? d.quickCommands.slice() : [],
    commandPlaceholders: Array.isArray(d.commandPlaceholders) ? d.commandPlaceholders.slice() : [],
  }

  // ★ 核心保护：有未保存修改且未强制 → 不覆盖
  if (state.dirty && !o.force && state.config) {
    if (!o.silent) {
      setNotice('warn', '服务端配置已重新读取，但**你未保存的修改已保留**，没有被覆盖。要改用服务端版本请点「放弃修改并重新载入」。')
    } else {
      notify()
    }
    return { ok: true, kept: true, error: '' }
  }

  state.config = clone(d.config)
  state.baseline = clone(d.config)
  state.dirty = false
  state.saveError = ''
  state.loaded = true
  state.loadedAt = Date.now()
  if (state.meta.configError) {
    state.notice = { kind: 'error', text: '宿主读取配置文件时出错：' + state.meta.configError + '（当前显示的是宿主归一后的配置）' }
  }
  notify()
  return { ok: true, kept: false, error: '' }
}

/** 放弃本地修改，回到基线（不发请求；重新拉取请用 loadConfig({force:true})） */
export function discard() {
  if (!state.baseline) return
  state.config = clone(state.baseline)
  state.dirty = false
  state.saveError = ''
  setNotice('info', '已放弃未保存的修改。')
}

/**
 * 保存整份配置。
 *
 * 提交 `{ item, proj }` 两侧（见文件头的契约说明：宿主是整份替换，漏一侧就会清空它）。
 * 成功 → 基线同步为宿主回的配置（宿主已归一，可能与提交值有细微差别，比如自动补 `/`），
 * 脏标记归零；失败 → **保留脏标记**并如实显示原因（管理员可以改完再存）。
 */
export async function save() {
  if (!state.loaded || !state.config) {
    return { ok: false, error: '尚未成功读取配置，不能保存（避免用空清单覆盖线上配置）' }
  }
  if (state.saving) return { ok: false, error: '正在保存中' }
  state.saving = true
  state.saveError = ''
  notify()

  var payload = { item: clone(side('item')), proj: clone(side('proj')) }
  var res = await post(API.config, payload)
  state.saving = false

  if (!res.ok) {
    state.saveError = errText(res, '保存失败')
    notify()
    return { ok: false, error: state.saveError, errors: (res.data && res.data.errors) || [] }
  }

  var d = res.data || {}
  if (d.config) {
    state.config = clone(d.config)
    state.baseline = clone(d.config)
  } else {
    state.baseline = clone(state.config)
  }
  state.dirty = false
  state.meta.warnings = Array.isArray(d.warnings) ? d.warnings.slice() : state.meta.warnings
  state.notice = { kind: 'ok', text: '保存成功（已写盘并下发给游戏服）' + pushText(d.push) }
  notify()
  return { ok: true, error: '', warnings: state.meta.warnings, push: d.push }
}

/**
 * 把宿主的下发结果翻成一句人话。
 * 形状依据 plugins/anti-cheat/index.js:299-401 的 pushConfig 返回值：
 *   { ok, total, okCount, pendingCount, reason, results:[{id,name,ok,error,serverHalfMissing}] }
 */
export function pushText(push) {
  if (!push || typeof push !== 'object') return ''
  if (push.skipped) return '；本次未下发（' + (push.reason || '变更即推已关闭') + '）'
  var total = Number(push.total) || 0
  if (total === 0) return '；没有启用中的服务器可下发'
  var results = Array.isArray(push.results) ? push.results : []
  var bad = results.filter(function (r) { return r && r.ok !== true })
  var text = '；下发 ' + (Number(push.okCount) || 0) + '/' + total + ' 台成功'
  if (bad.length) {
    text += '，失败：' + bad.map(function (r) {
      var why = (r && r.error) ? String(r.error) : '未知原因'
      if (r && r.serverHalfMissing) why += '（该服未安装 AntiCheat.dll）'
      return ((r && (r.name || r.id)) || '未知服务器') + '（' + why + '）'
    }).join('；')
  }
  if (Number(push.pendingCount) || 0) text += '；仍有 ' + push.pendingCount + ' 台待确认'
  return text
}
