/**
 * anti-cheat 前端半 —— 进度档位模型（两页共用的唯一来源）
 *
 * ══════════ 为什么必须单独一个文件（这是本件要修的头号旧版缺陷）══════════
 * 旧版在**两个页面各写一份 19 档的硬编码数组**，保存时又**只遍历该数组**
 * （规格 B §3.6(d) :572-577 与 §3.7 :628；旧 ItemRestrictView.vue:147-167、ProjRestrictView.vue:138-158）：
 *   - 界面看不到任何"数组外的档位"；
 *   - 保存时那些档位被**静默删除**（规格 B §3.6(g) I-8、§6.8 坑 1）。
 *   → 只要管理员用旧版前端保存过一次，插件端已有的自定义档位就永久消失。
 *
 * 本件的改法（对应必改缺陷 #1）：
 *   1. 档位顺序**从宿主配置派生**，不再硬编码：宿主 GET /api/anticheat/config 回
 *      `progressOrder`（当前配置里档位的顺序，plugins/anti-cheat/index.js:703 源头 config.js:613）
 *      与 `knownProgress`（权威进度名全集，index.js:704 源 config.js:126-154 的 PROGRESS_ORDER）。
 *   2. **未知档位单独成卡并显式标注**，绝不隐藏：凡出现在配置里但不在 knownProgress 的档位，
 *      一律排在末尾、加橙色边框与「未知档位」徽标，并给出"服端对它恒判不生效"的说明
 *      （config.js:394-396 的归一警告正是这句话）。
 *   3. 保存时**原样保留**它们（见 shared/tier-editor.js 的 buildConfigPayload）。
 *
 * 硬编码的那份 PROGRESS_ORDER_FALLBACK 只在"宿主没回 knownProgress"时用（防宿主版本旧），
 * 且必须与 plugins/anti-cheat/config.js:126-154 逐字一致。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import { bossIconUrl, svg } from './api.js'

/** 「始终生效」档名（旧 GetWorldInfo.cs:275 的逐字字面量；config.js:157） */
export var ALWAYS_PROGRESS = '始终生效'

/**
 * Boss 立绘文件名映射。
 *
 * 逐字来自旧版 ItemRestrictView.vue:169-188 的 `bossImageMap`（18 项，本件已核对旧文件原文；
 * 旧 ProjRestrictView.vue:160-179 是同一份）。**「始终生效」没有映射** —— 旧版同样没有，
 * 那里的卡片用占位图形（旧版 :531-536 的占位 SVG），本件照旧。
 *
 * 路径变了：旧版是主包的 `/assets/img/Boss/<file>`（旧 :197-200），
 * 新宿主在 data-items 插件下（/plugins/data-items/client/img/Boss/<file>，见 shared/api.js 的 DATA）。
 */
export var BOSS_IMAGES = {
  '史莱姆王': 'King_Slime.png',
  '克苏鲁之眼': 'Eye_of_Cthulhu.png',
  '世界吞噬者': 'Eater_of_Worlds.webp',
  '克苏鲁之脑': 'Brain_of_Cthulhu.png',
  '蜂后': 'QueenBee.png',
  '骷髅王': 'Skeletron.png',
  '血肉墙': 'Wall_of_Flesh.png',
  '史莱姆皇后': 'Queen_Slime.png',
  '毁灭者': 'The_Destroyer.png',
  '机械骷髅王': 'Skeletron_Prime.png',
  '双子魔眼': 'The_Twins.png',
  '世纪之花': 'Plantera.png',
  '石巨人': 'Golem.png',
  '猪龙鱼公爵': 'Duke_Fishron.png',
  '光之女皇': 'Empress_of_Light.png',
  '拜月教教徒': 'Lunatic_Cultist.png',
  '月亮领主': 'Moon_Lord.png',
  '哥布林入侵': 'Goblin.webp',
}

/**
 * 权威进度名与顺序的兜底副本。
 * 逐字取自 plugins/anti-cheat/config.js:126-154 的 PROGRESS_ORDER（25 项）：
 *   前 19 项 = 旧版两页硬编码的那 19 档（旧版无「巨鹿」，它由本次按 BossProgress.BossOrder 插入），
 *   末 5 项 = 旧 GetWorldInfo.cs:35-43 的 EventNames 里未进默认清单的事件名。
 */
export var PROGRESS_ORDER_FALLBACK = [
  '始终生效',
  '哥布林入侵',
  '史莱姆王',
  '克苏鲁之眼',
  '世界吞噬者',
  '克苏鲁之脑',
  '蜂后',
  '巨鹿',
  '骷髅王',
  '血肉墙',
  '史莱姆皇后',
  '毁灭者',
  '双子魔眼',
  '机械骷髅王',
  '世纪之花',
  '石巨人',
  '猪龙鱼公爵',
  '光之女皇',
  '拜月教教徒',
  '月亮领主',
  '海盗入侵',
  '火星人入侵',
  '日食',
  '冰雪女王',
  '南瓜王',
]

/**
 * 宿主下发的权威进度名全集（缺字段时用兜底副本）。
 *
 * 保证「始终生效」一定在列表里：它是唯一**不依赖世界进度**的档位
 * （服端对它的判定是"恒成立"，旧 bossImageMap 也刻意没给它映射），
 * 一旦它不在列表里，界面上就再也表达不出"对所有进度都生效的规则"——
 * 那属于静默丢能力。宿主版本较旧、回了个不含它的 knownProgress 时，这里补齐。
 */
export function knownProgressOf(meta) {
  var k = meta && meta.knownProgress
  var list = (Array.isArray(k) && k.length) ? k.slice() : PROGRESS_ORDER_FALLBACK.slice()
  if (list.indexOf(ALWAYS_PROGRESS) < 0) list.unshift(ALWAYS_PROGRESS)
  return list
}

/** 进度名 → Boss 立绘 URL（无映射给空串，调用方用占位图形） */
export function progressImageUrl(name) {
  var file = BOSS_IMAGES[String(name || '')]
  return file ? bossIconUrl(file) : ''
}

/**
 * 档位卡左侧的占位图形（旧版「始终生效」与未知档用占位 SVG，旧 ItemRestrictView.vue:531-536）。
 * 纯几何图形，不是 emoji。
 */
export function progressPlaceholderSvg() {
  return svg('<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 12h8"/><path d="M12 8v8"/>', 20)
}

/**
 * 把「宿主配置里的档位」与「权威进度名全集」合成界面要渲染的档位列表。
 *
 * 顺序（保证旧版视觉顺序不变，同时不隐藏任何东西）：
 *   1) knownProgress 全量，按它的顺序 —— 旧版 19 档的相对顺序与它一致，所以观感与旧版相同，
 *      只是多出「巨鹿」与 5 个事件档（宿主本来就认这些名字，旧前端无法选是旧版的缺陷）。
 *   2) 配置里存在、但不在 knownProgress 的**未知档位**，按配置顺序排在最后。
 *
 * @param {Array} configTiers 配置里的 限制列表（[{进度, 限制物品|限制弹幕: [...]}]）
 * @param {object} meta       宿主的 { knownProgress, progressOrder }
 * @param {string} entryKey   条目字段名（物品侧「限制物品」、弹幕侧「限制弹幕」）
 * @returns {Array<{进度:string, entries:Array, known:boolean, inConfig:boolean}>}
 */
export function buildTierList(configTiers, meta, entryKey) {
  var tiers = Array.isArray(configTiers) ? configTiers : []
  var byName = {}
  var order = []
  for (var i = 0; i < tiers.length; i++) {
    var t = tiers[i] || {}
    var name = String(t.进度 == null ? '' : t.进度)
    if (name === '') continue
    if (!Object.prototype.hasOwnProperty.call(byName, name)) {
      byName[name] = { name: name, entries: [], index: order.length }
      order.push(name)
    }
    var list = Array.isArray(t[entryKey]) ? t[entryKey] : []
    for (var j = 0; j < list.length; j++) byName[name].entries.push(list[j])
  }

  var known = knownProgressOf(meta)
  var knownSet = {}
  for (var k = 0; k < known.length; k++) knownSet[known[k]] = true

  var out = []
  var seen = {}
  for (var a = 0; a < known.length; a++) {
    var nm = String(known[a])
    if (seen[nm]) continue
    seen[nm] = true
    var hit = Object.prototype.hasOwnProperty.call(byName, nm) ? byName[nm] : null
    out.push({
      进度: nm,
      entries: hit ? hit.entries : [],
      known: true,
      inConfig: Boolean(hit),
    })
  }
  // 未知档位：原样保留（绝不隐藏、绝不丢弃）
  for (var b = 0; b < order.length; b++) {
    var un = order[b]
    if (knownSet[un]) continue
    out.push({ 进度: un, entries: byName[un].entries, known: false, inConfig: true })
  }
  return out
}

/**
 * 统计一个档位列表里的条目总数（卡片上的「N 条限制」）。
 * 旧版文案：`{{ N }} 条限制`（规格 B §3.6(b) :532 引旧 ItemRestrictView.vue:541）。
 */
export function countEntries(tiers) {
  var n = 0
  var list = Array.isArray(tiers) ? tiers : []
  for (var i = 0; i < list.length; i++) {
    var e = list[i] && list[i].entries
    n += Array.isArray(e) ? e.length : 0
  }
  return n
}

/** 配置里一共有几个档位有内容（用作"当前清单规模"的摘要） */
export function countTiersWithEntries(tiers) {
  var list = Array.isArray(tiers) ? tiers : []
  var n = 0
  for (var i = 0; i < list.length; i++) {
    if (list[i] && Array.isArray(list[i].entries) && list[i].entries.length > 0) n++
  }
  return n
}
