/**
 * anti-cheat 前端半 —— 处置方式（method）模型
 *
 * 单一来源：本模块是**前端唯一**的 method 值域 / 文案 / 颜色定义处。
 * 旧版把 method 文案与颜色各写一份（规格 B §3.6 I-13「getMethodLabel / getMethodColor 是死代码」，
 * 物品页 :338-352、弹幕页 :295-309 各一份，且都无人调用）；本件抽到这里，两页共用。
 *
 * 值域**不硬编码**：优先用宿主 GET /api/anticheat/config 回的 `methodValues`
 * （plugins/anti-cheat/index.js:712，源头是 config.js:59 的 METHOD_VALUES 闭集）。
 * 硬编码的那份只是"宿主没给时的兜底"，且必须与 config.js:59 一致。
 *
 * ★ 为什么是 5 个按钮而不是旧版的 4 个（有意差异，理由）：
 *   host 的闭集是 ['log','kick','ban','drop','command']（config.js:59），比旧版多一个 `drop`
 *   （config.js:48-51 明确保留：语义=只阻断不处置，物品丢出/存箱与弹幕阻断天然有这个档）。
 *   旧版前端只有 4 个按钮，任何 `drop` 档在界面上**无法表达**——一旦配置里存在 drop，
 *   界面会把它显示成"都没选中"，保存时又被写回原值，管理员看到的与实际生效的不一致。
 *   本件按宿主闭集渲染全部按钮，等于把"界面能表达的集合"与"数据能存的集合"对齐，
 *   属于修「静默丢/静默改」同类缺陷，而不是新增功能。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */

/** 宿主没回 methodValues 时的兜底（必须与 plugins/anti-cheat/config.js:59 逐字一致） */
export var METHOD_VALUES_FALLBACK = ['log', 'kick', 'ban', 'drop', 'command']

/**
 * 处置方式的中文说明（按钮 title）。
 * 兜底值逐字取自 plugins/anti-cheat/config.js:62-68 的 METHOD_LABELS
 * （注释里写明它同源于旧 item-restrict.cs:151-157）。
 */
export var METHOD_LABELS_FALLBACK = {
  log: '仅记录日志',
  kick: '踢出玩家',
  ban: '封禁玩家',
  drop: '仅阻断（不踢不封）',
  command: '执行自定义命令',
}

/**
 * 按钮上的**短**文案。旧版四按钮逐字为 记录 / 踢出 / 封禁 / 命令
 * （规格 B §3.6(b) :537-540，出自旧 ItemRestrictView.vue:613/627/641/654）。
 * `drop` 旧版无按钮，短文案取「阻断」（title 用 host 的完整说明）。
 */
export var METHOD_SHORT_LABELS = {
  log: '记录',
  kick: '踢出',
  ban: '封禁',
  drop: '阻断',
  command: '命令',
}

/**
 * 按钮选中态颜色（旧版逐字：ban=#ef4444、kick=#f97316、log=#eab308、custom=#8b5cf6，
 * 见规格 B §3.6(e) :590 引旧 ItemRestrictView.vue:746-749）。`drop` 旧版没有，
 * 取中性石板色 #64748b（与日志页"其它处理方式"的兜底色一致，规格 B §3.3(b) :403）。
 */
export var METHOD_COLORS = {
  log: '#eab308',
  kick: '#f97316',
  ban: '#ef4444',
  drop: '#64748b',
  command: '#8b5cf6',
}

/** 取按钮短文案（未知值原样回显，不吞） */
export function methodShort(m) {
  var k = String(m || '')
  return METHOD_SHORT_LABELS[k] || k || '未设置'
}

/** 取按钮 title（未知值回显原文，便于发现脏数据） */
export function methodLabel(m, labels) {
  var k = String(m || '')
  var table = labels && typeof labels === 'object' ? labels : METHOD_LABELS_FALLBACK
  return table[k] || ('未知处置方式：' + k)
}

/** 取按钮颜色（未知值给中性色） */
export function methodColor(m) {
  return METHOD_COLORS[String(m || '')] || '#64748b'
}

/**
 * 物品侧快捷命令模板。
 *
 * 直接用**宿主下发的**那份（plugins/anti-cheat/index.js:714 回 `quickCommands`，
 * 源头 config.js:78-83 的 QUICK_COMMANDS）——它逐字等于旧版 ItemRestrictView.vue:190-195
 * 的 4 条（本件已逐字核对过旧文件），所以不需要在前端再抄一份。
 * host 尚未回该字段时用这里的最小兜底（同源，仅防"宿主版本旧"）。
 */
export var QUICK_COMMANDS_FALLBACK = [
  { method: 'ban', label: '封禁玩家', template: '/banp "{playername}" "违规使用{itemname}"' },
  { method: 'kick', label: '踢出玩家', template: '/kick "{playername}" "违规使用{itemname}"' },
  { method: 'log', label: '广播公告', template: '/bc "{playername}违规使用{itemname}"' },
  { method: 'command', label: '清除物品', template: '/remove {playername} {itemid}' },
]

/**
 * 弹幕侧快捷命令：旧版只有 3 条（少 `/remove`），且占位符是 `{projid}` 而不是 `{itemname}`
 * （规格 B §3.7 :630 逐字，出自旧 ProjRestrictView.vue:181-185）：
 *   `/banp "{playername}" "违规使用{projid}"`、`/kick "{playername}" "违规使用{projid}"`、
 *   `/bc "{playername}违规使用{projid}"`
 *
 * 本件**从宿主下发的模板派生**，而不是再抄第三份：
 *   取模板里含 `{itemname}` 的项（即 ban/kick/log 三条），把 `{itemname}` 换成 `{projid}`；
 *   含 `{itemid}` 的 `/remove` 条被自然排除（弹幕侧没有"清除物品"语义）。
 *   这样宿主改模板时前端自动跟随，也不会出现"两处模板不同步"。
 */
export function projQuickCommands(quickCommands) {
  var list = Array.isArray(quickCommands) && quickCommands.length ? quickCommands : QUICK_COMMANDS_FALLBACK
  var out = []
  for (var i = 0; i < list.length; i++) {
    var c = list[i] || {}
    var tpl = String(c.template || '')
    if (tpl.indexOf('{itemname}') < 0) continue
    out.push({
      method: String(c.method || 'log'),
      label: String(c.label || ''),
      template: tpl.split('{itemname}').join('{projid}'),
    })
  }
  return out
}

/**
 * 自定义命令输入框下方的占位符提示（旧版 item 页逐字
 * `支持 {playername}、{itemname}、{itemid} 转义`，规格 B §3.6(b) :541；
 * 弹幕页逐字 `支持 {playername}、{projid} 转义`，§3.7 :627）。
 *
 * 从宿主下发的 `commandPlaceholders`（index.js:715，源头 config.js:71 的 4 个）里按页过滤派生：
 * item 侧取 {playername}/{itemname}/{itemid}，proj 侧取 {playername}/{projid}。
 */
export function placeholderHint(kind, placeholders) {
  var all = Array.isArray(placeholders) && placeholders.length
    ? placeholders
    : ['{playername}', '{itemname}', '{itemid}', '{projid}']
  var wanted = kind === 'proj' ? ['{playername}', '{projid}'] : ['{playername}', '{itemname}', '{itemid}']
  var picked = all.filter(function (p) { return wanted.indexOf(String(p)) >= 0 })
  return '支持 ' + picked.join('、') + ' 转义'
}

/**
 * method 的四个标准档判定（旧版 `isQuickMethod`：['ban','kick','log'].includes(method)，
 * 规格 B §3.6(e) :589 引旧 ItemRestrictView.vue:334-336）。
 *
 * 本件把它改成"是不是闭集里的标准档"：闭集里**除 command 外的都算标准档**。
 * 这样 `drop` 不会被误判成自定义命令模板（旧版正是靠"非 log/kick/ban 即当命令执行"，
 * 酿成 D-34 的任意命令执行面；config.js:216-246 已把这条收敛掉，前端必须跟着收敛）。
 */
export function isStandardMethod(m, values) {
  var list = Array.isArray(values) && values.length ? values : METHOD_VALUES_FALLBACK
  var k = String(m || '')
  return k !== '' && k !== 'command' && list.indexOf(k) >= 0
}

/** 一条违禁记录的空初值（与 plugins/anti-cheat/config.js:204-211 的默认一致） */
export function defaultEntry(kind) {
  if (kind === 'proj') return { id: 0, method: 'log', command: '' }
  return { id: 0, stack: 1, method: 'log', command: '' }
}
