/**
 * anti-cheat 前端半 —— 物品 / 弹幕选择器（替代旧版 ItemSearchDialog.vue 与 ProjectileSearchDialog.vue）
 *
 * ══════════ 为什么合成一个模块 ══════════
 * 旧版两个对话框近乎逐字重复（同款 props/emits/网格/多选/扫描结果），差异只有三处：
 * 数据源（物品 ID.json vs 弹幕 ProjectileData.json）、有没有 `stack`、图标路径
 * （旧 ItemSearchDialog.vue:167-169 用数据里的 image、ItemRestrictView.vue:209-215 用硬编码路径
 *  —— 规格 B §3.7 P-9 指出这两套逻辑"当前等价但脆弱"）。本件按 `kind` 参数化，一份实现。
 *
 * ══════════ 修掉的旧版缺陷 ══════════
 *   1. **禁 emoji**：旧 ItemSearchDialog.vue:442 的错误提示用了 emoji 叉号（U+274C，规格 B
 *      §3.10 X-6 逐字点名）。本件改成内联 SVG + 文本，客户端全部文件都不含 emoji
 *      （连注释里也不写该字符，免得被逐文件扫描当成违规）。
 *   2. **图标路径**：旧版从主包 `/ID.json`、`/assets/img/...` 取（旧 itemDataApi.js:9、
 *      ItemRestrictView.vue:209-215），新宿主已不持有这些资源 → 本件走
 *      `/plugins/data-items/client/...`、`/plugins/data-projectiles/client/...`
 *      （规格 B §6.3 结论 4、§6.8 坑 5）。**照抄旧路径会满屏破图。**
 *   3. **不再外链 wiki 图片**：旧版图标失败时回退 `https://terraria.wiki.gg/images/<english>.png`
 *      （旧 ItemRestrictView.vue:202-207）。本项目要求"无外部 CDN"，且该域名在离线/墙内环境
 *      会长时间挂住，所以本件改为**占位方块**（`?`）。有意差异，已在交付报告里记明。
 *   4. **模组弹幕不可选**（规格 B §3.7 P-6）：旧版 ProjectileSearchDialog 的 numericList 过滤
 *      `typeof p.id === 'number'`，20 条 `m1001`–`m1020` 在界面上完全不可选、且无任何提示。
 *      本件把非数字 ID **单独列出并明确标注"宿主的清单只接受数字 ID，此项不可加入"**，
 *      而不是让它静默消失（属于"静默丢"同类问题）。
 *   5. **I-11（成功动画与实际结果不符）**：本件把选择结果交给调用方 `onPick`，
 *      由它返回 `{ok, added, error}`，对话框**据实**显示成功条数或失败原因。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import {
  esc, svg, ICON, itemNameOf, projNameOf, itemIconUrl, projIconUrl,
  loadItemDict, loadProjDict, itemDictNow, projDictNow, API, get, errText, currentServerId,
  noticeHtml, bindImageFallback,
} from './api.js'

/** 结果列表最多渲染多少张卡（字典有 6000+ 条，全量渲染会卡住浏览器） */
export var MAX_RESULTS = 120

/** 把物品字典（{id: {...}}）摊平成可搜索数组 */
export function itemEntries() {
  var dict = itemDictNow()
  var out = []
  var keys = Object.keys(dict)
  for (var i = 0; i < keys.length; i++) {
    var info = dict[keys[i]] || {}
    out.push({
      id: Number(keys[i]),
      rawId: keys[i],
      chinese: String(info.chinese || ''),
      english: String(info.english || ''),
      internal: String(info.internal || ''),
      numeric: true,
    })
  }
  return out
}

/** 把弹幕字典摊平成可搜索数组（保留非数字 ID，见文件头第 4 条） */
export function projEntries() {
  var d = projDictNow()
  var out = []
  var dict = d.dict || {}
  var keys = Object.keys(dict)
  for (var i = 0; i < keys.length; i++) {
    var info = dict[keys[i]] || {}
    var raw = String(keys[i])
    out.push({
      id: Number(raw),
      rawId: raw,
      chinese: String(info.chinese || ''),
      english: String(info.english || ''),
      internal: String(info.internal || ''),
      image: info.image ? String(info.image) : '',
      numeric: /^-?\d+$/.test(raw),
    })
  }
  return out
}

/**
 * 搜索（旧版按名称/ID 搜索；本件的判据，已按其交互习惯对齐）：
 *   - 查询是**纯数字** → 优先 ID 精确命中，其次 ID 前缀/子串命中；
 *   - 其余 → 中文名 / 英文名 / 内部名的大小写不敏感**子串**命中。
 * 命中的条目按"精确优先、ID 升序"排序，便于大字典里快速定位。
 */
export function searchEntries(entries, query) {
  var q = String(query == null ? '' : query).trim()
  var list = Array.isArray(entries) ? entries : []
  if (q === '') {
    return { rows: list.slice(0, MAX_RESULTS), total: list.length, truncated: list.length > MAX_RESULTS }
  }
  var lower = q.toLowerCase()
  var isNum = /^\d+$/.test(q)
  var hit = []
  for (var i = 0; i < list.length; i++) {
    var e = list[i]
    var score = -1
    if (isNum && String(e.rawId) === q) score = 0
    else if (isNum && String(e.rawId).indexOf(q) === 0) score = 1
    else if (isNum && String(e.rawId).indexOf(q) > 0) score = 2
    else if (e.chinese.toLowerCase().indexOf(lower) >= 0) score = 3
    else if (e.english.toLowerCase().indexOf(lower) >= 0) score = 4
    else if (e.internal.toLowerCase().indexOf(lower) >= 0) score = 5
    if (score >= 0) hit.push({ e: e, score: score })
  }
  hit.sort(function (a, b) {
    if (a.score !== b.score) return a.score - b.score
    return Number(a.e.id || 0) - Number(b.e.id || 0)
  })
  return {
    rows: hit.slice(0, MAX_RESULTS).map(function (x) { return x.e }),
    total: hit.length,
    truncated: hit.length > MAX_RESULTS,
  }
}

/** 一条结果的显示名 */
function nameOfEntry(kind, e) {
  return e.chinese || e.english || e.internal || (kind === 'item' ? '未知物品' : '未知弹幕')
}

/** 一条结果的图标 URL（非数字 ID 无图标） */
function iconOfEntry(kind, e) {
  if (!e.numeric) return ''
  return kind === 'item' ? itemIconUrl(e.id) : projIconUrl(e.id)
}

/**
 * 打开选择器对话框。
 *
 * @param {object} cfg
 *   kind            'item' | 'proj'
 *   mode            'add'（多选加入档位）| 'entry'（单选覆盖某行）| 'browse'（浏览）| 'holders'（查持有者）
 *   multi           是否多选
 *   tiers           可选档位名数组（'add'/'browse' 用）
 *   defaultProgress 默认选中的档位
 *   onPick(picked, progress) → { ok, added, error }  由调用方执行真正的写入并**据实回报**
 *   onClose()       关闭回调
 * @returns {{close:function():void, el:HTMLElement}}
 */
export function openSearchDialog(cfg) {
  var kind = cfg.kind === 'proj' ? 'proj' : 'item'
  var mode = cfg.mode || 'add'
  var multi = cfg.multi === true
  var onPick = typeof cfg.onPick === 'function' ? cfg.onPick : function () { return { ok: true, added: 0 } }
  var onClose = typeof cfg.onClose === 'function' ? cfg.onClose : function () { }

  var state = {
    query: '',
    rows: [],
    total: 0,
    truncated: false,
    selected: {},        // rawId -> entry
    loadingDict: true,
    dictError: '',
    progress: String(cfg.defaultProgress || (cfg.tiers && cfg.tiers[0]) || ''),
    // holders 模式
    holderId: '',
    holders: null,
    holderLoading: false,
    holderError: '',
    // 上次提交结果（据实显示）
    lastResult: null,
  }

  // 遮罩与对话框**用 DOM API 建**，不靠"设置 innerHTML 再取 firstChild"：
  // 后者依赖 HTML 解析出的第一个节点正好是我们想要的那个元素（字符串一旦有前导空白就变成文本节点，
  // 整个对话框会直接失效），本机没有浏览器，这类脆弱点必须自己先掐掉。
  var overlay = document.createElement('div')
  overlay.className = 'ac-overlay'
  overlay.setAttribute('data-ac-dialog', kind)
  var modal = document.createElement('div')
  modal.className = 'ac-modal'
  modal.setAttribute('role', 'dialog')
  modal.setAttribute('aria-label', kind === 'item' ? '搜索物品' : '搜索弹幕')
  overlay.appendChild(modal)
  document.body.appendChild(overlay)

  function entriesOf() {
    return kind === 'item' ? itemEntries() : projEntries()
  }

  function refreshRows() {
    var r = searchEntries(entriesOf(), state.query)
    state.rows = r.rows
    state.total = r.total
    state.truncated = r.truncated
  }

  function selectedCount() {
    return Object.keys(state.selected).length
  }

  function bodyHtml() {
    var title = mode === 'holders'
      ? '按' + (kind === 'item' ? '物品' : '弹幕') + '查持有者'
      : (kind === 'item' ? '搜索物品' : '搜索弹幕')
    var html = '<div class="ac-modal-head"><strong>' + esc(title) + '</strong>' +
      '<button type="button" class="ac-btn mini" data-dlg="close" title="关闭">✕</button></div>'

    html += '<div class="ac-modal-body">'

    if (mode === 'holders') {
      html += '<div class="ac-row"><span class="ac-label">' + (kind === 'item' ? '物品ID' : '弹幕ID') + '</span>' +
        '<input class="ac-input ac-num" type="number" min="1" step="1" data-dlg="holder-id" value="' + esc(state.holderId) + '" placeholder="' + (kind === 'item' ? '物品ID' : '弹幕ID') + '">' +
        '<button type="button" class="ac-btn accent" data-dlg="holder-run"' + (state.holderLoading ? ' disabled' : '') + '>' +
        svg(ICON.search, 13) + (state.holderLoading ? '查询中...' : '查询') + '</button></div>'
      if (state.holderError) html += noticeHtml('error', state.holderError)
      if (state.holders) {
        var hs = state.holders
        html += '<div class="ac-scan"><div class="ac-muted">扫描 ' + esc(hs.scannedPlayers || 0) +
          ' 名在线玩家，命中 ' + esc(hs.count || (Array.isArray(hs.players) ? hs.players.length : 0)) + ' 处' +
          (hs.durationMs ? '，耗时 ' + esc(hs.durationMs) + 'ms' : '') +
          (hs.serverName ? '；目标服务器：' + esc(hs.serverName) : '') + '</div>'
        var players = Array.isArray(hs.players) ? hs.players : []
        if (!players.length) {
          html += '<div class="ac-empty">没有任何在线玩家持有它</div>'
        } else {
          html += '<table class="ac-table" style="margin-top:6px"><thead><tr>' +
            '<th>玩家</th><th>数量</th><th>上限</th><th>处置</th></tr></thead><tbody>'
          for (var i = 0; i < players.length; i++) {
            var p = players[i] || {}
            html += '<tr><td>' + esc(p.name || '-') + '</td><td>' + esc(p.stack) + '</td><td>' + esc(p.allowedStack) +
              '</td><td>' + esc(p.method || '-') + '</td></tr>'
          }
          html += '</tbody></table>'
        }
        html += '</div>'
      } else if (!state.holderLoading && !state.holderError) {
        html += '<div class="ac-empty">填入 ID 后点「查询」：这是纯查询动作（宿主 /api/anticheat/scan-by-id），不会处置任何玩家。</div>'
      }
      html += '</div>'
      html += '<div class="ac-modal-foot"><span class="ac-muted" style="font-size:11.5px">该动作只查询，不修改配置</span>' +
        '<button type="button" class="ac-btn" data-dlg="close">关闭</button></div>'
      return html
    }

    // 搜索模式：查询框 + 档位选择 + 结果网格
    html += '<div class="ac-row">' +
      '<input class="ac-input ac-input-wide" type="search" data-dlg="query" value="' + esc(state.query) + '" ' +
      'placeholder="按名称或 ID 搜索（例如 天顶剑 或 3063）">'
    if (mode === 'add' || mode === 'browse') {
      var tiers = Array.isArray(cfg.tiers) ? cfg.tiers : []
      html += '<span class="ac-label" style="min-width:auto">加入档位</span>'
      html += '<select class="ac-select" data-dlg="progress">' + tiers.map(function (t) {
        return '<option value="' + esc(t) + '"' + (String(t) === state.progress ? ' selected' : '') + '>' + esc(t) + '</option>'
      }).join('') + '</select>'
    }
    html += '</div>'

    if (state.loadingDict) html += '<div class="ac-muted">字典载入中...</div>'
    if (state.dictError) html += noticeHtml('warn', state.dictError)

    html += '<div class="ac-muted" style="font-size:11.5px;margin:6px 0">命中 ' + state.total + ' 条' +
      (state.truncated ? '（结果过多，只显示前 ' + MAX_RESULTS + ' 条，请细化搜索）' : '') +
      (multi ? '；可多选' : '；点一张卡即选定') + '</div>'

    if (!state.loadingDict && state.rows.length === 0) {
      html += '<div class="ac-empty">' + (state.query ? '没有匹配的条目' : '输入名称或 ID 开始搜索') + '</div>'
    }

    html += '<div class="ac-cards">'
    for (var k = 0; k < state.rows.length; k++) {
      var e = state.rows[k]
      var sel = Boolean(state.selected[e.rawId])
      var icon = iconOfEntry(kind, e)
      html += '<button type="button" class="ac-icard' + (sel ? ' sel' : '') + '" data-dlg="pick" data-raw="' + esc(e.rawId) + '"' +
        (e.numeric ? '' : ' title="模组/非数字 ID：宿主的清单只接受数字 ID（1-65535），该项不可加入"') + '>'
      html += icon
        ? '<img src="' + esc(icon) + '" alt="" loading="lazy">'
        : '<span class="ac-icon-ph">?</span>'
      html += '<span class="n">' + esc(nameOfEntry(kind, e)) + '</span>'
      html += '<span class="i">' + esc(e.rawId) + (e.numeric ? '' : '（不可加入）') + '</span>'
      html += '</button>'
    }
    html += '</div>'
    if (state.lastResult) {
      html += state.lastResult.ok
        ? noticeHtml('ok', '已加入 ' + state.lastResult.added + ' 条' +
          (state.lastResult.skipped ? '，跳过 ' + state.lastResult.skipped + ' 条（重复或 ID 非法）' : ''))
        : noticeHtml('error', state.lastResult.error || '加入失败')
    }
    html += '</div>'

    html += '<div class="ac-modal-foot"><span class="ac-muted" style="font-size:11.5px">已选 ' + selectedCount() + ' 条</span>' +
      '<span class="ac-btn-group">'
    if (kind === 'item') {
      html += '<button type="button" class="ac-btn" data-dlg="to-holders">按物品查持有者</button>'
    }
    html += '<button type="button" class="ac-btn" data-dlg="close">取消</button>'
    html += '<button type="button" class="ac-btn accent" data-dlg="confirm"' + (selectedCount() ? '' : ' disabled') + '>' +
      (mode === 'entry' ? '选定' : '加入档位') + '</button>'
    html += '</span></div>'
    return html
  }

  function render() {
    modal.innerHTML = bodyHtml()
    bindImageFallback(modal)   // 图标缺失 → 占位块，不留破图（旧版 I-10/P-7 的同类问题）
    var q = modal.querySelector('[data-dlg="query"]')
    if (q) {
      q.focus()
      try { q.setSelectionRange(q.value.length, q.value.length) } catch (e) { /* 某些类型不支持 */ }
    }
  }

  function close() {
    document.removeEventListener('keydown', onKey, true)
    overlay.removeEventListener('click', onClick)
    overlay.removeEventListener('input', onInput)
    overlay.removeEventListener('change', onChange)
    if (overlay.parentNode) overlay.parentNode.removeChild(overlay)
    onClose()
  }

  function onKey(ev) {
    if (ev.key === 'Escape') {
      ev.stopPropagation()
      close()
    }
  }

  function onClick(ev) {
    var el = ev.target && typeof ev.target.closest === 'function' ? ev.target.closest('[data-dlg]') : null
    if (!el) {
      if (ev.target === overlay) close()   // 点遮罩关闭
      return
    }
    var act = el.getAttribute('data-dlg')
    if (act === 'close') return close()

    if (act === 'pick') {
      var raw = String(el.getAttribute('data-raw') || '')
      var all = entriesOf()
      var found = null
      for (var i = 0; i < all.length; i++) {
        if (String(all[i].rawId) === raw) { found = all[i]; break }
      }
      if (!found) return
      if (!found.numeric) {
        // 非数字 ID（模组弹幕）：明确报错而不是静默忽略（旧版 P-6 是"完全不可选且无提示"）
        state.lastResult = { ok: false, error: '该条目 ID 是「' + found.rawId + '」，宿主的清单只接受数字 ID（1-65535），无法加入。' }
        return render()
      }
      if (multi) {
        if (state.selected[raw]) delete state.selected[raw]
        else state.selected[raw] = found
        state.lastResult = null
        return render()
      }
      // 单选：直接选定
      state.selected = {}
      state.selected[raw] = found
      return submit()
    }

    if (act === 'confirm') return submit()

    if (act === 'to-holders') {
      mode = 'holders'
      var first = Object.keys(state.selected)[0]
      state.holderId = first ? String(state.selected[first].id) : state.holderId
      return render()
    }

    if (act === 'holder-run') {
      return runHolders()
    }
  }

  function submit() {
    var picked = Object.keys(state.selected).map(function (k) { return state.selected[k] })
    var r = onPick(picked, state.progress)
    if (r && r.ok) {
      state.lastResult = { ok: true, added: r.added || 0, skipped: r.skipped || 0 }
      state.selected = {}
      // 单选模式（'entry'/'browse'）完成即关；多选保留对话框让管理员继续加
      if (!multi) return close()
      return render()
    }
    state.lastResult = { ok: false, error: (r && r.error) || '加入失败' }
    return render()
  }

  async function runHolders() {
    var id = Number(state.holderId)
    if (!Number.isInteger(id) || id <= 0) {
      state.holderError = '请填入有效的 ID（正整数）'
      return render()
    }
    state.holderLoading = true
    state.holderError = ''
    state.holders = null
    render()
    var sid = currentServerId()
    var path = API.scanById + '?itemId=' + encodeURIComponent(String(id)) + (sid ? '&serverId=' + encodeURIComponent(sid) : '')
    var res = await get(path)
    state.holderLoading = false
    if (!res.ok) {
      state.holderError = errText(res, '查询失败')
    } else {
      state.holders = res.data || {}
    }
    render()
  }

  function onInput(ev) {
    var el = ev.target
    if (!el || typeof el.getAttribute !== 'function') return
    var act = el.getAttribute('data-dlg')
    if (act === 'query') {
      state.query = el.value
      refreshRows()
      // 只重绘结果区会打断输入焦点，所以这里只更新网格与计数（保留输入框节点）
      modal.innerHTML = bodyHtml()
      var q = modal.querySelector('[data-dlg="query"]')
      if (q) {
        q.focus()
        try { q.setSelectionRange(q.value.length, q.value.length) } catch (e) { /* ignore */ }
      }
    } else if (act === 'holder-id') {
      state.holderId = el.value
    }
  }

  function onChange(ev) {
    var el = ev.target
    if (!el || typeof el.getAttribute !== 'function') return
    if (el.getAttribute('data-dlg') === 'progress') state.progress = el.value
  }

  overlay.addEventListener('click', onClick)
  overlay.addEventListener('input', onInput)
  overlay.addEventListener('change', onChange)
  document.addEventListener('keydown', onKey, true)

  // 字典：先画壳（带"字典载入中"），载好后重绘。失败只降级为提示，不阻塞（api.js 的 loader 不抛错）
  render()
  var loader = (kind === 'item') ? loadItemDict() : loadProjDict()
  Promise.resolve(loader).then(function () {
    state.loadingDict = false
    var dictEmpty = (kind === 'item') ? Object.keys(itemDictNow()).length === 0 : Object.keys(projDictNow().dict || {}).length === 0
    if (dictEmpty) {
      state.dictError = '字典未能载入（/plugins/data-' + (kind === 'item' ? 'items' : 'projectiles') +
        '/client/...）：可以直接手输 ID，或检查该基础数据插件是否已启用。'
    }
    refreshRows()
    render()
  })

  return { close: close, el: overlay }
}
