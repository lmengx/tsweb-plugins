/**
 * anti-cheat 前端半 —— 公共工具与宿主 API 契约
 *
 * 为什么单独一个文件（照 qq-bind/client/shared.js:1-9 的做法）：
 *   三个页面（物品限制 / 弹幕限制 / 检测日志）加一个玩家详情区块都要转义、都要发请求。
 *   各自复制一份迟早会在某一处漏掉转义（XSS），或者出现"这个页面认得 401、那个页面不认得"的分歧。
 *   旧版正是这样碎成两套 API 客户端（规格 B §3.10 X-1）：物品页走 api/antiCheatApi.js，
 *   日志页走 utils/api.js 的 apiRequest —— 本件统一到本文件。
 *
 * 本文件**顶层零副作用**：只有函数与常量定义，不注册任何东西、不碰 DOM。
 * （宿主 plugins/base/client/base.js:15-16 说明：ESM 的 import 会被提升并顺序求值，
 *   工具模块若在顶层抛错，会让它后面所有模块静默不注册。）
 *
 * 所有请求一律经宿主的 window.tsweb.api（plugins/web/public/app.js:93 挂载、:222-244 实现）：
 *   它自动带 Authorization: Bearer，并返回 { ok, status, data }。
 *   ★ 绝不自己写 fetch：旧版自建 fetch 会漏掉 Bearer 与 x-server-id（规格 B §3.10 X-8）。
 *
 * 约定：禁止 emoji（界面符号只用本仓既有几何字符 ✕ ＋ − — ⠿ ▶ ★ →）；中文注释；引用位置写 `文件:行号`。
 */

// ═══════════════════════ 基础工具 ═══════════════════════

/** HTML 转义。所有插入 HTML 的数据（玩家名 / 物品名 / 错误信息 / 后端回显）都必须过这里 */
export function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  })
}

/** 内联 SVG 图标（项目硬性约定：禁止 emoji，图标只用内联 SVG 或纯文字） */
export function svg(inner, size) {
  var s = size || 14
  return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
    'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ' +
    'style="flex:0 0 auto;vertical-align:-2px">' + inner + '</svg>'
}

/** 界面图标表（与 qq-bind/client/shared.js:26-37 同款风格；本件只用得到这几个） */
export var ICON = {
  refresh: '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 3v6h-6"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
  trash: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M6 6l1 14h10l1-14"/>',
  box: '<path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/>',
  crosshair: '<circle cx="12" cy="12" r="8"/><path d="M12 2v4"/><path d="M12 18v4"/><path d="M2 12h4"/><path d="M18 12h4"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
  alert: '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  send: '<path d="M22 2 11 13"/><path d="M22 2l-7 20-4-9-9-4 20-7z"/>',
  list: '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
  save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8"/><path d="M7 3v5h8"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  down: '<path d="M12 3v12"/><path d="M7 10l5 5 5-5"/><path d="M5 21h14"/>',
}

/**
 * 安全请求封装：任何异常（网络断了 / 宿主没提供 api / 返回不是对象）都归一成
 * `{ ok:false, status:0, data:null, error:'...' }`，**永不抛错**。
 *
 * 为什么不直接用 window.tsweb.api：它是 async 函数，fetch 失败会 reject
 * （plugins/web/public/app.js:236 的 fetch 没有 try/catch）。页面里一次未捕获的 reject
 * 就会让「装了加载态但永远不落地」——正是旧版 I-1「整页空白且错误框永不渲染」的同类事故。
 */
export async function req(path, opts) {
  var tsw = window.tsweb
  if (!tsw || typeof tsw.api !== 'function') {
    return { ok: false, status: 0, data: null, error: '宿主未提供 window.tsweb.api（页面无法发起请求）' }
  }
  try {
    var res = await tsw.api(path, opts)
    if (!res || typeof res !== 'object') {
      return { ok: false, status: 0, data: null, error: '请求未返回结果' }
    }
    return res
  } catch (err) {
    return {
      ok: false,
      status: 0,
      data: null,
      error: (err && err.message) ? String(err.message) : String(err),
    }
  }
}

/** GET 简写 */
export function get(path) {
  return req(path, { method: 'GET' })
}

/** POST JSON 简写 */
export function post(path, json) {
  return req(path, { method: 'POST', json: json === undefined ? {} : json })
}

/**
 * 从 { ok, status, data, error } 里取一句给人看的错误原因。
 * 顺序：服务端 error 文本 > 鉴权/缺失状态码的中文说明 > 网络层 error > HTTP 状态码。
 * 返回**纯文本**（调用方用 esc 之后写进 HTML）。
 */
export function errText(res, fallback) {
  if (res && res.data && res.data.error) {
    // 宿主 wrap（plugins/anti-cheat/index.js:655-671）保证任何失败都带可见的 error 字段；
    // 校验失败还带 errors 明细（同一处 :665），一并透出前几条，管理员才能改对。
    var base = String(res.data.error)
    if (Array.isArray(res.data.errors) && res.data.errors.length) {
      var first = res.data.errors.slice(0, 5).map(function (e) {
        var where = e && e.path ? '[' + e.path + '] ' : ''
        return where + ((e && e.message) || '')
      })
      if (first.length) base += '（' + first.join('；') + '）'
    }
    if (res.data.serverHalfMissing) {
      base += '（该游戏服未安装 ' + String(res.data.dllName || 'AntiCheat.dll') + '）'
    }
    return base
  }
  if (res && res.status === 401) return '登录状态已失效（HTTP 401），请重新登录后再试'
  if (res && res.status === 403) return '当前账号没有管理权限（HTTP 403）：反作弊清单与日志都要求管理员'
  if (res && res.status === 404) return '接口不存在（HTTP 404）：宿主里的 anti-cheat 后端半可能未启用或版本过旧'
  if (res && res.error) return String(res.error)
  if (res && res.status) return 'HTTP ' + res.status
  return fallback || '未知错误'
}

/** 从响应里取数据体（失败或无体时给 {}） */
export function dataOf(res) {
  if (res && res.ok && res.data && typeof res.data === 'object') return res.data
  return {}
}

/** 把对象拼成 query string（空值不下发，与旧版 buildQuery 的口径一致，规格 B §3.3(d) :108-113） */
export function qs(params, always) {
  var out = []
  var force = always || []
  Object.keys(params || {}).forEach(function (k) {
    var v = params[k]
    var isForced = force.indexOf(k) >= 0
    if (!isForced && (v === undefined || v === null || v === '')) return
    out.push(encodeURIComponent(k) + '=' + encodeURIComponent(String(v)))
  })
  return out.length ? '?' + out.join('&') : ''
}

/** 取当前选中的服务器 id（宿主的服务器切换器；plugins/web/public/app.js:94） */
export function currentServerId() {
  var tsw = window.tsweb
  try {
    if (tsw && typeof tsw.getServerId === 'function') return String(tsw.getServerId() || '')
  } catch (e) { /* 宿主版本旧则当成未选中 */ }
  return ''
}

/**
 * 给 promise 套硬超时（照 qq-bind/client/shared.js:80-100）。
 *
 * 为什么必须有：宿主 window.tsweb.api 自己拼 fetch 参数、**不透传 options.signal**
 * （plugins/web/public/app.js:236-240），浏览器 fetch 默认没有超时。日志页在游戏服掉线时
 * 会一直挂在"加载中"，而界面不给任何说法 —— 用 race 保证一定会落到一个可读状态。
 */
export function raceTimeout(promise, ms) {
  return new Promise(function (resolve, reject) {
    var settled = false
    var timer = setTimeout(function () {
      if (settled) return
      settled = true
      resolve({ timedOut: true, value: null })
    }, ms)
    Promise.resolve(promise).then(function (v) {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve({ timedOut: false, value: v })
    }, function (err) {
      if (settled) return
      settled = true
      clearTimeout(timer)
      reject(err)
    })
  })
}

/** 带超时的请求（默认 20 秒；游戏服交互式端点在最坏情况下要等它自己的代理超时） */
export async function reqTimed(path, opts, ms) {
  var r = await raceTimeout(req(path, opts), ms || 20000)
  if (r.timedOut) return { ok: false, status: 0, data: null, error: '请求超时（' + Math.round((ms || 20000) / 1000) + ' 秒无响应）' }
  return r.value
}

/**
 * 时间显示。
 *
 * 旧版 formatTime（规格 B §3.3(g) #1）是**恒等函数**，直接展示服端存的
 * `"yyyy-MM-dd HH:mm:ss"` 文本（旧 AntiCheatLog.cs:21 明确该格式字典序即时间序）。
 * 本件保持同一口径：**不臆造时区转换**（宿主机与游戏服可能不同时区，logs.js:104-105 已标明
 * `timeBasis='server-local'`），只做空值兜底与把 ISO 串换成同一形态，便于对齐阅读。
 */
export function fmtTime(v) {
  if (v == null || v === '') return ''
  var s = String(v)
  if (/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}/.test(s)) return s.replace('T', ' ').slice(0, 19)
  return s
}

// ═══════════════════════ 宿主 API 常量 ═══════════════════════
//
// 全部取自 plugins/anti-cheat/index.js 已注册的路由（本件只调用已存在的路由）：
//   :693 GET  /api/anticheat/config          清单 + 进度顺序 + method 值域 + 快捷命令
//   :720 POST /api/anticheat/config          清单写入（body，不走 query —— 旧版 D-8 的修法）
//   :740 GET  /api/anticheat/defaults        默认清单来源与预览
//   :758 POST /api/anticheat/apply-defaults  应用默认清单（必须 confirm:true 才写）
//   :790 GET  /api/anticheat/status          下发状态 + probe 自证
//   :797 POST /api/anticheat/push            手动下发
//   :814 GET  /api/anticheat/logs            检测日志分页查询（跨服聚合）
//   :838 GET  /api/anticheat/logs/stats      检测日志统计
//   :865 GET  /api/anticheat/check-anomaly   异常物品判定（服端权威）
//   :877 GET  /api/anticheat/audit           本件审计流水
//   :882 POST /api/anticheat/scan            手动扫描全部在线玩家（会真的处置）
//   :897 GET  /api/anticheat/scan-by-id      按物品 ID 查持有者（纯查询）
export var API = {
  config: '/api/anticheat/config',
  defaults: '/api/anticheat/defaults',
  applyDefaults: '/api/anticheat/apply-defaults',
  status: '/api/anticheat/status',
  push: '/api/anticheat/push',
  logs: '/api/anticheat/logs',
  logsStats: '/api/anticheat/logs/stats',
  checkAnomaly: '/api/anticheat/check-anomaly',
  audit: '/api/anticheat/audit',
  scan: '/api/anticheat/scan',
  scanById: '/api/anticheat/scan-by-id',
  /** 服务器清单（servers 插件；plugins/servers/index.js:957）——日志页的"服务器"下拉与下发状态卡用 */
  servers: '/api/servers',
}

// ═══════════════════════ 基础数据（物品 / 弹幕字典与图标）═══════════════════════
//
// ★ 静态路径必须走 data-* 插件（规格 B §6.3 结论 4、§6.8 坑 5）：
//   旧版是主包的 /ID.json、/ProjectileData.json、/assets/img/img/Item_<id>.png、
//   /assets/img/proj/proj_<id>.png（旧 ItemRestrictView.vue:209-215、ProjRestrictView.vue:123），
//   新宿主的主包**不再持有这些图**，照抄旧路径会满屏破图。
//   正确路径（plugins/data-items/index.js:10-13、plugins/data-projectiles/index.js:10-13）：
//     字典   /plugins/data-items/client/ID.json
//     图标   /plugins/data-items/client/img/img/Item_<netID>.png
//     Boss   /plugins/data-items/client/img/Boss/<file>
//     弹幕   /plugins/data-projectiles/client/ProjectileData.json
//     弹幕图 /plugins/data-projectiles/client/img/proj/proj_<id>.png
export var DATA = {
  itemDict: '/plugins/data-items/client/ID.json',
  itemIconBase: '/plugins/data-items/client/img/img/Item_',
  bossIconBase: '/plugins/data-items/client/img/Boss/',
  projDict: '/plugins/data-projectiles/client/ProjectileData.json',
  projIconBase: '/plugins/data-projectiles/client/img/proj/',
}

/** 物品字典缓存（{ [netID]: { chinese, english, internal } }） */
var itemDictCache = null
var itemDictPromise = null

/** 弹幕字典缓存（{ list: [], dict: { [id]: { chinese, english, internal, image } } }） */
var projDictCache = null
var projDictPromise = null

/**
 * 载入物品字典。失败**不抛错**，返回 {} 并让调用方降级成"只显示 ID"
 * （旧版字典加载失败也只是降级，规格 B §3.3(f) :23）。
 */
export function loadItemDict() {
  if (itemDictCache) return Promise.resolve(itemDictCache)
  if (itemDictPromise) return itemDictPromise
  itemDictPromise = fetch(DATA.itemDict).then(function (r) {
    if (!r.ok) throw new Error('HTTP ' + r.status)
    return r.json()
  }).then(function (json) {
    itemDictCache = (json && typeof json === 'object') ? json : {}
    return itemDictCache
  }).catch(function (err) {
    // 只降级、不抛错：字典缺失不该让整页失败
    console.warn('[anti-cheat] 物品字典加载失败（页面将只显示 ID）：' + ((err && err.message) || err))
    itemDictCache = {}
    return itemDictCache
  })
  return itemDictPromise
}

/** 载入弹幕字典（形状见 plugins/data-projectiles/index.js:36-38） */
export function loadProjDict() {
  if (projDictCache) return Promise.resolve(projDictCache)
  if (projDictPromise) return projDictPromise
  projDictPromise = fetch(DATA.projDict).then(function (r) {
    if (!r.ok) throw new Error('HTTP ' + r.status)
    return r.json()
  }).then(function (json) {
    projDictCache = (json && typeof json === 'object') ? json : { list: [], dict: {} }
    if (!projDictCache.list) projDictCache.list = []
    if (!projDictCache.dict) projDictCache.dict = {}
    return projDictCache
  }).catch(function (err) {
    console.warn('[anti-cheat] 弹幕字典加载失败（页面将只显示 ID）：' + ((err && err.message) || err))
    projDictCache = { list: [], dict: {} }
    return projDictCache
  })
  return projDictPromise
}

/** 已载入的物品字典（未载入时给 {}，调用方不必判空） */
export function itemDictNow() {
  return itemDictCache || {}
}

/** 已载入的弹幕字典（未载入时给空结构） */
export function projDictNow() {
  return projDictCache || { list: [], dict: {} }
}

/** ID → 物品中文名（chinese → english → internal；查不到返回空串） */
export function itemNameOf(id) {
  var info = itemDictNow()[String(id)]
  if (!info) return ''
  return String(info.chinese || info.english || info.internal || '')
}

/** ID → 弹幕中文名（chinese → english → internal；查不到返回空串） */
export function projNameOf(id) {
  var d = projDictNow()
  var info = d.dict ? d.dict[String(id)] : null
  if (!info) return ''
  return String(info.chinese || info.english || info.internal || '')
}

/** 物品图标 URL（静态路径走 data-items，见上方 DATA 的说明） */
export function itemIconUrl(id) {
  var n = Number(id)
  if (!Number.isFinite(n) || n <= 0) return ''
  return DATA.itemIconBase + Math.trunc(n) + '.png'
}

/**
 * 弹幕图标 URL。字典条目自带的 `image` 字段优先（旧 ProjectileSearchDialog.vue:167-169 就用它），
 * 缺失时回落 `proj_<id>.png`（已核实 1,148 条的 image 全部等于该命名，规格 B §3.7 P-9）。
 */
export function projIconUrl(id) {
  var n = Number(id)
  if (!Number.isFinite(n) || n <= 0) return ''
  var d = projDictNow()
  var info = d.dict ? d.dict[String(Math.trunc(n))] : null
  var file = info && info.image ? String(info.image) : ('proj_' + Math.trunc(n) + '.png')
  return DATA.projIconBase + file
}

/** Boss 立绘 URL（旧版是 /assets/img/Boss/<file>，新宿主在 data-items 下） */
export function bossIconUrl(file) {
  if (!file) return ''
  return DATA.bossIconBase + String(file)
}

/**
 * 服务器清单（判 enabled 之后按 name 排序）。
 * 来源是 servers 插件的 GET /api/servers（plugins/servers/index.js:957 → sanitize() :680-700）。
 * 之所以要它：反作弊的日志页与下发状态卡都要"跨服"列出服务器名，
 * 而 anti-cheat 自己的路由只回"已推送过的服"（index.js:425 pushStatus），
 * 没有它就拿不到"启用了但还没推过"的服名。
 */
export async function loadServers() {
  var res = await req(API.servers, { method: 'GET' })
  if (!res.ok || !res.data || !Array.isArray(res.data.servers)) {
    return { servers: [], error: errText(res, '读取服务器列表失败') }
  }
  var list = res.data.servers.filter(function (s) { return s && s.enabled !== false })
  list.sort(function (a, b) { return String(a.name || a.id).localeCompare(String(b.name || b.id)) })
  return { servers: list, error: '' }
}

// ═══════════════════════ 提示条（成功 / 失败 / 警告）═══════════════════════
//
// 旧版成功反馈有三种样式（SuccessModal 浮层 / 右上角 toast / 无反馈，规格 B §3.10 X-2）。
// 本件统一成一种：页面顶部的内联提示条（不引入任何弹层与定时器，也就没有
// 旧版 B-2「错误 toast 永不自动消失且 setTimeout 未清理」那类泄漏）。

/**
 * 渲染一条提示条。kind: 'ok' | 'error' | 'warn' | 'info'
 * 返回 HTML 字符串；调用方负责放进容器。
 *
 * 配色/边框由 shared/style.js 的 `.ac-notice` / `.ac-notice-<kind>` / `.ac-notice-ic` 提供，
 * **本函数不再内联写样式**：单一样式来源，避免"改了 CSS 但页面纹丝不动"这类看不懂的现象。
 * 图标用 `currentColor` 继承本行文字色，所以四态共用一个 svg。
 */
export function noticeHtml(kind, text) {
  var k = (kind === 'ok' || kind === 'error' || kind === 'warn' || kind === 'info') ? kind : 'info'
  return '<div class="ac-notice ac-notice-' + k + '" role="status">' +
    '<span class="ac-notice-ic" aria-hidden="true">' + svg(ICON.alert, 14) + '</span>' +
    '<span style="min-width:0;word-break:break-word">' + esc(text) + '</span></div>'
}

/** 警告列表 → 折叠展示块（宿主每次写入都会回显 warnings，必须让管理员看得见） */
export function warningsHtml(title, warnings) {
  if (!Array.isArray(warnings) || warnings.length === 0) return ''
  var rows = warnings.map(function (w) {
    return '<li style="margin:2px 0">' + esc(w) + '</li>'
  }).join('')
  return '<details class="ac-warnings" style="margin:8px 0;font-size:12px;line-height:1.7">' +
    '<summary style="cursor:pointer;color:#d97706">' + esc(title || '警告') + '（' + warnings.length + ' 条）</summary>' +
    '<ul style="margin:6px 0 0;padding-left:18px">' + rows + '</ul></details>'
}

/**
 * 图片兜底：图标文件不存在时，把 <img> 换成占位方块（`?`），而不是留一个破图。
 *
 * 为什么必须有：物品/弹幕图标来自 data-items / data-projectiles 的静态目录
 * （几千个文件，但不是每个 ID 都有图），而**旧版正是这里出了问题**：
 *   规格 B §3.6(g) I-10 —— 旧扫描面板的 `<img>` 没绑 `@error`，只要没有本地图标就**永久破图**；
 *   规格 B §3.7 P-7 —— 弹幕资料最终失败态还会渲染 `src=""`（同样是破图）。
 * 本件没有用 wiki 外链兜底（本项目要求无外部 CDN），所以"图挂了要退化成占位块"必须自己做好。
 *
 * 用**捕获阶段**监听 `error`：图片加载失败的 error 事件不冒泡，只有捕获阶段能在容器上收到。
 * 同一个容器只绑一次（按同一引用记在容器上），重复 render 不会累加监听器。
 */
export function bindImageFallback(container) {
  if (!container || typeof container.addEventListener !== 'function') return
  if (container.__acImgFallback) return
  container.__acImgFallback = function (ev) {
    var el = ev && ev.target
    if (!el || String(el.tagName).toUpperCase() !== 'IMG') return
    if (el.__acFallbackDone) return
    el.__acFallbackDone = true
    var ph = document.createElement('span')
    ph.className = 'ac-icon-ph'
    ph.textContent = '?'
    ph.title = '没有本地图标文件（本件不外链 wiki 图片）'
    if (el.parentNode) el.parentNode.replaceChild(ph, el)
  }
  container.addEventListener('error', container.__acImgFallback, true)
}

/** 统一的异步等待文案（旧版 Loading 组件默认值是 `加载中…`，调用点传 `加载中...`，规格 B §3.10 X-7） */
export var LOADING_TEXT = '加载中...'

/**
 * 事件委托绑定：**先按同一引用解绑再绑**。
 *
 * 为什么必须这样（照 plugins/status-panel/client/status-panel.js:1778-1801 的做法）：
 * 宿主的 route() 每次进入视图都调 `render(container)`，而 container 是**常驻节点**
 * （plugins/web/public/app.js:381-390），无条件下 addEventListener 会让监听器随访问次数累加。
 * 用一个挂在 container 上的固定属性名保存引用，就能"先解绑旧的、再绑新的"。
 *
 * @param {HTMLElement} container
 * @param {Array<[string, string, Function]>} bindings [事件名, 引用键, 处理函数]
 */
export function bindDelegated(container, bindings) {
  if (!container || !Array.isArray(bindings)) return
  for (var i = 0; i < bindings.length; i++) {
    // ★ 必须用 IIFE 固定每轮的 evt/key/fn：直接在循环体里写闭包会捕获到**最后一轮**的值，
    // 结果是所有事件都调用同一个处理函数、且日志里的名字全是最后一个。这是本轮自查发现的真实缺陷。
    (function (evt, key, fn) {
      if (container[key]) container.removeEventListener(evt, container[key])
      container[key] = function (ev) {
        try {
          fn(ev)
        } catch (err) {
          console.warn('[anti-cheat] ' + evt + ' 处理异常：' + ((err && err.message) || err))
        }
      }
      container.addEventListener(evt, container[key])
    })(bindings[i][0], '__' + bindings[i][1], bindings[i][2])
  }
}
