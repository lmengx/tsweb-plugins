/**
 * anti-cheat 前端半 —— 共享样式
 *
 * 为什么样一个文件：三个页面加一个玩家详情区块都要卡片 / 开关 / 输入框 / 按钮 / 表格 / 分页，
 * 各页各注入一份 <style> 会让同一个类名在不同页面有不同含义（旧版正是如此：物品页与弹幕页
 * 各有一大套同名 CSS，规格 B §3.6 I-13/I-14 还记录了"弹幕页的样式被复制到物品页、根 class
 * 都忘了改"这类事故）。
 *
 * 做法照抄 status-panel（plugins/status-panel/client/status-panel.js:645-... 的 injectStyle）：
 *   - 只在首次插入，用模块级 styleDone 去重；
 *   - 类名统一前缀 `ac-`（status-panel 用 `sp-`、promotion 用 `pm-`，本件用 `ac-`）；
 *   - 颜色/边框一律 `var(--xxx, 兜底值)`，跟随宿主主题（宿主的暗色变量见
 *     plugins/status-panel/client/status-panel.js:649-651 同一套 --border/--bg-2/--text/--muted/--accent）。
 *   - 旧版界面用到的排版符号 ✕ ＋ − — 保留（非 emoji，本仓既有文案字符）。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */

var styleDone = false

/** 只注入一次（多视图共用同一份 CSS） */
export function injectStyle() {
  if (styleDone || typeof document === 'undefined') return
  styleDone = true
  var css = '' +
    // ── 页面骨架 ──
    '.ac-wrap{display:flex;flex-direction:column;gap:14px;max-width:1280px}' +
    '.ac-head h2{margin:0;font-size:18px;display:flex;align-items:center;gap:8px}' +
    '.ac-sub{margin:4px 0 0;font-size:12.5px;color:var(--muted,#9aa4b2);line-height:1.7}' +
    '.ac-card{border:1px solid var(--border,#2a2f3a);border-radius:10px;padding:14px 16px;background:transparent}' +
    '.ac-card-head{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}' +
    '.ac-card-head h3{margin:0;font-size:15px}' +
    '.ac-desc{margin:6px 0 12px;font-size:12.5px;color:var(--muted,#9aa4b2);line-height:1.7}' +
    '.ac-muted{color:var(--muted,#9aa4b2)}' +
    '.ac-mono{font-family:ui-monospace,SFMono-Regular,Consolas,monospace}' +
    // ── 行 / 表单 ──
    '.ac-row{display:flex;align-items:center;gap:10px;margin:8px 0;flex-wrap:wrap}' +
    '.ac-label{min-width:96px;color:var(--muted,#9aa4b2);font-size:13px}' +
    '.ac-input,.ac-select{box-sizing:border-box;padding:6px 9px;font-size:13px;background:var(--bg-2,#171b23);' +
    'color:var(--text,#e6e9ef);border:1px solid var(--border,#2a2f3a);border-radius:6px}' +
    '.ac-input:disabled,.ac-select:disabled{opacity:.55;cursor:not-allowed}' +
    '.ac-input.ac-bad{border-color:#ef4444}' +
    '.ac-num{width:96px;text-align:center}' +
    '.ac-num-sm{width:72px;text-align:center}' +
    '.ac-input-wide{flex:1;min-width:220px}' +
    // ── 按钮 ──
    '.ac-btn{padding:6px 12px;font-size:12.5px;border-radius:6px;cursor:pointer;background:var(--bg-2,#171b23);' +
    'color:var(--text,#e6e9ef);border:1px solid var(--border,#2a2f3a);display:inline-flex;align-items:center;gap:6px}' +
    '.ac-btn:hover{border-color:var(--accent,#3b82f6)}' +
    '.ac-btn:disabled{opacity:.45;cursor:not-allowed}' +
    '.ac-btn.accent{background:var(--accent,#3b82f6);border-color:var(--accent,#3b82f6);color:#fff}' +
    '.ac-btn.danger{color:#e0533d;border-color:rgba(224,83,61,.5)}' +
    '.ac-btn.mini{width:28px;height:28px;padding:0;justify-content:center;font-size:13px;line-height:1}' +
    '.ac-btn-group{display:inline-flex;gap:4px;flex-wrap:wrap}' +
    '.ac-chip{padding:3px 9px;font-size:12px;border-radius:14px;cursor:pointer;border:1px solid var(--border,#2a2f3a);' +
    'background:transparent;color:var(--muted,#9aa4b2)}' +
    '.ac-chip.on{color:#fff;font-weight:600}' +
    // ── 开关（与 status-panel .sp-switch 同款）──
    '.ac-switch{position:relative;display:inline-block;width:46px;height:26px;flex-shrink:0}' +
    '.ac-switch input{opacity:0;width:0;height:0}' +
    '.ac-slider{position:absolute;cursor:pointer;inset:0;border:2px solid var(--border,#2a2f3a);border-radius:26px;' +
    'background:var(--bg-2,#171b23);transition:all .25s}' +
    '.ac-slider:before{content:"";position:absolute;height:16px;width:16px;left:3px;bottom:3px;' +
    'background:var(--muted,#9aa4b2);border-radius:50%;transition:all .25s}' +
    '.ac-switch input:checked+.ac-slider{background:var(--accent,#3b82f6);border-color:var(--accent,#3b82f6)}' +
    '.ac-switch input:checked+.ac-slider:before{transform:translateX(20px);background:#fff}' +
    '.ac-switch input:disabled+.ac-slider{opacity:.5;cursor:not-allowed}' +
    // ── 档位卡网格 ──
    '.ac-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(330px,1fr));gap:12px}' +
    '.ac-tier{border:1px solid var(--border,#2a2f3a);border-radius:10px;padding:10px 12px;display:flex;flex-direction:column;gap:8px}' +
    '.ac-tier.known-false{border-color:rgba(217,119,6,.55)}' +
    '.ac-tier-head{display:flex;align-items:center;gap:10px}' +
    '.ac-tier-art{width:40px;height:40px;flex:0 0 auto;border-radius:8px;background:var(--bg-2,#171b23);' +
    'display:flex;align-items:center;justify-content:center;overflow:hidden}' +
    '.ac-tier-art img{width:40px;height:40px;object-fit:contain}' +
    '.ac-tier-title{font-size:13.5px;font-weight:600;display:flex;align-items:center;gap:6px;flex-wrap:wrap}' +
    '.ac-tier-count{font-size:11.5px;color:var(--muted,#9aa4b2)}' +
    '.ac-badge{font-size:11px;padding:1px 7px;border-radius:10px;background:var(--bg-2,#171b23);color:var(--muted,#9aa4b2)}' +
    '.ac-badge.warn{color:#d97706;border:1px solid rgba(217,119,6,.5)}' +
    '.ac-badge.ok{color:#16a34a;border:1px solid rgba(22,163,74,.5)}' +
    '.ac-badge.err{color:#ef4444;border:1px solid rgba(239,68,68,.5)}' +
    // ── 条目行 ──
    '.ac-entry{border:1px solid var(--border,#2a2f3a);border-radius:8px;padding:8px;display:flex;flex-direction:column;gap:6px}' +
    '.ac-entry-main{display:flex;align-items:center;gap:6px;flex-wrap:wrap}' +
    '.ac-icon{width:26px;height:26px;object-fit:contain;image-rendering:pixelated;flex:0 0 auto}' +
    '.ac-icon-ph{width:26px;height:26px;flex:0 0 auto;border-radius:4px;background:var(--bg-2,#171b23);' +
    'color:var(--muted,#9aa4b2);font-size:10px;display:inline-flex;align-items:center;justify-content:center}' +
    '.ac-name{font-size:12px;min-width:84px;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ac-qc{font-size:11.5px;color:var(--muted,#9aa4b2);line-height:1.9}' +
    '.ac-qc button{margin-left:4px;padding:2px 7px;font-size:11.5px;border-radius:5px;cursor:pointer;' +
    'background:transparent;color:var(--text,#e6e9ef);border:1px solid var(--border,#2a2f3a)}' +
    '.ac-qc button:hover{border-color:var(--accent,#3b82f6)}' +
    '.ac-empty{font-size:12px;color:var(--muted,#9aa4b2);padding:6px 2px}' +
    // ── 统计卡 ──
    '.ac-stats{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px}' +
    '.ac-stat{border:1px solid var(--border,#2a2f3a);border-radius:10px;padding:10px 12px}' +
    '.ac-stat .v{font-size:20px;font-weight:600;font-variant-numeric:tabular-nums}' +
    '.ac-stat .k{font-size:12px;color:var(--muted,#9aa4b2);margin-top:2px}' +
    // ── 表格 ──
    '.ac-table{width:100%;border-collapse:collapse;font-size:12.5px}' +
    '.ac-table th{text-align:left;padding:7px 8px;border-bottom:1px solid var(--border,#2a2f3a);' +
    'color:var(--muted,#9aa4b2);font-weight:600;white-space:nowrap}' +
    '.ac-table td{padding:7px 8px;border-bottom:1px solid var(--border,#2a2f3a);vertical-align:top}' +
    '.ac-table tr:hover td{background:var(--bg-2,#171b23)}' +
    '.ac-tagpill{display:inline-block;padding:1px 8px;border-radius:10px;font-size:11.5px;border:1px solid}' +
    '.ac-detail{max-width:340px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    // ── 分页 ──
    '.ac-pager{display:flex;align-items:center;gap:8px;flex-wrap:wrap;justify-content:flex-end;margin-top:10px;font-size:12.5px}' +
    '.ac-pager button{padding:4px 10px;font-size:12.5px;border-radius:6px;cursor:pointer;' +
    'background:var(--bg-2,#171b23);color:var(--text,#e6e9ef);border:1px solid var(--border,#2a2f3a)}' +
    '.ac-pager button:disabled{opacity:.45;cursor:not-allowed}' +
    // ── 对话框（物品/弹幕选择器）──
    '.ac-overlay{position:fixed;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;' +
    'justify-content:center;z-index:60;padding:20px}' +
    '.ac-modal{background:var(--bg-1,#0f1218);border:1px solid var(--border,#2a2f3a);border-radius:12px;' +
    'width:min(860px,96vw);max-height:88vh;display:flex;flex-direction:column}' +
    '.ac-modal-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 14px;' +
    'border-bottom:1px solid var(--border,#2a2f3a)}' +
    '.ac-modal-body{padding:12px 14px;overflow:auto;flex:1;min-height:0}' +
    '.ac-modal-foot{padding:10px 14px;border-top:1px solid var(--border,#2a2f3a);display:flex;' +
    'align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}' +
    '.ac-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(108px,1fr));gap:8px}' +
    '.ac-icard{border:1px solid var(--border,#2a2f3a);border-radius:8px;padding:6px;cursor:pointer;' +
    'display:flex;flex-direction:column;align-items:center;gap:4px;text-align:center;background:transparent}' +
    '.ac-icard:hover{border-color:var(--accent,#3b82f6)}' +
    '.ac-icard.sel{border-color:var(--accent,#3b82f6);background:rgba(59,130,246,.12)}' +
    '.ac-icard img{width:32px;height:32px;object-fit:contain;image-rendering:pixelated}' +
    '.ac-icard .n{font-size:11.5px;line-height:1.35;max-height:2.7em;overflow:hidden}' +
    '.ac-icard .i{font-size:10.5px;color:var(--muted,#9aa4b2)}' +
    // ── 其它 ──
    '.ac-scan{border:1px solid var(--border,#2a2f3a);border-radius:8px;padding:10px 12px;font-size:12.5px;margin-top:8px}' +
    '.ac-diff{font-size:12px;line-height:1.8}' +
    '.ac-diff li{margin:1px 0}' +
    // ── 内联提示条（noticeHtml 生成；四态）──
    // 这几条是本轮自查补上的：noticeHtml/warningsHtml 在 api.js 里生成 ac-notice / ac-notice-<kind>
    // 与 ac-warnings，但 styles 里原先没有对应规则 —— 那样提示条会完全没有边框与配色，
    // 而"错误必须可读"正是本件要修的旧版缺陷之一（旧 ItemRestrictView 加载失败整页空白，规格 B I-1）。
    '.ac-notice{display:flex;gap:8px;align-items:flex-start;padding:8px 10px;border-radius:8px;' +
    'font-size:13px;line-height:1.6;margin:8px 0;border:1px solid var(--border,#2a2f3a);' +
    'background:var(--bg-2,#171b23)}' +
    '.ac-notice-ic{flex:0 0 auto;color:currentColor}' +
    '.ac-notice-ok{border-color:rgba(22,163,74,.55);color:#16a34a;background:rgba(22,163,74,.12)}' +
    '.ac-notice-error{border-color:rgba(239,68,68,.55);color:#ef4444;background:rgba(239,68,68,.12)}' +
    '.ac-notice-warn{border-color:rgba(217,119,6,.55);color:#d97706;background:rgba(217,119,6,.12)}' +
    '.ac-notice-info{border-color:rgba(100,116,139,.55);color:#64748b;background:rgba(100,116,139,.12)}' +
    '.ac-warnings{margin:8px 0;font-size:12px;line-height:1.7}' +
    '.ac-warnings summary{cursor:pointer;color:#d97706}' +
    // ── 卡片标题里的小图标容器（item.js / proj.js 传给编辑器当 iconPath）──
    '.ac-ic{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;' +
    'border-radius:6px;background:var(--bg-2,#171b23);color:var(--muted,#9aa4b2);flex:0 0 auto}' +
    '@media (max-width:900px){.ac-grid{grid-template-columns:1fr}}'
  var el = document.createElement('style')
  el.setAttribute('data-tsweb-plugin', 'anti-cheat')
  el.textContent = css
  document.head.appendChild(el)
}

/** 页面外壳（三个页面共用；各页面标题/副标题不同） */
export function shellHtml(title, subtitle, iconPath) {
  return '<div class="ac-head">' +
    '<h2>' + (iconPath || '') + '<span>' + title + '</span></h2>' +
    (subtitle ? '<p class="ac-sub">' + subtitle + '</p>' : '') +
    '</div>'
}
