/**
 * anti-cheat 前端半 —— 档位编辑器（物品页与弹幕页**共用同一份实现**）
 *
 * ══════════ 为什么两页共用一份 ══════════
 * 旧版两页是"高度同构的孪生页"（规格 B §6.4 理由 4：同批共享组件、同一套 method 四按钮、
 * 同一套离开守卫、同一套 19 档硬编码），却各自实现了一遍，于是同一个缺陷在两页各犯一次
 * （I-2/I-5/I-8/I-9/I-12 与 P-1..P-9，规格 B §3.6(g)/§3.7）。本件把编辑器抽成一份、
 * 用 `kind`（item/proj）参数化；两页真正的差异只有三处（也正是旧版真实的业务差异）：
 *   1. 条目字段：物品侧有 `stack`（数量阈值），弹幕侧**没有**（旧 proj-restrict.cs:30-37 的
 *      RestrictedProj 无该字段；弹幕按"是否使用"判定，不按数量）——规格 B §3.7 :632 逐字强调。
 *   2. 页面开关：物品侧 启用/自动扫描/扫描间隔/没收违禁物品；弹幕侧 启用/伤害上限。
 *   3. 快捷命令与占位符提示：物品侧 4 条 + {itemname}/{itemid}；弹幕侧 3 条 + {projid}。
 *
 * ══════════ 本件在编辑器里修掉的旧版缺陷 ══════════
 *   #1 档位集合外的数据静默丢失 → 档位从宿主派生（shared/progress.js 的 buildTierList）、
 *      未知档位单独成卡并在保存时**原样保留**（本文件的 buildTierPayload）。
 *   #2 拉取覆盖未保存编辑 → 一切读写都经 shared/store.js，它负责"有脏修改就不覆盖"。
 *   #3 加载失败整页空白（I-1）→ render() 永远先画外壳，再按 loading/error/loaded 三态渲染；
 *      失败态给出可读原因 + 「重试」按钮，并且**禁止保存**（避免空清单覆盖线上配置）。
 *   #4 禁 emoji → 图标只用内联 SVG 与几何字符（✕ ＋ −），无任何 emoji。
 *   #5（规格 B §3.6(g) 逐条）：
 *      I-5 清空数字框落盘空串 → validateEditor 预校验，有错就拦住保存并指出"哪一档哪一行哪个字段"。
 *      I-6 索引当 key + splice 错位 → 行定位一律走「档位名 + 行号」的再解析，重绘整块重建。
 *      I-9 区间校验缺失 → 扫描间隔 [1,86400]、伤害上限 >=1、id [1,65535]、数量 >=1 先挡一遍
 *          （范围与 config.js:86-94 同源；宿主那层仍是权威校验 config.js:519-599）。
 *      I-11 「成功动画与实际结果不符」→ 选择器回调**据实核对**新增条数，加不进去就报错（见 search.js）。
 *      I-13 死代码/重复样式 → 不复制（共用本文件与 shared/style.js）。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import {
  esc, svg, ICON, itemNameOf, projNameOf, itemIconUrl, projIconUrl,
  noticeHtml, warningsHtml, LOADING_TEXT, API, post, errText, currentServerId,
  loadItemDict, loadProjDict, bindDelegated, bindImageFallback,
} from './api.js'
import {
  METHOD_VALUES_FALLBACK, methodShort, methodLabel, methodColor, isStandardMethod,
  projQuickCommands, QUICK_COMMANDS_FALLBACK, placeholderHint, defaultEntry,
} from './method.js'
import {
  buildTierList, countEntries, countTiersWithEntries, progressImageUrl, progressPlaceholderSvg,
} from './progress.js'
import {
  ENTRY_KEY, MAX_TIERS, MAX_ENTRIES_PER_TIER, getState, side, tiers,
  mutate, mutateSilent, loadConfig, save, discard, setNotice, subscribe,
} from './store.js'
import { openSearchDialog } from './search.js'
import { pushPanelHtml, bindPushPanel } from './panel.js'
import { injectStyle } from './style.js'

/** 客户端预校验的数值范围（与 plugins/anti-cheat/config.js:86-94 同源） */
export var ID_MIN = 1
export var ID_MAX = 65535
export var INTERVAL_MIN = 1
export var INTERVAL_MAX = 86400

/**
 * 取一个"档位视图对象"里的条目数组。
 *
 * 注意（本件自查发现的一个**真会丢数据**的坑）：shared/progress.js 的 buildTierList()
 * 返回的视图对象用的是中性字段 `entries`（progress.js:156-167），而**配置对象**用的是中文键
 * `限制物品` / `限制弹幕`（config.js:169 的 ENTRY_KEY）。两处混用就会出现
 * "界面能显示条目、但保存时全部写空"——而且保存请求是 200、界面还显示成功，
 * 属于最坏的一类静默丢数据。所以条目一律只从这个函数取：
 *   优先视图字段 `entries`，兼容配置形态的中文键，最后给空数组（绝不 undefined）。
 */
function tierEntries(tier, entryKey) {
  if (!tier) return []
  if (Array.isArray(tier.entries)) return tier.entries
  if (entryKey && Array.isArray(tier[entryKey])) return tier[entryKey]
  return []
}

/** 把输入框里的原始字符串转成数字（空串/非法 → null，交给预校验报错） */
function toIntOrNull(v) {
  if (typeof v === 'number' && Number.isFinite(v)) return Math.trunc(v)
  var s = String(v == null ? '' : v).trim()
  if (s === '' || !/^-?\d+$/.test(s)) return null
  return Number(s)
}

/**
 * 客户端预校验：返回 [{档位, 行, 字段, 说明}]（行 -1 表示整页/整档问题）。
 *
 * 目的不是替代宿主校验（config.js:484-506 的 validateConfig 才是权威），而是：
 *   - 让管理员在**点保存之前**就看到是哪一行有问题（旧版是保存后弹一句 400 长文案）；
 *   - 挡住 I-5 那类"清空数字框 → 发出 {\"id\":\"\"}"（旧版 `?? ` 兜不住空串）。
 * 文案尽量与宿主一致，便于对照（config.js:584/589/522/542）。
 */
export function validateEditor(kind) {
  var out = []
  var list = tiers(kind)
  var s = side(kind)
  var entryKey = ENTRY_KEY[kind]

  if (list.length > MAX_TIERS) {
    out.push({ 档位: '', 行: -1, 字段: '限制列表', 说明: '档位数不能超过 ' + MAX_TIERS + '（当前 ' + list.length + '）' })
  }
  if (kind === 'item') {
    var iv = toIntOrNull(s.扫描间隔)
    if (iv === null) out.push({ 档位: '', 行: -1, 字段: '扫描间隔', 说明: '扫描间隔必须是整数（秒）' })
    else if (iv < INTERVAL_MIN || iv > INTERVAL_MAX) {
      out.push({
        档位: '', 行: -1, 字段: '扫描间隔',
        说明: '扫描间隔必须在 [' + INTERVAL_MIN + ', ' + INTERVAL_MAX + '] 秒之间（当前 ' + iv + '）',
      })
    }
  } else {
    var lim = toIntOrNull(s.伤害上限)
    if (lim === null) out.push({ 档位: '', 行: -1, 字段: '伤害上限', 说明: '伤害上限必须是整数' })
    else if (lim < 1) {
      out.push({ 档位: '', 行: -1, 字段: '伤害上限', 说明: '伤害上限必须 >= 1（<=0 会让所有弹幕都判定为异常伤害）' })
    }
  }

  for (var t = 0; t < list.length; t++) {
    var tier = list[t] || {}
    var progress = String(tier.进度 == null ? '' : tier.进度)
    var entries = tierEntries(tier, entryKey)
    if (entries.length > MAX_ENTRIES_PER_TIER) {
      out.push({ 档位: progress, 行: -1, 字段: entryKey, 说明: '单档条数不能超过 ' + MAX_ENTRIES_PER_TIER })
    }
    for (var i = 0; i < entries.length; i++) {
      var e = entries[i] || {}
      var id = toIntOrNull(e.id)
      if (id === null || id < ID_MIN || id > ID_MAX) {
        out.push({
          档位: progress, 行: i, 字段: 'id',
          说明: 'id 必须是 [' + ID_MIN + ', ' + ID_MAX + '] 之间的整数（当前 ' +
            JSON.stringify(e.id === undefined ? '' : e.id) + '）',
        })
      }
      if (kind === 'item') {
        var st = toIntOrNull(e.stack)
        if (st === null || st < 1) {
          out.push({
            档位: progress, 行: i, 字段: '数量',
            说明: '数量必须是 >= 1 的整数（当前 ' + JSON.stringify(e.stack === undefined ? '' : e.stack) + '）',
          })
        }
      }
      if (String(e.method == null ? '' : e.method).trim() === '') {
        out.push({ 档位: progress, 行: i, 字段: '处置方式', 说明: '处置方式不能为空' })
      } else if (String(e.method) === 'command' && String(e.command == null ? '' : e.command).trim() === '') {
        // ★ 宿主的校验**不拦这一条**（config.js:594-596 只要求 method 非空），但它是一条
        // "选了命令却不填命令"的规则：命中时什么都不会发生，管理员会以为已经处置了。
        // 属于"静默失效"，所以本件在客户端拦住并要求明确二选一（填命令 / 换处置方式）。
        // 这也顺带覆盖旧版 I-4（点「命令」按钮把 method 写成字面量 'command' 当命令执行）的同类风险。
        out.push({
          档位: progress, 行: i, 字段: '命令',
          说明: '处置方式选了「命令」但命令内容为空：命中时不会执行任何动作，请填写命令，或改回其它处置方式',
        })
      }
    }
  }
  return out
}

/**
 * 由编辑器状态构造**提交给宿主的档位数组**（本件修 I-8 的关键）。
 *
 * 规则（逐条给理由）：
 *   1. **未知档位一律保留**（known === false）：即使它一条都没有也照原样提交。
 *      理由：界面无法完整表达它的语义（服端 GetWorldStatus 对它恒判不生效，
 *      config.js:394-396 的归一警告正是这句话），一旦丢弃就是不可逆的信息丢失——这正是 I-8。
 *   2. 已知档位**只在有条目时提交**（与旧版 mapItemConfigToBackend 的"空组丢弃"一致，
 *      规格 B §3.6(c) :570）。理由：那些条目是管理员显式删掉的，保留空档只会在配置里堆垃圾；
 *      宿主 normalizeTiers 会保留空档（config.js:397-398），所以语义必须由前端定。
 *   3. `command` 一律保留（哪怕当前 method 不是 command）：host 的归一也保留它并给警告
 *      （config.js:441-445），丢了就等于吃掉管理员的草稿。
 *   4. 顺序按**界面顺序**写回（即 buildTierList 的顺序）：让配置文件里的档位顺序与界面一致，
 *      便于人工核对。
 */
export function buildTierPayload(kind, list) {
  var entryKey = ENTRY_KEY[kind]
  var out = []
  var src = Array.isArray(list) ? list : []
  for (var i = 0; i < src.length; i++) {
    var t = src[i] || {}
    var progress = String(t.进度 == null ? '' : t.进度).trim()
    if (progress === '') continue
    var entries = tierEntries(t, entryKey)
    var unknown = t.known === false
    if (entries.length === 0 && !unknown) continue
    var cleaned = []
    for (var j = 0; j < entries.length; j++) {
      var e = entries[j] || {}
      var one = { id: toIntOrNull(e.id) }
      if (kind === 'item') one.stack = toIntOrNull(e.stack)
      one.method = String(e.method == null ? 'log' : e.method)
      one.command = String(e.command == null ? '' : e.command)
      cleaned.push(one)
    }
    out.push({ 进度: progress, [entryKey]: cleaned })
  }
  return out
}

/** 一行「图标 + 名称」的预览（ID 改动时局部刷新它，不必整页重绘） */
function previewHtml(kind, id) {
  var n = toIntOrNull(id)
  if (n === null || n < ID_MIN) {
    return '<span class="ac-icon-ph">?</span><span class="ac-name ac-muted">未填 ID</span>'
  }
  var name = kind === 'item' ? itemNameOf(n) : projNameOf(n)
  var url = kind === 'item' ? itemIconUrl(n) : projIconUrl(n)
  var label = name || (kind === 'item' ? '未知物品' : '未知弹幕')
  var img = url
    ? '<img class="ac-icon" src="' + esc(url) + '" alt="' + (kind === 'item' ? 'Item' : 'Projectile') + '" loading="lazy">'
    : '<span class="ac-icon-ph">?</span>'
  return img + '<span class="ac-name" title="' + esc(label + '（ID ' + n + '）') + '">' + esc(label) + '</span>'
}

/** 处置方式按钮组（值域来自宿主，见 shared/method.js 的「为什么是 5 个按钮」） */
function methodButtonsHtml(kind, tierIndex, entryIndex, cur, meta) {
  var values = Array.isArray(meta.methodValues) && meta.methodValues.length ? meta.methodValues : METHOD_VALUES_FALLBACK
  var btns = values.map(function (v) {
    var on = String(cur) === v
    return '<button type="button" class="ac-chip' + (on ? ' on' : '') + '" ' +
      'data-ac-act="entry-method" data-ac-tier="' + tierIndex + '" data-ac-idx="' + entryIndex + '" ' +
      'data-ac-method="' + esc(v) + '" title="' + esc(methodLabel(v, meta.methodLabels)) + '" ' +
      (on ? 'style="background:' + methodColor(v) + ';border-color:' + methodColor(v) + '"' : '') + '>' +
      esc(methodShort(v)) + '</button>'
  }).join('')
  return '<span class="ac-btn-group">' + btns + '</span>'
}

/** 快捷命令行（`快速:` 与 4/3 条模板的文案逐字，见 shared/method.js） */
function quickListOf(kind, meta) {
  if (kind === 'proj') return projQuickCommands(meta.quickCommands)
  return (Array.isArray(meta.quickCommands) && meta.quickCommands.length) ? meta.quickCommands : QUICK_COMMANDS_FALLBACK
}

function quickCommandsHtml(kind, tierIndex, entryIndex, meta) {
  var list = quickListOf(kind, meta)
  if (!list.length) return ''
  var btns = list.map(function (c, i) {
    return '<button type="button" data-ac-act="entry-quick" data-ac-tier="' + tierIndex + '" data-ac-idx="' + entryIndex + '" ' +
      'data-ac-qc="' + i + '" title="' + esc(String(c.label || '') + '：' + String(c.template || '')) + '">' +
      esc(String(c.label || c.template || '')) + '</button>'
  }).join('')
  return '<div class="ac-qc">快速:' + btns + '</div>'
}

/** 单条违禁记录（物品/弹幕共用；差异只在有没有"数量"输入） */
function entryHtml(kind, tierIndex, tierProgress, entryIndex, e, meta, errors) {
  var mine = (errors || []).filter(function (x) { return x.档位 === tierProgress && x.行 === entryIndex })
  var badId = mine.some(function (x) { return x.字段 === 'id' })
  var badStack = mine.some(function (x) { return x.字段 === '数量' })
  var isCmd = String(e.method) === 'command'
  var standard = isStandardMethod(e.method, meta.methodValues)
  var commandDisabled = !isCmd
  var idText = (e.id === undefined || e.id === null) ? '' : String(e.id)
  var stackText = (e.stack === undefined || e.stack === null) ? '' : String(e.stack)

  var html = '<div class="ac-entry">'
  html += '<div class="ac-entry-main">'
  html += '<span data-ac-preview="' + tierIndex + '-' + entryIndex + '">' + previewHtml(kind, idText) + '</span>'
  html += '<span class="ac-muted" style="font-size:11.5px">ID</span>'
  html += '<input class="ac-input ac-num' + (badId ? ' ac-bad' : '') + '" type="number" min="' + ID_MIN + '" max="' + ID_MAX + '" ' +
    'step="1" placeholder="' + (kind === 'item' ? '物品ID' : '弹幕ID') + '" ' +
    'data-ac-act="entry-id" data-ac-tier="' + tierIndex + '" data-ac-idx="' + entryIndex + '" ' +
    'value="' + esc(idText) + '">'
  html += '<button type="button" class="ac-btn mini" data-ac-act="entry-search" data-ac-tier="' + tierIndex + '" ' +
    'data-ac-idx="' + entryIndex + '" title="搜索' + (kind === 'item' ? '物品' : '弹幕') + '">' + svg(ICON.search, 13) + '</button>'
  if (kind === 'item') {
    html += '<span class="ac-muted" style="font-size:11.5px">数量</span>'
    html += '<input class="ac-input ac-num-sm' + (badStack ? ' ac-bad' : '') + '" type="number" min="1" step="1" placeholder="最大数量" ' +
      'data-ac-act="entry-stack" data-ac-tier="' + tierIndex + '" data-ac-idx="' + entryIndex + '" ' +
      'value="' + esc(stackText) + '" ' +
      'title="持有数量达到该值即判定为违规（旧版判定是 stack >= 该值，旧 item-restrict.cs:187）">'
  }
  html += '<button type="button" class="ac-btn mini danger" data-ac-act="entry-del" data-ac-tier="' + tierIndex + '" ' +
    'data-ac-idx="' + entryIndex + '" title="移除">✕</button>'
  html += '</div>'

  html += '<div class="ac-entry-main">' + methodButtonsHtml(kind, tierIndex, entryIndex, e.method, meta) + '</div>'

  html += '<input class="ac-input ac-input-wide" type="text" ' +
    'placeholder="' + esc(placeholderHint(kind, meta.commandPlaceholders)) + '" ' +
    (commandDisabled ? 'disabled ' : '') +
    'data-ac-act="entry-command" data-ac-tier="' + tierIndex + '" data-ac-idx="' + entryIndex + '" ' +
    'value="' + esc(e.command == null ? '' : e.command) + '" ' +
    'title="' + (commandDisabled
      ? '当前处置方式不是「命令」，这条命令不会被使用（仍会保留，切回「命令」即生效）'
      : '占位符会在命中时被替换；' + placeholderHint(kind, meta.commandPlaceholders)) + '">'
  html += quickCommandsHtml(kind, tierIndex, entryIndex, meta)
  if (!standard && e.command) {
    html += '<div class="ac-muted" style="font-size:11.5px">该处置方式不在宿主闭集里，保存时会被宿主迁移成「命令」并保留上面的内容（config.js:430-436）。</div>'
  }
  html += '</div>'
  return html
}

/** 一个档位卡 */
function tierCardHtml(kind, tierIndex, tier, meta, errors) {
  var entryKey = ENTRY_KEY[kind]
  var entries = tierEntries(tier, entryKey)
  var known = tier.known !== false
  var art = progressImageUrl(tier.进度)
  var artHtml = art ? '<img src="' + esc(art) + '" alt="" loading="lazy">' : progressPlaceholderSvg()

  var html = '<div class="ac-tier' + (known ? '' : ' known-false') + '">'
  html += '<div class="ac-tier-head">'
  html += '<span class="ac-tier-art">' + artHtml + '</span>'
  html += '<span style="min-width:0;flex:1">'
  html += '<span class="ac-tier-title">' + esc(tier.进度)
  if (!known) {
    html += '<span class="ac-badge warn" title="该档位名不在宿主的权威进度表里；服端 GetWorldStatus 对它恒判不生效（config.js:394-396）。本件原样保留它，保存时不会删除。">未知档位</span>'
  }
  if (known && !tier.inConfig) {
    html += '<span class="ac-badge" title="当前配置里没有这一档；加了条目并保存后才会写入">未配置</span>'
  }
  html += '</span>'
  html += '<span class="ac-tier-count">' + entries.length + ' 条限制</span>'
  html += '</span></div>'

  if (entries.length === 0) {
    html += '<div class="ac-empty">暂无限制</div>'
  } else {
    for (var i = 0; i < entries.length; i++) {
      html += entryHtml(kind, tierIndex, tier.进度, i, entries[i] || {}, meta, errors)
    }
  }
  html += '<div class="ac-row" style="margin:2px 0 0">' +
    '<button type="button" class="ac-btn" data-ac-act="tier-add" data-ac-tier="' + tierIndex + '">' +
    svg(ICON.plus, 13) + '批量添加</button></div>'
  html += '</div>'
  return html
}

/** 页面开关区（物品侧 4 项、弹幕侧 2 项；文案逐字见规格 B §3.6(b) 与 §3.7） */
function switchesHtml(kind, s) {
  function sw(act, label, on, title) {
    return '<div class="ac-row">' +
      '<label class="ac-switch" title="' + esc(title) + '"><input type="checkbox" data-ac-act="' + act + '"' +
      (on ? ' checked' : '') + '><span class="ac-slider"></span></label>' +
      '<span style="font-size:13px">' + esc(label) + '</span>' +
      '</div>'
  }
  var html = ''
  html += sw('sw-enable', '启用检测', s.启用 === true,
    '关闭时游戏服不做该项检测（服端仍持有清单）；改动需要点「保存配置」才会写盘并下发')
  if (kind === 'item') {
    html += sw('sw-autoscan', '自动扫描', s.自动扫描 === true, '按「扫描间隔」周期性地遍历在线玩家背包')
    html += sw('sw-confiscate', '没收违禁物品', s.没收违禁物品 === true,
      '开启后，扫描检测到违禁物品时直接移除（整格清空），并继续按原处理方式执行')
    html += '<div class="ac-row"><span class="ac-label">扫描间隔(秒)</span>' +
      '<input class="ac-input ac-num" type="number" min="' + INTERVAL_MIN + '" max="' + INTERVAL_MAX + '" step="1" ' +
      'data-ac-act="sw-interval" value="' + esc(s.扫描间隔 === undefined || s.扫描间隔 === null ? '' : String(s.扫描间隔)) + '" ' +
      'title="合法范围 [' + INTERVAL_MIN + ', ' + INTERVAL_MAX + '] 秒；过短会持续占用游戏服线程（旧版没有这个钳制）">' +
      '</div>'
  } else {
    html += '<div class="ac-row"><span class="ac-label">伤害上限</span>' +
      '<input class="ac-input ac-num" type="number" min="1" step="1" ' +
      'data-ac-act="sw-damage" value="' + esc(s.伤害上限 === undefined || s.伤害上限 === null ? '' : String(s.伤害上限)) + '" ' +
      'title="弹幕伤害超过该值即判定为异常（默认 20000）。必须 >= 1：<=0 会让所有弹幕都判定为异常伤害">' +
      '<span class="ac-muted" style="font-size:11.5px">超过该值的弹幕判定为异常</span></div>'
  }
  return html
}

/** 扫描结果面板（物品侧专用：旧版物品页有、弹幕页没有） */
function scanPanelHtml(scan) {
  if (!scan) return ''
  if (scan.error) return '<div class="ac-scan">' + noticeHtml('error', '扫描失败：' + scan.error) + '</div>'
  var r = scan.result
  if (!r) return ''
  var players = Array.isArray(r.players) ? r.players : []
  var total = 0
  for (var i = 0; i < players.length; i++) {
    total += Array.isArray(players[i] && players[i].items) ? players[i].items.length : 0
  }
  var html = '<div class="ac-scan"><div style="font-size:13px;margin-bottom:6px">扫描结果</div>'
  html += '<div class="ac-muted">扫描 ' + esc(r.scannedPlayers || 0) + ' 名在线玩家，发现 ' +
    esc(r.violationCount || 0) + ' 条违规，耗时 ' + esc(r.durationMs || 0) + 'ms</div>'
  if (r.serverName) html += '<div class="ac-muted">目标服务器：' + esc(r.serverName) + '</div>'
  if (total === 0) {
    html += '<div class="ac-empty">未发现违规物品</div>'
  } else {
    for (var p = 0; p < players.length; p++) {
      var pl = players[p] || {}
      var items = Array.isArray(pl.items) ? pl.items : []
      if (!items.length) continue
      html += '<div style="margin-top:8px"><strong>' + esc(pl.name || '未知玩家') + '</strong>' +
        '<span class="ac-muted">（' + items.length + ' 格）</span><ul style="margin:4px 0 0;padding-left:18px">'
      for (var k = 0; k < items.length; k++) {
        var it = items[k] || {}
        var icon = itemIconUrl(it.id)
        var nm = it.itemName || itemNameOf(it.id) || ('ID:' + it.id)
        // 旧版 I-7：扫描面板用 item.id 当 key，同一玩家两格同物品会重复；本件直接用列表顺序渲染，
        // 不做 key 复用，并从服端字段里带上槽位（服端 ItemConfigHandler 每条命中都带 slot）
        html += '<li style="margin:2px 0">' +
          (icon ? '<img class="ac-icon" src="' + esc(icon) + '" alt="" loading="lazy">' : '') +
          esc(nm) + '<span class="ac-muted"> ID ' + esc(it.id) + ' 数量 ' + esc(it.stack) +
          '（上限 ' + esc(it.allowedStack) + '，处置 ' + esc(methodShort(it.method)) +
          (it.slot === undefined ? '' : '，槽位 ' + esc(it.slot)) + '）</span></li>'
      }
      html += '</ul></div>'
    }
  }
  html += '</div>'
  return html
}

/**
 * 创建一个档位配置页控制器。
 * @param {{kind:'item'|'proj', title:string, subtitle:string, iconPath:string}} cfg
 */
export function createTierPage(cfg) {
  var kind = cfg.kind
  var entryKey = ENTRY_KEY[kind]
  var root = null
  var dialog = null
  var scan = { loading: false, result: null, error: '' }
  var errors = []
  var saving = false
  var unsubscribe = null

  // ── 片段渲染 ──

  function noticeAreaHtml() {
    var st = getState()
    var html = ''
    if (st.notice) html += noticeHtml(st.notice.kind, st.notice.text)
    if (st.saveError) html += noticeHtml('error', '保存失败：' + st.saveError)
    return html
  }

  function saveBarInner(st) {
    var html = '<div class="ac-card-head"><div style="min-width:0">'
    html += '<h3 style="display:flex;align-items:center;gap:8px">' + cfg.iconPath + '<span>' + esc(cfg.title) + '</span>'
    html += st.dirty
      ? '<span class="ac-badge warn">有未保存的修改</span>'
      : '<span class="ac-badge ok">与服务端一致</span>'
    html += '</h3>'
    html += '<p class="ac-desc" style="margin:6px 0 0">' + esc(cfg.subtitle) + '</p>'
    html += '</div><div class="ac-btn-group">'
    html += '<button type="button" class="ac-btn accent" data-ac-act="save"' + (saving ? ' disabled' : '') + '>' +
      svg(ICON.save, 13) + (saving ? '保存中...' : '保存配置') + '</button>'
    html += '<button type="button" class="ac-btn" data-ac-act="discard"' + (st.dirty ? '' : ' disabled') + '>' +
      svg(ICON.refresh, 13) + '放弃修改</button>'
    html += '<button type="button" class="ac-btn" data-ac-act="reload"' + (saving ? ' disabled' : '') + '>' +
      svg(ICON.down, 13) + '重新载入</button>'
    html += '</div></div>'

    if (errors.length) {
      html += noticeHtml('error', '有 ' + errors.length + ' 处未通过校验，已阻止保存：' +
        errors.slice(0, 6).map(function (x) {
          var where = x.档位 ? ('档位「' + x.档位 + '」' + (x.行 >= 0 ? '第 ' + (x.行 + 1) + ' 行' : '')) : '页面设置'
          return where + ' 的' + x.字段 + '：' + x.说明
        }).join('；') + (errors.length > 6 ? ' …' : ''))
    }

    html += '<div class="ac-muted" style="font-size:11.5px;margin-top:8px;line-height:1.8">' +
      '保存会一次性提交**完整清单**（物品侧与弹幕侧），宿主写盘后立即下发给全部启用中的游戏服。'
    if (st.meta.configFile) html += '<br>配置文件：<span class="ac-mono">' + esc(st.meta.configFile) + '</span>'
    html += '</div>'
    return html
  }

  function saveBarHtml(st) {
    return '<div class="ac-card" data-ac-savebar="1">' + saveBarInner(st) + '</div>'
  }

  function warningsAreaHtml(st) {
    var html = ''
    var ws = []
    if (st.meta.configError) ws.push('配置文件读取出错：' + st.meta.configError)
    if (st.meta.defaultsError) ws.push('默认清单不可用：' + st.meta.defaultsError)
    if (Array.isArray(st.meta.warnings)) ws = ws.concat(st.meta.warnings)
    if (ws.length) html += warningsHtml('宿主配置警告', ws)
    var dep = st.meta.dependencies || {}
    if (kind === 'item' && dep.itemData === false) {
      html += noticeHtml('warn', '基础数据插件 data-items 未就绪：清单与日志里只能显示物品 ID 与占位图标（名称与图标解析不可用）。')
    }
    if (kind === 'proj' && dep.projectileData === false) {
      html += noticeHtml('warn', '基础数据插件 data-projectiles 未就绪：清单与日志里只能显示弹幕 ID 与占位图标。')
    }
    return html
  }

  function toolbarHtml(st) {
    var list = buildTierList(tiers(kind), st.meta, entryKey)
    var html = '<div class="ac-btn-group">'
    if (kind === 'item') {
      html += '<button type="button" class="ac-btn" data-ac-act="open-search">' + svg(ICON.search, 13) + '搜索指定物品</button>'
      html += '<button type="button" class="ac-btn" data-ac-act="open-holders">' + svg(ICON.list, 13) + '按物品查持有者</button>'
      html += '<button type="button" class="ac-btn" data-ac-act="scan"' + (scan.loading ? ' disabled' : '') + '>' +
        svg(ICON.crosshair, 13) + (scan.loading ? '扫描中...' : '扫描全部在线玩家') + '</button>'
    }
    html += '<span class="ac-muted" style="font-size:11.5px">共 ' + countTiersWithEntries(list) + ' 个档位有内容、' +
      countEntries(list) + ' 条限制</span>'
    html += '</div>'
    return html
  }

  function cardsHtml(st) {
    var list = buildTierList(tiers(kind), st.meta, entryKey)
    var html = '<div class="ac-card"><div class="ac-card-head">' +
      '<h3>' + (kind === 'item' ? '物品违禁清单' : '弹幕违禁清单') + '</h3>' +
      '<span class="ac-muted" style="font-size:11.5px">按世界进度分档；各档之间是**叠加**生效（服端把所有仍生效档位的清单合并，旧 item-restrict.cs:129-141），不是互斥阶段</span>' +
      '</div><div class="ac-grid">'
    for (var i = 0; i < list.length; i++) html += tierCardHtml(kind, i, list[i], st.meta, errors)
    html += '</div></div>'
    return html
  }

  /** 整页重绘（输入过程中**不**调用它，避免打断输入） */
  function renderAll() {
    if (!root) return
    var st = getState()
    var html = '<div class="ac-wrap">' + noticeAreaHtml()

    if (st.loading && !st.loaded) {
      root.innerHTML = html + '<div class="ac-card"><div class="ac-muted">' + esc(LOADING_TEXT) + '</div></div></div>'
      return
    }
    // ★ 修旧版 I-1：加载失败不再整页空白 —— 给出原因、重试按钮，并说明为什么不允许保存
    if (!st.loaded) {
      html += '<div class="ac-card">'
      html += '<div class="ac-card-head"><div><h3>' + cfg.iconPath + '<span>' + esc(cfg.title) + '</span></h3>' +
        '<p class="ac-desc" style="margin:6px 0 0">' + esc(cfg.subtitle) + '</p></div></div>'
      html += noticeHtml('error', '读取反作弊清单失败：' + (st.error || '未知原因'))
      html += '<div class="ac-row"><button type="button" class="ac-btn accent" data-ac-act="retry">' +
        svg(ICON.refresh, 13) + '重试</button>' +
        '<span class="ac-muted" style="font-size:11.5px">读不到配置时不会用默认清单顶替，也不允许保存（避免用空清单覆盖线上配置）。</span></div>'
      html += '</div></div>'
      root.innerHTML = html
      return
    }

    html += saveBarHtml(st)
    html += warningsAreaHtml(st)
    html += '<div class="ac-card"><div class="ac-card-head"><h3>检测开关</h3>' + toolbarHtml(st) + '</div>' +
      switchesHtml(kind, side(kind)) + '</div>'
    html += cardsHtml(st)
    if (kind === 'item') html += scanPanelHtml(scan)
    html += pushPanelHtml(kind)
    html += '</div>'
    root.innerHTML = html
    bindImageFallback(root)
    bindPushPanel(root, kind)
  }

  /** 只刷新保存栏（输入时用；不动输入框本身，光标不丢） */
  function refreshSaveBar() {
    if (!root) return
    var el = root.querySelector('[data-ac-savebar]')
    if (el) el.innerHTML = saveBarInner(getState())
  }

  // ── 事件 ──

  function idxOf(el) {
    var t = Number(el.getAttribute('data-ac-tier'))
    var i = Number(el.getAttribute('data-ac-idx'))
    return { tier: t, idx: i, ok: Number.isInteger(t) && t >= 0 && Number.isInteger(i) && i >= 0 }
  }

  /** 按进度名定位（必要时新建）真实配置里的档位对象 */
  function ensureTier(progress) {
    var s = side(kind)
    if (!Array.isArray(s['限制列表'])) s['限制列表'] = []
    for (var i = 0; i < s['限制列表'].length; i++) {
      if (String(s['限制列表'][i].进度) === String(progress)) return s['限制列表'][i]
    }
    var one = { 进度: String(progress) }
    one[entryKey] = []
    s['限制列表'].push(one)
    return one
  }

  function onInput(ev) {
    var el = ev.target
    if (!el || typeof el.getAttribute !== 'function') return
    var act = el.getAttribute('data-ac-act')
    if (!act) return
    var st = getState()
    if (!st.loaded) return

    if (act === 'entry-id' || act === 'entry-stack' || act === 'entry-command') {
      var at = idxOf(el)
      if (!at.ok) return
      var list = buildTierList(tiers(kind), st.meta, entryKey)
      var info = list[at.tier]
      if (!info) return
      var raw = el.value
      mutateSilent(function () {
        var tier = ensureTier(info.进度)
        var arr = tier[entryKey]
        if (!arr[at.idx]) return
        if (act === 'entry-id') arr[at.idx].id = (raw === '' ? '' : toIntOrNull(raw))
        else if (act === 'entry-stack') arr[at.idx].stack = (raw === '' ? '' : toIntOrNull(raw))
        else arr[at.idx].command = String(raw)
      })
      if (act === 'entry-id') {
        var holder = root.querySelector('[data-ac-preview="' + at.tier + '-' + at.idx + '"]')
        if (holder) holder.innerHTML = previewHtml(kind, raw)
      }
      refreshSaveBar()
      return
    }

    if (act === 'sw-interval' || act === 'sw-damage') {
      var key = (act === 'sw-interval') ? '扫描间隔' : '伤害上限'
      var v = el.value
      mutateSilent(function (c) { c[kind][key] = (v === '' ? '' : toIntOrNull(v)) })
      refreshSaveBar()
    }
  }

  function onChange(ev) {
    var el = ev.target
    if (!el || typeof el.getAttribute !== 'function') return
    var act = el.getAttribute('data-ac-act')
    var st = getState()
    if (!act || !st.loaded) return
    if (act === 'sw-enable' || act === 'sw-autoscan' || act === 'sw-confiscate') {
      var key = act === 'sw-enable' ? '启用' : (act === 'sw-autoscan' ? '自动扫描' : '没收违禁物品')
      var checked = el.checked === true
      mutateSilent(function (c) { c[kind][key] = checked })
      refreshSaveBar()
    }
  }

  function onClick(ev) {
    var el = ev.target && typeof ev.target.closest === 'function' ? ev.target.closest('[data-ac-act]') : null
    if (!el || !root || !root.contains(el)) return
    var act = el.getAttribute('data-ac-act')
    var st = getState()

    if (act === 'retry') return doLoad(true)
    if (act === 'reload') {
      if (st.dirty && !window.confirm('重新载入会用服务端配置覆盖你未保存的修改，继续？')) return
      return doLoad(true)
    }
    if (act === 'discard') {
      if (st.dirty && !window.confirm('放弃当前所有未保存的修改？')) return
      discard()
      return renderAll()
    }
    if (act === 'save') return doSave()
    if (act === 'scan') return doScan()
    if (act === 'open-search') return openPicker({ mode: 'browse' })
    if (act === 'open-holders') return openPicker({ mode: 'holders' })
    if (act === 'push-refresh' || act === 'push-now' || act === 'push-pending' || act === 'defaults-preview' ||
        act === 'defaults-apply' || act === 'audit-refresh') {
      // 下发/默认清单/审计面板由 shared/panel.js 自己处理（它绑定在同一容器上）
      return
    }
    if (act === 'tier-add') {
      return openPicker({ mode: 'add', tierIndex: Number(el.getAttribute('data-ac-tier')), multi: true })
    }

    if (!st.loaded) return
    var at = idxOf(el)
    if (!at.ok) return
    var list = buildTierList(tiers(kind), st.meta, entryKey)
    var info = list[at.tier]
    if (!info) return

    if (act === 'entry-method') {
      var m = String(el.getAttribute('data-ac-method'))
      mutate(function () {
        var tier = ensureTier(info.进度)
        if (!tier[entryKey][at.idx]) return
        tier[entryKey][at.idx].method = m
      })
      return renderAll()
    }
    if (act === 'entry-quick') {
      var qc = quickListOf(kind, st.meta)[Number(el.getAttribute('data-ac-qc'))]
      if (!qc) return
      mutate(function () {
        var tier = ensureTier(info.进度)
        var e = tier[entryKey][at.idx]
        if (!e) return
        // 旧版 insertQuickCommand 直接覆盖 method（规格 B §3.6(e) :587），本件照旧：
        // 模板自带引号，占位符转义只处理 \ 与 "（config.js:73-77 逐字说明了原因）。
        e.method = String(qc.method)
        e.command = String(qc.template)
      })
      return renderAll()
    }
    if (act === 'entry-del') {
      if (!window.confirm('删除这一条违禁记录？（保存后立即对游戏服生效）')) return
      mutate(function () {
        var tier = ensureTier(info.进度)
        tier[entryKey].splice(at.idx, 1)
      })
      return renderAll()
    }
    if (act === 'entry-search') {
      return openPicker({ mode: 'entry', tierIndex: at.tier, entryIndex: at.idx })
    }
  }

  function bindEvents(container) {
    bindDelegated(container, [
      ['click', 'acClick', onClick],
      ['input', 'acInput', onInput],
      ['change', 'acChange', onChange],
    ])
  }

  // ── 动作 ──

  async function doLoad(force) {
    await loadConfig({ force: force === true })
    renderAll()
  }

  async function doSave() {
    errors = validateEditor(kind)
    if (errors.length) {
      // 先设提示再整页重绘：setNotice 只通知保存栏，重绘后提示条才会出现在页面顶部
      setNotice('error', '有 ' + errors.length + ' 处未通过校验，已阻止保存（见下方清单与标红的输入框）。')
      return renderAll()
    }
    var st = getState()
    // 提交前把编辑器顺序与"未知档位保留"规则写回配置（见 buildTierPayload 的四条理由）
    mutateSilent(function (c) {
      c[kind]['限制列表'] = buildTierPayload(kind, buildTierList(c[kind]['限制列表'], st.meta, entryKey))
    })
    saving = true
    renderAll()
    await save()
    saving = false
    errors = []
    return renderAll()
  }

  async function doScan() {
    scan = { loading: true, result: null, error: '' }
    renderAll()
    var sid = currentServerId()
    // 这是**单服动作**（宿主 requireSingleServer，index.js:677-690）：多台启用服时必须显式指定，
    // 否则宿主会回 400「有 N 台启用中的服务器，请显式指定 serverId」。所以带上当前选中的服。
    var res = await post(API.scan, sid ? { serverId: sid } : {})
    if (!res.ok) {
      scan = { loading: false, result: null, error: errText(res, '扫描失败') }
    } else {
      var d = res.data || {}
      scan = {
        loading: false,
        error: '',
        result: Object.assign({}, d.scan || {}, { serverId: d.serverId, serverName: d.serverName }),
      }
    }
    return renderAll()
  }

  /**
   * 打开选择器对话框。
   *   mode 'add'     批量加入某档位（多选；旧版「批量添加」的等价物）
   *   mode 'entry'   单选覆盖某行的 id（**不动 stack/method**，与旧版 openItemSearch 一致）
   *   mode 'browse'  浏览（可加入指定档位 / 查持有者；对应旧版工具栏「搜索指定物品」）
   *   mode 'holders' 按物品查持有者（对应旧版「按物品查持有者」，走 /api/anticheat/scan-by-id）
   */
  function openPicker(opts) {
    var st = getState()
    if (!st.loaded) return
    var o = opts || {}
    var list = buildTierList(tiers(kind), st.meta, entryKey)
    var progress = (o.tierIndex != null && list[o.tierIndex]) ? list[o.tierIndex].进度 : (list[0] ? list[0].进度 : '')
    if (dialog) {
      dialog.close()
      dialog = null
    }
    dialog = openSearchDialog({
      kind: kind,
      mode: o.mode,
      multi: o.multi === true,
      tiers: list.map(function (t) { return t.进度 }),
      defaultProgress: progress,
      onClose: function () { dialog = null },
      onPick: function (picked, chosenProgress) {
        // 返回值**据实核对**：加不进去就回失败，绝不假装成功（旧版 I-11 正是"动画成功但什么都没加"）
        if (!picked || !picked.length) return { ok: false, error: '没有选中任何条目' }
        if (o.mode === 'entry') {
          var rowInfo = list[o.tierIndex]
          if (!rowInfo) return { ok: false, error: '目标档位已不存在（配置可能已重新载入）' }
          var okOne = false
          mutate(function () {
            var tier = ensureTier(rowInfo.进度)
            var e = tier[entryKey][o.entryIndex]
            if (!e) return
            e.id = toIntOrNull(picked[0].id)
            okOne = true
          })
          renderAll()
          return okOne ? { ok: true, added: 1 } : { ok: false, error: '目标行已不存在（列表可能已变化）' }
        }
        var target = String(chosenProgress || progress || '')
        if (!target) return { ok: false, error: '没有可加入的档位' }
        var added = 0
        var skipped = 0
        mutate(function () {
          var tier = ensureTier(target)
          for (var i = 0; i < picked.length; i++) {
            var id = toIntOrNull(picked[i].id)
            if (id === null || id < ID_MIN) { skipped++; continue }
            // 去重口径照旧版批量路径（按 id 去重、跳过 0/空，规格 B §3.6(e) :592）
            var dup = false
            for (var j = 0; j < tier[entryKey].length; j++) {
              if (toIntOrNull(tier[entryKey][j].id) === id) { dup = true; break }
            }
            if (dup) { skipped++; continue }
            var one = defaultEntry(kind)
            one.id = id
            tier[entryKey].push(one)
            added++
          }
        })
        renderAll()
        if (added === 0) return { ok: false, error: '没有新增条目（' + (skipped ? skipped + ' 条 ID 非法或在该档位里已存在' : '未选中有效条目') + '）' }
        return { ok: true, added: added, skipped: skipped }
      },
    })
  }

  // ── 视图挂载 ──

  function render(container) {
    root = container
    errors = []
    injectStyle()   // 幂等：style.js 用模块级标志位保证只注入一次
    if (unsubscribe) unsubscribe()
    unsubscribe = subscribe(function () { refreshSaveBar() })
    bindEvents(container)
    renderAll()
    // 字典是静态 JSON（/plugins/data-items/client/ID.json 等），载入后重绘一次把名称与图标填上；
    // 载入失败只降级为"只显示 ID"，不影响页面本身（shared/api.js 的 loadItemDict/loadProjDict）
    var p = (kind === 'item') ? loadItemDict() : loadProjDict()
    Promise.resolve(p).then(function () { renderAll() })
    doLoad(false)
  }

  return { render: render, validate: function () { return validateEditor(kind) } }
}
