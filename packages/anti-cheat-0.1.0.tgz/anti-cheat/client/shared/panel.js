/**
 * anti-cheat 前端半 —— 下发状态 / 默认清单 / 审计流水（两个配置页共用的面板）
 *
 * 文件名说明：本模块原计划叫 push-panel.js，与 shared/ 下其它模块（api/store/method/progress/
 * search/style/tier-editor）同为单层命名，这里就叫 panel.js。它导出的 pushPanelHtml/bindPushPanel
 * 是页面调用的入口。
 *
 * ══════════ 这一块为什么必须有 ══════════
 * 宿主的这几条路由是**为界面准备的**，且自述了它们的用途：
 *   - `GET /api/anticheat/status`：注释原文就写着「对外状态（`/api/anticheat/status` 与前端「下发状态」卡）」
 *     （plugins/anti-cheat/index.js:408）；它还带 `probe` —— 逐服探测"服端实际生效的配置"并与宿主比对
 *     （index.js:433-435 自述这是"界面写了什么"与"服端真的按什么在检测"之间的唯一直接证据）。
 *   - `POST /api/anticheat/push`：手动重推（index.js:797-811）。
 *   - `GET /api/anticheat/defaults` + `POST /api/anticheat/apply-defaults`：默认清单的预览与应用，
 *     **必须显式 confirm 才写**（index.js:758-787；index.js:743-745 说明读不到默认清单时端点
 *     明确回 501，绝不回一个空清单让管理员点下去把配置清空）。
 *   - `GET /api/anticheat/audit`：本件审计流水（index.js:877-879）。旧版**没有任何审计**
 *     （规格 B §5.4 逐字："后端无持久化状态……也没有审计记录"），所以旧版前端也没有这一块。
 *
 * 旧版前端**没有**这个面板；本件加上它，是为了让"保存成功"不再等于"已经生效"：
 * 旧版点保存只看到一句成功提示，没有任何证据说明游戏服真的按新清单在检测。
 * 面板本身不改动任何配置字段，所以不影响旧版三页的字段语义。
 *
 * ══════════ 「应用默认清单」的语义（对齐 host）══════════
 *   - 默认**只替换限制列表**，不动开关（host applyDefaults 的语义，defaults.js:246-254 逐字说明）；
 *   - preview 会列出"会新增的档位/会消失的档位/条数变化/开关变化"（defaults.js:205-235）；
 *   - 应用前必须二次确认，且**预检本地是否有未保存修改**（否则本地编辑会被服务端写盘的结果覆盖）。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import { esc, svg, ICON, API, get, post, errText, noticeHtml, warningsHtml, fmtTime, req } from './api.js'
import { getState, loadConfig, setNotice, pushText } from './store.js'

/** 面板状态（模块级：同一时刻只有一个反作弊页可见，故不按 kind 分开存） */
var st = {
  kind: 'item',
  loading: false,
  error: '',
  status: null,
  pushBusy: false,
  pushNotice: '',
  defaults: null,
  defaultsBusy: false,
  defaultsNotice: '',
  audit: null,
  auditLoading: false,
  auditError: '',
}

/** 逐服状态行：优先用 probe（它带 match/diff），probe 不可用时退回 pushStatus */
function serverRows(status) {
  var rows = []
  var probe = status && status.probe
  var probedList = probe && Array.isArray(probe.servers) ? probe.servers : null
  if (probedList) {
    for (var i = 0; i < probedList.length; i++) {
      var p = probedList[i] || {}
      rows.push({
        id: String(p.id),
        name: String(p.name || p.id),
        ok: p.ok === true,
        match: p.match === true,
        diff: Array.isArray(p.diff) ? p.diff : [],
        error: String(p.error || ''),
        serverHalfMissing: p.serverHalfMissing === true,
        from: 'probe',
      })
    }
    return rows
  }
  var list = status && Array.isArray(status.servers) ? status.servers : []
  for (var k = 0; k < list.length; k++) {
    var s = list[k] || {}
    rows.push({
      id: String(s.id),
      name: String(s.name || s.id),
      ok: s.ok === true,
      match: false,
      diff: [],
      error: String(s.error || ''),
      serverHalfMissing: s.serverHalfMissing === true,
      from: 'push',
    })
  }
  return rows
}

function statusHtml() {
  var cfg = getState()
  var html = '<div class="ac-card" data-ac-pushblock="status">'
  html += '<div class="ac-card-head"><h3>下发状态</h3><div class="ac-btn-group">' +
    '<button type="button" class="ac-btn" data-ac-act="push-refresh"' + (st.loading ? ' disabled' : '') + '>' +
    svg(ICON.refresh, 13) + (st.loading ? '刷新中...' : '刷新状态') + '</button>' +
    '<button type="button" class="ac-btn" data-ac-act="push-now"' + (st.pushBusy ? ' disabled' : '') + '>' +
    svg(ICON.send, 13) + (st.pushBusy ? '下发中...' : '立即下发') + '</button>' +
    // 仅补推未确认的服务器：对应宿主 POST /api/anticheat/push 的 onlyPending（index.js:807-808）。
    // 待确认台数很多时，"只补推没生效的那几台"比"整批重推"更安全（不打扰已生效的服）。
    '<button type="button" class="ac-btn" data-ac-act="push-pending"' + (st.pushBusy ? ' disabled' : '') + '>' +
    svg(ICON.refresh, 13) + '仅补推未确认</button>' +
    '</div></div>'

  html += '<p class="ac-desc">这里显示的是服端实际生效的配置与宿主配置的比对（宿主 probe 自证）：' +
    '「保存成功」只代表提交成功，不代表游戏服已经按它检测。</p>'

  if (st.error) html += noticeHtml('error', st.error)
  if (st.pushNotice) html += noticeHtml('info', st.pushNotice)

  if (!st.status) {
    html += '<div class="ac-empty">' + (st.loading ? '读取中...' : '点「刷新状态」读取逐服下发状态') + '</div>'
  } else {
    var s = st.status
    html += '<div class="ac-muted" style="font-size:11.5px;margin:4px 0 8px">' +
      '期望版本 v' + esc(s.desiredVersion) + '；待确认 ' + esc(s.pendingCount || 0) + ' 台' +
      (s.retryScheduled ? '（已安排自动重试）' : '') +
      (s.pendingServerIds && s.pendingServerIds.length ? '：' + esc(s.pendingServerIds.join('、')) : '') +
      '</div>'
    var rows = serverRows(s)
    if (!rows.length) {
      html += '<div class="ac-empty">没有启用中的服务器</div>'
    } else {
      html += '<table class="ac-table"><thead><tr><th>服务器</th><th>下发</th><th>服端是否一致</th><th>说明</th></tr></thead><tbody>'
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i]
        var badge = r.ok
          ? '<span class="ac-badge ok">已下发</span>'
          : '<span class="ac-badge err">未生效</span>'
        var match = r.from === 'probe'
          ? (r.match ? '<span class="ac-badge ok">一致</span>' : '<span class="ac-badge warn">有差异</span>')
          : '<span class="ac-muted">未探测</span>'
        var why = []
        if (r.error) why.push(r.error)
        if (r.serverHalfMissing) why.push('该服未安装 AntiCheat.dll')
        if (r.diff && r.diff.length) why.push('差异：' + r.diff.slice(0, 4).join('；'))
        html += '<tr><td>' + esc(r.name) + '</td><td>' + badge + '</td><td>' + match + '</td><td>' +
          (why.length ? esc(why.join(' / ')) : '<span class="ac-muted">-</span>') + '</td></tr>'
      }
      html += '</tbody></table>'
    }
    if (s.probe && s.probe.error) html += noticeHtml('warn', 'probe 探测失败：' + s.probe.error)
    if (Array.isArray(s.warnings) && s.warnings.length) html += warningsHtml('宿主清单警告', s.warnings)
    html += '<div class="ac-muted" style="font-size:11.5px;margin-top:8px">配置文件：<span class="ac-mono">' +
      esc(cfg.meta.configFile || s.configFile || '-') + '</span></div>'
  }
  return html + '</div>'
}

/** 默认清单预览表的渲染（字段名是 host 原样回的中文键，见 defaults.js:218-227） */
function kindsHtml(preview) {
  if (!preview || !preview.kinds) return ''
  var kinds = Object.keys(preview.kinds)
  var html = ''
  for (var i = 0; i < kinds.length; i++) {
    var k = kinds[i]
    var v = preview.kinds[k] || {}
    html += '<div style="margin-top:8px"><strong>' + esc(k === 'item' ? '物品侧' : '弹幕侧') +
      '</strong><ul class="ac-diff" style="margin:4px 0 0;padding-left:18px">'
    html += '<li>档位：现在 ' + esc((v.档位_现在 || []).join('、') || '（空）') + ' → 应用后 ' +
      esc((v.档位_应用后 || []).join('、') || '（空）') + '</li>'
    if ((v.新增档位 || []).length) html += '<li>会新增档位：' + esc(v.新增档位.join('、')) + '</li>'
    if ((v.消失档位 || []).length) {
      html += '<li style="color:#d97706">会消失档位：' + esc(v.消失档位.join('、')) +
        '（这些档位里的自定义条目会被默认清单替换掉）</li>'
    }
    html += '<li>条数：' + esc(v.条数_现在) + ' → ' + esc(v.条数_应用后) + '</li>'
    if ((v.开关变化 || []).length) {
      html += '<li>开关变化：' + esc(v.开关变化.map(function (x) {
        return x.字段 + ' ' + x.现在 + ' → ' + x.应用后
      }).join('；')) + '</li>'
    } else {
      html += '<li>开关：不变（默认不动开关，defaults.js:246-254）</li>'
    }
    html += '</ul></div>'
  }
  return html
}

function defaultsHtml() {
  var cfg = getState()
  var d = cfg.meta.defaults || {}
  var html = '<div class="ac-card" data-ac-pushblock="defaults">'
  html += '<div class="ac-card-head"><h3>默认清单</h3><div class="ac-btn-group">' +
    '<button type="button" class="ac-btn" data-ac-act="defaults-preview"' + (st.defaultsBusy ? ' disabled' : '') + '>' +
    svg(ICON.list, 13) + (st.defaultsBusy ? '读取中...' : '预览默认清单') + '</button>' +
    '<button type="button" class="ac-btn danger" data-ac-act="defaults-apply"' + (st.defaultsBusy ? ' disabled' : '') + '>' +
    svg(ICON.down, 13) + '应用默认清单（本侧）</button>' +
    '</div></div>'

  html += '<p class="ac-desc">默认清单来自插件包内的 <span class="ac-mono">resources/</span>；' +
    '应用只替换本侧的「限制列表」，不动开关；应用前会先给出预览并二次确认，全过程写入审计。</p>'

  var stats = d.stats
  if (stats) {
    html += '<div class="ac-muted" style="font-size:12px;line-height:1.9">默认清单规模：物品 ' +
      esc(stats.itemTiers) + ' 档 / ' + esc(stats.itemEntries) + ' 条；弹幕 ' +
      esc(stats.projTiers) + ' 档 / ' + esc(stats.projEntries) + ' 条。</div>'
  } else if (d.error) {
    // host 在默认清单不可用时**明确失败**（index.js:743-745）：这里照实说，不显示成"0 条"
    html += noticeHtml('error', '默认清单不可用：' + d.error)
  }
  if (d.files) {
    html += '<div class="ac-muted" style="font-size:11.5px;line-height:1.9">来源文件：<span class="ac-mono">' +
      esc(d.files.item || '') + '</span>；<span class="ac-mono">' + esc(d.files.proj || '') + '</span></div>'
  }
  if (Array.isArray(d.fixes) && d.fixes.length) {
    html += '<details style="margin-top:6px;font-size:12px"><summary style="cursor:pointer">默认清单里包含的数据修正（' +
      d.fixes.length + ' 项）</summary><ul class="ac-diff" style="margin:6px 0 0;padding-left:18px">' +
      d.fixes.map(function (f) {
        return '<li>' + esc(f.id || '') + '：' + esc(f.note || f.说明 || '') + '</li>'
      }).join('') + '</ul></details>'
  }
  if (Array.isArray(d.deferred) && d.deferred.length) {
    html += '<details style="margin-top:6px;font-size:12px"><summary style="cursor:pointer">已决定不做的数据修正（' +
      d.deferred.length + ' 项）</summary><ul class="ac-diff" style="margin:6px 0 0;padding-left:18px">' +
      d.deferred.map(function (f) {
        return '<li>' + esc(f.id || '') + '：' + esc(f.note || f.说明 || f.reason || '') + '</li>'
      }).join('') + '</ul></details>'
  }
  if (Array.isArray(d.warnings) && d.warnings.length) html += warningsHtml('默认清单警告', d.warnings)

  if (st.defaultsNotice) html += noticeHtml('info', st.defaultsNotice)
  if (st.defaults) {
    html += '<div style="margin-top:10px;font-size:12.5px">预览（范围：' +
      esc(st.defaults.scope === 'both' ? '两侧' : st.defaults.scope === 'item' ? '物品侧' : '弹幕侧') +
      '；开关：' + (st.defaults.includeSwitches ? '会一并改动' : '不动') + '）' +
      kindsHtml(st.defaults.preview) + '</div>'
  }
  return html + '</div>'
}

function auditHtml() {
  var html = '<div class="ac-card" data-ac-pushblock="audit">'
  html += '<div class="ac-card-head"><h3>审计流水</h3>' +
    '<button type="button" class="ac-btn" data-ac-act="audit-refresh"' + (st.auditLoading ? ' disabled' : '') + '>' +
    svg(ICON.refresh, 13) + (st.auditLoading ? '读取中...' : '刷新审计') + '</button></div>'
  html += '<p class="ac-desc">谁在什么时候改了清单、点了下发或应用默认清单，都记在这里（旧版完全没有审计）。</p>'
  if (st.auditError) html += noticeHtml('error', st.auditError)
  if (!st.audit) {
    html += '<div class="ac-empty">点「刷新审计」读取最近 20 条</div>'
  } else if (!st.audit.length) {
    html += '<div class="ac-empty">暂无审计记录</div>'
  } else {
    html += '<table class="ac-table"><thead><tr><th>时间</th><th>动作</th><th>操作者</th><th>摘要</th></tr></thead><tbody>'
    for (var i = 0; i < st.audit.length; i++) {
      var r = st.audit[i] || {}
      var summary = []
      if (r.changedKeys && r.changedKeys.length) summary.push('改动：' + r.changedKeys.join('、'))
      if (r.scope) summary.push('范围：' + r.scope)
      if (r.total !== undefined) summary.push('结果条数：' + r.total)
      if (r.action2) summary.push('来源：' + r.action2)
      if (r.serverId) summary.push('服务器：' + r.serverId)
      if (r.raw) summary.push(String(r.raw).slice(0, 120))
      html += '<tr><td style="white-space:nowrap">' + esc(fmtTime(r.t)) + '</td>' +
        '<td>' + esc(r.action || '-') + '</td>' +
        '<td>' + esc(r.actor || '-') + '</td>' +
        '<td>' + (summary.length ? esc(summary.join('；')) : '<span class="ac-muted">-</span>') + '</td></tr>'
    }
    html += '</tbody></table>'
  }
  return html + '</div>'
}

/** 面板 HTML（由页面拼进自己的整体 HTML 里） */
export function pushPanelHtml(kind) {
  st.kind = kind === 'proj' ? 'proj' : 'item'
  return '<div data-ac-pushpanel="1">' + statusHtml() + defaultsHtml() + auditHtml() + '</div>'
}

/** 只重绘面板（不触碰页面其它部分） */
function refreshPanel(root) {
  if (!root) return
  var holder = root.querySelector('[data-ac-pushpanel]')
  if (!holder) return
  holder.innerHTML = statusHtml() + defaultsHtml() + auditHtml()
}

// ── 动作 ──

async function loadStatus(root) {
  st.loading = true
  st.error = ''
  refreshPanel(root)
  var res = await get(API.status)
  st.loading = false
  if (!res.ok) st.error = errText(res, '读取下发状态失败')
  else st.status = res.data || null
  refreshPanel(root)
}

async function doPush(root, onlyPending) {
  st.pushBusy = true
  st.pushNotice = ''
  refreshPanel(root)
  // 不带 serverIds = 未指定（按模式默认：全部启用服）；onlyPending=true 只补推未确认的服务器。
  // 语义见约定（docs/插件开发约定.md:49）与 plugins/anti-cheat/index.js:797-811
  var res = await post(API.push, onlyPending === true ? { onlyPending: true } : {})
  st.pushBusy = false
  if (!res.ok) {
    st.error = errText(res, '下发失败')
  } else {
    st.pushNotice = (onlyPending === true ? '补推未确认服务器完成' : '手动重推完成') +
      pushText((res.data || {}).push || {})
    st.error = ''
  }
  await loadStatus(root)
}

async function loadDefaultsPreview(root) {
  st.defaultsBusy = true
  st.defaultsNotice = ''
  refreshPanel(root)
  // scope 交给 host 的默认值（both，index.js:753）：这里要如实展示"应用后会发生什么"
  var res = await get(API.defaults)
  st.defaultsBusy = false
  if (!res.ok) st.defaultsNotice = '读取默认清单失败：' + errText(res, '未知原因')
  else st.defaults = res.data || null
  refreshPanel(root)
}

async function applyDefaults(root) {
  var cfg = getState()
  if (cfg.dirty) {
    st.defaultsNotice = '当前有未保存的修改：请先「保存配置」或「放弃修改」，再应用默认清单（否则本地修改会被服务端写盘的结果覆盖）。'
    return refreshPanel(root)
  }
  st.defaultsBusy = true
  st.defaultsNotice = ''
  refreshPanel(root)

  // 第一步：不带 confirm —— 按 host 契约这**只回预览、不写任何东西**（index.js:766-769）
  var pre = await post(API.applyDefaults, { scope: st.kind })
  if (!pre.ok) {
    st.defaultsBusy = false
    st.defaultsNotice = '应用默认清单失败（预览阶段）：' + errText(pre, '未知原因')
    return refreshPanel(root)
  }
  var preview = (pre.data || {}).preview
  st.defaults = { scope: st.kind, includeSwitches: false, preview: preview }
  refreshPanel(root)

  var kinds = (preview && preview.kinds) ? preview.kinds : {}
  var v = kinds[st.kind] || {}
  var msg = '应用默认清单会替换「' + (st.kind === 'item' ? '物品侧' : '弹幕侧') + '」的全部限制列表：\n' +
    '条数 ' + (v.条数_现在 === undefined ? '?' : v.条数_现在) + ' → ' + (v.条数_应用后 === undefined ? '?' : v.条数_应用后) + '\n' +
    ((v.消失档位 || []).length ? '会消失的档位：' + v.消失档位.join('、') + '\n' : '') +
    '（开关不会被改动；本操作会写入审计）\n\n确认继续？'
  if (!window.confirm(msg)) {
    st.defaultsBusy = false
    st.defaultsNotice = '已取消，未改动任何配置。'
    return refreshPanel(root)
  }

  // 第二步：带 confirm=true 才真的写（index.js:766-786）
  var res = await post(API.applyDefaults, { scope: st.kind, confirm: true })
  st.defaultsBusy = false
  if (!res.ok) {
    st.defaultsNotice = '应用默认清单失败：' + errText(res, '未知原因')
    return refreshPanel(root)
  }
  var d = res.data || {}
  st.defaultsNotice = '已应用默认清单（' + ((d.changes || []).length) + ' 项改动）' + pushText(d.push)
  // 服务端已改配置：本地基线与编辑必须重新对齐（本地有脏修改时上面已拦下）
  await loadConfig({ force: true })
  setNotice('ok', st.defaultsNotice)
  refreshPanel(root)
}

async function loadAudit(root) {
  st.auditLoading = true
  st.auditError = ''
  refreshPanel(root)
  var res = await req(API.audit + '?limit=20', { method: 'GET' })
  st.auditLoading = false
  if (!res.ok) st.auditError = errText(res, '读取审计失败')
  else st.audit = Array.isArray((res.data || {}).rows) ? res.data.rows : []
  refreshPanel(root)
}

/**
 * 绑定面板事件（**先按同一引用解绑再绑**，理由同 status-panel：
 * plugins/status-panel/client/status-panel.js:1778-1801 —— 宿主的 route() 每次进入都调
 * render(container)，而 container 是常驻节点，无条件下 addEventListener 会随访问次数累加）。
 */
export function bindPushPanel(root, kind) {
  if (!root) return
  st.kind = kind === 'proj' ? 'proj' : 'item'
  if (root.__acPushClick) root.removeEventListener('click', root.__acPushClick)
  root.__acPushClick = function (ev) {
    var el = ev.target && typeof ev.target.closest === 'function' ? ev.target.closest('[data-ac-act]') : null
    if (!el || !root.contains(el)) return
    var act = el.getAttribute('data-ac-act')
    if (['push-refresh', 'push-now', 'push-pending', 'defaults-preview', 'defaults-apply', 'audit-refresh'].indexOf(act) < 0) return
    ev.preventDefault()
    try {
      if (act === 'push-refresh') return void loadStatus(root)
      if (act === 'push-now') return void doPush(root, false)
      if (act === 'push-pending') return void doPush(root, true)
      if (act === 'defaults-preview') return void loadDefaultsPreview(root)
      if (act === 'defaults-apply') return void applyDefaults(root)
      if (act === 'audit-refresh') return void loadAudit(root)
    } catch (err) {
      st.error = (err && err.message) || String(err)
      refreshPanel(root)
    }
  }
  root.addEventListener('click', root.__acPushClick)
}
