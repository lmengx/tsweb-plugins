/**
 * anti-cheat 前端半 —— 检测日志页（对应旧 AntiCheatLogView.vue，379 行）
 *
 * 页面文案与映射**逐字对齐旧版**（规格 B §3.3(a)(b)(c) 的逐字表，出处见每条注释）：
 *   标题 `反作弊日志`；副标题 `每次反作弊检测命中自动记录（物品 / 弹幕 / 粒子），存储于服务器 AntiCheatLog.sqlite`
 *   8 张统计卡：累计检测 / 今日检测 / 物品违禁 / 弹幕违禁 / 粒子拦截 / 封禁 / 踢出 / 丢弃拦截
 *   筛选：全部分类 / 全部处理方式 / 玩家名 / ~ / 关键字（物品/详情） / 查询 / 重置 / 刷新
 *   6 列：时间 玩家 分类 目标 处理 详情；空态 `暂无反作弊检测日志`；分页 `共 N 条` `‹ 上一页` `x / y` `下一页 ›`
 *   每页 `20/页` `50/页` `100/页`（默认 50）
 *   分类映射 item物品 / proj弹幕 / particle粒子；处理映射 log记录 / kick踢出 / ban封禁 / drop丢弃 / exempt豁免 / query查询
 *
 * ══════════ 与旧版的有意差异（逐条给理由）══════════
 *   1. **多服务器**：新宿主是多服架构（logs.js:6-11 自述），日志页必须能选"全部服务器（聚合）"或单台。
 *      聚合分页是**近似的**（logs.js:17-23），所以界面把 `approximate`/`note`/逐服失败
 *      明确显示出来，绝不静默给一个"看起来完整"的列表。
 *   2. **某台服失败必须可见**：宿主逐服返回 `servers[{ok,error,serverHalfMissing}]`（logs.js:176-199），
 *      本件把它显示成一条告警（旧版是单库单服，没有这个面）。
 *   3. **统计与筛选联动**（修 D-25）：旧版统计端点不接受筛选参数（旧 AntiCheatLog.cs:273 无参），
 *      筛了玩家之后统计卡仍是全服数字，极易误读。本件把同一套筛选传给 /logs/stats，
 *      并按宿主回的 `filtered` 标注「（已按当前筛选）」。
 *   4. **method 下拉补上 `query`**（修 D-22）：旧版 methodLabels 定义了 query:'查询'，
 *      但下拉里没有该选项（规格 B §3.3(b) :404 逐字指出）。本件按 methodLabels 全量生成选项，
 *      并把当前页里出现的**其它未知 method**也补进选项，避免"库里有、界面选不到"。
 *   5. **分页越界保护**（修 §3.3(g) #7）：筛选后总数变小而页码停在旧值时，旧版显示空列表 + 空态提示。
 *      本件检测到 `page > totalPages` 就自动回退到最后一页并重查。
 *   6. **详情可展开**（修 §3.3(g) #3）：旧版 detail 只有 ellipsis + title 悬浮。长详情在触屏/窄屏下
 *      完全看不到，本件用 `<details>` 提供展开。
 *   7. **显示服务器名**（多服架构的必然要求）：仍保持 6 列（时间/玩家/分类/目标/处理/详情），
 *      服务器名作为时间列下方的小字附注，而不是新增一列。
 *   8. **自动刷新**（修 §3.3(g) #5「无自动刷新」）：提供 10 秒自动刷新开关，默认关；
 *      切走页面时会自动停（views 没有卸载钩子，宿主的 route() 不使用 render 的返回值
 *      —— plugins/web/public/app.js:385 直接调用、不接收返回值，所以用 hashchange 兜底）。
 *   9. 旧的 `formatTime` 是恒等函数（§3.3(g) #1）；本件保持"不臆造时区转换"的口径，
 *      但在页面上明确标注**时间是游戏服本地时间**（宿主也为此回了 timeBasis='server-local'，logs.js:218）。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import {
  esc, svg, ICON, get, errText, dataOf, qs, noticeHtml, fmtTime, bindDelegated, bindImageFallback,
  projNameOf, loadProjDict, loadServers, API, LOADING_TEXT,
} from './shared/api.js'
import { injectStyle, shellHtml } from './shared/style.js'

/** 分类映射（逐字：旧 AntiCheatLogView.vue:45-49，规格 B §3.3(b)） */
export var CATEGORY_LABELS = { item: '物品', proj: '弹幕', particle: '粒子' }
/** 分类色（逐字：旧 :60-65，规格 B §3.3(b)） */
export var CATEGORY_COLORS = { item: '#6366f1', proj: '#f59e0b', particle: '#ec4899' }
/** 处理方式映射（逐字：旧 :51-58，规格 B §3.3(b)） */
export var METHOD_LABELS = { log: '记录', kick: '踢出', ban: '封禁', drop: '丢弃', exempt: '豁免', query: '查询' }
/** 处理方式色（逐字：旧 :67-73，规格 B §3.3(b)） */
export var METHOD_COLORS = { ban: '#ef4444', kick: '#f97316', drop: '#eab308', exempt: '#22c55e' }
/** 兜底色（旧 :64/:72 的 `|| '#94a3b8'` / `|| '#64748b'`） */
var CATEGORY_FALLBACK = '#94a3b8'
var METHOD_FALLBACK = '#64748b'

/** 每页条数选项（逐字：旧 :278-280 的 `20/页` `50/页` `100/页`） */
export var PAGE_SIZES = [20, 50, 100]
/** 默认每页条数（旧 :31 的 `pageSize = 50`；宿主也把 50 当默认，logs.js:164） */
export var DEFAULT_PAGE_SIZE = 50
/** 自动刷新间隔（毫秒） */
export var AUTO_REFRESH_MS = 10000

/** 分类显示名 */
export function categoryText(c) {
  return CATEGORY_LABELS[c] || c || '-'
}
export function categoryColor(c) {
  return CATEGORY_COLORS[c] || CATEGORY_FALLBACK
}
/** 处理方式显示名 */
export function methodText(m) {
  return METHOD_LABELS[m] || m || '-'
}
export function methodColor(m) {
  return METHOD_COLORS[m] || METHOD_FALLBACK
}

/**
 * 「目标」列的文本（逐字复刻旧 rowTitle，规格 B §3.3(c) :407-411）：
 *   有 itemName → `[i:{itemId}] {itemName}`
 *   projId > 0  → `弹幕#{projId} {名称}`（名称缺失时只留 `弹幕#{projId}`）
 *   两者皆无    → particle 分类给 `粒子请求`，否则 `检测事件`
 *   多段用 ` / ` 连接
 * 名称来源优先级：宿主已解析的 projName（logs.js:94-100 的字典兜底）→ 本页前端字典（旧版做法）。
 */
export function rowTitle(r) {
  var row = r || {}
  var parts = []
  var itemName = String(row.itemName || '')
  if (itemName !== '') parts.push('[i:' + row.itemId + '] ' + itemName)
  var projId = Number(row.projId) || 0
  if (projId > 0) {
    var pname = String(row.projName || '') || projNameOf(projId)
    parts.push(pname ? ('弹幕#' + projId + ' ' + pname) : ('弹幕#' + projId))
  }
  if (!parts.length) parts.push(String(row.category) === 'particle' ? '粒子请求' : '检测事件')
  return parts.join(' / ')
}

/** 空筛选初值（逐字：旧 :35-42 六个空串） */
export function emptyFilters() {
  return { serverId: '', player: '', category: '', method: '', timeFrom: '', timeTo: '', q: '' }
}

/**
 * 组装查询串（对应旧 buildQuery，:96-117）。
 *   - 空值不下发；`page` 与 `pageSize` **始终下发**（旧 :114-115）；
 *   - 日期只给 `YYYY-MM-DD` 时，**区间是闭区间整天**：from 补 00:00:00、to 补 23:59:59
 *     （旧 :111-112）。宿主的 normalizeTimeRange 也会补（logs.js:133-147），两边同口径。
 *   - `aggregate` 参数**刻意不发**：宿主 resolveLogTargets（index.js:559-569）在未指定 serverId 时
 *     自然就是"全部启用服"，而显式传 aggregate=true 会让**单台服**也走聚合分支并被标成近似
 *     （logs.js:207-239）。不传才能得到"单台=精确、多台=近似"的正确语义。
 */
export function buildLogQuery(filters, page, pageSize) {
  var f = filters || {}
  var p = {}
  if (f.serverId) p.serverId = f.serverId
  if (f.player) p.player = f.player
  if (f.category) p.category = f.category
  if (f.method) p.method = f.method
  if (f.timeFrom) p.timeFrom = /^\d{4}-\d{2}-\d{2}$/.test(f.timeFrom) ? f.timeFrom + ' 00:00:00' : f.timeFrom
  if (f.timeTo) p.timeTo = /^\d{4}-\d{2}-\d{2}$/.test(f.timeTo) ? f.timeTo + ' 23:59:59' : f.timeTo
  if (f.q) p.q = f.q
  p.page = page
  p.pageSize = pageSize
  return qs(p, ['page', 'pageSize'])
}

/** 统计卡（8 张，标签逐字：规格 B §3.3(a) :372-379） */
function statsHtml(stats, filters, statsError) {
  var s = stats || {}
  var byC = s.byCategory || {}
  var byM = s.byMethod || {}
  var cards = [
    [s.total, '累计检测'],
    [s.today, '今日检测'],
    [byC.item, '物品违禁'],
    [byC.proj, '弹幕违禁'],
    [byC.particle, '粒子拦截'],
    [byM.ban, '封禁'],
    [byM.kick, '踢出'],
    [byM.drop, '丢弃拦截'],
  ]
  var html = '<div class="ac-card"><div class="ac-card-head"><h3>统计</h3>' +
    '<span class="ac-muted" style="font-size:11.5px">' +
    (s.filtered ? '已按当前筛选统计（旧版统计恒定是全服数字，无法按条件看）' : '全服总计') + '</span></div>'
  if (statsError) html += noticeHtml('error', '统计加载失败：' + statsError)
  html += '<div class="ac-stats">'
  for (var i = 0; i < cards.length; i++) {
    var v = cards[i][0]
    html += '<div class="ac-stat"><div class="v">' + esc(v === undefined || v === null ? 0 : v) + '</div>' +
      '<div class="k">' + esc(cards[i][1]) + '</div></div>'
  }
  html += '</div>'
  if (s.note) html += noticeHtml('warn', s.note)
  if (s.range && s.range.expanded) {
    html += '<div class="ac-muted" style="font-size:11.5px;margin-top:6px">' +
      '只填了日期的区间已补足为整天（' + esc(s.range.timeFrom || '') + ' ~ ' + esc(s.range.timeTo || '') + '），否则当天的记录会被漏掉。</div>'
  }
  return html + '</div>'
}

/** 逐服查询结果（失败必须可见；成功时给出各服条数） */
function perServerHtml(servers, note, approximate) {
  var list = Array.isArray(servers) ? servers : []
  if (list.length <= 1 && !list.some(function (s) { return s && s.ok === false })) return ''
  var html = '<div class="ac-scan" style="font-size:12px">'
  if (approximate) {
    html += '<div class="ac-muted">当前是**全部服务器的聚合分页**：各服取同一页后按时间归并，跨服边界处可能漏条或重条（宿主 logs.js:17-23 自述）。</div>'
  }
  html += '<ul style="margin:4px 0 0;padding-left:18px">'
  for (var i = 0; i < list.length; i++) {
    var s = list[i] || {}
    if (s.ok) {
      html += '<li>' + esc(s.name) + '：本页 ' + esc(s.rows) + ' 条，库中命中 ' + esc(s.total) + ' 条</li>'
    } else {
      html += '<li style="color:#ef4444">' + esc(s.name) + '：查询失败 —— ' + esc(s.error || '未知原因') +
        (s.serverHalfMissing ? '（该服未安装 AntiCheat.dll）' : '') + '</li>'
    }
  }
  html += '</ul>'
  if (note) html += '<div class="ac-muted" style="margin-top:4px">' + esc(note) + '</div>'
  return html + '</div>'
}

/** 一个筛选下拉（旧版三个 select 的样式一致） */
function selectHtml(act, options, cur) {
  return '<select class="ac-select" data-ac-act="' + act + '">' + options.map(function (o) {
    return '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(cur) ? ' selected' : '') + '>' + esc(o[1]) + '</option>'
  }).join('') + '</select>'
}

function filtersHtml(state, servers, methodOptions) {
  var f = state.filters
  var catOptions = [['', '全部分类'], ['item', '物品'], ['proj', '弹幕'], ['particle', '粒子']]
  var srvOptions = [['', '全部服务器']].concat(servers.map(function (s) {
    return [String(s.id), String(s.name || s.id)]
  }))
  var html = '<div class="ac-card"><div class="ac-card-head"><h3>筛选</h3>' +
    '<span class="ac-muted" style="font-size:11.5px">' +
    (state.timeBasis === 'server-local' ? '时间为**游戏服本地时间**（宿主不做时区转换，logs.js:104-105）' : '') +
    '</span></div>'
  html += '<div class="ac-row">'
  if (servers.length > 1) {
    html += '<span class="ac-label" style="min-width:auto">服务器</span>' + selectHtml('f-server', srvOptions, f.serverId)
  }
  html += '<span class="ac-label" style="min-width:auto">分类</span>' + selectHtml('f-category', catOptions, f.category)
  html += '<span class="ac-label" style="min-width:auto">处理方式</span>' + selectHtml('f-method', methodOptions, f.method)
  html += '</div>'
  html += '<div class="ac-row">' +
    '<input class="ac-input" type="text" data-ac-act="f-player" value="' + esc(f.player) + '" placeholder="玩家名">' +
    '<input class="ac-input" type="date" data-ac-act="f-from" value="' + esc(f.timeFrom) + '" title="起始日期">' +
    '<span class="ac-muted">~</span>' +
    '<input class="ac-input" type="date" data-ac-act="f-to" value="' + esc(f.timeTo) + '" title="结束日期">' +
    '<input class="ac-input ac-input-wide" type="search" data-ac-act="f-q" value="' + esc(f.q) + '" placeholder="关键字（物品/详情）">' +
    '</div>'
  html += '<div class="ac-row"><div class="ac-btn-group">' +
    '<button type="button" class="ac-btn accent" data-ac-act="search">' + svg(ICON.search, 13) + '查询</button>' +
    '<button type="button" class="ac-btn" data-ac-act="reset">重置</button>' +
    '<button type="button" class="ac-btn" data-ac-act="refresh"' + (state.loading ? ' disabled' : '') + '>' +
    svg(ICON.refresh, 13) + '刷新</button>' +
    '</div>' +
    '<label class="ac-switch" style="margin-left:8px" title="每 10 秒自动重查当前筛选（切走页面会自动停）">' +
    '<input type="checkbox" data-ac-act="f-auto"' + (state.auto ? ' checked' : '') + '><span class="ac-slider"></span></label>' +
    '<span class="ac-muted" style="font-size:12px">自动刷新</span>' +
    '</div>'
    if (serversErrorText(state)) html += noticeHtml('warn', serversErrorText(state))
  return html + '</div>'
}

function serversErrorText(state) {
  return state.serversError ? '服务器列表读取失败（' + state.serversError + '），服务器筛选不可用；查询仍按宿主默认目标执行。' : ''
}

function tableHtml(state) {
  var rows = Array.isArray(state.rows) ? state.rows : []
  var html = '<div class="ac-card"><div class="ac-card-head"><h3>检测日志</h3>' +
    '<span class="ac-muted" style="font-size:11.5px">' + esc(state.totalText) + '</span></div>'
  if (state.error) html += noticeHtml('error', '加载失败：' + state.error)
  html += projServersBlock(state)
  if (state.loading && !rows.length) {
    html += '<div class="ac-empty">' + esc(LOADING_TEXT) + '</div>'
    return html + '</div>'
  }
  if (!rows.length) {
    html += '<div class="ac-empty">暂无反作弊检测日志</div>'
    return html + '</div>'
  }
  html += '<table class="ac-table"><thead><tr>' +
    '<th>时间</th><th>玩家</th><th>分类</th><th>目标</th><th>处理</th><th>详情</th>' +
    '</tr></thead><tbody>'
  for (var i = 0; i < rows.length; i++) {
    var r = rows[i] || {}
    var cat = String(r.category || '')
    var mth = String(r.method || '')
    var title = rowTitle(r)
    var detail = String(r.detail || '')
    html += '<tr>'
    html += '<td style="white-space:nowrap">' + esc(fmtTime(r.time)) +
      // 服务器名附注（多服架构必需；仍保持 6 列，见文件头第 7 条）
      (state.showServer && r.serverName ? '<div class="ac-muted" style="font-size:10.5px">' + esc(r.serverName) + '</div>' : '') +
      '</td>'
    html += '<td>' + esc(r.playerName || '-') + '</td>'
    html += '<td><span class="ac-tagpill" style="color:' + categoryColor(cat) + ';border-color:' + categoryColor(cat) + '">' +
      esc(categoryText(cat)) + '</span></td>'
    html += '<td class="ac-detail" title="' + esc(title) + '">' + esc(title) + '</td>'
    html += '<td><span class="ac-tagpill" style="color:' + methodColor(mth) + ';border-color:' + methodColor(mth) + '">' +
      esc(methodText(mth)) + '</span></td>'
    if (detail.length > 60) {
      // 长详情：可展开（修旧版只有 ellipsis + title 的问题）
      html += '<td class="ac-detail"><details><summary style="cursor:pointer">' +
        esc(detail.slice(0, 60)) + '…</summary><div style="white-space:pre-wrap;word-break:break-word">' +
        esc(detail) + '</div></details></td>'
    } else {
      html += '<td class="ac-detail" title="' + esc(detail) + '">' + esc(detail || '-') + '</td>'
    }
    html += '</tr>'
  }
  html += '</tbody></table>'
  html += pagerHtml(state)
  return html + '</div>'
}

function projServersBlock(state) {
  var list = Array.isArray(state.logServers) ? state.logServers : []
  var failed = list.filter(function (s) { return s && s.ok === false })
  var html = ''
  if (failed.length) {
    html += noticeHtml('error', '有 ' + failed.length + ' 台服务器查询失败（' + failed.map(function (s) {
      return s.name + '：' + (s.error || '未知原因')
    }).join('；') + '），下面的列表与统计都不含它们。')
  }
  html += perServerHtml(list, state.note, state.approximate)
  return html
}

function pagerHtml(state) {
  var html = '<div class="ac-pager">'
  html += '<span class="ac-muted">共 ' + esc(state.total) + ' 条</span>'
  html += '<button type="button" class="ac-btn" data-ac-act="prev"' + (state.page <= 1 ? ' disabled' : '') + '>‹ 上一页</button>'
  html += '<span>' + esc(state.page) + ' / ' + esc(state.totalPages) + '</span>'
  html += '<button type="button" class="ac-btn" data-ac-act="next"' + (state.page >= state.totalPages ? ' disabled' : '') + '>下一页 ›</button>'
  html += '<span class="ac-muted">每页</span>' + selectHtml('f-size', PAGE_SIZES.map(function (n) {
    return [String(n), n + '/页']
  }), String(state.pageSize))
  return html + '</div>'
}

/** 组装日志视图控制器（不依赖 window.tsweb，只依赖 DOM 与 fetch 封装，便于静态检查） */
function createLogView() {
  var root = null
  var styleDone = false
  var autoTimer = null
  var state = {
    loading: false,
    error: '',
    rows: [],
    total: 0,
    page: 1,
    totalPages: 1,
    pageSize: DEFAULT_PAGE_SIZE,
    totalText: '',
    filters: emptyFilters(),
    // 服务器下拉的选项来源（GET /api/servers，与"本次查询的逐服结果"是两码事，故分开存）
    serverOptions: [],
    serversError: '',
    // 本次日志查询的逐服结果（宿主 logs 响应里的 servers[]：{id,name,ok,rows,total,error}）
    logServers: [],
    // 宿主回的语义标注
    approximate: false,
    timeBasis: '',
    note: '',
    showServer: false,
    auto: false,
    stats: null,
    statsError: '',
    dictReady: false,
    methodOptions: [['', '全部处理方式']],
  }

  function injectStyleOnce() {
    if (styleDone) return
    styleDone = true
    injectStyle()
  }

  /** 处理方式下拉选项：methodLabels 全量 + 当前页出现的未知值（修 D-22） */
  function buildMethodOptions(rows) {
    var opts = [['', '全部处理方式']]
    var seen = {}
    Object.keys(METHOD_LABELS).forEach(function (k) {
      seen[k] = true
      opts.push([k, METHOD_LABELS[k]])
    })
    for (var i = 0; i < rows.length; i++) {
      var m = String((rows[i] || {}).method || '')
      if (m && !seen[m]) {
        seen[m] = true
        opts.push([m, m + '（未知，来自日志）'])
      }
    }
    return opts
  }

  function renderAll() {
    if (!root) return
    var html = '<div class="ac-wrap">'
    // 页面外壳走 shared/style.js 的 shellHtml（三个页面共用同一套标题排版，避免各写一份）
    html += shellHtml('反作弊日志',
      '每次反作弊检测命中自动记录（物品 / 弹幕 / 粒子），存储于服务器 AntiCheatLog.sqlite',
      svg(ICON.file, 18))
    html += statsHtml(state.stats, state.filters, state.statsError)
    html += filtersHtml(state, state.serverOptions, state.methodOptions)
    html += tableHtml(state)
    html += '</div>'
    root.innerHTML = html
    bindImageFallback(root)
    updateAutoTimer()
  }

  // ── 数据加载 ──

  async function loadLogs() {
    state.loading = true
    state.error = ''
    renderAll()
    var res = await get(API.logs + buildLogQuery(state.filters, state.page, state.pageSize))
    state.loading = false
    if (!res.ok) {
      state.error = errText(res, '请求失败')
      state.rows = []
      state.total = 0
      state.totalPages = 1
      state.totalText = ''
      return renderAll()
    }
    var d = dataOf(res)
    state.rows = Array.isArray(d.rows) ? d.rows : []
    state.total = Number(d.total) || 0
    state.pageSize = Number(d.pageSize) || state.pageSize
    state.approximate = d.approximate === true
    state.timeBasis = String(d.timeBasis || '')
    state.note = String(d.note || '')
    state.logServers = Array.isArray(d.servers) ? d.servers : []
    // 多台服务器聚合时给出服务器名附注（单台时没必要占地方）
    state.showServer = state.logServers.length > 1

    // totalPages：宿主给聚合模式下的估算值（logs.js:233），单台给该服自己的值
    var fromHost = Number(d.totalPages)
    var computed = Math.max(1, Math.ceil(state.total / state.pageSize))
    state.totalPages = Number.isFinite(fromHost) && fromHost > 0 ? fromHost : computed

    // ★ 修旧版 §3.3(g) #7：页码越界（筛选后总数变小、页码停在旧值）→ 自动回退最后一页并重查
    if (state.page > state.totalPages) {
      state.page = state.totalPages
      state.totalText = ''
      return loadLogs()
    }
    state.totalText = '共 ' + state.total + ' 条' + (state.approximate ? '（聚合近似）' : '')
    state.methodOptions = buildMethodOptions(state.rows)
    return renderAll()
  }

  async function loadStats() {
    // 统计端点不接受 page/pageSize（index.js:838-851 只透传筛选），所以这里用不带分页的查询串。
    // 旧版统计端点更是**完全不接受任何筛选**（旧 AntiCheatLog.cs:273 无参），本件传筛选以修 D-25。
    var res = await get(API.logsStats + buildStatsQuery(state.filters))
    if (!res.ok) {
      // 旧版统计失败是**静默**的（规格 B §3.3(e) :446）；本件如实显示，
      // 否则管理员看到的数字会不明不白地停在旧值上
      state.statsError = errText(res, '统计加载失败')
      state.stats = null
      return renderAll()
    }
    state.statsError = ''
    state.stats = dataOf(res)
    return renderAll()
  }

  /** 统计查询专用：不带 page/pageSize（宿主统计端点不认这两个参数） */
  function buildStatsQuery(filters) {
    var f = filters || {}
    var p = {}
    if (f.serverId) p.serverId = f.serverId
    if (f.player) p.player = f.player
    if (f.category) p.category = f.category
    if (f.method) p.method = f.method
    if (f.timeFrom) p.timeFrom = /^\d{4}-\d{2}-\d{2}$/.test(f.timeFrom) ? f.timeFrom + ' 00:00:00' : f.timeFrom
    if (f.timeTo) p.timeTo = /^\d{4}-\d{2}-\d{2}$/.test(f.timeTo) ? f.timeTo + ' 23:59:59' : f.timeTo
    if (f.q) p.q = f.q
    return qs(p)
  }

  async function loadServersOnce() {
    var r = await loadServers()
    state.serverOptions = r.servers || []
    state.serversError = r.error || ''
    if (state.serverOptions.length === 1) state.filters.serverId = ''
    return renderAll()
  }

  // ── 自动刷新 ──

  function updateAutoTimer() {
    if (autoTimer) {
      clearInterval(autoTimer)
      autoTimer = null
    }
    if (!state.auto) return
    autoTimer = setInterval(function () {
      // 自动刷新保留当前页码与筛选（与手动「刷新」同口径）
      loadLogs()
      loadStats()
    }, AUTO_REFRESH_MS)
  }

  function stopAuto() {
    if (autoTimer) {
      clearInterval(autoTimer)
      autoTimer = null
    }
  }

  // ── 事件 ──

  function onInput(ev) {
    var el = ev.target
    if (!el || typeof el.getAttribute !== 'function') return
    var act = el.getAttribute('data-ac-act')
    if (act === 'f-player') state.filters.player = el.value
    else if (act === 'f-q') state.filters.q = el.value
    else if (act === 'f-from') state.filters.timeFrom = el.value
    else if (act === 'f-to') state.filters.timeTo = el.value
  }

  function onChange(ev) {
    var el = ev.target
    if (!el || typeof el.getAttribute !== 'function') return
    var act = el.getAttribute('data-ac-act')
    if (act === 'f-category') {
      state.filters.category = el.value
      state.page = 1
      return loadBoth()
    }
    if (act === 'f-method') {
      state.filters.method = el.value
      state.page = 1
      return loadBoth()
    }
    if (act === 'f-server') {
      state.filters.serverId = el.value
      state.page = 1
      return loadBoth()
    }
    if (act === 'f-size') {
      state.pageSize = Number(el.value) || DEFAULT_PAGE_SIZE
      // 旧版切换每页条数即 @change="search"（回到第 1 页，规格 B §3.3(d) :434），本件照旧
      state.page = 1
      return loadLogs()
    }
    if (act === 'f-auto') {
      state.auto = el.checked === true
      return renderAll()
    }
  }

  function onClick(ev) {
    var el = ev.target && typeof ev.target.closest === 'function' ? ev.target.closest('[data-ac-act]') : null
    if (!el || !root.contains(el)) return
    var act = el.getAttribute('data-ac-act')
    if (act === 'search') {
      state.page = 1
      return loadBoth()
    }
    if (act === 'reset') {
      // 旧版 resetFilters 重置 6 个筛选项后 search()，**不复位 pageSize**（规格 B §3.3(d) :437），本件照旧
      var keepSize = state.pageSize
      state.filters = emptyFilters()
      state.pageSize = keepSize
      state.page = 1
      return loadBoth()
    }
    if (act === 'refresh') return loadBoth()
    if (act === 'prev') {
      if (state.page > 1) {
        state.page -= 1
        return loadLogs()
      }
      return
    }
    if (act === 'next') {
      if (state.page < state.totalPages) {
        state.page += 1
        return loadLogs()
      }
    }
  }

  function loadBoth() {
    loadLogs()
    loadStats()
  }

  function bindEvents(container) {
    bindDelegated(container, [
      ['click', 'acLogClick', onClick],
      ['input', 'acLogInput', onInput],
      ['change', 'acLogChange', onChange],
    ])
    // 视图没有卸载钩子（宿主 route() 不使用 render 的返回值，plugins/web/public/app.js:385），
    // 所以用 hashchange 在离开本页时停掉自动刷新，避免后台轮询
    if (typeof window !== 'undefined') {
      if (container.__acLogHash) window.removeEventListener('hashchange', container.__acLogHash)
      container.__acLogHash = function () {
        if (!location.hash || location.hash.indexOf('#/s/anticheat-log') !== 0) stopAuto()
      }
      window.addEventListener('hashchange', container.__acLogHash)
    }
  }

  function render(container) {
    root = container
    injectStyleOnce()
    bindEvents(container)
    state.loading = true
    state.error = ''
    renderAll()
    // 弹幕字典（把日志里的 projId 转中文名；宿主已做同样兜底，这里只是"宿主字典不可用时仍能显示名字"）
    loadProjDict().then(function () {
      state.dictReady = true
      renderAll()
    })
    loadServersOnce().then(function () {
      loadBoth()
    })
  }

  return { render: render, _stopAuto: stopAuto }
}

// ── 视图注册 ──
//
// 路径约定：宿主的 route() 只把 hash 切成两段（area/view），curPath = '/<area>/<view>'
// （plugins/web/public/app.js:369-374），所以插件视图的 path 必须是**两段扁平**路径，
// 不能写成 '/s/anticheat/logs'（那会匹配不上，侧边栏也不会高亮）。
// section 决定它出现在侧边栏哪个分区：本页面向运行中的游戏服数据，归「服务器设置」
// （与 task-scheduler 的 /s/tasks 同分区）。
// icon 只能取宿主侧边栏图标表里的键（plugins/web/public/app.js:99-105：grid/terminal/box/layers/server/key），
// 取别的键不会报错但图标会是空白，故这里用 server（与 status-panel 一致，同为"运行状态"类页面）。

/** 视图注册元信息（导出以便静态核对/测试断言，不必真的注册）—— 与 task-scheduler.js:630 的 VIEW_META 同惯例 */
export var VIEW_META = {
  id: 'anticheat-log',
  title: '检测日志',
  section: '服务器设置',
  path: '/s/anticheat-log',
  icon: 'server',
}

/** 控制器单例：route() 每次进入都调它，所以只建一次、复用同一份状态 */
var controller = null

/**
 * 挂载本视图（供 registerView 调用；导出也便于在无宿主环境下做静态检查）。
 * @param {HTMLElement} container 宿主提供的常驻容器节点
 */
export function mountLogView(container) {
  if (!controller) controller = createLogView()
  controller.render(container)
}

var tsw = typeof window !== 'undefined' ? window.tsweb : null

if (tsw && typeof tsw.registerView === 'function') {
  // 注册本身放在 try 里：任何意外都不该让整个 client bundle 加载失败（宿主是逐个 import 插件的，
  // 一个插件抛错不应影响其它插件的菜单——plugins/web/public/app.js:349-... loadPluginClients）
  try {
    tsw.registerView(Object.assign({}, VIEW_META, { render: mountLogView }))
  } catch (err) {
    console.warn('[anti-cheat] 注册「检测日志」视图失败：' + ((err && err.message) || err))
  }
}
