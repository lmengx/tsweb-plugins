/**
 * anti-cheat 前端半 —— 物品违禁页（对应旧 ItemRestrictView.vue）
 *
 * 本文件只做三件事：声明视图元信息、把 shared/tier-editor.js 的编辑器实例化、注册视图。
 * **所有业务逻辑与 UI 都在共用实现里**（shared/tier-editor.js）。
 *
 * 旧版这一页是 `C:\Users\lyt\Documents\GitHub\TsWeb\TsWeb\frontend\src\views\console\ItemRestrictView.vue`，
 * 与弹幕页 `ProjRestrictView.vue` 是**同构孪生页**（规格 B §3.6(g)/§3.7 列出的缺陷几乎一一对应），
 * 所以两页共用一份编辑器实现、只用 `kind` 参数化差异（详见 shared/tier-editor.js 头部说明）。
 *
 * 物品侧相对弹幕侧的真实业务差异（旧版就有，不是本件发明的）：
 *   1. 条目多一个 `stack`（数量阈值）—— 旧 proj-restrict.cs:30-37 的 RestrictedProj 没有该字段；
 *   2. 页面开关是 启用检测 / 自动扫描 / 扫描间隔 / 没收违禁物品（弹幕侧是 启用检测 / 伤害上限）；
 *   3. 有「扫描全部在线玩家」与「按物品查持有者」（弹幕侧没有）；
 *   4. 快捷命令 4 条（`{itemname}`/`{itemid}` 占位符），弹幕侧 3 条（`{projid}`）。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import { svg, ICON } from './shared/api.js'
import { createTierPage } from './shared/tier-editor.js'
import { loadItemDict } from './shared/api.js'
import { injectStyle } from './shared/style.js'

/** 视图注册元信息（导出以便静态核对/测试断言）—— 与 task-scheduler.js:630 的 VIEW_META 同惯例 */
export var VIEW_META = {
  id: 'anticheat-item',
  title: '物品违禁',
  section: '服务器设置',
  path: '/s/anticheat-item',
  // icon 只能取宿主侧边栏图标表的键（plugins/web/public/app.js:99-105）
  icon: 'box',
}

/**
 * 页面标题与副标题（**逐字**取旧版：规格 B §3.6(b) :520-521 的 `物品限制配置` /
 * `配置不同游戏进度下的物品限制规则`）。
 * 注意与侧边栏菜单名分开：VIEW_META.title 是新架构的菜单标签（`物品违禁`），
 * 而卡片标题沿用旧版逐字文案 —— 两者不是同一处 UI。
 */
var PAGE_TITLE = '物品限制配置'
var SUBTITLE = '配置不同游戏进度下的物品限制规则'

/** 物品页控制器（只建一次，复用状态） */
var page = null

/**
 * 挂载物品违禁页。
 * @param {HTMLElement} container 宿主提供的常驻容器节点
 */
export function mountItemView(container) {
  if (!page) {
    injectStyle()
    page = createTierPage({
      kind: 'item',
      title: PAGE_TITLE,
      subtitle: SUBTITLE,
      iconPath: '<span class="ac-ic">' + svg(ICON.box, 16) + '</span>',
    })
  }
  page.render(container)
  // 字典预热（可与页面加载并行；失败只降级为"只显示 ID"）
  loadItemDict()
}

var tsw = typeof window !== 'undefined' ? window.tsweb : null

if (tsw && typeof tsw.registerView === 'function') {
  try {
    tsw.registerView(Object.assign({}, VIEW_META, { render: mountItemView }))
  } catch (err) {
    console.warn('[anti-cheat] 注册「物品违禁」视图失败：' + ((err && err.message) || err))
  }
}
