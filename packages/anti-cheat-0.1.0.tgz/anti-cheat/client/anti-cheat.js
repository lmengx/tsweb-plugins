/**
 * anti-cheat 前端半 —— 客户端入口
 *
 * 宿主（plugins/web）每个插件只加载**一个** client 文件（package.json 的 tsweb.client 字段，
 * 本件声明 `./client/anti-cheat.js`），所以这里作为入口，引入本件的各功能模块；
 * 各模块在**自己的顶层**调用注册 API（与 qq-bind/client/qq-bind.js:1-21 同一约定）。
 *
 * 模块分工：
 *   - item.js            物品违禁页          #/s/anticheat-item   （registerView）
 *   - proj.js            弹幕违禁页          #/s/anticheat-proj   （registerView）
 *   - log.js             检测日志页          #/s/anticheat-log    （registerView）
 *   - player-section.js  玩家详情「违禁物品告警」区块（registerPlayerDetailSection）
 *   - shared/*           两页共用的存取层/编辑器/选择器/样式（不含注册）
 *
 * 加载顺序说明：
 *   1) item.js 与 proj.js 都 import shared/store.js：module 级单例状态在**第一次 import 时**建立，
 *      两页共用同一份配置缓存与脏标记（这正是修「切换页面丢编辑」所需的语义：
 *      物品页改了没保存，切到弹幕页再回来，编辑器里仍是你的修改，并继续提示"有未保存的修改"）。
 *      顺序因此无关紧要，谁先加载都只初始化一次。
 *   2) ESM 的 import 会被提升并顺序求值：任一模块在顶层抛错都会中断其后模块的求值，
 *      从而"静默少注册一个页面/区块"。所以每个模块都：把注册包在 try/catch 里，
 *      并在宿主没提供对应注册 API 时只 console.warn —— 保证后面的模块永远还能注册。
 *   3) 注册 API 都不存在时（宿主版本过旧）本文件不会报错，只是什么都没注册。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import './item.js'
import './proj.js'
import './log.js'
import './player-section.js'

import { getState } from './shared/store.js'

/**
 * 未保存修改的离开守卫（修旧版 I-12）。
 *
 * 旧版只挂了 `onBeforeRouteLeave`（规格 B §3.6(g) I-12 引旧 ItemRestrictView.vue:29-33），
 * 于是有未保存编辑时**按 F5 / 关标签页完全不提示**，编辑直接丢。
 *
 * 本件的两层保护：
 *   1. 页内导航（hash 切换）：物品页与弹幕页共用 shared/store.js 的同一份状态，
 *      切走再回来编辑仍在、脏标记仍在 —— 比旧版"切走就丢"更进一步，所以不需要拦截；
 *   2. 真正的离开（刷新 / 关标签 / 跳外链）：浏览器不允许自定义文案，
 *      只能靠 `beforeunload` + `preventDefault()` 让浏览器弹它自己的确认框。
 *
 * 只在**有未保存修改**时拦截，避免无缘无故打断正常操作。
 */
if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
  window.addEventListener('beforeunload', function (e) {
    var dirty = false
    try {
      dirty = getState().dirty === true
    } catch (err) {
      dirty = false
    }
    if (!dirty) return undefined
    e.preventDefault()
    // 老浏览器（Chrome < 119 等）需要 returnValue 才弹确认框
    e.returnValue = ''
    return ''
  })
}
