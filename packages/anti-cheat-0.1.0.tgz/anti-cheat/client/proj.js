/**
 * anti-cheat 前端半 —— 弹幕违禁页（对应旧 ProjRestrictView.vue）
 *
 * 与物品页共用 shared/tier-editor.js，只用 kind='proj' 参数化。差异见 client/item.js 头部与
 * shared/tier-editor.js 头部（条目**没有** stack / 开关是 启用检测+伤害上限 / 快捷命令 3 条 / 无扫描面板）。
 *
 * 旧版这一页的专属缺陷（规格 B §3.7，本件的处置逐条对应）：
 *   P-6 模组弹幕（`m1001`-`m1020`）在旧选择器里被 `typeof id === 'number'` 静默过滤掉，界面上完全不可选、
 *       也没有任何提示 → 本件在 shared/search.js 里**列出但明确标注不可加入**并说明原因。
 *   P-9 图标 URL 旧版有"数据里的 image 字段"与"硬编码路径"两套等价逻辑 → 本件收敛到
 *       `/plugins/data-projectiles/client/img/proj/proj_<id>.png` 一套（shared/api.js 的 projIconUrl）。
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import { svg, ICON } from './shared/api.js'
import { createTierPage } from './shared/tier-editor.js'
import { loadProjDict } from './shared/api.js'
import { injectStyle } from './shared/style.js'

/** 视图注册元信息（导出以便静态核对/测试断言） */
export var VIEW_META = {
  id: 'anticheat-proj',
  title: '弹幕违禁',
  section: '服务器设置',
  path: '/s/anticheat-proj',
  // icon 只能取宿主侧边栏图标表的键（plugins/web/public/app.js:99-105）
  icon: 'terminal',
}

/**
 * 页面标题与副标题（**逐字**取旧版：规格 B §3.7 :627 的 `弹幕限制配置` /
 * `配置不同游戏进度下的弹幕限制规则`）。侧边栏菜单名是 VIEW_META.title（`弹幕违禁`）。
 */
var PAGE_TITLE = '弹幕限制配置'
var SUBTITLE = '配置不同游戏进度下的弹幕限制规则'

var page = null

/**
 * 挂载弹幕违禁页。
 * @param {HTMLElement} container 宿主提供的常驻容器节点
 */
export function mountProjView(container) {
  if (!page) {
    injectStyle()
    page = createTierPage({
      kind: 'proj',
      title: PAGE_TITLE,
      subtitle: SUBTITLE,
      iconPath: '<span class="ac-ic">' + svg(ICON.crosshair, 16) + '</span>',
    })
  }
  page.render(container)
  loadProjDict()
}

var tsw = typeof window !== 'undefined' ? window.tsweb : null

if (tsw && typeof tsw.registerView === 'function') {
  try {
    tsw.registerView(Object.assign({}, VIEW_META, { render: mountProjView }))
  } catch (err) {
    console.warn('[anti-cheat] 注册「弹幕违禁」视图失败：' + ((err && err.message) || err))
  }
}
