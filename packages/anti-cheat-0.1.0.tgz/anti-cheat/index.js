/**
 * 反作弊（anti-cheat）—— 宿主半
 *
 * ══════════ 这是什么（旧版边界的核定结论）══════════
 * 旧版「反作弊」是**一套机制**，不是两套并行机制：`ItemConfigHandler.cs` / `ProjConfigHandler.cs`
 * 只是 `AntiCheat.*` 的 REST 包装层（规格 B §1.2(d)(e) 逐字：「它不是独立功能，是 AntiCheat 的门面」）。
 * 真正的检测在 `item-restrict.cs` / `proj-restrict.cs`，配置模型在 `AntiCheat.cs:15-40`，
 * 日志在 `AntiCheatLog.cs`。本插件按用户核定的范围只做这三块 + 同族的杂项功能：
 *   物品违禁（ItemDrop / ChestItemChange 包钩子 + 背包扫描 / 自动扫描 / 没收 / 进度过滤）
 *   弹幕违禁（NewProjectile 钩子 + 伤害上限 / 负伤害判定）
 *   检测日志（CheatLog 表，分页查询 + 统计）
 *   杂项：enable 开关、apply-defaults、/scan + /projlist + /scanlist 聊天命令
 * **明确不做**（后续添加，见交付报告「范围排除」）：粒子防线（归「漏洞修复」）、反恶性 bug、
 * 共享 IP（新宿主 base 已提供 `/api/base/players/duplicateips`）。
 *
 * ══════════ 职责分工 ══════════
 *   宿主半（本文件）  清单存储 / 权威校验 / 审计 / 下发（变更即推 + 连接恢复补推 + 退避重试 + 周期对账 + probe 自证）
 *                     跨服日志聚合查询 / ID→名称兜底 / 对外暴露 `ctx.anticheatLog` 日志服务
 *   前端半            /b/anti-cheat/{items,projectiles,logs} 三页 + 玩家详情页违禁告警区块
 *   游戏服半          AntiCheat.dll：包钩子与检测、阈值判定、**就地阻断**、进度过滤、
 *                     自动扫描调度、处置执行（log/kick/ban/drop/command）、日志本地落库
 *
 * ★ **检测与处置的就地性优先**：命中违禁弹幕/物品时，服端**立即**置 `args.Handled = true` 阻断该包，
 *   不回调宿主。把每包路径做成跨进程 REST 调用会让"阻断"变成"事后通知"，而且网络延迟直接进
 *   服务端主循环。宿主只在**配置与查询**这两类低频动作上参与。
 *
 * ══════════ 三条必须一致的行为（与旧版逐条对齐，见交付报告的语义对照表）══════════
 *   1. **清单是唯一权威、必须下发**：配置变更**立即**下发（这一条是"界面显示已启用、实际没生效"
 *      那类静默失效的解药）。`POST /api/anticheat/config` 在同一请求里完成落盘 + 下发，
 *      并把逐服结果原样回显。
 *   2. **下发失败永不静默**：逐服状态进 pushStatus，经 `/status` 与保存响应回给前端，
 *      同时按退避重试，直到该服确认应用（或管理员看到持续的失败原因）。
 *   3. **多服语义**：旧版是单机单库（配置与日志都在同一台机器上）。新宿主是多服，
 *      所以清单由宿主统一持有并推到**每一台启用的服**；日志则是"每台服各存各的"，
 *      由宿主聚合查询（聚合分页是**近似**的，见 logs.js 头部说明，界面必须标注）。
 *
 * 依赖：webServer / auth / servers / tshock / paths（全部由宿主或基础插件提供）
 * 软依赖：itemData / projectileData（plugins/data-items、plugins/data-projectiles）。
 *   ★ 刻意**不写进 inject**：`inject` 会让 apply 延迟执行，缺一个服务就"加载成功但什么都没注册"
 *   （docs/插件开发约定.md:118-137），而这两个服务只用于"日志行缺名称"的兜底解析，
 *   缺了也应该照常工作。所以一律经 `ctx.get()` 取（未注册返回 undefined，不抛错）。
 *
 * 约定：禁止 emoji；状态数据走 ctx.paths.dataOf('anti-cheat')（不在插件目录内）。
 */
import { Service } from '@deepseek-ai/cordis'
import { join } from 'node:path'

import { ACTIONS, AuditLog } from './audit.js'
import {
  METHOD_LABELS,
  METHOD_VALUES,
  PROGRESS_ORDER,
  QUICK_COMMANDS,
  COMMAND_PLACEHOLDERS,
  configStats,
  configWarnings,
  defaultConfig,
  httpError,
  normalizeConfig,
  progressOrder,
  validateConfig,
} from './config.js'
import { applyDefaults, loadDefaults, previewDefaults } from './defaults.js'
import { DLL_NAME, SERVER_HALF_PREFIX, createGameOps } from './gameOps.js'
import { queryLogStats, queryLogs } from './logs.js'
import { loadConfigFile, saveConfigFile } from './store.js'

export const name = 'anti-cheat'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths']

/** 单次手动下发可指定的服务器上限（防止一次请求把几十台服串行打完） */
const PUSH_LIMIT = 50

/**
 * 下发与对账节奏（**不写进配置文件**）。
 * config.json 的字段要与旧版一字不差（旧版是进程内功能，没有"下发节奏"这个概念），
 * 所以节奏只作为模块常量 + apply 时的 options 覆盖入口。
 */
export const PUSH_DEFAULTS = {
  /** 配置变更后立即下发；此项为 false 只影响"变更即推"，手动推送与对账仍在 */
  pushOnChange: true,
  /** 服务器连接建立 / 服务器列表加载后补推（连接恢复补推） */
  pushOnServerConnect: true,
  /** 周期对账：无条件重推一遍（清单约 16 KB，代价可接受；能自愈"服端配置被删改/重置"） */
  reconcileIntervalMs: 900000,
  /** 推送失败后的首次重试间隔 */
  retryIntervalMs: 60000,
  /** 失败重试的退避上限（连续失败时指数增长到此为止） */
  retryMaxIntervalMs: 900000,
}

/** 日志服务的服务名（其它插件用 `inject: ['anticheatLog']` 或 `ctx.get('anticheatLog')` 取） */
export const LOG_SERVICE_NAME = 'anticheatLog'

/**
 * 检测日志服务（**对外公开，不许私有化**）。
 *
 * 为什么必须做成服务：旧 `AntiCheatLog.cs:15` 自述这张表同时承载
 * 「物品违禁 / 弹幕违禁 / **粒子恶意** / **粒子超频丢弃**」四类，且 `particle-guard.cs:294/332/347`
 * 三处以 `category='particle'` 写入同一张表。粒子防线在新架构里是**另一个插件**（归「漏洞修复」），
 * 它将来要写同一张表、宿主日志页也要能筛 `particle` —— 所以：
 *   - 服端提供 `POST /data/anticheat/log` 外部写入端点（见 plugin/AntiCheatEndpoints.cs），
 *     未来的粒子插件**不需要**编译期引用 AntiCheat.dll 就能写入同一通道；
 *   - 宿主暴露 `ctx.anticheatLog`，提供 `record` / `query` / `stats`，别的宿主插件也能写与读；
 *   - 宿主**不按 category 白名单过滤**，任何分类都原样透出，`particle` 分类与统计卡始终保留。
 */
export class AntiCheatLogService extends Service {
  constructor(ctx, service) {
    super(ctx, LOG_SERVICE_NAME)
    this._svc = service
  }

  /**
   * 往指定服务器写一条检测日志（走 `POST /data/anticheat/log`）。
   * @param {string|number} serverId 目标服务器
   * @param {{playerName?:string, playerId?:number, category:string, method:string, detail?:string,
   *          itemId?:number, itemName?:string, projId?:number}} entry
   */
  async record(serverId, entry = {}) {
    return this._svc.record(serverId, entry)
  }

  /** 跨服日志查询（与 `/api/anticheat/logs` 同一实现） */
  async query(query = {}) {
    return this._svc.queryLogs(query)
  }

  /** 跨服日志统计（与 `/api/anticheat/logs/stats` 同一实现） */
  async stats(query = {}) {
    return this._svc.queryLogStats(query)
  }
}

export class AntiCheatService {
  constructor({ ctx, dataDir, configFile, auditFile, push }) {
    this.ctx = ctx
    this.dataDir = dataDir
    this.configFile = configFile || join(dataDir, 'config.json')
    this.auditFile = auditFile || join(dataDir, 'audit.jsonl')

    /** 当前生效配置（唯一权威；下发内容永远由它派生） */
    this.config = defaultConfig()
    /** 读配置时发现的问题（文件损坏等），如实回显给管理员 */
    this.configError = ''
    /** 读配置时的归一警告（旧 method 迁移、补斜杠、未知档位等），如实回显 */
    this.configWarnings = []
    /** 默认清单资源状态（缺失/损坏时如实回显，绝不静默把清单清空） */
    this.defaultsError = ''

    this.push = { ...PUSH_DEFAULTS, ...(push && typeof push === 'object' ? push : {}) }

    this.gameOps = createGameOps({ ctx })
    this.audit = new AuditLog({ file: this.auditFile })

    /**
     * 宿主侧期望的配置版本，**每次下发尝试都自增**（单调）。
     * 服端拒绝比它当前版本更旧的载荷（stale），所以"重试"必须带新版本号，
     * 否则一次乱序到达的旧请求会把新配置覆盖回去。
     */
    this.desiredVersion = 0
    /**
     * 配置内容修订号：**只在配置真的变了（或宿主刚启动）时自增**。
     * "版本号"管顺序，"修订号"管是否最新，各司其职（promotion 踩过的坑：只用版本号会让
     * 一次单服补推把其它已确认的服误判成落后，未确认计数永远清不掉）。
     */
    this.configRevision = 1
    /** serverId → { version, revision }（已确认应用的那一次下发） */
    this.acked = new Map()
    /** 最近一次已知的启用服务器 id 集合（用于算"未确认"台数，含从未推过的服） */
    this.knownServerIds = new Set()
    /** serverId → 最近一次下发结果（前端展示 + 排障） */
    this.pushStatus = new Map()

    this._reconcileTimer = null
    this._retryTimer = null
    this._retryDelay = 0
    this.log = this.gameOps.log
  }

  // ═══════════════════════ 生命周期 ═══════════════════════

  async init() {
    const loaded = await loadConfigFile(this.configFile)
    this.config = loaded.config
    this.configError = loaded.error
    this.configWarnings = loaded.warnings
    this._retryDelay = this.push.retryIntervalMs

    if (loaded.error) {
      // 配置损坏 → 按默认（检测未启用）运行并明确报错：绝不因为读不懂配置就"按启用"乱踢人
      console.error(`[anti-cheat] ${loaded.error}`)
    } else if (!loaded.existed) {
      // 首次运行：检查默认清单资源可用性（不可用要让管理员看见，而不是"应用默认配置"时才发现）
      const defaults = await this._defaultsOrNull()
      this.log(
        `[anti-cheat] 尚无配置文件（${this.configFile}），按默认配置运行（检测未启用）；` +
        `默认清单资源：${defaults ? `物品 ${defaults.stats.itemTiers} 档/${defaults.stats.itemEntries} 条、弹幕 ${defaults.stats.projTiers} 档/${defaults.stats.projEntries} 条` : `不可用（${this.defaultsError}）`}`,
      )
    }
    for (const w of this.configWarnings) console.warn(`[anti-cheat] 配置归一警告：${w}`)

    // 启动即对账一次（异步、不阻塞 apply）：宿主重启后若某服配置落后，这里就补上
    this.startReconcile()
    this.pushConfig({ reason: '宿主启动对账' }).catch((err) => {
      console.error(`[anti-cheat] 启动对账下发失败：${err.message}`)
    })
    return this
  }

  /** 读默认清单；失败时把原因记进 defaultsError 并返回 null（绝不返回"空清单"当成功） */
  async _defaultsOrNull() {
    try {
      const d = await loadDefaults()
      if (d.error) {
        this.defaultsError = d.error
        return null
      }
      this.defaultsError = ''
      return d
    } catch (err) {
      this.defaultsError = `默认清单读取失败：${err.message}`
      return null
    }
  }

  /**
   * 周期对账：无条件重推一遍。
   * 为什么无条件而不是"仅推落后的服"：服端配置文件可能被人删掉/改坏（它会退回默认），
   * 此时宿主的 acked 记录仍是"已确认"，只有无条件重推才能自愈这种"宿主以为生效了"的状态。
   */
  startReconcile() {
    this.stopReconcile()
    const ms = Number(this.push.reconcileIntervalMs) || 0
    if (ms <= 0) return false
    this._reconcileTimer = setInterval(() => {
      this.pushConfig({ reason: '周期对账' }).catch((err) => {
        console.error(`[anti-cheat] 周期对账下发失败：${err.message}`)
      })
    }, ms)
    if (typeof this._reconcileTimer.unref === 'function') this._reconcileTimer.unref()
    return true
  }

  stopReconcile() {
    if (this._reconcileTimer) {
      clearInterval(this._reconcileTimer)
      this._reconcileTimer = null
    }
  }

  dispose() {
    this.stopReconcile()
    this.stopRetry()
  }

  // ═══════════════════════ 下发 / 重试 / 对账 ═══════════════════════

  /** 待重试的定时器：指数退避，上限 retryMaxIntervalMs */
  scheduleRetry(reason) {
    if (this._retryTimer) return
    const delay = Math.min(Math.max(this._retryDelay, 1000), Number(this.push.retryMaxIntervalMs) || 60000)
    this._retryTimer = setTimeout(() => {
      this._retryTimer = null
      this.pushPending({ reason: `失败重试（${reason}）` })
        .then((r) => {
          if (r.pendingCount === 0) this._retryDelay = this.push.retryIntervalMs
          else this._retryDelay = Math.min(this._retryDelay * 2, Number(this.push.retryMaxIntervalMs) || 60000)
        })
        .catch((err) => {
          console.error(`[anti-cheat] 失败重试下发失败：${err.message}`)
          this._retryDelay = Math.min(this._retryDelay * 2, Number(this.push.retryMaxIntervalMs) || 60000)
        })
    }, delay)
    if (typeof this._retryTimer.unref === 'function') this._retryTimer.unref()
  }

  stopRetry() {
    if (this._retryTimer) {
      clearTimeout(this._retryTimer)
      this._retryTimer = null
    }
  }

  /** 未确认的服务器 id（含从未推过的启用服） */
  pendingIds() {
    const out = []
    for (const id of this.knownServerIds) {
      const a = this.acked.get(id)
      if (!a || a.revision !== this.configRevision) out.push(id)
    }
    return out
  }

  /**
   * 下发配置到若干台服。
   * @param {{serverIds?: Array<string|number>|null, reason?: string, onlyPending?: boolean}} [opts]
   * @returns {Promise<{ok:boolean,total:number,okCount:number,pendingCount:number,reason:string,results:Array<object>}>}
   */
  async pushConfig({ serverIds = null, reason = '下发', onlyPending = false } = {}) {
    let servers
    try {
      servers = await this.gameOps.enabledServers()
    } catch (err) {
      const message = `读取服务器列表失败：${err.message}`
      console.error(`[anti-cheat] ${message}`)
      return { ok: false, total: 0, okCount: 0, pendingCount: this.pendingIds().length, reason, results: [], error: message }
    }
    this.knownServerIds = new Set(servers.map((s) => String(s.id)))

    // serverIds 三态：未传（null）= 全部启用服；给了数组 = **只**下发这些。空数组是"明确不下发任何服"，
    // 由路由保留下来（:805 `b.serverIds.map(String).filter(s => s !== '')`，注释见 :804）。
    // 所以这里必须按 Array.isArray 判定，不能按 length>0 —— 否则 {"serverIds":[]} 会被当成"未指定"
    // 而推给全部服务器（空数组反而变成最大范围下发），与路由声明完全相反。
    const wanted = Array.isArray(serverIds) ? serverIds.map(String) : null
    let targets = wanted ? servers.filter((s) => wanted.includes(String(s.id))) : servers
    if (onlyPending) {
      const pending = new Set(this.pendingIds())
      targets = targets.filter((s) => pending.has(String(s.id)))
    }

    // 每次下发尝试都自增版本号（单调），保证乱序到达的旧载荷会被服端拒绝
    this.desiredVersion += 1
    const version = this.desiredVersion
    const revisionAtStart = this.configRevision
    const ts = new Date().toISOString()
    const config = normalizeConfig(this.config).config

    const results = []
    let okCount = 0
    for (const server of targets) {
      try {
        const data = await this.gameOps.pushConfig(server, { version, config, ts })
        const row = {
          id: String(server.id),
          name: String(server.name || server.id),
          ok: true,
          version: Number(data.version) || version,
          applied: data.applied !== false,
          stale: data.stale === true,
          notes: Array.isArray(data.notes) ? data.notes.map(String) : [],
          error: '',
          at: ts,
        }
        // 服端明确回 stale（它已有更新的版本）：这不是失败，但**必须显示**——
        // 它意味着"本次没生效"，静默当作成功会让管理员以为配置已推上去。
        if (row.stale) {
          row.ok = false
          row.error = row.notes.join('；') || `服端当前版本 ${row.version} 更新，本次载荷被忽略`
        }
        // ★ 服端"已应用但**落盘失败**"（AntiCheatEndpoints.cs:333-334 的 durable=false + saveError）
        //   绝不能当成功：内存里已生效、重启就回滚，而管理员界面显示"已生效"——这正是规格
        //   「失败绝不静默」要禁的静默。C# 侧自己也写明"绝不静默"（AntiCheatConfig.cs:505-506）。
        //   标成失败 → 不写 acked → 安排重试；磁盘恢复后重试即转成真正持久。
        const saveError = typeof data.saveError === 'string' ? data.saveError : ''
        if (row.ok && (data.durable === false || saveError !== '')) {
          row.ok = false
          row.error = `服端已应用但落盘失败：${saveError || '未说明原因'}（重启后会丢失，已安排重试）`
          row.durable = false
          row.saveError = saveError
        }
        if (row.ok) {
          this.acked.set(row.id, { version: row.version, revision: revisionAtStart })
          okCount += 1
        } else {
          this.acked.delete(row.id)
        }
        this.pushStatus.set(row.id, row)
        results.push(row)
      } catch (err) {
        const row = {
          id: String(server.id),
          name: String(server.name || server.id),
          ok: false,
          version: 0,
          applied: false,
          stale: false,
          notes: [],
          error: err.message,
          serverHalfMissing: err.serverHalfMissing === true,
          dllName: err.dllName || DLL_NAME,
          hint: err.hint || '',
          at: ts,
        }
        this.acked.delete(row.id)
        this.pushStatus.set(row.id, row)
        results.push(row)
      }
    }

    const pendingCount = this.pendingIds().length
    if (results.length > 0 && pendingCount > 0) this.scheduleRetry(reason)
    else if (pendingCount === 0) {
      this.stopRetry()
      this._retryDelay = this.push.retryIntervalMs
    }

    const summary = {
      ok: pendingCount === 0,
      total: results.length,
      okCount,
      pendingCount,
      reason,
      version,
      results,
    }
    if (pendingCount > 0) {
      console.error(
        `[anti-cheat] ${reason}：${results.length} 台中有 ${results.length - okCount} 台未生效` +
        `（未确认共 ${pendingCount} 台），已安排重试：` +
        results.filter((r) => !r.ok).map((r) => `${r.name}: ${r.error}`).join('；'),
      )
    } else {
      this.log(`[anti-cheat] ${reason}：${results.length} 台全部确认生效（期望版本 v${version}）`)
    }
    return summary
  }

  /** 只补推未确认的服务器 */
  async pushPending({ reason = '补推' } = {}) {
    return this.pushConfig({ reason, onlyPending: true })
  }

  /** 对外状态（`/api/anticheat/status` 与前端「下发状态」卡） */
  status() {
    const cfg = normalizeConfig(this.config).config
    return {
      desiredVersion: this.desiredVersion,
      configRevision: this.configRevision,
      configFile: this.configFile,
      configError: this.configError,
      defaultsError: this.defaultsError,
      warnings: [...this.configWarnings, ...configWarnings(cfg)],
      stats: configStats(cfg),
      progressOrder: progressOrder(cfg),
      intervals: {
        reconcileIntervalMs: this.push.reconcileIntervalMs,
        retryIntervalMs: this.push.retryIntervalMs,
        retryMaxIntervalMs: this.push.retryMaxIntervalMs,
      },
      servers: [...this.pushStatus.values()].map((r) => ({ ...r }))
        .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id))),
      pendingCount: this.pendingIds().length,
      pendingServerIds: this.pendingIds(),
      retryScheduled: this._retryTimer != null,
    }
  }

  /**
   * 逐服探测"服端实际生效的配置"，并与宿主配置比对（probe 自证）。
   * 这是"界面写了什么"与"服端真的按什么在检测"之间的唯一直接证据（保存响应只代表提交成功）。
   */
  async probeServers({ serverIds = null } = {}) {
    let servers
    try {
      servers = await this.gameOps.enabledServers()
    } catch (err) {
      return { servers: [], error: `读取服务器列表失败：${err.message}` }
    }
    // 与 pushConfig 同一套三态语义（parseIds 对 `?serverIds=` 返回 null，对 `?serverIds=,` 返回 []）：
    // 给了数组就**只**探这些，空数组 = 不探任何服，而不是退回"探全部"。
    const wanted = Array.isArray(serverIds) ? serverIds.map(String) : null
    const targets = wanted ? servers.filter((s) => wanted.includes(String(s.id))) : servers
    const cfg = normalizeConfig(this.config).config
    const out = []

    for (const server of targets) {
      try {
        const state = await this.gameOps.status(server)
        const diff = []

        // 开关逐项比对
        for (const key of ['启用', '自动扫描', '扫描间隔', '没收违禁物品']) {
          if (state.config.item[key] !== cfg.item[key]) {
            diff.push(`物品侧「${key}」服端=${state.config.item[key]}（宿主 ${cfg.item[key]}）`)
          }
        }
        for (const key of ['启用', '伤害上限']) {
          if (state.config.proj[key] !== cfg.proj[key]) {
            diff.push(`弹幕侧「${key}」服端=${state.config.proj[key]}（宿主 ${cfg.proj[key]}）`)
          }
        }

        // 清单：按"档位 → 条目集合"比对（顺序无关；条目内按 id/stack/method/command 组成排序键）
        for (const kind of ['item', 'proj']) {
          const key = kind === 'item'
            ? (e) => `${e.id}|${e.stack}|${e.method}|${e.command}`
            : (e) => `${e.id}|${e.method}|${e.command}`
          const entryKey = kind === 'item' ? '限制物品' : '限制弹幕'
          const tierKey = (tiers) => tiers
            .map((t) => `${t.进度}=[${(t[entryKey] || []).map(key).sort().join(',')}]`)
            .sort()
            .join(' ')
          const want = tierKey(cfg[kind].限制列表 || [])
          const got = tierKey(state.config[kind].限制列表 || [])
          if (want !== got) {
            const wantN = (cfg[kind].限制列表 || []).reduce((n, t) => n + (t[entryKey] || []).length, 0)
            const gotN = (state.config[kind].限制列表 || []).reduce((n, t) => n + (t[entryKey] || []).length, 0)
            diff.push(`${kind === 'item' ? '物品' : '弹幕'}清单不一致：服端 ${gotN} 条（宿主 ${wantN} 条）`)
          }
        }

        out.push({
          id: String(server.id),
          name: String(server.name || server.id),
          ok: true,
          match: diff.length === 0,
          diff,
          version: state.version,
          updatedAt: state.updatedAt,
          source: state.source,
          file: state.file,
          legacyFiles: state.legacyFiles,
          saveError: state.saveError,
          importedLegacy: state.importedLegacy,
          importNotes: state.importNotes,
          detection: state.detection,
          logStore: state.logStore,
          trigger: state.trigger,
          hooks: state.hooks,
          error: '',
        })
      } catch (err) {
        out.push({
          id: String(server.id),
          name: String(server.name || server.id),
          ok: false,
          match: false,
          diff: [],
          error: err.message,
          serverHalfMissing: err.serverHalfMissing === true,
          status: err.status || 502,
        })
      }
    }
    return { servers: out }
  }

  // ═══════════════════════ 配置写入 ═══════════════════════

  /**
   * 写入配置：落盘 → 审计 → 立即下发。
   *
   * **先落盘再下发**（promotion 六要点之一）：宿主崩在两者之间时，重启后至少配置还在，
   * 且启动对账会把没推成功的补上；反过来（先推后落盘）会留下"服端已生效、宿主重启后回退旧值"
   * 这种最糟糕的状态。
   */
  async setConfig(config, { actor = '', action = ACTIONS.configSet, detail = {}, changedKeys = [] } = {}) {
    const next = normalizeConfig(config).config
    await saveConfigFile(this.configFile, next)

    const prev = this.config
    this.config = next
    this.configError = ''
    // 配置内容变了 → 修订号自增，让所有服的 acked 记录变成"落后"（否则它们会被误判成已是最新）
    this.configRevision += 1

    await this.audit.append(action, {
      actor,
      // 只记"改了哪些顶层字段与统计数字"，不记整份清单明文（审计流水里塞 16 KB 清单既没用又难读）
      changedKeys,
      before: configStats(normalizeConfig(prev).config),
      after: configStats(next),
      ...detail,
    })

    const push = this.push.pushOnChange === false
      ? { ok: false, total: 0, okCount: 0, pendingCount: this.pendingIds().length, reason: '变更即推已关闭', results: [], skipped: true }
      : await this.pushConfig({ reason: '配置变更' })

    return { config: next, push }
  }

  // ═══════════════════════ 日志服务（对外） ═══════════════════════

  /** 解析日志查询的目标服务器集合 */
  async resolveLogTargets({ serverId = null, aggregate = false } = {}) {
    const servers = await this.gameOps.enabledServers()
    if (servers.length === 0) return { servers: [], aggregate: false, error: '没有启用中的服务器：无法查询检测日志' }
    if (serverId != null && String(serverId) !== '') {
      const one = servers.find((s) => String(s.id) === String(serverId))
      if (!one) return { servers: [], aggregate: false, error: `目标服务器不存在或未启用：${serverId}` }
      return { servers: [one], aggregate: false, error: '' }
    }
    if (servers.length === 1) return { servers, aggregate: false, error: '' }
    return { servers, aggregate: aggregate !== false, error: '' }
  }

  /** 跨服日志聚合查询（`ctx.anticheatLog.query` 与 `/api/anticheat/logs` 同一实现） */
  async queryLogs(query = {}) {
    const target = await this.resolveLogTargets({ serverId: query.serverId, aggregate: query.aggregate })
    if (target.error) return { rows: [], total: 0, error: target.error, servers: [] }
    return queryLogs({
      servers: target.servers,
      gameOps: this.gameOps,
      query,
      aggregate: target.aggregate,
      itemData: this._service('itemData'),
      projectileData: this._service('projectileData'),
    })
  }

  /** 跨服日志统计 */
  async queryLogStats(query = {}) {
    const target = await this.resolveLogTargets({ serverId: query.serverId, aggregate: query.aggregate })
    if (target.error) {
      return { total: 0, today: 0, byCategory: {}, byMethod: {}, recent: [], perServer: [], error: target.error, note: '' }
    }
    return queryLogStats({
      servers: target.servers,
      gameOps: this.gameOps,
      query,
      itemData: this._service('itemData'),
      projectileData: this._service('projectileData'),
    })
  }

  /** 往指定服写一条日志（外部通道；未来的粒子插件与其它宿主插件用它） */
  async record(serverId, entry = {}) {
    const servers = await this.gameOps.enabledServers()
    const one = servers.find((s) => String(s.id) === String(serverId))
    if (!one) throw httpError(404, `目标服务器不存在或未启用：${serverId}`)
    const data = await this.gameOps.recordLog(one, entry)
    return { serverId: String(one.id), serverName: String(one.name || one.id), ...data }
  }

  /**
   * 取基础数据服务（软依赖）。
   * 必须经 `ctx.get`：`plugins/data-items` 的服务是用 `Service` 子类注册的，
   * 直接属性访问在未注入时会抛错（docs/插件开发约定.md:139-142），可选链也挡不住。
   */
  _service(n) {
    try {
      return this.ctx.get(n) || null
    } catch {
      return null
    }
  }
}

// ═══════════════════════ 插件入口 ═══════════════════════

export async function apply(ctx, options = {}) {
  try {
    return await applyInner(ctx, options)
  } catch (err) {
    // inject 延迟执行里的异常不会冒泡（docs/插件开发约定.md:118-137），所以这里必须自己兜住并打印
    console.error('[anti-cheat] 初始化失败: ' + err.message)
    if (process.env.TSWEB_DEBUG) console.error(err.stack)
    throw err
  }
}

async function applyInner(ctx, options = {}) {
  const dataDir = ctx.paths.dataOf('anti-cheat')
  const service = new AntiCheatService({
    ctx,
    dataDir,
    configFile: options.configFile,
    auditFile: options.auditFile,
    push: options.push,
  })
  await service.init()

  // 日志服务（对外公开；见 AntiCheatLogService 的说明）
  const logService = new AntiCheatLogService(ctx, service)
  ctx.anticheatLog = logService

  const app = ctx.webServer.app
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]

  /** 统一包装：把 err.status 翻成状态码，并保证**任何失败都有可见的 error 字段** */
  const wrap = (fn) => async (req, res) => {
    try {
      const body = await fn(req)
      res.status(200).json({ ok: true, ...body })
    } catch (err) {
      const status = Number(err.status) || 500
      console.error(`[anti-cheat] 请求失败 ${req.method} ${req.originalUrl || req.url}: ${err.message}`)
      res.status(status).json({
        ok: false,
        error: err.message,
        ...(err.errors ? { errors: err.errors } : {}),
        ...(err.warnings ? { warnings: err.warnings } : {}),
        ...(err.serverHalfMissing ? { serverHalfMissing: true, dllName: err.dllName || DLL_NAME, hint: err.hint || '' } : {}),
        ...(err.bytes ? { bytes: err.bytes, maxBytes: err.maxBytes } : {}),
      })
    }
  }

  const q = (req) => req.query || {}
  const body = (req) => (req.body && typeof req.body === 'object' ? req.body : {})

  /** 读操作的目标服务器：显式 serverId；未指定且只有一台则用它；多台则要求显式指定 */
  async function requireSingleServer(req, explicit) {
    const servers = await service.gameOps.enabledServers()
    const wanted = explicit != null && String(explicit) !== '' ? String(explicit) : ''
    if (wanted !== '') {
      const one = servers.find((s) => String(s.id) === wanted)
      if (!one) throw httpError(404, `目标服务器不存在或未启用：${wanted}`)
      return one
    }
    if (servers.length === 0) throw httpError(400, '没有启用中的服务器')
    if (servers.length > 1) {
      throw httpError(400, `有 ${servers.length} 台启用中的服务器，请显式指定 serverId（该操作是单服动作，不会替你随机挑一台）`)
    }
    return servers[0]
  }

  // ── 清单：读 ──
  app.get('/api/anticheat/config', ...admin, wrap(async () => {
    const status = service.status()
    const defaults = await service._defaultsOrNull()
    return {
      config: normalizeConfig(service.config).config,
      configFile: service.configFile,
      configError: service.configError,
      defaultsError: service.defaultsError,
      warnings: status.warnings,
      stats: status.stats,
      progressOrder: status.progressOrder,
      knownProgress: PROGRESS_ORDER.slice(),
      defaults: defaults
        ? { stats: defaults.stats, files: defaults.files, fixes: defaults.fixes, deferred: defaults.deferred, error: '', warnings: defaults.warnings }
        : { stats: null, files: null, fixes: [], deferred: [], error: service.defaultsError, warnings: [] },
      dependencies: {
        itemData: service._service('itemData') !== null,
        projectileData: service._service('projectileData') !== null,
      },
      methodValues: METHOD_VALUES.slice(),
      methodLabels: { ...METHOD_LABELS },
      quickCommands: QUICK_COMMANDS.map((c) => ({ ...c })),
      commandPlaceholders: COMMAND_PLACEHOLDERS.slice(),
    }
  }))

  // ── 清单：写（body，不走 query；必改缺陷 #5）──
  app.post('/api/anticheat/config', ...admin, wrap(async (req) => {
    const input = body(req)
    const { config, errors, warnings } = validateConfig(input)
    if (errors.length > 0) {
      throw httpError(400, `清单校验未通过（${errors.length} 项）：${errors.slice(0, 8).map((e) => `${e.path || '(根)'} ${e.message}`).join('；')}`, {
        errors,
        warnings,
      })
    }
    const actor = (req.user && (req.user.username || req.user.name)) || 'admin'
    const prev = normalizeConfig(service.config).config
    const res = await service.setConfig(config, {
      actor,
      changedKeys: changedKeys(prev, config),
      detail: { warnings: warnings.slice(0, 40), warningCount: warnings.length },
    })
    return { config: res.config, warnings, push: res.push }
  }))

  // ── 默认清单：预览与来源 ──
  app.get('/api/anticheat/defaults', ...admin, wrap(async () => {
    const defaults = await service._defaultsOrNull()
    if (!defaults) {
      // 读不到就**明确失败**：绝不回一个空清单让管理员点下去把配置清空
      throw httpError(501, `默认清单不可用：${service.defaultsError}`)
    }
    return {
      stats: defaults.stats,
      files: defaults.files,
      fixes: defaults.fixes,
      deferred: defaults.deferred,
      warnings: defaults.warnings,
      error: '',
      preview: previewDefaults(normalizeConfig(service.config).config, defaults.config, { scope: 'both', includeSwitches: false }),
    }
  }))

  // ── 默认清单：应用（显式 confirm；不 confirm 只回预览）──
  app.post('/api/anticheat/apply-defaults', ...admin, wrap(async (req) => {
    const b = body(req)
    const defaults = await service._defaultsOrNull()
    if (!defaults) throw httpError(501, `默认清单不可用：${service.defaultsError}`)

    const opts = { scope: b.scope, includeSwitches: b.includeSwitches === true }
    const preview = previewDefaults(normalizeConfig(service.config).config, defaults.config, opts)

    if (b.confirm !== true) {
      // 不 confirm → 只预览，不写任何东西（必改缺陷 #6：这个动作必须"可预览"）
      return { applied: false, preview, note: '这是预览，尚未改动任何配置；确认请再发一次并带 confirm=true' }
    }

    const applied = applyDefaults(normalizeConfig(service.config).config, defaults.config, opts)
    const actor = (req.user && (req.user.username || req.user.name)) || 'admin'
    const res = await service.setConfig(applied.config, {
      actor,
      action: ACTIONS.configApplyDefaults,
      changedKeys: ['item', 'proj'],
      detail: {
        scope: applied.scope,
        includeSwitches: applied.includeSwitches,
        changes: applied.changes,
        defaultsFiles: defaults.files,
        defaultsStats: defaults.stats,
        dataFixes: defaults.fixes.map((f) => f.id),
      },
    })
    return { applied: true, preview, changes: applied.changes, config: res.config, push: res.push, warnings: defaults.warnings }
  }))

  // ── 状态 + probe 自证 ──
  app.get('/api/anticheat/status', ...admin, wrap(async (req) => {
    const st = service.status()
    const probe = await service.probeServers({ serverIds: parseIds(q(req).serverIds) })
    return { ...st, probe }
  }))

  // ── 手动下发 ──
  app.post('/api/anticheat/push', ...admin, wrap(async (req) => {
    const b = body(req)
    let serverIds = null
    if (Array.isArray(b.serverIds)) {
      if (b.serverIds.length > PUSH_LIMIT) {
        throw httpError(400, `单次下发服务器上限 ${PUSH_LIMIT} 台（本次 ${b.serverIds.length} 台）`)
      }
      // 语义与宿主一致：[] = 明确"不下发"；未传 = 未指定（按模式默认，即全部启用服）
      serverIds = b.serverIds.map(String).filter((s) => s !== '')
    }
    const push = b.onlyPending === true
      ? await service.pushPending({ reason: '手动补推（仅未确认的服务器）' })
      : await service.pushConfig({ serverIds, reason: '手动重推' })
    return { push }
  }))

  // ── 检测日志：分页查询（跨服聚合）──
  app.get('/api/anticheat/logs', ...admin, wrap(async (req) => {
    const query = q(req)
    const out = await service.queryLogs({
      serverId: query.serverId,
      aggregate: query.aggregate !== undefined && String(query.aggregate) !== '0' && String(query.aggregate) !== 'false',
      page: query.page,
      pageSize: query.pageSize,
      category: query.category,
      method: query.method,
      player: query.player,
      q: query.q,
      timeFrom: query.timeFrom,
      timeTo: query.timeTo,
    })
    // 审计只记"谁查了日志"（查询本身会暴露全服玩家行为，留痕但不记筛选明细里的玩家名以外的隐私）
    service.audit.append(ACTIONS.logsQuery, {
      actor: (req.user && (req.user.username || req.user.name)) || 'admin',
      serverId: query.serverId || '',
      filters: { category: query.category || '', method: query.method || '', hasPlayer: Boolean(query.player), hasQ: Boolean(query.q), timeFrom: query.timeFrom || '', timeTo: query.timeTo || '' },
      total: out.total,
    }).catch((err) => console.error(`[anti-cheat] 审计写入失败：${err.message}`))
    return out
  }))

  app.get('/api/anticheat/logs/stats', ...admin, wrap(async (req) => {
    const query = q(req)
    const out = await service.queryLogStats({
      serverId: query.serverId,
      aggregate: query.aggregate !== undefined && String(query.aggregate) !== '0' && String(query.aggregate) !== 'false',
      category: query.category,
      method: query.method,
      player: query.player,
      q: query.q,
      timeFrom: query.timeFrom,
      timeTo: query.timeTo,
    })
    return out
  }))

  /**
   * 异常物品判定（真正实现，而不是旧版"恒 200 且恒 false"）。
   *
   * 旧版缺陷：`/api/anticheat/check-anomaly` 在前端与后端都有引用，但 **C# 从未注册该端点**
   * （规格 A §6.0/规格 B §3.5 双向核对），于是它恒返回 200 且恒 false；同时旧前端
   * `UserDetailView.vue:13-23` 又自己在前端重算了一遍（读 `config.items`，而真名是
   * `限制列表[].限制物品[].stack`）→ **违禁告警永远为空**。
   *
   * 本件的改法：**判定放回服端权威执行**。因为"哪些档位当前生效"取决于**世界进度**
   * （BossProgress.GetWorldStatus 要读 NPC.downed* / 击杀计数），那是游戏服进程内的状态，
   * 宿主不可能知道。所以本端点转发到服端 `/data/anticheat/check-anomaly`，返回真实判定。
   */
  app.get('/api/anticheat/check-anomaly', ...admin, wrap(async (req) => {
    const query = q(req)
    const id = Number(query.id)
    const stack = Number(query.stack)
    if (!Number.isInteger(id) || id <= 0) throw httpError(400, '缺少有效的 id 参数（物品 ID）')
    if (!Number.isInteger(stack) || stack < 0) throw httpError(400, '缺少有效的 stack 参数（持有数量）')
    const server = await requireSingleServer(req, query.serverId)
    const out = await service.gameOps.checkAnomaly(server, { id, stack })
    return { ...out, serverId: String(server.id), serverName: String(server.name || server.id) }
  }))

  // ── 审计流水 ──
  app.get('/api/anticheat/audit', ...admin, wrap(async (req) => ({
    rows: await service.audit.tail(Number(q(req).limit) || 50),
  })))

  // ── 手动扫描（会真的执行处置，与旧版 scanall 一致）──
  app.post('/api/anticheat/scan', ...admin, wrap(async (req) => {
    const b = body(req)
    const server = await requireSingleServer(req, b.serverId)
    const scan = await service.gameOps.scanAll(server)
    await service.audit.append(ACTIONS.configSet, {
      actor: (req.user && (req.user.username || req.user.name)) || 'admin',
      action2: 'scan',
      serverId: String(server.id),
      scannedPlayers: scan.scannedPlayers,
      violationCount: scan.violationCount,
    }).catch(() => {})
    return { scan, serverId: String(server.id), serverName: String(server.name || server.id) }
  }))

  // ── 按物品查持有者（纯查询）──
  app.get('/api/anticheat/scan-by-id', ...admin, wrap(async (req) => {
    const query = q(req)
    const itemId = Number(query.itemId)
    if (!Number.isInteger(itemId) || itemId <= 0) throw httpError(400, '缺少有效的 itemId 参数')
    const server = await requireSingleServer(req, query.serverId)
    const out = await service.gameOps.scanById(server, itemId)
    return { ...out, serverId: String(server.id), serverName: String(server.name || server.id) }
  }))

  // ── 连接恢复补推（对齐既有插件的做法）──
  const repush = (why) => {
    if (service.push.pushOnServerConnect === false) return
    service.pushPending({ reason: why }).catch((err) => {
      console.error(`[anti-cheat] ${why}补推失败：${err.message}`)
    })
  }
  try {
    ctx.on('push/connected', () => repush('服务器连接建立'))
    ctx.on('servers/loaded', () => repush('服务器列表加载'))
  } catch (err) {
    // ctx.on 在个别宿主版本上不可用/不允许：补推少一层兜底但插件照常工作，如实记录
    console.error(`[anti-cheat] 事件订阅失败（连接恢复补推不可用）：${err.message}`)
  }

  const dep = service._service('itemData') !== null && service._service('projectileData') !== null
  const st = service.status()
  console.log(
    `[anti-cheat] 已挂载：物品清单 ${st.stats.itemEntries} 条 / ${st.stats.itemTiers} 档、` +
    `弹幕清单 ${st.stats.projEntries} 条 / ${st.stats.projTiers} 档（检测${service.config.item.启用 ? '物品已启用' : '物品未启用'}/` +
    `${service.config.proj.启用 ? '弹幕已启用' : '弹幕未启用'}）；` +
    `端点 ${SERVER_HALF_PREFIX}/snapshot（需要游戏服安装 ${DLL_NAME}）；` +
    `基础数据 ${dep ? '已就绪（ID→名称兜底可用）' : '不完整（日志行将只显示 ID）'}` +
    (service.configError ? `；配置有问题：${service.configError}` : ''),
  )

  // 返回 dispose effect：cordis 在插件禁用/卸载时调用（停定时器）
  return () => service.dispose()
}

// ═══════════════════════ 小工具 ═══════════════════════

/** 解析逗号分隔的 id 列表（query 参数） */
function parseIds(value) {
  if (value == null || String(value).trim() === '') return null
  return String(value).split(',').map((s) => s.trim()).filter((s) => s !== '')
}

/** 列出两份配置的"顶层字段 + 统计"变化（进审计；不记整份清单明文） */
function changedKeys(prev, next) {
  const keys = []
  for (const kind of ['item', 'proj']) {
    for (const [k, v] of Object.entries(next[kind] || {})) {
      if (k === '限制列表') continue
      if (prev[kind]?.[k] !== v) keys.push(`${kind}.${k}`)
    }
    const before = JSON.stringify(prev[kind]?.限制列表 || [])
    const after = JSON.stringify(next[kind]?.限制列表 || [])
    if (before !== after) keys.push(`${kind}.限制列表`)
  }
  return keys
}
