/**
 * 本件审计流水（<dataDir>/anti-cheat/audit.jsonl，追加写）
 *
 * 为什么反作弊必须有自己的审计流水（旧版**完全没有**，规格 B §5.4 逐字：「后端无持久化状态……
 * 也没有审计记录」）：
 *   1. `method='command'` 的自定义处置命令会**以服务器身份执行**（旧版缺陷 #1 / D-34）。
 *      转义只能防"参数注入"，**防不住"有权写配置的人主动写入任意命令"** —— 唯一可行的约束是
 *      "谁在什么时候把哪条命令写了进去"必须可追溯。本件的每一次清单写入都进审计。
 *   2. 「应用默认配置」会整体替换清单（可能删掉管理员自定义的档位），必须留下"谁点了、替换了什么"。
 *   3. 下发与探测结果本身就是"配置是否真生效"的证据链。
 *
 * 动作名与旧版后端语义对齐（旧版没有审计，这里按 promotion/audit.js 的命名风格定义）：
 *   anticheat.config.set           清单写入（谁、改了哪些顶层字段、警告条数）
 *   anticheat.config.seed          首次运行的默认清单播种（从插件内 resources/ 装入）
 *   anticheat.config.applydefaults 「应用默认配置」（含 scope 与改动摘要）
 *   anticheat.config.importlegacy  从旧版 TSWeb/AntiCheat 配置迁移（发生在服端，宿主只记自己这侧的导入）
 *   anticheat.logs.query           跨服日志查询（只读，但会暴露全服玩家行为，故留痕）
 *
 * 写法刻意保持极简（JSONL 追加 + 单文件上限轮转），并按插件各存一份：不依赖其它插件的模块。
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import { appendFile, mkdir, readFile, rename, stat } from 'node:fs/promises'
import path from 'node:path'

/** 单文件上限（超过则轮转为 audit.jsonl.1），避免无限增长 */
const MAX_BYTES = 8 * 1024 * 1024

/** 本件的审计动作名（唯一权威定义，测试与文档都引这里） */
export const ACTIONS = {
  configSet: 'anticheat.config.set',
  configSeed: 'anticheat.config.seed',
  configApplyDefaults: 'anticheat.config.applydefaults',
  configImportLegacy: 'anticheat.config.importlegacy',
  logsQuery: 'anticheat.logs.query',
}

export class AuditLog {
  constructor({ file }) {
    if (!file) throw new Error('AuditLog 需要 file 路径')
    this.file = file
    this.dir = path.dirname(file)
  }

  /**
   * 追加一条审计。
   * @param {string} action 见 ACTIONS
   * @param {object} entry  { actor, ...detail }
   */
  async append(action, entry = {}) {
    const line = JSON.stringify({
      t: new Date().toISOString(),
      action: String(action),
      actor: entry.actor != null ? String(entry.actor) : '',
      ...entry,
    }) + '\n'
    await mkdir(this.dir, { recursive: true })
    await this._rotateIfNeeded()
    await appendFile(this.file, line, 'utf8')
    return true
  }

  async _rotateIfNeeded() {
    try {
      const st = await stat(this.file)
      if (st.size >= MAX_BYTES) await rename(this.file, `${this.file}.1`)
    } catch (err) {
      if (err.code !== 'ENOENT') throw err
    }
  }

  /** 读取最近 n 条（新的在前）；文件不存在返回空数组，坏行降级为 parse-error 行 */
  async tail(limit = 100) {
    const n = Math.min(Math.max(1, Number(limit) || 100), 1000)
    let raw
    try {
      raw = await readFile(this.file, 'utf8')
    } catch (err) {
      if (err.code === 'ENOENT') return []
      throw err
    }
    const lines = raw.split('\n').filter((l) => l.trim() !== '')
    const out = []
    for (let i = lines.length - 1; i >= 0 && out.length < n; i--) {
      try {
        out.push(JSON.parse(lines[i]))
      } catch {
        out.push({ t: null, action: 'parse-error', raw: lines[i].slice(0, 200) })
      }
    }
    return out
  }
}
