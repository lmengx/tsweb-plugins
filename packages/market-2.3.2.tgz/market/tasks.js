import fs from 'node:fs/promises'
import path from 'node:path'
import crypto from 'node:crypto'

const pending = job => ['waiting', 'active'].includes(job.state)
const conflict = message => Object.assign(new Error(message), { status: 409 })

/** One durable queue per runtime data directory. The controller survives market's
 * own hot replacement; only its service adapter is replaced by the new fiber. */
export async function attachTaskQueue(service) {
  const key = Symbol.for('tsweb.market.task-queues.v1')
  const queues = globalThis[key] ||= new Map()
  const directory = path.resolve(service.dataDir)
  let queue = queues.get(directory)
  if (!queue) {
    queue = new MarketTaskQueue(path.join(directory, 'tasks.json'))
    queues.set(directory, queue)
  }
  await queue.ready
  queue.service = service
  service.taskQueue = queue
  queue.schedule()
  service.ctx.on('dispose', () => {
    if (queue.service === service) queue.service = null
  })
  return queue
}

export class MarketTaskQueue {
  constructor(file) {
    this.file = file
    this.jobs = []
    this.paused = false
    this.revision = 0
    this.service = null
    this.running = false
    this.executingId = null
    this.timer = null
    this.writeChain = Promise.resolve()
    this.changeChain = Promise.resolve()
    this.ready = this.load()
  }

  async load() {
    let snapshot
    try { snapshot = JSON.parse(await fs.readFile(this.file, 'utf8')) }
    catch (error) {
      if (error.code === 'ENOENT') return
      // Never erase an unreadable queue and silently start again.
      throw new Error(`更新任务读取失败，原文件已保留：${error.message}`)
    }
    if (snapshot.schema !== 1 || !Array.isArray(snapshot.jobs)) throw new Error('更新任务文件格式无效，原文件已保留')
    this.jobs = snapshot.jobs
    this.paused = snapshot.paused === true
    this.revision = Number(snapshot.revision) || 0
    // A process crash may have committed the installation. Require an explicit
    // retry and recheck the registry instead of executing it a second time.
    for (const job of this.jobs) if (job.state === 'active') {
      job.state = 'failed'
      job.error = '面板在任务执行期间停止，请核对安装状态后重试。'
      job.finishedAt = Date.now()
      this.paused = true
    }
    await this.persist()
  }

  persist() {
    const snapshot = JSON.stringify({ schema: 1, jobs: this.jobs, paused: this.paused, revision: this.revision }, null, 2)
    const write = async () => {
      await fs.mkdir(path.dirname(this.file), { recursive: true })
      const tmp = `${this.file}.${crypto.randomUUID()}.tmp`
      try { await fs.writeFile(tmp, snapshot); await fs.rename(tmp, this.file) }
      finally { await fs.rm(tmp, { force: true }).catch(() => {}) }
    }
    const result = this.writeChain.then(write)
    this.writeChain = result.catch(() => {})
    return result
  }

  change(action) {
    const result = this.changeChain.then(action)
    this.changeChain = result.catch(() => {})
    return result
  }

  assertAvailable(taskId) {
    if ((this.running || this.jobs.some(pending)) && taskId !== this.executingId)
      throw conflict('更新任务队列正在使用安装通道，请先等待完成或取消待执行任务。')
  }

  assertPluginMutable(name) {
    if (this.jobs.some(job => job.name === name && pending(job))) throw conflict('该插件已在更新任务中，请先完成或取消任务。')
  }

  async plan(name, action, installDeps) {
    const svc = this.service
    if (!svc) throw conflict('插件市场正在重新加载，请稍后重试')
    if (!['install', 'update', 'host-ui'].includes(action)) throw Object.assign(new Error('无效任务类型'), { status: 400 })
    if ((name === 'web') !== (action === 'host-ui')) throw conflict('宿主前端必须通过前端投放通道更新')
    const index = await svc.fetchIndex()
    const entry = svc.findEntry(index, name)
    const installed = await svc.installedNames()
    if (action === 'install' && installed.has(name)) throw conflict('该插件已安装，请使用更新')
    if (action !== 'install' && !installed.has(name)) throw conflict('该插件尚未安装')
    const closure = svc.dependencyClosure(index, name)
    const missing = closure.filter(dep => !installed.has(dep.name))
    if (missing.length && !installDeps) throw svc.missingDepsError(name, missing)
    return { version: entry.version, sha256: entry.sha256 || '', size: entry.size || 0,
      hasClient: !!entry.hasClient, dependencies: missing.map(dep => dep.name) }
  }

  async enqueue({ name, action, installDeps = false }) {
    return this.change(async () => {
      name = String(name || '').trim()
      const existing = this.jobs.find(job => job.name === name && pending(job))
      if (existing) return { task: { ...existing }, duplicate: true }
      if (this.jobs.filter(pending).length >= 100) throw conflict('待执行任务最多 100 项，请先处理已有任务')
      const plan = await this.plan(name, action, installDeps === true)
      const task = { id: crypto.randomUUID(), name, action, ...plan, installDeps: installDeps === true,
        state: 'waiting', createdAt: Date.now(), refreshRequired: false, refreshAcknowledged: false, error: '' }
      this.jobs.push(task)
      this.revision++
      try { await this.persist() } catch (error) { this.jobs.pop(); this.revision++; throw error }
      this.schedule()
      return { task: { ...task }, duplicate: false }
    })
  }

  async control({ action, id, ids, revision }) {
    return this.change(async () => {
      if (action === 'reorder') {
        const waiting = this.jobs.filter(job => job.state === 'waiting')
        if (revision !== this.revision || !Array.isArray(ids) || ids.length !== waiting.length || new Set(ids).size !== ids.length || waiting.some(job => !ids.includes(job.id)))
          throw conflict('任务状态已变化，已重新读取顺序，请再拖动一次。')
        const byId = new Map(waiting.map(job => [job.id, job]))
        let position = 0
        this.jobs = this.jobs.map(job => job.state === 'waiting' ? byId.get(ids[position++]) : job)
      } else if (action === 'pause') this.paused = true
      else if (action === 'resume') this.paused = false
      else if (action === 'cancel') {
        const job = this.jobs.find(job => job.id === id)
        if (!job || job.state !== 'waiting') throw conflict('只能取消尚未开始的任务，当前任务会安全完成。')
        job.state = 'cancelled'; job.finishedAt = Date.now()
      } else if (action === 'retry') {
        const job = this.jobs.find(job => job.id === id)
        if (!job || !['failed', 'cancelled'].includes(job.state) || this.jobs.some(other => other.name === job.name && pending(other))) throw conflict('该任务不能重试或已经在队列中')
        // Retry uses the current published package, including versions that were
        // published while the interrupted task was waiting.
        const installed = await this.service.installedNames()
        const nextAction = job.action === 'host-ui' ? 'host-ui' : installed.has(job.name) ? 'update' : 'install'
        Object.assign(job, await this.plan(job.name, nextAction, job.installDeps), { action: nextAction,
          state: 'waiting', error: '', finishedAt: null, startedAt: null })
      } else if (action === 'clear') {
        this.jobs = this.jobs.filter(job => pending(job) || (job.state === 'done' && ((job.refreshRequired && !job.refreshAcknowledged) || this.restartIds(job).length)))
      } else if (action === 'acknowledge-refresh') {
        if (!Array.isArray(ids)) throw Object.assign(new Error('缺少待生效任务'), { status: 400 })
        for (const job of this.jobs) if (ids.includes(job.id) && job.state === 'done') job.refreshAcknowledged = true
      } else throw Object.assign(new Error('无效任务操作'), { status: 400 })
      this.revision++
      try { await this.persist() }
      catch (error) { this.paused = true; this.revision++; throw error }
      this.schedule()
    })
  }

  restartIds(job) {
    if (job.state !== 'done') return []
    const entry = this.service?.ctx.plugins.entries?.find(entry => entry.name === job.name)
    return Object.entries(entry?.servers || {}).filter(([, state]) => state === 'pending').map(([id]) => id)
  }

  snapshot() {
    return { revision: this.revision, paused: this.paused, jobs: this.jobs.map(job => {
      const op = job.state === 'active' ? this.service?.listOperations().find(op => op.name === job.name) : null
      return { ...job, refreshRequired: job.refreshRequired && !job.refreshAcknowledged,
        restartServerIds: this.restartIds(job), progress: op || null }
    }) }
  }

  schedule() {
    if (this.timer || this.running || this.paused || !this.service || !this.jobs.some(job => job.state === 'waiting')) return
    // Let enqueue/reorder HTTP responses finish before starting the next item.
    this.timer = setTimeout(() => { this.timer = null; this.pump().catch(error => console.error('[market] 更新任务异常：' + error.message)) }, 100)
    this.timer.unref?.()
  }

  async execute(job, svc) {
    const index = await svc.fetchIndex()
    const entry = svc.findEntry(index, job.name)
    if (entry.version !== job.version || (job.sha256 && entry.sha256 !== job.sha256)) throw new Error('等待期间市场版本已变化，请重试以确认最新版本。')
    const installed = (svc.ctx.plugins.entries || []).find(entry => entry.name === job.name)
    if (job.action === 'install' && installed && await svc.ctx.plugins.dirExists(job.name)) {
      if (installed.version === job.version) return { warning: '已由先前任务安装，无需重复安装', refreshRequired: job.hasClient }
      throw new Error('插件已由其它操作安装，请取消此任务后重新加入更新。')
    }
    const opts = { installDeps: job.installDeps, taskId: job.id }
    if (job.action === 'host-ui') return svc.applyHostUi(opts)
    if (job.name === 'market') {
      const plan = await svc.prepareSelfUpdate(opts)
      return { ...(await svc.applySelfUpdate(plan)), refreshRequired: true }
    }
    const result = job.action === 'install' ? await svc.install(job.name, opts) : await svc.update(job.name, opts)
    return { ...result, refreshRequired: job.hasClient || (result.dependencies || []).some(dep => index.packages.find(p => p.name === dep.name)?.hasClient) }
  }

  async pump() {
    if (this.running || this.paused || !this.service) return
    if (this.service.listOperations().some(op => !['done', 'failed'].includes(op.phase))) {
      this.schedule()
      return
    }
    const job = this.jobs.find(job => job.state === 'waiting')
    if (!job) return
    this.running = true
    this.executingId = job.id
    job.state = 'active'; job.startedAt = Date.now(); this.revision++
    try {
      await this.persist()
      const result = await this.execute(job, this.service)
      job.state = 'done'
      job.refreshRequired = !!result.refreshRequired
      job.warning = result.warning || ''
      job.version = result.to || result.version || job.version
    } catch (error) {
      job.state = 'failed'; job.error = String(error.message || error)
      // A failed dependency or update must not let later dependent tasks run.
      this.paused = true
    } finally {
      job.finishedAt = Date.now(); this.revision++
      try { await this.persist() }
      catch (error) { this.paused = true; console.error('[market] 更新任务保存失败：' + error.message) }
      this.executingId = null
      this.running = false
      this.schedule()
    }
  }
}
