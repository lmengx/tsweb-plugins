import accessContract from './access.js'
import { attachTaskQueue } from './tasks.js'
/**
 * 插件市场插件（cordis）
 *
 * 职责：从市场仓库（tsweb-plugins）拉取集中索引 market.json，把其中的 tgz 发行包安装到本机运行时插件目录。
 *
 * 市场仓库的约定（只存发行包与元数据，不存源码）：
 *   tsweb-plugins/
 *   ├── market.json                  索引：每个插件当前版本的 name/version/url/sha256/size/dll[]
 *   └── packages/<name>-<ver>.tgz    发行包（顶层 <name>/，含 package.json/index.js + 前端编译产物 dist//plugin/*.dll）
 *
 * 安装/更新完全复用宿主注册表能力：ctx.plugins.installFromTgz / updateFromTgz / uninstall，
 * 因此"市场装"与"本地 tgz 装"走同一条落位与校验路径，不会出现两套逻辑分叉。
 *
 * 两条取包通道：
 *   1. 在线：从自建 R2 直链（cloudflare）取索引与包
 *   2. 离线：配置 localDir 指向市场仓库工作副本，直接读本地文件（用于 push 之前自测）
 *
 * 配置：<dataDir>/market/config.json（首次运行写出默认值）
 *   { repo, branch, mirrorOrder, localDir, timeoutMs }
 */
import crypto from 'node:crypto'
import { compareVersions, pluginCompatibility } from '../../src/plugin-contract.js'
import { canUninstall as pluginCanUninstall, canUpdate as pluginCanUpdate } from '../../src/plugin-gates.js'
import fs from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import { Service } from '@deepseek-ai/cordis'

export const name = 'market'
// 安装、更新后的游戏服同步统一由宿主 registry 管理。
export const inject = ['webServer', 'auth', 'plugins', 'servers', 'terminal', 'paths']

/** 市场自身在索引与登记表里的插件名；自更新分支用它判定"要更新的就是我自己" */
const SELF_NAME = 'market'
/**
 * 携带游戏服核心件的插件名。base 的 C# 半是游戏服上的核心件（控制台 / 世界启动 / 玩家管理），
 * 市场页要把它与普通业务插件分开呈现（更新影响不同：游戏服 DLL 会重新同步，接收端不随插件走）。
 * 它同时是"可更新的内置插件"，判定在 src/plugin-gates.js。
 */
const CORE_NAME = 'base'
/**
 * 宿主前端的载体插件名。
 *
 * `web` 插件的 `public/` 就是整个面板前端（index.html + assets + sdk.js + vendor），
 * 由 `pack-plugin.mjs` 在打包 `web` 时用 buildHost 现构建进包（914 KB 左右）。
 * 它的**后端半**属于自带插件、`canUpdate` 明确拒绝热更新（换掉静态服务会打断正在跑的宿主），
 * 但**静态资源**可以单独投放——`applyHostUi()` 就只替换 `plugins/web/public/`，
 * 让"添加服务器向导/初始化弹窗"这类纯前端改动不必等整包发行。
 */
const HOST_UI_NAME = 'web'
/**
 * 面板运行所依赖、**不允许在界面上停用**的插件（启用不受限）。
 *   - accounts：登录与鉴权，停掉就没法登录；
 *   - servers：服务器注册表与 REST 代理；
 *   - web：面板前端静态资源与 /api/me；
 *   - market：就是当前这个页面本身，停用会 dispose 掉自己注册的路由。
 * 它们仍可被卸载门禁拦（web/accounts/servers 在 BUILTIN、market 在 NO_UNINSTALL），
 * 但"禁用"在 registry 层没有任何门禁，所以必须在这里挡。
 */
const PANEL_CRITICAL = new Set(['accounts', 'servers', HOST_UI_NAME, SELF_NAME])

const DEFAULT_CONFIG = {
  repo: 'lmengx/tsweb-plugins',
  branch: 'main',
  /** 镜像候选顺序：失败自动切换到下一个，成功的被记住并优先复用 */
  mirrorOrder: ['cloudflare'],
  /** 离线模式：指向市场仓库工作副本；非空时优先于在线拉取（push 前自测用） */
  localDir: '',
  /** 覆盖下载基址（自建镜像/内网分发/本地联调用）：非空时替代 mirrors 模板，形如 http://host/path */
  mirrorOverride: '',
  /** 拉索引的超时（毫秒）：索引只有几十 KB，短超时快速切换镜像 */
  timeoutMs: 20000,
  /** 已投放的宿主前端：{ version, sha256, appliedAt, backup }；空对象表示仍是发行包自带的那份 */
  hostUi: {},
  /**
   * 下载发行包的超时（毫秒）。
   *
   * 实测教训：base 的包里带 9.5 MB 地图贴图资源，整包 9.76 MB；用同一个 20 秒超时去下载，
   * 在 1.8 Mbps 的镜像上要 43 秒，于是每次都在 20 秒被 abort——市场报"下载发行包失败"，
   * 而失败分支原本不打日志，服务器窗口看起来"毫无反应"。包下载必须独立给足时间。
   */
  packageTimeoutMs: 180000,
  /** 索引缓存有效期（毫秒） */
  cacheTtlMs: 10 * 60 * 1000,
  /** 收藏的插件名（市场页「收藏」栏用；存在服务端，换浏览器/清缓存都不丢） */
  favorites: [],
}

/**
 * 镜像模板：{repo}/{branch} 由配置替换。
 *
 * **GitHub 与 gh-proxy 已弃用**（2026-10-30）：raw.githubusercontent.com 在国内解析到黑洞地址，
 * gh-proxy 只是它的公共前缀代理（同一套上游，同一套失败），两者一起失去存在意义。
 * 现在只有一个来源：自建 Cloudflare R2 直链（桶 tlry-plugins，自定义域直出，包不经过 Worker）。
 * 老配置里残留的 'github'/'ghproxy' 会被 baseUrls() 的 `MIRRORS[id]` 过滤掉，不会报错，无需迁移。
 */
const MIRRORS = {
  /**
   * 自建 Cloudflare R2 直链（与 mods-market 同一套架构：R2 桶 + 自定义域直出，包不经过 Worker）。
   * 键与仓库目录一致：/market.json 与 /packages/<file>.tgz。
   *
   * 实测：R2 直链索引亚秒级，9.76 MB 的 base 包 3~13 秒。
   */
  cloudflare: 'https://cdn.plugin.tlry.me',
}

function sha256(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex')
}

function human(bytes) {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(2) + ' MB'
}

/**
 * 「这个插件有没有可用更新」的**唯一**判定入口。
 *
 * 以前 `list()`（市场列表）与 `installedOverview()`（已安装页）各写一套：
 * 前者把"版本相同但 packageHash 与索引 sha256 不一致"也算更新，后者只比版本。
 * 于是界面出现幽灵徽标——页签上写 1、点进去变 0；宿主区说「1 项可更新」，
 * 三张卡却都写着"已是最新"（卡片走的是前端投放记录那套）。两处提示都消除不掉。
 * 现在两边都只调这里，徽标和按钮永远同源。
 *
 * `web` 是例外：它的"已装版本"是**前端 bundle 的投放记录**，而且投放是幂等的
 * （同版本再投会被 `/api/market/host-ui` 直接拒"无需重复投放"），所以只比投放版本，
 * 不参与"同版本不同哈希"那条规则——否则会给一个点了必然失败的更新按钮。
 */
function computeHasUpdate({ name, pkg, entryVersion, entryHash, appliedBundleVersion }) {
  if (!pkg || !pkg.version) return false
  if (name === HOST_UI_NAME) {
    const current = appliedBundleVersion || entryVersion
    return !!current && current !== pkg.version
  }
  const direction = compareVersions(pkg.version, entryVersion)
  if (direction !== null && direction > 0) return true
  // 版本相同但包内容变了（同版本重发）也算可更新：registry 的 updateFromTgz 不校验版本，能真的换掉
  return direction === 0 && !!pkg.sha256 && !!entryHash && String(entryHash).toLowerCase() !== String(pkg.sha256).toLowerCase()
}

export class MarketService extends Service {
  constructor(ctx, options = {}) {
    // 必须继承 Service 并以 super(ctx,'market') 注册：cordis 不允许插件直接
    // 往 ctx 上赋一个未声明的服务名（会报 cannot set property "market" without provide）
    super(ctx, 'market')
    this.ctx = ctx
    this.dataDir = options.dataDir ?? ctx.paths?.dataOf('market') ?? path.join(process.cwd(), 'data', 'market')
    this.configPath = path.join(this.dataDir, 'config.json')
    this.config = { ...DEFAULT_CONFIG, ...options }
    this.index = null          // market.json 内容
    this.indexAt = 0           // 拉取时间戳（缓存用）
    this.preferredMirror = null
    /** 正在进行的安装/更新：name -> { phase, label, done, total, startedAt }（市场页轮询 /api/market/progress） */
    this.operations = new Map()
    /** 读配置时发现的问题（文件损坏等），如实回显给管理员；空串 = 正常 */
    this.loadError = ''
  }

  /**
   * 读配置。
   *
   * **文件不存在**（全新安装）与**内容损坏**必须分开处理：
   * 老写法是裸 `catch { await this.saveConfig() }`，两者一视同仁——
   * 于是配置一旦损坏（写一半崩溃、磁盘满、手工改错一个逗号），用户的收藏与镜像偏好
   * 会被**静默清空并覆写**，无备份、无提示，原文件不可恢复。
   *
   * 现在的取向与本仓既有范式一致（见 task-scheduler/index.js:194-205 对旧版缺陷 D29 的修法）：
   * 损坏时把原文件另存为 .corrupt-<ts>、以默认值运行、并把原因记在 loadError 上如实回显，
   * **不覆盖磁盘上的原文件**——用户仍有救回来的机会。
   */
  async loadConfig() {
    let raw
    try {
      raw = await fs.readFile(this.configPath, 'utf8')
    } catch (err) {
      if (err.code === 'ENOENT') {
        // 全新安装：没有文件是正常状态，落一份默认配置
        this.loadError = ''
        await this.saveConfig()
        return this.config
      }
      // 读不了（权限/IO）不当作"没有配置"去覆盖：保留现状并如实报错
      this.loadError = `配置读取失败（${err.message}）；本次按默认值运行，未改动磁盘文件。`
      console.error(`[market] 配置读取失败：${err.message}`)
      return this.config
    }

    try {
      const parsed = JSON.parse(raw)
      this.config = { ...DEFAULT_CONFIG, ...parsed }
      this.loadError = ''
    } catch (err) {
      const backup = `${this.configPath}.corrupt-${Date.now()}`
      try {
        await fs.copyFile(this.configPath, backup)
      } catch (copyErr) {
        console.error(`[market] 备份损坏配置失败：${copyErr.message}`)
      }
      this.config = { ...DEFAULT_CONFIG }
      this.loadError = `配置文件无法解析（${err.message}）；已另存为 ${backup}，`
        + `当前按默认值运行。在修复该文件或保存一次配置之前，不会覆盖磁盘上的原文件。`
      console.error(`[market] 配置解析失败：${err.message}（已另存 ${backup}）`)
    }
    return this.config
  }

  async saveConfig() {
    await fs.mkdir(this.dataDir, { recursive: true })
    await fs.writeFile(this.configPath, JSON.stringify(this.config, null, 2), 'utf8')
  }

  /** 候选基址顺序：成功的镜像优先，其余按配置顺序 */
  baseUrls() {
    const override = String(this.config.mirrorOverride || '').trim()
    if (override) {
      // 覆盖模式下只用一个基址（自建镜像/内网/本地联调），不再尝试公共镜像
      return [{ id: 'override', base: override.replace(/\/+$/, '') }]
    }
    const order = (this.config.mirrorOrder || DEFAULT_CONFIG.mirrorOrder).filter((id) => MIRRORS[id])
    const rest = Object.keys(MIRRORS).filter((id) => !order.includes(id))
    const list = this.preferredMirror
      ? [this.preferredMirror, ...order.filter((i) => i !== this.preferredMirror), ...rest]
      : [...order, ...rest]
    return list.map((id) => ({
      id,
      base: MIRRORS[id].replace('{repo}', this.config.repo).replace('{branch}', this.config.branch),
    }))
  }

  async fetchWithTimeout(url, timeoutMs) {
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), timeoutMs)
    try {
      const res = await fetch(url, { signal: ctrl.signal, redirect: 'follow' })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      return Buffer.from(await res.arrayBuffer())
    } catch (err) {
      // abort 的原始文案是 "This operation was aborted"，对排查毫无信息量：换成"多久没下完"
      if (err?.name === 'AbortError') throw new Error(`超过 ${Math.round(timeoutMs / 1000)} 秒未完成`)
      throw err
    } finally {
      clearTimeout(timer)
    }
  }

  /**
   * 带进度回调的下载：逐块读响应体，把已收字节数报给调用方。
   *
   * 为什么单独一条：`fetchWithTimeout` 用 `arrayBuffer()` 一次性取回，网络再慢界面上
   * 也只有"没有任何动静"。市场页要显示安装进度就必须能看到字节在增长。
   * 响应没有 `content-length` 时 `total` 记 0，前端据此显示不确定态（来回滚动的进度条）。
   */
  async fetchWithProgress(url, timeoutMs, onProgress) {
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), timeoutMs)
    try {
      const res = await fetch(url, { signal: ctrl.signal, redirect: 'follow' })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const total = Number(res.headers.get('content-length')) || 0
      if (!res.body || typeof res.body.getReader !== 'function') {
        onProgress?.({ done: 0, total })
        return Buffer.from(await res.arrayBuffer())
      }
      const reader = res.body.getReader()
      const chunks = []
      let done = 0
      onProgress?.({ done, total })
      for (;;) {
        const { done: finished, value } = await reader.read()
        if (finished) break
        chunks.push(Buffer.from(value))
        done += value.length
        onProgress?.({ done, total })
      }
      onProgress?.({ done, total: total || done })
      return Buffer.concat(chunks)
    } catch (err) {
      if (err?.name === 'AbortError') throw new Error(`超过 ${Math.round(timeoutMs / 1000)} 秒未完成`)
      throw err
    } finally {
      clearTimeout(timer)
    }
  }

  /** 开始记录一次安装/更新：前端按 name 对齐到卡片，phase 是当前阶段，done/total 是下载字节 */
  beginOperation(name, action) {
    const op = {
      name,
      action,
      phase: 'prepare',
      label: '读取市场索引',
      done: 0,
      total: 0,
      startedAt: Date.now(),
      updatedAt: Date.now(),
    }
    this.operations.set(name, op)
    return op
  }

  /** 推进阶段；`done`/`total` 单位为字节，只在下钻包时有意义 */
  stepOperation(name, patch) {
    const op = this.operations.get(name)
    if (!op) return
    Object.assign(op, patch, { updatedAt: Date.now() })
  }

  /** 收尾：成功保留 3 秒（让界面看到 100%），失败保留 20 秒（够读完原因） */
  finishOperation(name, error) {
    const op = this.operations.get(name)
    if (!op) return
    if (error) {
      op.phase = 'failed'
      op.error = String(error.message || error)
    } else {
      op.phase = 'done'
      op.label = '已完成'
      if (op.total) op.done = op.total
    }
    op.updatedAt = Date.now()
    const timer = setTimeout(() => this.operations.delete(name), error ? 20000 : 3000)
    timer.unref?.()
  }

  /** 正在进行的安装/更新（市场页轮询用） */
  listOperations() {
    return [...this.operations.values()].map((op) => ({ ...op }))
  }

  /** 已经投放过的宿主前端（空 = 仍是发行包自带的那份） */
  hostUiState() {
    const applied = this.config.hostUi || {}
    return applied.version ? { ...applied } : null
  }

  /**
   * 「已安装」页签的数据源：插件登记表 + 市场版本 + 每台服务器的下发状态，一次取齐。
   *
   * 为什么不复用 `/api/plugins` 与 `/api/plugins/servers/:id`：
   *   1. 分服状态要一格一格画出来，逐服请求是 N 次往返；
   *   2. 那些路由属于「已安装插件」页的权限域，市场页的账号未必有。
   *      这里直接调注册表**服务**（ctx.plugins）汇总，权限由市场自己的 action 表达。
   */
  async installedOverview() {
    const index = await this.fetchIndex().catch(() => null)
    const marketPkgs = new Map((index?.packages || []).map((p) => [p.name, p]))
    const all = await this.ctx.plugins.list()
    // packageHash 只在原始登记表里：与 list() 的判定要保持一致，必须拿它比"同版本换内容"
    const rawEntries = new Map((this.ctx.plugins.entries || []).map((e) => [e.name, e]))
    // 可选链只保护到调用为止：`ctx.servers` 若不存在，`?.list?.()` 会返回 undefined，
    // 后面直接 `.catch` 就是 TypeError（整个接口 500）。先取到值再判断。
    const serverList = this.ctx.servers?.list?.()
    const servers = (serverList && typeof serverList.catch === 'function' ? await serverList.catch(() => []) : []) || []
    const hostUi = this.hostUiState()
    const items = all.map((e) => {
      const pkg = marketPkgs.get(e.name) || null
      const hasDll = Array.isArray(e.dlls) && e.dlls.length > 0
      // web：前端 bundle 的"已装版本"是**投放记录**，不是登记版本（两者在登记里恒等）
      const appliedBundle = e.name === HOST_UI_NAME ? hostUi : null
      const currentVersion = appliedBundle?.version || e.version
      // 与 market/list 同一份规则：徽标、卡片、按钮才不会互相打架
      const hasUpdate = computeHasUpdate({
        name: e.name, pkg, entryVersion: e.version,
        entryHash: rawEntries.get(e.name)?.packageHash, appliedBundleVersion: hostUi?.version,
      })
      return {
        name: e.name,
        version: e.version,
        currentVersion,
        marketVersion: pkg?.version || null,
        hasUpdate,
        enabled: e.enabled === true,
        requestedEnabled: e.requestedEnabled === true,
        backendState: e.backendState || null,
        status: e.status || null,
        error: e.error || null,
        source: e.source || null,
        installedAt: e.installedAt || null,
        requires: Array.isArray(e.requires) ? e.requires : [],
        hasDll,
        // 每台服务器的 DLL 状态：loaded / pending / unloaded / error:… / null（从未下发）
        servers: e.servers || {},
        sync: e.sync || {},
        self: e.name === SELF_NAME,
        core: e.name === CORE_NAME,
        hostUi: e.name === HOST_UI_NAME,
        // 能不能「更新」要分两条通道看：
        //   - web：注册表门禁明确拒绝（BUILTIN），但它的前端 bundle 走 /api/market/host-ui 投放，
        //     所以对界面来说它照样可更新；
        //   - 其余：与宿主同一套 canUpdate 门禁，避免前端再抄一遍规则。
        canUpdate: hasUpdate && (e.name === HOST_UI_NAME || pluginCanUpdate(e.name, e)),
        canUninstall: pluginCanUninstall(e.name, e),
        bundleAppliedAt: appliedBundle?.appliedAt || null,
      }
    })
    items.sort((a, b) => {
      if (a.hasUpdate !== b.hasUpdate) return a.hasUpdate ? -1 : 1 // 可更新置顶
      if (a.enabled !== b.enabled) return a.enabled ? -1 : 1
      return a.name.localeCompare(b.name)
    })
    return {
      items,
      servers: servers.map((s) => ({
        id: s.id, name: s.name || s.host, host: s.host, port: s.port,
        enabled: s.enabled !== false, connected: s.connected === true, status: s.status || null,
      })),
      updatable: items.filter((i) => i.hasUpdate).length,
      hostUi,
      indexUpdated: index?.updated || null,
      indexMirror: this.preferredMirror || (String(this.config.localDir || '').trim() ? 'local' : null),
    }
  }

  /** 启用 / 禁用后端半（与「已安装插件」页同一个注册表动作） */
  async setEnabled(name, on) {
    this.taskQueue?.assertPluginMutable(name)
    const entry = (await this.ctx.plugins.list()).find((e) => e.name === name)
    if (!entry) throw Object.assign(new Error(`插件未安装: ${name}`), { status: 404 })
    /**
     * 拒绝禁用"面板正在用来提供这个页面"的几个插件。
     *
     * 这页把启用/禁用开放给了界面，而 registry 只对**卸载**有门禁、对禁用没有：
     * 一旦在界面上把 market/web/accounts/servers 停掉，当前这个请求就连回话的通道都没了
     * （market 停用会 dispose 自己注册的路由），面板随后连登录都进不去。
     * 这类动作只能通过安装目录/发行包做，不在页面上提供。
     */
    if (!on && PANEL_CRITICAL.has(name)) {
      throw Object.assign(new Error(`${name} 是面板运行所依赖的插件，不能在页面上停用`), { status: 409 })
    }
    if (on) await this.ctx.plugins.enable(name)
    else await this.ctx.plugins.disable(name)
    return { name, enabled: on === true }
  }

  /** 分服下发：逐台下发，失败的按台回报，不让一台失败吞掉其它台 */
  async deployToServers(name, serverIds) {
    this.taskQueue?.assertPluginMutable(name)
    const entry = (await this.ctx.plugins.list()).find((e) => e.name === name)
    if (!entry) throw Object.assign(new Error(`插件未安装: ${name}`), { status: 404 })
    if (!Array.isArray(entry.dlls) || entry.dlls.length === 0) {
      throw Object.assign(new Error(`${name} 没有游戏服半（无 DLL），无需下发`), { status: 409 })
    }
    const ids = Array.isArray(serverIds) ? [...new Set(serverIds.filter((x) => typeof x === 'string' && x))] : []
    if (ids.length === 0) throw Object.assign(new Error('请选择至少一台服务器'), { status: 400 })
    const deployed = []
    const failed = []
    for (const serverId of ids) {
      try {
        await this.ctx.plugins.deploy(name, serverId)
        deployed.push(serverId)
      } catch (err) {
        failed.push({ serverId, error: err.message })
      }
    }
    return { name, deployed, failed }
  }

  /** 从单台服务器撤下 DLL */
  async undeployFromServer(name, serverId) {
    this.taskQueue?.assertPluginMutable(name)
    if (typeof serverId !== 'string' || !serverId) throw Object.assign(new Error('缺少 serverId'), { status: 400 })
    const entry = await this.ctx.plugins.undeploy(name, serverId)
    const sync = entry?.sync?.[serverId] || null
    return { name, serverId, enabled: false, state: sync?.phase || 'queued', sync }
  }

  /** `web` 插件的目录（host 前端就挂在它的 public/ 下） */
  hostUiRoot() {
    const pluginsDir = this.ctx.plugins?.pluginsDir
    if (!pluginsDir) throw new Error('宿主角色的插件目录不可用，无法投放前端')
    return path.join(pluginsDir, HOST_UI_NAME)
  }

  /**
   * 投放宿主前端：把市场里 `web` 包内的 `public/**` 替换到本机 `plugins/web/public/`。
   *
   * 为什么单独一条通道，而不走 registry.updateFromTgz：
   *   `canUpdate('web')` 明确为 false——换掉自带插件的**后端半**会打断正在跑的静态服务与
   *   侧边栏路由。但"添加服务器向导 / 初始化弹窗"这类改动全在**静态资源**里，
   *   换文件 + 刷新页面即可生效，没必要为此发整包。
   *
   * 安全与可回滚：
   *   1. 包来自已校验 sha256 的市场索引条目（fetchPackage 强制复算）；
   *   2. 只取包内 `public/**`，其余文件（后端 index.js 等）一律不落盘；
   *   3. 落盘前校验清单（index.html / sdk.js / 至少一个 assets/*.js 引用），不完整即拒；
   *   4. 旧目录改名成 `public.bak-<时间戳>` 再原子换入新目录，失败自动还原。
   */
  async applyHostUi(opts = {}) {
    this.taskQueue?.assertAvailable(opts.taskId)
    const opName = HOST_UI_NAME
    this.beginOperation(opName, 'host-ui')
    try {
      const index = await this.fetchIndex()
      const entry = this.findEntry(index, HOST_UI_NAME)
      const applied = this.hostUiState()
      if (applied && applied.version === entry.version && (!entry.sha256 || applied.sha256 === entry.sha256)) {
        throw new Error(`宿主前端已是市场最新版 v${entry.version}，无需重复投放`)
      }

      const webDir = this.hostUiRoot()
      const target = path.join(webDir, 'public')
      try {
        await fs.access(path.join(target, 'index.html'))
      } catch {
        throw new Error(`未找到宿主前端目录 ${target}（${HOST_UI_NAME} 插件是否被移动或删除？）`)
      }

      this.stepOperation(opName, { phase: 'download', label: '下载宿主前端包（web）', done: 0, total: Number(entry.size) || 0 })
      const { buf, from } = await this.fetchPackage(entry, {
        onProgress: ({ done, total }) => this.stepOperation(opName, { done, total }),
      })
      this.stepOperation(opName, { phase: 'verify', label: '校验 sha256 完整性', done: buf.length, total: buf.length })

      this.stepOperation(opName, { phase: 'install', label: '解出 public/ 并校验清单' })
      const staging = await fs.mkdtemp(path.join(os.tmpdir(), 'tsweb-hostui-'))
      let backup = ''
      try {
        await this.extractHostUi(staging, buf)
        const staged = path.join(staging, 'public')
        await this.assertHostUiBundle(staged)

        backup = `${target}.bak-${Date.now()}`
        await fs.rename(target, backup)
        try {
          await fs.rename(staged, target)
        } catch (err) {
          await fs.rename(backup, target).catch(() => {})
          backup = ''
          throw err
        }
      } finally {
        await fs.rm(staging, { recursive: true, force: true }).catch(() => {})
      }

      this.config.hostUi = {
        version: entry.version,
        sha256: entry.sha256 || sha256(buf),
        size: buf.length,
        from,
        appliedAt: new Date().toISOString(),
        backup,
      }
      await this.saveConfig()
      console.log(`[market] 宿主前端已投放 v${entry.version}（来源 ${from}），旧目录备份 ${backup || '无'}`)
      this.finishOperation(opName)
      return { version: entry.version, sha256: this.config.hostUi.sha256, size: buf.length, from, backup, refreshRequired: true }
    } catch (err) {
      this.finishOperation(opName, err)
      throw err
    }
  }

  /** 解开 tgz 里的 `public/**`（顶层 <name>/ 用 strip:1 去掉），其余内容直接丢弃 */
  async extractHostUi(dir, buf) {
    const tgzFile = path.join(dir, 'host-ui.tgz')
    await fs.writeFile(tgzFile, buf)
    const { x } = await import('tar')
    await x({
      file: tgzFile,
      cwd: dir,
      strip: 1,
      // 只收 public/ 下的文件；防路径穿越
      filter: (p) => !p.split(/[\\/]/).includes('..') && p.split(/[\\/]/)[1] === 'public',
    })
    await fs.rm(tgzFile, { force: true })
  }

  /** 投放前的最小清单校验：缺任何一项都说明包不完整，宁可不换 */
  async assertHostUiBundle(publicDir) {
    const must = ['index.html', 'sdk.js']
    for (const file of must) {
      try {
        await fs.access(path.join(publicDir, file))
      } catch {
        throw new Error(`前端包不完整：缺少 ${file}`)
      }
    }
    let assets = []
    try {
      assets = await fs.readdir(path.join(publicDir, 'assets'))
    } catch {
      throw new Error('前端包不完整：缺少 assets/')
    }
    if (!assets.some((f) => f.endsWith('.js'))) throw new Error('前端包不完整：assets/ 里没有入口脚本')
    const html = await fs.readFile(path.join(publicDir, 'index.html'), 'utf8')
    if (!/assets\/[^"']+\.js/.test(html)) throw new Error('前端包不完整：index.html 未引用 assets 入口')
  }

  /**
   * 发行包下载超时：取配置下限与实际大小的较大者。
   *
   * 下限 `packageTimeoutMs`（默认 180 秒）覆盖正常网络；再按 32 KB/s 的"极慢但还能用"的速率
   * 折算一个与体积相关的上限，避免大包（base 近 10 MB）在慢线路上被固定超时卡死。
   */
  packageTimeout(entry) {
    const floor = Number(this.config.packageTimeoutMs) > 0 ? Number(this.config.packageTimeoutMs) : DEFAULT_CONFIG.packageTimeoutMs
    const size = Number(entry?.size) > 0 ? Number(entry.size) : 0
    return Math.max(floor, Math.ceil(size / 32768) * 1000)
  }

  /** 拉索引：localDir 优先；在线按镜像逐个尝试 */
  async fetchIndex(force = false) {
    const now = Date.now()
    if (!force && this.index && now - this.indexAt < (this.config.cacheTtlMs || DEFAULT_CONFIG.cacheTtlMs)) {
      return this.index
    }
    const localDir = String(this.config.localDir || '').trim()
    if (localDir) {
      const file = path.join(localDir, 'market.json')
      this.index = JSON.parse(await fs.readFile(file, 'utf8'))
      this.indexAt = now
      return this.index
    }
    const errors = []
    for (const { id, base } of this.baseUrls()) {
      try {
        const buf = await this.fetchWithTimeout(`${base}/market.json`, this.config.timeoutMs || 20000)
        this.index = JSON.parse(buf.toString('utf8'))
        this.indexAt = now
        if (this.preferredMirror !== id) {
          this.preferredMirror = id
          console.log(`[market] 索引来源镜像: ${id}`)
        }
        return this.index
      } catch (err) {
        errors.push(`${id}: ${err.message}`)
      }
    }
    throw new Error('拉取 market.json 失败（已尝试 ' + errors.join(' | ') + '）')
  }

  /** 取发行包字节（本地或在线），并校验 sha256；`onProgress` 用于界面显示下载进度 */
  async fetchPackage(entry, { verify = true, onProgress } = {}) {
    const localDir = String(this.config.localDir || '').trim()
    let buf
    let from
    if (localDir) {
      const file = path.join(localDir, entry.url.split('/').join(path.sep))
      buf = await fs.readFile(file)
      from = file
      onProgress?.({ done: buf.length, total: buf.length })
    } else {
      const errors = []
      const timeout = this.packageTimeout(entry)
      for (const { id, base } of this.baseUrls()) {
        const started = Date.now()
        try {
          const url = `${base}/${entry.url}`
          buf = onProgress
            ? await this.fetchWithProgress(url, timeout, onProgress)
            : await this.fetchWithTimeout(url, timeout)
          from = `${id}:${entry.url}`
          this.preferredMirror = id
          console.log(`[market] 下载 ${entry.url} 完成（${human(buf.length)}，${id}，${((Date.now() - started) / 1000).toFixed(1)}s）`)
          break
        } catch (err) {
          // 失败必须落日志：否则服务器窗口里只有"点了没反应"，无从判断是网络、镜像还是超时
          console.error(`[market] 下载 ${entry.url} 失败（${id}，${((Date.now() - started) / 1000).toFixed(1)}s）: ${err.message}`)
          errors.push(`${id}: ${err.message}`)
          onProgress?.({ done: 0, total: 0 })
        }
      }
      if (!buf) throw new Error(`下载发行包失败（已尝试 ${errors.join(' | ')}）；换镜像见 data/market/config.json 的 mirrorOverride`)
    }
    if (verify && entry.sha256) {
      const got = sha256(buf)
      if (got !== entry.sha256) {
        throw new Error(`sha256 校验失败: 期望 ${entry.sha256.slice(0, 16)}… 实际 ${got.slice(0, 16)}…`)
      }
    }
    return { buf, from, size: buf.length }
  }

  /** 市场索引与本地已装状态对比 */
  async list(force = false) {
    const index = await this.fetchIndex(force)
    const installed = new Map((this.ctx.plugins?.entries || []).map((e) => [e.name, e]))
    // 依赖判定看"登记且目录存在"：登记残留但目录被删的插件不能算已有依赖
    const installedNames = new Set()
    for (const e of (this.ctx.plugins?.entries || [])) {
      if (await this.ctx.plugins.dirExists(e.name)) installedNames.add(e.name)
    }
    const favorites = new Set(this.config.favorites || [])
    const appliedBundleVersion = this.hostUiState()?.version || null
    return (index.packages || []).map((p) => {
      const cur = installed.get(p.name)
      const installedVersion = cur?.version || null
      const hasUpdate = computeHasUpdate({
        name: p.name, pkg: p, entryVersion: installedVersion,
        entryHash: cur?.packageHash, appliedBundleVersion,
      })
      const compatibilityError = pluginCompatibility({ tsweb: { accessApi: p.accessApi, client: p.hasClient ? './dist/index.js' : null, clientApi: p.clientApi, receiverProtocol: p.receiverProtocol } })
      // 目标版本声明的依赖缺项：前端据此在安装/更新前弹窗（服务端安装时仍会再校验一次）
      const requires = Array.isArray(p.requires) ? p.requires : []
      const missingDeps = requires.filter((n) => !installedNames.has(n)).map((n) => {
        const dep = (index.packages || []).find((x) => x.name === n)
        return { name: n, version: dep?.version || null, size: dep?.size || 0 }
      })
      return {
        name: p.name,
        version: p.version,
        description: p.description || '',
        releaseNotes: typeof p.releaseNotes === 'string' ? p.releaseNotes : '',
        author: p.author || null,
        // 分类标签（索引里可选；老索引没有该字段时为空数组，前端据此不渲染标签区）
        tags: Array.isArray(p.tags) ? p.tags.filter((t) => typeof t === 'string' && t.trim()) : [],
        bundled: p.bundled === true,
        hasClient: p.hasClient === true,
        dll: p.dll || [],
        requires,
        missingDeps,
        // 同步不再受旧包 deploy=ask/manual 字段限制。
        deploy: 'auto',
        size: p.size || 0,
        publishedAt: p.publishedAt || null,
        installed: Boolean(cur),
        installedVersion,
        hasUpdate,
        compatible: !compatibilityError,
        compatibilityError,
        olderThanInstalled: compareVersions(p.version, installedVersion) < 0,
        origin: cur?.source || null,
        favorite: favorites.has(p.name),
        // 市场自身：前端据此标出"这是市场"，更新它时提示"刷新页面后生效"
        self: p.name === SELF_NAME,
        // 核心件（base）：更新会重新同步游戏服上的 DLL，前端给它单独的确认与结果提示
        core: p.name === CORE_NAME,
        // 宿主前端（web）：更新只换 public/ 静态资源，走 /api/market/host-ui 而非注册表更新
        hostUi: p.name === HOST_UI_NAME,
      }
    })
  }

  /** 收藏 / 取消收藏（持久化到 market config.json） */
  async setFavorite(name, on) {
    const plugin = String(name || '').trim()
    if (!plugin) throw new Error('缺少插件名')
    const set = new Set(this.config.favorites || [])
    if (on) set.add(plugin)
    else set.delete(plugin)
    this.config.favorites = [...set]
    await this.saveConfig()
    return { name: plugin, favorite: on, favorites: this.config.favorites }
  }

  findEntry(index, name) {
    const hit = (index.packages || []).find((p) => p.name === name)
    if (!hit) throw new Error(`市场中不存在插件: ${name}`)
    return hit
  }

  /** 已安装且目录存在的插件名集合（只有登记但目录被删的插件要按重装处理，不算"已有"） */
  async installedNames() {
    const out = new Set()
    for (const e of (this.ctx.plugins?.entries || [])) {
      if (await this.ctx.plugins.dirExists(e.name)) out.add(e.name)
    }
    return out
  }

  /**
   * 目标的依赖闭包（含依赖自身的依赖），顺序为"被依赖者在前"。
   *
   * 与"是否已安装"无关：已装依赖同样在闭包里，由 ensureDependencies 决定是
   * 启用还是跳过；已装但索引里没有条目的依赖会合成为 `{ name }`，只用于启用判断。
   * 环用 visiting 终止；索引缺条目且本机也没装才报错。
   */
  dependencyClosure(index, name) {
    const byName = new Map((index.packages || []).map((p) => [p.name, p]))
    const installed = new Set((this.ctx.plugins?.entries || []).map((e) => e.name))
    const out = [], seen = new Set(), visiting = new Set()
    const visit = (n) => {
      if (visiting.has(n) || seen.has(n)) return
      const entry = byName.get(n)
      if (!entry) {
        if (!installed.has(n)) {
          const err = new Error(`市场索引缺少依赖条目：${n}（本机未安装，无法自动安装，请检查发布索引）`)
          err.status = 502
          throw err
        }
        seen.add(n)
        out.push({ name: n })
        return
      }
      visiting.add(n)
      for (const dep of entry.requires || []) visit(dep)
      visiting.delete(n)
      seen.add(n)
      out.push(entry)
    }
    const target = byName.get(name)
    for (const dep of target?.requires || []) visit(dep)
    return out
  }

  /** 缺依赖时的 409：前端据此弹窗列出依赖并让管理员确认后带 installDeps 重试 */
  missingDepsError(name, deps) {
    const err = new Error(
      `安装 ${name} 需要先下载 ${deps.length} 个依赖：${deps.map((d) => `${d.name}@${d.version || ''}`.replace(/@$/, '')).join('、')}`
    )
    err.status = 409
    err.code = 'missing-deps'
    err.deps = deps.map((d) => ({ name: d.name, version: d.version || null, size: d.size || 0 }))
    return err
  }

  /**
   * 处理依赖闭包：缺的装、已装但被禁用的启用、已就绪的跳过。
   * 依赖必须先就绪（消费方的 cordis inject 才拿得到服务），因此这里是串行执行。
   */
  async ensureDependencies(deps, opName) {
    const done = []
    for (const dep of deps) {
      const existing = (this.ctx.plugins?.entries || []).find((e) => e.name === dep.name)
      const dirOk = existing ? await this.ctx.plugins.dirExists(dep.name) : false
      if (!existing || !dirOk) {
        if (!dep.url) throw new Error(`依赖 ${dep.name} 缺少可下载的市场包，无法自动安装`)
        this.stepOperation(opName, { phase: 'deps', label: `先安装依赖 ${dep.name}`, done: 0, total: 0 })
        const { buf, from } = await this.fetchPackage(dep, {
          onProgress: ({ done, total }) => this.stepOperation(opName, { done, total }),
        })
        console.log(`[market] 安装依赖 ${dep.name}@${dep.version}（${human(buf.length)}，来源 ${from}）`)
        await this.ctx.plugins.installFromTgz(buf, { enable: true, source: 'market' })
        done.push({ name: dep.name, version: dep.version, action: 'installed' })
        continue
      }
      if (!existing.enabled) {
        console.log(`[market] 启用已安装的依赖 ${dep.name}`)
        await this.ctx.plugins.enable(dep.name)
        done.push({ name: dep.name, version: existing.version, action: 'enabled' })
      }
    }
    return done
  }

  /**
   * 解析目标版本的依赖：
   *   - missing：闭包里本机没有（登记+目录）的依赖 → 未确认时 409，由前端弹窗；
   *   - dependencies：确认后实际执行的动作（安装 / 启用）。
   */
  async resolveDependencies(index, name, opts) {
    const installed = await this.installedNames()
    const closure = this.dependencyClosure(index, name)
    const missing = closure.filter((d) => !installed.has(d.name))
    if (missing.length > 0 && opts.installDeps !== true) throw this.missingDepsError(name, missing)
    return { deps: closure, missing, dependencies: await this.ensureDependencies(closure, name) }
  }

  /** 安装：下载 -> 校验 -> 宿主落位并自动按哈希同步。 */
  async install(name, opts = {}) {
    this.taskQueue?.assertAvailable(opts.taskId)
    this.beginOperation(name, 'install')
    try {
      const result = await this.runInstall(name, opts)
      this.finishOperation(name)
      return result
    } catch (err) {
      this.finishOperation(name, err)
      throw err
    }
  }

  async runInstall(name, opts = {}) {
    const index = await this.fetchIndex()
    const entry = this.findEntry(index, name)
    const existing = (this.ctx.plugins.entries || []).find((e) => e.name === name)
    if (existing) {
      // 登记在、目录已删（手工删目录/上次中断/换机器）→ 允许重新安装；目录健在才要求走 update
      const dirOk = await this.ctx.plugins.dirExists(name)
      if (dirOk) {
        throw new Error(`${name} 已安装（v${existing.version}），如需升级请用 update`)
      }
      console.log(`[market] 登记存在但目录缺失，按重新安装处理: ${name}`)
    }
    const { dependencies } = await this.resolveDependencies(index, name, opts)
    this.stepOperation(name, { phase: 'download', label: '下载发行包', done: 0, total: Number(entry.size) || 0 })
    const { buf, from } = await this.fetchPackage(entry, {
      onProgress: ({ done, total }) => this.stepOperation(name, { done, total }),
    })
    console.log(`[market] 安装 ${name}@${entry.version}（${human(buf.length)}，来源 ${from}）`)
    this.stepOperation(name, { phase: 'verify', label: '校验 sha256 完整性', done: buf.length, total: buf.length })
    this.stepOperation(name, { phase: 'install', label: '解压、落位并热加载' })
    const created = await this.ctx.plugins.installFromTgz(buf, { enable: true, source: 'market' })
    return { name, version: created.version, from, dependencies, deployed: [], deployFailed: [], deployMode: 'auto',
      deploySkipped: false, backendState: created.status, warning: created.status === 'enabled' ? '后端安装完成，游戏服正在自动按哈希同步' : `插件已安装，后端尚未就绪（${created.status || '未知状态'}），请检查依赖` }
  }

  /** 更新：下载 -> 校验 -> updateFromTgz（失败自动回滚）；新版本新增的依赖同样先补装 */
  async update(name, opts = {}) {
    this.taskQueue?.assertAvailable(opts.taskId)
    this.beginOperation(name, 'update')
    try {
      const result = await this.runUpdate(name, opts)
      this.finishOperation(name)
      return result
    } catch (err) {
      this.finishOperation(name, err)
      throw err
    }
  }

  async runUpdate(name, opts = {}) {
    const index = await this.fetchIndex()
    const entry = this.findEntry(index, name)
    const existing = (this.ctx.plugins.entries || []).find((e) => e.name === name)
    if (!existing) throw new Error(`${name} 未安装，请用 install`)
    const { dependencies } = await this.resolveDependencies(index, name, opts)
    this.stepOperation(name, { phase: 'download', label: '下载发行包', done: 0, total: Number(entry.size) || 0 })
    const { buf, from } = await this.fetchPackage(entry, {
      onProgress: ({ done, total }) => this.stepOperation(name, { done, total }),
    })
    console.log(`[market] 更新 ${name} ${existing.version} -> ${entry.version}（来源 ${from}）`)
    this.stepOperation(name, { phase: 'verify', label: '校验 sha256 完整性', done: buf.length, total: buf.length })
    this.stepOperation(name, { phase: 'install', label: '备份旧版本、原子替换并热加载' })
    const result = await this.ctx.plugins.updateFromTgz(name, buf)
    return { ...result, from, dependencies, deployed: [], deployFailed: [], deployMode: 'auto', deploySkipped: false,
      warning: '后端更新完成，游戏服正在自动按哈希同步' }
  }

  /** 自更新准备：获取并校验包；尚未修改安装目录。 */
  async prepareSelfUpdate(opts = {}) {
    this.taskQueue?.assertAvailable(opts.taskId)
    this.beginOperation(SELF_NAME, 'update')
    try {
      const index = await this.fetchIndex()
      const entry = this.findEntry(index, SELF_NAME)
      const existing = (this.ctx.plugins?.entries || []).find((e) => e.name === SELF_NAME)
      if (!existing) throw new Error(`插件未登记，无法自更新: ${SELF_NAME}`)
      this.stepOperation(SELF_NAME, { phase: 'download', label: '下载发行包', done: 0, total: Number(entry.size) || 0 })
      const { buf, from, size } = await this.fetchPackage(entry, {
        onProgress: ({ done, total }) => this.stepOperation(SELF_NAME, { done, total }),
      })
      this.stepOperation(SELF_NAME, { phase: 'verify', label: '校验 sha256 完整性', done: buf.length, total: buf.length })
      return { buf, from, size, before: existing.version, to: entry.version }
    } catch (err) {
      this.finishOperation(SELF_NAME, err)
      throw err
    }
  }

  /** 由宿主执行替换，调用方等待结果；失败和回滚结果返回 HTTP 请求。 */
  async applySelfUpdate(plan) {
    try {
      console.log(`[market] 自更新 ${SELF_NAME} v${plan.before} -> v${plan.to}（来源 ${plan.from}）`)
      this.stepOperation(SELF_NAME, { phase: 'install', label: '备份旧版本、原子替换并热加载' })
      const result = await this.ctx.plugins.updateFromTgz(SELF_NAME, plan.buf)
      console.log(`[market] 自更新完成 v${result.to}；服务端半已热重载，前端半需刷新页面后生效`)
      this.finishOperation(SELF_NAME)
      return result
    } catch (err) {
      console.error(`[market] 自更新失败（回滚状态见错误详情）: ${err.message}`)
      this.finishOperation(SELF_NAME, err)
      throw err
    }
  }

  /** 卸载（含从服务器撤下 DLL，若曾下发） */
  async uninstall(name, opts = {}) {
    this.taskQueue?.assertPluginMutable(name)
    const entry = (this.ctx.plugins.entries || []).find((e) => e.name === name)
    if (!entry) throw new Error(`${name} 未安装`)
    const undeployed = []
    for (const [serverId, state] of Object.entries(entry.servers || {})) {
      if (state !== 'loaded') continue
      try {
        await this.ctx.plugins.undeploy(name, serverId)
        undeployed.push(serverId)
      } catch (err) {
        console.error(`[market] 从服务器撤下失败 ${serverId}: ${err.message}`)
      }
    }
    await this.ctx.plugins.uninstall(name)
    return { name, undeployed }
  }

  async refresh() {
    this.index = null
    this.indexAt = 0
    const index = await this.fetchIndex(true)
    return { count: (index.packages || []).length, mirror: this.preferredMirror || (this.config.localDir ? 'local' : 'unknown') }
  }
}

export async function apply(ctx, options = {}) {
  try {
    return await applyInner(ctx, options)
  } catch (err) {
    // cordis 对"等待 inject 后才执行"的插件，apply 异常不会冒泡到加载器，必须在此显式记录
    console.error('[market] 初始化失败: ' + err.message)
    if (process.env.TSWEB_DEBUG) console.error(err.stack)
    throw err
  }
}

async function applyInner(ctx, options = {}) {
  if (process.env.TSWEB_DEBUG) console.log('[market][dbg] apply 被调用，开始加载配置')
  const svc = new MarketService(ctx, options)
  await svc.loadConfig()
  ctx.market = svc
  const queue = await attachTaskQueue(svc)

  const app = ctx.auth.access.policyApp(ctx.webServer.app, accessContract, ctx)
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]

  app.get('/api/market/tasks', ...admin, (_req, res) => {
    res.json({ success: true, ...queue.snapshot() })
  })
  app.post('/api/market/tasks', ...admin, async (req, res) => {
    try {
      const result = await queue.enqueue(req.body || {})
      res.json({ success: true, ...result, ...queue.snapshot() })
    } catch (error) {
      res.status(error.status || 400).json({ error: error.message, code: error.code || null, deps: error.deps || [] })
    }
  })
  app.post('/api/market/tasks/control', ...admin, async (req, res) => {
    try {
      await queue.control(req.body || {})
      res.json({ success: true, ...queue.snapshot() })
    } catch (error) {
      res.status(error.status || 400).json({ error: error.message, ...queue.snapshot() })
    }
  })

  app.get('/api/market/list', ...admin, async (req, res) => {
    try {
      // force=1 时绕过索引缓存（面板「刷新索引」用）
      // configError 随列表回显：配置损坏时管理员必须看到原因与备份路径，
      // 否则只会看到"收藏凭空消失"而无从排查（见 loadConfig）。
      const plugins = await svc.list(req.query?.force === '1')
      res.json({ success: true, plugins, configError: svc.loadError || '',
        // 已投放的宿主前端版本（市场页据此显示"当前前端 vX / 可更新到 vY"）
        hostUi: svc.hostUiState(),
        // 索引新鲜度：面板上的"刷新"曾经只重拉列表、仍吃 10 分钟缓存，
        // 于是"市场发了新版但页面看不到"。把这两项回显出来，让人一眼看出索引是哪天的。
        indexUpdated: svc.index?.updated || null,
        indexMirror: svc.preferredMirror || (String(svc.config.localDir || '').trim() ? 'local' : null) })
    } catch (err) {
      res.status(502).json({ error: err.message })
    }
  })

  // 收藏 / 取消收藏（服务端持久化；收藏栏与列表星标共用）
  app.post('/api/market/favorite', ...admin, async (req, res) => {
    try {
      res.json({ success: true, ...(await svc.setFavorite(String(req.body?.name || ''), req.body?.favorite === true)) })
    } catch (err) {
      res.status(400).json({ error: err.message })
    }
  })

  app.post('/api/market/refresh', ...admin, async (_req, res) => {
    try {
      res.json({ success: true, ...(await svc.refresh()) })
    } catch (err) {
      res.status(502).json({ error: err.message })
    }
  })

  /**
   * 正在进行的安装/更新（市场页在操作期间轮询它显示进度）。
   * 只读、无副作用：没有操作时返回空数组。
   */
  app.get('/api/market/progress', ...admin, (_req, res) => {
    res.json({ success: true, operations: svc.listOperations() })
  })

  app.post('/api/market/install', ...admin, async (req, res) => {
    try {
      // installDeps=false 时若缺依赖返回 409（页面据此弹窗确认）；确认后带 true 重试
      const result = await svc.install(String(req.body?.name || ''), {
        serverIds: req.body?.serverIds || null,
        installDeps: req.body?.installDeps === true,
      })
      res.json({ success: true, ...result })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message, code: err.code || null, deps: err.deps || [] })
    }
  })

  app.post('/api/market/update', ...admin, async (req, res) => {
    const target = String(req.body?.name || '')

    // Await the host-owned update operation so rollback failures reach the caller.
    // The request/response outlive the old market fiber; no old service is used afterwards.
    if (target === SELF_NAME) {
      try {
        const plan = await svc.prepareSelfUpdate()
        const result = await svc.applySelfUpdate(plan)
        res.json({ success: true, ...result, self: true, source: plan.from,
          refreshRequired: true, restartRequired: false })
      } catch (error) { res.status(error.status || 500).json({ error: error.message }) }
      return
    }

    try {
      const result = await svc.update(target, {
        serverIds: req.body?.serverIds || null,
        installDeps: req.body?.installDeps === true,
      })
      /**
       * 普通更新的生效语义（与自更新同一套双标记）：
       * 后端半由 updateFromTgz 热重载、立即生效；前端半仍是页面加载时的旧 bundle。
       * loader 此时已重新加载出该插件的 clientUrl（带 ?v=），非空即表示它有前端半、需要刷新。
       */
      let refreshRequired = false
      try {
        refreshRequired = Boolean(svc.ctx.plugins?.loader?.loaded?.get?.(target)?.clientUrl)
      } catch { /* 拿不到就按"无需刷新"处理，不因此让更新报错 */ }
      res.json({ success: true, ...result, refreshRequired, restartRequired: false })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message, code: err.code || null, deps: err.deps || [] })
    }
  })

  /**
   * 投放宿主前端（web 包的 public/）。与 install/update 分开：
   * 它不登记插件、不换后端半，只替换静态资源，成功后刷新页面即生效。
   */
  app.post('/api/market/host-ui', ...admin, async (_req, res) => {
    try {
      res.json({ success: true, ...(await svc.applyHostUi()) })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  /**
   * 「已安装」页签：登记表 + 市场版本 + 每台服务器的下发状态，一次取齐。
   */
  app.get('/api/market/installed', ...admin, async (_req, res) => {
    try {
      res.json({ success: true, ...(await svc.installedOverview()) })
    } catch (err) {
      res.status(err.status || 502).json({ error: err.message })
    }
  })

  // 启用 / 禁用后端半
  app.post('/api/market/enable', ...admin, async (req, res) => {
    try {
      const name = String(req.body?.name || '')
      res.json({ success: true, ...(await svc.setEnabled(name, req.body?.enabled !== false)) })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 分服下发（body: { name, serverIds: [] }）
  app.post('/api/market/deploy', ...admin, async (req, res) => {
    try {
      res.json({ success: true, ...(await svc.deployToServers(String(req.body?.name || ''), req.body?.serverIds)) })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // 从单台服务器撤下（body: { name, serverId }）
  app.post('/api/market/undeploy', ...admin, async (req, res) => {
    try {
      res.json({ success: true, ...(await svc.undeployFromServer(String(req.body?.name || ''), String(req.body?.serverId || ''))) })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  app.post('/api/market/uninstall', ...admin, async (req, res) => {
    try {
      res.json({ success: true, ...(await svc.uninstall(String(req.body?.name || ''))) })
    } catch (err) {
      res.status(err.status || 400).json({ error: err.message })
    }
  })

  // ── 终端命令 ──
  const term = ctx.terminal
  if (term?.register) {
    term.register('market-list', '列出市场插件与本地状态', async () => {
      try {
        const rows = await svc.list()
        if (rows.length === 0) { console.log('（市场暂无插件）'); return }
        for (const r of rows) {
          const st = !r.installed ? `未安装 -> 可装 v${r.version}`
            : r.hasUpdate ? `v${r.installedVersion} -> v${r.version}`
              : `已最新 v${r.installedVersion}`
          console.log(`  ${r.name.padEnd(16)} ${st.padEnd(28)} ${r.bundled ? '[自带]' : ''} ${r.description || ''}`)
          if (r.missingDeps?.length) console.log(`    缺依赖: ${r.missingDeps.map((d) => d.name).join('、')}（安装/更新时会自动先装）`)
        }
      } catch (err) {
        console.error('拉取市场索引失败: ' + err.message)
      }
    })
    term.register('market-install', '从市场安装插件并自动同步（用法: market-install <name>）', async (args) => {
      if (!args?.[0] || args.length !== 1 || args[0].startsWith('--')) { console.log('用法: market-install <name>（自动同步）'); return }
      try {
        // 终端没有弹窗：依赖直接一并安装，并把装了哪些依赖打印出来
        const r = await svc.install(String(args[0]), { installDeps: true })
        for (const dep of r.dependencies || []) console.log(`  依赖 ${dep.name}@${dep.version} ${dep.action === 'enabled' ? '已启用' : '已安装'}`)
        console.log(`已安装 ${r.name}@${r.version}；游戏服自动按哈希同步`)

      } catch (err) {
        console.error('安装失败: ' + err.message)
      }
    })
    term.register('market-update', '从市场覆盖更新并自动同步（用法: market-update <name>）', async (args) => {
      if (!args?.[0] || args.length !== 1 || args[0].startsWith('--')) { console.log('用法: market-update <name>（自动同步）'); return }
      try {
        const r = await svc.update(String(args[0]), { installDeps: true })
        for (const dep of r.dependencies || []) console.log(`  依赖 ${dep.name}@${dep.version} ${dep.action === 'enabled' ? '已启用' : '已安装'}`)
        console.log(`已更新 ${r.name}: ${r.from} -> ${r.to}；游戏服自动按哈希同步`)

      } catch (err) {
        console.error('更新失败: ' + err.message)
      }
    })
    term.register('market-uninstall', '卸载市场插件（用法: market-uninstall <name>）', async (args) => {
      if (!args?.[0]) { console.log('用法: market-uninstall <name>'); return }
      try {
        const r = await svc.uninstall(String(args[0]))
        console.log(`已卸载 ${r.name}；从 ${r.undeployed.length} 台服务器撤下`)
      } catch (err) {
        console.error('卸载失败: ' + err.message)
      }
    })
    term.register('market-refresh', '强制重拉市场索引', async () => {
      try {
        const r = await svc.refresh()
        console.log(`索引已刷新: ${r.count} 个插件（来源 ${r.mirror}）`)
      } catch (err) {
        console.error('刷新失败: ' + err.message)
      }
    })
  }

  console.log(`[market] 插件市场已就绪（repo=${svc.config.repo} 分支=${svc.config.branch}`
    + (svc.config.localDir ? ` 离线目录=${svc.config.localDir}` : ' 在线模式') + '）')
}
