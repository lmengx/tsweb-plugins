// Module permissions authorize both UI features and their backend routes.
export default {
  "owner": "qq-bind",
  "version": 2,
  "modules": [
    {
      "id": "qq-bind.qq-bind",
      "permission": "qq-bind.ui.qq-bind",
      "title": "QQ 绑定管理",
      "roles": [
        "superadmin"
      ],
      "scope": "global",
      "requires": [
        "qq-bind.get.qq.bind.list",
        "qq-bind.post.qq.bind.lookup",
        "qq-bind.post.qq.bind.nickname.refresh",
        "qq-bind.get.qq.bind.nickname.status",
        "qq-bind.get.qq.bind.status",
        "qq-bind.post.qq.bind.bind",
        "qq-bind.post.qq.bind.rebind",
        "qq-bind.post.qq.bind.transfer",
        "qq-bind.post.qq.bind.unbind",
        "qq-bind.post.qq.bind.batch",
        "qq-bind.post.qq.bind.playtime.refresh",
        "qq-bind.get.qq.bind.audit",
        "qq-bind.get.qq.bind.config",
        "qq-bind.post.qq.bind.config",
        "qq-bind.post.qq.bind.token.rotate"
      ]
    }
  ],
  "actions": [
    {
      "id": "qq-bind.get.qq.bind.list",
      "method": "GET",
      "path": "/api/qq-bind/list",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.post.qq.bind.lookup",
      "method": "POST",
      "path": "/api/qq-bind/lookup",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.post.qq.bind.nickname.refresh",
      "method": "POST",
      "path": "/api/qq-bind/nickname-refresh",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.get.qq.bind.nickname.status",
      "method": "GET",
      "path": "/api/qq-bind/nickname-status",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.get.qq.bind.status",
      "method": "GET",
      "path": "/api/qq-bind/status",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.post.qq.bind.bind",
      "method": "POST",
      "path": "/api/qq-bind/bind",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.post.qq.bind.rebind",
      "method": "POST",
      "path": "/api/qq-bind/rebind",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.post.qq.bind.transfer",
      "method": "POST",
      "path": "/api/qq-bind/transfer",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.post.qq.bind.unbind",
      "method": "POST",
      "path": "/api/qq-bind/unbind",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.post.qq.bind.batch",
      "method": "POST",
      "path": "/api/qq-bind/batch",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.post.qq.bind.playtime.refresh",
      "method": "POST",
      "path": "/api/qq-bind/playtime-refresh",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.get.qq.bind.audit",
      "method": "GET",
      "path": "/api/qq-bind/audit",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.get.qq.bind.config",
      "method": "GET",
      "path": "/api/qq-bind/config",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.post.qq.bind.config",
      "method": "POST",
      "path": "/api/qq-bind/config",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    },
    {
      "id": "qq-bind.post.qq.bind.token.rotate",
      "method": "POST",
      "path": "/api/qq-bind/token/rotate",
      "scope": "global",
      "module": "qq-bind.qq-bind"
    }
  ],
  "features": [
    {
      "id": "qq-bind:qq-bind",
      "module": "qq-bind.qq-bind",
      "requires": [
        "qq-bind.get.qq.bind.list",
        "qq-bind.post.qq.bind.lookup",
        "qq-bind.post.qq.bind.nickname.refresh",
        "qq-bind.get.qq.bind.nickname.status",
        "qq-bind.get.qq.bind.status",
        "qq-bind.post.qq.bind.bind",
        "qq-bind.post.qq.bind.rebind",
        "qq-bind.post.qq.bind.transfer",
        "qq-bind.post.qq.bind.unbind",
        "qq-bind.post.qq.bind.batch",
        "qq-bind.post.qq.bind.playtime.refresh",
        "qq-bind.get.qq.bind.audit",
        "qq-bind.get.qq.bind.config",
        "qq-bind.post.qq.bind.config",
        "qq-bind.post.qq.bind.token.rotate"
      ]
    },
    {
      "id": "qq-bind:binding",
      "module": "qq-bind.qq-bind",
      "requires": [
        "qq-bind.post.qq.bind.lookup",
        "qq-bind.post.qq.bind.bind",
        "qq-bind.post.qq.bind.rebind",
        "qq-bind.post.qq.bind.transfer",
        "qq-bind.post.qq.bind.unbind",
        "qq-bind.post.qq.bind.batch"
      ]
    },
    {
      "id": "qq-bind:qq",
      "module": "qq-bind.qq-bind",
      "requires": [
        "qq-bind.post.qq.bind.lookup"
      ]
    }
  ]
}
