import { createHash, timingSafeEqual } from 'node:crypto'
import { serverFlags } from './config.js'

// Base64 fields make the canonical form independent of JSON escaping and newlines in names.
export function credentialLine(record) {
  return ['username', 'qq', 'passwordHash', 'uuid'].map(key =>
    Buffer.from(String(record[key] || ''), 'utf8').toString('base64')).join(':') + '\n'
}
export function credentialFingerprint(record) {
  return createHash('sha256').update(credentialLine(record)).digest('hex')
}
export function credentialDocument(records, syncCredentials) {
  const ordered = [...records].sort((a, b) => a.username < b.username ? -1 : a.username > b.username ? 1 : 0)
  const hash = createHash('sha256').update(`qq-credentials/2\n${syncCredentials ? 1 : 0}\n` + ordered.map(credentialLine).join('')).digest('hex')
  return { protocol: 2, syncCredentials: !!syncCredentials, hash, records: ordered }
}

// Machine endpoints use the individual game server secret, never a panel/browser token.
export function mountCredentialTransport(ctx, service, ready) {
  const transport = ctx.webServer.app
  const machine = Object.assign(async (req, res, next) => {
    try {
      await ready
      const id = req.headers['x-server-id']
      const secret = req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : ''
      const server = typeof id === 'string' ? ctx.servers.getRaw(id) : null
      const expected = String(server?.pushSecret || '')
      if (!server || server.enabled === false || !secret || !expected || Buffer.byteLength(secret) !== Buffer.byteLength(expected) ||
          !timingSafeEqual(Buffer.from(secret), Buffer.from(expected))) return res.status(401).json({ error: 'Invalid server secret' })
      req.qqServer = server
      res.setHeader('Cache-Control', 'no-store')
      next()
    } catch { res.status(503).json({ error: 'QQ credentials unavailable' }) }
  }, { [Symbol.for('tsweb.access.machine')]: 'server-secret' })
  transport.get('/tsweb/qq-bind/credentials/hash', machine, (req, res) => {
    const { hash, protocol, syncCredentials } = service.credentialSnapshot(req.qqServer)
    res.json({ hash, protocol, syncCredentials })
  })
  transport.get('/tsweb/qq-bind/credentials', machine, (req, res) => res.json(service.credentialSnapshot(req.qqServer)))
  return () => {
    const stack = transport.router?.stack || transport._router?.stack
    if (!stack) return
    for (let i = stack.length - 1; i >= 0; i--)
      if (stack[i].route?.stack?.some(layer => layer.handle === machine)) stack.splice(i, 1)
  }
}

export async function receiveCredentialLogin(service, { serverId, data }) {
  if (!data || typeof data !== 'object') return false
  const server = service.ctx.servers.getRaw(serverId)
  if (!server || server.enabled === false || !serverFlags(service.config, serverId).syncCredentials) return false
  const { username, qq, uuid, fingerprint } = data
  if (typeof username !== 'string' || typeof qq !== 'string' || typeof uuid !== 'string' || !/^[0-9a-fA-F-]{1,128}$/.test(uuid) ||
      typeof fingerprint !== 'string' || !/^[0-9a-f]{64}$/.test(fingerprint)) return false
  const result = await service.ledger.updateUuid({ username, qq, uuid, fingerprint })
  if (!result.accepted) return false
  // A full snapshot is sent back even for UUID reuse; nothing writes the online source table directly.
  if (result.changed) await service._ensurePushed()
  else await service._schedulePush()
  const targets = await service.gameOps.enabledServers()
  await Promise.allSettled(targets.filter(s => s.id !== serverId && serverFlags(service.config, s.id).kickDuplicate)
    .map(s => service.gameOps.kickDuplicate(s, result.username)))
  return true
}
