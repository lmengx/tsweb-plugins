/* TSWeb 在线统计客户端插件（online-stats 的前端半）
 *
 * 依赖宿主能力（window.tsweb，由 web 插件提供）：
 *   - window.tsweb.registerView({ id, title, section, path, render })
 *   - window.tsweb.api(path, opts)   带 Bearer 的统一请求：{ ok, status, data }
 *
 * 页面：#/b/online-stats（后端设置 → 在线统计）
 *   - 当前在线：全部已登记服务器在线人数 / 上限（后端聚合 total）
 *   - 近端趋势：内联 SVG 折线图（本进程 60s 采样，多服合计，悬停显示数值与时间）
 *   - 在线玩家：当前在线玩家明细（昵称 / 账号 / 组 / 所在服）
 *   - 单玩家查询：在线状态 + 权威累计时长（游戏服半 /data/online/player）
 *   - 累计时长排行：online（累计分钟）/ deaths（PVE 死亡）/ fishing（钓鱼任务），支持时间范围
 *   - 逐时在线快照：某日 24 小时在线玩家名单（游戏服半每小时落库）
 *   - 玩家日历：某玩家某年每日在线分钟热力图（内联 SVG）
 *
 * 数据说明：权威统计来自游戏服半 OnlineStats.dll（TShock 进程内按分钟累计并落库）。
 * 若某台服务器未安装该 DLL，相关面板会提示"去插件下发页启用"，而不是显示 0。
 *
 * 约定：禁止 emoji；图标用内联 SVG / 纯文字；不引入图表库（宿主无框架原则）。
 */
(function () {
  'use strict'

  var tsw = window.tsweb
  if (!tsw) return

  // ═══════════ 工具 ═══════════
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    })
  }

  function api(path, opts) {
    return tsw.api(path, opts)
  }

  function pad2(n) {
    return (n < 10 ? '0' : '') + n
  }

  /** 日期时间：MM-DD HH:MM */
  function fmtDateTime(t) {
    if (!t) return '-'
    var d = new Date(t)
    return pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes())
  }

  /** 本地日期 → yyyy-MM-dd（与游戏服端 date 列一致） */
  function fmtDateInput(d) {
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate())
  }

  /** 分钟 → "X 小时 Y 分" */
  function fmtMinutes(min) {
    var m = Math.max(0, Math.round(Number(min) || 0))
    var h = Math.floor(m / 60)
    var rest = m % 60
    return h > 0 ? (h + ' 小时 ' + rest + ' 分') : (rest + ' 分')
  }

  /** 逐时快照的 hour_ts（yyyyMMddHH）→ "HH:00" */
  function fmtHourTs(ts) {
    var s = String(ts)
    return s.length >= 10 ? (s.slice(8, 10) + ':00') : String(ts)
  }

  /** 统一错误文案：把"服务端半未安装"变成可操作提示 */
  function errText(data, status) {
    if (data && data.serverHalfMissing) {
      return (data.error || '游戏服端未安装服务端半') + ' —— 请到「插件下发」页对该服务器启用 OnlineStats.dll 后重试'
    }
    return (data && data.error) || ('HTTP ' + status)
  }

  var root = null

  function $(id) {
    return root ? root.querySelector('#' + id) : null
  }

  function setMsg(text, cls) {
    var el = $('os-msg')
    if (!el) return
    el.className = cls || 'muted'
    el.textContent = text || ''
  }

  /** 各面板的"部分服务器失败"提示（多服场景：一台没装 DLL 不影响其它服数据） */
  function partialHint(errors) {
    if (!errors || !errors.length) return ''
    var names = errors.map(function (e) { return esc(e.name || e.serverId) }).join('、')
    var missing = errors.some(function (e) { return e.serverHalfMissing })
    return '<p class="muted" style="font-size:12px;margin:6px 0 0">' + names + ' 取数失败' +
      (missing ? '（未安装 OnlineStats.dll，请到「插件下发」页启用）' : '') + '：' +
      esc(errors[0].error || '') + '</p>'
  }

  // ═══════════ SVG 折线图 ═══════════
  // 纯内联 SVG：不引入任何图表库。输入 points=[{t,n}]（n 为 null 表示断点），输出 svg 字符串。
  // 超过 MAX_POINTS 时按窗口降采样（每窗口取最后一个有效值），避免 7 天（~10080 点）渲染卡顿。
  var MAX_POINTS = 400

  function sparklineSvg(points, w, h) {
    w = w || 760
    h = h || 160
    var padL = 34, padR = 8, padT = 8, padB = 20
    var innerW = w - padL - padR
    var innerH = h - padT - padB

    // ── 降采样 ──
    if (points.length > MAX_POINTS) {
      var step = Math.ceil(points.length / MAX_POINTS)
      var ds = []
      for (var si = 0; si < points.length; si += step) {
        var slice = points.slice(si, si + step)
        var last = null
        for (var sj = slice.length - 1; sj >= 0; sj--) {
          if (slice[sj].n !== null && slice[sj].n !== undefined) { last = slice[sj]; break }
        }
        if (last) ds.push(last)
        else if (slice.length) ds.push(slice[slice.length - 1]) // 全断点：保留末点（n=null）
      }
      points = ds
    }

    var nums = points.filter(function (p) { return p.n !== null && p.n !== undefined })
    var t0 = points.length ? points[0].t : Date.now() - 3600 * 1000
    var t1 = points.length ? points[points.length - 1].t : Date.now()
    if (t1 === t0) t1 = t0 + 1
    var maxN = 1
    for (var i = 0; i < nums.length; i++) { if (nums[i].n > maxN) maxN = nums[i].n }
    maxN = Math.max(1, Math.ceil(maxN * 1.1))

    var x = function (t) { return padL + ((t - t0) / (t1 - t0)) * innerW }
    var y = function (n) { return padT + innerH - (n / maxN) * innerH }

    // 网格线 + Y 轴刻度（4 条）
    var grid = ''
    for (var g = 0; g <= 4; g++) {
      var gy = padT + innerH - (g / 4) * innerH
      var gv = Math.round((maxN * g) / 4)
      grid += '<line x1="' + padL + '" y1="' + gy + '" x2="' + (w - padR) + '" y2="' + gy + '" stroke="#333" stroke-width="1" stroke-dasharray="2 3"/>'
      grid += '<text x="' + (padL - 6) + '" y="' + (gy + 3) + '" text-anchor="end" font-size="10" fill="#888">' + gv + '</text>'
    }

    // 折线：分段（null 断点断开）
    var path = ''
    var started = false
    for (var i2 = 0; i2 < points.length; i2++) {
      var p = points[i2]
      if (p.n === null || p.n === undefined) {
        started = false
        continue
      }
      var px = x(p.t).toFixed(1)
      var py = y(p.n).toFixed(1)
      if (!started) {
        path += 'M' + px + ' ' + py
        started = true
      } else {
        path += 'L' + px + ' ' + py
      }
    }

    // X 轴 4 个时间刻度（跨天显示日期）
    var xLabels = ''
    for (var xg = 0; xg <= 4; xg++) {
      var xt = t0 + ((t1 - t0) * xg) / 4
      xLabels += '<text x="' + x(xt).toFixed(1) + '" y="' + (h - 5) + '" text-anchor="middle" font-size="10" fill="#888">' + fmtAxisTime(xt, t0, t1) + '</text>'
    }

    // 悬停数据点（title 提示）
    var dots = ''
    for (var i3 = 0; i3 < nums.length; i3++) {
      var np = nums[i3]
      dots += '<circle cx="' + x(np.t).toFixed(1) + '" cy="' + y(np.n).toFixed(1) + '" r="2.2" fill="#4a9eff">' +
        '<title>' + fmtDateTime(np.t) + '  在线 ' + np.n + '</title></circle>'
    }

    return '<svg viewBox="0 0 ' + w + ' ' + h + '" style="width:100%;height:auto;display:block" role="img">' +
      '<rect x="0" y="0" width="' + w + '" height="' + h + '" fill="#16181d"/>' +
      grid + xLabels +
      (path ? '<path d="' + path + '" fill="none" stroke="#4a9eff" stroke-width="1.6" stroke-linejoin="round"/>' : '') +
      dots +
      '<text x="' + (w - padR) + '" y="' + (padT + 10) + '" text-anchor="end" font-size="10" fill="#4a9eff">在线人数</text>' +
      '</svg>'
  }

  /** 时间轴刻度：跨度跨天时显示日期+时间，否则仅时间 */
  function fmtAxisTime(t, t0, t1) {
    var spanMs = t1 - t0
    var d = new Date(t)
    var hm = pad2(d.getHours()) + ':' + pad2(d.getMinutes())
    return spanMs > 24 * 3600 * 1000 ? (pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' + hm) : hm
  }

  // ═══════════ 日历热力图（内联 SVG）═══════════
  // days=[{date:'yyyy-MM-dd',daily_min:n}] → 12 行（月）× 31 列（日）的热力格，附悬停明细。
  var HEAT_LEVELS = 4

  function heatmapSvg(days, year) {
    var map = {}
    var maxMin = 1
    ;(days || []).forEach(function (d) {
      map[d.date] = Number(d.daily_min) || 0
      if ((Number(d.daily_min) || 0) > maxMin) maxMin = Number(d.daily_min) || 0
    })

    var cell = 15, gap = 3, left = 30, top = 6, bottom = 24
    var w = left + 31 * (cell + gap) + 4
    var h = top + 12 * (cell + gap) + bottom

    var body = ''
    for (var m = 1; m <= 12; m++) {
      var y = top + (m - 1) * (cell + gap)
      body += '<text x="' + (left - 6) + '" y="' + (y + cell - 3) + '" text-anchor="end" font-size="10" fill="#888">' + m + ' 月</text>'
      var daysInMonth = new Date(year, m, 0).getDate()
      for (var d = 1; d <= daysInMonth; d++) {
        var x = left + (d - 1) * (cell + gap)
        var dateStr = year + '-' + pad2(m) + '-' + pad2(d)
        var val = map[dateStr]
        var fill = '#22252b'
        if (val) {
          var level = Math.min(HEAT_LEVELS, Math.max(1, Math.ceil((val / maxMin) * HEAT_LEVELS)))
          fill = 'rgba(74,158,255,' + (0.18 + 0.2 * level).toFixed(2) + ')'
        }
        body += '<rect x="' + x + '" y="' + y + '" width="' + cell + '" height="' + cell + '" rx="2" fill="' + fill + '">' +
          '<title>' + dateStr + '  ' + (val ? val + ' 分钟' : '无记录') + '</title></rect>'
      }
    }

    // 图例
    var legend = '<text x="' + left + '" y="' + (h - 8) + '" font-size="10" fill="#888">少</text>'
    for (var l = 1; l <= HEAT_LEVELS; l++) {
      var lx = left + 20 + (l - 1) * (cell + 2)
      legend += '<rect x="' + lx + '" y="' + (h - 18) + '" width="' + cell + '" height="10" rx="2" fill="rgba(74,158,255,' + (0.18 + 0.2 * l).toFixed(2) + ')"/>'
    }
    legend += '<text x="' + (left + 20 + HEAT_LEVELS * (cell + 2) + 6) + '" y="' + (h - 8) + '" font-size="10" fill="#888">多（按当年单日最高 ' + maxMin + ' 分钟归一）</text>'

    return '<svg viewBox="0 0 ' + w + ' ' + h + '" style="width:100%;max-width:820px;height:auto;display:block" role="img">' +
      '<rect x="0" y="0" width="' + w + '" height="' + h + '" fill="#16181d"/>' +
      body + legend + '</svg>'
  }

  // ═══════════ 视图渲染 ═══════════
  function renderShell(container) {
    var today = fmtDateInput(new Date())
    var thisYear = new Date().getFullYear()

    container.innerHTML = '' +
      '<div class="toolbar">' +
      '  <h2 style="margin:0">在线统计</h2>' +
      '  <div class="spacer"></div>' +
      '  <button id="os-refresh" class="ghost sm">刷新</button>' +
      '</div>' +
      '<p id="os-msg" class="muted" style="min-height:18px"></p>' +

      // 当前在线
      '<div class="panel" style="margin-bottom:16px">' +
      '  <h3>当前在线 <span id="os-total" class="badge"></span></h3>' +
      '  <table>' +
      '    <thead><tr><th>服务器</th><th>在线 / 上限</th><th>连接状态</th><th>采集时间</th></tr></thead>' +
      '    <tbody id="os-servers"></tbody>' +
      '  </table>' +
      '</div>' +

      // 近端趋势
      '<div class="panel" style="margin-bottom:16px">' +
      '  <div class="toolbar">' +
      '    <h3 style="margin:0">近端趋势</h3>' +
      '    <div class="spacer"></div>' +
      '    <select id="os-hours" class="sm">' +
      '      <option value="1">近 1 小时</option>' +
      '      <option value="6">近 6 小时</option>' +
      '      <option value="24" selected>近 24 小时</option>' +
      '      <option value="72">近 3 天</option>' +
      '      <option value="168">近 7 天</option>' +
      '    </select>' +
      '  </div>' +
      '  <div id="os-chart" style="margin-top:10px"></div>' +
      '  <p id="os-chart-meta" class="muted" style="font-size:13px;margin-top:8px"></p>' +
      '  <p class="muted" style="font-size:12px;margin:4px 0 0">本曲线由 TSWeb 每 60 秒采样 TShock 状态得到（分钟级）；逐时/按天的权威数据见下方各面板。</p>' +
      '</div>' +

      // 在线玩家
      '<div class="panel" style="margin-bottom:16px">' +
      '  <h3>在线玩家 <span id="os-players-count" class="badge"></span></h3>' +
      '  <table>' +
      '    <thead><tr><th>昵称</th><th>账号</th><th>组</th><th>服务器</th></tr></thead>' +
      '    <tbody id="os-players"></tbody>' +
      '  </table>' +
      '</div>' +

      // 单玩家查询
      '<div class="panel" style="margin-bottom:16px">' +
      '  <h3>单玩家查询</h3>' +
      '  <div style="display:flex;gap:8px;align-items:center;margin-top:8px;flex-wrap:wrap">' +
      '    <input id="os-player-input" type="text" placeholder="输入用户名或昵称" style="flex:1;max-width:280px"/>' +
      '    <label class="muted" style="font-size:13px">年份</label>' +
      '    <input id="os-player-year" type="number" min="2000" max="2100" value="' + thisYear + '" style="width:90px"/>' +
      '    <button id="os-player-query" class="ghost sm">查询</button>' +
      '  </div>' +
      '  <div id="os-player-result" class="muted" style="font-size:13px;line-height:1.8;margin-top:10px"></div>' +
      '</div>' +

      // 累计时长排行
      '<div class="panel" style="margin-bottom:16px">' +
      '  <div class="toolbar">' +
      '    <h3 style="margin:0">排行榜</h3>' +
      '    <div class="spacer"></div>' +
      '    <select id="os-rank-type" class="sm">' +
      '      <option value="online" selected>累计在线时长</option>' +
      '      <option value="deaths">PVE 死亡次数</option>' +
      '      <option value="fishing">钓鱼任务完成</option>' +
      '    </select>' +
      '    <select id="os-rank-mode" class="sm">' +
      '      <option value="today" selected>今天</option>' +
      '      <option value="24h">近 24 小时</option>' +
      '      <option value="7d">近 7 天</option>' +
      '      <option value="30d">近 30 天</option>' +
      '      <option value="all">全部</option>' +
      '    </select>' +
      '    <button id="os-rank-query" class="ghost sm">查询</button>' +
      '  </div>' +
      '  <table style="margin-top:10px">' +
      '    <thead><tr><th style="width:56px">名次</th><th>玩家</th><th>数值</th></tr></thead>' +
      '    <tbody id="os-ranking"></tbody>' +
      '  </table>' +
      '  <div id="os-ranking-hint"></div>' +
      '</div>' +

      // 逐时在线快照
      '<div class="panel" style="margin-bottom:16px">' +
      '  <div class="toolbar">' +
      '    <h3 style="margin:0">逐时在线快照</h3>' +
      '    <div class="spacer"></div>' +
      '    <input id="os-hourly-date" type="date" value="' + today + '" class="sm"/>' +
      '    <button id="os-hourly-query" class="ghost sm">查询</button>' +
      '  </div>' +
      '  <table style="margin-top:10px">' +
      '    <thead><tr><th style="width:80px">时段</th><th style="width:70px">人数</th><th>在线玩家</th></tr></thead>' +
      '    <tbody id="os-hourly"></tbody>' +
      '  </table>' +
      '  <div id="os-hourly-hint"></div>' +
      '</div>' +

      // 玩家日历
      '<div class="panel">' +
      '  <h3>玩家日历</h3>' +
      '  <div style="display:flex;gap:8px;align-items:center;margin-top:8px;flex-wrap:wrap">' +
      '    <input id="os-cal-input" type="text" placeholder="输入用户名" style="flex:1;max-width:280px"/>' +
      '    <label class="muted" style="font-size:13px">年份</label>' +
      '    <input id="os-cal-year" type="number" min="2000" max="2100" value="' + thisYear + '" style="width:90px"/>' +
      '    <button id="os-cal-query" class="ghost sm">查询</button>' +
      '  </div>' +
      '  <div id="os-cal-result" class="muted" style="font-size:13px;line-height:1.8;margin-top:10px"></div>' +
      '</div>'
  }

  // ── 当前在线表 ──
  function renderServers(data) {
    var tbody = $('os-servers')
    var total = $('os-total')
    if (!tbody) return
    var list = data.servers || []
    if (total) {
      total.textContent = '合计 ' + (data.total != null ? data.total : '-') + ' 人'
      total.className = 'badge'
    }
    if (!list.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="muted">尚未配置任何服务器</td></tr>'
      return
    }
    tbody.innerHTML = list.map(function (s) {
      var online = s.playercount != null ? s.playercount : '-'
      var max = s.maxplayers != null ? s.maxplayers : '-'
      var st = s.connected ? '<span class="ok">已连接</span>' : '<span class="muted">' + esc(s.status || '未连接') + '</span>'
      return '<tr>' +
        '<td>' + esc(s.name) + '</td>' +
        '<td>' + online + ' / ' + max + '</td>' +
        '<td>' + st + '</td>' +
        '<td class="muted">' + fmtDateTime(s.fetchedAt) + '</td>' +
        '</tr>'
    }).join('')
  }

  // ── 趋势图 ──
  function renderTrend(data) {
    var chart = $('os-chart')
    var meta = $('os-chart-meta')
    if (!chart) return
    var points = data.points || []
    if (!points.length) {
      chart.innerHTML = '<p class="muted" style="padding:24px 0;text-align:center">暂无趋势数据（等待采集）</p>'
      if (meta) meta.textContent = ''
      return
    }
    chart.innerHTML = sparklineSvg(points, 760, 160)
    if (meta) {
      meta.textContent = '峰值 ' + (data.max != null ? data.max : '-') + ' 人 · 平均 ' + (data.avg != null ? data.avg : '-') + ' 人 · ' + points.length + ' 个采样点'
    }
  }

  // ── 在线玩家表 ──
  function renderPlayers(data) {
    var tbody = $('os-players')
    var count = $('os-players-count')
    if (!tbody) return
    var list = data.players || []
    if (count) { count.textContent = list.length + ' 人'; count.className = 'badge' }
    if (!list.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="muted">当前没有在线玩家</td></tr>'
      return
    }
    tbody.innerHTML = list.map(function (p) {
      return '<tr>' +
        '<td>' + esc(p.nickname || '-') + '</td>' +
        '<td>' + esc(p.username || '-') + '</td>' +
        '<td>' + esc(p.group || '-') + '</td>' +
        '<td>' + esc(p.serverName || p.serverId || '-') + '</td>' +
        '</tr>'
    }).join('')
  }

  // ── 单玩家结果（权威累计时长）──
  function renderPlayerResult(d) {
    var el = $('os-player-result')
    if (!el) return
    if (d.error) {
      el.innerHTML = '<span class="error">' + esc(errText(d, d.status)) + '</span>'
      return
    }
    var lines = []
    lines.push('玩家：<b>' + esc(d.username) + '</b>')
    if (d.online) {
      var where = (d.currentServers || []).map(function (s) {
        return esc(s.name || s.serverId) + (s.group ? '（组 ' + esc(s.group) + '）' : '')
      }).join('、')
      lines.push('状态：<span class="ok">在线</span>' + (where ? ' · ' + where : ''))
    } else {
      lines.push('状态：<span class="muted">离线</span>')
    }

    var pt = d.playtime || { totalMin: 0, perServer: [] }
    lines.push('累计在线时长：<b>' + fmtMinutes(pt.totalMin) + '</b>（' + (pt.totalMin || 0) + ' 分钟）')
    if ((pt.perServer || []).length > 1) {
      lines.push('分服时长：' + pt.perServer.map(function (p) {
        return esc(p.name || p.serverId) + ' ' + fmtMinutes(p.totalMin)
      }).join(' · '))
    }
    if (d.calendar && d.calendar.days && d.calendar.days.length) {
      lines.push('日历（' + esc(d.calendar.serverName || '') + ' ' + d.calendar.year + ' 年）：有记录 ' +
        d.calendar.days.length + ' 天 —— 完整跨服日历见下方「玩家日历」')
    }
    if (d.errors && d.errors.length) {
      lines.push('<span class="error">' + esc(errText(d.errors[0], 0)) + '</span>')
    }
    el.innerHTML = lines.join('<br>')
  }

  // ── 排行榜 ──
  function renderRanking(data, type) {
    var tbody = $('os-ranking')
    var hint = $('os-ranking-hint')
    if (!tbody) return
    var rows = data.ranking || []
    if (hint) hint.innerHTML = partialHint(data.errors)
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="3" class="muted">暂无数据（需要游戏服运行一段时间后统计）</td></tr>'
      return
    }
    tbody.innerHTML = rows.map(function (r, i) {
      var name = r.uid != null ? r.uid : r.name
      var value
      if (type === 'online') value = fmtMinutes(r.total_min) + '（' + (r.total_min || 0) + ' 分钟）'
      else value = (r.value != null ? r.value : '-') + ' ' + (r.unit || '')
      return '<tr>' +
        '<td class="muted">' + (i + 1) + '</td>' +
        '<td>' + esc(name) + '</td>' +
        '<td>' + esc(value) + '</td>' +
        '</tr>'
    }).join('')
  }

  // ── 逐时快照 ──
  function renderHourly(data) {
    var tbody = $('os-hourly')
    var hint = $('os-hourly-hint')
    if (!tbody) return
    var hours = data.hours || []
    if (hint) hint.innerHTML = partialHint(data.errors)
    if (!hours.length) {
      tbody.innerHTML = '<tr><td colspan="3" class="muted">该日无快照记录</td></tr>'
      return
    }
    tbody.innerHTML = hours.map(function (h) {
      var names = h.online_players || []
      return '<tr>' +
        '<td>' + esc(fmtHourTs(h.hour_ts)) + '</td>' +
        '<td>' + (h.count != null ? h.count : names.length) + '</td>' +
        '<td style="font-size:12px">' + (names.length ? esc(names.join('、')) : '<span class="muted">无人在线</span>') + '</td>' +
        '</tr>'
    }).join('')
  }

  // ── 玩家日历 ──
  function renderCalendar(d) {
    var el = $('os-cal-result')
    if (!el) return
    if (d.error) {
      el.innerHTML = '<span class="error">' + esc(d.error) + '</span>'
      return
    }
    var head = '玩家 <b>' + esc(d.player) + '</b> · ' + d.year + ' 年 · 合计 <b>' + fmtMinutes(d.total_min) + '</b>' +
      ' · 有记录 ' + (d.days || []).length + ' 天'
    var errs = d.errors && d.errors.length ? '<br><span class="error">' + esc(errText(d.errors[0], 0)) + '</span>' : ''
    if (!d.days || !d.days.length) {
      el.innerHTML = head + '<br><span class="muted">该年暂无在线记录</span>' + errs
      return
    }
    el.innerHTML = head + errs + '<div style="margin-top:10px">' + heatmapSvg(d.days, d.year) + '</div>'
  }

  // ── 数据加载 ──
  var loading = false

  async function loadAll() {
    if (loading) return
    loading = true
    setMsg('正在加载 ...', 'muted')
    try {
      var hours = Number(($('os-hours') && $('os-hours').value) || 24)
      var results = await Promise.all([
        api('/api/online-stats/current'),
        api('/api/online-stats/trend?hours=' + hours),
        api('/api/online-stats/players'),
      ])
      var cur = results[0], trend = results[1], players = results[2]
      if (cur.ok && cur.data) renderServers(cur.data)
      else setMsg('当前在线获取失败：' + errText(cur.data, cur.status), 'error')
      if (trend.ok && trend.data) renderTrend(trend.data)
      if (players.ok && players.data) renderPlayers(players.data)
      setMsg('')
    } catch (err) {
      setMsg('加载失败：' + (err.message || err), 'error')
    } finally {
      loading = false
    }
  }

  async function queryPlayer() {
    var input = $('os-player-input')
    var yearEl = $('os-player-year')
    var username = input ? String(input.value || '').trim() : ''
    var el = $('os-player-result')
    if (!username) {
      if (el) el.innerHTML = '<span class="muted">请输入用户名或昵称</span>'
      return
    }
    var year = yearEl ? Number(yearEl.value) || new Date().getFullYear() : new Date().getFullYear()
    if (el) el.innerHTML = '查询中 ...'
    try {
      var res = await api('/api/online-stats/player?username=' + encodeURIComponent(username) + '&year=' + year)
      if (res.ok && res.data) renderPlayerResult(res.data)
      else renderPlayerResult({ error: errText(res.data, res.status), serverHalfMissing: res.data && res.data.serverHalfMissing })
    } catch (err) {
      renderPlayerResult({ error: err.message || String(err) })
    }
  }

  /** 排行榜：online 走 /ranking（带时间范围），deaths/fishing 走 /ranking/stats（带分页） */
  async function queryRanking() {
    var typeEl = $('os-rank-type')
    var modeEl = $('os-rank-mode')
    var type = typeEl ? typeEl.value : 'online'
    var mode = modeEl ? modeEl.value : 'today'
    var tbody = $('os-ranking')
    var hint = $('os-ranking-hint')
    if (tbody) tbody.innerHTML = '<tr><td colspan="3" class="muted">查询中 ...</td></tr>'
    if (hint) hint.innerHTML = ''
    if (modeEl) modeEl.disabled = (type !== 'online')
    try {
      var res = type === 'online'
        ? await api('/api/online-stats/ranking?mode=' + encodeURIComponent(mode))
        : await api('/api/online-stats/ranking-stats?type=' + encodeURIComponent(type) + '&page=1&pageSize=50')
      if (res.ok && res.data) renderRanking(res.data, type)
      else {
        if (tbody) tbody.innerHTML = '<tr><td colspan="3" class="error">' + esc(errText(res.data, res.status)) + '</td></tr>'
        if (hint) hint.innerHTML = ''
      }
    } catch (err) {
      if (tbody) tbody.innerHTML = '<tr><td colspan="3" class="error">' + esc(err.message || err) + '</td></tr>'
    }
  }

  async function queryHourly() {
    var dateEl = $('os-hourly-date')
    var date = dateEl && dateEl.value ? dateEl.value : fmtDateInput(new Date())
    var tbody = $('os-hourly')
    var hint = $('os-hourly-hint')
    if (tbody) tbody.innerHTML = '<tr><td colspan="3" class="muted">查询中 ...</td></tr>'
    if (hint) hint.innerHTML = ''
    try {
      var res = await api('/api/online-stats/hourly?date=' + encodeURIComponent(date))
      if (res.ok && res.data) renderHourly(res.data)
      else {
        if (tbody) tbody.innerHTML = '<tr><td colspan="3" class="error">' + esc(errText(res.data, res.status)) + '</td></tr>'
        if (hint) hint.innerHTML = ''
      }
    } catch (err) {
      if (tbody) tbody.innerHTML = '<tr><td colspan="3" class="error">' + esc(err.message || err) + '</td></tr>'
    }
  }

  async function queryCalendar() {
    var input = $('os-cal-input')
    var yearEl = $('os-cal-year')
    var el = $('os-cal-result')
    var username = input ? String(input.value || '').trim() : ''
    if (!username) {
      if (el) el.innerHTML = '<span class="muted">请输入用户名</span>'
      return
    }
    var year = yearEl ? Number(yearEl.value) || new Date().getFullYear() : new Date().getFullYear()
    if (el) el.innerHTML = '查询中 ...'
    try {
      var res = await api('/api/online-stats/playtime?username=' + encodeURIComponent(username) + '&year=' + year)
      if (res.ok && res.data) renderCalendar(res.data)
      else renderCalendar({ error: errText(res.data, res.status) })
    } catch (err) {
      renderCalendar({ error: err.message || String(err) })
    }
  }

  // ═══════════ 视图注册 ═══════════
  tsw.registerView({
    id: 'online-stats',
    title: '在线统计',
    section: '后端设置',
    path: '/b/online-stats',
    render: function (container) {
      root = container
      renderShell(container)

      bind('os-refresh', 'click', loadAll)
      bind('os-hours', 'change', loadAll)
      bind('os-player-query', 'click', queryPlayer)
      bindEnter('os-player-input', queryPlayer)
      bind('os-rank-query', 'click', queryRanking)
      bind('os-rank-type', 'change', queryRanking)
      bind('os-rank-mode', 'change', queryRanking)
      bind('os-hourly-query', 'click', queryHourly)
      bind('os-cal-query', 'click', queryCalendar)
      bindEnter('os-cal-input', queryCalendar)

      loadAll()
      queryRanking()
      queryHourly()
    },
  })

  function bind(id, evt, fn) {
    var el = $(id)
    if (el) el.addEventListener(evt, fn)
  }

  function bindEnter(id, fn) {
    var el = $(id)
    if (el) el.addEventListener('keydown', function (e) { if (e.key === 'Enter') fn() })
  }

  // ═══════════ 玩家详情页扩展点（可选接入）══════════════
  // 若宿主/players 已实现 window.tsweb.registerPlayerDetailSection（设计文档 3.2 节），
  // 则注册一个"在线统计"区块；未实现时无感跳过（详情页不出现该区块）。
  if (typeof tsw.registerPlayerDetailSection === 'function') {
    tsw.registerPlayerDetailSection({
      id: 'online-stats',
      title: '在线统计',
      order: 5,
      render: function (container, account) {
        var username = account && (account.Username || account.username)
        if (!username) {
          container.innerHTML = '<p class="muted">缺少账号名，无法查询</p>'
          return function () {}
        }
        var holder = document.createElement('div')
        container.appendChild(holder)
        holder.innerHTML = '查询中 ...'
        var cancelled = false
        api('/api/online-stats/player?username=' + encodeURIComponent(username))
          .then(function (res) {
            if (cancelled) return
            if (!res.ok || !res.data) {
              holder.innerHTML = '<p class="error">查询失败：' + esc(errText(res.data, res.status)) + '</p>'
              return
            }
            var d = res.data
            var pt = d.playtime || { totalMin: 0 }
            var html = '<p class="muted" style="font-size:13px;line-height:1.8;margin:0">'
            html += d.online ? '状态：<b class="ok">在线</b>' : '状态：<span class="muted">离线</span>'
            html += ' · 累计在线：<b>' + fmtMinutes(pt.totalMin) + '</b>'
            html += ' · 有记录 ' + (d.calendar && d.calendar.days ? d.calendar.days.length : 0) + ' 天'
            html += '</p>'
            holder.innerHTML = html
          })
          .catch(function (err) {
            if (!cancelled) holder.innerHTML = '<p class="error">查询失败：' + esc(err.message || err) + '</p>'
          })
        return function () { cancelled = true }
      },
    })
  }
})()
