/**
 * 在线统计插件（online-stats）—— 宿主侧半
 *
 * 数据来源分工（重要）：
 *   1. 权威统计（累计游玩时长 / 逐时在线快照 / 排行榜 / 玩家日历）
 *      → 游戏服半 OnlineStats.dll 注册的 /data/online/* 端点，由 TShock 进程内按分钟采样落库
 *        （player_daily_stat 累计分钟 + hourly_online_snapshot 逐时名单；沿用老版 TSWeb 契约）
 *   2. 当前在线 / 上限 / 世界名
 *      → TShock 自带 /v2/server/status?players=true（老版后端同样用它取 playercount）
 *   3. 近端曲线与变化事件
 *      → 本进程 60s 采样（游戏服半只有逐时粒度，画不出分钟级曲线；也用于服务端半缺失时的降级显示）
 *
 * 职责：
 *   - 代理/聚合上述三个来源，对前端与其它插件统一暴露
 *   - REST 端点（全部 verifyAuth + requireAdmin）：
 *       GET /api/online-stats/current               当前在线（单服或多服聚合）
 *       GET /api/online-stats/trend?hours=24        近端趋势（本进程 60s 采样）
 *       GET /api/online-stats/players               当前在线玩家列表
 *       GET /api/online-stats/player?username=&year= 单玩家统计（含权威累计时长与日历）
 *       GET /api/online-stats/servers               已登记服务器摘要
 *       GET /api/online-stats/hourly?date=          某日逐时在线快照（权威）
 *       GET /api/online-stats/ranking?mode=         累计时长排行（权威）
 *       GET /api/online-stats/ranking-stats?type=   通用排行 online|deaths|fishing（权威）
 *       GET /api/online-stats/playtime?username=&year= 某玩家某年每日在线分钟（权威）
 *       GET /api/online-stats/all-playtime          全量累计时长，多服聚合（权威）
 *
 * 对外服务（ctx.onlineStats，其他插件可 inject: ['onlineStats'] 依赖调用）：
 *   - getCurrent(serverId?)            → { servers: [{id,name,playercount,maxplayers,...}], total, fetchedAt }
 *   - getTrend(serverId?, hours)        → { points: [{t,n}], max, avg, perServer? }（本进程采样）
 *   - getPlayers(serverId?)             → { players: [...], fetchedAt }
 *   - getPlayerStats(username, opts?)   → { username, online, currentServers, playtime, calendar }（权威）
 *   - getServers()                      → 已登记服务器摘要
 *   - getHourly(serverId?, date)        → 逐时在线快照（权威，跨服合并名单）
 *   - getRanking(serverId?, mode)       → 累计时长排行（权威，跨服按玩家求和）
 *   - getRankingStats(serverId?, type, page, pageSize) → 通用排行（权威）
 *   - getPlaytime(serverId?, username, year) → 玩家日历（权威）
 *   - getAllPlaytime(serverId?)         → { stats: { 玩家名: 分钟 } }（权威）
 *   - on(event, handler)                → 'tick'（每轮采样完成）、'change'（某服在线数变化）
 *   - on() 返回取消函数；事件仅在同一进程内有效（不跨进程广播）
 *
 * 依赖：webServer / auth / servers / tshock / paths（全部由宿主或基础插件提供）
 * 约定：禁止 emoji；状态数据走 ctx.paths.dataOf('online-stats')（不在插件目录内）
 */
import { Service } from '@deepseek-ai/cordis'
import { readFile, writeFile, mkdir } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'online-stats'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths']

const __dirname = path.dirname(fileURLToPath(import.meta.url))

/** 默认采集间隔（毫秒）：60s 一采样，24h 共 1440 点/服 */
const DEFAULT_INTERVAL_MS = 60_000
/** 环形缓冲保留时长（毫秒）：24h */
const DEFAULT_KEEP_MS = 24 * 60 * 60 * 1000

/** 采集结果缓存有效期：getCurrent 直接问询太频繁会打服务器，缓存 30s */
const CURRENT_CACHE_MS = 30_000

/** 游戏服半的权威统计端点前缀（OnlineStats.dll 注册，权限 data.rest.invsee） */
const SERVER_HALF_PREFIX = '/data/online'

class OnlineStatsService extends Service {
  constructor(ctx, options = {}) {
    super(ctx, 'onlineStats')
    this.servers = null      // 由 apply 注入（ServerRegistryService）
    this.tshock = null       // 由 apply 注入（TshockService）
    this.dataFile = null     // 由 apply 注入（<dataDir>/online-stats/trends.json）

    this.intervalMs = Number(options.intervalMs) || DEFAULT_INTERVAL_MS
    this.keepMs = Number(options.keepMs) || DEFAULT_KEEP_MS

    /** serverId -> [{ t, n }]（t=毫秒时间戳，n=在线数），按时间升序 */
    this.buffer = new Map()
    /** serverId -> { playercount, maxplayers, name, fetchedAt, players } 最近一次采集快照（含在线玩家明细） */
    this.snapshots = new Map()
    /** serverId -> { playercount, fetchedAt } getCurrent 的短缓存 */
    this.currentCache = new Map()
    /** serverId -> bool 该服是否已确认安装 online-stats 游戏服半（用于降级提示，避免每次请求都探测） */
    this.serverHalfState = new Map()

    /** 采集定时器 / 运行状态 */
    this._timer = null
    this._running = false
    this._lastTickAt = 0
    this._tickSeq = 0
    /** 事件订阅：eventName -> Set<handler> */
    this._listeners = new Map()
  }

  // ═════════════ 事件订阅（供其他插件响应式使用）═════════════

  /**
   * 订阅事件。返回取消函数。
   * 事件：
   *   'tick'   → 每轮采集完成：({ tickSeq, at, servers: [{id,name,playercount}], total })
   *   'change' → 某服在线数与上次采集不同：({ serverId, name, prev, cur, at })
   */
  on(event, handler) {
    if (typeof handler !== 'function') return () => {}
    let set = this._listeners.get(event)
    if (!set) {
      set = new Set()
      this._listeners.set(event, set)
    }
    set.add(handler)
    return () => { set.delete(handler) }
  }

  _emit(event, payload) {
    const set = this._listeners.get(event)
    if (!set || set.size === 0) return
    for (const handler of set) {
      try { handler(payload) } catch (err) { console.error('[online-stats] 事件处理异常:', err.message) }
    }
  }

  // ═════════════ 对外数据接口（其他插件 inject 调用）═════════════

  /** 服务器摘要（含当前在线数缓存 + 服务端半安装状态） */
  async getServers() {
    const list = await this.servers.list()
    return list.map((s) => {
      const snap = this.snapshots.get(s.id)
      const cache = this.currentCache.get(s.id)
      return {
        id: s.id,
        name: s.name,
        host: s.host,
        port: s.port,
        enabled: s.enabled !== false,
        status: s.status || 'unknown',
        connected: !!s.connected, // 注意：servers.list() sanitize 字段是 connected（非 isConnected）
        serverHalf: this.serverHalfState.get(s.id), // true=已确认安装服务端半 / false=未安装 / undefined=尚未探测
        playercount: snap ? snap.playercount : (cache ? cache.playercount : null),
        maxplayers: snap ? snap.maxplayers : null,
        fetchedAt: snap ? snap.fetchedAt : (cache ? cache.fetchedAt : 0),
      }
    })
  }

  /** 当前在线：单服或多服聚合。serverId 缺省 = 全部 enabled 服务器合计 */
  async getCurrent(serverId) {
    const targets = await this._targetServers(serverId)

    const now = Date.now()
    const servers = []
    let total = 0
    for (const s of targets) {
      const live = await this._fetchCurrent(s)
      servers.push({
        id: s.id,
        name: live.ok ? live.name : s.name,
        playercount: live.ok ? live.playercount : null,
        maxplayers: live.ok ? live.maxplayers : null,
        status: s.status || 'unknown',
        connected: !!s.connected,
        error: live.ok ? undefined : live.error,
        fetchedAt: live.ok ? live.fetchedAt : 0,
      })
      if (live.ok) total += live.playercount
    }
    return {
      servers,
      total,
      fetchedAt: now,
      serverId: serverId || undefined,
    }
  }

  /** 近端趋势（本进程 60s 采样）：points 按时间升序。serverId 缺省 = 全部（perServer 逐服序列 + 合计 max/avg） */
  async getTrend(serverId, hours = 24) {
    // 归一化 hours（1h ~ 7d），供其他插件直接调用时也受保护
    hours = Math.min(Math.max(Number(hours) || 24, 1), 168)
    const since = Date.now() - hours * 60 * 60 * 1000
    const targets = await this._targetServers(serverId)

    // 单服：直接返回该服序列
    if (targets.length === 1) {
      const series = this._seriesOf(targets[0].id, since)
      return { serverId: targets[0].id, name: targets[0].name, points: series, max: maxOf(series), avg: avgOf(series) }
    }

    // 多服：合计序列（同一轮采集各服 t 完全一致，直接按 t 对齐求和）
    const perServer = {}
    const merged = new Map() // t -> sum
    for (const s of targets) {
      const series = this._seriesOf(s.id, since)
      perServer[s.id] = { name: s.name, points: series }
      for (const p of series) {
        if (p.n === null || p.n === undefined) continue // 断点不参与合计
        merged.set(p.t, (merged.get(p.t) || 0) + p.n)
      }
    }
    const points = [...merged.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([t, sum]) => ({ t, n: sum }))
    return {
      serverId: undefined,
      points,
      max: maxOf(points),
      avg: avgOf(points),
      perServer,
    }
  }

  /** 在线玩家列表（最近一次采集快照；单服或多服聚合） */
  async getPlayers(serverId) {
    const targets = await this._targetServers(serverId)

    const players = []
    for (const s of targets) {
      const snap = this.snapshots.get(s.id)
      if (!snap || !Array.isArray(snap.players)) continue
      for (const p of snap.players) {
        players.push({
          nickname: p.nickname || '',
          username: p.username || '',
          group: p.group || '',
          state: p.state,
          team: p.team,
          serverId: s.id,
          serverName: s.name,
        })
      }
    }
    return { players, serverId: serverId || undefined, fetchedAt: Math.max(0, ...targets.map((s) => this.snapshots.get(s.id)?.fetchedAt || 0)) }
  }

  /**
   * 单玩家统计（权威）：
   *   - 当前在线：来自本进程采集快照（TShock status 的 players 明细）
   *   - 累计时长/日历：来自游戏服半 /data/online/player（进程内逐分钟累计，落库）
   * 兼容旧签名 getPlayerStats(username, serverId)，新签名 getPlayerStats(username, { serverId, year })
   */
  async getPlayerStats(username, opts = {}) {
    const displayName = String(username || '').trim()
    if (!displayName) {
      const err = new Error('username 不能为空')
      err.status = 400
      throw err
    }
    const serverId = typeof opts === 'string' ? opts : opts.serverId
    const year = typeof opts === 'object' && opts.year ? Number(opts.year) : undefined
    const key = displayName.toLowerCase()
    const targets = await this._targetServers(serverId)

    // 当前在线（采集快照）
    const currentServers = []
    for (const s of targets) {
      const snap = this.snapshots.get(s.id)
      if (!snap || !Array.isArray(snap.players)) continue
      const hit = snap.players.find((p) => (p.username || '').toLowerCase() === key
        || (p.nickname || '').toLowerCase() === key)
      if (hit) {
        currentServers.push({
          serverId: s.id,
          name: s.name,
          nickname: hit.nickname || '',
          group: hit.group || '',
        })
      }
    }

    // 权威累计时长（逐服取 /data/online/player；单服失败不中断，错误汇总在 errors）
    const half = await this._serverHalfAll(targets, '/player', { name: displayName, year })
    const perServer = []
    const errors = half.errors
    let totalMin = 0
    let calendar = null
    for (const { server: s, data } of half.ok) {
      const min = Number(data.total_min) || 0
      totalMin += min
      perServer.push({ serverId: s.id, name: s.name, totalMin: min, year: data.year })
      if (!calendar && Array.isArray(data.days)) {
        calendar = {
          serverId: s.id,
          serverName: s.name,
          year: data.year,
          days: data.days,
          totalMin: min,
        }
      }
    }

    return {
      username: displayName,
      online: currentServers.length > 0,
      currentServers,
      playtime: { totalMin, unit: 'min', perServer },
      calendar,
      errors: errors.length ? errors : undefined,
    }
  }

  // ═════════════ 权威统计（游戏服半 /data/online/*）═════════════

  /**
   * 逐时在线快照（权威）：某日每小时在线玩家名单（hourly_online_snapshot）。
   * 多服时按小时合并：online_players 为并集（去重排序），perServer 记录各服该小时人数。
   */
  async getHourly(serverId, date) {
    const day = date || formatDate(new Date())
    const targets = await this._targetServers(serverId)
    const { ok, errors } = await this._serverHalfAll(targets, '/hourly', { date: day })
    if (ok.length === 0) throw firstErrorOf(errors)
    const byHour = new Map()
    const perServer = []

    for (const { server: s, data } of ok) {
      const hours = Array.isArray(data.hours) ? data.hours : []
      perServer.push({ serverId: s.id, name: s.name, hours })
      for (const h of hours) {
        const names = Array.isArray(h.online_players) ? h.online_players : []
        let slot = byHour.get(h.hour_ts)
        if (!slot) {
          slot = { hour_ts: h.hour_ts, names: new Set(), perServer: {} }
          byHour.set(h.hour_ts, slot)
        }
        slot.perServer[s.id] = names.length
        for (const n of names) slot.names.add(n)
      }
    }

    const hours = [...byHour.values()]
      .sort((a, b) => a.hour_ts - b.hour_ts)
      .map((h) => ({
        hour_ts: h.hour_ts,
        count: h.names.size,
        online_players: [...h.names].sort(),
        perServer: h.perServer,
      }))

    return {
      date: day,
      serverId: serverId || undefined,
      hours,
      perServer: serverId ? undefined : perServer,
      errors: errors.length ? errors : undefined,
    }
  }

  /**
   * 累计游玩时长排行（权威）：mode=today|24h|7d|30d|all。
   * 多服按玩家名求和后排序（同一玩家在多个服的时长累加）。
   */
  async getRanking(serverId, mode = 'today') {
    const targets = await this._targetServers(serverId)
    const { ok, errors } = await this._serverHalfAll(targets, '/ranking', { mode })
    if (ok.length === 0) throw firstErrorOf(errors)
    const merged = new Map()
    const perServer = []
    let since = null

    for (const { server: s, data } of ok) {
      const rows = Array.isArray(data.ranking) ? data.ranking : []
      since = since || data.since || null
      perServer.push({ serverId: s.id, name: s.name, ranking: rows })
      for (const r of rows) {
        const uid = r.uid || ''
        if (!uid) continue
        merged.set(uid, (merged.get(uid) || 0) + (Number(r.total_min) || 0))
      }
    }

    const ranking = [...merged.entries()]
      .map(([uid, total_min]) => ({ uid, total_min }))
      .sort((a, b) => b.total_min - a.total_min)

    return {
      mode,
      since,
      serverId: serverId || undefined,
      ranking,
      perServer: serverId ? undefined : perServer,
      errors: errors.length ? errors : undefined,
    }
  }

  /**
   * 通用排行榜（权威）：type=online（累计时长）| deaths（PVE 死亡）| fishing（钓鱼任务）。
   * 多服按玩家名求和后统一分页（分页作用于聚合结果，不是逐服分页）。
   */
  async getRankingStats(serverId, type = 'online', page = 1, pageSize = 10) {
    const kind = String(type || 'online').toLowerCase()
    if (!['online', 'deaths', 'fishing'].includes(kind)) {
      const err = new Error(`type 必须是 online | deaths | fishing，实际为: ${type}`)
      err.status = 400
      throw err
    }
    const p = Math.max(1, Number(page) || 1)
    const size = Math.min(Math.max(1, Number(pageSize) || 10), 1000)
    const targets = await this._targetServers(serverId)
    const { ok, errors } = await this._serverHalfAll(targets, '/ranking/stats', { type: kind, page: 1, pageSize: 1000 })
    if (ok.length === 0) throw firstErrorOf(errors)

    // 逐服取足够多的行（聚合后才能正确分页）：按聚合上限 1000 行/服
    const merged = new Map()
    const perServer = []
    let unit = kind === 'online' ? 'min' : (kind === 'deaths' ? '次' : '个')

    for (const { server: s, data } of ok) {
      const rows = Array.isArray(data.ranking) ? data.ranking : []
      if (rows.length && rows[0].unit) unit = rows[0].unit
      perServer.push({ serverId: s.id, name: s.name, total: data.total, ranking: rows })
      for (const r of rows) {
        const name = r.name || ''
        if (!name) continue
        merged.set(name, (merged.get(name) || 0) + (Number(r.value) || 0))
      }
    }

    const all = [...merged.entries()]
      .map(([name, value]) => ({ name, value, unit }))
      .filter((r) => r.value > 0)
      .sort((a, b) => b.value - a.value)

    const offset = (p - 1) * size
    return {
      type: kind,
      page: p,
      pageSize: size,
      total: all.length,
      ranking: all.slice(offset, offset + size),
      serverId: serverId || undefined,
      perServer: serverId ? undefined : perServer,
      errors: errors.length ? errors : undefined,
    }
  }

  /**
   * 玩家日历（权威）：某玩家某年每日在线分钟。多服按日期求和。
   * year 缺省 = 当前年。
   */
  async getPlaytime(serverId, username, year) {
    const displayName = String(username || '').trim()
    if (!displayName) {
      const err = new Error('username 不能为空')
      err.status = 400
      throw err
    }
    const y = Number(year) || new Date().getFullYear()
    const targets = await this._targetServers(serverId)
    const { ok, errors } = await this._serverHalfAll(targets, '/player', { name: displayName, year: y })
    if (ok.length === 0) throw firstErrorOf(errors)
    const perServer = []
    const byDate = new Map()
    let totalMin = 0

    for (const { server: s, data } of ok) {
      const min = Number(data.total_min) || 0
      totalMin += min
      perServer.push({ serverId: s.id, name: s.name, totalMin: min })
      for (const d of (Array.isArray(data.days) ? data.days : [])) {
        byDate.set(d.date, (byDate.get(d.date) || 0) + (Number(d.daily_min) || 0))
      }
    }

    const days = [...byDate.entries()]
      .sort((a, b) => (a[0] < b[0] ? -1 : 1))
      .map(([date, daily_min]) => ({ date, daily_min }))

    return {
      player: displayName,
      year: y,
      days,
      total_min: totalMin,
      serverId: serverId || undefined,
      perServer: serverId ? undefined : perServer,
      errors: errors.length ? errors : undefined,
    }
  }

  /** 全量累计时长（权威）：{ stats: { 玩家名: 分钟 } }，多服按玩家名求和 */
  async getAllPlaytime(serverId) {
    const targets = await this._targetServers(serverId)
    const { ok, errors } = await this._serverHalfAll(targets, '/all-stat', {})
    if (ok.length === 0) throw firstErrorOf(errors)
    const stats = {}
    const perServer = []

    for (const { server: s, data } of ok) {
      const map = (data && typeof data.stats === 'object' && data.stats) || {}
      perServer.push({ serverId: s.id, name: s.name, players: Object.keys(map).length })
      for (const [name, min] of Object.entries(map)) {
        stats[name] = (stats[name] || 0) + (Number(min) || 0)
      }
    }

    return {
      stats,
      serverId: serverId || undefined,
      perServer: serverId ? undefined : perServer,
      errors: errors.length ? errors : undefined,
    }
  }

  // ═════════════ 采集（内部）═════════════

  /** 解析目标服务器（缺省 = 全部 enabled）；指定 serverId 但不存在/未启用 → 404 */
  async _targetServers(serverId) {
    const list = await this.servers.list()
    const enabled = list.filter((s) => s.enabled !== false)
    const targets = serverId ? enabled.filter((s) => s.id === serverId) : enabled
    if (serverId && targets.length === 0) {
      const err = new Error('目标服务器不存在或未启用')
      err.status = 404
      throw err
    }
    return targets
  }

  /**
   * 逐服调用游戏服半并容错：单服失败不中断整体（多服场景下部分服未装服务端半时仍返回可用数据）。
   * 返回 { ok: [{ server, data }], errors: [{ serverId, name, error, serverHalfMissing }] }
   */
  async _serverHalfAll(targets, suffix, params = {}) {
    const ok = []
    const errors = []
    for (const s of targets) {
      try {
        ok.push({ server: s, data: await this._serverHalf(s, suffix, params) })
      } catch (err) {
        errors.push({
          serverId: s.id,
          name: s.name,
          error: err.message,
          serverHalfMissing: !!err.serverHalfMissing,
        })
      }
    }
    return { ok, errors }
  }

  /** 调用游戏服半端点（/data/online/*）。成功返回 response body（解析后的对象）。
   * 失败按原因归类抛错，便于前端给出可操作提示：
   *   404 → 服务端半未安装（err.serverHalfMissing = true）
   *   401/403 → token 缺 data.rest.invsee 权限
   *   其它/网络 → 服务端返回异常或连接失败
   */
  async _serverHalf(server, suffix, params = {}) {
    let result
    try {
      result = await this.tshock.fetchFor(server, `${SERVER_HALF_PREFIX}${suffix}`, params)
    } catch (err) {
      const e = new Error(`连接游戏服失败: ${err.message}`)
      e.status = 502
      e.serverId = server.id
      throw e
    }

    if (result.ok) {
      this.serverHalfState.set(server.id, true)
      return result.data || {}
    }

    if (result.status === 404) {
      this.serverHalfState.set(server.id, false)
      const e = new Error('游戏服端未安装 online-stats 服务端半（OnlineStats.dll）：请在「插件下发」页对该服务器启用')
      e.status = 501
      e.serverHalfMissing = true
      e.serverId = server.id
      throw e
    }
    if (result.status === 401 || result.status === 403) {
      const e = new Error(`游戏服 token 权限不足（HTTP ${result.status}）：需要 data.rest.invsee 权限`)
      e.status = 502
      e.serverId = server.id
      throw e
    }
    const e = new Error(`游戏服端点返回 HTTP ${result.status}${result.data ? ': ' + describeRestError(result.data) : ''}`)
    e.status = 502
    e.serverId = server.id
    throw e
  }

  /** 采集一轮：轮询全部 enabled 服务器在线数 + 玩家明细，写入缓冲与快照 */
  async _collect() {
    if (this._running) return
    this._running = true
    const at = Date.now()
    this._tickSeq++
    try {
      const list = await this.servers.list()
      const enabled = list.filter((s) => s.enabled !== false)
      const summary = []
      let total = 0
      for (const s of enabled) {
        const prev = this.buffer.get(s.id)?.at(-1)?.n ?? null
        const result = await this._fetchCurrent(s)
        if (result.ok) {
          this._pushPoint(s.id, at, result.playercount)
          total += result.playercount
          summary.push({ id: s.id, name: s.name, playercount: result.playercount })
          if (prev !== null && prev !== result.playercount) {
            this._emit('change', { serverId: s.id, name: s.name, prev, cur: result.playercount, at })
          }
        } else {
          // 服务器无响应：写入一个 null 占位（趋势图上断点），不累计 total
          this._pushPoint(s.id, at, null)
          summary.push({ id: s.id, name: s.name, playercount: null, error: result.error })
        }
        this._prune(s.id)
      }
      this._lastTickAt = at
      this._emit('tick', { tickSeq: this._tickSeq, at, servers: summary, total })
      // 清理已删除服务器的残留缓存/快照/缓冲（防内存累积）
      const alive = new Set(enabled.map((s) => s.id))
      for (const id of [...this.currentCache.keys()]) { if (!alive.has(id)) this.currentCache.delete(id) }
      for (const id of [...this.snapshots.keys()]) { if (!alive.has(id)) this.snapshots.delete(id) }
      for (const id of [...this.buffer.keys()]) { if (!alive.has(id)) this.buffer.delete(id) }
      for (const id of [...this.serverHalfState.keys()]) { if (!alive.has(id)) this.serverHalfState.delete(id) }
      // 落盘（失败不阻断采集）
      try { await this._persist() } catch (err) { console.error('[online-stats] 趋势落盘失败:', err.message) }
    } catch (err) {
      console.error('[online-stats] 采集失败:', err.message)
    } finally {
      this._running = false
    }
  }

  /** 问询一台服务器当前在线（带 30s 短缓存；失败返回 { ok:false, error } 不抛错） */
  async _fetchCurrent(server) {
    const cached = this.currentCache.get(server.id)
    if (cached && Date.now() - cached.fetchedAt < CURRENT_CACHE_MS) {
      return { ok: true, ...cached }
    }
    try {
      const result = await this.tshock.fetchFor(server, '/v2/server/status', { players: true })
      if (result.ok && result.data && typeof result.data.playercount === 'number') {
        const payload = {
          playercount: result.data.playercount,
          maxplayers: result.data.maxplayers ?? null,
          name: result.data.name || server.name,
          fetchedAt: Date.now(),
        }
        this.currentCache.set(server.id, payload)
        this.snapshots.set(server.id, {
          ...payload,
          players: Array.isArray(result.data.players) ? result.data.players : [],
        })
        return { ok: true, ...payload }
      }
      if (result.status === 401 || result.status === 403) {
        return { ok: false, error: `token 无效或权限不足（HTTP ${result.status}）` }
      }
      return { ok: false, error: `TShock REST 返回 ${result.status}`, status: result.status }
    } catch (err) {
      return { ok: false, error: err.message, type: err.type || 'network' }
    }
  }

  /** 写入环形缓冲（n 为 null 表示该时刻无数据/断点） */
  _pushPoint(serverId, t, n) {
    let series = this.buffer.get(serverId)
    if (!series) {
      series = []
      this.buffer.set(serverId, series)
    }
    const last = series.at(-1)
    if (last && Math.abs(last.t - t) < this.intervalMs / 2) {
      // 同一采样窗口内重复写入：覆盖（避免抖动产生双点）
      last.n = n
      last.t = t
      return
    }
    series.push({ t, n })
    this._prune(serverId)
  }

  /** 裁剪超出保留窗口的点 */
  _prune(serverId) {
    const series = this.buffer.get(serverId)
    if (!series) return
    const cutoff = Date.now() - this.keepMs
    while (series.length > 0 && series[0].t < cutoff) series.shift()
  }

  /** 取某服某时间段序列（升序；含 null 断点） */
  _seriesOf(serverId, since) {
    const series = this.buffer.get(serverId) || []
    return series.filter((p) => p.t >= since).map((p) => ({ t: p.t, n: p.n }))
  }

  // ═════════════ 持久化 ═════════════

  /** 落盘：缓冲（JSON；仅在缓冲非空时写）。权威累计数据在游戏服端落库，这里只存本进程采样曲线 */
  async _persist() {
    if (!this.dataFile || this.buffer.size === 0) return
    const payload = {
      updatedAt: Date.now(),
      buffers: {},
    }
    for (const [id, series] of this.buffer) {
      payload.buffers[id] = series
    }
    await mkdir(path.dirname(this.dataFile), { recursive: true })
    await writeFile(this.dataFile, JSON.stringify(payload), 'utf8')
  }

  /** 启动时回填上次进程的趋势（失败静默） */
  async _restore() {
    if (!this.dataFile) return
    try {
      const raw = await readFile(this.dataFile, 'utf8')
      const parsed = JSON.parse(raw)
      if (parsed && typeof parsed === 'object' && parsed.buffers) {
        for (const [id, series] of Object.entries(parsed.buffers)) {
          if (Array.isArray(series) && series.length) {
            this.buffer.set(id, series)
            this._prune(id)
          }
        }
        console.log(`[online-stats] 已回填本进程采样曲线（${this.buffer.size} 服）`)
      }
    } catch { /* 首次运行/文件损坏：忽略 */ }
  }

  // ═════════════ 生命周期 ═════════════

  start() {
    if (this._timer) return
    this._timer = setInterval(() => { this._collect().catch(() => {}) }, this.intervalMs)
    this._timer.unref?.()
    console.log(`[online-stats] 采集已启动（每 ${Math.round(this.intervalMs / 1000)}s 一轮，保留 ${Math.round(this.keepMs / 3600_000)}h）`)
  }

  stop() {
    if (this._timer) { clearInterval(this._timer); this._timer = null }
  }

  /** 插件卸载清理：停采集 + 落盘 */
  async dispose() {
    this.stop()
    try { await this._persist() } catch { /* ignore */ }
  }
}

// ═════════════ 工具 ═════════════

function maxOf(points) {
  let max = null
  for (const p of points) {
    if (p.n === null || p.n === undefined) continue
    if (max === null || p.n > max) max = p.n
  }
  return max
}

function avgOf(points) {
  let sum = 0
  let count = 0
  for (const p of points) {
    if (p.n === null || p.n === undefined) continue
    sum += p.n
    count++
  }
  return count ? Math.round((sum / count) * 10) / 10 : null
}

/** 本地日期 → yyyy-MM-dd（游戏服端表里的 date 列格式） */
function formatDate(d) {
  const pad = (n) => (n < 10 ? '0' : '') + n
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}

/** 从 TShock REST 错误响应里提取可读信息（老版 RestObject 的 error 字段） */
function describeRestError(data) {
  if (!data) return ''
  if (typeof data === 'string') return data
  if (typeof data.error === 'string') return data.error
  try { return JSON.stringify(data).slice(0, 200) } catch { return '' }
}

/**
 * 全部目标服务器都取数失败时，抛出首个错误（保留 501=服务端半未安装 / 502=服务端异常 的分类，
 * 让前端能给出"去插件下发页启用"这类可操作提示）。
 */
function firstErrorOf(errors) {
  const first = (errors && errors[0]) || {}
  const err = new Error(first.error || '游戏服端数据获取失败')
  err.status = first.serverHalfMissing ? 501 : 502
  err.serverHalfMissing = !!first.serverHalfMissing
  err.serverId = first.serverId
  err.errors = errors
  return err
}

// ═════════════ 插件挂载 ═════════════

export async function apply(ctx, options = {}) {
  const service = new OnlineStatsService(ctx, options)
  service.servers = ctx.servers
  service.tshock = ctx.tshock
  service.dataFile = path.join(ctx.paths.dataOf('online-stats'), 'trends.json')

  // 回填上次进程数据 → 立即采集一轮 → 启动定时器
  await service._restore()
  ctx.onlineStats = service
  service._collect().catch(() => {})
  service.start()

  // ══ REST 端点（全部 admin 鉴权）══
  const app = ctx.webServer.app
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]
  /** 目标服务器：优先 x-server-id 头，其次 serverId 查询参数，缺省 = 全部 enabled */
  const reqServerId = (req) => req.headers['x-server-id'] || (req.query && req.query.serverId) || undefined
  /** 统一错误响应：带 status 的错误用其状态码（501=服务端半未安装 / 502=服务端异常 / 400=参数） */
  const fail = (res, err) => res.status(err.status || 500).json({
    error: err.message,
    serverId: err.serverId,
    serverHalfMissing: err.serverHalfMissing || undefined,
  })

  // 当前在线
  app.get('/api/online-stats/current', ...admin, async (req, res) => {
    try {
      res.json(await service.getCurrent(reqServerId(req)))
    } catch (err) {
      fail(res, err)
    }
  })

  // 近端趋势（本进程 60s 采样）
  app.get('/api/online-stats/trend', ...admin, async (req, res) => {
    try {
      const hours = Math.min(Math.max(Number((req.query || {}).hours) || 24, 1), 168) // 1h ~ 7d
      res.json(await service.getTrend(reqServerId(req), hours))
    } catch (err) {
      fail(res, err)
    }
  })

  // 在线玩家列表
  app.get('/api/online-stats/players', ...admin, async (req, res) => {
    try {
      res.json(await service.getPlayers(reqServerId(req)))
    } catch (err) {
      fail(res, err)
    }
  })

  // 单玩家统计（含权威累计时长与日历）
  app.get('/api/online-stats/player', ...admin, async (req, res) => {
    try {
      const q = req.query || {}
      res.json(await service.getPlayerStats(q.username, { serverId: reqServerId(req), year: q.year }))
    } catch (err) {
      fail(res, err)
    }
  })

  // 服务器摘要（含在线数 + 服务端半安装状态）
  app.get('/api/online-stats/servers', ...admin, async (req, res) => {
    try {
      res.json({ servers: await service.getServers() })
    } catch (err) {
      fail(res, err)
    }
  })

  // ── 以下为游戏服半权威统计（/data/online/*）──

  // 某日逐时在线快照
  app.get('/api/online-stats/hourly', ...admin, async (req, res) => {
    try {
      const date = (req.query || {}).date
      res.json(await service.getHourly(reqServerId(req), date))
    } catch (err) {
      fail(res, err)
    }
  })

  // 累计时长排行
  app.get('/api/online-stats/ranking', ...admin, async (req, res) => {
    try {
      const mode = (req.query || {}).mode || 'today'
      res.json(await service.getRanking(reqServerId(req), mode))
    } catch (err) {
      fail(res, err)
    }
  })

  // 通用排行榜（online | deaths | fishing）
  app.get('/api/online-stats/ranking-stats', ...admin, async (req, res) => {
    try {
      const q = req.query || {}
      res.json(await service.getRankingStats(reqServerId(req), q.type || 'online', q.page, q.pageSize))
    } catch (err) {
      fail(res, err)
    }
  })

  // 玩家日历（某玩家某年每日在线分钟）
  app.get('/api/online-stats/playtime', ...admin, async (req, res) => {
    try {
      const q = req.query || {}
      res.json(await service.getPlaytime(reqServerId(req), q.username, q.year))
    } catch (err) {
      fail(res, err)
    }
  })

  // 全量累计时长（多服聚合）
  app.get('/api/online-stats/all-playtime', ...admin, async (req, res) => {
    try {
      res.json(await service.getAllPlaytime(reqServerId(req)))
    } catch (err) {
      fail(res, err)
    }
  })

  console.log('[online-stats] 在线统计插件已挂载（ctx.onlineStats + /api/online-stats/*，权威统计走游戏服半 /data/online/*）')
  // 返回 dispose effect：cordis 在插件禁用/卸载时调用（停采集定时器 + 落盘）。
  // 注意：不能返回 service 对象（"Invalid effect"），返回函数是合法 effect。
  return () => service.dispose()
}
