/* TSWeb 插件市场客户端插件（market 的前端半）
 *
 * 依赖宿主能力（window.tsweb，由 web 插件提供）：
 *   - window.tsweb.registerView({ id, title, section, path, render, icon })
 *   - window.tsweb.api(path, opts)   带 Bearer 的统一请求：{ ok, status, data }
 *
 * 页面：#/b/market（后端设置 → 插件市场），三栏布局：
 *   插件列表  —— 市场索引里的插件卡片：介绍、标签、体积、发布时间、状态徽标、安装/更新/卸载
 *   收藏      —— 收藏过的插件（服务端持久化，见 config.favorites），星标切换
 *   已安装    —— 登记表里的插件（含市场外的自带/本地插件），来源徽标 + 启用状态 + 可更新提示
 *
 * 本地插件（登记表）只在「插件管理」页维护，本页仅做市场侧操作。
 */
(function () {
  'use strict'

  var tsw = window.tsweb
  if (!tsw) return

  var root = null
  var styleDone = false

  // ═══════════ 状态 ═══════════
  var state = {
    /** 市场索引（已与本地登记表对比） */
    plugins: [],
    /** 登记表全量（含市场外的自带/本地插件），用于「已安装」栏 */
    installed: [],
    busy: false,
    /** 搜索关键字（名称 / 介绍 / 标签） */
    query: '',
    /** 选中的标签筛选（空=不限） */
    tag: '',
    /** 收藏栏当前页（1 起；越界时由 pageSlice 夹取并回写） */
    favPage: 1,
    /** 已安装栏当前页（1 起；同上） */
    instPage: 1,
  }

  /** 市场索引来源标记（refresh 后由后端返回镜像 id） */
  var lastMirror = ''

  /**
   * 侧栏每页条数（收藏 / 已安装共用）。
   *
   * 为什么这两栏必须分页：「已安装」取的是**登记表全量**，含全部自带插件（十几条起步，
   * 且随安装不断增长），「收藏」则是用户长期累积的结果。不分页时它们会把页面拉成一条
   * 极长的窄列，与主列高度完全失衡，且要滚动很久才能看到底部的插件。
   * 定 6 条是为了在当前数据量下（自带插件 10 个上下）分页真正起到分屏作用，
   * 而不是变成"永远只有一页"的摆设。
   */
  var PAGE_SIZE = 6

  // ═══════════ 工具 ═══════════
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    })
  }

  function human(bytes) {
    var n = Number(bytes || 0)
    if (!n) return '-'
    if (n < 1024) return n + ' B'
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB'
    return (n / 1024 / 1024).toFixed(2) + ' MB'
  }

  /** 发布时间 → 本地日期（只到天，足够用） */
  function shortDate(iso) {
    if (!iso) return ''
    var d = new Date(iso)
    if (isNaN(d.getTime())) return ''
    var p = function (n) { return (n < 10 ? '0' : '') + n }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate())
  }

  function api(path, opts) {
    return tsw.api(path, opts)
  }

  function $(id) {
    return root ? root.querySelector('#' + id) : null
  }

  /** 内联 SVG 图标（项目约定：不使用 emoji） */
  function svg(inner, size) {
    var s = size || 14
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
      'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex:0 0 auto;vertical-align:-2px">' + inner + '</svg>'
  }

  var ICON = {
    star: '<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 3v6h-6"/>',
    download: '<path d="M12 3v12"/><path d="M7 11l5 5 5-5"/><path d="M4 21h16"/>',
    trash: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M6 6l1 14h10l1-14"/>',
    plug: '<path d="M9 3v6"/><path d="M15 3v6"/><path d="M6 9h12v3a6 6 0 0 1-12 0z"/><path d="M12 18v3"/>',
    box: '<path d="M21 8l-9-5-9 5 9 5z"/><path d="M3 8v8l9 5 9-5V8"/>',
  }

  // ═══════════ 徽标 ═══════════
  /** 市场侧安装状态：未安装 / 可更新 / 已安装(最新) */
  function statusBadge(p) {
    if (!p.installed) return '<span class="badge">未安装</span>'
    if (p.hasUpdate) return '<span class="badge warn">可更新</span>'
    return '<span class="badge ok">已安装</span>'
  }

  /** 登记表来源：内置 / 市场 / 本地 */
  function sourceBadge(source) {
    if (source === 'builtin') return '<span class="badge" title="随发行包自带，不可卸载">内置</span>'
    if (source === 'market') return '<span class="badge ok" title="从市场安装">市场</span>'
    if (source === 'local') return '<span class="badge warn" title="本地目录安装（未上架）">本地</span>'
    return '<span class="badge">' + esc(source || '未知') + '</span>'
  }

  /** 派生属性徽标：含前端 / 含 DLL / 下发模式 */
  function attrBadges(p) {
    var out = ''
    if (p.hasClient) out += '<span class="badge">含前端</span>'
    if (p.dll && p.dll.length) {
      out += '<span class="badge">含 C# DLL</span>'
      var mode = p.deploy === 'ask' ? '安装时选服' : p.deploy === 'manual' ? '静默不下发' : '自动下发'
      out += '<span class="badge ' + (p.deploy === 'manual' ? 'warn' : '') + '">' + mode + '</span>'
    }
    return out
  }

  // ═══════════ 筛选 ═══════════
  function matchQuery(p, q) {
    if (!q) return true
    var hay = (p.name + ' ' + (p.description || '') + ' ' + (p.tags || []).join(' ')).toLowerCase()
    return hay.indexOf(q.toLowerCase()) >= 0
  }

  function visiblePlugins() {
    var q = state.query.trim()
    return state.plugins.filter(function (p) {
      if (state.tag && (p.tags || []).indexOf(state.tag) < 0) return false
      return matchQuery(p, q)
    })
  }

  /** 索引里出现过的全部标签（用于标签筛选条） */
  function allTags() {
    var seen = {}, out = []
    for (var i = 0; i < state.plugins.length; i++) {
      var t = state.plugins[i].tags || []
      for (var j = 0; j < t.length; j++) {
        if (!seen[t[j]]) { seen[t[j]] = true; out.push(t[j]) }
      }
    }
    return out
  }

  function favPlugins() {
    return state.plugins.filter(function (p) { return p.favorite })
  }

  /** 已安装栏：登记表全量，附上市场侧的可更新信息 */
  function installedRows() {
    var byName = {}
    for (var i = 0; i < state.plugins.length; i++) byName[state.plugins[i].name] = state.plugins[i]
    return state.installed.map(function (e) {
      var m = byName[e.name] || null
      var loaded = 0
      var sv = e.servers || {}
      for (var k in sv) if (sv[k] === 'loaded') loaded++
      return {
        name: e.name,
        version: e.version,
        source: e.source,
        enabled: e.enabled !== false,
        status: e.status,
        missing: e.missing === true,
        dlls: (e.dlls || []).length,
        serversTotal: Object.keys(sv).length,
        serversLoaded: loaded,
        inMarket: !!m,
        hasUpdate: !!(m && m.hasUpdate),
        marketVersion: m ? m.version : null,
        favorite: !!(m && m.favorite),
      }
    }).sort(function (a, b) {
      // 有更新的排最前，其次按名称
      if (a.hasUpdate !== b.hasUpdate) return a.hasUpdate ? -1 : 1
      return a.name.localeCompare(b.name)
    })
  }

  // ═══════════ 分页 ═══════════
  /**
   * 取某页数据，并把页码夹到合法范围后**回写**到调用方。
   *
   * 必须夹取而不能只做越界判断：取消收藏、卸载插件、刷新索引都会让总数变小，
   * 若停在已失效的页码上就会渲染出一片空白——看起来像"收藏/插件凭空消失了"，
   * 而这恰恰是最容易被误报成 bug 的表现。
   */
  function pageSlice(list, page) {
    var pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE))
    /**
     * 先把页码解析成有限整数再夹取。
     * 不能直接 Math.max(1, page)：Math.max(1, undefined) 是 NaN，Math.min(NaN, pages) 仍是 NaN，
     * 于是 slice(NaN, NaN) 得到空数组、cur 也是 NaN —— 而调用方会把 cur **回写**进 state，
     * 那一栏从此每次渲染都空白且永远写回 NaN，自我锁死、且看起来完全不像分页的问题。
     */
    var p = parseInt(page, 10)
    if (!isFinite(p)) p = 1
    var cur = Math.min(Math.max(1, p), pages)
    var start = (cur - 1) * PAGE_SIZE
    return { cur: cur, pages: pages, rows: list.slice(start, start + PAGE_SIZE) }
  }

  /**
   * 分页器 HTML。只有一页时返回空串：不留占位、也不显示无意义的"第 1/1 页"。
   * 页码按钮带 data-mpg（页码，或 prev/next）与 data-mpane（哪一栏），交给事件委托统一处理。
   */
  function pagerHtml(pane, cur, pages, total, unit) {
    if (pages <= 1) return ''
    // 数字窗口比账号列表窄一档（±1 而非 ±2）：侧栏本来就窄，按钮铺多了会换行折行
    var lo = Math.max(2, cur - 1)
    var hi = Math.min(pages - 1, cur + 1)
    function btn(pg, text, on, disabled) {
      return '<button class="pg-btn' + (on ? ' on' : '') + '" data-mpg="' + pg + '" data-mpane="' + pane + '"' +
        (disabled ? ' disabled' : '') + '>' + text + '</button>'
    }
    var html = '<div class="tswm-pager">'
    html += '<span class="pg-info">共 ' + total + ' ' + unit + ' · 第 ' + cur + '/' + pages + ' 页</span>'
    html += btn('prev', '上一页', false, cur <= 1)
    html += btn(1, '1', cur === 1, false)
    if (lo > 2) html += '<span class="pg-gap">…</span>'
    for (var i = lo; i <= hi; i++) html += btn(i, String(i), i === cur, false)
    if (hi < pages - 1) html += '<span class="pg-gap">…</span>'
    html += btn(pages, String(pages), cur === pages, false)
    html += btn('next', '下一页', false, cur >= pages)
    return html + '</div>'
  }

  // ═══════════ 样式（tswm- 前缀，避免与宿主及别的插件冲突）═══════════
  function injectStyle() {
    if (styleDone) return
    styleDone = true
    var st = document.createElement('style')
    st.textContent = [
      '.tswm-cols{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(0,1fr) minmax(0,1fr);gap:16px;align-items:start}',
      '@media (max-width:1180px){.tswm-cols{grid-template-columns:1fr}}',
      '.tswm-col{display:flex;flex-direction:column;gap:12px;min-width:0}',
      '.tswm-colhead{display:flex;align-items:center;gap:8px;font-size:14px;font-weight:600;margin:0}',
      '.tswm-colhead .count{font-weight:400;font-size:12px;color:var(--muted-foreground)}',
      '.tswm-card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius-md);padding:14px 16px;',
      'box-shadow:var(--shadow);display:flex;flex-direction:column;gap:10px;transition:box-shadow .15s var(--ease-out),border-color .15s var(--ease-out)}',
      '.tswm-card:hover{box-shadow:var(--shadow-lg);border-color:var(--accent)}',
      '.tswm-card.is-fav{border-color:var(--accent)}',
      '.tswm-head{display:flex;align-items:flex-start;gap:8px}',
      '.tswm-name{font-size:15px;font-weight:600;word-break:break-all}',
      '.tswm-ver{font-size:12px;color:var(--muted-foreground);font-family:ui-monospace,SFMono-Regular,Menlo,monospace}',
      '.tswm-star{margin-left:auto;background:none;border:none;padding:2px;cursor:pointer;color:var(--muted-foreground);line-height:0}',
      '.tswm-star:hover{color:var(--warn)}',
      '.tswm-star.on{color:var(--warn)}',
      '.tswm-desc{font-size:13px;line-height:1.65;color:var(--foreground);margin:0}',
      '.tswm-tags{display:flex;flex-wrap:wrap;gap:6px}',
      '.tswm-tag{font-size:12px;padding:2px 8px;border-radius:999px;background:var(--secondary);color:var(--secondary-foreground);',
      'border:1px solid var(--border);cursor:pointer;line-height:1.7}',
      '.tswm-tag:hover{background:var(--accent);color:var(--accent-foreground);border-color:var(--accent)}',
      '.tswm-tag.on{background:var(--accent);color:var(--accent-foreground);border-color:var(--accent)}',
      '.tswm-meta{display:flex;flex-wrap:wrap;gap:12px;font-size:12px;color:var(--muted-foreground)}',
      '.tswm-badges{display:flex;flex-wrap:wrap;gap:6px;align-items:center}',
      '.tswm-ops{display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding-top:2px}',
      '.tswm-row{display:flex;align-items:center;gap:8px;padding:9px 12px;border:1px solid var(--border);border-radius:var(--radius-sm);',
      'background:var(--card)}',
      '.tswm-row:hover{border-color:var(--accent)}',
      '.tswm-row .nm{font-size:13px;font-weight:600;word-break:break-all}',
      '.tswm-row .vr{font-size:12px;color:var(--muted-foreground);font-family:ui-monospace,SFMono-Regular,Menlo,monospace}',
      '.tswm-row .sp{flex:1;min-width:0}',
      '.tswm-empty{font-size:13px;color:var(--muted-foreground);line-height:1.7;padding:14px 16px;border:1px dashed var(--border);',
      'border-radius:var(--radius-md);margin:0}',
      // 侧栏分页器。info 用 width:100% 独占一行：侧栏窄，与按钮同行会被挤到折行
      '.tswm-pager{display:flex;align-items:center;justify-content:center;gap:6px;flex-wrap:wrap;padding:2px 0 0}',
      '.tswm-pager .pg-info{width:100%;text-align:center;font-size:12px;color:var(--muted-foreground);margin-bottom:2px}',
      '.tswm-pager .pg-btn{font-size:12px;padding:2px 8px;border:1px solid var(--border);border-radius:var(--radius-sm);',
      'background:var(--card);color:var(--foreground);cursor:pointer;line-height:1.7;font-family:inherit}',
      '.tswm-pager .pg-btn:hover:not(:disabled){border-color:var(--accent);background:var(--accent);color:var(--accent-foreground)}',
      '.tswm-pager .pg-btn:disabled{opacity:.45;cursor:default}',
      '.tswm-pager .pg-btn.on{background:var(--accent);color:var(--accent-foreground);border-color:var(--accent)}',
      '.tswm-pager .pg-gap{font-size:12px;color:var(--muted-foreground)}',
      '.tswm-toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:14px}',
      '.tswm-toolbar input{min-width:200px;flex:1;max-width:320px}',
      '.tswm-tagbar{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-bottom:14px}',
      '.tswm-tagbar .lb{font-size:12px;color:var(--muted-foreground);margin-right:2px}',
      '.tswm-help{font-size:13px;line-height:1.7;color:var(--muted-foreground);margin:6px 0 0}',
      // 刷新提示横幅。只用本文件里已出现过的 token（--accent/--secondary/--radius-md 等），不引入新变量。
      '.tswm-banner{display:flex;flex-wrap:wrap;gap:10px;align-items:center;padding:10px 14px;margin:0 0 12px;',
      'border:1px solid var(--accent);border-radius:var(--radius-md);background:var(--secondary);font-size:13px;line-height:1.6}',
      '.tswm-banner .sp{flex:1;min-width:0}',
      // 必须显式写：本样式表在宿主样式之后注入，同优先级下 .tswm-banner 的 display:flex 会盖掉宿主的 .hidden
      '.tswm-banner.hidden{display:none}',
    ].join('')
    document.head.appendChild(st)
  }

  // ═══════════ 渲染：外壳 ═══════════
  function renderShell(container) {
    container.innerHTML = '' +
      '<div class="tswm-toolbar">' +
      '  <h2 style="margin:0">插件市场</h2>' +
      '  <input id="tswm-search" type="search" placeholder="搜索名称 / 介绍 / 标签" value="' + esc(state.query) + '">' +
      '  <span id="tswm-src" class="badge"></span>' +
      '  <button id="tswm-refresh" class="ghost sm" data-mact="refresh">' + svg(ICON.refresh) + ' 刷新索引</button>' +
      '</div>' +
      '<p id="tswm-msg" class="muted" style="min-height:18px;margin:0 0 12px"></p>' +
      '<div id="tswm-banner" class="tswm-banner hidden"></div>' +
      '<div id="tswm-tagbar" class="tswm-tagbar"></div>' +
      '<div class="tswm-cols">' +
      '  <div class="tswm-col">' +
      '    <div class="tswm-colhead">' + svg(ICON.box) + ' 插件列表 <span class="count" id="tswm-listcount"></span></div>' +
      '    <div id="tswm-list" class="tswm-col"></div>' +
      '  </div>' +
      '  <div class="tswm-col">' +
      '    <div class="tswm-colhead">' + svg(ICON.star) + ' 收藏 <span class="count" id="tswm-favcount"></span></div>' +
      '    <div id="tswm-fav" class="tswm-col"></div>' +
      '  </div>' +
      '  <div class="tswm-col">' +
      '    <div class="tswm-colhead">' + svg(ICON.plug) + ' 已安装 <span class="count" id="tswm-instcount"></span></div>' +
      '    <div id="tswm-installed" class="tswm-col"></div>' +
      '  </div>' +
      '</div>' +
      '<div class="panel" style="margin-top:16px">' +
      '  <h3>说明</h3>' +
      '  <p class="tswm-help">' +
      '    安装会从市场仓库下载对应 tgz 发行包，校验 sha256 后解到运行时插件目录并立即加载；' +
      '    内含 C# DLL 的插件会按「下发模式」处理：自动下发=下发到所有启用中的服务器，安装时选服=弹窗勾选，静默不下发=只装后端半。<br>' +
      '    徽标含义：内置=随发行包自带（不可卸载）；市场=从市场安装；本地=本地目录安装（未上架）。' +
      '    本地未上架的插件包可放入发行目录的 incoming/ 后用终端命令 plugin-install &lt;name&gt; 安装。' +
      '  </p>' +
      '</div>'
  }

  // ═══════════ 渲染：插件列表 ═══════════
  function opsHtml(p) {
    if (!p.installed) {
      return '<button class="primary sm" data-mact="install" data-mname="' + esc(p.name) + '">' + svg(ICON.download) + ' 安装</button>'
    }
    var html = ''
    if (p.hasUpdate) {
      html += '<button class="primary sm" data-mact="update" data-mname="' + esc(p.name) + '">' + svg(ICON.refresh) + ' 更新到 v' + esc(p.version) + '</button>'
    }
    // 市场自身不可卸载（后端 registry 也会拒绝），因此不给按钮，只留一句说明
    if (p.self) {
      html += '<span class="muted" style="font-size:12px">市场插件不可卸载</span>'
      return html
    }
    html += '<button class="danger sm" data-mact="uninstall" data-mname="' + esc(p.name) + '">' + svg(ICON.trash) + ' 卸载</button>'
    return html
  }

  function cardHtml(p) {
    var tags = (p.tags || []).map(function (t) {
      return '<span class="tswm-tag' + (state.tag === t ? ' on' : '') + '" data-mtag="' + esc(t) + '">' + esc(t) + '</span>'
    }).join('')

    var meta = []
    if (p.size) meta.push('体积 ' + human(p.size))
    if (p.publishedAt) meta.push('发布 ' + shortDate(p.publishedAt))
    if (p.author) meta.push('作者 ' + esc(p.author))
    if (p.installedVersion) meta.push('本地 v' + esc(p.installedVersion))

    return '' +
      '<div class="tswm-card' + (p.favorite ? ' is-fav' : '') + '" data-mgroup="' + esc(p.name) + '">' +
      '  <div class="tswm-head">' +
      '    <div style="min-width:0">' +
      '      <div class="tswm-name">' + esc(p.name) + '</div>' +
      '      <div class="tswm-ver">v' + esc(p.version) + '</div>' +
      '    </div>' +
      '    <button class="tswm-star' + (p.favorite ? ' on' : '') + '" data-mact="favorite" data-mname="' + esc(p.name) + '" ' +
      'title="' + (p.favorite ? '取消收藏' : '收藏') + '">' + svg(ICON.star, 16) + '</button>' +
      '  </div>' +
      (p.description ? '  <p class="tswm-desc">' + esc(p.description) + '</p>' : '') +
      (tags ? '  <div class="tswm-tags">' + tags + '</div>' : '') +
      '  <div class="tswm-badges">' + (p.self ? '<span class="badge">市场自身</span>' : '') + statusBadge(p) + attrBadges(p) + '</div>' +
      (meta.length ? '  <div class="tswm-meta">' + meta.map(function (m) { return '<span>' + m + '</span>' }).join('') + '</div>' : '') +
      '  <div class="tswm-ops">' + opsHtml(p) + '</div>' +
      '</div>'
  }

  function renderList() {
    var el = $('tswm-list')
    if (!el) return
    var list = visiblePlugins()
    var c = $('tswm-listcount')
    if (c) {
      var total = state.plugins.length
      c.textContent = list.length === total ? ('共 ' + total + ' 个') : (list.length + ' / ' + total + ' 个')
    }
    if (!list.length) {
      el.innerHTML = '<p class="tswm-empty">' +
        (state.plugins.length ? '没有匹配的插件，试试换个关键字或清掉标签筛选。'
          : '市场索引里还没有插件。点右上角「刷新索引」重新拉取。') + '</p>'
      return
    }
    el.innerHTML = list.map(cardHtml).join('')
  }

  // ═══════════ 渲染：收藏 ═══════════
  function renderFav() {
    var el = $('tswm-fav')
    if (!el) return
    var list = favPlugins()
    var c = $('tswm-favcount')
    if (c) c.textContent = list.length ? (list.length + ' 个') : ''
    if (!list.length) {
      el.innerHTML = '<p class="tswm-empty">还没有收藏。点插件卡片右上角的星标即可收藏，收藏会存在服务端。</p>'
      return
    }
    var pg = pageSlice(list, state.favPage)
    state.favPage = pg.cur
    el.innerHTML = pg.rows.map(function (p) {
      var act = !p.installed
        ? '<button class="primary sm" data-mact="install" data-mname="' + esc(p.name) + '">安装</button>'
        : (p.hasUpdate
          ? '<button class="primary sm" data-mact="update" data-mname="' + esc(p.name) + '">更新</button>'
          : '')
      return '<div class="tswm-row">' +
        '<div class="sp"><div class="nm">' + esc(p.name) + '</div>' +
        '<div class="vr">v' + esc(p.version) + '</div></div>' +
        statusBadge(p) +
        act +
        '<button class="tswm-star on" data-mact="favorite" data-mname="' + esc(p.name) + '" title="取消收藏">' + svg(ICON.star, 14) + '</button>' +
        '</div>'
    }).join('') + pagerHtml('fav', pg.cur, pg.pages, list.length, '个')
  }

  // ═══════════ 渲染：已安装 ═══════════
  function renderInstalled() {
    var el = $('tswm-installed')
    if (!el) return
    var rows = installedRows()
    var c = $('tswm-instcount')
    if (c) c.textContent = rows.length ? (rows.length + ' 个') : ''
    if (!rows.length) {
      el.innerHTML = '<p class="tswm-empty">登记表里还没有插件。</p>'
      return
    }
    var pg = pageSlice(rows, state.instPage)
    state.instPage = pg.cur
    el.innerHTML = pg.rows.map(function (r) {
      var badges = sourceBadge(r.source)
      badges += r.enabled ? '<span class="badge ok">已启用</span>' : '<span class="badge warn">已停用</span>'
      if (r.missing) badges += '<span class="badge danger" title="登记表里有，但插件目录不存在">目录缺失</span>'
      if (r.hasUpdate) badges += '<span class="badge warn">可更新到 v' + esc(r.marketVersion) + '</span>'

      var info = []
      if (r.dlls) info.push(r.dlls + ' 个 DLL')
      if (r.serversTotal) info.push('已下发 ' + r.serversLoaded + '/' + r.serversTotal + ' 台')

      return '<div class="tswm-row">' +
        '<div class="sp"><div class="nm">' + esc(r.name) + '</div>' +
        '<div class="vr">v' + esc(r.version) + (info.length ? ' · ' + info.join(' · ') : '') + '</div></div>' +
        '<div class="tswm-badges">' + badges + '</div>' +
        '</div>'
    }).join('') + pagerHtml('inst', pg.cur, pg.pages, rows.length, '个')
  }

  function renderTagbar() {
    var el = $('tswm-tagbar')
    if (!el) return
    var tags = allTags()
    if (!tags.length) { el.innerHTML = ''; return }
    var html = '<span class="lb">标签</span>'
    if (state.tag) html += '<span class="tswm-tag on" data-mtag="">全部</span>'
    html += tags.map(function (t) {
      return '<span class="tswm-tag' + (state.tag === t ? ' on' : '') + '" data-mtag="' + esc(t) + '">' + esc(t) + '</span>'
    }).join('')
    el.innerHTML = html
  }

  function renderAll() {
    renderTagbar()
    renderList()
    renderFav()
    renderInstalled()
  }

  function setMsg(text, cls) {
    var el = $('tswm-msg')
    if (!el) return
    el.className = cls || 'muted'
    el.textContent = text || ''
  }

  /**
   * 刷新提示横幅。
   *
   * 与 setMsg 的区别：**不会被后续的加载/失败提示覆盖**，并且自带一个刷新按钮。
   * 用在"服务端已生效、但浏览器还跑着页面加载时的旧 bundle"这一种情况上
   * —— plugin 更新的前端半、以及市场自更新都属于这种。
   */
  function showRefreshBanner(text) {
    var el = $('tswm-banner')
    if (!el) return
    el.innerHTML = '<span class="sp">' + esc(text) + '</span>' +
      '<button class="primary sm" data-mact="reload">' + svg(ICON.refresh) + ' 刷新页面</button>'
    el.classList.remove('hidden')
  }

  function setBusy(on, label) {
    state.busy = on
    var btns = root ? root.querySelectorAll('button[data-mact]') : []
    for (var i = 0; i < btns.length; i++) btns[i].disabled = on
    if (on && label) setMsg(label + ' ...', 'muted')
  }

  // ═══════════ 数据加载 ═══════════
  async function load(force) {
    setMsg(force ? '正在重新拉取市场索引 ...' : '正在加载 ...', 'muted')
    var res = await api('/api/market/list' + (force ? '?force=1' : ''))
    if (!res.ok || !res.data) {
      setMsg('获取市场索引失败：' + ((res.data && res.data.error) || ('HTTP ' + res.status)), 'error')
      state.plugins = []
      renderAll()
      return
    }
    state.plugins = res.data.plugins || []
    var src = $('tswm-src')
    if (src) {
      src.textContent = lastMirror ? ('索引来源 ' + lastMirror) : (state.plugins.length + ' 个插件')
      src.className = lastMirror ? 'badge ok' : 'badge'
    }
    setMsg('')
    await loadInstalled()
  }

  /** 登记表全量（已安装栏用；含市场外的自带/本地插件） */
  async function loadInstalled() {
    try {
      var res = await api('/api/plugins')
      state.installed = (res && res.ok && res.data && res.data.plugins) || []
    } catch (err) {
      state.installed = []
    }
    renderAll()
  }

  // ═══════════ 收藏 ═══════════
  async function toggleFav(name) {
    if (state.busy) return
    var cur = null
    for (var i = 0; i < state.plugins.length; i++) if (state.plugins[i].name === name) cur = state.plugins[i]
    if (!cur) return
    var next = !cur.favorite
    // 乐观更新：立刻反映到界面，失败再回滚
    cur.favorite = next
    renderAll()
    var res = await api('/api/market/favorite', { method: 'POST', json: { name: name, favorite: next } })
    if (!res.ok || !res.data || res.data.success === false) {
      cur.favorite = !next
      setMsg('收藏失败：' + ((res.data && res.data.error) || ('HTTP ' + res.status)), 'error')
      renderAll()
      return
    }
    setMsg(next ? ('已收藏 ' + name) : ('已取消收藏 ' + name), 'ok')
  }

  // ═══════════ 安装 / 更新 / 卸载 ═══════════
  async function doAction(act, name) {
    if (state.busy) return
    var label = act === 'install' ? '安装' : act === 'update' ? '更新' : '卸载'
    // 从当前列表取该插件的元数据（下发模式等）
    var meta = null
    for (var i = 0; i < state.plugins.length; i++) {
      if (state.plugins[i].name === name) { meta = state.plugins[i]; break }
    }
    var hasDll = !!(meta && meta.dll && meta.dll.length)
    var mode = meta && meta.deploy ? meta.deploy : 'all'

    // ask 模式：弹窗让用户勾选目标服务器（仅含 DLL 的插件才有意义）
    if ((act === 'install' || act === 'update') && hasDll && mode === 'ask') {
      var picked = await pickServers(name, label, mode)
      if (picked === null) return // 用户取消
      return doDeployAction(act, name, label, picked === true ? null : picked)
    }
    return doDeployAction(act, name, label, null)
  }

  /** 真正发起请求（serverIds=null 表示不指定 → 后端按模式决策；数组则显式下发） */
  async function doDeployAction(act, name, label, serverIds) {
    setBusy(true, '正在' + label + ' ' + name)
    var selfUpdated = false
    try {
      var res
      var body = { name: name }
      if (serverIds) body.serverIds = serverIds
      if (act === 'refresh') {
        res = await api('/api/market/refresh', { method: 'POST', json: {} })
      } else {
        res = await api('/api/market/' + act, { method: 'POST', json: body })
      }
      if (!res.ok || !res.data || res.data.success === false) {
        var err = (res.data && res.data.error) || ('HTTP ' + res.status)
        setMsg(label + '失败：' + err, 'error')
      } else {
        var d = res.data
        if (d.self) {
          /**
           * 自更新：响应是**在替换之前**发出的（后端随后才热重载自己），
           * 所以这里拿到 success 就表示替换已排队，且服务端半马上生效。
           */
          selfUpdated = true
          setMsg('市场已更新：' + d.from + ' -> ' + d.to + '（服务端已生效）', 'ok')
          showRefreshBanner('市场插件已更新到 v' + d.to + '，服务端半已生效。' +
            '当前页面仍是更新前加载的旧界面，刷新后才会加载新界面。')
          // 本地同步状态，避免"已更新却仍显示可更新按钮"（再点会得到"已是最新"）
          for (var k = 0; k < state.plugins.length; k++) {
            if (state.plugins[k].name === name) {
              state.plugins[k].hasUpdate = false
              state.plugins[k].installedVersion = d.to
              state.plugins[k].installed = true
            }
          }
          renderAll()
        } else if (act === 'install' || act === 'update') {
          var suffix = ''
          if (d.deployMode === 'manual') {
            suffix = act === 'update'
              ? '（更新会把新 DLL 自动重推给原先已下发过的在线服务器；本次无可重推目标，可在「插件下发」页手动部署）'
              : '（插件声明静默下发，可在「插件下发」页手动部署）'
          } else if (d.deploySkipped) suffix = '（未选择服务器，跳过下发；可在「插件下发」页手动部署）'
          var verb = act === 'install' ? '已安装' : '已更新'
          setMsg(verb + ' ' + d.name + (act === 'update' ? '：' + d.from + ' -> ' + d.to : '@' + d.version)
            + '，DLL 下发 ' + ((d.deployed || []).length) + ' 台' + suffix, 'ok')
          // 有前端半的插件：服务端已生效，但页面仍是旧 bundle
          if (d.refreshRequired) {
            showRefreshBanner('插件 ' + d.name + ' 的前端半已更新（服务端已生效），刷新页面后新界面才会加载。')
          }
        } else if (act === 'uninstall') {
          setMsg('已卸载 ' + d.name + '，数据保留；从 ' + ((d.undeployed || []).length) + ' 台服务器撤下 DLL', 'ok')
        } else {
          lastMirror = d.mirror || ''
          setMsg('索引已刷新：' + d.count + ' 个插件（来源 ' + d.mirror + '）', 'ok')
        }
      }
    } catch (err) {
      setMsg(label + '异常：' + (err.message || err), 'error')
    } finally {
      setBusy(false)
      /**
       * 自更新后**不再拉取列表**：此刻后端正在热重载自己（disable → 换目录 → enable），
       * 这一拉多半失败，load() 会把"获取市场索引失败"写进消息区，把刚发出的成功提示盖掉
       * —— 于是"更新其实成功了，界面却报失败"。
       */
      if (!selfUpdated) await load(act === 'refresh')
    }
  }

  /**
   * ask 模式的服务器选择弹窗。
   * 返回：true=用户选择"全部"；string[]=勾选的服务器 id 列表；null=用户取消。
   * 拉 /api/servers 获取已登记服务器，默认勾选 enabled 的。
   */
  async function pickServers(name, label, mode) {
    var sres = await api('/api/servers')
    var servers = (sres.ok && sres.data && sres.data.servers) || []
    if (!servers.length) {
      // 无服务器：提示后直接继续（等价于"不指定"→ 后端 ask 模式跳过下发）
      return true
    }
    var checked = {}
    for (var i = 0; i < servers.length; i++) {
      if (servers[i].enabled !== false) checked[servers[i].id] = true
    }
    var rows = servers.map(function (s) {
      return '<label class="pick-row" style="display:flex;align-items:center;gap:8px;padding:6px 2px;border-bottom:1px solid var(--border);font-size:13px;cursor:pointer">' +
        '<input type="checkbox" data-sid="' + esc(s.id) + '"' +
        (checked[s.id] ? ' checked' : '') + '>' +
        '<span style="flex:1">' + esc(s.name) + '</span>' +
        '<span class="muted">' + esc(s.host) + ':' + esc(s.port) + '</span>' +
        (s.connected ? '<span class="badge ok">在线</span>' : '<span class="badge warn">未连接</span>') +
        '</label>'
    }).join('')
    var title = label + ' ' + name + '：选择下发服务器'
    var hint = '<p class="muted" style="font-size:12px;margin:0 0 8px">该插件声明「安装时选择下发目标」。勾选要下发 DLL 的服务器；不勾选任何服务器则只装后端半，可稍后在「插件下发」页手动部署。</p>'

    return new Promise(function (resolve) {
      var modal = document.createElement('div')
      modal.className = 'modal-mask'
      modal.innerHTML =
        '<div class="modal" style="max-width:520px">' +
        '  <h3>' + esc(title) + '</h3>' +
        hint +
        '  <div style="max-height:280px;overflow:auto;border:1px solid var(--border);border-radius:8px;padding:8px 12px">' +
        rows +
        '  </div>' +
        '  <div class="row-actions">' +
        '    <button data-pk="cancel" class="ghost sm">取消</button>' +
        '    <button data-pk="none" class="ghost sm">不下发</button>' +
        '    <button data-pk="ok" class="primary sm">确定下发</button>' +
        '  </div>' +
        '</div>'
      document.body.appendChild(modal)
      function done(val) {
        document.body.removeChild(modal)
        resolve(val)
      }
      modal.addEventListener('click', function (ev) {
        var t = ev.target
        if (!t || !t.getAttribute || !t.getAttribute('data-pk')) return
        if (t.getAttribute('data-pk') === 'cancel') return done(null)
        if (t.getAttribute('data-pk') === 'none') return done([])
        var boxes = modal.querySelectorAll('input[data-sid]:checked')
        var ids = []
        for (var i = 0; i < boxes.length; i++) ids.push(boxes[i].getAttribute('data-sid'))
        return done(ids)
      })
    })
  }

  // ═══════════ 视图注册 ═══════════
  tsw.registerView({
    id: 'market',
    title: '插件市场',
    section: '后端设置',
    path: '/b/market',
    icon: 'box',
    render: function (container) {
      root = container
      injectStyle()
      renderShell(container)

      /**
       * 事件委托：**每次都先按同一引用解绑、再绑**（而不是用标记"只绑一次"）。
       *
       * 两个约束必须同时满足：
       *  - 宿主的 route() 每次进入本路由都调 render(container)，而 container 是常驻元素
       *    #plugin-view-content：无条件下 addEventListener 会让监听器随访问次数累加，
       *    一次点击被执行 N 次（卸载连弹 N 个确认框、收藏发 N 个互相抵消的请求）。
       *  - 但也不能只靠"绑过一次"的标记：处理器属于**首次渲染那个模块实例**的闭包，
       *    而 loader 热重载插件时会用新的 cache-busting query 重新 import；新实例若因标记
       *    仍在而跳过绑定，点击会继续由旧 bundle 的闭包与 state 处理（界面静默跑旧 JS）。
       * 处理器引用存在容器上、按引用解绑，则任一时刻恰好一个监听器，且总是当前实例的。
       */
      if (container.__tswmClick) container.removeEventListener('click', container.__tswmClick)
      if (container.__tswmInput) container.removeEventListener('input', container.__tswmInput)

      container.__tswmClick = function (ev) {
        var t = ev.target
        if (!t || !t.closest) return

        /**
         * #plugin-view-content 是**所有插件视图共享**的容器，而本监听器一旦挂上就不会
         * 随视图切换消失：别的插件视图占着这个容器时，点它会落到这里（早期版本读
         * target 自己的 data-mact，同样会串扰；closest 只是把匹配面略微放大）。
         * 只在本市场视图确实渲染在容器里时（外壳带 .tswm-toolbar）才处理。
         */
        if (!container.querySelector('.tswm-toolbar')) return

        // 标签筛选（标签可在筛选条和卡片上点）
        var tagEl = t.closest('.tswm-tag[data-mtag]')
        if (tagEl && container.contains(tagEl)) {
          var tagVal = tagEl.getAttribute('data-mtag')
          state.tag = state.tag === tagVal ? '' : tagVal
          renderAll()
          return
        }

        // 侧栏分页（收藏 / 已安装各自独立翻页）。
        // 必须放在 data-mact 查找之前：分页按钮不带 data-mact，落到下面会被直接
        // `if (!btn) return` 吞掉，表现为"点页码完全没反应"。
        var pgBtn = t.closest('[data-mpg]')
        if (pgBtn && container.contains(pgBtn)) {
          if (pgBtn.disabled) return
          var pane = pgBtn.getAttribute('data-mpane') === 'fav' ? 'fav' : 'inst'
          // 页码按"当前列表"重算，而不是信任按钮上的数字：
          // 列表可能在两次渲染之间变短（取消收藏 / 卸载 / 刷新索引），夹取后才是合法目标
          var view = pane === 'fav'
            ? pageSlice(favPlugins(), state.favPage)
            : pageSlice(installedRows(), state.instPage)
          var want = pgBtn.getAttribute('data-mpg')
          if (want === 'prev') want = view.cur - 1
          else if (want === 'next') want = view.cur + 1
          want = parseInt(want, 10)
          if (!(want >= 1) || want > view.pages || want === view.cur) return
          if (pane === 'fav') { state.favPage = want; renderFav() } else { state.instPage = want; renderInstalled() }
          return
        }

        /**
         * 必须向上找最近的带 data-mact 的元素，不能直接读 ev.target：
         * 按钮内容多数是 svg 图标，点击落在 <svg>/<path> 上时 ev.target 自己没有
         * data-mact，直接读会让"点图标"完全无响应——星标按钮只有图标，等于收藏点不动。
         */
        var btn = t.closest('[data-mact]')
        if (!btn || !container.contains(btn)) return
        var act = btn.getAttribute('data-mact')
        if (!act) return
        // 刷新横幅上的按钮：直接重载页面（此时服务端已生效，需要重新加载前端 bundle）
        if (act === 'reload') { location.reload(); return }
        if (act === 'refresh') return doAction('refresh')
        var name = btn.getAttribute('data-mname')
        if (!name) return
        if (act === 'favorite') return toggleFav(name)
        if (act === 'uninstall') {
          if (!window.confirm('确定卸载插件 ' + name + '？\n数据会保留，但会先从服务器撤下其 DLL。')) return
        }
        doAction(act, name)
      }
      container.addEventListener('click', container.__tswmClick)

      container.__tswmInput = function (ev) {
        var t = ev.target
        if (!t || t.id !== 'tswm-search') return
        state.query = t.value || ''
        renderList()
      }
      container.addEventListener('input', container.__tswmInput)

      load(false)
    },
  })

  console.log('[tsweb] 市场客户端插件已注册: #/b/market')
})()
