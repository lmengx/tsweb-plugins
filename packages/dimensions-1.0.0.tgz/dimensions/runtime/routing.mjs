// Global defaults are ordered. Thresholds affect initial routing only, never admission.
export class EntryRouter {
  scores = new Map()
  snapshots = new Map()
  update(rows) {
    for (const row of rows) {
      if (!Number.isSafeInteger(row.online) || row.online < 0 || !Array.isArray(row.sessions)) continue
      this.snapshots.set(row.id, { online: row.online, sessions: new Set(row.sessions), at: Number.isSafeInteger(row.checkedAt) ? Math.min(Date.now(), row.checkedAt) : Date.now() })
    }
  }
  count(row, clients) {
    const snapshot = this.snapshots.get(row.id)
    // Managed reservations remain until a snapshot reports that exact session.
    const reservations = [...clients.values()].filter(c => !c.socket.destroyed && (c.tswebManaged?.targetId ? c.tswebManaged.targetId === row.id : c.server.name === row.command) && !snapshot?.sessions.has(c.ID)).length
    return (snapshot?.online ?? 0) + reservations
  }
  choose(config, clients, excluded = new Set()) {
    const rows = config.targets.filter(t => t.enabled && t.entry && !excluded.has(t.id) && (!config.requirePopulation || Date.now() - (this.snapshots.get(t.id)?.at ?? 0) < 15000))
    if (!rows.length) return null
    if (config.routingMode !== 'weight') {
      const free = rows.find(row => this.count(row, clients) < (row.distributionValue ?? 10))
      if (free) return free
    }
    // Smooth weighted round robin avoids random streaks and is stable under retries.
    let winner = rows[0], total = 0
    for (const row of rows) {
      const weight = row.distributionValue ?? 10
      total += weight; this.scores.set(row.id, (this.scores.get(row.id) ?? 0) + weight)
      if (this.scores.get(row.id) > this.scores.get(winner.id)) winner = row
    }
    this.scores.set(winner.id, this.scores.get(winner.id) - total)
    for (const id of this.scores.keys()) if (!rows.some(row => row.id === id)) this.scores.delete(id)
    return winner
  }
}
