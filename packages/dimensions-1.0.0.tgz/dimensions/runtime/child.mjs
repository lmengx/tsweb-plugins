import { Runtime } from './engine.mjs'
import { createRequire } from 'node:module'
import { resolve } from 'node:path'
import { readFileSync } from 'node:fs'
import { safeLog } from '../logs.js'
let consoleHelper = null
const consoleState = { requested: process.platform === 'win32' && process.env.TSWEB_DIMENSIONS_CONSOLE === '1', visible: false, error: '' }
if (process.platform === 'win32' && process.env.TSWEB_DIMENSIONS_CONSOLE === '1') {
  try {
    const helperPath = process.env.TSWEB_DIMENSIONS_CONSOLE_HELPER || readFileSync(resolve('tmp/dimensions-console-path.txt'), 'utf8').trim()
    consoleHelper = createRequire(import.meta.url)(helperPath)
    if (typeof consoleHelper.writeConsole !== 'function') throw new Error('控制台辅助模块版本过旧，请重新构建')
    consoleHelper.openConsole(); process.title = 'TSWeb Dimensions Proxy'; consoleState.visible = true
  }
  catch { consoleHelper = null; consoleState.error = '可见控制台创建失败，请检查并重新构建本机辅助模块；网页控制台仍可查看日志' }
}
let eventCount = 0
const send = message => {
  if (!process.connected) return
  const event = message.kind === 'event' || message.kind === 'log'
  if (event && eventCount >= 64) return
  if (event) eventCount++
  process.send(message, () => { if (event) eventCount-- })
}
const log = (level, message) => {
  const text = safeLog(message)
  send({ kind: 'log', level, message: text })
  if (consoleHelper) {
    try { consoleHelper.writeConsole(`[${new Date().toLocaleTimeString()}] [${level.toUpperCase()}] ${text}\r\n`) }
    catch { consoleHelper = null; consoleState.visible = false; consoleState.error = '本机窗口写入失败，日志已继续发送至网页控制台'; send({ kind: 'log', level: 'warn', message: consoleState.error }) }
  }
}
const telemetry = () => ({ uptimeMs: Math.round(process.uptime() * 1000), rssBytes: process.memoryUsage().rss, heapUsedBytes: process.memoryUsage().heapUsed, heartbeatAt: Date.now(), console: consoleState })
log('info', `维度代理已启动 · PID ${process.pid} · Node ${process.versions.node} · IPC 托管`)
log(consoleState.error ? 'warn' : 'info', consoleState.error || (consoleState.visible ? '本机窗口与网页控制台日志同步已启用' : '网页控制台日志已启用'))
let protocolWarnings = 0, lastProtocolLog = 0
const runtime = new Runtime(event => {
  send({ kind: 'event', event })
  if (event.type === 'protocol.error') {
    protocolWarnings++
    if (Date.now() - lastProtocolLog >= 10000) { log('warn', `协议兼容消息被跳过（本时段 ${protocolWarnings} 条；不输出原始报文）`); lastProtocolLog = Date.now(); protocolWarnings = 0 }
  } else if (event.type.startsWith('captcha.route.')) {
    const stages = { connecting: '连接默认世界', slot: '子服已分配玩家位置', inventory: '客户端已提交角色数据', tiles_requested: '客户端已请求图格', world: '子服已返回世界信息', spawn_requested: '子服已发送出生请求', spawn_confirmed: '客户端已确认出生', password: '子服要求密码验证', chat_waiting: '握手期间的聊天已隔离', rejected: '子服拒绝本次连接', ready: '默认世界握手完成' }
    const title = stages[event.type.slice('captcha.route.'.length)]
    if (title) log('info', `验证码接入 · ${title} · 连接 ${event.sessionId ?? '-'} · 子服 ${event.targetId ?? '-'}`)
  } else if (['joined', 'left', 'switching', 'fallback', 'spawn.unconfirmed'].includes(event.type)) {
    const titles = { joined: '玩家接入', left: '玩家离开', switching: '开始切服', fallback: '转往备用大厅', 'spawn.unconfirmed': '客户端出生尚未确认' }
    log(event.type === 'fallback' ? 'warn' : 'info', `${titles[event.type]} · 连接 ${event.sessionId ?? '-'} · 子服 ${event.targetId ?? '-'}`)
  }
})
let queue = Promise.resolve(), stopping = false
const pulse = setInterval(() => {
  send({ kind: 'telemetry', runtime: telemetry() })
  log('info', `运行心跳 · PID ${process.pid} · 在线 ${runtime.clients.size} · 内存 ${(process.memoryUsage().rss / 1048576).toFixed(1)} MB · 已运行 ${Math.floor(process.uptime())} 秒`)
}, 15000)
pulse.unref()
async function stop() {
  if (stopping) return
  stopping = true
  clearInterval(pulse); log('info', '正在停止维度代理，释放玩家连接和监听端口')
  const force = setTimeout(() => process.exit(1), 2500); force.unref()
  await runtime.close()
  clearTimeout(force)
}
process.on('message', request => {
  if (request?.kind !== 'request' || typeof request.id !== 'string') return
  const execute = async () => {
    try {
      if (stopping) throw new Error('代理正在停止')
      let result
      switch (request.method) {
        case 'ping': result = { protocol: 1, runtime: telemetry() }; break
        case 'configure':
          result = await runtime.configure(request.data)
          log('info', `入口已监听 ${request.data.listenHost}:${request.data.listenPort} · 配置版本 ${request.data.revision} · 子服 ${request.data.targets.filter(t => t.enabled).length} 个`)
          break
        case 'sessions': result = runtime.sessions(); break
        case 'population': result = runtime.population(request.data); break
        case 'switch': result = await runtime.switch(request.data.sessionId, request.data.targetId); break
        case 'kick': result = runtime.kick(request.data.sessionId); break
        case 'stop': await stop(); send({ kind: 'response', id: request.id, ok: true, result: {} }); process.disconnect(); process.exit(0); return
        default: throw new Error('未知代理操作')
      }
      send({ kind: 'response', id: request.id, ok: true, result })
    } catch (err) { log('error', `操作 ${request.method} 失败：${err.message}`); send({ kind: 'response', id: request.id, ok: false, error: err.message }) }
  }
  // A pending player switch must not block shutdown, inventory reads or another player's request.
  if (request.method === 'configure') { queue = queue.then(execute, execute) } else execute()
})
process.on('disconnect', () => stop().finally(() => process.exit(0)))
for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => stop().finally(() => process.exit(0)))
process.on('uncaughtException', error => { log('error', `未处理异常：${error?.name || 'Error'}`); stop().finally(() => process.exit(1)) })
process.on('unhandledRejection', () => { log('error', '未处理的异步异常，正在退出并等待托管恢复'); stop().finally(() => process.exit(1)) })
