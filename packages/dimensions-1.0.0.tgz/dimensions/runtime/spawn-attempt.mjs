// Packet12 has no transaction ID. After superseding an unresolved spawn, a late
// packet cannot safely confirm any subsequent attempt on the same connection.
// Proxy-generated packets must never enter observeClient().
export class SpawnAttempt {
  constructor(id, targetId, now = Date.now(), confirmationAmbiguous = false) {
    this.id = id; this.targetId = targetId; this.startedAt = now
    this.worldDataSeen = false; this.tileSections = 0; this.playerSpawnSelfSeen = false
    this.c2sSpawnConfirmed = false; this.result = 'connecting'; this.switchMs = null
    this.confirmationAmbiguous = confirmationAmbiguous
  }
  observeServer(type) {
    if (!['connecting', 'original_spawn_unconfirmed'].includes(this.result) || this.expired) return
    if (type === 7) this.worldDataSeen = true
    if (type === 10) this.tileSections++
    if (type === 49) { this.playerSpawnSelfSeen = true; this.result = 'original_spawn_unconfirmed' }
  }
  observeClient(spawn, playerId, now = Date.now()) {
    if (this.confirmationAmbiguous || this.expired || this.result === 'completed' || !this.worldDataSeen || this.tileSections < 1 || !this.playerSpawnSelfSeen || spawn?.playerId !== playerId || spawn.context !== 'SpawningIntoWorld') return false
    // (-1,-1) is a valid vanilla sentinel and is deliberately accepted.
    this.c2sSpawnConfirmed = true; this.result = 'completed'; this.switchMs = now - this.startedAt
    return true
  }
  finish(result) { if (this.result === 'completed' || this.expired) return; this.result = result; this.expired = true; this.switchMs = Date.now() - this.startedAt }
  snapshot() {
    return { id: this.id, targetId: this.targetId, startedAt: this.startedAt, mapReady: this.worldDataSeen && this.tileSections > 0, tileSections: this.tileSections, playerSpawnSelfSeen: this.playerSpawnSelfSeen, c2sSpawnConfirmed: this.c2sSpawnConfirmed, confirmationAmbiguous: this.confirmationAmbiguous, result: this.result, switchMs: this.switchMs }
  }
}
