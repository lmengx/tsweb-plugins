import net from 'node:net'
import { createHmac, randomBytes } from 'node:crypto'
import { fail } from './config.js'
const sign = (key, value) => createHmac('sha256', key).update(value).digest('hex')
function frame(type, value, subtype) {
  const text = Buffer.from(value), length = []; let n = text.length
  do { length.push((n & 127) | (n > 127 ? 128 : 0)); n >>>= 7 } while (n)
  const head = Buffer.alloc(subtype === undefined ? 3 : 5); head[2] = type
  if (subtype !== undefined) head.writeInt16LE(subtype, 3)
  const packet = Buffer.concat([head, Buffer.from(length), text]); packet.writeUInt16LE(packet.length); return packet
}
function textOf(packet, offset) {
  let n = 0, shift = 0, byte
  do { if (offset >= packet.length || shift > 28) throw fail(502, '游戏握手报文无效'); byte = packet[offset++]; n |= (byte & 127) << shift; shift += 7 } while (byte & 128)
  if (n < 0 || n !== packet.length - offset) throw fail(502, '游戏握手长度无效')
  return packet.toString('utf8', offset)
}
export function probeBridge(row, key, { version, password = '', timeoutMs = 8000 } = {}) {
  if (!/^Terraria\d{2,6}$/.test(version)) return Promise.reject(fail(502, '配套 DLL 未报告游戏版本，请更新 DLL'))
  return new Promise((resolve, reject) => {
    const socket = net.connect(row.port, row.host); let buffer = Buffer.alloc(0), payload, done = false
    const finish = error => { if (done) return; done = true; clearTimeout(timer); socket.destroy(); error ? reject(error) : resolve({ verified: true, checkedAt: Date.now() }) }
    const timer = setTimeout(() => finish(fail(504, '游戏协议握手超时')), timeoutMs)
    socket.on('error', () => finish(fail(502, '无法连接游戏 IP / 端口')))
    socket.on('close', () => finish(fail(502, '子服在协议验证完成前关闭了连接')))
    socket.on('connect', () => socket.write(frame(1, version)))
    socket.on('data', chunk => {
      buffer = Buffer.concat([buffer, chunk]); if (buffer.length > 65536) return finish(fail(502, '游戏验证响应过大'))
      try {
        while (buffer.length >= 3) {
          const length = buffer.readUInt16LE(); if (length < 3) throw fail(502, '游戏报文无效'); if (buffer.length < length) break
          const packet = buffer.subarray(0, length); buffer = buffer.subarray(length)
          if (packet[2] === 37) {
            if (!password) throw fail(409, '游戏服要求连接密码，请填写验证用游戏密码（仅用于本次握手，不保存）')
            socket.write(frame(38, password))
          } else if (packet[2] === 2) throw fail(502, '游戏服拒绝验证连接，请检查密码、版本与准入设置')
          else if (packet[2] === 3 && !payload) {
            const ip = (socket.localAddress || '').replace(/^::ffff:/, '')
            payload = Buffer.from(JSON.stringify({ v: 1, ip, at: Date.now(), nonce: randomBytes(18).toString('hex'), session: 'probe-' + randomBytes(10).toString('hex'), dimension: row.id })).toString('base64url')
            socket.write(frame(67, payload + '.' + sign(key, payload), 32700))
          } else if (packet[2] === 67 && packet.length >= 5 && packet.readInt16LE(3) === 32701) {
            if (!payload || textOf(packet, 5) !== payload + '.' + sign(key, 'ack:' + payload)) throw fail(502, '游戏端口的签名回执不匹配')
            finish(); return
          }
        }
      } catch (error) { finish(error) }
    })
  })
}
