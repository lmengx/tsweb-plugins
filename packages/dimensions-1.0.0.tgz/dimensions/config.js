import { isIP } from 'node:net'
import { randomUUID } from 'node:crypto'

export const fail = (status, message) => Object.assign(new Error(message), { status })
export const defaults = () => ({ schema: 2, revision: 0, enabled: false, captchaEnabled: false, captchaWorld: { source: 'builtin', assetId: '', spawnX: null, spawnY: null }, listenHost: '0.0.0.0', listenPort: 7777, fallbackId: '', routingMode: 'fill', connectTimeoutMs: 15000, connectionLimit: 5, connectionRate: 12, targets: [] })
const reserved = new Set(['dimensions', '维度', 'who', 'ping', 'void'])
const text = (v, max, label) => {
  if (typeof v !== 'string' || !v.trim() || v.trim().length > max) throw fail(400, `${label}格式无效`)
  return v.trim()
}
const integer = (v, min, max, label) => {
  if (!Number.isInteger(v) || v < min || v > max) throw fail(400, `${label}须为 ${min} 至 ${max} 的整数`)
  return v
}
export function validateConfig(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw fail(400, '配置格式无效')
  const config = { ...defaults() }
  if (typeof input.enabled !== 'boolean') throw fail(400, '请选择是否启用中转')
  config.enabled = input.enabled
  if (input.captchaEnabled !== undefined && typeof input.captchaEnabled !== 'boolean') throw fail(400, '请选择是否启用入服验证码')
  config.captchaEnabled = input.captchaEnabled ?? false
  if (input.captchaWorld !== undefined) {
    const world = input.captchaWorld
    if (!world || typeof world !== 'object' || Array.isArray(world) || !['builtin', 'trb', 'tsb'].includes(world.source)) throw fail(400, '验证码世界来源无效：请选择内置简易世界或自定义 TRB 建筑')
    const source = world.source === 'tsb' ? 'trb' : world.source
    if (typeof world.assetId !== 'string' || (world.assetId !== '' && !/^[a-f0-9]{64}$/.test(world.assetId)) || (source === 'trb' && !world.assetId)) throw fail(400, '请先在验证码世界中上传并选择 .trb 建筑文件，再保存配置')
    const spawnX = world.spawnX ?? null, spawnY = world.spawnY ?? null
    if ((spawnX === null) !== (spawnY === null)) throw fail(400, '出生点 X、Y 须同时填写或同时留空')
    if (spawnX !== null) { integer(spawnX, 0, 1023, '出生点 X'); integer(spawnY, 0, 1023, '出生点 Y') }
    config.captchaWorld = { source, assetId: world.assetId, spawnX, spawnY }
  }
  config.routingMode = input.routingMode ?? 'fill'
  if (!['fill', 'weight'].includes(config.routingMode)) throw fail(400, '分流模式须为足人或权重')
  config.revision = integer(input.revision, 0, Number.MAX_SAFE_INTEGER, '配置版本')
  config.listenHost = text(input.listenHost, 45, '监听地址')
  if (!isIP(config.listenHost)) throw fail(400, '监听地址须为本机 IPv4 或 IPv6 地址')
  config.listenPort = integer(input.listenPort, 1, 65535, '入口端口')
  config.connectTimeoutMs = integer(input.connectTimeoutMs, 3000, 60000, '连接超时')
  config.connectionLimit = integer(input.connectionLimit, 1, 100, '每 IP 连接数')
  config.connectionRate = integer(input.connectionRate, 1, 1000, '每 IP 十秒连接次数')
  if (!Array.isArray(input.targets) || input.targets.length > 32) throw fail(400, '子服最多为 32 个')
  const ids = new Set(), commands = new Set(), servers = new Set(), endpoints = new Set()
  config.targets = input.targets.map(row => {
    if (!row || typeof row !== 'object') throw fail(400, '子服格式无效')
    const id = row.id ? text(row.id, 64, '子服标识') : randomUUID()
    if (!/^[a-zA-Z0-9_-]+$/.test(id) || ids.has(id)) throw fail(400, '子服标识无效或重复')
    ids.add(id)
    const command = text(row.command, 128, '切服命令').replace(/[ \t]+/g, ' ').toLowerCase()
    if (!/^[a-z][a-z0-9_-]*(?: [a-z0-9_-]+)*$/.test(command) || reserved.has(command.split(' ')[0]) || commands.has(command)) throw fail(400, '切服命令须以英文字母开头，可用空格分隔参数；只支持英文字母、数字、下划线和短横线，完整命令不能重复或使用保留命令')
    commands.add(command)
    const serverId = text(row.serverId, 100, '管理服务器')
    if (servers.has(serverId)) throw fail(400, '同一管理服务器不能重复绑定')
    servers.add(serverId)
    const host = text(row.host, 253, '游戏主机地址')
    if (/[\s/\\?#@]/.test(host) || (!isIP(host) && !/^[a-zA-Z0-9.-]+$/.test(host))) throw fail(400, '游戏主机只填写 IP 或域名')
    const port = integer(row.port, 1, 65535, '游戏端口')
    const endpoint = `${host.toLowerCase()}:${port}`
    if (endpoints.has(endpoint)) throw fail(400, '游戏连接地址重复')
    endpoints.add(endpoint)
    if (port === config.listenPort && ['localhost', '127.0.0.1', '::1', config.listenHost].includes(host)) throw fail(400, '子服不能指向中转入口自身')
    for (const key of ['enabled', 'entry', 'hidden']) if (typeof row[key] !== 'boolean') throw fail(400, '子服开关格式无效')
    const distributionValue = integer(row.distributionValue ?? 10, 1, 100000, '分流数量 / 权重')
    return { id, name: text(row.name, 60, '子服名称'), command, host, port, serverId, enabled: row.enabled, entry: row.entry, hidden: row.hidden, distributionValue }
  })
  config.fallbackId = typeof input.fallbackId === 'string' ? input.fallbackId : ''
  if (config.fallbackId && !config.targets.some(t => t.id === config.fallbackId && t.enabled)) throw fail(400, '备用大厅须为已启用的子服')
  if (config.enabled && (!config.targets.some(t => t.enabled && t.entry) || !config.fallbackId)) throw fail(400, '启用前请配置入口子服和备用大厅')
  return config
}
