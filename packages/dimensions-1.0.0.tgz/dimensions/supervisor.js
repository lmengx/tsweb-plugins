import { fork } from 'node:child_process'
import { EventEmitter } from 'node:events'
import { fileURLToPath } from 'node:url'
import { fail } from './config.js'
import { LogBuffer, safeLog } from './logs.js'

// Only owns children created by this instance. Never discovers or terminates user processes.
export class ProxySupervisor extends EventEmitter {
  constructor({ childFile = fileURLToPath(new URL('./runtime/child.mjs', import.meta.url)), requestTimeout = 20000, restartBase = 1000, heartbeatMs = 10000 } = {}) {
    super(); this.childFile = childFile; this.requestTimeout = requestTimeout; this.restartBase = restartBase; this.heartbeatMs = heartbeatMs
    this.child = null; this.pending = new Map(); this.sequence = 0; this.generation = 0
    this.desired = null; this.timer = null; this.attempts = 0; this.closed = false; this.status = { phase: 'stopped', error: '', appliedRevision: null, pid: null }
    this.queue = Promise.resolve(); this.logs = new LogBuffer()
  }
  log(level, message, source = 'supervisor') { this.emit('log', this.logs.append(level, message, source)) }
  telemetry(value) {
    if (!value || typeof value !== 'object') return
    const patch = {}
    for (const key of ['uptimeMs', 'rssBytes', 'heapUsedBytes', 'heartbeatAt']) if (Number.isFinite(value[key]) && value[key] >= 0) patch[key] = value[key]
    if (value.console && typeof value.console === 'object') patch.console = { requested: value.console.requested === true, visible: value.console.visible === true, error: safeLog(value.console.error || '') }
    this.publish(patch)
  }
  publish(patch) { this.status = { ...this.status, ...patch }; this.emit('status', this.status) }
  apply(config) {
    const operation = this.queue.then(async () => {
      if (this.closed) throw fail(503, '中转插件已停用')
      this.desired = structuredClone(config); clearTimeout(this.timer); this.timer = null
      if (!config.enabled) { await this.stop(); return this.status }
      try {
        if (!this.child) await this.launch()
        const result = await this.rpc('configure', config)
        this.attempts = 0; this.publish({ phase: 'running', error: '', appliedRevision: config.revision, pid: this.child.pid, listenHost: config.listenHost, listenPort: config.listenPort })
        return result
      } catch (err) { if (err.status === 504) this.child?.kill(); this.publish({ phase: 'error', error: err.message }); this.schedule(); throw err }
    })
    this.queue = operation.catch(() => {}); return operation
  }
  async launch() {
    this.publish({ phase: 'starting', error: '', startedAt: Date.now(), uptimeMs: 0, heartbeatAt: null, rssBytes: null, heapUsedBytes: null, console: null })
    this.log('info', '正在启动独立维度代理进程')
    // Windows detached children get their own console, while IPC still owns their lifetime.
    const visibleConsole = process.platform === 'win32' && process.env.TSWEB_DIMENSIONS_CONSOLE === '1'
    const child = fork(this.childFile, [], { windowsHide: !visibleConsole, detached: visibleConsole, execArgv: [], stdio: ['ignore', 'pipe', 'pipe', 'ipc'], serialization: 'json' })
    this.child = child; this.publish({ pid: child.pid ?? null }); const generation = ++this.generation
    for (const [stream, source] of [[child.stdout, 'stdout'], [child.stderr, 'stderr']]) {
      let pending = ''
      stream.setEncoding('utf8')
      stream.on('data', chunk => {
        if (this.child !== child) return
        pending += chunk
        const lines = pending.split(/\r?\n/); pending = lines.pop()
        for (const line of lines) if (line.trim()) this.log(source === 'stderr' ? 'error' : 'info', line, source)
        if (pending.length > 4096) { this.log('warn', pending, source); pending = '' }
      })
      stream.on('end', () => { if (this.child === child && pending.trim()) this.log(source === 'stderr' ? 'error' : 'info', pending, source) })
    }
    child.on('message', message => {
      if (this.child !== child || generation !== this.generation) return
      if (message?.kind === 'response') {
        const item = this.pending.get(message.id); if (!item) return
        this.pending.delete(message.id); clearTimeout(item.timer)
        message.ok ? item.resolve(message.result) : item.reject(fail(502, message.error || '代理操作失败'))
      } else if (message?.kind === 'event') this.emit('event', message.event)
      else if (message?.kind === 'log' && typeof message.message === 'string') this.log(message.level, message.message, 'proxy')
      else if (message?.kind === 'telemetry') this.telemetry(message.runtime)
    })
    child.on('error', err => { if (this.child === child) this.publish({ phase: 'error', error: `代理无法启动：${err.message}` }) })
    child.once('exit', (code, signal) => {
      clearInterval(heartbeat)
      if (this.child !== child) return
      this.child = null
      this.log(this.desired?.enabled && !this.closed ? 'warn' : 'info', `维度进程已退出（${code ?? signal}）`)
      for (const item of this.pending.values()) { clearTimeout(item.timer); item.reject(fail(503, '代理进程已退出')) }
      this.pending.clear()
      this.publish({ phase: this.desired?.enabled && !this.closed ? 'retrying' : 'stopped', pid: null, appliedRevision: null, error: this.desired?.enabled ? `代理进程退出（${code ?? signal}）` : '' })
      this.schedule()
    })
    let checking = false
    const heartbeat = setInterval(async () => {
      if (checking || this.child !== child || this.closed || this.status.phase !== 'running') return
      checking = true
      try { const result = await this.rpc('ping', null); this.telemetry(result.runtime) }
      catch { if (this.child === child) { this.log('error', '代理健康检查超时，正在恢复'); this.publish({ phase: 'error', error: '代理健康检查超时，正在恢复' }); child.kill() } }
      finally { checking = false }
    }, this.heartbeatMs)
    heartbeat.unref?.()
    const initial = await this.rpc('ping', null); this.telemetry(initial.runtime)
  }
  rpc(method, data, timeoutMs = this.requestTimeout) {
    const child = this.child
    if (!child?.connected) return Promise.reject(fail(503, '代理尚未连接'))
    const id = `${this.generation}:${++this.sequence}`
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(id); reject(fail(504, '代理响应超时，请读取状态核对操作结果')) }, timeoutMs)
      timer.unref?.(); this.pending.set(id, { resolve, reject, timer })
      child.send({ kind: 'request', id, method, data }, err => { if (err && this.pending.delete(id)) { clearTimeout(timer); reject(fail(503, '代理通信失败')) } })
    })
  }
  schedule() {
    if (this.closed || !this.desired?.enabled || this.timer) return
    this.timer = setTimeout(() => { this.timer = null; this.apply(this.desired).catch(() => {}) }, Math.min(30000, this.restartBase * 2 ** Math.min(this.attempts++, 5)))
    this.timer.unref?.()
  }
  async stop() {
    clearTimeout(this.timer); this.timer = null
    const child = this.child; if (!child) { this.publish({ phase: 'stopped', pid: null, appliedRevision: null, error: '' }); return }
    this.publish({ phase: 'stopping' }); this.log('info', '正在停止维度进程并释放入口端口')
    const exited = new Promise(resolve => child.once('exit', resolve))
    const force = setTimeout(() => child.kill(), 3000); force.unref?.()
    try { await this.rpc('stop', null) } catch {}
    await exited; clearTimeout(force)
    this.publish({ phase: 'stopped', pid: null, appliedRevision: null, error: '' })
  }
  async close() { this.closed = true; this.desired = null; clearTimeout(this.timer); await this.queue; await this.stop(); this.removeAllListeners() }
}
