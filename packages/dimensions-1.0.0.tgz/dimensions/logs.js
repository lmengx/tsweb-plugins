const levels = new Set(['info', 'warn', 'error', 'debug'])
export function safeLog(value) {
  return String(value ?? '').replace(/\x1b\[[0-9;]*[A-Za-z]/g, '').replace(/[\x00-\x08\x0b-\x1f\x7f]/g, '')
    .replace(/\b[a-f0-9]{64}\b/gi, '[已隐藏密钥]')
    .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g, '[已隐藏令牌]')
    .replace(/((?:token|secret|password|authorization|bridgeKey)["']?\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s,}]+)/gi, '$1[已隐藏]')
    .slice(0, 2048)
}
export class LogBuffer {
  constructor(capacity = 400) { this.capacity = capacity; this.sequence = 0; this.rows = [] }
  append(level, message, source = 'proxy') {
    const row = { id: ++this.sequence, at: Date.now(), level: levels.has(level) ? level : 'info', source: ['proxy', 'supervisor', 'stdout', 'stderr'].includes(source) ? source : 'proxy', message: safeLog(message) }
    this.rows.push(row); if (this.rows.length > this.capacity) this.rows.shift()
    return row
  }
  read(after = 0, limit = 200) {
    if (!Number.isSafeInteger(after) || after < 0 || !Number.isInteger(limit) || limit < 1 || limit > 400) throw Object.assign(new Error('日志游标或条数无效'), { status: 400 })
    const available = this.rows.filter(row => row.id > after), rows = available.slice(-limit)
    return { logs: rows, cursor: this.sequence, truncated: (after > 0 && this.rows.length > 0 && after < this.rows[0].id - 1) || available.length > limit }
  }
}
