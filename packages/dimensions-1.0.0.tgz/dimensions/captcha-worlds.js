import fs from 'node:fs/promises'
import path from 'node:path'
import { createHash, randomUUID } from 'node:crypto'
const { prepareCaptchaBuilding, MAX_BUILDING_BYTES } = await import('./runtime/captcha-world.mjs' + new URL(import.meta.url).search)
import { fail } from './config.js'

const hash = bytes => createHash('sha256').update(bytes).digest('hex')
export class CaptchaWorldAssets {
  constructor(dir) { this.dir = dir; this.cache = new Map() }
  assetPath(id, extension = '.trb') {
    if (typeof id !== 'string' || !/^[a-f0-9]{64}$/.test(id)) throw fail(400, '验证码建筑标识无效')
    return path.join(this.dir, id + extension)
  }
  async read(id) {
    let file
    try {
      try { file = await fs.open(this.assetPath(id), 'r') }
      catch (error) { if (error.code !== 'ENOENT') throw error; file = await fs.open(this.assetPath(id, '.tsb'), 'r') }
      const info = await file.stat()
      if (!info.isFile()) throw fail(422, 'TRB 建筑资源不是普通文件，请重新上传 .trb 文件')
      if (info.size > MAX_BUILDING_BYTES) throw fail(413, `TRB 文件大小为 ${info.size} 字节，超过 32 MiB（${MAX_BUILDING_BYTES} 字节）上限，请缩小建筑区域后重新导出`)
      const bytes = await file.readFile()
      if (hash(bytes) !== id) throw fail(422, '验证码建筑已损坏：文件内容的 SHA-256 与上传时不一致，请重新上传原始 .trb 文件')
      return bytes
    } catch (error) { if (error.code === 'ENOENT') throw fail(404, '验证码建筑不存在，请重新上传或选择内置世界'); throw error }
    finally { await file?.close() }
  }
  async metadata(id) {
    const value = JSON.parse(await fs.readFile(this.assetPath(id, '.json'), 'utf8'))
    return { id, name: String(value.name).slice(0, 160).replace(/\.tsb$/i, '.trb'), width: value.width, height: value.height, spawnX: value.spawnX, spawnY: value.spawnY, createdAt: value.createdAt }
  }
  async list() {
    await fs.mkdir(this.dir, { recursive: true })
    const assets = [], seen = new Set()
    for (const entry of await fs.readdir(this.dir)) {
      if (!/^[a-f0-9]{64}\.(trb|tsb)$/.test(entry)) continue
      const id = entry.slice(0, -4)
      if (seen.has(id)) continue
      try { assets.push(await this.metadata(id)); seen.add(id) } catch { /* unfinished upload is not selectable */ }
    }
    return { assets: assets.sort((a, b) => b.createdAt - a.createdAt) }
  }
  async write(file, bytes) {
    const temp = file + '.' + randomUUID() + '.tmp'
    try { await fs.writeFile(temp, bytes, { flag: 'wx', mode: 0o600 }); await fs.rename(temp, file) }
    finally { await fs.rm(temp, { force: true }) }
  }
  async upload(body) {
    const name = body?.name, data = body?.data
    if (typeof name !== 'string' || !name || name.length > 160 || /[\\/:*?"<>|\x00-\x1f]/.test(name)) throw fail(400, 'TRB 文件名无效：只允许不超过 160 个字符的文件名，不能包含目录或特殊路径字符')
    if (!/\.trb$/i.test(name)) throw fail(400, `导入「${name}」失败：仅接受 .trb 建筑文件（tsweb-building v1 / raw14），不支持 .wld、.schematic 等其它文件；旧版 .tsb 使用相同契约，可将扩展名改为 .trb 后导入`)
    if (typeof data !== 'string' || !data.length) throw fail(400, `导入「${name}」失败：上传内容为空，请重新选择非空 .trb 文件`)
    if (data.length > Math.ceil(MAX_BUILDING_BYTES / 3) * 4) throw fail(413, `导入「${name}」失败：文件超过 32 MiB（${MAX_BUILDING_BYTES} 字节），请缩小建筑区域后重新导出`)
    if (data.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/.test(data)) throw fail(400, `导入「${name}」失败：上传数据不是有效的 Base64，文件尚未开始解析，请重新上传`)
    const bytes = Buffer.from(data, 'base64'), id = hash(bytes)
    if (bytes.toString('base64') !== data) throw fail(400, `导入「${name}」失败：Base64 数据不完整或编码不规范，请重新上传原始文件`)
    let prepared
    try { prepared = prepareCaptchaBuilding(bytes, {}, true) }
    catch (error) { throw fail(error.status || 422, `导入「${name}」失败：${error.message}`) }
    await fs.mkdir(this.dir, { recursive: true })
    const entries = await this.list()
    if (entries.assets.length >= 20 && !entries.assets.some(asset => asset.id === id)) throw fail(413, '最多保留 20 份验证码建筑，请先删除不再使用的文件')
    const asset = { id, name, width: prepared.width, height: prepared.height, spawnX: prepared.spawnX, spawnY: prepared.spawnY, createdAt: Date.now() }
    await this.write(this.assetPath(id), bytes)
    await this.write(this.assetPath(id, '.json'), JSON.stringify(asset))
    this.cache.clear()
    return { asset, preview: prepared.preview }
  }
  async describe(id) {
    const bytes = await this.read(id), asset = await this.metadata(id)
    return { asset, preview: prepareCaptchaBuilding(bytes, {}, true).preview }
  }
  async prepare(settings) {
    if (!settings || settings.source === 'builtin') return undefined
    const bytes = await this.read(settings.assetId)
    const key = JSON.stringify([settings.assetId, settings.spawnX, settings.spawnY])
    if (this.cache.has(key)) return this.cache.get(key)
    const world = prepareCaptchaBuilding(bytes, settings)
    this.cache.clear(); this.cache.set(key, world)
    return world
  }
  async remove(id, selected) {
    this.assetPath(id)
    if (['trb', 'tsb'].includes(selected?.source) && selected.assetId === id) throw fail(409, '此建筑仍在已保存的验证码世界配置中，请先更换并保存配置')
    await fs.rm(this.assetPath(id), { force: true }); await fs.rm(this.assetPath(id, '.tsb'), { force: true }); await fs.rm(this.assetPath(id, '.json'), { force: true })
    this.cache.clear(); return { deleted: true }
  }
}
