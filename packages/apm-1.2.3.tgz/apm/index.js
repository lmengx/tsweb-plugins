import path from "node:path";
const revision = new URL(import.meta.url).search;
const { default: contract } = await import(`./access.js${revision}`);
const { GithubCatalog } = await import(`./catalog.js${revision}`);
const { ApmService } = await import(`./service.js${revision}`);
export const name = "apm";
export const inject = [
  "webServer",
  "auth",
  "paths",
  "servers",
  "configAnything",
];
export async function apply(ctx) {
  if (
    typeof ctx.configAnything.installPlugin !== "function" ||
    !ctx.configAnything.capabilities?.sharedDependencies ||
    !ctx.configAnything.capabilities?.logicalPackages ||
    !ctx.configAnything.capabilities?.configurationApply ||
    typeof ctx.configAnything.unloadPlugin !== "function"
  )
    throw new Error(
      "APM 需要 config-anything 1.5.0 或以上版本，请先更新配置基础插件",
    );
  const catalog = new GithubCatalog(
    path.join(ctx.paths.dataOf("apm"), "cache"),
  );
  const service = new ApmService(ctx, catalog),
    controllers = new Set();
  ctx.effect(() => () => {
    service.dispose();
    for (const controller of controllers) controller.abort();
  });
  await catalog.init();
  if (typeof ctx.configAnything.registerLifecyclePolicy === "function") {
    const remove = ctx.configAnything.registerLifecyclePolicy("apm", async assemblyName => {
      return catalog.current?.plugins.find(row => row.assemblyName === assemblyName) || null;
    });
    ctx.effect(() => remove);
  }
  const app = ctx.auth.access.policyApp(ctx.webServer.app, contract, ctx);
  const wrap = (handler) => async (req, res) => {
    const controller = new AbortController();
    controllers.add(controller);
    const close = () => {
      if (!res.writableFinished) controller.abort();
    };
    res.on("close", close);
    try {
      const id = req.headers["x-server-id"];
      service.server(id);
      const result = await handler(req, id, controller.signal);
      if (!res.destroyed) res.json(result);
    } catch (err) {
      if (!res.destroyed)
        res.status(err.status || 502).json({ error: err.message });
    } finally {
      controllers.delete(controller);
      res.off("close", close);
    }
  };
  app.get(
    "/api/apm/catalog",
    wrap((req, id, signal) => service.list(id, { signal })),
  );
  app.post(
    "/api/apm/refresh",
    wrap((req, id, signal) => service.list(id, { force: true, signal })),
  );
  app.post(
    "/api/apm/install",
    wrap((req, id, signal) => service.install(id, req.body, { signal })),
  );
  app.post(
    "/api/apm/uninstall",
    wrap((req, id, signal) => service.uninstall(id, req.body, { signal })),
  );
  app.get(
    "/api/apm/pages",
    wrap((req, id) => ({ pages: service.pages(id, req.user) })),
  );
  app.post(
    "/api/apm/pages",
    wrap((req, id, signal) => service.bind(id, req.body, { signal })),
  );
  app.delete(
    "/api/apm/pages/:id",
    wrap((req, id) => service.remove(id, req.params.id)),
  );
}
