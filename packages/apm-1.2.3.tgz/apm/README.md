# APM

依赖 `config-anything` 1.5.0 的 Cordis 插件，游戏服接收端需要 TsWebHost 2.2.0。侧边栏提供 **APM → 插件浏览**，支持搜索、已安装筛选、运行版本比较、安装卸载和配置页面管理。

## 使用流程

1. 启用 `config-anything` 和 APM，游戏服部署新版 `ConfigAnything.dll` 及支持业务包安装的 TsWebHost。
2. 选择服务器，进入 APM 插件浏览。首次访问下载 GitHub 发布包，后续使用缓存；刷新按钮重新检查发布包。
3. 选择插件，安装并加载主 DLL 与缺失依赖。已有原生插件也可直接创建配置页。
4. 选择加载期读取记录，或手动填写 tshock 目录内的文件路径，确认后保存配置页。
5. 页面永久保存于 `config-anything` 的关联数据中，重启后恢复到 APM 分组。管理员可在现有权限管理中单独授权每一页。

配置页复用原有 JSON 配置器和文本编辑器。移除页面只删除关联，保留插件和配置文件。

配置页新增 Reload 与热重载按钮：有目标插件的 Reload 订阅时优先建议 Reload，否则建议热重载。Reload 只触发目标插件回调。APM 将已缓存清单中的 `HotReload: false` 限制登记给配置基础件，不为状态检测额外联网；共享依赖的使用方保护仍由宿主检查。

在“已安装”中选中插件，点击“卸载插件”并确认。卸载对应逻辑包及其独占普通库，移除对应 APM 配置页，保留配置文件。LazyAPI 等依赖插件各自独立管理，不随首个使用方一起卸载；旧混装包会保留实例迁移归属。仅支持本加载器管理且支持热卸载的包，其他情况显示禁用原因；已有清单缓存时允许离线卸载。

## 来源与加载边界

- 来源：`UnrealMultiple/TShockPlugin` 的滚动发布 `V1.0.0.0`，资产 `Plugins.zip`。清单使用 ZIP 内的 `Plugins.json`，与安装 DLL 来自同一发布包；不混用 master 分支清单，也不调用上游 HTTP APM 服务。
- 下载使用 GitHub Release Asset API，根据发布元数据中的资产 ID 请求二进制并跟随官方 CDN 重定向，避免依赖浏览器下载域名的可达性。
- 按程序集身份识别已安装插件，按 `TerrariaPlugin.Version` 与上游清单比较版本，不将程序集文件版本混作插件版本。
- 校验 GitHub 提供的 SHA-256（如有）、DLL 哈希和托管程序集身份。下载仅允许固定 GitHub 发布资产及其官方重定向域名，并限制下载、解压和 DLL 大小。
- 网络不可用时明确显示缓存状态，禁止安装。插件配置页仍可独立使用。
- 调用 `ctx.configAnything.installPlugin()`，由 TsWebHost 执行加载及失败回滚，不安装上游 AutoPluginManager DLL。
- 支持更新当前主插件对应的外部包；拒绝覆盖原生加载器、其他插件包拥有的插件，拒绝包含 `HotReload: false` 组件的在线替换。
- 已加载的原生依赖或其他外部包的依赖达到目录版本时，直接共享同一个程序集和插件实例；重复上传的普通库 DLL 仅在程序集身份及 SHA-256 均一致时自动共享。版本过旧、二进制不同、提供方不唯一时明确报错。
- 共享关系写入包清单，服务器重启按依赖顺序恢复；接收端热重载接管原实例和共享关系。使用方更新失败时恢复旧版及依赖关系。
- 依赖仍被使用时，TsWebHost 拒绝更新或卸载其所属包，并列出使用方；先卸载使用方后才可更新提供方。此保护覆盖整个提供包，包含主插件与其依赖；同内容重复安装不触发更新。其他原生加载器的独立操作不受此保护约束。
- 上游清单没有可靠的 TShock 版本约束，显示目录版本不代表已经验证运行兼容性。加载失败返回加载器错误并回滚；发布包不包含的本地插件请在“插件配置”中管理。
- 捕获构造和初始化期间的读取及首次创建配置；已初始化的 LazyAPI 配置可从路径元数据补充候选，界面标明来源。其他无记录插件仍须手动输入路径；修改文件何时生效由目标插件决定。

APM 浏览、安装和关联管理限超级管理员；普通管理员只会看到授权给自己的配置页，不会获得通用文件或命令权限。APM 停用不卸载已经在游戏服运行的插件。

## 开发验证

```powershell
node --test plugins/apm/test/*.test.mjs plugins/config-anything/test/*.test.mjs client/test/shared-dependencies.test.mjs client/test/receiver-sync.test.mjs
node scripts/build-client.mjs apm config-anything
dotnet build plugins/config-anything/plugin/ConfigAnything.csproj -c Release
dotnet build plugins/tsweb-host/TsWebHost.csproj -c Release
npm run check:access
```
