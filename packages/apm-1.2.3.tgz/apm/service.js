import { createHash } from "node:crypto";
import { error, extractArchive } from "./catalog.js";

export const externalKey = (name) =>
  "external-" + createHash("sha256").update(name).digest("hex").slice(0, 20);
export const assemblyOf = (plugin) =>
  plugin.assemblyName || plugin.fileName?.replace(/\.dll$/i, "");
const ownedBy = (plugin, key) => plugin.packageKey ? plugin.packageKey === key : plugin.loadContext?.startsWith(`tsweb:${key}:`);
export function compareVersions(a, b) {
  if (
    ![a, b].every(
      (value) => typeof value === "string" && /^\d+(\.\d+){1,3}$/.test(value),
    )
  )
    return null;
  const left = a.split(".").map(BigInt),
    right = b.split(".").map(BigInt);
  for (let i = 0; i < 4; i++) {
    if ((left[i] || 0n) !== (right[i] || 0n))
      return (left[i] || 0n) > (right[i] || 0n) ? 1 : -1;
  }
  return 0;
}
export function dependencyClosure(plugins, assemblyName) {
  const catalog = new Map(plugins.map((row) => [row.assemblyName, row]));
  if (!catalog.has(assemblyName)) throw error(404, "插件不在 APM 清单中");
  const visited = new Set(),
    active = new Set(),
    rows = [];
  function visit(name) {
    if (active.has(name)) throw error(409, "插件依赖存在循环：" + name);
    if (visited.has(name)) return;
    active.add(name);
    const row = catalog.get(name) || {
      assemblyName: name,
      name,
      fileName: `${name}.dll`,
      dependencies: [],
      hotReload: true,
      library: true,
    };
    for (const dependency of row.dependencies) visit(dependency);
    active.delete(name);
    visited.add(name);
    rows.push(row);
  }
  visit(assemblyName);
  if (rows.length > 21) throw error(413, "插件与依赖数量超过 21 个");
  return rows;
}

function uninstallPlan(catalog, snapshot, assemblyName) {
  const main = snapshot.plugins.filter((p) => assemblyOf(p) === assemblyName);
  const key = externalKey(assemblyName);
  const owned = snapshot.plugins.filter((p) =>
    ownedBy(p, key),
  );
  let reason = "";
  if (!main.length) reason = "插件未加载，请刷新列表";
  else if (main.some((p) => !ownedBy(p, key)))
    reason = "该插件由其他加载器或插件包管理，请通过其所属加载器卸载";
  else {
    const blocked = owned.filter(
      (p) =>
        !catalog.some(
          (row) => row.assemblyName === assemblyOf(p) && row.hotReload,
        ),
    );
    if (blocked.length)
      reason = `插件包包含不支持在线卸载的组件：${blocked.map((p) => p.name).join("、")}，需停服后移除`;
  }
  return {
    uninstallable: !reason,
    uninstallReason: reason,
    uninstallPluginNames: owned.map((p) => p.name),
    pluginIds: owned.map((p) => p.id),
  };
}

export class ApmService {
  constructor(ctx, catalog) {
    this.ctx = ctx;
    this.catalog = catalog;
    this.queues = new Map();
    this.disposed = false;
  }
  server(id) {
    if (this.disposed) throw error(503, "APM 正在停用");
    if (!id || typeof id !== "string") throw error(400, "请先选择服务器");
    if (!this.ctx.servers.getRaw(id)) throw error(404, "服务器不存在");
  }
  pages(id, user) {
    this.server(id);
    return this.ctx.configAnything
      .listConfigurations(id, user)
      .filter((row) => row.slot === "apm");
  }
  async list(id, { force = false, signal } = {}) {
    this.server(id);
    const [release, snapshot] = await Promise.all([
      this.catalog.get({ force }),
      this.ctx.configAnything.listPlugins(id, { signal }),
    ]);
    signal?.throwIfAborted();
    this.server(id);
    const plugins = release.plugins.map((row) => {
      const instances = snapshot.plugins.filter(
        (plugin) => assemblyOf(plugin) === row.assemblyName,
      );
      const versions = [...new Set(instances.map((p) => p.version))];
      const installedVersion = versions.length === 1 ? versions[0] : null;
      const comparison = installedVersion
        ? compareVersions(installedVersion, row.version)
        : null;
      const status = !instances.length
        ? "available"
        : comparison === null
          ? "unknown"
          : comparison < 0
            ? "update"
            : comparison > 0
              ? "newer"
              : "current";
      return {
        ...row,
        instances,
        installedVersion,
        status,
        ...uninstallPlan(release.plugins, snapshot, row.assemblyName),
        managed:
          instances.length > 0 &&
          instances.every((p) =>
            ownedBy(p, externalKey(row.assemblyName)),
          ),
      };
    });
    return {
      plugins,
      source: release.source,
      observation: snapshot.observation,
    };
  }
  async install(id, input = {}, { signal } = {}) {
    this.server(id);
    if (
      typeof input.assemblyName !== "string" ||
      !Number.isSafeInteger(input.assetId) ||
      !/^[a-f0-9]{64}$/.test(input.sha256) ||
      (input.replace !== undefined && typeof input.replace !== "boolean")
    )
      throw error(400, "请选择插件及发布包版本");
    return this.operation(id, () => this.performInstall(id, input, signal));
  }
  async operation(id, action) {
    if (this.queues.has(id))
      throw error(409, "此服务器已有插件操作任务，请等待完成");
    const operation = Promise.resolve().then(action);
    this.queues.set(id, operation);
    try {
      return await operation;
    } finally {
      this.queues.delete(id);
    }
  }
  async uninstall(id, input = {}, { signal } = {}) {
    this.server(id);
    if (
      typeof input.assemblyName !== "string" ||
      !input.assemblyName ||
      input.assemblyName.length > 200
    )
      throw error(400, "请选择需要卸载的插件");
    return this.operation(id, () =>
      this.performUninstall(id, input.assemblyName, signal),
    );
  }
  async performUninstall(id, assemblyName, signal) {
    const [release, snapshot] = await Promise.all([
      this.catalog.get({ cached: true }),
      this.ctx.configAnything.listPlugins(id, { signal }),
    ]);
    if (!release.plugins.some((p) => p.assemblyName === assemblyName))
      throw error(404, "插件不在 APM 清单中");
    const plan = uninstallPlan(release.plugins, snapshot, assemblyName);
    if (!plan.uninstallable) throw error(409, plan.uninstallReason);
    const affected = this.pages(id).filter((row) =>
      plan.pluginIds.includes(row.pluginId),
    );
    signal?.throwIfAborted();
    this.server(id);
    const result = await this.ctx.configAnything.unloadPlugin(
      id,
      {
        assemblyName,
        reloadableAssemblies: [
          ...new Set(
            snapshot.plugins
              .filter((p) => plan.pluginIds.includes(p.id))
              .map(assemblyOf),
          ),
        ],
      },
      { signal },
    );
    if (!result.unloaded)
      throw error(502, "加载器未确认卸载，请刷新检查服务器日志");
    // Complete sidebar cleanup even if the requesting browser disconnects after unloading.
    const cleanupErrors = [];
    let removedPages = 0;
    for (const row of affected) {
      try {
        await this.ctx.configAnything.unregisterConfiguration(row.id, id);
        removedPages++;
      } catch (err) {
        if (err.status !== 404)
          cleanupErrors.push(`${row.title || row.id}：${err.message}`);
      }
    }
    return { ...result, removedPages, cleanupErrors };
  }
  async performInstall(id, input, signal) {
    const release = await this.catalog.get({ strict: true });
    if (
      release.meta.assetId !== input.assetId ||
      release.meta.sha256 !== input.sha256
    )
      throw error(409, "APM 发布包已变化，请刷新列表后重试");
    const closure = dependencyClosure(release.plugins, input.assemblyName);
    const snapshot = await this.ctx.configAnything.listPlugins(id, { signal });
    const key = externalKey(input.assemblyName),
      included = [],
      sharedDependencies = [];
    let updating = false;
    for (const row of closure) {
      const installed = snapshot.plugins.filter(
        (p) => assemblyOf(p) === row.assemblyName,
      );
      // Pin foreign dependencies through the receiver, which owns cross-package references.
      if (
        row.assemblyName !== input.assemblyName &&
        installed.length &&
        installed.every((p) => !ownedBy(p, key))
      ) {
        if (
          row.version &&
          installed.some((p) => {
            const c = compareVersions(p.version, row.version);
            return c === null || c < 0;
          })
        )
          throw error(409, `依赖 ${row.name} 的版本过旧，请先更新其提供方`);
        sharedDependencies.push({
          assemblyName: row.assemblyName,
          minimumVersion: row.version,
        });
        continue;
      }
      for (const plugin of installed) {
        if (!ownedBy(plugin, key))
          throw error(
            409,
            `${row.name} 已由其他加载器或插件包管理，不能重复加载或覆盖`,
          );
        updating = true;
      }
      included.push(row);
    }
    if (updating && !input.replace)
      throw error(409, "插件包已加载，请明确选择更新");
    if (updating && included.some((row) => !row.hotReload))
      throw error(409, "此插件包包含不支持热更新的插件，不能在线替换");
    const files = await extractArchive(
      release.bytes,
      new Set(included.map((row) => `Plugins/${row.fileName}`)),
    );
    const blobs = included.map((row) => {
      const bytes = files.get(`Plugins/${row.fileName}`);
      if (!bytes) throw error(502, `发布包缺少依赖文件：${row.fileName}`);
      return { fileName: row.fileName, bytes };
    });
    signal?.throwIfAborted();
    this.server(id);
    const loaded = await this.ctx.configAnything.installPlugin(
      id,
      {
        mainFile: closure.at(-1).fileName,
        files: blobs,
        sharedDependencies,
        replace: !!input.replace,
        reloadable: included.every((row) => row.hotReload),
      },
      { signal },
    );
    // Runtime state is authoritative even if the client disconnected during activation.
    this.server(id);
    const after = await this.ctx.configAnything.listPlugins(id);
    const instances = after.plugins.filter(
      (p) => assemblyOf(p) === input.assemblyName,
    );
    if (!instances.length)
      throw error(
        502,
        "加载器已返回，但未发现目标插件实例，请刷新检查服务器日志",
      );
    return {
      ...loaded,
      instances,
      installed: included.map((row) => row.assemblyName),
      source: release.source,
    };
  }
  async bind(id, input = {}, { signal } = {}) {
    this.server(id);
    const snapshot = await this.ctx.configAnything.listPlugins(id, { signal });
    const plugin = snapshot.plugins.find((p) => p.id === input.pluginId);
    if (
      !plugin ||
      !input.assemblyName ||
      assemblyOf(plugin) !== input.assemblyName
    )
      throw error(400, "请选择当前服务器中的目标插件实例");
    const release = await this.catalog.get();
    if (!release.plugins.some((row) => row.assemblyName === input.assemblyName))
      throw error(404, "插件不在 APM 清单中");
    return this.ctx.configAnything.registerConfiguration(
      {
        serverId: id,
        pluginId: plugin.id,
        path: input.path,
        title: input.title,
        slot: "apm",
        sidebar: false,
      },
      { signal },
    );
  }
  async remove(id, bindingId) {
    if (!this.pages(id).some((row) => row.id === bindingId))
      throw error(404, "APM 配置页面不存在");
    return this.ctx.configAnything.unregisterConfiguration(bindingId, id);
  }
  dispose() {
    this.disposed = true;
    this.catalog.dispose();
  }
}
