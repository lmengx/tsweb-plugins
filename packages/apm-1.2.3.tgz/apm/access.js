const routes = [
  ["catalog", "GET", "/api/apm/catalog"],
  ["refresh", "POST", "/api/apm/refresh"],
  ["install", "POST", "/api/apm/install"],
  ["uninstall", "POST", "/api/apm/uninstall"],
  ["bind", "POST", "/api/apm/pages"],
  ["remove", "DELETE", "/api/apm/pages/:id"],
];
export default {
  owner: "apm",
  version: 2,
  modules: [
    {
      id: "apm.manage",
      permission: "apm.manage",
      title: "APM 插件浏览与安装卸载",
      roles: ["superadmin"],
      superadminOnly: true,
      scope: "server",
      requires: routes.map(([id]) => `apm.${id}`),
    },
    {
      id: "apm.pages",
      permission: "apm.pages",
      title: "APM 已授权配置页面",
      roles: ["superadmin", "admin", "subadmin", "custom"],
      grantable: false,
      scope: "server",
      requires: ["apm.list-pages"],
    },
  ],
  actions: [
    ...routes.map(([id, method, path]) => ({
      id: `apm.${id}`,
      module: "apm.manage",
      method,
      path,
      scope: "server",
    })),
    {
      id: "apm.list-pages",
      module: "apm.pages",
      method: "GET",
      path: "/api/apm/pages",
      scope: "server",
    },
  ],
  features: [
    {
      id: "apm:browse",
      module: "apm.manage",
      requires: routes.map(([id]) => `apm.${id}`),
    },
  ],
};
