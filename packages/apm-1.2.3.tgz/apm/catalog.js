import fs from "node:fs/promises";
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import yauzl from "yauzl";

export const REPOSITORY = "UnrealMultiple/TShockPlugin";
export const RELEASE_TAG = "V1.0.0.0";
export const ASSET_URL = `https://github.com/${REPOSITORY}/releases/download/${RELEASE_TAG}/Plugins.zip`;
export const error = (status, message) =>
  Object.assign(new Error(message), { status });
export const sha256 = (bytes) =>
  createHash("sha256").update(bytes).digest("hex");
const MB = 1024 * 1024;
export function safeDll(value) {
  return (
    typeof value === "string" &&
    value.length <= 200 &&
    value === value.trim() &&
    /^[^\\/:<>"|?*\x00-\x1f]+\.dll$/i.test(value) &&
    !value.startsWith(".")
  );
}

export async function extractArchive(bytes, wanted) {
  if (bytes.length > 80 * MB) throw error(413, "APM 发布包超过 80 MB");
  const zip = await new Promise((resolve, reject) =>
    yauzl.fromBuffer(
      bytes,
      { lazyEntries: true, strictFileNames: true, validateEntrySizes: true },
      (err, value) => (err ? reject(err) : resolve(value)),
    ),
  );
  const entries = new Set(),
    output = new Map();
  let total = 0,
    extracted = 0;
  try {
    await new Promise((resolve, reject) => {
      zip.on("error", reject);
      zip.on("end", resolve);
      zip.on("entry", (entry) => {
        (async () => {
          const name = entry.fileName;
          if (
            entries.size >= 5000 ||
            entries.has(name.toLowerCase()) ||
            name.split("/").some((p) => p === "." || p === "..") ||
            /^[\\/]|:|\\/.test(name) ||
            entry.uncompressedSize > 24 * MB ||
            (total += entry.uncompressedSize) > 300 * MB
          )
            throw error(400, "发布包文件重复、路径无效或解压大小超限");
          entries.add(name.toLowerCase());
          if (wanted.has(name)) {
            const limit = name === "Plugins.json" ? 4 * MB : 20 * MB;
            if (entry.uncompressedSize > limit)
              throw error(413, "发布包文件过大");
            const stream = await new Promise((r, j) =>
              zip.openReadStream(entry, (e, s) => (e ? j(e) : r(s))),
            );
            const chunks = [];
            let size = 0;
            for await (const chunk of stream) {
              size += chunk.length;
              extracted += chunk.length;
              if (size > limit || extracted > 54 * MB) {
                stream.destroy();
                throw error(413, "插件包解压超限");
              }
              chunks.push(chunk);
            }
            output.set(name, Buffer.concat(chunks));
          }
          zip.readEntry();
        })().catch(reject);
      });
      zip.readEntry();
    });
    return output;
  } finally {
    zip.close();
  }
}

export function parseManifest(bytes) {
  let rows;
  try {
    rows = JSON.parse(bytes?.toString("utf8").replace(/^\uFEFF/, ""));
  } catch {
    throw error(502, "发布包缺少有效的 Plugins.json");
  }
  if (!Array.isArray(rows) || rows.length > 2000)
    throw error(502, "APM 插件清单格式错误");
  const names = new Set();
  return rows.map((row) => {
    if (
      !row ||
      typeof row.AssemblyName !== "string" ||
      !safeDll(row.Path) ||
      !safeDll(`${row.AssemblyName}.dll`) ||
      row.Path.toLowerCase() !== `${row.AssemblyName}.dll`.toLowerCase() ||
      names.has(row.AssemblyName.toLowerCase()) ||
      !/^\d+(\.\d+){1,3}$/.test(row.Version) ||
      !Array.isArray(row.Dependencies) ||
      row.Dependencies.length > 20 ||
      row.Dependencies.some(
        (dep) => typeof dep !== "string" || !safeDll(`${dep}.dll`),
      ) ||
      typeof row.HotReload !== "boolean"
    )
      throw error(502, "APM 插件清单字段无效");
    names.add(row.AssemblyName.toLowerCase());
    return {
      assemblyName: row.AssemblyName,
      name: String(row.Name || row.AssemblyName).slice(0, 200),
      version: row.Version,
      author: String(row.Author || "").slice(0, 500),
      description: String(
        (typeof row.Description === "object"
          ? row.Description?.["zh-CN"] || row.Description?.["en-US"]
          : row.Description) || "",
      ).slice(0, 5000),
      fileName: row.Path,
      dependencies: [...new Set(row.Dependencies)],
      hotReload: row.HotReload,
    };
  });
}

async function download(
  fetcher,
  url,
  max,
  signal,
  accept = "application/vnd.github+json",
) {
  const hosts = new Set([
    "api.github.com",
    "github.com",
    "release-assets.githubusercontent.com",
    "objects.githubusercontent.com",
  ]);
  for (let redirects = 0; redirects <= 5; redirects++) {
    const address = new URL(url);
    if (
      address.protocol !== "https:" ||
      !hosts.has(address.hostname) ||
      address.port ||
      address.username ||
      address.password
    )
      throw error(502, "GitHub 下载地址无效");
    const response = await fetcher(address.href, {
      redirect: "manual",
      signal,
      headers: {
        "User-Agent": "TSWeb-APM",
        Accept: accept,
      },
    });
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      url = new URL(response.headers.get("location"), address).href;
      await response.body?.cancel();
      continue;
    }
    if (!response.ok) {
      await response.body?.cancel();
      throw error(502, `GitHub 请求失败 (${response.status})`);
    }
    if (Number(response.headers.get("content-length")) > max) {
      await response.body?.cancel();
      throw error(413, "GitHub 下载文件过大");
    }
    const chunks = [];
    let length = 0;
    try {
      for await (const chunk of response.body) {
        length += chunk.length;
        if (length > max) throw error(413, "GitHub 下载文件过大");
        chunks.push(chunk);
      }
    } catch (err) {
      await response.body?.cancel().catch(() => {});
      throw err;
    }
    return Buffer.concat(chunks);
  }
  throw error(502, "GitHub 重定向次数过多");
}

export class GithubCatalog {
  constructor(directory, { fetcher = fetch, now = Date.now } = {}) {
    Object.assign(this, { directory, fetcher, now });
    this.controller = new AbortController();
    this.current = null;
    this.pending = null;
    this.checkedAt = 0;
  }
  dispose() {
    this.controller.abort();
  }
  async init() {
    try {
      const meta = JSON.parse(
        await fs.readFile(path.join(this.directory, "release.json"), "utf8"),
      );
      if (
        !/^[a-f0-9]{64}$/.test(meta.sha256) ||
        !Number.isSafeInteger(meta.assetId)
      )
        throw error(502, "APM 缓存元数据无效");
      const bytes = await fs.readFile(
        path.join(this.directory, `${meta.sha256}.zip`),
      );
      if (sha256(bytes) !== meta.sha256) throw error(502, "APM 缓存校验失败");
      const content = await extractArchive(bytes, new Set(["Plugins.json"]));
      this.current = {
        meta,
        bytes,
        plugins: parseManifest(content.get("Plugins.json")),
      };
    } catch (err) {
      if (err.code !== "ENOENT") this.cacheError = err.message;
    }
  }
  async refresh() {
    const signal = AbortSignal.any([
      this.controller.signal,
      AbortSignal.timeout(120000),
    ]);
    const metadata = JSON.parse(
      (
        await download(
          this.fetcher,
          `https://api.github.com/repos/${REPOSITORY}/releases/tags/${RELEASE_TAG}`,
          2 * MB,
          signal,
        )
      ).toString(),
    );
    const asset = metadata.assets?.find((row) => row.name === "Plugins.zip");
    if (
      !asset ||
      !Number.isSafeInteger(asset.id) ||
      asset.size > 80 * MB ||
      asset.browser_download_url !== ASSET_URL
    )
      throw error(502, "GitHub 发布包元数据无效");
    const digest =
      typeof asset.digest === "string" &&
      /^sha256:[a-f0-9]{64}$/.test(asset.digest)
        ? asset.digest.slice(7)
        : null;
    if (
      this.current?.meta.assetId === asset.id &&
      this.current.meta.updatedAt === asset.updated_at &&
      (!digest || this.current.meta.sha256 === digest)
    ) {
      this.checkedAt = this.now();
      return this.current;
    }
    // Download the selected release asset through GitHub's API. The browser download
    // host may be unreachable even when the API and official asset CDN are accessible.
    const bytes = await download(
      this.fetcher,
      `https://api.github.com/repos/${REPOSITORY}/releases/assets/${asset.id}`,
      80 * MB,
      signal,
      "application/octet-stream",
    );
    const hash = sha256(bytes);
    if (digest && hash !== digest)
      throw error(502, "GitHub 发布包 SHA-256 校验失败");
    const content = await extractArchive(bytes, new Set(["Plugins.json"]));
    const plugins = parseManifest(content.get("Plugins.json"));
    const meta = {
      repository: REPOSITORY,
      tag: RELEASE_TAG,
      assetId: asset.id,
      updatedAt: asset.updated_at,
      sha256: hash,
      digestVerified: !!digest,
      downloadedAt: new Date(this.now()).toISOString(),
    };
    this.controller.signal.throwIfAborted();
    await fs.mkdir(this.directory, { recursive: true });
    // Content-addressed ZIP first; metadata rename commits the matching pair.
    const archive = path.join(this.directory, `${hash}.zip`),
      temp = path.join(this.directory, `${randomUUID()}.tmp`);
    try {
      await fs.writeFile(archive, bytes);
      await fs.writeFile(temp, JSON.stringify(meta));
      this.controller.signal.throwIfAborted();
      await fs.rename(temp, path.join(this.directory, "release.json"));
    } finally {
      await fs.rm(temp, { force: true });
    }
    this.current = { meta, bytes, plugins };
    this.checkedAt = this.now();
    // Requests retain their own byte buffers; obsolete on-disk ZIPs need not accumulate.
    for (const file of await fs.readdir(this.directory).catch(() => []))
      if (/^[a-f0-9]{64}\.zip$/.test(file) && file !== `${hash}.zip`)
        await fs
          .rm(path.join(this.directory, file), { force: true })
          .catch(() => {});
    return this.current;
  }
  async get({ force = false, strict = false, cached = false } = {}) {
    this.controller.signal.throwIfAborted();
    if (cached && this.current) return this.current;
    try {
      if (
        !this.current ||
        force ||
        this.now() - this.checkedAt > 10 * 60 * 1000
      ) {
        this.pending ||= this.refresh().finally(() => {
          this.pending = null;
        });
        await this.pending;
      }
      return {
        ...this.current,
        source: { ...this.current.meta, stale: false },
      };
    } catch (err) {
      this.checkedAt = -Infinity;
      if (strict || !this.current || this.controller.signal.aborted) throw err;
      return {
        ...this.current,
        source: { ...this.current.meta, stale: true, error: err.message },
      };
    }
  }
}
