import { Service } from "@deepseek-ai/cordis";
import { mkdir, readFile, writeFile, rename, rm } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import {
  themes,
  defaults,
  validate,
  collect,
  sample,
  sampleProfile,
} from "./data.js";
import { renderPages } from "./render.js";
export const name = "qq-render";
export const inject = ["paths", "servers", "tshock"];
export class Renderer extends Service {
  constructor(ctx) {
    super(ctx, "qqRenderer");
    this.file = path.join(ctx.paths.dataOf(name), "config.json");
    this.config = defaults();
    this.revision = randomUUID();
    this.tail = Promise.resolve();
    this.active = 0;
    this.cache = null;
  }
  async load() {
    await mkdir(path.dirname(this.file), { recursive: true });
    try {
      const stored = JSON.parse(await readFile(this.file, "utf8"));
      this.config = validate(stored.config);
      this.revision = stored.revision || randomUUID();
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
  }
  publicConfig() {
    return {
      ...this.config,
      addresses: { ...this.config.addresses },
      revision: this.revision,
      themes,
      messageKinds: ["home", "account", "servers", "players"],
    };
  }
  async save(input, revision) {
    await this.ready;
    const job = this.tail.then(async () => {
      if (revision !== this.revision)
        throw Object.assign(new Error("配置已变化，请刷新后重试"), {
          status: 409,
        });
      const next = validate(input, this.config),
        nextRevision = randomUUID(),
        temporary = this.file + "." + randomUUID() + ".tmp";
      try {
        await writeFile(
          temporary,
          JSON.stringify({ config: next, revision: nextRevision }, null, 2) +
            "\n",
          { mode: 0o600, flag: "wx" },
        );
        await rename(temporary, this.file);
      } finally {
        await rm(temporary, { force: true }).catch(() => {});
      }
      this.config = next;
      this.revision = nextRevision;
      this.cache = null;
      return this.publicConfig();
    });
    this.tail = job.catch(() => {});
    return job;
  }
  async snapshot(signal) {
    if (this.cache && this.cache.expiresAt > Date.now()) return this.cache.data;
    const data = await collect(this.ctx, this.config.addresses, signal);
    this.cache = { data, expiresAt: Date.now() + 10000 };
    return data;
  }
  async render(
    kind,
    {
      preview = false,
      theme,
      scenario = "normal",
      signal,
      profile,
      botStatus,
    } = {},
  ) {
    await this.ready;
    theme ??= this.config.theme;
    if (this.active >= 3)
      throw Object.assign(new Error("渲染任务较多，请稍后重试"), {
        status: 429,
      });
    this.active++;
    try {
      if (signal?.aborted) throw signal.reason;
      const data = preview
        ? sample(scenario)
        : kind === "account"
          ? { rows: [], generatedAt: new Date().toISOString(), sample: false }
          : await this.snapshot(signal);
      const images = await renderPages(data, kind, theme, {
        profile: preview ? sampleProfile(scenario) : profile,
        botStatus: preview ? { connected: true } : botStatus,
      });
      return {
        images,
        text:
          {
            home: "机器人主页",
            account: "账号服务",
            players: "全服在线玩家",
            servers: "服务器列表",
          }[kind] +
          " · " +
          themes.find((value) => value.id === theme)?.name,
        data,
      };
    } finally {
      this.active--;
    }
  }
}
export async function apply(ctx) {
  const service = new Renderer(ctx);
  service.ready = service.load();
  ctx.qqRenderer = service;
  ctx.effect(
    () => () => {
      service.cache = null;
    },
    "qq-render:cache",
  );
  await service.ready;
}
