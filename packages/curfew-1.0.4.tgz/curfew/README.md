# 宵禁管理 curfew

独立 Cordis 插件，包含 Vue 页面、宿主 API 和游戏服 `TsWebCurfew.dll`。入口：更多插件 → 宵禁管理（`/s/curfew`）。采用已选的方案 1「分类双区」。

## 界面

- 长期循环：紫色实线排期条，每日重复；每天相同的开始和结束时间表示全天。
- 指定日期：青色斜纹排期条，完整展示开始和结束日期，到期自动关闭。
- 两区独立添加规则，支持编辑、启停、删除确认、单条豁免组和提示消息。
- 按游戏服返回的本地日期选择预览晚上 18:00 至次日 10:00。排期条只展示窗口交集，白天及超出窗口的时间以文字为准。
- 最终限制条合并所有启用规则的重叠和相邻区间；标注日期排期是否扩展了长期限制。
- 默认豁免组和消息独立设置；空规则组继承默认，默认组留空表示无豁免。默认消息和单条消息留空时分别回退到内置消息和默认消息。
- 草稿预览与读取时的实际状态明确区分。显式保存，未保存离开提示，失败保留草稿，切服隔离旧响应；支持深浅主题和手机宽度。

正式页面只读取游戏服配置，不注入示例规则。浏览器预览脚本中的测试数据仅用于本地界面验收。

## 游戏行为

时间以游戏服本地 `DateTime.Now` 为准，包含开始，不包含结束。`ServerJoin` 以最高优先级检查；宵禁期间放行的玩家在登录后按真实用户组复查，宵禁前已经在线的玩家不受影响。进服时尚未生成玩家对象的连接记录到登录复查，并输出警告；并非所有连接阶段都保证立即获得玩家对象。

延续旧版用户组语义：已登录玩家使用当前组，否则按角色名查账号组，无账号回退默认访客组。当前生效规则的豁免组取并集，组名不区分大小写。每条规则有非空独立组时覆盖默认组。

拦截消息支持 `{now}`、`{date}`、`{weekday}`、`{startTime}`、`{endTime}`、`{timeLeft}`、`{allowedGroups}`、`{curfewName}`、`{serverName}`。优先使用配置顺序中首条当前生效规则的消息；恢复时间使用连续限制区间的最终结束，涵盖稍后生效并接续当前限制的排期。全天循环或多条循环合计覆盖全天时显示持续限制，不虚构恢复时间。

到期排期每 30 秒自动停用并保存；每次入服始终直接按当前时间判定，不等待定时器。到期标记不依赖启停状态。自动保存失败时显示警告，结束时间依然会停止拦截。

命令权限 `tshock.admin`，兼容 `/curfew` 和 `/宵禁`：

```text
/curfew status
/curfew list
/curfew on 名称或ID
/curfew off 名称或ID
/curfew del 名称或ID
/curfew add 名称 HH:mm HH:mm [daily|once]
```

`once` 命令从游戏服当天开始，结束不晚于开始时延至次日；更复杂日期使用页面。重名规则须使用唯一 ID。

## 配置与权限

当前配置规则：只读取本版本配置；缺失时使用默认值，不读取、复制、备份或转换旧版配置。旧版导入统一由 legacy-import 插件显式执行。

保存使用 SHA-256 配置版本检查，冲突返回 409；临时文件写盘成功后替换正式文件并发布新快照。`/reload` 失败时保留上次有效配置并告警。宿主不保存第二份配置，也不定时覆盖游戏服。

网页管理模块 `curfew.manage` 默认授予 `superadmin` 和 `admin`，同时约束服务器范围，其他账号可按模块显式授权。游戏服 REST 令牌需要 `tsweb.curfew.manage`。

宿主 API：`GET/POST /api/curfew/config`。POST 为 `{ config, expectedRevision }`。游戏端为 `/data/curfew/config` 和 `/data/curfew/config/set`，支持表单 POST。旧版 `TShockData.Curfew` 同时加载时，独立插件暂停拦截及配置写入并提示冲突，防止双模块重复工作。

## 开发验证

在 Cordis 仓库根目录运行：

```powershell
node --test plugins/curfew/test/*.test.mjs
node scripts/build-client.mjs curfew
dotnet build plugins/curfew/plugin/TsWebCurfew.csproj -c Release -o tmp/curfew-build
node plugins/curfew/test/browser.mjs
npm run check:access
npm run test:auth
npm run test:client
```

`browser.mjs --serve` 保留隔离的交互预览，终端打印地址；页面明确标记测试数据，不连接游戏服。可通过 `PLAYWRIGHT_MODULE` 指定 Playwright ESM 路径；默认使用本机 Codex 依赖和 Edge。截图保存在 `tmp/curfew-preview/`，覆盖深浅主题及 1280、390、320 像素。

测试覆盖生产 C# 调度与写盘、旧配置迁移、进服和登录复查、已有在线玩家、REST 版本冲突、生命周期清理、模块权限与服务器范围，以及 Vue 编辑和切服行为。C# 桩测试和真实依赖编译均已执行；尚未在真实游戏服验证玩家连接。

正式打包可运行 `node scripts/pack-plugin.mjs curfew --out tmp/curfew-release`。安装和目标服务器启用应通过现有插件管理流程执行。
