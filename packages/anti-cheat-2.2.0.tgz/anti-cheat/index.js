import accessContract from './access.js'
/**
 * anti-cheat 插件（宿主半）—— 旧版还原
 *
 * ══════════ 本文件的来源与忠实度约定 ══════════
 * 本件是旧版后端两条链路的**原样移植**，不新增、不删减任何对外行为：
 *
 *   1. `TsWeb/backend/routes/antiCheatRoutes.js`（223 行）
 *      → 本件的 /api/anticheat/* 全部路由；路径、方法、请求体字段、响应形状逐字对齐。
 *        旧版响应一律带 `status` 字符串字段（'200'/'400'/'500'/'502'），前端
 *        `antiCheatApi.js` 就是按 `data.status === 200 || data.status === '200'` 判断的，
 *        所以**绝不能**改成 cordis 其他插件的 `{success:...}` 形状。
 *
 *   2. `TsWeb/backend/services/anticheatDefaults.js`（109 行）
 *      → 本件的 getDefaultConfig / getDefaultConfigEnabled / hasEffectiveConfig /
 *        pushDefaultToPlugin / enableAntiCheat 五个函数，逻辑逐字对齐。
 *
 * ══════════ 与旧版的差异（架构所致，已在注释中逐处标明） ══════════
 * 1. 目标服务器来源：旧版经 `tshockService.proxyDataRequest(...)` 打到「当前服务器」
 *    （x-server-id 头）；本插件改用 cordis 的 `ctx.tshock.fetchFor/postFor`，
 *    服务器由 `ctx.servers.getRaw()` 解析（仍优先读 x-server-id 头）。
 * 2. HTTP 动词与传参位置**严格对齐旧版**（见下），这是容易被想当然写错的地方：
 *    旧版把参数一律放在 **URL query**，而非 form body，实测游戏服只读 query。
 *
 * ══════════ 插件端端点与旧版实际请求形状（源：tshockService.js:1170-1530） ══════════
 * 见旧版 `TsWeb/plugin/Main.cs` 的 /data/anticheat/* 注册块：
 *   /data/anticheat/item-config/getitemconfig    GET                       （:1244）
 *   /data/anticheat/item-config/saveitemconfig   POST + ?config=<json>     （:1281）
 *   /data/anticheat/item-config/scanall          GET                       （:1492）
 *   /data/anticheat/item-config/scan-by-id       GET  + ?itemId=           （:1529）
 *   /data/anticheat/proj-config/getprojconfig    GET                       （:1170）
 *   /data/anticheat/proj-config/saveprojconfig   POST + ?config=<json>     （:1207）
 *   /data/anticheat/enable                       POST + ?itemEnabled=true  （:1435）
 *   /data/anticheat/logs                         GET  + 筛选参数           （:190 路由）
 *   /data/anticheat/logs/stats                   GET
 *   /data/bugfix                                 GET                       （:1318）
 *   /data/bugfix/set                             POST + ?enabled=... 等    （:1355-1364）
 *   /data/anticheat/proj-config/saveprojconfig   POST
 *   /data/anticheat/enable                       POST
 *   /data/anticheat/logs                         GET
 *   /data/anticheat/logs/stats                   GET
 *   /data/bugfix                                 GET
 *   /data/bugfix/set                             POST
 *
 * 约定：禁止 emoji；中文注释；引用位置写 `文件:行号`。
 */
import { Service } from '@deepseek-ai/cordis'
import { readFileSync, existsSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

export const name = 'anti-cheat'
// tshock 必须声明：本插件的全部转发都走 ctx.tshock.fetchFor/postFor。
// 漏掉它时 cordis 会在访问 ctx.tshock 抛 "cannot get property \"tshock\" without inject"，
// 表现为所有 /api/anticheat/* 一律 500（已由启动实测捕获）。
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths']

/** 默认配置资源目录（本插件 resources/，逐字节取自旧版 backend/resources/默认配置/） */
const defaultsDir = path.join(__dirname, 'resources')

const DEFAULT_FILES = {
  item: '物品违禁.json',
  proj: '弹幕违禁.json',
}

// ═══════════════════════════════════════════════════════════
// 默认配置（对应旧版 anticheatDefaults.js:16-31）
// ═══════════════════════════════════════════════════════════

/** 读取后端内置默认配置（未启用状态，作为模板） */
export function getDefaultConfig(kind) {
  const file = DEFAULT_FILES[kind]
  if (!file) throw new Error(`未知配置类型: ${kind}`)
  const filePath = path.join(defaultsDir, file)
  if (!existsSync(filePath)) {
    throw new Error(`默认配置缺失: ${filePath}`)
  }
  return JSON.parse(readFileSync(filePath, 'utf8'))
}

/** 读取后端内置默认配置并将 启用 置为 true（下发时启用） */
export function getDefaultConfigEnabled(kind) {
  const config = getDefaultConfig(kind)
  config['启用'] = true
  return config
}

/**
 * 判断插件端当前配置是否「无有效限制」（无任何进度组或所有组均为空）
 * 对应旧版 anticheatDefaults.js:34-53。
 */
export async function hasEffectiveConfig(ctx, server, kind) {
  const data = kind === 'item'
    ? await getItemConfig(ctx, server)
    : await getProjConfig(ctx, server)

  if (!data || data.error) {
    // 插件不可达/无配置 → 视为无配置
    return false
  }
  // 兼容后端透传包装 { config: {...} }
  const config = data.config && !Array.isArray(data.config) ? data.config : data
  const list = config['限制列表'] ?? config.restrictions ?? []
  if (!Array.isArray(list) || list.length === 0) return false
  // 所有进度组的限制均为空 → 视为无配置
  const key = kind === 'item' ? '限制物品' : '限制弹幕'
  return list.some(group => {
    const items = group?.[key] ?? group?.items ?? group?.projectiles ?? []
    return Array.isArray(items) && items.length > 0
  })
}

/**
 * 将后端默认配置下发到插件端（启用=true）。
 * 默认仅当插件端无有效限制时执行；已有配置则不覆盖（返回 skipped）。
 * force=true 时跳过该判断，强制以权威默认覆盖插件端清单
 * 对应旧版 anticheatDefaults.js:61-83。
 */
export async function pushDefaultToPlugin(ctx, server, kind, force = false) {
  if (!server || !server.id) {
    return { status: 'error', error: '当前服务器未连接或未配置' }
  }

  if (!force) {
    const alreadyConfigured = await hasEffectiveConfig(ctx, server, kind)
    if (alreadyConfigured) {
      return { status: 'skipped', message: '插件端已有配置，未覆盖' }
    }
  }

  const defaultConfig = getDefaultConfigEnabled(kind)
  const result = kind === 'item'
    ? await saveItemConfig(ctx, server, defaultConfig)
    : await saveProjConfig(ctx, server, defaultConfig)

  if (result && result.error) {
    return { status: 'error', error: result.error }
  }
  return { status: 'ok', message: '默认配置已下发', enabled: true }
}

/**
 * 打开反作弊统一入口：
 *  - 插件端无有效配置 → 下发后端默认配置（启用=true）
 *  - 插件端已有配置 → 仅翻转启用开关（调用插件 /data/anticheat/enable）
 * 对应旧版 anticheatDefaults.js:90-109。
 */
export async function enableAntiCheat(ctx, server, kind) {
  if (!server || !server.id) {
    return { status: 'error', error: '当前服务器未连接或未配置' }
  }

  const alreadyConfigured = await hasEffectiveConfig(ctx, server, kind)
  if (!alreadyConfigured) {
    return await pushDefaultToPlugin(ctx, server, kind)
  }

  // 已有配置 → 仅启用开关（旧版 anticheatDefaults.js:90-109 传 itemEnabled/projEnabled）
  const flag = kind === 'item' ? 'itemEnabled' : 'projEnabled'
  const result = await setAntiCheatEnabled(ctx, server, flag, true)
  if (result && result.error) {
    return { status: 'error', error: result.error }
  }
  return { status: 'ok', message: '已启用现有配置', enabled: true }
}

// ═══════════════════════════════════════════════════════════
// 插件端调用（严格对齐旧版 tshockService.js 的请求形状）
// ═══════════════════════════════════════════════════════════
//
// 关键（曾在此处写错并被启动实测捕获）：
// 旧版一律把参数放在 **URL query**，几乎全是 GET；只有 save*/enable/bugfix-set 用 POST，
// 但它们的参数**同样在 query**（见 TsWeb/backend/services/tshockService.js:1170-1530）。
// 实测：把参数放进 form body 时，游戏服收到的是空值
// （/data/anticheat/item-config/scan-by-id 回 "收到「」"），因为 TShock 的
// SecureRestCommand 只读 Request.Parameters，而该集合在本服实现下取不到 form body。
// 因此这里全部改用 query 传参，POST 仅用 postFor 的 opts 走 query（body 传 {}）。

/** 把对象拼成 query 字符串（跳过 undefined/null），供 postFor 的 pathname 使用 */
function toQueryString(params) {
  const usp = new URLSearchParams()
  for (const [k, v] of Object.entries(params || {})) {
    if (v !== undefined && v !== null) usp.set(k, String(v))
  }
  return usp.toString()
}

/**
 * 带 query 的 POST。
 * 为什么不用 postFor 的 body：旧版这些端点把参数放在 **URL query**，
 * 而 postFor 只支持 body（见 servers/index.js:238-256，opts 无 query 项）。
 * 故这里把 query 拼进 pathname，再让 postFor 发一个空 form body，等价于旧版请求。
 */
async function postQuery(ctx, server, pathname, params) {
  const qs = toQueryString(params)
  const path = qs ? `${pathname}?${qs}` : pathname
  return ctx.tshock.postFor(server, path, {}, {})
}

/**
 * 「反作弊插件在这台服上没有接口」的专用状态。
 *
 * 常见成因是：反作弊 DLL 没有声明 `TsWeb.BeforeWorld=1`，下发后文件先暂存，要等世界
 * 启动后的首次游戏线程才 Initialize() 并注册 `/data/anticheat*`、`/data/bugfix*`；在那
 * 之前游戏服对它们一律回 TShock 的通用 404（`Specified API endpoint doesn't exist...`）。
 * 另一种成因是服上跑的是旧版 DLL、根本没有这个接口。两者在线上表现一样，所以文案把
 * 「先启动世界」放在首位、并保留「版本过旧就重新下发」这条退路，不硬说成某一种。
 *
 * 状态码/错误码/文案与前端共用 activation-contract.js：两边各写一份的话，改了一处前端
 * 就认不出后端的失败（review 里实际踩到），所以这里改成单一来源再转出。
 */
import {
  ACTIVATION_CODE as ACTIVATION_CODE_VALUE,
  ACTIVATION_MESSAGE as ACTIVATION_MESSAGE_VALUE,
  ACTIVATION_STATUS as ACTIVATION_STATUS_VALUE,
} from './activation-contract.js'

export const ACTIVATION_STATUS = ACTIVATION_STATUS_VALUE
export const ACTIVATION_CODE = ACTIVATION_CODE_VALUE
export const ACTIVATION_MESSAGE = ACTIVATION_MESSAGE_VALUE

const NOT_FOUND_TEXT = /Specified API endpoint doesn't exist/i

/** 上游是否在说"这个端点不存在"（= 插件没运行 / 没激活 / 版本里没这个接口）。 */
export function pendingActivation(result) {
  if (!result) return false
  if (Number(result.status) === ACTIVATION_STATUS) return true
  if (Number(result.status) === 404) return true
  const text = String(result.data?.error || result.data?.message || result.data?.response || '')
  return NOT_FOUND_TEXT.test(text)
}

function pendingActivationError() {
  const error = new Error(ACTIVATION_MESSAGE)
  error.status = ACTIVATION_STATUS
  error.code = ACTIVATION_CODE
  return error
}

/** 统一的失败响应：等待激活回 424，其余保持原有的 500/502。 */
function fail(res, json, error, code = 500) {
  const pending = Number(error?.status) === ACTIVATION_STATUS
  const status = pending ? ACTIVATION_STATUS : code
  return json(res, status, {
    status: String(status),
    ...(pending ? { code: ACTIVATION_CODE } : {}),
    error: error?.message || '反作弊接口调用失败',
  })
}

function configResponse(result) {
  if (pendingActivation(result)) throw pendingActivationError()
  const data = result?.data
  if (!result || result.ok === false || Number(result.status) >= 400 || !data ||
      data.error || data.success === false || Number(data.status) >= 400)
    throw new Error(data?.error || data?.message || '游戏服反作弊配置接口未返回成功结果')
  let nested = data
  for (let depth = 0; nested?.config && depth < 5; depth++) {
    nested = nested.config
    if (nested.error || nested.success === false || Number(nested.status) >= 400)
      throw new Error(nested.error || nested.message || '游戏服反作弊配置读取失败')
  }
  return data
}

async function getItemConfig(ctx, server) {
  const r = await ctx.tshock.fetchFor(server, '/data/anticheat/item-config/getitemconfig')
  return configResponse(r)
}

async function getProjConfig(ctx, server) {
  const r = await ctx.tshock.fetchFor(server, '/data/anticheat/proj-config/getprojconfig')
  return configResponse(r)
}

// save*：旧版 POST + ?config=<整份 JSON>（tshockService.js:1207 / :1281）
async function saveItemConfig(ctx, server, config) {
  const r = await postQuery(ctx, server, '/data/anticheat/item-config/saveitemconfig', {
    config: JSON.stringify(config),
  })
  return configResponse(r)
}

async function saveProjConfig(ctx, server, config) {
  const r = await postQuery(ctx, server, '/data/anticheat/proj-config/saveprojconfig', {
    config: JSON.stringify(config),
  })
  return configResponse(r)
}

// enable：旧版 POST + ?itemEnabled=true / ?projEnabled=true（tshockService.js:1435）
async function setAntiCheatEnabled(ctx, server, flag, value) {
  const r = await postQuery(ctx, server, '/data/anticheat/enable', { [flag]: String(value) })
  return configResponse(r)
}

// scanall：旧版 **GET**（tshockService.js:1492）
async function scanAllItems(ctx, server) {
  const r = await ctx.tshock.fetchFor(server, '/data/anticheat/item-config/scanall')
  if (pendingActivation(r)) throw pendingActivationError()
  return r.data
}

// scan-by-id：旧版 **GET** + ?itemId=（tshockService.js:1529）
async function scanItemById(ctx, server, itemId, scope = 'online') {
  const r = await ctx.tshock.fetchFor(server, '/data/anticheat/item-config/scan-by-id', { itemId, scope }, { timeoutMs: scope === 'all' ? 30000 : 5000 })
  if (pendingActivation(r)) throw pendingActivationError()
  if (!r.ok) throw new Error(r.data?.error || r.data?.response || `搜索失败（HTTP ${r.status}）`)
  return r.data
}

/**
 * 统一处理游戏服日志响应：旧 DLL 返回 status，旧版/部分 DLL 只返回数据。
 * 只有 HTTP 成功且业务 status 未明确失败时才补 status=200，避免把 HTTP 500
 * 或插件返回的 { status: 500 } 伪装成成功。
 */
export function normalizeLogResponse(result) {
  if (pendingActivation(result)) {
    return { status: String(ACTIVATION_STATUS), code: ACTIVATION_CODE, error: ACTIVATION_MESSAGE }
  }
  const payload = result?.data
  const httpStatus = Number(result?.status ?? 200)
  if (!result || result.ok === false || httpStatus < 200 || httpStatus >= 300) {
    return { status: '500', error: payload?.error || `游戏服日志接口返回 HTTP ${httpStatus}` }
  }
  if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
    const businessStatus = payload.status
    if (payload.error || (businessStatus !== undefined && businessStatus !== 200 && businessStatus !== '200')) {
      return { ...payload, status: businessStatus === undefined || businessStatus === 200 || businessStatus === '200' ? '500' : String(businessStatus), error: payload.error || '日志接口返回失败' }
    }
    return { ...payload, status: '200' }
  }
  return { status: '500', error: '日志接口响应格式无效' }
}

// ═══════════════════════════════════════════════════════════
// 服务：目标服务器解析（旧版靠 x-server-id 头，本件靠 ctx.servers）
// ═══════════════════════════════════════════════════════════

class AntiCheatService extends Service {
  constructor(ctx) {
    super(ctx, 'antiCheat')
    this.ctx = ctx
  }

  /**
   * 取本次请求的目标服务器。
   * 旧版由 `getCurrentServer()`（x-server-id 请求级上下文）决定；本件读请求头
   * `x-server-id` → 找不到则回退到唯一一台启用服（与旧版"当前服务器"语义一致：
   * 前端 utils/api.js 会自动带 x-server-id）。
   */
  async resolveServer(req) {
    const wantId = req?.headers?.['x-server-id'] || req?.headers?.['X-Server-Id']
    // 必须用 getRaw：list() 经 sanitize() 脱敏，**不含 token**，
    // 而 fetchFor/postFor 需要 token 才能调通游戏服 REST（servers/index.js:700-711,814）。
    const all = await this.ctx.servers.list()
    const enabled = all
      .filter((s) => s.enabled !== false)
      .map((s) => this.ctx.servers.getRaw(s.id))
      .filter(Boolean)

    if (wantId) {
      const hit = enabled.find((s) => String(s.id) === String(wantId))
      return hit || null
    }
    if (enabled.length === 1) return enabled[0]
    if (enabled.length === 0) return null
    // 多台且未指定：旧版语义是"当前服务器"，本件无该上下文，如实报错而不是随便挑一台
    return null
  }
}

// ═══════════════════════════════════════════════════════════
// 路由（逐条对应旧版 antiCheatRoutes.js）
// ═══════════════════════════════════════════════════════════

export async function apply(ctx) {
  const svc = new AntiCheatService(ctx)
  const app = ctx.auth.access.policyApp(ctx.webServer.app, accessContract, ctx)

  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireServerManager()]

  const json = (res, code, body) => res.status(code).json(body)

  /** 取目标服务器；拿不到就回旧版同款错误形状 */
  const needServer = async (req, res) => {
    const server = await svc.resolveServer(req)
    if (!server) {
      json(res, 500, { status: '500', error: '没有可用的启用中服务器（或未指定 x-server-id）' })
      return null
    }
    return server
  }

  // ── POST /api/anticheat/enable（旧版 :14-28）──
  app.post('/api/anticheat/enable', ...admin, async (req, res) => {
    const { item, proj, itemEnabled, projEnabled } = req.body || {}
    if ([item, proj, itemEnabled, projEnabled].some(value => value !== undefined && typeof value !== 'boolean') ||
        (item !== undefined && itemEnabled !== undefined) || (proj !== undefined && projEnabled !== undefined))
      return json(res, 400, { status: '400', error: '反作弊开关须为布尔值，且不能重复指定' })
    if (!item && !proj && itemEnabled === undefined && projEnabled === undefined) {
      return json(res, 400, { status: '400', error: '缺少 item / proj 启用标记' })
    }
    const server = await needServer(req, res)
    if (!server) return
    const results = {}
    try {
      for (const [kind, value] of [['item', itemEnabled ?? (item ? true : undefined)], ['proj', projEnabled ?? (proj ? true : undefined)]]) {
        if (value === undefined) continue
        if (value) results[kind] = await enableAntiCheat(ctx, server, kind)
        else {
          await setAntiCheatEnabled(ctx, server, `${kind}Enabled`, false)
          results[kind] = { status: 'ok', enabled: false }
        }
      }
      const failed = Object.values(results).some(r => r?.status === 'error')
      res.status(failed ? 502 : 200).json({ status: failed ? '502' : '200', results })
    } catch (err) {
      fail(res, json, err)
    }
  })

  // ── POST /api/anticheat/apply-defaults（旧版 :33-49）──
  app.post('/api/anticheat/apply-defaults', ...admin, async (req, res) => {
    const { item, proj, force } = req.body || {}
    const kinds = []
    if (item) kinds.push('item')
    if (proj) kinds.push('proj')
    if (kinds.length === 0) {
      return json(res, 400, { status: '400', error: '缺少 item / proj 标记' })
    }
    const server = await needServer(req, res)
    if (!server) return
    const results = {}
    try {
      for (const kind of kinds) results[kind] = await pushDefaultToPlugin(ctx, server, kind, !!force)
      const failed = Object.values(results).some(r => r?.status === 'error')
      res.status(failed ? 502 : 200).json({ status: failed ? '502' : '200', results })
    } catch (err) {
      fail(res, json, err)
    }
  })

  // 重置每次读取包内默认配置并下发，不受“已有有效配置则跳过”的启用逻辑影响。
  app.post('/api/anticheat/reset-defaults', ...admin, async (req, res) => {
    const kind = req.body?.kind
    if (!['item', 'proj', 'damage'].includes(kind))
      return json(res, 400, { status: '400', error: '无效的重置类型' })
    const server = await needServer(req, res)
    if (!server) return
    try {
      let config
      if (kind === 'damage') {
        const read = await ctx.tshock.fetchFor(server, '/data/anticheat/proj-config/getprojconfig')
        if (pendingActivation(read)) throw pendingActivationError()
        if (read.ok === false || Number(read.status) >= 400)
          throw new Error(read.data?.error || read.data?.response || '读取弹幕配置失败')
        config = read.data
        for (let depth = 0; depth < 4 && config?.config; depth++) {
          if (config.error || Number(config.status) >= 400) throw new Error(config.error || config.message || '读取弹幕配置失败')
          config = config.config
        }
        if (!config || Array.isArray(config) || typeof config !== 'object' || config.error || Number(config.status) >= 400 || config.config)
          throw new Error(config?.error || '读取弹幕配置失败')
        const limit = getDefaultConfig('proj')['伤害上限']
        config = { ...config, '伤害上限': limit }
        if (Object.hasOwn(config, 'damageLimit')) config.damageLimit = limit
      } else {
        config = getDefaultConfigEnabled(kind)
      }
      const response = await postQuery(ctx, server, kind === 'item' ? '/data/anticheat/item-config/saveitemconfig' : '/data/anticheat/proj-config/saveprojconfig', { config: JSON.stringify(config) })
      const result = response.data
      if (response.ok === false || Number(response.status) >= 400 || !result || result.error || result.success === false || Number(result.status) >= 400)
        return json(res, 502, { status: '502', error: result?.error || result?.response || result?.message || '默认配置下发失败' })
      res.json({ status: '200', config })
    } catch (error) {
      fail(res, json, error)
    }
  })

  // ── GET /api/anticheat/config（旧版 :51-63）──
  app.get('/api/anticheat/config', ...admin, async (req, res) => {
    const server = await needServer(req, res)
    if (!server) return
    try {
      const data = await getItemConfig(ctx, server)
      if (data && data.error) return json(res, 500, { status: '500', error: data.error })
      res.json({ status: '200', config: data })
    } catch (error) {
      fail(res, json, error)
    }
  })

  // ── GET /api/anticheat/proj-config（旧版 :65-77）──
  app.get('/api/anticheat/proj-config', ...admin, async (req, res) => {
    const server = await needServer(req, res)
    if (!server) return
    try {
      const data = await getProjConfig(ctx, server)
      if (data && data.error) return json(res, 500, { status: '500', error: data.error })
      res.json({ status: '200', config: data })
    } catch (error) {
      fail(res, json, error)
    }
  })

  // ── POST /api/anticheat/proj-config（旧版 :79-96）──
  app.post('/api/anticheat/proj-config', ...admin, async (req, res) => {
    const config = req.body
    if (!config) return json(res, 400, { status: '400', error: 'Missing config data' })
    const server = await needServer(req, res)
    if (!server) return
    try {
      const data = await saveProjConfig(ctx, server, config)
      if (data && data.error) return json(res, 500, { status: '500', error: data.error })
      res.json({ status: '200', message: 'Projectile config saved successfully' })
    } catch (error) {
      fail(res, json, error)
    }
  })

  // ── GET /api/anticheat/item-config（旧版 :98-110）──
  app.get('/api/anticheat/item-config', ...admin, async (req, res) => {
    const server = await needServer(req, res)
    if (!server) return
    try {
      const data = await getItemConfig(ctx, server)
      if (data && data.error) return json(res, 500, { status: '500', error: data.error })
      res.json({ status: '200', config: data })
    } catch (error) {
      fail(res, json, error)
    }
  })

  // ── POST /api/anticheat/item-config（旧版 :112-129）──
  app.post('/api/anticheat/item-config', ...admin, async (req, res) => {
    const config = req.body
    if (!config) return json(res, 400, { status: '400', error: 'Missing config data' })
    const server = await needServer(req, res)
    if (!server) return
    try {
      const data = await saveItemConfig(ctx, server, config)
      if (data && data.error) return json(res, 500, { status: '500', error: data.error })
      res.json({ status: '200', message: 'Item config saved successfully' })
    } catch (error) {
      fail(res, json, error)
    }
  })

  // Item abuse protection has its own config; it is independent of BugFixes.Enabled.
  const abuseFields = { multiChest: 'boolean', itemFlood: 'boolean', dropRateLimit: 'boolean', fishingReelLimit: 'boolean',
    rangeViolationThreshold: 10000, rangeDistanceTiles: 1000, dropsPerSecond: 10000, fishingReelIntervalMs: 60000 }
  const abuseResponse = (res, r) => {
    if (pendingActivation(r))
      return json(res, ACTIVATION_STATUS, { status: String(ACTIVATION_STATUS), code: ACTIVATION_CODE, error: ACTIVATION_MESSAGE })
    const data = r?.data
    if (!r || r.ok === false || Number(r.status) >= 400 || !data || data.error || data.success === false || String(data.status) !== '200')
      return json(res, 502, { status: '502', error: data?.error || '游戏服物品与多箱保护接口不可用，请更新 AntiCheat.dll' })
    return res.json({ status: '200', config: data })
  }
  app.get('/api/anticheat/item-abuse', ...admin, async (req, res) => {
    const server = await needServer(req, res)
    if (!server) return
    try { return abuseResponse(res, await ctx.tshock.fetchFor(server, '/data/anticheat/item-abuse')) }
    catch (error) { return fail(res, json, error, 502) }
  })
  app.post('/api/anticheat/item-abuse/set', ...admin, async (req, res) => {
    const body = req.body
    if (!body || typeof body !== 'object' || Array.isArray(body) || !Object.keys(body).length
      || Object.entries(body).some(([key, value]) => !Object.hasOwn(abuseFields, key)
        || (abuseFields[key] === 'boolean' ? typeof value !== 'boolean'
          : !Number.isInteger(value) || value < 1 || value > abuseFields[key])))
      return json(res, 400, { status: '400', error: '保护开关必须为布尔值，次数为 1–10000 的整数，距离为 1–1000 格，渔获间隔为 1–60000 毫秒的整数' })
    const server = await needServer(req, res)
    if (!server) return
    try { return abuseResponse(res, await postQuery(ctx, server, '/data/anticheat/item-abuse/set', body)) }
    catch (error) { return fail(res, json, error, 502) }
  })

  // ── GET /api/anticheat/bugfix（旧版 :133-145）──
  app.get('/api/anticheat/bugfix', ...admin, async (req, res) => {
    const server = await needServer(req, res)
    if (!server) return
    try {
      const r = await ctx.tshock.fetchFor(server, '/data/bugfix')
      res.json({ status: '200', config: configResponse(r) })
    } catch (error) {
      fail(res, json, error)
    }
  })

  // ── POST /api/anticheat/bugfix/set（旧版 :147-164）──
  app.post('/api/anticheat/bugfix/set', ...admin, async (req, res) => {
    const { enabled, chestFix, minionLimit, bossSummonConditions, mapRevealDetection, autoBuildDetection, lightning, particleBlacklistKick, particleWhitelistReview } = req.body || {}
    if (enabled === undefined && chestFix === undefined &&
        minionLimit === undefined && bossSummonConditions === undefined && mapRevealDetection === undefined && autoBuildDetection === undefined && lightning === undefined &&
        particleBlacklistKick === undefined && particleWhitelistReview === undefined) {
      return json(res, 400, { status: '400', error: '缺少开关参数（enabled/chestFix/minionLimit/bossSummonConditions/mapRevealDetection/autoBuildDetection/particleBlacklistKick/particleWhitelistReview）' })
    }
    const server = await needServer(req, res)
    if (!server) return
    try {
      // 旧版只传已给出的开关（缺省参数保持插件原值），
      // 且参数走 **query**（tshockService.js:1355-1364），故用 postQuery。
      const params = {}
      if (enabled !== undefined) params.enabled = enabled
      if (chestFix !== undefined) params.chestFix = chestFix
      if (minionLimit !== undefined) params.minionLimit = minionLimit
      if (bossSummonConditions !== undefined) params.bossSummonConditions = bossSummonConditions
      if (autoBuildDetection !== undefined) params.autoBuildDetection = autoBuildDetection
      if (mapRevealDetection !== undefined) params.mapRevealDetection = mapRevealDetection
      if (lightning !== undefined) params.lightning = lightning
      if (particleBlacklistKick !== undefined) params.particleBlacklistKick = particleBlacklistKick
      if (particleWhitelistReview !== undefined) params.particleWhitelistReview = particleWhitelistReview
      const r = await postQuery(ctx, server, '/data/bugfix/set', params)
      res.json({ status: '200', message: 'BugFixes 配置已保存', config: configResponse(r) })
    } catch (error) {
      fail(res, json, error)
    }
  })

  // ── POST /api/anticheat/check-anomaly（旧版 :166-183）──
  app.post('/api/anticheat/check-anomaly', ...admin, async (req, res) => {
    const { id, stack } = req.body || {}
    if (id === undefined || stack === undefined) {
      return res.json({ status: '400', error: 'Missing parameters' })
    }
    const server = await svc.resolveServer(req)
    if (!server) return res.json({ status: '200', isAnomaly: false, itemName: null })
    try {
      // 旧版走 /data/anticheat/check-anomaly?id=&stack=，但**该端点未在 C# 端注册**
      // （见 TsWeb/plugin/Main.cs 的 anticheat 注册块，无 check-anomaly）。
      // 本件改用已注册的 /data/anticheat/item-config/scan-by-id（GET + ?itemId=），
      // 语义等价：按物品 id 判定是否违禁并回物品名，前端只读 isAnomaly/itemName。
      const r = await scanItemById(ctx, server, id)
      const data = r.data || {}
      res.json({
        status: '200',
        isAnomaly: data.isAnomaly || false,
        itemName: data.itemName || null,
      })
    } catch (error) {
      res.json({ status: '200', isAnomaly: false, itemName: null })
    }
  })

  // ── GET /api/anticheat/logs（旧版 :190-206）──
  app.get('/api/anticheat/logs', ...admin, async (req, res) => {
    const params = {}
    for (const k of ['page', 'pageSize', 'player', 'category', 'method', 'timeFrom', 'timeTo', 'q', 'players', 'playerMode', 'categories', 'categoryMode', 'hideBanned']) {
      if (req.query[k] !== undefined && req.query[k] !== '') params[k] = req.query[k]
    }
    const server = await needServer(req, res)
    if (!server) return
    try {
      const r = await ctx.tshock.fetchFor(server, '/data/anticheat/logs', params)
      const data = normalizeLogResponse(r)
      if (data.status !== '200') return json(res, Number(data.status) === ACTIVATION_STATUS ? ACTIVATION_STATUS : 502, data)
      res.json(data)
    } catch (error) {
      fail(res, json, error)
    }
  })

  // ── GET /api/anticheat/logs/stats（旧版 :209-221）──
  app.get('/api/anticheat/logs/stats', ...admin, async (req, res) => {
    const server = await needServer(req, res)
    if (!server) return
    try {
      const r = await ctx.tshock.fetchFor(server, '/data/anticheat/logs/stats', {})
      const data = normalizeLogResponse(r)
      if (data.status !== '200') return json(res, Number(data.status) === ACTIVATION_STATUS ? ACTIVATION_STATUS : 502, data)
      res.json(data)
    } catch (error) {
      fail(res, json, error)
    }
  })

  // ── POST /api/tshock/itemscan（旧版前端 antiCheatApi.scanItems）──
  app.post('/api/tshock/itemscan', ...admin, async (req, res) => {
    const server = await needServer(req, res)
    if (!server) return
    try {
      // 旧版 scanAllItems 是 **GET**（tshockService.js:1492）
      const data = await scanAllItems(ctx, server)
      res.json(data)
    } catch (error) {
      fail(res, json, error)
    }
  })

  // ── POST /api/tshock/itemscan-by-id（旧版前端 antiCheatApi.scanItemById）──
  app.post('/api/tshock/itemscan-by-id', ...admin, async (req, res) => {
    const { itemId } = req.body || {}
    const server = await needServer(req, res)
    if (!server) return
    try {
      // 旧版 scanItemById 是 **GET** + ?itemId=（tshockService.js:1529）
      const scope = req.body?.scope || 'online'
      if (!['online', 'all'].includes(scope)) return json(res, 400, { error: '无效的搜索范围' })
      const data = await scanItemById(ctx, server, itemId, scope)
      if (scope === 'all' && data?.scope !== 'all' && !data?.error && !(Number(data?.status) >= 400))
        return json(res, 502, { error: '请更新游戏服反作弊插件后搜索全部玩家' })
      res.json(data)
    } catch (error) {
      fail(res, json, error)
    }
  })

  console.log('[anti-cheat] 反作弊插件已挂载（旧版还原）：/api/anticheat/* + /api/tshock/itemscan*')
}
