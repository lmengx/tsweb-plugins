const xml = value => String(value ?? '').replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[char])
const palettes = {
  mist: { layout: 'classic', bg: '#f0f5fb', paper: '#ffffff', hero: '#e6f1fc', heroEnd: '#e9e7ff', card: '#edf2ff', ink: '#263c52', muted: '#60748c', accent: '#526fe0', line: '#dce5ef', selected: '#eef1ff', radius: 22 },
  space: { layout: 'report', bg: '#0c1c24', paper: '#10252d', hero: '#10252d', heroEnd: '#245451', card: '#1a343b', ink: '#e8f5f3', muted: '#a4bdc0', accent: '#8de2bf', line: '#315158', selected: '#1d423f', radius: 14 },
  cream: { layout: 'ticket', bg: '#eae4d9', paper: '#fffaf0', hero: '#fffaf0', heroEnd: '#fffaf0', card: '#f0e7d7', ink: '#3b342b', muted: '#7d6d58', accent: '#af5b32', line: '#d9ccb7', selected: '#fae8d7', radius: 4 },
  pixel: { layout: 'report', bg: '#222c32', paper: '#293637', hero: '#293637', heroEnd: '#3c5144', card: '#354742', ink: '#f6efd9', muted: '#c2cfbc', accent: '#f1d496', line: '#536757', selected: '#485444', radius: 0 },
}
const statusText = round => round.archived ? '已归档' : round.status === 'open' ? '进行中' : '已结束'
const finite = value => typeof value === 'number' && Number.isFinite(value)
const number = value => finite(value) ? String(Math.round(value * 100) / 100) : '—'
const date = value => value && Number.isFinite(new Date(value).getTime()) ? new Date(value).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', hour12: false, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }) : null
function wrap(value, columns = 60) {
  const lines = []; let line = '', width = 0
  for (const char of String(value ?? '')) {
    const size = /[^\x00-\xff]/.test(char) ? 2 : 1
    if (char === '\n' || width + size > columns) { lines.push(line); line = ''; width = 0; if (char === '\n') continue }
    line += char; width += size
  }
  if (line || !lines.length) lines.push(line)
  return lines
}
export function voteSummary(result, action) {
  if (action === 'cast') return `投票成功 · 本次权重 ${number(result.weight)} 分`
  if (action === 'propose') return result.existing ? '提案已存在，已为你定位' : '提案已提交'
  return '投票结果'
}
export function buildVotePages({ result, action = 'list', theme = 'pixel', accent = '', optionsPerPage = 20, showDescription = true }) {
  const p = { ...(palettes[theme] || palettes.pixel), ...(/^#[0-9a-f]{6}$/i.test(accent) ? { accent } : {}) }
  const text = (x, y, value, size = 26, color = p.ink, weight = 400, anchor = 'start') => `<text x="${x}" y="${y}" fill="${color}" font-size="${size}" font-weight="${weight}" text-anchor="${anchor}">${xml(value)}</text>`
  const rect = (x, y, w, h, fill, radius = p.radius, stroke = '') => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${radius}" fill="${fill}"${stroke ? ` stroke="${stroke}" stroke-width="2"` : ''}/>`
  const block = (value, size = 24, color = p.muted, weight = 400, width = 840, x = 60) => wrap(value, Math.max(8, Math.floor(width / (size * .54)))).map(line => ({ height: size + 10, draw: y => text(x, y + size, line, size, color, weight) }))
  const heightOf = items => items.reduce((sum, item) => sum + item.height, 0)
  const draw = (items, y) => items.map(item => { const svg = item.draw(y); y += item.height; return svg }).join('')
  const gap = height => ({ height, draw: () => '' })
  const shell = (height, content) => `<svg xmlns="http://www.w3.org/2000/svg" width="960" height="${height}" viewBox="0 0 960 ${height}" data-layout="${p.layout}"><title>投票结果</title><defs><linearGradient id="vote-hero" x1="0" x2="1" y2="1"><stop stop-color="${p.hero}"/><stop offset="1" stop-color="${p.heroEnd}"/></linearGradient></defs>${rect(0, 0, 960, height, p.bg, 0)}${rect(20, 20, 920, height - 40, p.paper)}<g font-family="Microsoft YaHei,Noto Sans CJK SC,WenQuanYi Zen Hei,sans-serif">${content}</g></svg>`
  const rounds = result.round ? [result.round] : result.rounds || []
  if (!rounds.length || (!result.round && rounds.length > 1)) {
    const header = block(rounds.length ? `共 ${rounds.length} 轮投票，显示前 ${Math.min(20, rounds.length)} 轮。` : '当前没有可查看的投票。', 28, p.ink, 700)
    const items = rounds.slice(0, 20).map((round, i) => {
      const title = block(`${i + 1}. ${round.title}`, 28, p.ink, 700, 800, 80)
      const footer = block(`${statusText(round)} · ${round.options.length} 个选项 · ${round.options.reduce((sum, option) => sum + (Number(option.votes) || 0), 0)} 票`, 22, p.muted, 400, 800, 80)
      const end = block(`截止：${date(round.endAt) || '长期有效'} · 查询：投票 ${i + 1}`, 21, p.muted, 400, 800, 80)
      const height = heightOf(title) + heightOf(footer) + heightOf(end) + 26
      return { height: height + 14, draw: y => rect(60, y, 840, height, p.card) + draw(title.concat(footer, end), y + 8) }
    })
    const guide = block(rounds.length ? '查看详情：投票 完整轮次名（也可使用轮次编号）' : '发送「投票」刷新轮次列表。', 23, p.accent)
    const groups = []; let group = [], used = 0
    const budget = 3400 - heightOf(header.concat(guide))
    for (const item of items) {
      if (group.length && used + item.height > budget) { groups.push(group); group = []; used = 0 }
      group.push(item); used += item.height
    }
    if (group.length || !groups.length) groups.push(group)
    return { pages: groups.map((rows, i) => {
      const height = Math.max(400, 190 + heightOf(header.concat(rows, guide)))
      return shell(height, text(60, 74, 'TSWEB / 玩家投票', 24, p.muted, 700) + draw(header.concat([gap(18)], rows, guide), 108) + text(900, height - 36, `第 ${i + 1} / ${groups.length} 页`, 20, p.muted, 400, 'end'))
    }) }
  }
  const round = rounds[0], options = round.options || []
  const personal = ['cast', 'propose'].includes(action) ? round.my : null
  const voted = new Set(personal?.votedOptions || [])
  const totalScore = options.reduce((sum, option) => sum + (Number(option.score) || 0), 0)
  const totalVotes = options.reduce((sum, option) => sum + (Number(option.votes) || 0), 0)
  const title = block(round.title, p.layout === 'ticket' ? 44 : 42, p.ink, 700)
  const dates = block(`发起 ${date(round.createdAt) || '时间未记录'} · 截止 ${date(round.endAt) || '长期有效'}`, 22)
  const headerHeight = 106 + heightOf(title.concat(dates)) + 22
  const hero = () => rect(20, 20, 920, headerHeight - 20, 'url(#vote-hero)') + (p.layout === 'ticket' ? rect(20, 20, 920, 9, p.accent, 0) : '') + text(60, 72, 'TSWEB / 社区投票', 23, p.layout === 'ticket' ? p.accent : p.muted, 700) + text(900, 72, statusText(round), 23, p.accent, 700, 'end') + draw(title, 100) + draw(dates, 110 + heightOf(title)) + `<path d="M40 ${headerHeight}H920" stroke="${p.line}"${p.layout === 'ticket' ? ' stroke-dasharray="6 6"' : ''}/>`
  const weightRules = round.weightRules || []
  const ruleText = rule => `时长 ${rule.op} ${number(rule.threshold)}h 加 ${number(rule.weight)} 分`
  const ruleColumns = [['投票额度', `每人最多 ${number(round.maxVotesPerUser)} 票`], ['计分规则', `基础 ${number(round.baseWeight)} 分 / 票`], ['时长加成', weightRules.length ? ruleText(weightRules[0]) : '无额外加成']].map(([label, value], i) => ({ label, x: 60 + i * 286, value: block(value, 23, p.ink, 600, 268, 60 + i * 286) }))
  const stripHeight = Math.max(...ruleColumns.map(column => heightOf(column.value))) + 36
  const ruleItems = [
    { height: stripHeight, draw: y => ruleColumns.map(column => text(column.x, y + 19, column.label, 19, p.muted) + draw(column.value, y + 27)).join('') },
    ...weightRules.slice(1).flatMap(rule => block(ruleText(rule), 22)),
    ...block(`${round.allowUnbound === false ? '仅已绑定玩家参与' : '允许未绑定玩家参与'} · ${round.allowProposals ? `自主提案：每人最多 ${number(round.maxProposalsPerUser)} 次` : '自主提案：本轮不开放'}`, 21),
  ]
  const stats = (x, y, width, columns = 4) => {
    const compact = width < 500
    const rows = [[number(personal?.votesLeft), compact ? '还可投' : '还可投 / 票'], [String(voted.size), compact ? '已投' : '已投 / 票'], [number(personal?.weight), compact ? '分 / 票' : '权重 / 分'], [round.allowProposals ? number(personal?.proposalsLeft) : '关闭', compact ? '可提案' : '可提案 / 次']]
    const cell = (width - (columns - 1) * 10) / columns
    return rows.map(([value, label], i) => {
      const left = x + (i % columns) * (cell + 10), top = y + Math.floor(i / columns) * 114
      const size = Math.min(38, Math.max(16, Math.floor((cell - 24) / Math.max(value.length, 1) / .7)))
      return `<g data-stat="${['votesLeft', 'voted', 'weight', 'proposalsLeft'][i]}">` + rect(left, top, cell, 100, p.card, p.radius ? 12 : 0) + text(left + 12, top + 46, value, size, i === 0 ? p.accent : p.ink, 700) + text(left + 12, top + 80, label, 18, p.muted) + '</g>'
    }).join('')
  }
  const receiptLines = personal ? [
    ...block(action === 'cast' ? '投票成功 ✓' : voteSummary(result, action), 29, p.accent, 700, p.layout === 'report' ? 380 : p.layout === 'ticket' ? 210 : 840, p.layout === 'ticket' ? 676 : 60),
    ...(action === 'cast' ? block(`本次权重 ${number(result.weight)} 分`, 23, p.muted, 400, p.layout === 'ticket' ? 210 : p.layout === 'report' ? 380 : 840, p.layout === 'ticket' ? 676 : 60) : []),
    ...(action === 'propose' && result.option?.text ? block(`提案内容：${result.option.text}`, 22, p.muted, 400, p.layout === 'ticket' ? 210 : p.layout === 'report' ? 380 : 840, p.layout === 'ticket' ? 676 : 60) : []),
  ] : []
  const personalHeight = personal ? p.layout === 'classic' ? heightOf(receiptLines) + 134 : p.layout === 'report' ? Math.max(heightOf(receiptLines) + 20, 124) : 0 : 0
  const receipt = y => !personal || p.layout === 'ticket' ? '' : draw(receiptLines, y) + stats(p.layout === 'report' ? 474 : 60, y + (p.layout === 'report' ? 0 : heightOf(receiptLines) + 12), p.layout === 'report' ? 426 : 840)
  const nextOption = options.findIndex(option => !option.id || !voted.has(option.id)) + 1
  const commands = round.archived || round.status !== 'open' ? block(`本轮${round.archived ? '已归档' : '已结束'}，仅可查看结果，无法投票或提交提案。`, 23, p.muted, 400, 800, 80) : [
    ...block(personal && personal.votesLeft === 0 ? '投票额度已用完 · 可继续查看结果' : '如何参与 · 在群内发送以下指令', 23, p.accent, 700, 800, 80),
    ...(personal && (personal.votesLeft === 0 || !nextOption) ? [] : block(`参与投票 ${round.title} ${nextOption || 1}`, 24, p.ink, 700, 800, 80)),
    ...block('末尾数字对应选项编号，也可填写选项名称；不能重复投同一项。', 21, p.muted, 400, 800, 80),
    ...(round.allowProposals ? block(personal?.proposalsLeft === 0 ? '本轮提案额度已用完' : `提交提案：投票提案 ${round.title} 内容`, 22, p.ink, 400, 800, 80) : []),
  ]
  const guideHeight = heightOf(commands) + 38
  const sideLines = p.layout === 'ticket' ? (personal ? receiptLines : block('参与须知', 27, p.accent, 700, 210, 676)) : []
  const sideNote = p.layout === 'ticket' ? block(personal ? `已投 ${voted.size} 项 · 还可投 ${number(personal.votesLeft)} 项` : round.allowUnbound === false ? '请先绑定玩家，再参与投票。' : '允许未绑定玩家参与投票。', 21, p.muted, 400, 210, 676) : []
  const sideHeight = p.layout === 'ticket' ? 40 + heightOf(sideLines) + (personal ? 240 : 0) + heightOf(sideNote) : 0
  const sidebar = y => !sideHeight ? '' : rect(656, y, 244, sideHeight, p.card, 0) + draw(sideLines, y + 16) + (personal ? stats(666, y + 28 + heightOf(sideLines), 224, 2) : '') + draw(sideNote, y + sideHeight - heightOf(sideNote) - 14)
  const optionWidth = p.layout === 'ticket' ? 566 : 840
  const optionItems = options.map((option, i) => {
    const selected = !!option.id && voted.has(option.id)
    const isProposal = option.type === 'custom'
    const proposed = action === 'propose' && !!option.id && result.option?.id === option.id
    const label = block(`${i + 1}. ${option.text}`, 26, p.ink, 700, optionWidth - 88, 86)
    const proposalTag = isProposal ? option.anonymous ? '匿名提案' : '自主提案' : ''
    const tag = selected ? ['✓ 已投', proposalTag].filter(Boolean).join(' · ') : proposed ? result.existing ? '已定位提案' : '本次提案' : proposalTag
    const height = heightOf(label) + (tag ? 28 : 0) + 70
    const share = totalScore > 0 ? Math.max(0, Math.min(100, (Number(option.score) || 0) / totalScore * 100)) : 0
    return { height: height + 14, draw: y => {
      const base = p.layout === 'ticket' ? `<path d="M60 ${y + height}H${60 + optionWidth}" stroke="${p.line}"/>` : rect(60, y, optionWidth, height, selected || proposed ? p.selected : p.card, p.radius, selected || proposed ? p.accent : '')
      const labelTop = y + 10
      const metricsY = y + height - 29
      return `<g data-option-index="${i + 1}" data-selected="${selected}" data-share="${number(share)}">` + base + draw(label, labelTop) + (tag ? text(86, labelTop + heightOf(label) + 20, tag, 20, p.accent, 700) : '') + text(86, metricsY, `${number(option.votes)} 票 / ${number(option.score)} 分`, 23, p.ink, 600) + text(60 + optionWidth - 22, metricsY, `${number(share)}%`, 21, p.muted, 400, 'end') + rect(86, y + height - 15, optionWidth - 52, 6, p.line, 3) + rect(86, y + height - 15, (optionWidth - 52) * share / 100, 6, p.accent, 3) + '</g>'
    } }
  })
  const pageSize = Number.isInteger(optionsPerPage) ? Math.max(6, Math.min(30, optionsPerPage)) : 20
  const rulesBefore = p.layout === 'classic' ? heightOf(ruleItems) + 18 : 0
  const rulesAfter = p.layout === 'classic' ? 0 : heightOf(ruleItems) + 20
  const bodyTop = headerHeight + 24 + personalHeight + rulesBefore
  const contentHeight = 3600 - bodyTop - rulesAfter - guideHeight - 170
  const description = showDescription && round.description ? block(round.description, 23, p.muted, 400, optionWidth) : []
  const chunks = []; let items = [], descriptionLines = [], used = 0, start = 0
  const flush = () => { chunks.push({ items, description: descriptionLines, start }); start += items.length; items = []; descriptionLines = []; used = 0 }
  for (const line of description) {
    if (descriptionLines.length && used + line.height > contentHeight) flush()
    descriptionLines.push(line); used += line.height
  }
  for (const item of optionItems) {
    if ((descriptionLines.length || items.length) && (items.length >= pageSize || used + item.height > contentHeight)) flush()
    items.push(item); used += item.height
  }
  if (descriptionLines.length || items.length || !chunks.length) flush()
  return { pages: chunks.map((chunk, i) => {
    const contentY = bodyTop + 44
    const contentH = Math.max(heightOf(chunk.description.concat(chunk.items)), sideHeight)
    const rulesY = contentY + contentH + 18
    const guideY = rulesY + rulesAfter + 10
    const height = Math.max(450, Math.ceil(guideY + guideHeight + 84))
    const footer = `${chunk.items.length ? `选项 ${chunk.start + 1}–${chunk.start + chunk.items.length} / ${options.length}` : '投票说明'} · 第 ${i + 1} / ${chunks.length} 页`
    return shell(height, hero() + receipt(headerHeight + 24) + (rulesBefore ? draw(ruleItems, headerHeight + 24 + personalHeight) : '') + text(60, bodyTop + 26, '投票选项', 27, p.ink, 700) + text(900, bodyTop + 26, `${options.length} 个选项 · ${number(totalVotes)} 票 · ${number(totalScore)} 分`, 21, p.muted, 400, 'end') + draw(chunk.description.concat(chunk.items), contentY) + sidebar(contentY) + (rulesAfter ? draw(ruleItems, rulesY) : '') + rect(60, guideY, 840, guideHeight, p.card, p.layout === 'ticket' ? 0 : p.radius) + draw(commands, guideY + 16) + text(60, height - 39, footer, 21, p.muted) + text(900, height - 39, 'TSWEB / COMMUNITY VOTE', 17, p.muted, 400, 'end'))
  }) }
}
export function registerVoteRendering(ctx, settings) {
  return ctx.inject(['qqRenderer'], c => {
    if (!c.qqRenderer.registerTemplate) return
    return c.qqRenderer.registerTemplate('vote/results', { owner: 'vote', build: options => buildVotePages({ ...settings?.config, ...options }) })
  })
}
export async function presentVote(ctx, result, { action, signal } = {}, settings) {
  let renderer
  try { renderer = ctx.get('qqRenderer') } catch {}
  if (settings?.config.enabled === false || !renderer?.config?.enabled || !renderer.registerTemplate) return null
  return renderer.render('vote/results', { result, action, signal })
}
