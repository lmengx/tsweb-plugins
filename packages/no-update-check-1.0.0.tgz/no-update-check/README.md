# 关闭更新检查

无前端 Cordis 插件。市场包名 `no-update-check`，游戏服程序集 `NoUpdateCheck.dll`。
关闭 TShock 内置远端更新检查，避免检查失败时重复打印日志。

## 安装与使用

在插件市场安装并启用，宿主按各服的启用范围同步 DLL。没有独立页面、REST 接口或额外权限模块。
冷启动时等世界初始化完成后接管；热加载时立即接管。游戏服出现“已接管更新检查”日志才表示安装成功。
卸载或停用会恢复原检查客户端；已有检查请求可能仍完成，不取消宿主的请求。
请先移除游戏服手工安装的同名旧 DLL，避免两套来源重复加载。

## 兼容性与开发

针对 TShock 6.1 / .NET 9，依赖 UpdateManager 的 HttpClient 字段；反射失败时记录警告并保持原行为。
不修改 TShock 文件或配置，不访问更新站点，不创建后台定时器。

源码源自 `TsWeb/plugin-son/NoUpdateCheck`。此目录为 Cordis 市场版本的维护入口。
执行 `node scripts/pack-plugin.mjs no-update-check` 构建并打包。
回归：`dotnet run --project plugins/no-update-check/test/Regression.csproj -c Release`。
