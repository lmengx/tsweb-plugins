// Game-server DLL lifecycle is managed by the host registry. No routes or UI.
export const name = 'no-update-check'
export function apply() {}
