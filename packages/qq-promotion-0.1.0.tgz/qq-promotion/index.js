/**
 * QQ 绑定后自动晋升（qq-promotion）—— 宿主半
 *
 * 为什么独立成插件（这是本件存在的理由，也是它不做成 qq-bind 附属模块的原因）：
 *   1. 晋升只在游戏服进程内做得了（改组要经 TShock 的 UserAccounts/组系统），
 *      而"谁登录了"只有游戏服知道（docs/QQ绑定基础件设计.md §7.1 的能力表）；
 *   2. 设计 §7.3（doc 第 520 行）明确了官方取向：**若晋升/风控独立成 DLL，
 *      则改为各自读快照文件（同一份 JSON），避免 DLL 间耦合**；
 *   3. 独立发布：晋升的开关与目标组由本件自己的配置与端点管理，
 *      不再依赖 qq-bind 的 `/data/qq/*` 通道与它的快照下发时机。
 *
 * 于是游戏服半**只读 qq-bind 落盘的绑定快照文件**识别"该账号是否已绑定"
 * （`<TShock.SavePath>/qqbind-snapshot.json`，见旧实现 plugins/qq-bind/plugin/QqSnapshot.cs:30），
 * 既不引用 QqBind.dll（程序集耦合 + 卸载风险），也不再自己存一份绑定关系（双份权威）。
 * 快照文件的权威结构见 QqSnapshot.cs:335-350（records: { 用户名: { qq, passwordHash } }）。
 *
 * 职责分工：
 *   宿主半（本文件）  配置存储 / 校验 / 审计 / 下发（变更即推 + 连接恢复补推 + 失败重试 + 周期对账）
 *   前端半            /b/qq-promotion：四个字段的编辑保存 + 下发状态可见
 *   游戏服半          QqPromotion.dll：登录时按配置晋升，只读绑定快照
 *   seed.js           首次运行从 qq-bind 旧配置的 promotion 块迁移晋升设置（见该文件顶部说明）
 *
 * 旧配置迁移（seed）：晋升原来内嵌在 qq-bind 里，其配置留在 `<dataDir>/qq-bind/config.json` 的
 * `promotion` 块；本件**只在首次运行（自己的配置文件不存在）**时把它搬过来，已存在绝不覆盖，
 * 且不删除对方文件里的旧块。qq-bind 是**软依赖**（可能没装），取服务一律走 ctx.get，
 * 不得直接属性访问（docs/插件开发约定.md §2.3）。详见 seed.js 与 _seedFromLegacyQqBind()。
 *
 * 三条必须一致的行为（与旧实现逐条对齐，见交付报告的语义对照表）：
 *   1. **只在登录时晋升**：改配置 / 快照变更都**不会**立刻晋升当前在线玩家 —— 保持旧行为。
 *      所以本文件的任何路径都不调用游戏服的"立即晋升"动作，服端也没有这个端点。
 *   2. 配置变更必须**立即下发**（这一条是"界面显示已启用、实际没生效"那类静默失效的解药，
 *      旧注释见 plugins/qq-bind/index.js:1345-1349）：POST /api/qq-promotion/config 在同一请求里
 *      完成落盘 + 下发，并把逐服结果原样回显，不假装成功。
 *   3. 下发失败**永不静默**：逐服状态进 pushStatus，经 /status 与保存响应回给前端，
 *      同时按退避重试，直到该服确认应用（或管理员看到持续的失败原因）。
 *
 * 依赖：webServer / auth / servers / tshock / paths（全部由宿主或基础插件提供）
 * 约定：禁止 emoji；状态数据走 ctx.paths.dataOf('qq-promotion')（不在插件目录内）。
 */
import { join } from 'node:path'

import { AuditLog } from './audit.js'
import {
  configWarnings,
  defaultConfig,
  loadConfig,
  normalizeConfig,
  saveConfig,
  setByPath,
  toGamePayload,
} from './config.js'
import { createGameOps, httpError, DLL_NAME } from './gameOps.js'
import { LEGACY_SOURCE_PLUGIN, readLegacyPromotion, seedFromLegacyPromotion } from './seed.js'

export const name = 'qq-promotion'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths']

/** 单次手动下发可指定的服务器上限（防止一次请求把几十台服串行打完） */
const PUSH_LIMIT = 50

export class PromotionService {
  constructor({ ctx, dataDir, configFile, auditFile }) {
    this.ctx = ctx
    this.dataDir = dataDir
    this.configFile = configFile || join(dataDir, 'config.json')
    this.auditFile = auditFile || join(dataDir, 'audit.jsonl')

    /** 当前生效配置（唯一权威；下发内容永远由它派生） */
    this.config = defaultConfig()
    /** 读配置时发现的问题（文件损坏等），如实回显给管理员 */
    this.configError = ''

    this.gameOps = createGameOps({ ctx })
    this.audit = new AuditLog({ file: this.auditFile })

    /**
     * 宿主侧期望的配置版本，**每次下发尝试都自增**（单调）。
     * 服端会拒绝比它当前版本更旧的载荷（stale），所以"重试"必须带新版本号，
     * 否则一次乱序到达的旧请求会把新配置覆盖回去。
     */
    this.desiredVersion = 0
    /**
     * 配置内容修订号：**只在配置真的变了（或宿主刚启动）时自增**。
     * 为什么不能直接用 desiredVersion 判断"某服是否已是最新配置"：一次只推一台服的
     * 补推/重试也会把 desiredVersion 抬高，于是刚刚确认过的其它服会被误判成"落后"，
     * 未确认计数永远清不掉（实测踩到）。所以"版本号"管顺序，"修订号"管是否最新，各司其职。
     */
    this.configRevision = 1
    /** serverId → { version, revision }（已确认应用的那一次下发） */
    this.acked = new Map()
    /** 最近一次已知的启用服务器 id 集合（用于算"未确认"台数，含从未推过的服） */
    this.knownServerIds = new Set()
    /** serverId → 最近一次下发结果（前端展示 + 排障） */
    this.pushStatus = new Map()

    this._reconcileTimer = null
    this._retryTimer = null
    this._retryDelay = 0
  }

  // ═══════════════════════ 生命周期 ═══════════════════════

  async init() {
    const loaded = await loadConfig(this.configFile)
    this.config = loaded.config
    this.configError = loaded.error
    this._retryDelay = this.config.push.retryIntervalMs

    if (loaded.error) {
      // 配置损坏 → 按默认（未启用）运行并明确报错：绝不因为读不懂配置就"按启用"乱改组
      console.error(`[qq-promotion] ${loaded.error}`)
    } else if (!loaded.existed) {
      // 首次运行：先尝试从 qq-bind 旧配置迁移晋升设置，迁移成功就不再打"按默认配置运行"
      // （否则日志会与随后的实际生效配置自相矛盾）
      const seed = await this._seedFromLegacyQqBind()
      if (!seed.seeded) {
        console.log(
          `[qq-promotion] 尚无配置文件（${this.configFile}），按默认配置运行：` +
          `晋升${this.config.enabled ? '已启用' : '未启用'}`,
        )
      }
    }

    // 启动即对账一次（异步、不阻塞 apply）：宿主重启后若某服配置落后，这里就补上
    this.startReconcile()
    this.pushConfig({ reason: '宿主启动对账' }).catch((err) => {
      console.error(`[qq-promotion] 启动对账下发失败：${err.message}`)
    })
    return this
  }

  /**
   * 首次运行时的旧配置迁移（seed）：把 qq-bind 旧配置里的 promotion 块搬过来。
   *
   * 触发条件**只有**"本件自己的配置文件不存在"（由 init 传进来的 loadConfig().existed 决定，
   * 见 init 的调用点）：文件已存在就绝不覆盖，哪怕旧值与现值不同 —— 用户可能已经在本件里
   * 改过；配置损坏（error 非空）也不 seed，免得把"读不懂的现值"换成"另一个来源的值"。
   * 写下去之后下次启动 existed 即为 true，天然只迁移一次（幂等）。
   *
   * 旧值来源与校验全部在 seed.js（软依赖取服务、只读对方文件、逐字段过本件归一）；
   * 这里有且只有三件事：判定、落盘、留痕（审计 + 日志）。
   *
   * **任何异常都吞掉并只记日志**：迁移是便利功能，不能因为"旧配置读不出来"就让本插件
   * 加载失败（那会让管理员连配置页都进不去）。
   */
  async _seedFromLegacyQqBind() {
    try {
      const legacy = await readLegacyPromotion(this.ctx)
      if (!legacy.available) {
        // 没有可迁移的旧值（qq-bind 没装 / 无 promotion 块 / 读不出来）：**不写**"已迁移"日志
        return { seeded: false, reason: legacy.reason }
      }

      const { config, adopted, skipped } = seedFromLegacyPromotion(legacy.promotion)
      if (adopted.length === 0) {
        // 旧块在、但一个可用字段都没有：保持默认配置，也不写"已迁移"日志（没搬任何东西）
        return { seeded: false, reason: '旧 promotion 块里没有可采用的字段' }
      }

      await saveConfig(this.configFile, config)
      this.config = config
      this.configError = ''

      await this.audit.append('qqpromotion.config.seed', {
        // 宿主自身发起的迁移，没有自然人操作者：用 'system' 与 'admin'/'terminal' 区分开
        actor: 'system',
        source: LEGACY_SOURCE_PLUGIN,
        sourceFile: legacy.file,
        keys: adopted,
        skipped,
      })

      // 只报来源路径与**字段名**，不打配置明文（保持本件"日志不含配置内容"的习惯）
      console.log(
        `[qq-promotion] 已从 qq-bind 旧配置迁移晋升设置（来源 ${legacy.file}）：` +
        `采用 ${adopted.join('/')}` +
        (skipped.length > 0 ? `；未采用 ${skipped.join('/')}（旧值不可用，回落本件默认值）` : ''),
      )
      return { seeded: true, keys: adopted, skipped, config }
    } catch (err) {
      console.error(`[qq-promotion] 旧配置迁移跳过（不影响本件加载）：${err.message}`)
      if (process.env.TSWEB_DEBUG) console.error(err.stack)
      return { seeded: false, reason: err.message }
    }
  }

  /**
   * 周期对账：无条件重推一遍（配置极小，代价可忽略）。
   * 为什么无条件而不是"仅推落后的服"：服端的配置文件可能被人删掉/改坏（它会退回默认=未启用），
   * 此时宿主的 acked 记录仍是"已确认"，只有无条件重推才能自愈这种"宿主以为生效了"的状态。
   */
  startReconcile() {
    this.stopReconcile()
    const ms = Number(this.config.push.reconcileIntervalMs) || 0
    if (ms <= 0) return false
    this._reconcileTimer = setInterval(() => {
      this.pushConfig({ reason: '周期对账' }).catch((err) => {
        console.error(`[qq-promotion] 周期对账下发失败：${err.message}`)
      })
    }, ms)
    this._reconcileTimer.unref?.()
    return true
  }

  stopReconcile() {
    if (this._reconcileTimer) {
      clearInterval(this._reconcileTimer)
      this._reconcileTimer = null
    }
  }

  /** 失败重试（指数退避到 push.retryMaxIntervalMs）；全部确认后由 clearRetry 停掉 */
  _scheduleRetry() {
    const cfg = this.config.push
    if (cfg.retryIntervalMs <= 0) return false
    if (this._retryTimer) return true
    const delay = Math.max(cfg.retryIntervalMs, Math.min(this._retryDelay, cfg.retryMaxIntervalMs))
    this._retryTimer = setTimeout(() => {
      this._retryTimer = null
      this._retryDelay = Math.min(Math.max(this._retryDelay, cfg.retryIntervalMs) * 2, cfg.retryMaxIntervalMs)
      this.pushPending({ reason: '失败重试' }).catch((err) => {
        console.error(`[qq-promotion] 失败重试下发异常：${err.message}`)
      })
    }, delay)
    this._retryTimer.unref?.()
    return true
  }

  _clearRetry() {
    if (this._retryTimer) {
      clearTimeout(this._retryTimer)
      this._retryTimer = null
    }
    this._retryDelay = this.config.push.retryIntervalMs
  }

  /** 插件禁用/卸载时由 apply 返回的释放钩子调用 */
  dispose() {
    this.stopReconcile()
    this._clearRetry()
  }

  // ═══════════════════════ 下发 ═══════════════════════

  /** 某服是否已确认**当前这份配置**（按修订号判断，见 configRevision 的注释） */
  isAcked(serverId) {
    const entry = this.acked.get(String(serverId))
    return typeof entry === 'object' && entry !== null && entry.revision === this.configRevision
  }

  /** 未确认的服务器 id（含从未下发过的启用的服） */
  pendingIds() {
    const ids = new Set([...this.knownServerIds, ...this.pushStatus.keys()])
    return [...ids].filter((id) => !this.isAcked(id))
  }

  /** 逐服下发（内部实现；targets 为原始服务器记录） */
  async _push(targets, { reason = '' } = {}) {
    if (targets.length === 0) {
      this._clearRetry()
      return {
        ok: true, reason, version: this.desiredVersion, total: 0, okCount: 0, pendingCount: 0,
        servers: [], note: '没有启用中的服务器',
      }
    }

    const version = this.desiredVersion + 1
    this.desiredVersion = version
    const payload = toGamePayload(this.config, version)
    const results = []
    const at = new Date().toISOString()

    for (const server of targets) {
      try {
        const data = await this.gameOps.pushConfig(server, payload)
        const ok = data.applied === true && data.stale !== true
        let error = ''
        if (!ok) {
          error = data.stale
            ? `服端已有更新版本（v${data.version}），本次 v${version} 未生效`
            : '服端未确认应用（applied=false）'
        }
        if (data.saveError) error = error === '' ? `服端落盘失败：${data.saveError}` : `${error}；服端落盘失败：${data.saveError}`
        const entry = {
          id: server.id,
          name: server.name,
          ok,
          version: Number(data.version || version),
          sentVersion: version,
          applied: data.applied === true,
          stale: data.stale === true,
          saveError: data.saveError,
          ignoreNote: data.ignoreNote,
          bindings: data.bindings,
          at,
          error,
        }
        if (ok) this.acked.set(String(server.id), { version, revision: this.configRevision })
        this.pushStatus.set(String(server.id), entry)
        results.push(entry)
      } catch (err) {
        const entry = {
          id: server.id,
          name: server.name,
          ok: false,
          version,
          sentVersion: version,
          applied: false,
          stale: false,
          at,
          error: err.message,
          serverHalfMissing: err.serverHalfMissing === true,
          status: err.status || 502,
        }
        this.pushStatus.set(String(server.id), entry)
        results.push(entry)
      }
    }

    const okCount = results.filter((r) => r.ok).length
    const failed = results.filter((r) => !r.ok)
    if (failed.length > 0) this._scheduleRetry()
    else this._clearRetry()

    try {
      this.ctx.emit('qqpromotion/push', {
        reason,
        version,
        total: results.length,
        okCount,
        servers: results.map((r) => ({ id: r.id, ok: r.ok, error: r.error })),
      })
    } catch {
      /* 无监听者/宿主不提供 emit：忽略 */
    }

    return {
      ok: failed.length === 0,
      reason,
      version,
      total: results.length,
      okCount,
      pendingCount: failed.length,
      servers: results,
    }
  }

  /**
   * 下发到启用服（默认全部；serverIds 显式给出时只发这些）。
   * 语义对齐 qq-bind/plugins/qq-bind/index.js:618-668：逐服独立成败、永不整体抛错，
   * 调用方拿到的结果可直接回给用户。
   */
  async pushConfig({ serverIds = null, reason = '' } = {}) {
    const servers = await this.gameOps.enabledServers()
    this.knownServerIds = new Set(servers.map((s) => String(s.id)))
    const wanted = Array.isArray(serverIds) && serverIds.length > 0 ? serverIds.map(String) : null
    const targets = wanted ? servers.filter((s) => wanted.includes(String(s.id))) : servers
    if (wanted && targets.length === 0) {
      throw httpError(404, '指定的服务器不存在或未启用', { serverIds: wanted })
    }
    return this._push(targets, { reason })
  }

  /** 只推"尚未确认当前配置"的服：连接恢复补推与失败重试都走这里，避免无谓流量 */
  async pushPending({ reason = '' } = {}) {
    const servers = await this.gameOps.enabledServers()
    this.knownServerIds = new Set(servers.map((s) => String(s.id)))
    const targets = servers.filter((s) => !this.isAcked(s.id))
    if (targets.length === 0) {
      this._clearRetry()
      return {
        ok: true, reason, version: this.desiredVersion, total: 0, okCount: 0, pendingCount: 0,
        servers: [], note: '全部启用中的服务器都已确认最新配置',
      }
    }
    return this._push(targets, { reason })
  }

  // ═══════════════════════ 状态与排障 ═══════════════════════

  /** 宿主侧下发状态汇总（不含探测；探测见 probeServers） */
  status() {
    const cfg = normalizeConfig(this.config)
    return {
      config: cfg,
      configFile: this.configFile,
      configError: this.configError,
      warnings: configWarnings(cfg),
      desiredVersion: this.desiredVersion,
      configRevision: this.configRevision,
      intervals: {
        reconcileIntervalMs: cfg.push.reconcileIntervalMs,
        retryIntervalMs: cfg.push.retryIntervalMs,
        retryMaxIntervalMs: cfg.push.retryMaxIntervalMs,
      },
      servers: [...this.pushStatus.values()]
        .map((r) => ({ ...r }))
        .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id))),
      pendingCount: this.pendingIds().length,
      pendingServerIds: this.pendingIds(),
      retryScheduled: this._retryTimer != null,
    }
  }

  /**
   * 逐服探测"服端实际生效的配置"，并与宿主配置比对。
   * 这是"界面写了什么"与"服端真的按什么在晋升"之间的唯一直接证据（保存响应里只代表提交成功）。
   */
  async probeServers({ serverIds = null } = {}) {
    let servers
    try {
      servers = await this.gameOps.enabledServers()
    } catch (err) {
      return { servers: [], error: `读取服务器列表失败：${err.message}` }
    }
    const wanted = Array.isArray(serverIds) && serverIds.length > 0 ? serverIds.map(String) : null
    const targets = wanted ? servers.filter((s) => wanted.includes(String(s.id))) : servers
    const cfg = normalizeConfig(this.config)
    const out = []

    for (const server of targets) {
      try {
        const state = await this.gameOps.status(server)
        const diff = []
        if (state.enabled !== cfg.enabled) diff.push(`启用=${state.enabled}（宿主 ${cfg.enabled}）`)
        if (state.targetGroup !== cfg.targetGroup) diff.push(`目标组=${state.targetGroup || '空'}（宿主 ${cfg.targetGroup || '空'}）`)
        if (state.mode !== cfg.mode) diff.push(`模式=${state.mode || '空'}（宿主 ${cfg.mode}）`)
        const groupSet = (list) => list.map((x) => String(x).toLowerCase()).sort().join(',')
        if (groupSet(state.ignoreGroups) !== groupSet(cfg.ignoreGroups)) {
          diff.push(`忽略组=${state.ignoreGroups.join('/') || '空'}（宿主 ${cfg.ignoreGroups.join('/') || '空'}）`)
        }
        out.push({ id: server.id, name: server.name, ok: true, state, match: diff.length === 0, diff })
      } catch (err) {
        out.push({
          id: server.id,
          name: server.name,
          ok: false,
          error: err.message,
          serverHalfMissing: err.serverHalfMissing === true,
          status: err.status || 502,
        })
      }
    }
    return { servers: out }
  }

  // ═══════════════════════ 配置写入 ═══════════════════════

  /**
   * 应用配置更新：白名单校验 → 归一 → 落盘 → 审计 → **立即下发**。
   * 顺序刻意是"先落盘再下发"：落盘失败就不该让服端跑一份只存在于内存的配置。
   * （旧注释见 plugins/qq-bind/index.js:1345-1349：配置变更不立刻下发时，
   *  reconcileIntervalMs=0 的部署可能**永远不生效**。）
   */
  async applyUpdates(updates, { actor = 'admin', reason = '配置变更即时下发' } = {}) {
    if (!updates || typeof updates !== 'object' || Array.isArray(updates)) {
      throw httpError(400, '缺少参数: updates（应为 { 配置路径: 值 } 对象）')
    }
    const keys = Object.keys(updates)
    if (keys.length === 0) throw httpError(400, 'updates 为空，没有可写入的配置项')

    const before = normalizeConfig(this.config)
    const draft = JSON.parse(JSON.stringify(before))
    for (const key of keys) setByPath(draft, key, updates[key])

    const next = normalizeConfig(draft)
    await saveConfig(this.configFile, next)
    this.config = next
    this.configError = ''
    // 配置内容变了 → 修订号自增：所有服的"已确认"记录随之失效，直到它们各自确认新一轮下发
    this.configRevision += 1

    // 节奏类配置改了要立刻生效（不必重启宿主）：重开对账定时器
    this._clearRetry()
    this.startReconcile()

    await this.audit.append('qqpromotion.config.set', {
      actor,
      keys,
      enabled: next.enabled,
      targetGroup: next.targetGroup,
      mode: next.mode,
      ignoreGroups: next.ignoreGroups,
    })

    const push = await this.pushConfig({ reason })
    return {
      ok: push.ok,
      config: next,
      warnings: configWarnings(next),
      changed: keys.filter((k) => JSON.stringify(before[k.split('.')[0]]) !== JSON.stringify(next[k.split('.')[0]])),
      push,
    }
  }
}

// ═══════════════════════ 插件挂载 ═══════════════════════

export async function apply(ctx, options = {}) {
  try {
    return await applyInner(ctx, options)
  } catch (err) {
    // 约定（docs/插件开发约定.md §2.2）：声明 inject 的插件 apply 是延迟执行的，
    // 期间抛出的异常不会被加载器的 try/catch 捕获，表现为"插件加载成功但什么都没注册"，
    // 所以这里自己兜一层并打印。
    console.error('[qq-promotion] 初始化失败: ' + err.message)
    if (process.env.TSWEB_DEBUG) console.error(err.stack)
    throw err
  }
}

async function applyInner(ctx, options = {}) {
  const dataDir = options.dataDir || ctx.paths.dataOf('qq-promotion')
  const service = new PromotionService({
    ctx,
    dataDir,
    configFile: options.configFile,
    auditFile: options.auditFile,
  })
  await service.init()

  const app = ctx.webServer.app
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]
  const fail = (res, err) => {
    const status = err.status || 500
    const body = { error: err.message }
    for (const key of ['serverId', 'serverHalfMissing', 'serverIds', 'missingDll']) {
      if (err[key] !== undefined) body[key] = err[key]
    }
    if (!res.headersSent) res.status(status).json(body)
  }
  const wrap = (handler) => async (req, res) => {
    try {
      res.json(await handler(req, res))
    } catch (err) {
      fail(res, err)
    }
  }

  // 读配置（含损坏提示与生效性警告）
  app.get('/api/qq-promotion/config', ...admin, wrap(async () => {
    const cfg = normalizeConfig(service.config)
    return {
      ok: true,
      config: cfg,
      configFile: service.configFile,
      configError: service.configError,
      warnings: configWarnings(cfg),
      defaults: { ignoreGroups: defaultConfig().ignoreGroups, mode: defaultConfig().mode },
    }
  }))

  /**
   * 保存配置 [+ 立即下发]。
   * body：{ updates: { 路径: 值 } } 或 { path, value }
   * 返回：{ ok, config, warnings, push: { okCount, total, servers:[...] } }
   *   —— push 的结果**原样**回给前端，让"是否真生效"可见，不假装成功。
   */
  app.post('/api/qq-promotion/config', ...admin, wrap(async (req) => {
    const b = req.body || {}
    let updates = b.updates && typeof b.updates === 'object' && !Array.isArray(b.updates) ? b.updates : null
    if (!updates) {
      if (b.path === undefined) throw httpError(400, '缺少参数: updates 或 path/value')
      updates = { [String(b.path)]: b.value }
    }
    return service.applyUpdates(updates, { actor: 'admin' })
  }))

  // 下发状态（probe=1 时逐服探测服端实际生效的配置）
  app.get('/api/qq-promotion/status', ...admin, wrap(async (req) => {
    const q = req.query || {}
    const out = service.status()
    if (q.probe === '1' || q.probe === 'true') {
      out.probe = await service.probeServers({ serverIds: q.serverId ? [q.serverId] : null })
    }
    return { ok: true, ...out }
  }))

  /**
   * 手动重推（排障用；也是"某服刚才离线"后的补救入口）。
   * body：{ serverIds?: string[], onlyPending?: boolean }
   */
  app.post('/api/qq-promotion/push', ...admin, wrap(async (req) => {
    const b = req.body || {}
    let serverIds = null
    if (Array.isArray(b.serverIds)) {
      if (b.serverIds.length > PUSH_LIMIT) {
        throw httpError(400, `单次下发服务器上限 ${PUSH_LIMIT} 台（本次 ${b.serverIds.length} 台）`)
      }
      serverIds = b.serverIds.map(String).filter((s) => s !== '')
    }
    const push = b.onlyPending === true
      ? await service.pushPending({ reason: '手动补推（仅未确认的服务器）' })
      : await service.pushConfig({ serverIds, reason: '手动重推' })
    return { ok: push.ok, push }
  }))

  // 审计流水（只记配置变更：晋升动作发生在游戏服侧，宿主拿不到逐次事件）
  app.get('/api/qq-promotion/audit', ...admin, wrap(async (req) => ({
    ok: true,
    rows: await service.audit.tail(Number((req.query || {}).limit) || 50),
  })))

  // ── 连接恢复补推（对齐 qq-bind/plugins/qq-bind/index.js:1433-1440 的做法）──
  const repush = (why) => {
    if (service.config.push.pushOnServerConnect === false) return
    service.pushPending({ reason: why }).catch((err) => {
      console.error(`[qq-promotion] ${why}补推失败：${err.message}`)
    })
  }
  try {
    ctx.on('push/connected', () => repush('服务器连接建立'))
    ctx.on('servers/loaded', () => repush('服务器列表加载'))
  } catch (err) {
    // ctx.on 在个别宿主版本上不可用/不允许：补推少一层兜底但插件照常工作，如实记录
    console.error(`[qq-promotion] 事件订阅失败（连接恢复补推不可用）：${err.message}`)
  }

  console.log(
    `[qq-promotion] 已挂载：晋升${service.config.enabled ? '已启用' : '未启用'}` +
    `（目标组 ${service.config.targetGroup || '未设置'}，模式 ${service.config.mode}，` +
    `忽略组 ${service.config.ignoreGroups.join('/') || '空'}）；` +
    `下发端点 ${'/data/promotion/snapshot'}（需要游戏服安装 ${DLL_NAME}）`,
  )

  // 返回 dispose effect：cordis 在插件禁用/卸载时调用（停定时器）
  return () => service.dispose()
}
