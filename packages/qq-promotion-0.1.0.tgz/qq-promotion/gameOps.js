/**
 * 游戏服调用层（宿主 → TShock）
 *
 * 本件用自己的端点前缀 `/data/promotion/*`，**不复用** qq-bind 的 `/data/qq/*`：
 * 两个插件各自独立发布，共用前缀会让"DLL 没装"的 404 无法区分是哪一半缺失
 * （enum 级别的排障体验，见 docs/QQ绑定基础件设计.md §6.3 对 404 两种含义的处理）。
 * 前缀先例：plugins/online-stats/index.js:63 的 `/data/online`。
 *
 * 传输契约：**GET + query 参数**。理由与 qq-bind/plugins/qq-bind/gameOps.js:134-140 一致：
 *   TShock 的 SecureRestCommand 语义是"带 token 的 GET"，插件侧只读 args.Parameters；
 *   "form body 是否被解析进 Parameters"在本项目没有先例可证，赌它会解析等于把失败做成静默。
 *   本件载荷只有 5 个短字段（version/enabled/targetGroup/mode/ignoreGroups），
 *   远低于 URL 长度上限，无需分块。
 *
 * 错误语义照 online-stats（plugins/online-stats/index.js:543-577）与 qq-bind 的既有约定，
 * 保证"服务器半缺失"在各插件里表现一致：
 *   404      → 501 + serverHalfMissing=true（目标服没装 QqPromotion.dll）
 *   401/403  → 502（token 缺 data.rest.invsee 权限）
 *   网络/超时 → 502
 */
import { normalizeIgnoreGroups, normalizeMode, normalizeTargetGroup } from './config.js'

/** 游戏服半的端点前缀 */
export const SERVER_HALF_PREFIX = '/data/promotion'

/** 游戏服半的 DLL 名（报错文案用） */
export const DLL_NAME = 'QqPromotion.dll'

/** 本件端点的权限节点（与 TShock 侧 SecureRestCommand 注册的权限一致） */
export const REST_PERMISSION = 'data.rest.invsee'

/** 构造带 status 的错误（宿主路由按 err.status 回状态码） */
export function httpError(status, message, extra = {}) {
  const err = new Error(message)
  err.status = status
  Object.assign(err, extra)
  return err
}

/** 把游戏服返回的 ignoreGroups 归一成数组（服端可能回 JArray/数组/逗号串；非法即空数组） */
function toGroupList(value) {
  if (Array.isArray(value)) return value.map(String)
  if (typeof value === 'string' && value.trim() !== '') {
    return value.split(/[\s,;，；]+/).filter((s) => s !== '').map(String)
  }
  return []
}

export function createGameOps({ ctx }) {
  const log = (...args) => {
    try {
      console.log('[qq-promotion]', ...args)
    } catch {
      /* 忽略 */
    }
  }

  /** 启用中的服务器（拉原始记录，含 token，代理要用） */
  async function enabledServers() {
    const list = await ctx.servers.list()
    const out = []
    for (const s of list) {
      if (s.enabled === false) continue
      const raw = ctx.servers.getRaw(s.id)
      if (raw) out.push(raw)
    }
    return out
  }

  function rawOf(serverId) {
    return ctx.servers.getRaw(String(serverId)) || null
  }

  /** 统一把 fetchFor 的结果翻成数据或抛错 */
  function unwrap(server, result, label) {
    if (result.ok) return result.data || {}
    if (result.status === 404) {
      throw httpError(501, `游戏服端未安装 ${DLL_NAME}（${label} 返回 404）：请在「插件下发」页对该服务器启用`, {
        serverHalfMissing: true,
        serverId: server.id,
        missingDll: DLL_NAME,
      })
    }
    if (result.status === 401 || result.status === 403) {
      throw httpError(502, `游戏服 token 权限不足（HTTP ${result.status}）：需要 ${REST_PERMISSION} 权限`, {
        serverId: server.id,
      })
    }
    if (result.status === 400) {
      // 服端的参数校验拒绝（例如"启用但目标组为空"）——如实回传服端的 error 文案，
      // 不吞成 502，否则管理员只会看到"游戏服返回异常"而不知道自己要改哪里
      const detail = result.data && result.data.error ? result.data.error : '参数被游戏服拒绝'
      throw httpError(400, `游戏服拒绝该次下发：${detail}`, { serverId: server.id })
    }
    const detail = result.data && result.data.error ? `：${result.data.error}` : ''
    throw httpError(502, `游戏服返回异常（HTTP ${result.status}）${detail}`, { serverId: server.id })
  }

  async function callGet(server, suffix, params = {}) {
    let result
    try {
      result = await ctx.tshock.fetchFor(server, `${SERVER_HALF_PREFIX}${suffix}`, params)
    } catch (err) {
      throw httpError(502, `连接游戏服失败：${err.message}`, { serverId: server.id })
    }
    return unwrap(server, result, `GET ${SERVER_HALF_PREFIX}${suffix}`)
  }

  return {
    enabledServers,
    rawOf,

    /**
     * 下发晋升配置（整份替换，幂等）。
     *
     * 参数命名与 qq-bind 的既有约定对齐：query 全小驼峰、布尔用 1/0
     * （plugins/qq-bind/gameOps.js:153-162 的 syncAccounts/syncUuid 就是这么发的）；
     * 数组按"JSON 字符串塞进 query"的既有做法传（tshockService.js:1178 把 JSON 编码进 query）。
     *
     * **载荷永远带齐 4 个字段**：ignoreGroups 缺失曾导致服端空保护名单（见 config.js 顶部说明），
     * 所以这里宁可显式发 `[]` 也不省略字段；本函数还会再归一一次，防止调用方漏传。
     */
    async pushConfig(server, payload = {}) {
      const version = Math.max(1, Math.floor(Number(payload.version) || 1))
      const enabled = payload.enabled === true
      const targetGroup = normalizeTargetGroup(payload.targetGroup)
      const mode = normalizeMode(payload.mode)
      const ignoreGroups = normalizeIgnoreGroups(payload.ignoreGroups)

      const data = await callGet(server, '/snapshot', {
        version,
        enabled: enabled ? 1 : 0,
        targetGroup,
        mode,
        ignoreGroups: JSON.stringify(ignoreGroups),
        ts: new Date().toISOString(),
      })

      return {
        ok: true,
        applied: data.applied === true,
        // 服端已有更新版本时不会用旧配置覆盖（返回 stale=true），宿主据此把该服标为"未生效"
        stale: data.stale === true,
        version: Number(data.version != null ? data.version : version),
        enabled: data.enabled === true,
        targetGroup: String(data.targetGroup || ''),
        mode: String(data.mode || ''),
        ignoreGroups: toGroupList(data.ignoreGroups),
        saveError: String(data.saveError || ''),
        ignoreNote: String(data.ignoreNote || ''),
        bindings: data.bindings && typeof data.bindings === 'object'
          ? {
            count: Number(data.bindings.count || 0),
            snapshotVersion: Number(data.bindings.snapshotVersion || 0),
            snapshotUpdatedAt: String(data.bindings.snapshotUpdatedAt || ''),
            file: String(data.bindings.file || ''),
            source: String(data.bindings.source || ''),
            note: String(data.bindings.note || ''),
          }
          : null,
      }
    },

    /**
     * 服端实际生效状态（排障与"配置是否真生效"的证据）。
     * 返回的是**游戏服进程内存里当前这份配置**，不是宿主以为发过什么。
     */
    async status(server) {
      const data = await callGet(server, '/status', {})
      return {
        ok: true,
        version: Number(data.version || 0),
        enabled: data.enabled === true,
        targetGroup: String(data.targetGroup || ''),
        mode: String(data.mode || ''),
        ignoreGroups: toGroupList(data.ignoreGroups),
        updatedAt: String(data.updatedAt || ''),
        source: String(data.source || ''),
        file: String(data.file || ''),
        saveError: String(data.saveError || ''),
        bindings: {
          count: Number((data.bindings || {}).count || 0),
          snapshotVersion: Number((data.bindings || {}).snapshotVersion || 0),
          snapshotUpdatedAt: String((data.bindings || {}).snapshotUpdatedAt || ''),
          file: String((data.bindings || {}).file || ''),
          source: String((data.bindings || {}).source || ''),
          note: String((data.bindings || {}).note || ''),
        },
      }
    },

    log,
  }
}
