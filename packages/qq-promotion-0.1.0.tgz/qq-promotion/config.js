/**
 * qq-promotion 配置（<dataDir>/qq-promotion/config.json）
 *
 * 这份配置是"晋升开关"的**唯一权威**：宿主归一后经自己的端点
 * `GET /data/promotion/snapshot`（见 gameOps.js）下发给游戏服半，
 * 游戏服半原子应用并落盘 <TShock.SavePath>/qq-promotion-config.json。
 *
 * 字段就四个（与前端管理页一一对应，照 docs/QQ绑定基础件设计.md §8.1 的配置区范围）：
 *   enabled       是否启用登录时自动晋升
 *   targetGroup   目标用户组
 *   mode          'auto' = 沿父组链判断、已达目标组则跳过；其它值一律按 force（直接改组）
 *   ignoreGroups  忽略的用户组（命中则静默跳过，保护管理组不被降级）
 *
 * 与 qq-bind/plugins/qq-bind/config.js:40-45 的 promotion 块**字段语义刻意一致**（便于迁移），
 * 但本件自己存自己的文件：两个插件各自独立发布，不共享配置文件就不会互相覆盖。
 *
 * 保护性默认值的由来（这是本件相对旧实现修掉的一处单边缺失）：
 *   qq-bind 的 C# 侧 `Settings.IgnoreGroups` 初值是**空列表**（旧 plugins/qq-bind/plugin/QqPromotion.cs:40），
 *   而宿主侧默认是 ['owner','superadmin']（旧 config.js:44）。凡是"载荷不完整"的路径
 *   （老宿主只发 promotion.enabled、或发的 JSON 缺字段）都会让服端拿到**空保护名单**，
 *   此时管理员账号若不在目标组的父链下方，auto 模式照样改组 = 管理员被降级。
 *   本件在**两端**都把缺失视为"用保护默认值"：
 *     - 宿主：normalizeIgnoreGroups（缺失/null/非法类型 → DEFAULT_IGNORE_GROUPS）
 *     - 服端：QqPromotionConfig.Settings.IgnoreGroups 的字段初值即保护默认值，且 setter 把 null 折回默认
 *   并且 toGamePayload 永远把 4 个字段**带齐**发出，从源头消掉"缺字段"这条路径。
 */
import { readFile, writeFile, mkdir, copyFile, rename } from 'node:fs/promises'
import path from 'node:path'

export const CONFIG_SCHEMA = 1

/**
 * 忽略组默认值（保护名单）。与 qq-bind/plugins/qq-bind/config.js:44 一致，
 * 也让"管理员不会被自动晋升逻辑降级"这条约束在缺失配置时依然成立。
 */
export const DEFAULT_IGNORE_GROUPS = ['owner', 'superadmin']

/** 目标组默认值（与 qq-bind/plugins/qq-bind/config.js:42 一致；enabled 默认 false，故不会被误用） */
export const DEFAULT_TARGET_GROUP = 'vip'

/** 模式默认值：只有 auto 有特殊语义，缺失时按 auto（与 qq-bind/plugins/qq-bind/config.js:107 归一后的语义一致） */
export const DEFAULT_MODE = 'auto'

/** 下发与对账节奏（push.* 组，管理接口也可改） */
export const PUSH_DEFAULTS = {
  /** 配置变更后立即下发；此项为 false 只影响"变更即推"，手动推送与对账仍在 */
  pushOnChange: true,
  /** 服务器连接建立 / 服务器列表加载后补推（连接恢复补推） */
  pushOnServerConnect: true,
  /** 周期对账：无条件重推一遍（配置极小，代价可忽略；能自愈"服端配置被删改/重置"） */
  reconcileIntervalMs: 600000,
  /** 推送失败后的首次重试间隔 */
  retryIntervalMs: 60000,
  /** 失败重试的退避上限（连续失败时指数增长到此为止） */
  retryMaxIntervalMs: 600000,
}

export function defaultConfig() {
  return {
    schema: CONFIG_SCHEMA,
    enabled: false,
    targetGroup: DEFAULT_TARGET_GROUP,
    mode: DEFAULT_MODE,
    ignoreGroups: DEFAULT_IGNORE_GROUPS.slice(),
    push: { ...PUSH_DEFAULTS },
  }
}

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v)
}

/** 深合并：对象递归，数组整体替换（配置语义：给了就替换） */
export function mergeConfig(base, patch) {
  if (!isPlainObject(patch)) return base
  const out = Array.isArray(base) ? base.slice() : { ...base }
  for (const [k, v] of Object.entries(patch)) {
    if (v === undefined) continue
    if (isPlainObject(v) && isPlainObject(out[k])) out[k] = mergeConfig(out[k], v)
    else out[k] = v
  }
  return out
}

/** 数组去重（大小写不敏感，保留首次出现的写法）；非数组 → null（调用方决定回落） */
export function dedupeGroups(list) {
  if (!Array.isArray(list)) return null
  const seen = new Set()
  const out = []
  for (const item of list) {
    const name = String(item == null ? '' : item).trim()
    if (name === '') continue
    const key = name.toLowerCase()
    if (seen.has(key)) continue
    seen.add(key)
    out.push(name)
  }
  return out
}

/**
 * 忽略组归一。**这是修掉"单边缺失"的关键一处**：
 *   缺失 / null / 非数组非字符串 / 空字符串 / 拆分后为空 → DEFAULT_IGNORE_GROUPS（保护默认值）
 *   数组（含空数组）→ 逐项 trim 去空去重：空数组是管理员**显式**选择"不保护任何组"，予以保留，
 *                     但会在 configWarnings 里如实提示（不静默）。
 *   字符串 → 按换行/逗号/分号/空白拆分（配置文件手写常见形态），拆分后为空同样回落默认值。
 */
export function normalizeIgnoreGroups(value) {
  if (Array.isArray(value)) {
    const deduped = dedupeGroups(value)
    return deduped === null ? DEFAULT_IGNORE_GROUPS.slice() : deduped
  }
  if (typeof value === 'string') {
    const parts = value.split(/[\s,;，；]+/).filter((s) => s !== '')
    const deduped = dedupeGroups(parts)
    return deduped === null || deduped.length === 0 ? DEFAULT_IGNORE_GROUPS.slice() : deduped
  }
  return DEFAULT_IGNORE_GROUPS.slice()
}

/**
 * 模式归一：只有 'auto' 有特殊语义（序数忽略大小写比较），其它任何值一律归到 'force'；
 * 缺失/空白 → DEFAULT_MODE。与服端 QqPromotion.IsAutoMode 的判定一致。
 */
export function normalizeMode(value) {
  const raw = String(value == null ? '' : value).trim()
  if (raw === '') return DEFAULT_MODE
  return raw.toLowerCase() === 'auto' ? 'auto' : 'force'
}

/** 目标组归一：缺失 → 默认组；显式空串保留（由 configWarnings 提示"下发会被服端拒绝"） */
export function normalizeTargetGroup(value) {
  if (value === undefined || value === null) return DEFAULT_TARGET_GROUP
  return String(value).trim()
}

function normalizePush(value) {
  const p = isPlainObject(value) ? value : {}
  const num = (v, fallback) => {
    const n = Number(v)
    return Number.isFinite(n) && n >= 0 ? Math.floor(n) : fallback
  }
  return {
    pushOnChange: p.pushOnChange !== false,
    pushOnServerConnect: p.pushOnServerConnect !== false,
    reconcileIntervalMs: num(p.reconcileIntervalMs, PUSH_DEFAULTS.reconcileIntervalMs),
    retryIntervalMs: num(p.retryIntervalMs, PUSH_DEFAULTS.retryIntervalMs),
    retryMaxIntervalMs: Math.max(
      num(p.retryIntervalMs, PUSH_DEFAULTS.retryIntervalMs),
      num(p.retryMaxIntervalMs, PUSH_DEFAULTS.retryMaxIntervalMs),
    ),
  }
}

/** 类型归一与兜底（读到脏配置时不让它把功能静默关掉，也不让它把保护名单变成空的） */
export function normalizeConfig(cfg) {
  const out = mergeConfig(defaultConfig(), cfg)
  return {
    schema: CONFIG_SCHEMA,
    enabled: out.enabled === true,
    targetGroup: normalizeTargetGroup(out.targetGroup),
    mode: normalizeMode(out.mode),
    ignoreGroups: normalizeIgnoreGroups(out.ignoreGroups),
    push: normalizePush(out.push),
  }
}

/**
 * 生效性检查（**不作为拒绝依据**，只用来把问题显式暴露给管理员）：
 * 返回 [{ level: 'error'|'warn', message }]。管理页与 /status 都会展示，
 * 免得出现"界面显示已启用、实际不可能生效"这种静默失效。
 */
export function configWarnings(cfg) {
  const c = normalizeConfig(cfg)
  const out = []
  if (c.enabled && c.targetGroup === '') {
    out.push({ level: 'error', message: '已启用晋升但目标用户组为空：服端会以 400 拒绝该次下发，晋升不会生效' })
  }
  if (c.ignoreGroups.length === 0) {
    out.push({
      level: 'warn',
      message: '忽略的用户组为空：没有任何保护名单，若管理员账号不在目标组父链下方，auto 模式会把管理员改组',
    })
  }
  return out
}

/**
 * 下发给游戏服的载荷。**4 个字段永远带齐**（含 ignoreGroups 为空数组时也显式发 []），
 * 因为"载荷缺字段 → 服端拿到空保护名单"正是旧实现的缺陷来源。
 */
export function toGamePayload(cfg, version) {
  const c = normalizeConfig(cfg)
  return {
    version: Math.max(1, Math.floor(Number(version) || 1)),
    enabled: c.enabled === true,
    targetGroup: c.targetGroup,
    mode: c.mode,
    ignoreGroups: c.ignoreGroups.slice(),
  }
}

/**
 * 读配置：
 *   不存在 → 默认值（未启用，安全方向）
 *   非法 JSON / 结构不符 → **也返回默认值**，同时把错误如实带回（error 字段）
 *
 * 为什么不像 qq-bind/plugins/qq-bind/config.js:124-140 那样抛错：那是"配置损坏就别启动"的取向，
 * 本件选择"配置损坏 = 按未启用运行 + 明确报错"——原因有二：① 未启用是安全方向（绝不会误晋升）；
 * ② 插件装载失败会让"界面里连配置都看不到"，管理员没有修复入口。错误经 GET /api/qq-promotion/config
 * 与 /status 的 configError 回显。
 */
export async function loadConfig(file) {
  let raw
  try {
    raw = await readFile(file, 'utf8')
  } catch (err) {
    if (err.code === 'ENOENT') return { config: defaultConfig(), existed: false, error: '' }
    return {
      config: defaultConfig(),
      existed: true,
      error: `配置文件读取失败（${file}）：${err.message}；已按默认配置（未启用）运行`,
    }
  }
  let parsed
  try {
    parsed = JSON.parse(raw)
  } catch (err) {
    return {
      config: defaultConfig(),
      existed: true,
      error: `配置文件不是合法 JSON（${file}）：${err.message}；已按默认配置（未启用）运行，请修复后重新保存`,
    }
  }
  if (!isPlainObject(parsed)) {
    return {
      config: defaultConfig(),
      existed: true,
      error: `配置文件顶层不是对象（${file}）；已按默认配置（未启用）运行`,
    }
  }
  return { config: normalizeConfig(parsed), existed: true, error: '' }
}

/** 原子落盘（.tmp + rename，保留 .bak）：半个文件不会被下次读取当成配置 */
export async function saveConfig(file, cfg) {
  const payload = JSON.stringify(normalizeConfig(cfg), null, 2)
  await mkdir(path.dirname(file), { recursive: true })
  const tmp = `${file}.tmp`
  await writeFile(tmp, payload, 'utf8')
  try {
    await copyFile(file, `${file}.bak`)
  } catch (err) {
    if (err.code !== 'ENOENT') throw err
  }
  await rename(tmp, file)
  return file
}

/**
 * 管理接口可写的路径白名单（值是校验器）。结构类字段（schema）不可写。
 * 与 qq-bind/plugins/qq-bind/config.js:161-176 同一套约定：只允许按点号路径改已知字段。
 */
export const EDITABLE_PATHS = {
  enabled: (v) => typeof v === 'boolean',
  targetGroup: (v) => typeof v === 'string' && v.trim() !== '',
  mode: (v) => typeof v === 'string' && ['auto', 'force'].includes(v.trim().toLowerCase()),
  ignoreGroups: (v) => Array.isArray(v) && v.every((x) => typeof x === 'string'),
  'push.pushOnChange': (v) => typeof v === 'boolean',
  'push.pushOnServerConnect': (v) => typeof v === 'boolean',
  'push.reconcileIntervalMs': (v) => Number.isFinite(Number(v)) && Number(v) >= 0,
  'push.retryIntervalMs': (v) => Number.isFinite(Number(v)) && Number(v) >= 0,
  'push.retryMaxIntervalMs': (v) => Number.isFinite(Number(v)) && Number(v) >= 0,
}

function badRequest(message, extra = {}) {
  const err = new Error(message)
  err.status = 400
  Object.assign(err, extra)
  return err
}

/** 按点号路径写值（仅白名单；类型不符即 400：不把非法值写进配置） */
export function setByPath(cfg, dottedPath, value) {
  const key = String(dottedPath == null ? '' : dottedPath).trim()
  if (!key) throw badRequest('缺少参数: path')
  const validator = EDITABLE_PATHS[key]
  if (!validator) {
    throw badRequest(`不可写的配置项：${key}（可写项：${Object.keys(EDITABLE_PATHS).join('、')}）`)
  }
  if (!validator(value)) throw badRequest(`${key} 的值类型不合法（收到 ${JSON.stringify(value)}）`)

  const parts = key.split('.')
  let node = cfg
  for (const part of parts.slice(0, -1)) {
    if (!isPlainObject(node[part])) node[part] = {}
    node = node[part]
  }
  node[parts[parts.length - 1]] = value
  return cfg
}
