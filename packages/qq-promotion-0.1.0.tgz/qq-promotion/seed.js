/**
 * 旧配置迁移 seed（qq-bind 的 promotion 块 → 本件自己的配置）
 *
 * 背景：晋升原来内嵌在 qq-bind 里，配置存在 `<dataDir>/qq-bind/config.json` 的 `promotion` 块。
 * 摘除该功能时**刻意保留了用户原值**（qq-bind 的 mergeConfig 对未知字段原样透传，
 * 见 plugins/qq-bind/config.js 的 mergeConfig），所以老用户的开关/目标组/忽略组还在那个文件里。
 * 本模块负责在**首次运行**时把它搬过来，避免"升级后用户配置人间蒸发、晋升悄悄退回默认"。
 *
 * 四条硬规则（缺一条都会造成"用户配置被改坏"这类难查故障）：
 *   1. **只在首次运行触发**：本件自己的配置文件不存在时才尝试；已存在就绝不覆盖
 *      （哪怕旧值与现值不同 —— 用户可能已经在本件里改过）。
 *   2. **qq-bind 是软依赖**：它可能根本没装。取服务一律走 optionalService
 *      （ctx.get 优先、失败再 try ctx[name]）；取不到就当"没有可迁移的旧值"。
 *      **绝不能**写成 `ctx.qqBind?.x`：未 inject 的服务是"属性访问即抛错"
 *      （docs/插件开发约定.md §2.3，可选链挡不住；本仓刚因此出过一次线上故障）。
 *   3. **旧值必须过本件自己的归一**：只采用旧块里存在的字段，缺失的字段用本件默认值；
 *      采用的字段一律经 normalizeConfig / normalizeMode / normalizeIgnoreGroups 校验，
 *      绝不把未校验的旧值直接写进配置文件。
 *   4. **迁移是尽力而为**：任何异常都只记日志、绝不上抛 —— 读不出旧配置不该让本插件加载失败。
 *
 * 另外：**不删除** qq-bind 配置里的旧 promotion 块（保留无害，删了会让回退/排查无从取材）。
 *
 * 约定：禁止 emoji；文件 IO 走只读（本模块不写别的插件的数据目录）。
 */
import { readFile } from 'node:fs/promises'
import path from 'node:path'

import {
  defaultConfig,
  normalizeConfig,
  normalizeIgnoreGroups,
  normalizeMode,
} from './config.js'

/** 旧配置所在的插件名（数据目录名与文件布局都由它推导） */
export const LEGACY_SOURCE_PLUGIN = 'qq-bind'

/**
 * 旧 `promotion` 块里本件认识的字段。
 * 与 plugins/qq-bind/config.js 的 promotion 语义一致（本件 config.js:8-15 也是照它对齐的）。
 */
export const LEGACY_PROMOTION_KEYS = ['enabled', 'targetGroup', 'mode', 'ignoreGroups']

/** 旧配置文件名（qq-bind 的配置文件固定在它自己的数据目录下，见 qq-bind/index.js 的 configFile） */
const LEGACY_CONFIG_FILE = 'config.json'

/** 旧块外层字段名 */
const LEGACY_BLOCK = 'promotion'

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v)
}

/**
 * 取一个**软依赖**服务（拿不到就返回 null，绝不抛）。
 *
 * 两级取法（照搬 plugins/legacy-import/modules/registry.js:63-78 的已验证做法）：
 *   1. `ctx.get(name)`：服务由 Service 子类注册（super(ctx, 'name')）时命中；
 *      未注册时返回 undefined。注意它看不到"普通属性赋值"挂上去的假服务。
 *   2. `ctx[name]`：包在 try 里读；未 inject 的 ctx 代理在这里抛错，按"没有该服务"处理。
 */
export function optionalService(ctx, name) {
  try {
    if (ctx && typeof ctx.get === 'function') {
      const svc = ctx.get(name)
      if (svc) return svc
    }
  } catch {
    /* 取不到就当没有：软依赖失败一律降级，绝不冒泡成"插件加载失败" */
  }
  try {
    return (ctx && ctx[name]) || null
  } catch {
    /* 未 inject 的 ctx 代理在这里抛错：按"没有该服务"处理 */
    return null
  }
}

/**
 * 读 qq-bind 旧配置里的 promotion 块（**只读，不改动对方文件**）。
 *
 * @returns {Promise<{ available: boolean, promotion: object|null, file: string, reason: string }>}
 *   available=false 时 reason 说明"为什么没有可迁移的旧值"（不进日志的敏感内容，仅路径与原因）。
 */
export async function readLegacyPromotion(ctx) {
  if (!optionalService(ctx, 'qqBind')) {
    // qq-bind 没装（或它的服务没就绪）：没有旧值可迁移，这不是错误
    return { available: false, promotion: null, file: '', reason: 'qq-bind 未安装（取不到 ctx 上的 qqBind 服务）' }
  }

  let file
  try {
    file = path.join(ctx.paths.dataOf(LEGACY_SOURCE_PLUGIN), LEGACY_CONFIG_FILE)
  } catch (err) {
    return { available: false, promotion: null, file: '', reason: `推导 qq-bind 配置路径失败：${err.message}` }
  }

  let raw
  try {
    raw = await readFile(file, 'utf8')
  } catch (err) {
    const why = err.code === 'ENOENT' ? 'qq-bind 还没有配置文件' : `读取失败：${err.message}`
    return { available: false, promotion: null, file, reason: why }
  }

  let parsed
  try {
    parsed = JSON.parse(raw)
  } catch (err) {
    return { available: false, promotion: null, file, reason: `qq-bind 配置不是合法 JSON：${err.message}` }
  }

  if (!isPlainObject(parsed) || !isPlainObject(parsed[LEGACY_BLOCK])) {
    return { available: false, promotion: null, file, reason: 'qq-bind 配置里没有 promotion 块' }
  }

  return { available: true, promotion: parsed[LEGACY_BLOCK], file, reason: '' }
}

/**
 * 把旧 promotion 块合成到本件配置上（**纯函数**，不落盘、不读文件）。
 *
 * 采用规则（逐字段）：
 *   enabled      boolean 才采用；其它类型视为不可用（保持默认 false，安全方向）
 *   targetGroup  非空字符串采用（trim 后）；空/空白**不采用**——空目标组会让"已启用"
 *                永远无法生效（前端 configWarnings 会直接报 error），迁移不该把这种
 *                坏状态搬进来，改用本件默认组
 *   mode         一律经 normalizeMode：非 auto 归一到 'force'；空/空白回落默认 'auto'
 *                （与本件归一完全一致，不自己另立口径）
 *   ignoreGroups 一律经 normalizeIgnoreGroups：数组去空去重（空数组是显式选择，保留）；
 *                字符串按分隔符拆；其它类型回落保护默认值 ['owner','superadmin']
 *
 * @returns {{ config: object, adopted: string[], skipped: string[] }}
 *   adopted = 旧块里**存在且被采用**的字段名；skipped = 存在但不可用、回落默认值的字段名。
 *   两者都只含字段名，不含值（便于写日志/审计而不暴露配置内容）。
 */
export function seedFromLegacyPromotion(promotion, base = defaultConfig()) {
  const out = normalizeConfig(base)
  const adopted = []
  const skipped = []

  if (!isPlainObject(promotion)) return { config: out, adopted, skipped }

  for (const key of LEGACY_PROMOTION_KEYS) {
    if (!Object.prototype.hasOwnProperty.call(promotion, key)) continue // 缺失 → 保持本件默认值
    const value = promotion[key]
    if (value === undefined || value === null) {
      skipped.push(key)
      continue
    }

    if (key === 'enabled') {
      if (typeof value !== 'boolean') {
        skipped.push(key)
        continue
      }
      out.enabled = value
    } else if (key === 'targetGroup') {
      const group = String(value).trim()
      if (group === '') {
        skipped.push(key)
        continue
      }
      out.targetGroup = group
    } else if (key === 'mode') {
      out.mode = normalizeMode(value)
    } else if (key === 'ignoreGroups') {
      out.ignoreGroups = normalizeIgnoreGroups(value)
    }

    adopted.push(key)
  }

  // 再整体过一遍归一：即便上面逐字段已经校验过，落盘前也保证产物是"本件认可的形态"
  return { config: normalizeConfig(out), adopted, skipped }
}
