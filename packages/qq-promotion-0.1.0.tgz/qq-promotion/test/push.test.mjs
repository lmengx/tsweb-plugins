/**
 * 下发链路测试（真实 apply + 假宿主 ctx + 假游戏服半）
 *
 * 覆盖本次任务要求的下发链路四件事：
 *   1. 配置变更 → **立即下发**（POST /api/qq-promotion/config 内同步完成，不是等对账周期）
 *   2. 下发失败 → 逐服如实回显（含"没装 DLL"的 501 语义），并按退避**自动重试**
 *   3. 连接恢复 / 服务器列表加载 → **补推**（只打还没确认最新配置的服）
 *   4. 服端实际生效状态的**探测**（probe）：与宿主配置逐字段比对，不一致必须报出来
 *
 * 另外锁住两条"不许悄悄退化"的行为：
 *   - 启动即对账一次，且载荷里 ignoreGroups 带的是保护默认值（不是空数组）
 *   - 配置变更写审计 qqpromotion.config.set
 *
 * 注意：本测试**不启动任何服务进程**，也不引入 express/cordis（见 test/support/fake-host.mjs 的说明）。
 * 运行：node test/push.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, readFile, writeFile, mkdir } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { apply } from '../index.js'
import { defaultConfig } from '../config.js'
import { makeFakeHost, makeGameHalf, waitFor } from './support/fake-host.mjs'

const SERVERS = [
  { raw: { id: 's1', name: '一服', host: '127.0.0.1', port: 7777, token: 't1', enabled: true } },
  { raw: { id: 's2', name: '二服', host: '127.0.0.1', port: 7778, token: 't2', enabled: true } },
]

let dir
let seq = 0

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), 'qqpromo-push-'))
})

after(async () => {
  await rm(dir, { recursive: true, force: true })
})

async function boot({ servers = SERVERS } = {}) {
  seq += 1
  const dataDir = path.join(dir, `case-${seq}`)
  const gameHalf = makeGameHalf({ serverIds: servers.map((s) => s.raw.id) })
  const host = makeFakeHost({ dataDir, servers, fetchFor: gameHalf.fetchFor })
  const dispose = await apply(host.ctx)
  return { dataDir, host, gameHalf, dispose }
}

/**
 * 插件的数据目录与配置文件路径：index.js 用 ctx.paths.dataOf('qq-promotion')，
 * 而假宿主的 dataOf(n) = <dataDir>/n，所以配置文件在 <dataDir>/qq-promotion/config.json。
 */
function pluginDataDir(dataDir) {
  return path.join(dataDir, 'qq-promotion')
}
function pluginConfigFile(dataDir) {
  return path.join(pluginDataDir(dataDir), 'config.json')
}

/** 让所有服都确认本次启动下发（异步流程，需要等一下） */
async function waitAllAcked(host, count) {
  return waitFor(() => host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length >= count, {
    label: `启动下发打到 ${count} 台服`,
  })
}

// ═══════════════ 1. 挂载与启动对账 ═══════════════

test('apply：注册 4 个管理端点 + 订阅连接恢复事件 + 启动即对账下发', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    for (const p of ['/api/qq-promotion/config', '/api/qq-promotion/status', '/api/qq-promotion/push', '/api/qq-promotion/audit']) {
      assert.ok(host.hasRoute('get', p) || host.hasRoute('post', p), `应注册端点 ${p}`)
    }
    assert.ok(host.hasRoute('get', '/api/qq-promotion/config'))
    assert.ok(host.hasRoute('post', '/api/qq-promotion/config'))
    assert.ok(host.hasRoute('get', '/api/qq-promotion/status'))
    assert.ok(host.hasRoute('post', '/api/qq-promotion/push'))
    assert.ok(host.hasRoute('get', '/api/qq-promotion/audit'))

    // 连接恢复补推的两个事件必须订阅（卸载时由 cordis 回收）
    assert.equal(host.fire('push/connected'), true)
    assert.equal(host.fire('servers/loaded'), true)

    await waitAllAcked(host, 2)
    const first = host.calls.find((c) => c.pathname === '/data/promotion/snapshot')
    assert.equal(first.params.enabled, 0, '默认未启用：下发时 enabled=0')
    assert.equal(first.params.mode, 'auto')
    // 关键断言：载荷必须带保护默认值，而不是空数组（这就是修掉的那处单边缺失）
    assert.deepEqual(JSON.parse(first.params.ignoreGroups), ['owner', 'superadmin'])
    assert.ok(Number(first.params.version) >= 1, 'version 必须是正整数')

    // 假服端确实收下并生效了
    assert.equal(gameHalf.applied.get('s1').enabled, false)
    assert.equal(gameHalf.applied.get('s2').enabled, false)
  } finally {
    dispose()
  }
})

test('启动对账：宿主重启后即便配置已在文件里，也会主动推一次（不依赖任何变更触发）', async () => {
  seq += 1
  const dataDir = path.join(dir, `restart-${seq}`)
  const cfgFile = pluginConfigFile(dataDir)
  // 先按"上一轮已保存过配置"的形态落盘（此时宿主还没启动）
  await mkdir(path.dirname(cfgFile), { recursive: true })
  await writeFile(cfgFile, JSON.stringify({ ...defaultConfig(), enabled: true, targetGroup: 'vip' }), 'utf8')

  const gameHalf = makeGameHalf({ serverIds: ['s1'] })
  const host = makeFakeHost({ dataDir, servers: [SERVERS[0]], fetchFor: gameHalf.fetchFor })
  const dispose = await apply(host.ctx)
  try {
    await waitFor(() => gameHalf.applied.has('s1'), { label: '启动对账把文件里的配置推给服端' })
    assert.equal(gameHalf.applied.get('s1').enabled, true)
    assert.equal(gameHalf.applied.get('s1').targetGroup, 'vip')
  } finally {
    dispose()
  }
})

// ═══════════════ 2. 配置变更 → 立即下发 ═══════════════

test('POST config：保存落盘 + 写审计 + 同一请求内立即下发（响应即逐服结果）', async () => {
  const { dataDir, host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    const before = host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length

    const res = await host.call('post', '/api/qq-promotion/config', {
      body: {
        updates: {
          enabled: true,
          targetGroup: 'vip',
          mode: 'auto',
          ignoreGroups: ['owner', 'superadmin', 'admin'],
        },
      },
    })

    assert.equal(res.status, 200)
    assert.equal(res.data.ok, true)
    assert.equal(res.data.push.ok, true, '两台都成功时 push.ok 必须为 true')
    assert.equal(res.data.push.okCount, 2)
    assert.equal(res.data.push.total, 2)
    for (const s of res.data.push.servers) assert.equal(s.ok, true, `${s.name} 应确认生效`)

    // 响应返回时下发**已经**发生（不是"稍后异步推"）：这就是"改配置立即下发"的保证
    assert.equal(host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length, before + 2)
    assert.equal(gameHalf.applied.get('s1').enabled, true)
    assert.equal(gameHalf.applied.get('s1').targetGroup, 'vip')
    assert.deepEqual(gameHalf.applied.get('s1').ignoreGroups, ['owner', 'superadmin', 'admin'])
    assert.equal(gameHalf.applied.get('s2').enabled, true)

    // 落盘
    const saved = JSON.parse(await readFile(pluginConfigFile(dataDir), 'utf8'))
    assert.equal(saved.enabled, true)
    assert.equal(saved.targetGroup, 'vip')
    assert.deepEqual(saved.ignoreGroups, ['owner', 'superadmin', 'admin'])

    // 审计
    const audit = await host.call('get', '/api/qq-promotion/audit?limit=10')
    assert.equal(audit.data.rows[0].action, 'qqpromotion.config.set')
    assert.equal(audit.data.rows[0].enabled, true)
    assert.ok(audit.data.rows[0].keys.includes('targetGroup'))

    // 状态端点能看到"期望版本"与逐服结果
    const status = await host.call('get', '/api/qq-promotion/status')
    assert.equal(status.data.config.enabled, true)
    assert.equal(status.data.servers.length, 2)
    assert.equal(status.data.pendingCount, 0)
  } finally {
    dispose()
  }
})

test('POST config：非法值被 400 拒绝，且不落盘、不下发', async () => {
  const { dataDir, host, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    const before = host.calls.length

    const bad1 = await host.call('post', '/api/qq-promotion/config', { body: { updates: { mode: 'fast' } } })
    assert.equal(bad1.status, 400)
    assert.match(bad1.data.error, /不合法/)

    const bad2 = await host.call('post', '/api/qq-promotion/config', { body: { updates: { targetGroup: '   ' } } })
    assert.equal(bad2.status, 400)

    const bad3 = await host.call('post', '/api/qq-promotion/config', { body: {} })
    assert.equal(bad3.status, 400)

    assert.equal(host.calls.length, before, '被拒绝的请求不应触发任何下发')
    await assert.rejects(readFile(pluginConfigFile(dataDir), 'utf8'), '被拒绝时不应写出配置文件')
  } finally {
    dispose()
  }
})

// ═══════════════ 3. 失败语义与重试 ═══════════════

test('下发失败：未装 DLL（404）→ 501 serverHalfMissing，逐服如实回显且不假装成功', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    gameHalf.setBehavior('s2', 'missing')

    const res = await host.call('post', '/api/qq-promotion/config', { body: { updates: { enabled: true, targetGroup: 'vip' } } })
    assert.equal(res.status, 200)
    assert.equal(res.data.push.ok, false, '有一台失败时 push.ok 必须是 false')
    assert.equal(res.data.push.okCount, 1)
    assert.equal(res.data.push.pendingCount, 1)

    const s2 = res.data.push.servers.find((s) => s.id === 's2')
    assert.equal(s2.ok, false)
    assert.equal(s2.serverHalfMissing, true)
    assert.equal(s2.status, 501)
    assert.match(s2.error, /QqPromotion\.dll/)

    const status = await host.call('get', '/api/qq-promotion/status')
    const row = status.data.servers.find((s) => s.id === 's2')
    assert.equal(row.ok, false)
    assert.match(row.error, /插件下发/)
  } finally {
    dispose()
  }
})

test('权限不足（403）与参数被拒（400）分别归类，不混成同一句话', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)

    gameHalf.setBehavior('s1', 'forbidden')
    let res = await host.call('post', '/api/qq-promotion/config', { body: { updates: { targetGroup: 'vip' } } })
    let row = res.data.push.servers.find((s) => s.id === 's1')
    assert.equal(row.ok, false)
    assert.equal(row.status, 502)
    assert.match(row.error, /data\.rest\.invsee/)

    gameHalf.setBehavior('s1', 'badRequest')
    res = await host.call('post', '/api/qq-promotion/config', { body: { updates: { targetGroup: 'vip' } } })
    row = res.data.push.servers.find((s) => s.id === 's1')
    assert.equal(row.ok, false)
    assert.equal(row.status, 400)
    assert.match(row.error, /游戏服拒绝该次下发/)
  } finally {
    dispose()
  }
})

test('服端 stale：宿主的旧版本载荷被拒时标记为未生效（不会被当成成功）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    gameHalf.setBehavior('s1', 'stale')
    const res = await host.call('post', '/api/qq-promotion/config', { body: { updates: { enabled: true, targetGroup: 'vip' } } })
    const row = res.data.push.servers.find((s) => s.id === 's1')
    assert.equal(row.ok, false)
    assert.equal(row.stale, true)
    assert.match(row.error, /服端已有更新版本/)
  } finally {
    dispose()
  }
})

test('失败重试：失败后按退避自动重试，服端恢复后自动变成已生效并停止重试', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)

    // 先把重试间隔改小（真实部署是 60s，测试里 30ms）
    gameHalf.setBehavior('s2', 'missing')
    const res = await host.call('post', '/api/qq-promotion/config', {
      body: { updates: { enabled: true, targetGroup: 'vip', 'push.retryIntervalMs': 30, 'push.retryMaxIntervalMs': 60 } },
    })
    assert.equal(res.data.push.ok, false)
    const status1 = await host.call('get', '/api/qq-promotion/status')
    assert.equal(status1.data.retryScheduled, true, '有失败时必须有重试在排队')
    assert.equal(status1.data.pendingCount, 1)

    const callsBefore = host.calls.filter((c) => c.pathname === '/data/promotion/snapshot' && c.serverId === 's2').length
    const s1CallsBefore = host.calls.filter((c) => c.pathname === '/data/promotion/snapshot' && c.serverId === 's1').length

    // 服端"装上了 DLL"
    gameHalf.setBehavior('s2', 'ok')

    // 不需要任何人工动作：重试应该自己把它补上（pushPending 只打未确认的服）
    await waitFor(async () => {
      const st = await host.call('get', '/api/qq-promotion/status')
      return st.data.pendingCount === 0 && st.data.servers.find((s) => s.id === 's2').ok
    }, { label: '自动重试把 s2 补上', timeoutMs: 3000, intervalMs: 20 })

    const s2Calls = host.calls.filter((c) => c.pathname === '/data/promotion/snapshot' && c.serverId === 's2').length
    assert.ok(s2Calls > callsBefore, '应至少发生一次重试下发')
    // 重试只补落后的服：已确认过的 s1 不该被反复打扰
    assert.equal(
      host.calls.filter((c) => c.pathname === '/data/promotion/snapshot' && c.serverId === 's1').length,
      s1CallsBefore,
      '重试只应打未确认的服',
    )
    // 重试不应对已确认的 s1 再发（只补落后的服）
    const status2 = await host.call('get', '/api/qq-promotion/status')
    assert.equal(status2.data.retryScheduled, false, '全部确认后必须停止重试定时器')
    assert.equal(gameHalf.applied.get('s2').enabled, true)
  } finally {
    dispose()
  }
})

// ═══════════════ 4. 连接恢复补推 ═══════════════

test('连接恢复补推：只推未确认的服务器；全部确认时一个请求都不发', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    const callsAllAcked = host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length

    // 全部已确认 → 补推是空操作
    host.fire('push/connected')
    host.fire('servers/loaded')
    await new Promise((r) => setTimeout(r, 30))
    assert.equal(
      host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length,
      callsAllAcked,
      '全部已确认时不应再发下发请求',
    )

    // 新来一台服务器（从未确认过）→ 连接建立时必须补推给它
    host.setRaw('s3', { id: 's3', name: '三服', host: '127.0.0.1', port: 7779, token: 't3', enabled: true })
    gameHalf.behavior.set('s3', 'ok')
    host.fire('push/connected')

    await waitFor(() => host.calls.some((c) => c.pathname === '/data/promotion/snapshot' && c.serverId === 's3'), {
      label: '连接建立后给新服补推',
    })
    assert.ok(gameHalf.applied.has('s3'), '新服应收到配置')
  } finally {
    dispose()
  }
})

test('pushOnServerConnect=false 时不做连接恢复补推（配置能关掉这层兜底）', async () => {
  const { host, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    await host.call('post', '/api/qq-promotion/config', { body: { updates: { 'push.pushOnServerConnect': false } } })
    const before = host.calls.length
    host.setRaw('s3', { id: 's3', name: '三服', host: '127.0.0.1', port: 7779, token: 't3', enabled: true })
    host.fire('push/connected')
    await new Promise((r) => setTimeout(r, 30))
    assert.equal(host.calls.length, before, '关闭后不应因连接事件补推')
  } finally {
    dispose()
  }
})

// ═══════════════ 5. 探测（服端实际生效 vs 宿主配置） ═══════════════

test('probe=1：逐服探测服端实际生效的配置并比对，不一致必须报出差异', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    await host.call('post', '/api/qq-promotion/config', { body: { updates: { enabled: true, targetGroup: 'vip' } } })

    let res = await host.call('get', '/api/qq-promotion/status?probe=1')
    assert.equal(res.data.probe.servers.length, 2)
    for (const p of res.data.probe.servers) {
      assert.equal(p.ok, true)
      assert.equal(p.match, true, '刚下发成功，服端应与宿主一致')
      assert.equal(p.state.enabled, true)
      assert.equal(p.state.bindings.count, 2, '服端绑定快照读取状态应回传（用于判断"识别得出多少已绑定账号"）')
    }

    // 服端被人改成了别的目标组（模拟"服端配置被改坏/被旧版本顶掉"）
    gameHalf.applied.set('s1', { version: 1, enabled: true, targetGroup: 'old-group', mode: 'auto', ignoreGroups: ['owner'] })

    res = await host.call('get', '/api/qq-promotion/status?probe=1')
    const p1 = res.data.probe.servers.find((p) => p.id === 's1')
    assert.equal(p1.match, false)
    assert.ok(p1.diff.some((d) => d.includes('目标组')), `差异里应指出目标组：${p1.diff.join('；')}`)
    const p2 = res.data.probe.servers.find((p) => p.id === 's2')
    assert.equal(p2.match, true, '另一台不受影响')
  } finally {
    dispose()
  }
})

test('probe：服端没装 DLL 时该服标为未安装，不抛错也不把其它服带崩', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    gameHalf.setBehavior('s2', 'missing')
    const res = await host.call('get', '/api/qq-promotion/status?probe=1')
    assert.equal(res.status, 200)
    const p2 = res.data.probe.servers.find((p) => p.id === 's2')
    assert.equal(p2.ok, false)
    assert.equal(p2.serverHalfMissing, true)
    const p1 = res.data.probe.servers.find((p) => p.id === 's1')
    assert.equal(p1.ok, true)
  } finally {
    dispose()
  }
})

// ═══════════════ 6. 手动推送 ═══════════════

test('POST push：onlyPending 在全确认时明确回"无需下发"，不做无谓请求', async () => {
  const { host, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    const before = host.calls.length
    const res = await host.call('post', '/api/qq-promotion/push', { body: { onlyPending: true } })
    assert.equal(res.status, 200)
    assert.equal(res.data.push.total, 0)
    assert.match(res.data.push.note, /都已确认最新配置/)
    assert.equal(host.calls.length, before)
  } finally {
    dispose()
  }
})

test('POST push：全部重推会真的重发一遍（排障入口）', async () => {
  const { host, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    const before = host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length
    const res = await host.call('post', '/api/qq-promotion/push', { body: {} })
    assert.equal(res.data.push.total, 2)
    assert.equal(res.data.push.okCount, 2)
    assert.equal(host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length, before + 2)
  } finally {
    dispose()
  }
})

test('POST push：指定不存在的服务器 → 404（不静默当成 0 台）', async () => {
  const { host, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    const res = await host.call('post', '/api/qq-promotion/push', { body: { serverIds: ['nope'] } })
    assert.equal(res.status, 404)
    assert.match(res.data.error, /不存在或未启用/)
  } finally {
    dispose()
  }
})

// ═══════════════ 7. dispose ═══════════════

test('dispose：停掉对账与重试定时器（卸载后不再有后台请求）', async () => {
  const { host, gameHalf, dispose } = await boot()
  await waitAllAcked(host, 2)
  gameHalf.setBehavior('s1', 'missing')
  await host.call('post', '/api/qq-promotion/config', {
    body: { updates: { 'push.retryIntervalMs': 20, 'push.reconcileIntervalMs': 20 } },
  })
  dispose()
  const after = host.calls.length
  await new Promise((r) => setTimeout(r, 120))
  assert.equal(host.calls.length, after, 'dispose 后不应再有后台下发')
})
