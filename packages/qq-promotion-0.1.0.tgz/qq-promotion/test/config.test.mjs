/**
 * 配置模块（config.js）单元测试
 *
 * 覆盖本次任务明确要求的三块：
 *   1. 归一与**缺失回落**——重点是修掉的那处单边缺失：
 *      ignoreGroups 缺失时必须拿到保护默认值 ['owner','superadmin']（**不能是空列表**），
 *      mode 缺失时必须回落到 'auto'（与宿主归一后的语义一致）
 *   2. 保存 / 读取 / 白名单校验，以及**非法值必须被拒绝**（不写进配置）
 *   3. 下发载荷 toGamePayload 必须**永远带齐 4 个字段**（缺字段正是服端空保护名单的来源）
 *
 * 运行：node test/config.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import {
  CONFIG_SCHEMA,
  DEFAULT_IGNORE_GROUPS,
  DEFAULT_MODE,
  configWarnings,
  defaultConfig,
  dedupeGroups,
  loadConfig,
  mergeConfig,
  normalizeConfig,
  normalizeIgnoreGroups,
  normalizeMode,
  saveConfig,
  setByPath,
  toGamePayload,
} from '../config.js'

let dir

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), 'qqpromo-config-'))
})

after(async () => {
  await rm(dir, { recursive: true, force: true })
})

function cfgFile(name) {
  return path.join(dir, `${name}.json`)
}

// ═══════════════ 1. 默认值与归一 ═══════════════

test('默认配置：晋升未启用 + 保护默认值在场', () => {
  const c = defaultConfig()
  assert.equal(c.schema, CONFIG_SCHEMA)
  assert.equal(c.enabled, false, '默认必须未启用（安全方向）')
  assert.deepEqual(c.ignoreGroups, ['owner', 'superadmin'])
  assert.deepEqual(DEFAULT_IGNORE_GROUPS, ['owner', 'superadmin'])
  assert.equal(c.mode, 'auto')
  assert.equal(DEFAULT_MODE, 'auto')
})

test('ignoreGroups 缺失 / null / 非数组非字符串 → 保护默认值（绝不是空列表）', () => {
  assert.deepEqual(normalizeIgnoreGroups(undefined), ['owner', 'superadmin'])
  assert.deepEqual(normalizeIgnoreGroups(null), ['owner', 'superadmin'])
  assert.deepEqual(normalizeIgnoreGroups(123), ['owner', 'superadmin'], '数字等非法类型也要回落')
  assert.deepEqual(normalizeIgnoreGroups({}), ['owner', 'superadmin'])
  assert.deepEqual(normalizeIgnoreGroups(''), ['owner', 'superadmin'])
  assert.deepEqual(normalizeIgnoreGroups('   '), ['owner', 'superadmin'])
  assert.deepEqual(normalizeIgnoreGroups(',,,'), ['owner', 'superadmin'], '拆分后为空同样回落')

  // 这是本件修掉的缺陷的**直接断言**：整份配置里缺字段时，归一的产物必须带保护名单
  const c = normalizeConfig({ enabled: true, targetGroup: 'vip' })
  assert.deepEqual(c.ignoreGroups, ['owner', 'superadmin'], '配置缺 ignoreGroups 时必须回落保护默认值')
  assert.notEqual(c.ignoreGroups.length, 0, '空保护名单 = 管理员可能被降级，绝不允许')
})

test('ignoreGroups 给了就用给的：数组去空去重（大小写不敏感），字符串按分隔符拆', () => {
  assert.deepEqual(normalizeIgnoreGroups(['admin', 'ADMIN', ' vip ']), ['admin', 'vip'])
  assert.deepEqual(normalizeIgnoreGroups([]), [], '显式空数组是管理员的选择，予以保留（但会有警告）')
  assert.deepEqual(normalizeIgnoreGroups('owner, superadmin'), ['owner', 'superadmin'])
  assert.deepEqual(normalizeIgnoreGroups('owner\nsuperadmin；vip'), ['owner', 'superadmin', 'vip'])
  assert.equal(dedupeGroups(['a', 'A', '']).length, 1)
  assert.equal(dedupeGroups('not-an-array'), null)
})

test('mode 归一：只有 auto 有特殊语义，缺失回落 auto，其它一律 force', () => {
  assert.equal(normalizeMode(undefined), 'auto')
  assert.equal(normalizeMode(null), 'auto')
  assert.equal(normalizeMode(''), 'auto')
  assert.equal(normalizeMode('  '), 'auto')
  assert.equal(normalizeMode('auto'), 'auto')
  assert.equal(normalizeMode('AUTO'), 'auto', '比较用序数忽略大小写')
  assert.equal(normalizeMode('AuTo'), 'auto')
  assert.equal(normalizeMode('force'), 'force')
  assert.equal(normalizeMode('whatever'), 'force', '其它任何值一律按 force')
  assert.equal(normalizeMode(0), 'force', '非字符串也要有确定结果，不能变成空')

  const c = normalizeConfig({ enabled: true })
  assert.equal(c.mode, 'auto', '配置缺 mode 时必须回落 auto')
})

test('targetGroup 归一：缺失用默认组，显式空串保留（由警告提示）', () => {
  assert.equal(normalizeConfig({}).targetGroup, 'vip')
  assert.equal(normalizeConfig({ targetGroup: '  vip  ' }).targetGroup, 'vip')
  assert.equal(normalizeConfig({ targetGroup: '' }).targetGroup, '')
})

test('push 节奏归一：非法值回落默认，retryMax 不小于 retry', () => {
  const c = normalizeConfig({ push: { reconcileIntervalMs: -5, retryIntervalMs: 'abc', retryMaxIntervalMs: 1 } })
  assert.equal(c.push.reconcileIntervalMs, 600000)
  assert.equal(c.push.retryIntervalMs, 60000)
  assert.equal(c.push.retryMaxIntervalMs, 60000, 'retryMax 不得小于 retry（否则退避失效）')
  assert.equal(c.push.pushOnChange, true)
  const c2 = normalizeConfig({ push: { pushOnServerConnect: false } })
  assert.equal(c2.push.pushOnServerConnect, false)
})

test('生效性警告：启用但目标组为空 → error；忽略组为空 → warn', () => {
  const a = configWarnings({ enabled: true, targetGroup: '' })
  assert.equal(a.some((w) => w.level === 'error'), true)
  const b = configWarnings({ enabled: true, targetGroup: 'vip', ignoreGroups: [] })
  assert.equal(b.some((w) => w.level === 'warn'), true, '空保护名单必须被提示')
  const c = configWarnings({ enabled: false, targetGroup: '', ignoreGroups: [] })
  assert.equal(c.some((w) => w.level === 'error'), false, '未启用时空目标组不是错误')
})

// ═══════════════ 2. 下发载荷必带齐字段 ═══════════════

test('toGamePayload：永远带齐 4 个字段（缺字段曾导致服端空保护名单）', () => {
  const p = toGamePayload({}, 7)
  assert.equal(p.version, 7)
  assert.equal(p.enabled, false)
  assert.equal(p.mode, 'auto')
  assert.equal(p.targetGroup, 'vip')
  assert.ok(Object.prototype.hasOwnProperty.call(p, 'ignoreGroups'), 'ignoreGroups 字段必须存在')
  assert.deepEqual(p.ignoreGroups, ['owner', 'superadmin'])

  // 就算传进来一个"残缺"的配置对象，也不能发出缺字段的载荷
  const p2 = toGamePayload({ enabled: true, targetGroup: 'vip', ignoreGroups: undefined }, 1)
  assert.ok(Object.prototype.hasOwnProperty.call(p2, 'ignoreGroups'))
  assert.deepEqual(p2.ignoreGroups, ['owner', 'superadmin'])
  assert.equal(p2.version, 1)

  // version 非法时兜到 1（服端要求正整数）
  assert.equal(toGamePayload({}, 0).version, 1)
  assert.equal(toGamePayload({}, -3).version, 1)
  assert.equal(toGamePayload({}, 'x').version, 1)
})

// ═══════════════ 3. 白名单写入与非法值拒绝 ═══════════════

test('setByPath：白名单内的合法值写入成功', () => {
  const cfg = defaultConfig()
  setByPath(cfg, 'enabled', true)
  setByPath(cfg, 'targetGroup', 'vip2')
  setByPath(cfg, 'mode', 'force')
  setByPath(cfg, 'ignoreGroups', ['owner'])
  setByPath(cfg, 'push.retryIntervalMs', 1000)
  assert.equal(cfg.enabled, true)
  assert.equal(cfg.targetGroup, 'vip2')
  assert.equal(cfg.mode, 'force')
  assert.deepEqual(cfg.ignoreGroups, ['owner'])
  assert.equal(cfg.push.retryIntervalMs, 1000)
})

test('setByPath：非法值与越界路径一律 400 拒绝（不写进配置）', () => {
  const cases = [
    ['unknown.key', 1],
    ['schema', 2],
    ['enabled', 'yes'],
    ['enabled', 1],
    ['targetGroup', ''],
    ['targetGroup', '   '],
    ['targetGroup', 5],
    ['mode', 'fast'],
    ['mode', ''],
    ['ignoreGroups', 'owner'],
    ['ignoreGroups', ['owner', 3]],
    ['push.reconcileIntervalMs', -1],
    ['push.reconcileIntervalMs', 'abc'],
    ['push.pushOnChange', 'true'],
    ['', true],
  ]
  for (const [key, value] of cases) {
    const cfg = defaultConfig()
    assert.throws(
      () => setByPath(cfg, key, value),
      (err) => err.status === 400,
      `应拒绝 ${JSON.stringify(key)} = ${JSON.stringify(value)}`,
    )
  }
  // 被拒绝时配置必须保持原样
  const cfg = defaultConfig()
  assert.throws(() => setByPath(cfg, 'mode', 'fast'))
  assert.equal(cfg.mode, 'auto')
})

// ═══════════════ 4. 落盘 / 读取 ═══════════════

test('保存 → 读取：字段往返一致，且写入的是归一后的形状', async () => {
  const file = cfgFile('roundtrip')
  await saveConfig(file, { enabled: true, targetGroup: ' vip ', mode: 'AUTO', ignoreGroups: ['owner', ' OWNER ', 'superadmin'], push: {} })
  const raw = JSON.parse(await readFile(file, 'utf8'))
  assert.equal(raw.enabled, true)
  assert.equal(raw.targetGroup, 'vip')
  assert.equal(raw.mode, 'auto')
  assert.deepEqual(raw.ignoreGroups, ['owner', 'superadmin'])
  assert.equal(raw.schema, CONFIG_SCHEMA)

  const loaded = await loadConfig(file)
  assert.equal(loaded.existed, true)
  assert.equal(loaded.error, '')
  assert.equal(loaded.config.enabled, true)
  assert.deepEqual(loaded.config.ignoreGroups, ['owner', 'superadmin'])
})

test('保存会留 .bak，且再次保存不残留 .tmp', async () => {
  const file = cfgFile('backup')
  await saveConfig(file, { enabled: false })
  await saveConfig(file, { enabled: true })
  const bak = JSON.parse(await readFile(`${file}.bak`, 'utf8'))
  assert.equal(bak.enabled, false, '.bak 应是上一份配置')
  await assert.rejects(readFile(`${file}.tmp`, 'utf8'), '临时文件必须已被 rename 掉')
})

test('读取不存在的文件：按默认（未启用）且不报错', async () => {
  const r = await loadConfig(cfgFile('does-not-exist'))
  assert.equal(r.existed, false)
  assert.equal(r.error, '')
  assert.equal(r.config.enabled, false)
  assert.deepEqual(r.config.ignoreGroups, ['owner', 'superadmin'])
})

test('读取损坏的 JSON：回落默认（未启用）并带回明确错误（不抛错）', async () => {
  const file = cfgFile('broken')
  await writeFile(file, '{ this is not json', 'utf8')
  const r = await loadConfig(file)
  assert.equal(r.existed, true)
  assert.equal(r.config.enabled, false, '读不懂配置时绝不允许按启用运行')
  assert.deepEqual(r.config.ignoreGroups, ['owner', 'superadmin'])
  assert.match(r.error, /不是合法 JSON/)
})

test('读取顶层不是对象的文件：同样回落默认并带回错误', async () => {
  const file = cfgFile('array-top')
  await writeFile(file, '[1,2,3]', 'utf8')
  const r = await loadConfig(file)
  assert.equal(r.config.enabled, false)
  assert.match(r.error, /顶层不是对象/)
})

test('读取旧配置（缺 ignoreGroups / mode 字段）时保护默认值必须补上', async () => {
  const file = cfgFile('legacy-missing')
  // 模拟"老宿主写出来的、只有一半字段"的配置文件
  await writeFile(file, JSON.stringify({ schema: 1, enabled: true, targetGroup: 'vip' }), 'utf8')
  const r = await loadConfig(file)
  assert.equal(r.config.enabled, true)
  assert.equal(r.config.mode, 'auto', 'mode 缺失回落 auto')
  assert.deepEqual(r.config.ignoreGroups, ['owner', 'superadmin'], 'ignoreGroups 缺失必须回落保护默认值')
})

test('mergeConfig：对象递归合并，数组整体替换', () => {
  const merged = mergeConfig({ a: { b: 1, c: 2 }, list: [1, 2] }, { a: { b: 9 }, list: [3] })
  assert.deepEqual(merged, { a: { b: 9, c: 2 }, list: [3] })
})
