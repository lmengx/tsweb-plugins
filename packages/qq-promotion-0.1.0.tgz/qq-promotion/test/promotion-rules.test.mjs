/**
 * 晋升判定语义测试（**JS 等价镜像**，语义双保险）
 *
 * 必须先说清楚这条测试能证明什么、不能证明什么：
 *   - C# 的游戏服半（plugin/QqPromotion.cs）在本机**跑不起来**：它依赖 TShock 运行时
 *     （TShock.Groups / UserAccounts / TSocket 玩家对象），本机没有游戏服环境，
 *     这一点也写在 docs/QQ绑定基础件设计.md 里（该 DLL 从未在真实 TShock 上跑过）。
 *   - 所以这里放一份与 C# 逻辑**逐条对应**的 JS 镜像，把"判定顺序与边界情况"用可执行的
 *     断言固定下来：这是一份**语义双保险**，用来防止"改动时把顺序/大小写/成环处理弄错"，
 *     **不是**对 C# 实现的覆盖。C# 那侧本次只有编译层与字节层验证（见 dll-content.test.mjs）。
 *   - 镜像与 C# 的对应关系逐条写在下面的注释里（含文件:行号），两边同时改才不会漂移。
 *
 * 还额外断言一条"界面上说不清就会变静默失效"的行为：**只有 auto 有特殊语义**，
 * 其它任何值（含 force、含大小写混写）都按"直接改组"处理。
 *
 * 运行：node test/promotion-rules.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'

// ════════════════════════════════════════════════════════════
//  镜像实现（对应 plugins/qq-promotion/plugin/QqPromotion.cs）
// ════════════════════════════════════════════════════════════

/** 对应 QqPromotion.IsAutoMode（plugin/QqPromotion.cs:63-66）：序数忽略大小写比较 */
function isAutoMode(mode) {
  return String(mode == null ? '' : mode).toLowerCase() === 'auto'
}

/**
 * 对应 QqPromotionConfig.Settings.Mode 的 setter（plugin/QqPromotionConfig.cs）：
 * 空白/null → DefaultMode（'auto'），否则 trim。
 * 这一层必须镜像出来：C# 侧 IsAutoMode 看到的是**已经被 setter 归一过**的值，
 * 所以"mode 缺失"在服端的实际语义是 auto（跳过已达目标组者），不是 force。
 */
function normalizeModeLikeCSharp(mode) {
  return mode == null || String(mode).trim() === '' ? 'auto' : String(mode).trim()
}

/**
 * 对应 QqPromotion.IsGroupAtOrAbove（plugin/QqPromotion.cs 同名方法）：
 * 沿父组链向上找目标组；visited 防配置错误造成成环时死循环。
 * 注意成环的语义：成环且链上没有目标组 → 返回 false（不是"到达"），于是 auto 模式会改组。
 */
function isGroupAtOrAbove(group, targetGroupName) {
  const visited = new Set()
  let current = group
  while (current) {
    const name = String(current.name).toLowerCase()
    if (visited.has(name)) break
    visited.add(name)
    if (name === String(targetGroupName).toLowerCase()) return true
    current = current.parent || null
  }
  return false
}

/**
 * 对应 QqPromotion.TryPromoteOnLogin + TryPromote 的完整判定顺序
 * （plugin/QqPromotion.cs 的两个方法，与旧实现 plugins/qq-bind/plugin/QqPromotion.cs:64-132 一致）。
 *
 * @param {object} input
 *   player        登录中的玩家（null 表示没有玩家对象）
 *   bound         账号是否在绑定快照里（QqPromotionBindings.IsBound）
 *   config        晋升配置 { enabled, targetGroup, mode, ignoreGroups }
 *   groups        组表：{ 组名: { name, parent } }（parent 为组对象或 null）
 * @returns {{ action:'skip'|'promote', step:string, target?:string, warned?:boolean }}
 */
function decide({ player, bound, config, groups }) {
  // 1. 玩家非空、已登录、有 Account（QqPromotion.cs:66）
  if (!player || !player.isLoggedIn || !player.account) return { action: 'skip', step: 'no-login' }

  // 2. 该账号在绑定快照里存在（QqPromotion.cs:71）
  if (!bound) return { action: 'skip', step: 'not-bound' }

  // 3. 配置 enabled（QqPromotion.cs:74）
  if (config.enabled !== true) return { action: 'skip', step: 'disabled' }

  // 3.5 目标组名为空（C# 侧 TryPromote 第一行的 string.IsNullOrEmpty 检查 + 本件新增的告警）
  if (!config.targetGroup || String(config.targetGroup).trim() === '') {
    return { action: 'skip', step: 'empty-target-group', warned: true }
  }

  // 4. 目标组存在（QqPromotion.cs:94-98）
  if (!groups[String(config.targetGroup).toLowerCase()]) {
    return { action: 'skip', step: 'target-group-missing', warned: true }
  }

  // 5. 当前组命中 ignoreGroups（序数忽略大小写）→ 静默跳过（QqPromotion.cs:100-110）
  const currentGroup = groups[String(player.account.group || '').toLowerCase()] || null
  if (currentGroup) {
    const ignore = Array.isArray(config.ignoreGroups) ? config.ignoreGroups : []
    for (const g of ignore) {
      if (String(currentGroup.name).toLowerCase() === String(g).toLowerCase()) {
        return { action: 'skip', step: 'ignored' } // 静默：不产生警告
      }
    }
  }

  // 6. auto 模式且已达目标组 → 跳过（QqPromotion.cs:112-115）
  //    注意先过 config 层的 mode 归一（缺失 → auto），与 C# 侧 Settings setter 的行为一致
  if (isAutoMode(normalizeModeLikeCSharp(config.mode)) && currentGroup && isGroupAtOrAbove(currentGroup, config.targetGroup)) {
    return { action: 'skip', step: 'already-at-or-above' }
  }

  // 7. 改组（QqPromotion.cs:117-125）
  return { action: 'promote', step: 'promoted', target: config.targetGroup }
}

// ════════════════════════════════════════════════════════════
//  测试夹具
// ════════════════════════════════════════════════════════════

/** 组表：default → guest → vip → admin（父链自下而上）；owner 无父；loop-a ↔ loop-b 成环 */
function makeGroups() {
  const guest = { name: 'guest', parent: null }
  const vip = { name: 'vip', parent: guest }
  const admin = { name: 'admin', parent: vip }
  const owner = { name: 'owner', parent: null }
  const loopA = { name: 'loop-a', parent: null }
  const loopB = { name: 'loop-b', parent: loopA }
  loopA.parent = loopB // 父链成环
  const out = {}
  for (const g of [guest, vip, admin, owner, loopA, loopB]) out[g.name.toLowerCase()] = g
  return out
}

const BASE_CONFIG = {
  enabled: true,
  targetGroup: 'vip',
  mode: 'auto',
  ignoreGroups: ['owner', 'superadmin'],
}

function loginPlayer(group) {
  return { isLoggedIn: true, account: { name: 'Steve', group } }
}

// ════════════════════════════════════════════════════════════
//  判定顺序
// ════════════════════════════════════════════════════════════

test('判定顺序 1-2：未登录/无账号先于一切；未绑定玩家即便启用 + force 也不被动组', () => {
  const groups = makeGroups()
  assert.equal(decide({ player: null, bound: true, config: BASE_CONFIG, groups }).step, 'no-login')
  assert.equal(
    decide({ player: { isLoggedIn: false, account: { group: 'vip' } }, bound: true, config: BASE_CONFIG, groups }).step,
    'no-login',
  )
  assert.equal(
    decide({ player: { isLoggedIn: true, account: null }, bound: true, config: BASE_CONFIG, groups }).step,
    'no-login',
  )

  // 未绑定：即使启用、即使 force、即使在目标组下方，也必须跳过（未绑定玩家不受影响）
  const force = { ...BASE_CONFIG, mode: 'force' }
  assert.equal(decide({ player: loginPlayer('guest'), bound: false, config: force, groups }).step, 'not-bound')
})

test('判定顺序 3：未启用时连绑定都不看之外的判断都不做', () => {
  const groups = makeGroups()
  const cfg = { ...BASE_CONFIG, enabled: false }
  assert.deepEqual(decide({ player: loginPlayer('guest'), bound: true, config: cfg, groups }), {
    action: 'skip', step: 'disabled',
  })
})

test('判定顺序 4：目标组不存在 → 跳过并告警（不能因为改组失败就崩）', () => {
  const groups = makeGroups()
  const cfg = { ...BASE_CONFIG, targetGroup: 'not-exist' }
  const r = decide({ player: loginPlayer('guest'), bound: true, config: cfg, groups })
  assert.equal(r.action, 'skip')
  assert.equal(r.step, 'target-group-missing')
  assert.equal(r.warned, true)
})

test('判定顺序 4.5：目标组为空 → 跳过（本件把它从"彻底静默"改成"告警的跳过"）', () => {
  const groups = makeGroups()
  for (const targetGroup of ['', '   ', null, undefined]) {
    const r = decide({ player: loginPlayer('guest'), bound: true, config: { ...BASE_CONFIG, targetGroup }, groups })
    assert.equal(r.action, 'skip', `targetGroup=${JSON.stringify(targetGroup)} 不应晋升`)
    assert.equal(r.step, 'empty-target-group')
    assert.equal(r.warned, true, '必须有告警（不然就是静默不生效）')
  }
})

test('判定顺序 5：命中忽略组 → 静默跳过，force 模式也保护（管理员不被降级）', () => {
  const groups = makeGroups()
  for (const mode of ['auto', 'force', 'whatever']) {
    const r = decide({ player: loginPlayer('owner'), bound: true, config: { ...BASE_CONFIG, mode }, groups })
    assert.equal(r.action, 'skip', `mode=${mode} 时 owner 组必须被保护`)
    assert.equal(r.step, 'ignored')
    assert.notEqual(r.warned, true, '命中忽略组是静默跳过（不产生告警）')
  }
  // 大小写不敏感：配置里写 Owner/SUPERADMIN 也要命中
  const cfg = { ...BASE_CONFIG, ignoreGroups: ['Owner', 'SUPERADMIN'] }
  assert.equal(decide({ player: loginPlayer('owner'), bound: true, config: cfg, groups }).step, 'ignored')
  // 当前组名大小写不同（TShock 里可能是 Owner）也要命中
  assert.equal(decide({ player: loginPlayer('OWNER'), bound: true, config: BASE_CONFIG, groups }).step, 'ignored')
})

test('判定顺序 6：auto 模式沿父组链判断，已达目标组（或其上级）则跳过', () => {
  const groups = makeGroups()
  // 当前就是目标组
  assert.equal(decide({ player: loginPlayer('vip'), bound: true, config: BASE_CONFIG, groups }).step, 'already-at-or-above')
  // 当前在目标组上方（admin 的父链：admin → vip → guest）
  assert.equal(decide({ player: loginPlayer('admin'), bound: true, config: BASE_CONFIG, groups }).step, 'already-at-or-above')
  // 父链上没有目标组 → 需要晋升
  assert.equal(decide({ player: loginPlayer('guest'), bound: true, config: BASE_CONFIG, groups }).action, 'promote')
})

test('判定顺序 6 边界：父链成环不死循环，且"成环但没到目标组"要按需改组', () => {
  const groups = makeGroups()
  const cfg = { ...BASE_CONFIG, targetGroup: 'vip' }
  const r = decide({ player: loginPlayer('loop-a'), bound: true, config: cfg, groups })
  assert.equal(r.action, 'promote', '成环且链上无目标组 → 不视为"已达目标组"，应改组')
  // 目标组就在环上时（自身即目标组的判定）也要能正确返回
  assert.equal(isGroupAtOrAbove(groups['loop-a'], 'loop-b'), true)
  assert.equal(isGroupAtOrAbove(groups['loop-a'], 'guest'), false)
})

test('只有 auto 有特殊语义：其它任何值（含大小写混写）都直接改组', () => {
  const groups = makeGroups()
  assert.equal(isAutoMode('auto'), true)
  assert.equal(isAutoMode('AUTO'), true, '序数忽略大小写')
  assert.equal(isAutoMode('Auto'), true)
  assert.equal(isAutoMode('force'), false)
  assert.equal(isAutoMode(''), false)
  assert.equal(isAutoMode(null), false)

  // config 层归一：缺失/空白 → auto（对应 C# Settings.Mode 的 setter）
  assert.equal(normalizeModeLikeCSharp(null), 'auto')
  assert.equal(normalizeModeLikeCSharp('   '), 'auto')
  assert.equal(normalizeModeLikeCSharp(' force '), 'force')

  // vip 是目标组本身：auto 跳过，force 与其它值都改组
  const atTarget = () => decide({ player: loginPlayer('vip'), bound: true, config: { ...BASE_CONFIG, mode: 'force' }, groups })
  assert.equal(atTarget().action, 'promote')
  assert.equal(decide({ player: loginPlayer('vip'), bound: true, config: { ...BASE_CONFIG, mode: 'whatever' }, groups }).action, 'promote')
  assert.equal(decide({ player: loginPlayer('vip'), bound: true, config: { ...BASE_CONFIG, mode: 'AUTO' }, groups }).action, 'skip')
  assert.equal(
    decide({ player: loginPlayer('vip'), bound: true, config: { ...BASE_CONFIG, mode: null }, groups }).action,
    'skip',
    'mode 缺失时 C# 侧 setter 会归一成 auto，因此"已达目标组"必须跳过',
  )
})

test('当前组解析不到时（TShock.Groups.GetGroupByName 返回 null）忽略组检查被跳过 —— 与 C# 一致', () => {
  const groups = makeGroups()
  // 玩家所在组名不在组表里 → currentGroup = null
  const r = decide({ player: loginPlayer('ghost-group'), bound: true, config: BASE_CONFIG, groups })
  assert.equal(r.action, 'promote', '与旧实现一致：解析不到当前组时不看忽略名单，仍按 auto 判断')
  // auto 模式下 currentGroup 为 null 也不会被判成"已达目标组"
  assert.equal(r.step, 'promoted')
})

test('保护默认值：缺失 ignoreGroups 时由**宿主侧**归一补上 owner/superadmin（镜像里显式验证）', () => {
  const groups = makeGroups()
  // 模拟"配置载荷缺 ignoreGroups 字段"——本件在宿主归一与服端 Settings 初值两处都会补默认值，
  // 所以走到这里的 config.ignoreGroups 一定是保护名单（JS 镜像这里显式给它，验证判定行为）
  const cfg = { enabled: true, targetGroup: 'vip', mode: 'auto', ignoreGroups: ['owner', 'superadmin'] }
  assert.equal(decide({ player: loginPlayer('owner'), bound: true, config: cfg, groups }).step, 'ignored')
  // 反例对照：如果保护名单是空的（旧实现的缺陷形态），owner 就会被 auto 逻辑改组
  const empty = { ...cfg, ignoreGroups: [] }
  assert.equal(decide({ player: loginPlayer('owner'), bound: true, config: empty, groups }).action, 'promote',
    '空保护名单下 owner 会被改组 —— 这正是必须修掉"缺字段回落到空名单"的原因')
})
