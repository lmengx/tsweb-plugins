/**
 * DLL 内容断言（防"DLL 里其实没有这段代码"）
 *
 * 为什么必须有这条测试：
 *   本仓实测发生过这种缺陷——plugins/qq-bind/plugin/QqBind.dll（27136 B，09-29）的**二进制里
 *   根本没有** QqPromotion / TryPromoteOnLogin / IsGroupAtOrAbove，而同目录 obj/Release/QqBind.dll
 *   （32768 B，10-01）里是有的。也就是说"会被打包下发的 DLL 里没有晋升代码"，而构建、打包、
 *   `--check` 全程没有任何报错。根因是打包器从 bin/Release/<tfm>/ 回拷时用了陈旧产物
 *   （见 scripts/pack-plugin.mjs 的 pickBuildArtifact 注释）。
 *   → 于是：**编译通过 ≠ 功能在包里**。这里对**实际会被打包的那个文件**做字节层断言。
 *
 * 判据设计（阳性对照，避免"扫了个空文件也算过"）：
 *   - 阳性对照：几个与本功能无关、但必然存在的元数据字符串（基类名 / 覆写方法名 / 框架类型名）。
 *     对照只要有一个没命中，说明扫错了文件或扫描本身失效，测试直接失败（不是"缺功能"）。
 *   - 目标串：晋升功能必然编译进去的类型名、方法名、路由字面量、快照文件名、落盘文件名、
 *     以及**保护默认值的字面量**（owner / superadmin）。
 *   - 阴性对照：一个肯定不存在的串必须扫不到 —— 证明"扫得到"这件事本身是有区分度的。
 *
 * 局限（如实说明，不要当成运行时保证）：本机没有 TShock 运行环境，这条测试只能证明
 *   "这段代码在 DLL 的元数据里"，**不能**证明它在真实 TShock 上按预期晋升。
 *
 * 运行：node test/dll-content.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile, readdir, stat } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginDir = path.join(here, '..', 'plugin')
/** 发行目录里的镜像（同步过后两份必须逐字节一致） */
const mirrorPluginDir = path.resolve(here, '..', '..', '..', 'tsweb-dist-lite', 'plugins', 'qq-promotion', 'plugin')

/**
 * 阳性对照：与本功能无关但必然出现在本程序集元数据里的名字。
 * 注意 'TerrariaPlugin' 是基类名、'Initialize' 是覆写方法名、'SecureRestCommand'/'PlayerPostLogin'
 * 是框架类型名——它们的存在只说明"这确实是一个编译好的 TShock 插件程序集"。
 */
const POSITIVE_CONTROLS = ['TerrariaPlugin', 'Initialize', 'SecureRestCommand', 'PlayerPostLogin']

/** 目标串：晋升功能本体（类型名 / 方法名 / 端点 / 文件名 / 保护默认值） */
const TARGETS = [
  ['QqPromotionPlugin', '游戏服半的插件入口类型（注册路由与登录钩子的地方）'],
  ['TryPromoteOnLogin', '登录时的晋升识别方法'],
  ['TryPromote', '晋升判定与改组方法'],
  ['IsGroupAtOrAbove', '父组链判断（防成环）'],
  ['QqPromotionBindings', '只读绑定快照的读取器'],
  ['QqPromotionConfig', '配置存储（原子应用 + 落盘）'],
  ['QqPromotionEndpoints', 'REST 端点'],
  ['/data/promotion/snapshot', '配置接收端点路由字面量'],
  ['/data/promotion/status', '状态端点路由字面量'],
  ['qqbind-snapshot.json', '它只读的 qq-bind 绑定快照文件名'],
  ['qq-promotion-config.json', '它自己的配置落盘文件名'],
  ['DefaultIgnoreGroups', '保护默认值的取用点（缺失回落的实现）'],
  ['owner', '保护默认值之一（编译进 DLL 的字面量）'],
  ['superadmin', '保护默认值之一（编译进 DLL 的字面量）'],
]

/** 阴性对照：任何情况下都不该出现在本 DLL 里的串 */
const NEGATIVE_CONTROL = 'TSWEB_DLL_SCAN_NEGATIVE_CONTROL_9f3ab7c1'

async function findDll() {
  let entries = []
  try {
    entries = await readdir(pluginDir)
  } catch (err) {
    assert.fail(`读不到 plugin 目录：${pluginDir}（${err.message}）`)
  }
  const dlls = entries.filter((f) => f.toLowerCase().endsWith('.dll'))
  assert.ok(
    dlls.length > 0,
    `plugin/ 下没有任何 .dll —— 请先构建：\n`
    + `    node scripts/pack-plugin.mjs qq-promotion --check\n`
    + `  （或 dotnet build plugins/qq-promotion/plugin/QqPromotion.csproj -c Release）`,
  )
  assert.equal(dlls.length, 1, `plugin/ 下应只有本插件自己的 DLL，实际有：${dlls.join(', ')}`)
  return path.join(pluginDir, dlls[0])
}

/**
 * 在字节里找 .NET 的字符串——**必须同时扫两种编码**，否则会得出错误结论：
 *   - 类型名 / 方法名 / 字段名等元数据字符串 → #Strings 堆，**UTF-8**
 *   - 字符串字面量（如 `"qqbind-snapshot.json"`、`"owner"`）→ #US 堆，**UTF-16LE**
 * 实测教训：先用 PowerShell 的 `[Encoding]::UTF8.GetString(...).IndexOf('owner')` 扫，
 * 竟然"命中"了——因为 UTF-16LE 的 "o\0w\0n\0e\0r" 解码后含 NUL，而 .NET 的
 * `String.IndexOf(string)` 默认是**文化敏感**比较、会忽略零权字符（NUL），于是给出了假阳性。
 * 所以这里用 Node 按字节扫，并显式覆盖两种编码。
 */
function containsString(buf, s) {
  return buf.indexOf(Buffer.from(s, 'utf8')) >= 0 || buf.indexOf(Buffer.from(s, 'utf16le')) >= 0
}

test('插件 DLL 存在且体积合理（空文件/半截文件直接失败）', async () => {
  const dll = await findDll()
  const st = await stat(dll)
  assert.ok(st.size > 4096, `DLL 体积异常小（${st.size} B），疑似构建失败或占位文件：${dll}`)
  const buf = await readFile(dll)
  assert.equal(buf.subarray(0, 2).toString('latin1'), 'MZ', '不是合法的 PE 文件（应为 MZ 开头）')
})

test('阳性对照：本功能无关的元数据字符串必须命中（证明扫描有效、扫的是插件程序集）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const missing = POSITIVE_CONTROLS.filter((s) => !containsString(buf, s))
  assert.deepEqual(
    missing, [],
    `阳性对照未命中：${missing.join('、')} —— 说明扫描本身失效或扫错了文件，此时"目标串命中"没有意义`,
  )
})

test('阴性对照：不存在的串必须扫不到（证明命中是有区分度的）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  assert.equal(containsString(buf, NEGATIVE_CONTROL), false, '阴性对照居然命中了，扫描逻辑不可信')
})

test('目标串：晋升功能的类型/方法/端点/文件名/保护默认值必须都在 DLL 里', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const missing = TARGETS.filter(([s]) => !containsString(buf, s))
  assert.deepEqual(
    missing.map(([s]) => s), [],
    '升级代码没有真正进到将被打包下发的 DLL 里（这正是 qq-bind 实测踩过的缺陷：\n'
    + '  plugin/QqBind.dll 里没有 QqPromotion/TryPromoteOnLogin，而 obj/Release 里有）。\n'
    + '  缺的是：\n'
    + missing.map(([s, why]) => `    - ${s}：${why}`).join('\n')
    + '\n  修复方向：删掉 plugin/bin、plugin/obj 后重建（或加 --rebuild），并确认打包不再从陈旧 bin 回拷。',
  )
})

test('不引用 QqBind.dll：DLL 里不存在 "QqBind" 这个程序集名（只读文件，不做程序集耦合）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  // 快照文件名是 "qqbind-snapshot.json"（全小写），而程序集引用/类型名是 "QqBind"（首字母大写），
  // 两者大小写不同，所以这条断言能区分"读了 qq-bind 的文件"与"引用了 QqBind.dll"。
  // 正确的扫描必须同时看 UTF-8（#Strings 里的程序集名）与 UTF-16LE（#US 里的字面量）。
  assert.equal(
    buf.indexOf(Buffer.from('QqBind', 'utf8')) >= 0 || buf.indexOf(Buffer.from('QqBind', 'utf16le')) >= 0,
    false,
    'DLL 里出现了 "QqBind" —— 说明本插件引用了 QqBind.dll 或写了该大小写的字面量；'
    + '设计 §7.3 要求各自读快照文件以避免程序集耦合（卸载/热重载时"A 卸了 B 就崩"）。',
  )
  assert.equal(containsString(buf, 'qqbind-snapshot.json'), true, '但快照文件名必须存在（它靠这个文件识别绑定）')
})

test('发行目录镜像里的 DLL 与源码目录逐字节一致（同步后不许有第二份不同内容）', async () => {
  const dll = await findDll()
  const mirror = path.join(mirrorPluginDir, path.basename(dll))
  let mirrorBuf
  try {
    mirrorBuf = await readFile(mirror)
  } catch (err) {
    if (err.code === 'ENOENT') {
      // 镜像目录不存在（例如别人只 checkout 了源码目录）→ 跳过，不误报
      return
    }
    throw err
  }
  const src = await readFile(dll)
  const sha = (b) => createHash('sha256').update(b).digest('hex')
  assert.equal(
    sha(mirrorBuf), sha(src),
    `两份 DLL 内容不一致：\n  源码 ${dll}\n  镜像 ${mirror}\n  请重新同步（镜像必须逐字节一致）`,
  )
})
