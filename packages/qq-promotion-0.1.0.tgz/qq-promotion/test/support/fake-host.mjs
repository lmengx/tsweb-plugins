/**
 * 测试用的最小宿主（假 ctx）—— 不启动任何服务进程、不依赖 express / cordis。
 *
 * 为什么自己搓一个：本机 `node --test test/` 会因 `spawn EPERM`（沙箱不允许管道捕获子进程）
 * 而整体失败，测试必须能逐个 `node test/<名>.test.mjs` 跑；同时"不启动/重启任何服务进程"
 * 是本次任务的硬约定，所以**不引入真实 HTTP 监听**，而是直接调用插件注册在 app.get/app.post
 * 上的处理函数（与真实 express 的用法一致：插件只用到 (req,res) 两个参数）。
 *
 * 覆盖到的宿主契约（plugins/qq-promotion/index.js 依赖的全部服务）：
 *   webServer.app.get/post、auth.verifyAuth/requireAdmin、servers.list/getRaw、
 *   tshock.fetchFor（记录全部调用，供断言"下发确实发生了"）、paths.dataOf、
 *   ctx.on/ctx.emit（连接恢复补推靠它触发）、ctx.get（软依赖取服务，见 services 参数）
 */
import path from 'node:path'

export function makeFakeHost({ dataDir, servers = [], fetchFor, services = {} }) {
  const routes = { get: new Map(), post: new Map() }
  const listeners = new Map()
  const events = []
  const calls = []
  const raw = new Map(servers.map((s) => [String(s.raw.id), { ...s.raw }]))

  const app = {
    get(routePath, ...handlers) {
      routes.get.set(routePath, handlers[handlers.length - 1])
    },
    post(routePath, ...handlers) {
      routes.post.set(routePath, handlers[handlers.length - 1])
    },
  }

  const ctx = {
    webServer: { app },
    /**
     * 软依赖取服务：对齐真实 cordis 的 Context.get 语义——**未注册返回 undefined，不抛错**
     * （实测见 plugins/legacy-import/modules/registry.js:57-61 的注释）。
     * 用普通属性赋值挂上去的假服务对 get 不可见，这正是生产里"服务没注册就取不到"的形态。
     */
    get: (name) => services[name],
    // 鉴权中间件在测试里直接放行（本件只关心处理逻辑；鉴权链路由宿主插件保证）
    auth: {
      verifyAuth: () => (req, res, next) => next(),
      requireAdmin: () => (req, res, next) => next(),
    },
    paths: { dataOf: (n) => path.join(dataDir, n) },
    logger: { info() {}, warn() {}, error() {} },
    servers: {
      list: async () => [...raw.values()].map((s) => ({ ...s })),
      getRaw: (id) => (raw.has(String(id)) ? { ...raw.get(String(id)) } : null),
    },
    tshock: {
      async fetchFor(server, pathname, params) {
        calls.push({ serverId: server.id, pathname, params })
        return fetchFor(server, pathname, params)
      },
    },
    emit(name, payload) {
      events.push({ name, payload })
    },
    on(name, fn) {
      listeners.set(name, fn)
      return () => listeners.delete(name)
    },
  }

  return {
    ctx,
    /** 全部游戏服调用（含参数），供"下发确实发生/参数正确"类断言 */
    calls,
    /** 插件 emit 的事件 */
    events,
    /** 改假服务器记录（例如临时置 enabled=false） */
    setRaw(id, patch) {
      raw.set(String(id), { ...(raw.get(String(id)) || {}), ...patch })
    },
    /** 触发宿主事件（连接恢复补推靠它） */
    fire(name, payload) {
      const fn = listeners.get(name)
      if (!fn) return false
      fn(payload)
      return true
    },
    listenerCount: () => listeners.size,
    /** 直接调用插件注册的某个端点（不经网络） */
    async call(method, url, { query = {}, body = {} } = {}) {
      const u = new URL(url, 'http://localhost')
      const merged = { ...Object.fromEntries(u.searchParams.entries()), ...query }
      const handler = routes[method].get(u.pathname)
      if (!handler) throw new Error(`插件未注册该路由: ${method.toUpperCase()} ${u.pathname}`)
      let data = null
      let status = 200
      const res = {
        headersSent: false,
        status(code) {
          status = code
          return res
        },
        json(payload) {
          data = payload
          return res
        },
      }
      await handler({ query: merged, body, headers: {} }, res)
      return { status, data }
    },
    hasRoute: (method, routePath) => routes[method].has(routePath),
  }
}

/** 轮询等待条件成立（用于等异步下发/重试完成）；超时抛错，不静默通过 */
export async function waitFor(cond, { timeoutMs = 2000, intervalMs = 10, label = '条件' } = {}) {
  const started = Date.now()
  for (;;) {
    const v = await cond()
    if (v) return v
    if (Date.now() - started > timeoutMs) throw new Error(`等待超时：${label}`)
    await new Promise((r) => setTimeout(r, intervalMs))
  }
}

/**
 * 假游戏服半（QqPromotion.dll 的端点行为）。
 * 逐服可设行为：ok | missing（未装 DLL，404）| forbidden（token 权限不足，403）|
 *               stale（服端已有更新版本）| badRequest（400 参数被拒）| saveFail（落盘失败）
 */
export function makeGameHalf({ serverIds = [] } = {}) {
  const applied = new Map()
  const behavior = new Map(serverIds.map((id) => [String(id), 'ok']))
  /** 服端"已绑定账号数"，用于断言宿主能看到服端的绑定识别状态 */
  const bindings = new Map(serverIds.map((id) => [String(id), { count: 2, snapshotVersion: 3, snapshotUpdatedAt: '2026-01-01T00:00:00Z', file: 'X:/tshock/qqbind-snapshot.json', source: 'file', note: '' }]))

  return {
    applied,
    behavior,
    bindings,
    setBehavior(id, mode) {
      behavior.set(String(id), mode)
    },
    setBindings(id, patch) {
      bindings.set(String(id), { ...(bindings.get(String(id)) || {}), ...patch })
    },
    fetchFor(server, pathname, params) {
      const id = String(server.id)
      const mode = behavior.get(id) || 'ok'
      if (mode === 'missing') return { ok: false, status: 404, data: {} }
      if (mode === 'forbidden') return { ok: false, status: 403, data: {} }

      if (pathname === '/data/promotion/snapshot') {
        // 宿主必须发合法 JSON 数组字符串（这是"载荷带齐"的一部分）
        let ignoreGroups
        try {
          ignoreGroups = JSON.parse(params.ignoreGroups)
        } catch (err) {
          return { ok: false, status: 400, data: { error: `ignoreGroups 不是合法 JSON: ${err.message}` } }
        }
        if (mode === 'badRequest') return { ok: false, status: 400, data: { error: '启用晋升时 targetGroup 不能为空' } }
        if (mode === 'stale') {
          return {
            ok: true,
            status: 200,
            data: {
              ok: true, applied: false, stale: true, version: 99,
              enabled: false, targetGroup: '', mode: 'auto', ignoreGroups: [],
            },
          }
        }
        const next = {
          version: Number(params.version),
          enabled: params.enabled === 1 || params.enabled === '1',
          targetGroup: String(params.targetGroup || ''),
          mode: String(params.mode || ''),
          ignoreGroups,
        }
        applied.set(id, next)
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            applied: true,
            stale: false,
            ...next,
            saveError: mode === 'saveFail' ? '磁盘只读' : '',
            bindings: bindings.get(id),
          },
        }
      }

      if (pathname === '/data/promotion/status') {
        const a = applied.get(id) || { version: 0, enabled: false, targetGroup: '', mode: 'auto', ignoreGroups: [] }
        return {
          ok: true,
          status: 200,
          data: { ok: true, ...a, updatedAt: '2026-01-01T00:00:00Z', source: 'rest', file: 'X:/tshock/qq-promotion-config.json', saveError: '', bindings: bindings.get(id) },
        }
      }

      return { ok: false, status: 500, data: { error: `未预期的路径 ${pathname}` } }
    },
  }
}
