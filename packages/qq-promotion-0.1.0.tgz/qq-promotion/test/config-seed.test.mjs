/**
 * 旧配置迁移 seed 测试（qq-bind 的 promotion 块 → 本件 <dataDir>/qq-promotion/config.json）
 *
 * 背景：晋升原来内嵌在 qq-bind 里，摘除时**刻意保留了用户原值**（qq-bind 的 mergeConfig 原样
 * 透传未知字段），本机实测该值是
 *   { enabled: false, targetGroup: 'vip', mode: 'auto', ignoreGroups: ['owner','superadmin'] }
 * —— 注意这组值恰好与本件默认值相同，所以"到底采用没采用旧值"用它是测不出来的：
 * 本文件的正式用例都用**与默认值明显不同**的旧值，才能把"采用了"和"回落默认"区分开。
 *
 * 覆盖（对应任务要求逐条）：
 *   1. 无自己的配置 + qq-bind 有 promotion → 采用旧值（逐字段断言）+ 写审计 + 记日志
 *   2. 无自己的配置 + qq-bind 没有 promotion 块 → 用默认值、不报错、不写审计
 *   3. 无自己的配置 + qq-bind 未安装 → 用默认值、不抛错、**不写"已迁移"日志**
 *   4. 自己的配置已存在 → 不 seed、不覆盖（哪怕旧值不同）；且 seed 只发生一次（幂等）
 *   5. 旧值畸形（mode 非法 / ignoreGroups 非数组 / targetGroup 空）→ 归一后落盘，非法值不落盘
 *   6. 旧块只给了部分字段 → 只采用存在的字段，其余用本件默认值
 *   7. 回归护栏：宿主半不直接属性访问未 inject 的服务（软依赖必须走 ctx.get）
 *
 * 另外锁住两条副作用要求：
 *   - 迁移**不删除** qq-bind 配置里的旧 promotion 块（读回逐字段比对）
 *   - 迁移日志只报来源与**字段名**，不含配置内容
 *
 * 注意：本测试不启动任何服务进程（复用 test/support/fake-host.mjs 的假宿主）。
 * 运行：node test/config-seed.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, readFile, writeFile, mkdir } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

import { apply } from '../index.js'
import { defaultConfig, normalizeConfig } from '../config.js'
import { seedFromLegacyPromotion, optionalService, LEGACY_SOURCE_PLUGIN } from '../seed.js'
import { makeFakeHost } from './support/fake-host.mjs'

let dir
let seq = 0

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), 'qqpromo-seed-'))
})

after(async () => {
  await rm(dir, { recursive: true, force: true })
})

/** 本件数据目录 / 配置文件 / 审计文件；假宿主的 dataOf(n) = <dataDir>/n */
function ownConfigFile(dataDir) {
  return path.join(dataDir, 'qq-promotion', 'config.json')
}
function ownAuditFile(dataDir) {
  return path.join(dataDir, 'qq-promotion', 'audit.jsonl')
}
function legacyConfigFile(dataDir) {
  return path.join(dataDir, LEGACY_SOURCE_PLUGIN, 'config.json')
}

/** 读 JSON 文件；不存在返回 null（"文件没被写出来"本身是要断言的事实） */
async function readJsonOrNull(file) {
  try {
    return JSON.parse(await readFile(file, 'utf8'))
  } catch (err) {
    if (err.code === 'ENOENT') return null
    throw err
  }
}

/** 读审计行（不存在 → 空数组） */
async function readAudit(file) {
  try {
    const raw = await readFile(file, 'utf8')
    return raw.split('\n').filter((l) => l.trim() !== '').map((l) => JSON.parse(l))
  } catch (err) {
    if (err.code === 'ENOENT') return []
    throw err
  }
}

/**
 * 起一个宿主并 await apply。
 *   qqBind：false = 模拟"qq-bind 未安装"（ctx.get('qqBind') 取不到）；
 *           对象 = 模拟服务已注册（真实宿主里由 qq-bind 的 Service 注册）
 *   legacy：写进 qq-bind 配置文件的内容（外层对象原样写；promotion 块由调用方给出或省略）
 *   ownConfig：预置本件自己的配置文件内容（模拟"不是首次运行"）
 *
 * 捕获 apply 期间的 console 输出：本用例要断言"迁移日志写了 / 没写"，
 * 而 _seedFromLegacyQqBind 在 init 内同步 await 完成，所以 apply 返回时日志已经产出。
 */
async function boot({ legacy, qqBind = {}, ownConfig } = {}) {
  seq += 1
  const dataDir = path.join(dir, `case-${seq}`)

  if (legacy !== undefined) {
    await mkdir(path.dirname(legacyConfigFile(dataDir)), { recursive: true })
    await writeFile(legacyConfigFile(dataDir), JSON.stringify(legacy, null, 2), 'utf8')
  }
  if (ownConfig !== undefined) {
    await mkdir(path.dirname(ownConfigFile(dataDir)), { recursive: true })
    await writeFile(ownConfigFile(dataDir), JSON.stringify(ownConfig, null, 2), 'utf8')
  }

  const services = qqBind === false ? {} : { qqBind: qqBind === true ? {} : qqBind }
  // 没有启用中的服务器：本用例只关心 seed，不关心下发（去掉异步下发的噪声）
  const host = makeFakeHost({
    dataDir,
    servers: [],
    services,
    fetchFor: async () => ({ ok: false, status: 404, data: {} }),
  })

  const logs = []
  const origLog = console.log
  const origError = console.error
  console.log = (...a) => logs.push(a.join(' '))
  console.error = (...a) => logs.push('[stderr] ' + a.join(' '))
  let dispose
  try {
    dispose = await apply(host.ctx)
  } finally {
    console.log = origLog
    console.error = origError
  }

  return {
    dataDir,
    host,
    logs,
    dispose,
    /** 日志里是否出现了"已迁移"（写给别人的断言用，避免各处重写正则） */
    hasSeedLog: () => logs.some((l) => /已从 qq-bind 旧配置迁移晋升设置/.test(l)),
    ownConfig: () => readJsonOrNull(ownConfigFile(dataDir)),
    audit: () => readAudit(ownAuditFile(dataDir)),
  }
}

/** 与默认值明显不同的旧值（测"确实采用了旧值"） */
const LEGACY_DISTINCT = {
  enabled: true,
  targetGroup: 'legacygroup',
  mode: 'force',
  ignoreGroups: ['Helper', 'helper', ' Admin '],
}

// ═══════════════ 1. 采用旧值（逐字段）+ 审计 + 日志 ═══════════════

test('首次运行 + qq-bind 有 promotion → 逐字段采用旧值、写审计、记迁移日志', async () => {
  // 旧配置里保留 promotion 块（本件只读、不改动对方文件）
  const legacyDoc = { schema: 1, token: 'legacy-token-不动', promotion: { ...LEGACY_DISTINCT } }
  const b = await boot({ legacy: legacyDoc })
  try {
    assert.equal(b.hasSeedLog(), true, `应记一条"已从 qq-bind 旧配置迁移晋升设置"日志，实际：${b.logs.join(' | ')}`)

    const cfg = await b.ownConfig()
    assert.ok(cfg, '迁移必须把配置落到本件自己的文件里')
    // 逐字段断言（旧值都与默认值不同，能真正区分"采用"与"回落默认"）
    assert.equal(cfg.enabled, true, 'enabled 应采用旧值 true（默认为 false）')
    assert.equal(cfg.targetGroup, 'legacygroup', 'targetGroup 应采用旧值')
    assert.equal(cfg.mode, 'force', 'mode 应采用旧值 force')
    assert.deepEqual(cfg.ignoreGroups, ['Helper', 'Admin'], 'ignoreGroups 应采用旧值（去重去空白）')
    assert.equal(cfg.schema, 1, 'schema 由本件自己的归一写入')
    // push.* 旧块里没有 → 必须是本件默认值（不是"被旧值带没了"）
    assert.deepEqual(cfg.push, defaultConfig().push, '旧块没有的字段用本件默认值')

    // 审计：动作名 + 来源 + 采用了哪些键
    const rows = await b.audit()
    const seedRows = rows.filter((r) => r.action === 'qqpromotion.config.seed')
    assert.equal(seedRows.length, 1, '应写且只写一条 seed 审计')
    assert.equal(seedRows[0].source, LEGACY_SOURCE_PLUGIN)
    assert.equal(seedRows[0].actor, 'system', '宿主自发动作，actor 用 system 与人为操作区分')
    assert.deepEqual(seedRows[0].keys, ['enabled', 'targetGroup', 'mode', 'ignoreGroups'])
    assert.deepEqual(seedRows[0].skipped, [])
    assert.match(seedRows[0].sourceFile, /qq-bind[\\/]config\.json$/, '审计要能指出旧配置在哪')

    // 迁移日志只报来源与字段名，不泄露配置内容
    const seedLine = b.logs.find((l) => /已从 qq-bind 旧配置迁移晋升设置/.test(l))
    assert.match(seedLine, /采用 enabled\/targetGroup\/mode\/ignoreGroups/)
    for (const secret of ['legacygroup', 'legacy-token-不动', 'Helper']) {
      assert.equal(seedLine.includes(secret), false, `迁移日志不应出现配置内容（${secret}）`)
    }

    // 旧文件原样保留：**不删除** promotion 块（回退/排查取材）
    const legacyAfter = await readJsonOrNull(legacyConfigFile(b.dataDir))
    assert.deepEqual(legacyAfter, legacyDoc, '本件不得改动 qq-bind 的配置文件')
  } finally {
    b.dispose()
  }
})

// ═══════════════ 2. 旧配置没有 promotion 块 ═══════════════

test('首次运行 + qq-bind 已装但没有 promotion 块 → 用本件默认值、不报错、不写 seed 审计', async () => {
  const b = await boot({ legacy: { schema: 1, token: 'only-token' } })
  try {
    assert.equal(b.hasSeedLog(), false, `没有旧值可迁移时不应记"已迁移"日志：${b.logs.join(' | ')}`)
    assert.equal(await b.ownConfig(), null, '没迁移成功就不该凭空写出配置文件')
    assert.deepEqual(await b.audit(), [], '没有迁移就不该有 seed 审计')

    // 生效配置必须是本件默认值（经端点回显，证明插件正常加载且没有半套配置）
    const res = await b.host.call('get', '/api/qq-promotion/config')
    assert.equal(res.status, 200)
    assert.deepEqual(res.data.config, normalizeConfig(defaultConfig()))
    assert.equal(b.logs.some((l) => l.startsWith('[stderr]')), false, `不该有错误输出：${b.logs.join(' | ')}`)
  } finally {
    b.dispose()
  }
})

// ═══════════════ 3. qq-bind 未安装 ═══════════════

test('首次运行 + qq-bind 未安装 → 用默认值、不抛错、不写"已迁移"日志', async () => {
  // 刻意连 qq-bind 的数据目录都不建：模拟"这台机器上从来没有 qq-bind"
  const b = await boot({ qqBind: false })
  try {
    assert.equal(b.hasSeedLog(), false, `qq-bind 未安装时绝不能记"已迁移"日志：${b.logs.join(' | ')}`)
    assert.equal(await b.ownConfig(), null, 'qq-bind 未安装时不该写本件配置文件')
    assert.deepEqual(await b.audit(), [], 'qq-bind 未安装时不该写 seed 审计')

    const res = await b.host.call('get', '/api/qq-promotion/config')
    assert.equal(res.status, 200, '插件必须照常可用（软依赖失败只降级，不影响加载）')
    assert.deepEqual(res.data.config, normalizeConfig(defaultConfig()), '必须回落到本件默认配置')
    assert.equal(b.logs.some((l) => l.startsWith('[stderr]')), false, `不该有错误输出：${b.logs.join(' | ')}`)
  } finally {
    b.dispose()
  }
})

// ═══════════════ 4. 幂等：已存在绝不覆盖 ═══════════════

test('本件配置已存在 → 不 seed、不覆盖（哪怕旧值不同）；第二轮启动也不再 seed', async () => {
  // 4a. 预置"用户已经在本件里改过"的配置：与旧值完全不同
  const mine = { ...defaultConfig(), enabled: false, targetGroup: 'mine', mode: 'auto', ignoreGroups: ['owner'] }
  const b1 = await boot({ legacy: { promotion: { ...LEGACY_DISTINCT } }, ownConfig: mine })
  try {
    assert.equal(b1.hasSeedLog(), false, '配置文件已存在时绝不能 seed')
    const cfg = await b1.ownConfig()
    assert.equal(cfg.targetGroup, 'mine', '已存在的配置绝不能被旧值覆盖')
    assert.equal(cfg.enabled, false, '已存在的配置绝不能被旧值覆盖')
    assert.deepEqual(cfg.ignoreGroups, ['owner'])
    assert.deepEqual(await b1.audit(), [], '没 seed 就不该有 seed 审计')
  } finally {
    b1.dispose()
  }

  // 4b. 真实幂等路径：第一轮 seed 落盘后，第二轮（旧值改成别的）必须不再迁移
  const b2 = await boot({ legacy: { promotion: { enabled: true, targetGroup: 'first', mode: 'force', ignoreGroups: ['a'] } } })
  let dataDir2
  try {
    assert.equal(b2.hasSeedLog(), true, '第一轮应发生迁移')
    dataDir2 = b2.dataDir
    assert.equal((await b2.ownConfig()).targetGroup, 'first')
  } finally {
    b2.dispose()
  }

  // 同一 dataDir 再来一次，旧文件换成明显不同的值
  seq += 1
  const legacyChanged = { promotion: { enabled: false, targetGroup: 'second', mode: 'auto', ignoreGroups: ['b'] } }
  await writeFile(legacyConfigFile(dataDir2), JSON.stringify(legacyChanged, null, 2), 'utf8')
  const host2 = makeFakeHost({ dataDir: dataDir2, servers: [], services: { qqBind: {} }, fetchFor: async () => ({ ok: false, status: 404, data: {} }) })
  const logs2 = []
  const origLog2 = console.log
  console.log = (...a) => logs2.push(a.join(' '))
  let dispose2
  try {
    dispose2 = await apply(host2.ctx)
  } finally {
    console.log = origLog2
  }
  try {
    assert.equal(logs2.some((l) => /已从 qq-bind 旧配置迁移晋升设置/.test(l)), false, 'seed 只能发生一次')
    const cfg2 = JSON.parse(await readFile(ownConfigFile(dataDir2), 'utf8'))
    assert.equal(cfg2.targetGroup, 'first', '第二轮不得用新旧值覆盖已落盘的配置')
    assert.equal(cfg2.enabled, true)
    const rows = await readAudit(ownAuditFile(dataDir2))
    assert.equal(rows.filter((r) => r.action === 'qqpromotion.config.seed').length, 1, 'seed 审计也只有一条')
  } finally {
    dispose2()
  }
})

// ═══════════════ 5. 旧值畸形 → 归一后落盘 ═══════════════

test('旧值畸形（mode 非法 / ignoreGroups 非数组 / targetGroup 空）→ 归一后落盘，非法值不落盘', async () => {
  const b = await boot({
    legacy: { promotion: { enabled: true, targetGroup: '   ', mode: 'manual', ignoreGroups: 5 } },
  })
  try {
    const cfg = await b.ownConfig()
    assert.ok(cfg, '有可用字段就应迁移')
    assert.equal(cfg.enabled, true, 'enabled 是合法布尔值 → 采用')
    assert.equal(cfg.mode, 'force', 'mode 非 auto（manual）必须归一到 force，不能原样写进去')
    assert.deepEqual(cfg.ignoreGroups, ['owner', 'superadmin'], 'ignoreGroups 非数组 → 回落保护默认值')
    assert.notEqual(cfg.ignoreGroups, 5, '非法值不得落盘')
    assert.equal(cfg.targetGroup, 'vip', 'targetGroup 为空 → 回落本件默认组（空组会让"已启用"永不生效）')
    assert.notEqual(cfg.targetGroup.trim(), '', '不得写入空目标组')

    // 落盘产物必须是本件归一的**不动点**：再归一一次结果不变 = 没有未校验的旧值混进去
    assert.deepEqual(normalizeConfig(cfg), cfg, '落盘内容必须已过本件归一')

    const rows = (await b.audit()).filter((r) => r.action === 'qqpromotion.config.seed')
    assert.equal(rows.length, 1)
    assert.deepEqual(rows[0].keys, ['enabled', 'mode', 'ignoreGroups'], '被采用的字段如实记录')
    assert.deepEqual(rows[0].skipped, ['targetGroup'], '回落默认值的字段也要如实记录')
  } finally {
    b.dispose()
  }
})

test('旧块只给部分字段 → 只采用存在的字段，其余用本件默认值', async () => {
  const b = await boot({ legacy: { promotion: { enabled: true } } })
  try {
    const cfg = await b.ownConfig()
    assert.equal(cfg.enabled, true, '唯一给出的字段被采用')
    assert.equal(cfg.targetGroup, defaultConfig().targetGroup)
    assert.equal(cfg.mode, defaultConfig().mode)
    assert.deepEqual(cfg.ignoreGroups, defaultConfig().ignoreGroups, '缺失的 ignoreGroups 必须是保护默认值，不是空列表')
    const rows = (await b.audit()).filter((r) => r.action === 'qqpromotion.config.seed')
    assert.deepEqual(rows[0].keys, ['enabled'])
  } finally {
    b.dispose()
  }
})

// ═══════════════ 6. 纯函数口径（不落盘，逐条锁死归一规则） ═══════════════

test('seedFromLegacyPromotion：归一规则逐条锁死（含"非 auto 一律 force"与空值回落）', () => {
  const base = defaultConfig()

  // 非 auto 一律 force（大小写不敏感只有 auto 特殊）
  assert.equal(seedFromLegacyPromotion({ mode: 'manual' }, base).config.mode, 'force')
  assert.equal(seedFromLegacyPromotion({ mode: 'AUTO' }, base).config.mode, 'auto', 'auto 判定忽略大小写')
  assert.equal(seedFromLegacyPromotion({ mode: '' }, base).config.mode, 'auto', '空白 → 本件默认 auto')
  assert.equal(seedFromLegacyPromotion({ mode: 7 }, base).config.mode, 'force', '非字符串的非空值也归一到 force')

  // ignoreGroups：数组去重；字符串按分隔符拆；其它类型回落保护默认值
  assert.deepEqual(seedFromLegacyPromotion({ ignoreGroups: ['A', 'a', ' b '] }, base).config.ignoreGroups, ['A', 'b'])
  assert.deepEqual(seedFromLegacyPromotion({ ignoreGroups: 'owner, superadmin' }, base).config.ignoreGroups, ['owner', 'superadmin'])
  assert.deepEqual(seedFromLegacyPromotion({ ignoreGroups: 5 }, base).config.ignoreGroups, ['owner', 'superadmin'])
  assert.deepEqual(seedFromLegacyPromotion({ ignoreGroups: {} }, base).config.ignoreGroups, ['owner', 'superadmin'])
  assert.deepEqual(seedFromLegacyPromotion({ ignoreGroups: [] }, base).config.ignoreGroups, [], '显式空数组是"不保护任何组"的选择，予以保留（configWarnings 会提示）')

  // enabled 非布尔 → 不可用，保持默认 false（安全方向）
  const notBool = seedFromLegacyPromotion({ enabled: 'true' }, base)
  assert.equal(notBool.config.enabled, false, '字符串 true 不是布尔值，不得当成启用')
  assert.deepEqual(notBool.skipped, ['enabled'])

  // 纯函数不该改到 base（默认配置对象被复用）
  assert.deepEqual(base, defaultConfig())

  // 不是对象 / 空对象：什么都不采用
  for (const bad of [null, undefined, 'x', 42, []]) {
    const r = seedFromLegacyPromotion(bad, base)
    assert.deepEqual(r.adopted, [])
    assert.deepEqual(r.config, normalizeConfig(base))
  }
})

// ═══════════════ 7. 软依赖取法护栏 ═══════════════

test('optionalService：ctx.get 优先、未 inject 时直接属性访问抛错也只当"没有"', () => {
  assert.equal(optionalService({ get: () => ({ ok: 1 }) }, 'qqBind').ok, 1, 'ctx.get 命中时用它')
  assert.equal(optionalService({ get: () => undefined }, 'qqBind'), null, 'get 返回 undefined → 没有该服务')
  assert.equal(optionalService({ get: () => undefined, qqBind: { via: 'prop' } }, 'qqBind').via, 'prop', 'get 看不到普通赋值时回落到 ctx[name]')
  // 模拟未 inject 的 ctx 代理：属性访问本身抛错
  const throwing = { get: () => undefined }
  Object.defineProperty(throwing, 'qqBind', { get() { throw new Error('cannot get property "qqBind" without inject') } })
  assert.equal(optionalService(throwing, 'qqBind'), null, '属性访问抛错必须被吞掉，绝不冒泡成插件加载失败')
  assert.equal(optionalService(null, 'qqBind'), null, 'ctx 为空也不抛')
  assert.equal(optionalService({}, 'qqBind'), null, '没有 ctx.get 也不抛')
})

test('宿主半不直接属性访问未 inject 的服务（软依赖必须走 ctx.get）', async () => {
  const here = path.dirname(fileURLToPath(import.meta.url))
  for (const rel of ['../index.js', '../seed.js']) {
    const src = await readFile(path.resolve(here, rel), 'utf8')
    const lines = src.split(/\r?\n/)
    const hits = []
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]
      // 只查代码部分（朴素去注释：够用且不会漏报本用例关心的形态）
      const trimmed = line.trim()
      if (trimmed.startsWith('//') || trimmed.startsWith('*') || trimmed.startsWith('/*')) continue
      const code = line.includes('//') ? line.slice(0, line.indexOf('//')) : line
      if (/(?:this\.)?ctx\.qqBind\b/.test(code)) hits.push(`${rel}:${i + 1} ${trimmed}`)
    }
    assert.deepEqual(
      hits,
      [],
      'qqBind 是本件的软依赖（不在 inject 里），直接属性访问会抛 cannot get property "qqBind" without inject：\n' + hits.join('\n'),
    )
  }
})
