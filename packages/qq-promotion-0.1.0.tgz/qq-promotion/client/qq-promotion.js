/**
 * qq-promotion 前端半 —— 管理页「QQ 自动晋升」（后端设置 → /b/qq-promotion）
 *
 * 依赖宿主能力（window.tsweb，由 web 插件提供，写法照 plugins/online-stats/client/online-stats.js:1-36）：
 *   - window.tsweb.registerView({ id, title, section, path, render })
 *   - window.tsweb.api(path, opts)   带 Bearer 的统一请求：{ ok, status, data }
 *
 * 这一页只做四件事（对应配置的四个字段）：
 *   1. 启用开关 / 目标用户组 / 模式（auto|force）/ 忽略的用户组 —— 编辑与保存
 *   2. 保存后**必须**回显"是否真的下发成功"（逐服成功/失败 + 原因），
 *      这是"界面显示已启用、实际没生效"那类静默失效的唯一可见性来源
 *   3. "服端实际生效的配置"探测（GET /api/qq-promotion/status?probe=1），
 *      与宿主配置逐字段比对；不一致时明确指出差异
 *   4. 手动重推按钮（某服刚才离线时的补救入口）
 *
 * 三条写进界面文案的既存语义（不要改成"看起来更好"的版本）：
 *   - 晋升只发生在**玩家登录时**（游戏服侧 PlayerHooks.PlayerPostLogin）：
 *     改配置**不会**立刻晋升当前在线玩家，页面上要如实写清楚，不能让管理员以为保存就生效了。
 *   - 只有 auto 模式有"已达目标组则跳过"的语义；force（以及其它任何值）一律直接改组。
 *   - 忽略的用户组是**保护名单**：命中即静默跳过，为空等于没有任何保护。
 *
 * 约定：禁止 emoji；不引入第三方 UI 库；图标用内联 SVG；局部类名统一 qqp- 前缀。
 */
(function () {
  'use strict'

  var tsw = window.tsweb
  if (!tsw) return

  var root = null
  var styleDone = false

  var state = {
    config: null,
    configFile: '',
    configError: '',
    warnings: [],
    defaults: { ignoreGroups: ['owner', 'superadmin'], mode: 'auto' },
    desiredVersion: 0,
    servers: [],
    pendingCount: 0,
    probe: null,
    audit: [],
    msg: { text: '', cls: 'muted' },
    busy: false,
  }

  // ═══════════ 工具 ═══════════

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    })
  }

  function api(path, opts) {
    return tsw.api(path, opts)
  }

  function $(id) {
    return root ? root.querySelector('#' + id) : null
  }

  function setMsg(text, cls) {
    state.msg = { text: text || '', cls: cls || 'muted' }
    var el = $('qqp-msg')
    if (el) {
      el.className = state.msg.cls
      el.textContent = state.msg.text
    }
  }

  /** 错误文案：把"服端没装 DLL"翻译成可操作提示（与后端 serverHalfMissing 标志对应） */
  function errText(data, status) {
    if (data && data.serverHalfMissing) {
      return (data.error || '游戏服端未安装 QqPromotion.dll') +
        ' —— 请到「插件下发」页对该服务器启用 QqPromotion.dll 后重试'
    }
    return (data && data.error) || ('HTTP ' + status)
  }

  function pad2(n) {
    return (n < 10 ? '0' : '') + n
  }

  function fmtTime(t) {
    if (!t) return '-'
    var d = new Date(t)
    if (isNaN(d.getTime())) return String(t)
    return pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' +
      pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds())
  }

  /** 文本框 → 组名数组：换行 / 逗号 / 分号 / 空白都能拆（与后端 normalizeIgnoreGroups 的拆分一致） */
  function splitList(text) {
    var seen = {}
    var out = []
    String(text == null ? '' : text).split(/[\s,;，；]+/).forEach(function (part) {
      var name = part.trim()
      if (name === '') return
      var key = name.toLowerCase()
      if (seen[key]) return
      seen[key] = true
      out.push(name)
    })
    return out
  }

  function setBusy(on) {
    state.busy = on
    var btns = root ? root.querySelectorAll('button[data-qqpact]') : []
    for (var i = 0; i < btns.length; i++) btns[i].disabled = on
  }

  function background(promise, onError) {
    if (!promise || typeof promise.then !== 'function') return
    promise.catch(function (err) {
      console.warn('[qq-promotion] 后台任务异常：' + ((err && err.message) || err))
      if (onError) onError(err)
    })
  }

  // ═══════════ 样式 ═══════════

  function injectStyle() {
    if (styleDone) return
    styleDone = true
    var css = '' +
      '.qqp-panel{border:1px solid var(--border,#2a2f3a);border-radius:8px;padding:14px 16px;margin-bottom:14px}' +
      '.qqp-panel h3{margin:0 0 10px;font-size:14px}' +
      '.qqp-row{display:flex;align-items:center;gap:10px;margin:10px 0;flex-wrap:wrap}' +
      '.qqp-row>label{min-width:110px;color:var(--muted,#9aa4b2);font-size:13px}' +
      '.qqp-hint{font-size:12px;color:var(--muted,#9aa4b2);margin:2px 0 0;line-height:1.6}' +
      '.qqp-warn{color:#d9a41a}' +
      '.qqp-error{color:#e0533d}' +
      '.qqp-ok{color:#3fae6a}' +
      '.qqp-muted{color:var(--muted,#9aa4b2)}' +
      '.qqp-table{width:100%;border-collapse:collapse;font-size:13px}' +
      '.qqp-table th,.qqp-table td{border-bottom:1px solid var(--border,#2a2f3a);padding:6px 8px;text-align:left;vertical-align:top}' +
      '.qqp-table th{color:var(--muted,#9aa4b2);font-weight:500}' +
      '.qqp-code{font-family:ui-monospace,Consolas,monospace;font-size:12px;word-break:break-all}' +
      '.qqp-inline{display:flex;gap:8px;flex-wrap:wrap}'
    var el = document.createElement('style')
    el.textContent = css
    document.head.appendChild(el)
  }

  // ═══════════ 渲染 ═══════════

  function renderShell(container) {
    container.innerHTML =
      '<h2 style="margin:0 0 4px">QQ 自动晋升</h2>' +
      '<p class="qqp-hint" style="margin-bottom:14px">' +
      '玩家登录时，若其账号在 QQ 绑定台账里（由 qq-bind 落盘的绑定快照文件识别）且本页已启用，' +
      '则由游戏服半按下面四个字段自动调整用户组。' +
      '</p>' +
      '<div id="qqp-msg" class="' + esc(state.msg.cls) + '"></div>' +
      '<div id="qqp-config"></div>' +
      '<div id="qqp-status"></div>' +
      '<div id="qqp-audit"></div>'
  }

  function renderConfig() {
    var box = $('qqp-config')
    if (!box) return
    var c = state.config || {}
    var ignore = Array.isArray(c.ignoreGroups) ? c.ignoreGroups.join('\n') : ''
    var mode = String(c.mode || 'auto') === 'auto' ? 'auto' : 'force'

    var warnHtml = ''
    if (state.configError) {
      warnHtml += '<p class="qqp-error">' + esc(state.configError) + '</p>'
    }
    if (state.warnings && state.warnings.length) {
      warnHtml += state.warnings.map(function (w) {
        return '<p class="' + (w.level === 'error' ? 'qqp-error' : 'qqp-warn') + '">' + esc(w.message) + '</p>'
      }).join('')
    }

    box.innerHTML = '<div class="qqp-panel">' +
      '<h3>晋升配置</h3>' +
      warnHtml +
      '<div class="qqp-row"><label>启用</label>' +
      '<input type="checkbox" id="qqp-enabled"' + (c.enabled === true ? ' checked' : '') + '>' +
      '<span class="qqp-hint">关闭时登录不做任何判断（默认关闭）</span></div>' +

      '<div class="qqp-row"><label>目标用户组</label>' +
      '<input id="qqp-group" value="' + esc(c.targetGroup == null ? '' : c.targetGroup) + '" placeholder="例如 vip" style="max-width:240px">' +
      '<span class="qqp-hint">不能为空；该组必须在各服 TShock 里已存在，否则服端跳过并记一条警告</span></div>' +

      '<div class="qqp-row"><label>模式</label>' +
      '<select id="qqp-mode" style="max-width:420px">' +
      '<option value="auto"' + (mode === 'auto' ? ' selected' : '') + '>auto - 沿父组链判断，已达目标组则跳过</option>' +
      '<option value="force"' + (mode === 'force' ? ' selected' : '') + '>force - 直接改组，不做判断</option>' +
      '</select><span class="qqp-hint">只有 auto 有特殊语义，其它值一律按 force</span></div>' +

      '<div class="qqp-row" style="align-items:flex-start"><label>忽略的用户组</label>' +
      '<textarea id="qqp-ignore" rows="3" style="min-width:280px" placeholder="一行一个，或用逗号分隔">' + esc(ignore) + '</textarea>' +
      '<span class="qqp-hint">命中这些组的玩家不晋升（保护管理组不被降级）；默认 ' +
      esc((state.defaults.ignoreGroups || []).join(' / ')) + '。留空等于没有任何保护名单，页面会给出警告</span></div>' +

      '<div class="qqp-row qqp-inline">' +
      '<button class="primary sm" data-qqpact="save">保存并即时下发</button>' +
      '<button class="sm" data-qqpact="reload">重新读取</button>' +
      '<button class="sm" data-qqpact="push-pending">补推未确认的服务器</button>' +
      '<button class="sm" data-qqpact="push-all">全部重推</button>' +
      '</div>' +

      '<p class="qqp-hint">配置文件：<span class="qqp-code">' + esc(state.configFile || '(未知)') + '</span></p>' +
      '<p class="qqp-hint">' +
      '注意：晋升只在**玩家登录时**发生。保存配置不会立刻晋升当前在线的玩家，' +
      '他们需要重新登录（或由管理员手工改组）。' +
      '</p>' +
      '</div>'
  }

  function pushResultHtml(push) {
    if (!push) return ''
    var servers = Array.isArray(push.servers) ? push.servers : []
    var okCount = Number(push.okCount || 0)
    var head = '已保存并即时下发：成功 ' + okCount + '/' + Number(push.total || servers.length) + ' 台' +
      '（配置版本 v' + esc(push.version) + '）'
    var cls = push.ok ? 'qqp-ok' : 'qqp-error'
    var rows = servers.filter(function (r) { return !r.ok }).map(function (r) {
      return '<li>' + esc(r.name || r.id) + '：' + esc(r.error || '未生效') + '</li>'
    }).join('')
    return '<p class="' + cls + '">' + esc(head) + '</p>' +
      (rows ? '<ul class="qqp-hint">' + rows + '</ul>' : '') +
      (push.note ? '<p class="qqp-hint">' + esc(push.note) + '</p>' : '')
  }

  function renderStatus() {
    var box = $('qqp-status')
    if (!box) return
    var probeByServer = {}
    if (state.probe && Array.isArray(state.probe.servers)) {
      state.probe.servers.forEach(function (p) { probeByServer[String(p.id)] = p })
    }

    var rows = state.servers.map(function (s) {
      var p = probeByServer[String(s.id)]
      var probeCell
      if (!p) {
        probeCell = '<span class="qqp-muted">未探测</span>'
      } else if (!p.ok) {
        probeCell = '<span class="qqp-error">读取失败：' + esc(p.error || '') + '</span>'
      } else if (p.match) {
        probeCell = '<span class="qqp-ok">与宿主一致</span>'
      } else {
        probeCell = '<span class="qqp-warn">不一致：' + esc((p.diff || []).join('；')) + '</span>'
      }
      var bindingsCell = '<span class="qqp-muted">-</span>'
      if (p && p.ok && p.state && p.state.bindings) {
        var b = p.state.bindings
        bindingsCell = esc(String(b.count || 0)) + ' 条' +
          (b.snapshotVersion ? '<br><span class="qqp-muted">快照 v' + esc(b.snapshotVersion) + '</span>' : '') +
          (b.note ? '<br><span class="qqp-muted">' + esc(b.note) + '</span>' : '')
      } else if (s.bindings) {
        bindingsCell = esc(String(s.bindings.count || 0)) + ' 条'
      }

      return '<tr>' +
        '<td>' + esc(s.name || s.id) + '<br><span class="qqp-muted qqp-code">' + esc(s.id) + '</span></td>' +
        '<td>' + (s.ok ? '<span class="qqp-ok">成功</span>' : '<span class="qqp-error">失败</span>') +
        '<br><span class="qqp-muted">v' + esc(s.version) + '</span></td>' +
        '<td>' + esc(fmtTime(s.at)) + '</td>' +
        '<td>' + (s.error ? '<span class="qqp-error">' + esc(s.error) + '</span>' : '<span class="qqp-muted">-</span>') + '</td>' +
        '<td>' + probeCell + '</td>' +
        '<td>' + bindingsCell + '</td>' +
        '</tr>'
    }).join('')

    box.innerHTML = '<div class="qqp-panel">' +
      '<h3>下发状态<span class="qqp-muted" style="font-weight:400;font-size:12px">　期望版本 v' +
      esc(state.desiredVersion) + '　未确认 ' + esc(state.pendingCount) + ' 台</span></h3>' +
      (state.servers.length === 0
        ? '<p class="qqp-muted">尚未向任何服务器下发（没有启用中的服务器，或宿主刚启动）。</p>'
        : '<table class="qqp-table"><thead><tr>' +
          '<th>服务器</th><th>最近下发</th><th>时间</th><th>失败原因</th><th>服端实际生效</th><th>服端绑定快照</th>' +
          '</tr></thead><tbody>' + rows + '</tbody></table>') +
      '<p class="qqp-hint">' +
      '"服端实际生效"来自游戏服半的 GET /data/promotion/status：它读的是**游戏服进程内存里当前这份配置**，' +
      '不是宿主以为发过什么。所以这一列是"配置是否真生效"的直接证据。' +
      '</p>' +
      '</div>'
  }

  function renderAudit() {
    var box = $('qqp-audit')
    if (!box) return
    var rows = (state.audit || []).slice(0, 10).map(function (r) {
      var detail = []
      if (r.keys) detail.push('字段 ' + (Array.isArray(r.keys) ? r.keys.join('、') : String(r.keys)))
      if (r.enabled !== undefined) detail.push('启用=' + (r.enabled === true ? '是' : '否'))
      if (r.targetGroup !== undefined) detail.push('目标组=' + String(r.targetGroup || '空'))
      if (r.mode !== undefined) detail.push('模式=' + String(r.mode))
      if (Array.isArray(r.ignoreGroups)) detail.push('忽略组=' + (r.ignoreGroups.join('/') || '空'))
      return '<tr><td>' + esc(fmtTime(r.t)) + '</td><td>' + esc(r.action) + '</td><td>' + esc(detail.join('；')) + '</td></tr>'
    }).join('')

    box.innerHTML = '<div class="qqp-panel">' +
      '<h3>配置变更审计<span class="qqp-muted" style="font-weight:400;font-size:12px">　最近 10 条</span></h3>' +
      (rows
        ? '<table class="qqp-table"><thead><tr><th>时间</th><th>动作</th><th>内容</th></tr></thead><tbody>' + rows + '</tbody></table>'
        : '<p class="qqp-muted">暂无记录。晋升动作发生在游戏服侧，宿主只审计配置变更。</p>') +
      '</div>'
  }

  // ═══════════ 数据 ═══════════

  async function loadConfig() {
    var res = await api('/api/qq-promotion/config')
    if (!res.ok) {
      setMsg(errText(res.data, res.status), 'qqp-error')
      return false
    }
    var d = res.data || {}
    state.config = d.config || null
    state.configFile = d.configFile || ''
    state.configError = d.configError || ''
    state.warnings = Array.isArray(d.warnings) ? d.warnings : []
    if (d.defaults) state.defaults = { ignoreGroups: d.defaults.ignoreGroups || [], mode: d.defaults.mode || 'auto' }
    renderConfig()
    return true
  }

  async function loadStatus(withProbe) {
    var res = await api('/api/qq-promotion/status' + (withProbe ? '?probe=1' : ''))
    if (!res.ok) {
      setMsg(errText(res.data, res.status), 'qqp-error')
      return false
    }
    var d = res.data || {}
    state.servers = Array.isArray(d.servers) ? d.servers : []
    state.desiredVersion = d.desiredVersion != null ? d.desiredVersion : 0
    state.pendingCount = Number(d.pendingCount || 0)
    state.probe = d.probe || null
    renderStatus()
    return true
  }

  async function loadAudit() {
    var res = await api('/api/qq-promotion/audit?limit=10')
    if (!res.ok) return false
    state.audit = (res.data && res.data.rows) || []
    renderAudit()
    return true
  }

  // ═══════════ 动作 ═══════════

  async function save() {
    if (state.busy) return
    var enabledEl = $('qqp-enabled')
    var groupEl = $('qqp-group')
    var modeEl = $('qqp-mode')
    var ignoreEl = $('qqp-ignore')
    if (!enabledEl || !groupEl || !modeEl || !ignoreEl) return

    var group = String(groupEl.value || '').trim()
    if (!group) {
      setMsg('目标用户组不能为空（服务端与服端都会拒绝空值）', 'qqp-error')
      return
    }
    var mode = String(modeEl.value || 'auto') === 'auto' ? 'auto' : 'force'
    var updates = {
      enabled: enabledEl.checked === true,
      targetGroup: group,
      mode: mode,
      ignoreGroups: splitList(ignoreEl.value),
    }

    setBusy(true)
    setMsg('正在保存并下发...', 'qqp-muted')
    var res = await api('/api/qq-promotion/config', { json: { updates: updates } })
    setBusy(false)

    if (!res.ok) {
      setMsg('保存失败：' + errText(res.data, res.status), 'qqp-error')
      return
    }
    var d = res.data || {}
    state.config = d.config || state.config
    state.warnings = Array.isArray(d.warnings) ? d.warnings : []
    renderConfig()

    // 结果如实回显：push 里逐服成败 + 失败原因（不把"提交成功"当成"已生效"）
    var box = $('qqp-config')
    if (box) box.insertAdjacentHTML('beforeend', pushResultHtml(d.push))
    setMsg(
      d.push && d.push.ok
        ? '已保存并即时下发：全部 ' + Number(d.push.total) + ' 台服务器确认生效'
        : '已保存，但下发未完全成功：请查看下方逐服原因（将会自动重试）',
      d.push && d.push.ok ? 'qqp-ok' : 'qqp-error',
    )
    background(loadStatus(true))
    background(loadAudit())
  }

  async function manualPush(onlyPending) {
    if (state.busy) return
    setBusy(true)
    setMsg(onlyPending ? '正在补推未确认的服务器...' : '正在全部重推...', 'qqp-muted')
    var res = await api('/api/qq-promotion/push', { json: { onlyPending: onlyPending === true } })
    setBusy(false)
    if (!res.ok) {
      setMsg('重推失败：' + errText(res.data, res.status), 'qqp-error')
      return
    }
    var push = (res.data && res.data.push) || {}
    var box = $('qqp-config')
    if (box) box.insertAdjacentHTML('beforeend', pushResultHtml(push))
    setMsg(
      push.total === 0
        ? (push.note || '没有需要下发的服务器')
        : (push.ok ? '重推完成：全部 ' + push.total + ' 台确认生效' : '重推完成，仍有 ' + Number(push.pendingCount) + ' 台未生效'),
      push.ok ? 'qqp-ok' : 'qqp-error',
    )
    background(loadStatus(true))
  }

  async function reload() {
    if (state.busy) return
    setBusy(true)
    setMsg('正在读取...', 'qqp-muted')
    var okCfg = await loadConfig()
    var okStatus = await loadStatus(true)
    await loadAudit()
    setBusy(false)
    setMsg(okCfg && okStatus ? '已读取最新配置与下发状态' : '读取未完全成功，请重试', okCfg && okStatus ? 'qqp-ok' : 'qqp-error')
  }

  function onClick(e) {
    var t = e.target
    if (!t || !root || !root.contains(t)) return
    var btn = t.closest ? t.closest('[data-qqpact]') : null
    if (!btn || btn.disabled) return
    var act = btn.getAttribute('data-qqpact')
    if (act === 'save') return save()
    if (act === 'reload') return reload()
    if (act === 'push-pending') return manualPush(true)
    if (act === 'push-all') return manualPush(false)
  }

  // ═══════════ 视图注册 ═══════════

  try {
    tsw.registerView({
      id: 'qq-promotion',
      title: 'QQ 自动晋升',
      section: '后端设置',
      path: '/b/qq-promotion',
      icon: 'key',
      render: function (container) {
        root = container
        injectStyle()
        renderShell(container)

        /**
         * 事件委托：先按同一引用解绑再绑（不是"只绑一次"标记）。
         * 宿主的 route() 每次进入本路由都调 render(container)，而 container 是常驻节点；
         * 无条件下 addEventListener 会让监听器随访问次数累加（一次点击执行 N 次）。
         * 也不能只靠标记：插件热重载会用新的 cache-busting query 重新 import，
         * 新实例若因标记仍在而跳过绑定，点击会继续由旧 bundle 的闭包处理。
         */
        if (container.__qqpClick) container.removeEventListener('click', container.__qqpClick)
        container.__qqpClick = function (ev) {
          try {
            onClick(ev)
          } catch (err) {
            console.warn('[qq-promotion] 点击处理异常：' + ((err && err.message) || err))
          }
        }
        container.addEventListener('click', container.__qqpClick)

        background(loadConfig())
        background(loadStatus(true))
        background(loadAudit())
      },
    })
    console.log('[tsweb] qq-promotion 客户端插件已注册: #/b/qq-promotion')
  } catch (err) {
    console.warn('[qq-promotion] 注册管理页失败：' + ((err && err.message) || err))
  }
})()
