/**
 * 本件审计流水（<dataDir>/promotion/audit.jsonl，追加写）
 *
 * 事件名（迁移说明：本件是独立插件，动作名**不带插件名后缀的连字符形态**，
 * 与旧版后端 auditEvents 的 `config.promotion.set` 语义对齐）
 *   promotion.config.set    管理页/终端改了配置（谁、什么时候、改了哪些字段）
 *   promotion.config.seed   宿主首次运行时从 qq-bind 旧配置迁移了 QQ 绑定提升设置
 *
 * 为什么本件只需要记"配置变更"：
 *   晋升动作**只发生在游戏服侧**（登录热路径 + 每分钟节拍，宿主拿不到逐次晋升事件），
 *   宿主能审计的只有"谁在什么时候把配置改成了什么"。游戏服侧的晋升结果落在
 *   TShock 控制台日志（`[Promotion] 晋升成功：...`），不在这里伪造。
 *
 * 写法上刻意保持极简（JSONL 追加 + 单文件上限轮转），并按插件各存一份：
 * 不依赖其它插件的模块，也不共享文件。
 */
import { appendFile, mkdir, readFile, stat, rename } from 'node:fs/promises'
import path from 'node:path'

/** 单文件上限（超过则轮转为 audit.jsonl.1），避免无限增长 */
const MAX_BYTES = 8 * 1024 * 1024

/** 本件的审计动作名（唯一权威定义，测试与文档都引这里） */
export const ACTIONS = {
  /** 配置变更（对齐旧版 config.promotion.set 的语义） */
  configSet: 'promotion.config.set',
  /** 首次运行的旧配置迁移 */
  configSeed: 'promotion.config.seed',
}

export class AuditLog {
  constructor({ file }) {
    if (!file) throw new Error('AuditLog 需要 file 路径')
    this.file = file
    this.dir = path.dirname(file)
  }

  /**
   * 追加一条审计。
   * @param {string} action 见 ACTIONS
   * @param {object} entry  { actor, ...detail }
   */
  async append(action, entry = {}) {
    const line = JSON.stringify({
      t: new Date().toISOString(),
      action: String(action),
      actor: entry.actor != null ? String(entry.actor) : '',
      ...entry,
    }) + '\n'
    await mkdir(this.dir, { recursive: true })
    await this._rotateIfNeeded()
    await appendFile(this.file, line, 'utf8')
    return true
  }

  async _rotateIfNeeded() {
    try {
      const st = await stat(this.file)
      if (st.size >= MAX_BYTES) await rename(this.file, `${this.file}.1`)
    } catch (err) {
      if (err.code !== 'ENOENT') throw err
    }
  }

  /** 读取最近 n 条（新的在前）；文件不存在返回空数组，坏行降级为 parse-error 行 */
  async tail(limit = 100) {
    const n = Math.min(Math.max(1, Number(limit) || 100), 1000)
    let raw
    try {
      raw = await readFile(this.file, 'utf8')
    } catch (err) {
      if (err.code === 'ENOENT') return []
      throw err
    }
    const lines = raw.split('\n').filter((l) => l.trim() !== '')
    const out = []
    for (let i = lines.length - 1; i >= 0 && out.length < n; i--) {
      try {
        out.push(JSON.parse(lines[i]))
      } catch {
        out.push({ t: null, action: 'parse-error', raw: lines[i].slice(0, 200) })
      }
    }
    return out
  }
}
