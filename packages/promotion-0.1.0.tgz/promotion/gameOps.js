/**
 * 游戏服调用层（宿主 → TShock）
 *
 * 本件用自己的端点前缀 `/data/promotion/*`，**不复用** qq-bind 的 `/data/qq/*`：
 * 两个插件各自独立发布，共用前缀会让"DLL 没装"的 404 无法区分是哪一半缺失。
 * 前缀先例：plugins/online-stats/index.js 的 `/data/online`。
 *
 * 传输契约：**GET + query 参数**。理由与既有插件一致：
 *   TShock 的 SecureRestCommand 语义是"带 token 的 GET"，插件侧只读 args.Parameters；
 *   "form body 是否被解析进 Parameters"在本项目没有先例可证，赌它会解析等于把失败做成静默。
 *   本件载荷 = version + 三块配置（qqBind / playtimeThresholds / ignoreGroups 各一个 JSON 串），
 *   远低于 URL 长度上限（时长规则再多也是每条几十字节），无需分块。
 *
 * 错误语义照 online-stats 与 qq-bind 的既有约定，保证"服务器半缺失"在各插件里表现一致：
 *   404      → 501 + serverHalfMissing=true（目标服没装 Promotion.dll）
 *   401/403  → 502（token 缺 data.rest.invsee 权限）
 *   400      → 400 + 服端原文（参数被服端拒绝，不要让管理员只看到"游戏服返回异常"）
 *   网络/超时 → 502
 */
import {
  normalizeIgnoreGroups,
  normalizeMode,
  normalizeQqBind,
  normalizeTargetGroup,
  normalizeThresholds,
} from './config.js'

/** 游戏服半的端点前缀 */
export const SERVER_HALF_PREFIX = '/data/promotion'

/** 游戏服半的 DLL 名（报错文案用） */
export const DLL_NAME = 'Promotion.dll'

/** 本件端点的权限节点（与 TShock 侧 SecureRestCommand 注册的权限一致） */
export const REST_PERMISSION = 'data.rest.invsee'

/**
 * base 插件的"全部用户组名"端点（管理页的目标组下拉用它）。
 * 先例：plugins/base/index.js:230 的 `/api/base/players/groups` 转发到
 * `/data/base/players/groups`（实现在 plugins/base/plugin/AdminActions.cs:311-333，
 * 返回 `{ groups: [...], count: n }`）。
 */
export const GROUPS_ENDPOINT = '/data/base/players/groups'

/** 构造带 status 的错误（宿主路由按 err.status 回状态码） */
export function httpError(status, message, extra = {}) {
  const err = new Error(message)
  err.status = status
  Object.assign(err, extra)
  return err
}

/**
 * "端点缺失（404）"的默认口径：本件自己的端点在 404 时只可能是游戏服没装 Promotion.dll。
 * 读到 base 插件的端点时要用另一套说法（见 fetchGroups），否则会误导管理员去装错的 DLL。
 */
const DEFAULT_MISSING = {
  status: 501,
  dllName: DLL_NAME,
  message: `游戏服端未安装 ${DLL_NAME}`,
  hint: '请在「插件下发」页对该服务器启用本插件',
}

/** base 插件端点缺失时的口径（用户组列表由 base 提供，与本件的 DLL 无关） */
const BASE_MISSING = {
  status: 501,
  dllName: 'Base.dll',
  message: '游戏服端未安装 base 插件（或版本过旧，没有用户组列表端点）',
  hint: '用户组列表由 base 插件提供，请先在「插件下发」页为该服务器启用 base 插件',
}

/** 把游戏服返回的数组字段归一成字符串数组（服端可能回 JArray/数组/逗号串；非法即空数组） */
function toStrList(value) {
  if (Array.isArray(value)) return value.map(String)
  if (typeof value === 'string' && value.trim() !== '') {
    return value.split(/[\s,;，；]+/).filter((s) => s !== '').map(String)
  }
  return []
}

/** 服端回的 qqBind 块（结构异常时给一个"未启用"的安全读数，不让上层拿到 null） */
function toQqBind(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return { enabled: false, targetGroup: '', mode: 'auto' }
  }
  return {
    enabled: value.enabled === true,
    targetGroup: String(value.targetGroup == null ? '' : value.targetGroup),
    mode: String(value.mode == null ? '' : value.mode),
  }
}

/** 服端回的时长规则数组（逐条归一，忽略非法项） */
function toThresholds(value) {
  if (!Array.isArray(value)) return []
  const out = []
  for (const item of value) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) continue
    out.push({
      minutes: Number(item.minutes) || 0,
      targetGroup: String(item.targetGroup == null ? '' : item.targetGroup),
      mode: String(item.mode == null ? '' : item.mode),
    })
  }
  return out
}

/** 服端回的绑定快照读取状态 */
function toBindings(value) {
  const b = value && typeof value === 'object' ? value : {}
  return {
    count: Number(b.count || 0),
    snapshotVersion: Number(b.snapshotVersion || 0),
    snapshotUpdatedAt: String(b.snapshotUpdatedAt || ''),
    file: String(b.file || ''),
    source: String(b.source || ''),
    note: String(b.note || ''),
  }
}

export function createGameOps({ ctx }) {
  const log = (...args) => {
    try {
      console.log('[promotion]', ...args)
    } catch {
      /* 忽略 */
    }
  }

  /** 启用中的服务器（拉原始记录，含 token，代理要用） */
  async function enabledServers() {
    const list = await ctx.servers.list()
    const out = []
    for (const s of list) {
      if (s.enabled === false) continue
      const raw = ctx.servers.getRaw(s.id)
      if (raw) out.push(raw)
    }
    return out
  }

  function rawOf(serverId) {
    return ctx.servers.getRaw(String(serverId)) || null
  }

  /** 统一把 fetchFor 的结果翻成数据或抛错 */
  function unwrap(server, result, label, missing = DEFAULT_MISSING) {
    if (result.ok) return result.data || {}
    if (result.status === 404) {
      // label 已经带了完整路径，够管理员定位是哪一半缺失
      throw httpError(501, `${missing.message}（${label} 返回 404）：${missing.hint}`, {
        serverHalfMissing: true,
        serverId: server.id,
        missingDll: missing.dllName,
      })
    }
    if (result.status === 401 || result.status === 403) {
      throw httpError(502, `游戏服 token 权限不足（HTTP ${result.status}）：需要 ${REST_PERMISSION} 权限`, {
        serverId: server.id,
      })
    }
    if (result.status === 400) {
      // 服端的参数校验拒绝（例如"启用 QQ 绑定提升但目标组为空"）——如实回传服端的 error 文案
      const detail = result.data && result.data.error ? result.data.error : '参数被游戏服拒绝'
      throw httpError(400, `游戏服拒绝该请求：${detail}`, { serverId: server.id })
    }
    const detail = result.data && result.data.error ? `：${result.data.error}` : ''
    throw httpError(502, `游戏服返回异常（HTTP ${result.status}）${detail}`, { serverId: server.id })
  }

  /**
   * 发一次 GET 到游戏服。
   *
   * @param suffixOrPath 默认是**本件前缀下的后缀**（如 '/snapshot'）；absolute=true 时是完整路径。
   *   为什么要有 absolute 这个开关：读用户组要走 base 插件的 `/data/base/players/groups`，
   *   它不是本件前缀下的端点 —— 曾经这里一律拼前缀，结果打到了
   *   `/data/promotion/data/base/players/groups`（不存在的路由，游戏服 404/500），
   *   表现为"目标权限组下拉永远是空的"。
   * @param missing 该端点缺失时的报错口径（默认是"未装 Promotion.dll"；base 的端点要换成 base 的说法）
   */
  async function callGet(server, suffixOrPath, params = {}, { absolute = false, missing } = {}) {
    const full = absolute ? suffixOrPath : `${SERVER_HALF_PREFIX}${suffixOrPath}`
    let result
    try {
      result = await ctx.tshock.fetchFor(server, full, params)
    } catch (err) {
      throw httpError(502, `连接游戏服失败：${err.message}`, { serverId: server.id })
    }
    return unwrap(server, result, `GET ${full}`, missing)
  }

  return {
    enabledServers,
    rawOf,

    /**
     * 下发**整份统一配置**（整份替换，幂等）。
     *
     * 载荷形态（与 plugin/PromotionEndpoints.cs 的参数解析逐字对应）：
     *   version              正整数
     *   qqBind               JSON 对象字符串
     *   playtimeThresholds   JSON 数组字符串
     *   ignoreGroups         JSON 数组字符串
     * 三个配置字段**永远带齐**（含空数组），见 config.js:toGamePayload 的注释。
     */
    async pushConfig(server, payload = {}) {
      const version = Math.max(1, Math.floor(Number(payload.version) || 1))
      const qqBind = normalizeQqBind(payload.qqBind)
      const thresholds = normalizeThresholds(payload.playtimeThresholds)
      const ignoreGroups = normalizeIgnoreGroups(payload.ignoreGroups)

      const data = await callGet(server, '/snapshot', {
        version,
        qqBind: JSON.stringify({
          enabled: qqBind.enabled,
          targetGroup: normalizeTargetGroup(qqBind.targetGroup),
          mode: normalizeMode(qqBind.mode),
        }),
        playtimeThresholds: JSON.stringify(thresholds),
        ignoreGroups: JSON.stringify(ignoreGroups),
        ts: new Date().toISOString(),
      })

      return {
        ok: true,
        applied: data.applied === true,
        // 服端已有更新版本时不会用旧配置覆盖（返回 stale=true），宿主据此把该服标为"未生效"
        stale: data.stale === true,
        version: Number(data.version != null ? data.version : version),
        qqBind: toQqBind(data.qqBind),
        playtimeThresholds: toThresholds(data.playtimeThresholds),
        ignoreGroups: toStrList(data.ignoreGroups),
        saveError: String(data.saveError || ''),
        notes: toStrList(data.notes),
        bindings: toBindings(data.bindings),
      }
    },

    /**
     * 服端实际生效状态（排障与"配置是否真生效"的证据）。
     * 返回的是**游戏服进程内存里当前这份配置**，不是宿主以为发过什么。
     */
    async status(server) {
      const data = await callGet(server, '/status', {})
      return {
        ok: true,
        version: Number(data.version || 0),
        qqBind: toQqBind(data.qqBind),
        playtimeThresholds: toThresholds(data.playtimeThresholds),
        ignoreGroups: toStrList(data.ignoreGroups),
        updatedAt: String(data.updatedAt || ''),
        source: String(data.source || ''),
        file: String(data.file || ''),
        legacyFile: String(data.legacyFile || ''),
        saveError: String(data.saveError || ''),
        trigger: String(data.trigger || ''),
        bindings: toBindings(data.bindings),
      }
    },

    /**
     * 读某台服的**全部用户组名**（管理页「目标权限组」下拉的数据源）。
     *
     * 走 base 插件的 `/data/base/players/groups`（返回 { groups: [...] }）：
     * 组是 TShock 进程内的权威状态，只能从游戏服取；宿主不缓存也不猜测。
     * 失败一律抛 httpError（调用方决定"退化为文本输入并说明原因"），绝不静默返回空列表——
     * 空列表会让管理员以为"这台服一个组都没有"。
     */
    async fetchGroups(server) {
      // 注意 absolute=true：这是 base 插件的绝对端点，不能拼本件的 SERVER_HALF_PREFIX
      // （用户组是 TShock 进程内的权威状态，只有 base 那个端点能取到）
      const data = await callGet(server, GROUPS_ENDPOINT, {}, { absolute: true, missing: BASE_MISSING })
      const groups = toStrList(data.groups)
      if (groups.length === 0) {
        throw httpError(502, '游戏服返回的用户组列表为空（base 插件可能未安装或未启用）', {
          serverId: server.id,
        })
      }
      return { groups, count: Number(data.count || groups.length) }
    },

    log,
  }
}
