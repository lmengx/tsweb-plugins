/**
 * 权限提升（promotion）—— 宿主半
 *
 * 这是旧版 TsWeb「权限提升」功能的独立插件化。旧版的真正形态是**一块配置管两种依据**：
 *   {
 *     "qqBind": { "enabled": false, "targetGroup": "vip", "mode": "auto" },
 *     "playtimeThresholds": [ { "minutes": 3000, "targetGroup": "trustedplayer", "mode": "auto" } ],
 *     "ignoreGroups": ["owner", "superadmin"]
 *   }
 * 两者的执行动作共用一个 TryPromote（旧版 TsWeb/plugin/PromotionConfig.cs:244-307），
 * 且共享同一个忽略组保护名单。本件照搬这个结构，不做拆分。
 *
 * 职责分工：
 *   宿主半（本文件）  配置存储 / 校验 / 审计 / 下发（变更即推 + 连接恢复补推 + 失败重试 + 周期对账）
 *   前端半            /b/promotion：三块卡片（QQ 绑定提升 / 游玩时长提升 / 忽略组）+ 下发状态可见
 *   游戏服半          Promotion.dll：登录识别（QQ 绑定）+ 每分钟节拍（游玩时长），共用 TryPromote
 *   seed.js           首次运行从 qq-bind 旧配置的 promotion 块迁移 QQ 绑定提升设置
 *
 * 三条必须一致的行为（与旧版逐条对齐，见交付报告的语义对照表）：
 *   1. **晋升不需要管理员手动触发**：QQ 绑定在**玩家登录时**识别一次
 *      （旧版 QQ.cs:172-195，经 AccountSync.cs:279-293 调用）；
 *      游玩时长在**每分钟**节拍里检查（旧版 OnlineData.cs:71-84 的 3600 tick 分支）。
 *      改配置**不会**立刻晋升当前在线玩家 —— 保持旧行为，服端也没有"立即晋升"端点。
 *   2. 配置变更必须**立即下发**（这一条是"界面显示已启用、实际没生效"那类静默失效的解药）：
 *      POST /api/promotion/config 在同一请求里完成落盘 + 下发，并把逐服结果原样回显。
 *   3. 下发失败**永不静默**：逐服状态进 pushStatus，经 /status 与保存响应回给前端，
 *      同时按退避重试，直到该服确认应用（或管理员看到持续的失败原因）。
 *
 * 软依赖：qq-bind **可能没装**（它是另一件独立发布的插件）。没装时：
 *   - 「游玩时长提升」完全不受影响（时长数据来自 online-stats 的 player_daily_stat，与 qq-bind 无关）；
 *   - 「QQ 绑定提升」显示为**不可用并给出原因**（配置项照常可编辑下发，只是服端识别不到绑定，
 *     因为服端要读 qq-bind 落盘的 qqbind-snapshot.json）。
 *   取服务一律走 ctx.get（见 seed.js 的 optionalService），**不得**直接属性访问未注入的服务
 *   （那会抛 `cannot get property "x" without inject`，可选链挡不住，docs/插件开发约定.md §2.3）。
 *
 * 依赖：webServer / auth / servers / tshock / paths（全部由宿主或基础插件提供）
 * 约定：禁止 emoji；状态数据走 ctx.paths.dataOf('promotion')（不在插件目录内）。
 */
import { join } from 'node:path'

import { ACTIONS, AuditLog } from './audit.js'
import {
  PUSH_DEFAULTS,
  configWarnings,
  defaultConfig,
  loadConfig,
  normalizeConfig,
  saveConfig,
  setByPath,
  toGamePayload,
  validateConfig,
} from './config.js'
import { DLL_NAME, createGameOps, httpError } from './gameOps.js'
import { LEGACY_SOURCE_PLUGIN, qqBindAvailability, readLegacyPromotion, seedFromLegacyPromotion } from './seed.js'

export const name = 'promotion'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths']

/** 单次手动下发可指定的服务器上限（防止一次请求把几十台服串行打完） */
const PUSH_LIMIT = 50

export class PromotionService {
  constructor({ ctx, dataDir, configFile, auditFile, push }) {
    this.ctx = ctx
    this.dataDir = dataDir
    this.configFile = configFile || join(dataDir, 'config.json')
    this.auditFile = auditFile || join(dataDir, 'audit.jsonl')

    /** 当前生效配置（唯一权威；下发内容永远由它派生） */
    this.config = defaultConfig()
    /** 读配置时发现的问题（文件损坏等），如实回显给管理员 */
    this.configError = ''

    /**
     * 下发/对账节奏。**不写进配置文件**：config.json 的字段要与旧版一字不差
     * （旧版是进程内功能，没有下发节奏这个概念）。见 config.js:PUSH_DEFAULTS。
     */
    this.push = { ...PUSH_DEFAULTS, ...(push && typeof push === 'object' ? push : {}) }

    this.gameOps = createGameOps({ ctx })
    this.audit = new AuditLog({ file: this.auditFile })

    /**
     * 宿主侧期望的配置版本，**每次下发尝试都自增**（单调）。
     * 服端会拒绝比它当前版本更旧的载荷（stale），所以"重试"必须带新版本号，
     * 否则一次乱序到达的旧请求会把新配置覆盖回去。
     */
    this.desiredVersion = 0
    /**
     * 配置内容修订号：**只在配置真的变了（或宿主刚启动）时自增**。
     * 为什么不能直接用 desiredVersion 判断"某服是否已是最新配置"：一次只推一台服的
     * 补推/重试也会把 desiredVersion 抬高，于是刚刚确认过的其它服会被误判成"落后"，
     * 未确认计数永远清不掉（实测踩到）。所以"版本号"管顺序，"修订号"管是否最新，各司其职。
     */
    this.configRevision = 1
    /** serverId → { version, revision }（已确认应用的那一次下发） */
    this.acked = new Map()
    /** 最近一次已知的启用服务器 id 集合（用于算"未确认"台数，含从未推过的服） */
    this.knownServerIds = new Set()
    /** serverId → 最近一次下发结果（前端展示 + 排障） */
    this.pushStatus = new Map()

    this._reconcileTimer = null
    this._retryTimer = null
    this._retryDelay = 0
  }

  // ═══════════════════════ 生命周期 ═══════════════════════

  async init() {
    const loaded = await loadConfig(this.configFile)
    this.config = loaded.config
    this.configError = loaded.error
    this._retryDelay = this.push.retryIntervalMs

    if (loaded.error) {
      // 配置损坏 → 按默认（未启用）运行并明确报错：绝不因为读不懂配置就"按启用"乱改组
      console.error(`[promotion] ${loaded.error}`)
    } else if (!loaded.existed) {
      // 首次运行：先尝试从 qq-bind 旧配置迁移 QQ 绑定提升设置，迁移成功就不再打"按默认配置运行"
      // （否则日志会与随后的实际生效配置自相矛盾）
      const seed = await this._seedFromLegacyQqBind()
      if (!seed.seeded) {
        console.log(
          `[promotion] 尚无配置文件（${this.configFile}），按默认配置运行：` +
          `QQ 绑定提升${this.config.qqBind.enabled ? '已启用' : '未启用'}、` +
          `时长规则 ${this.config.playtimeThresholds.length} 条`,
        )
      }
    }

    // 启动即对账一次（异步、不阻塞 apply）：宿主重启后若某服配置落后，这里就补上
    this.startReconcile()
    this.pushConfig({ reason: '宿主启动对账' }).catch((err) => {
      console.error(`[promotion] 启动对账下发失败：${err.message}`)
    })
    return this
  }

  /**
   * 首次运行时的旧配置迁移（seed）：把 qq-bind 旧配置里的 promotion 块搬过来，
   * 映射成新结构的 qqBind 块 + 顶层 ignoreGroups（映射表见 seed.js 顶部）。
   *
   * 触发条件**只有**"本件自己的配置文件不存在"：文件已存在就绝不覆盖，哪怕旧值与现值不同
   * （用户可能已经在本件里改过）；配置损坏（error 非空）也不 seed，免得把"读不懂的现值"
   * 换成"另一个来源的值"。写下去之后下次启动 existed 即为 true，天然只迁移一次（幂等）。
   *
   * **任何异常都吞掉并只记日志**：迁移是便利功能，不能因为"旧配置读不出来"就让本插件
   * 加载失败（那会让管理员连配置页都进不去）。
   */
  async _seedFromLegacyQqBind() {
    try {
      const legacy = await readLegacyPromotion(this.ctx)
      if (!legacy.available) {
        // 没有可迁移的旧值（qq-bind 没装 / 无 promotion 块 / 读不出来）：**不写**"已迁移"日志
        return { seeded: false, reason: legacy.reason }
      }

      const { config, adopted, skipped } = seedFromLegacyPromotion(legacy.promotion)
      if (adopted.length === 0) {
        // 旧块在、但一个可用字段都没有：保持默认配置，也不写"已迁移"日志（没搬任何东西）
        return { seeded: false, reason: '旧 promotion 块里没有可采用的字段' }
      }

      await saveConfig(this.configFile, config)
      this.config = config
      this.configError = ''

      await this.audit.append(ACTIONS.configSeed, {
        // 宿主自身发起的迁移，没有自然人操作者：用 'system' 与 'admin'/'terminal' 区分开
        actor: 'system',
        source: LEGACY_SOURCE_PLUGIN,
        sourceFile: legacy.file,
        keys: adopted,
        skipped,
      })

      // 只报来源路径与**字段名**，不打配置明文（保持本件"日志不含配置内容"的习惯）
      console.log(
        `[promotion] 已从 qq-bind 旧配置迁移 QQ 绑定提升设置（来源 ${legacy.file}）：` +
        `采用 ${adopted.join('/')}` +
        (skipped.length > 0 ? `；未采用 ${skipped.join('/')}（旧值不可用，回落本件默认值）` : ''),
      )
      return { seeded: true, keys: adopted, skipped, config }
    } catch (err) {
      console.error(`[promotion] 旧配置迁移跳过（不影响本件加载）：${err.message}`)
      if (process.env.TSWEB_DEBUG) console.error(err.stack)
      return { seeded: false, reason: err.message }
    }
  }

  /**
   * 周期对账：无条件重推一遍（配置极小，代价可忽略）。
   * 为什么无条件而不是"仅推落后的服"：服端的配置文件可能被人删掉/改坏（它会退回默认），
   * 此时宿主的 acked 记录仍是"已确认"，只有无条件重推才能自愈这种"宿主以为生效了"的状态。
   */
  startReconcile() {
    this.stopReconcile()
    const ms = Number(this.push.reconcileIntervalMs) || 0
    if (ms <= 0) return false
    this._reconcileTimer = setInterval(() => {
      this.pushConfig({ reason: '周期对账' }).catch((err) => {
        console.error(`[promotion] 周期对账下发失败：${err.message}`)
      })
    }, ms)
    this._reconcileTimer.unref?.()
    return true
  }

  stopReconcile() {
    if (this._reconcileTimer) {
      clearInterval(this._reconcileTimer)
      this._reconcileTimer = null
    }
  }

  /** 失败重试（指数退避到 push.retryMaxIntervalMs）；全部确认后由 clearRetry 停掉 */
  _scheduleRetry() {
    const cfg = this.push
    if (cfg.retryIntervalMs <= 0) return false
    if (this._retryTimer) return true
    const delay = Math.max(cfg.retryIntervalMs, Math.min(this._retryDelay, cfg.retryMaxIntervalMs))
    this._retryTimer = setTimeout(() => {
      this._retryTimer = null
      this._retryDelay = Math.min(Math.max(this._retryDelay, cfg.retryIntervalMs) * 2, cfg.retryMaxIntervalMs)
      this.pushPending({ reason: '失败重试' }).catch((err) => {
        console.error(`[promotion] 失败重试下发异常：${err.message}`)
      })
    }, delay)
    this._retryTimer.unref?.()
    return true
  }

  _clearRetry() {
    if (this._retryTimer) {
      clearTimeout(this._retryTimer)
      this._retryTimer = null
    }
    this._retryDelay = this.push.retryIntervalMs
  }

  /** 插件禁用/卸载时由 apply 返回的释放钩子调用 */
  dispose() {
    this.stopReconcile()
    this._clearRetry()
  }

  // ═══════════════════════ 下发 ═══════════════════════

  /** 某服是否已确认**当前这份配置**（按修订号判断，见 configRevision 的注释） */
  isAcked(serverId) {
    const entry = this.acked.get(String(serverId))
    return typeof entry === 'object' && entry !== null && entry.revision === this.configRevision
  }

  /** 未确认的服务器 id（含从未下发过的启用的服） */
  pendingIds() {
    const ids = new Set([...this.knownServerIds, ...this.pushStatus.keys()])
    return [...ids].filter((id) => !this.isAcked(id))
  }

  /** 逐服下发（内部实现；targets 为原始服务器记录） */
  async _push(targets, { reason = '' } = {}) {
    if (targets.length === 0) {
      this._clearRetry()
      return {
        ok: true, reason, version: this.desiredVersion, total: 0, okCount: 0, pendingCount: 0,
        servers: [], note: '没有启用中的服务器',
      }
    }

    const version = this.desiredVersion + 1
    this.desiredVersion = version
    const payload = toGamePayload(this.config, version)
    const results = []
    const at = new Date().toISOString()

    for (const server of targets) {
      try {
        const data = await this.gameOps.pushConfig(server, payload)
        /**
         * 成功的判据必须同时满足三条：
         *   applied=true      服端确实收下并替换了内存里的配置
         *   stale=false       服端没有更新的版本（否则这次载荷被拒，等于没生效）
         *   saveError 为空    服端**写盘成功** —— 只改内存不算成功：游戏服重启后配置会退回旧值，
         *                     那种"界面显示成功、重启就没了"的静默失效正是本件要杜绝的，
         *                     所以这里把它算作失败，交给退避重试继续打，直到真正落盘。
         */
        const reasons = []
        if (data.stale === true) {
          reasons.push(`服端已有更新版本（v${data.version}），本次 v${version} 未生效`)
        } else if (data.applied !== true) {
          reasons.push('服端未确认应用（applied=false）')
        }
        if (data.saveError) reasons.push(`服端落盘失败：${data.saveError}`)
        const ok = reasons.length === 0

        const entry = {
          id: server.id,
          name: server.name,
          ok,
          version: Number(data.version || version),
          sentVersion: version,
          applied: data.applied === true,
          stale: data.stale === true,
          saveError: data.saveError,
          notes: data.notes,
          bindings: data.bindings,
          at,
          error: reasons.join('；'),
        }
        if (ok) {
          this.acked.set(String(server.id), { version, revision: this.configRevision })
        } else {
          // 关键：这一次没成功 → 撤掉该服此前"已确认"的记录。
          // 否则一个刚刚下发失败、配置仍是旧的服务器会被算成"已是最新"，
          // 于是补推/重试不会再打它、未确认台数也永远是 0（实测踩到）。
          this.acked.delete(String(server.id))
        }
        this.pushStatus.set(String(server.id), entry)
        results.push(entry)
      } catch (err) {
        // 抛错同样意味着"这一服没有确认新配置"：撤掉旧的确认记录（理由同上）
        this.acked.delete(String(server.id))
        const entry = {
          id: server.id,
          name: server.name,
          ok: false,
          version,
          sentVersion: version,
          applied: false,
          stale: false,
          at,
          error: err.message,
          serverHalfMissing: err.serverHalfMissing === true,
          status: err.status || 502,
        }
        this.pushStatus.set(String(server.id), entry)
        results.push(entry)
      }
    }

    const okCount = results.filter((r) => r.ok).length
    const failed = results.filter((r) => !r.ok)
    if (failed.length > 0) this._scheduleRetry()
    else this._clearRetry()

    try {
      this.ctx.emit('promotion/push', {
        reason,
        version,
        total: results.length,
        okCount,
        servers: results.map((r) => ({ id: r.id, ok: r.ok, error: r.error })),
      })
    } catch {
      /* 无监听者/宿主不提供 emit：忽略 */
    }

    return {
      ok: failed.length === 0,
      reason,
      version,
      total: results.length,
      okCount,
      pendingCount: failed.length,
      servers: results,
    }
  }

  /**
   * 下发到启用服（默认全部；serverIds 显式给出时只发这些）。
   * 语义对齐既有插件：逐服独立成败、永不整体抛错，调用方拿到的结果可直接回给用户。
   */
  async pushConfig({ serverIds = null, reason = '' } = {}) {
    const servers = await this.gameOps.enabledServers()
    this.knownServerIds = new Set(servers.map((s) => String(s.id)))
    const wanted = Array.isArray(serverIds) && serverIds.length > 0 ? serverIds.map(String) : null
    const targets = wanted ? servers.filter((s) => wanted.includes(String(s.id))) : servers
    if (wanted && targets.length === 0) {
      throw httpError(404, '指定的服务器不存在或未启用', { serverIds: wanted })
    }
    return this._push(targets, { reason })
  }

  /** 只推"尚未确认当前配置"的服：连接恢复补推与失败重试都走这里，避免无谓流量 */
  async pushPending({ reason = '' } = {}) {
    const servers = await this.gameOps.enabledServers()
    this.knownServerIds = new Set(servers.map((s) => String(s.id)))
    const targets = servers.filter((s) => !this.isAcked(s.id))
    if (targets.length === 0) {
      this._clearRetry()
      return {
        ok: true, reason, version: this.desiredVersion, total: 0, okCount: 0, pendingCount: 0,
        servers: [], note: '全部启用中的服务器都已确认最新配置',
      }
    }
    return this._push(targets, { reason })
  }

  // ═══════════════════════ 状态与排障 ═══════════════════════

  /** 宿主侧下发状态汇总（不含探测；探测见 probeServers） */
  status() {
    const cfg = normalizeConfig(this.config)
    return {
      config: cfg,
      configFile: this.configFile,
      configError: this.configError,
      warnings: configWarnings(cfg),
      // 软依赖状态：qq-bind 没装时「QQ 绑定提升」不可用（前端据此显示原因）
      dependencies: { qqBind: qqBindAvailability(this.ctx) },
      desiredVersion: this.desiredVersion,
      configRevision: this.configRevision,
      intervals: {
        reconcileIntervalMs: this.push.reconcileIntervalMs,
        retryIntervalMs: this.push.retryIntervalMs,
        retryMaxIntervalMs: this.push.retryMaxIntervalMs,
      },
      servers: [...this.pushStatus.values()]
        .map((r) => ({ ...r }))
        .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id))),
      pendingCount: this.pendingIds().length,
      pendingServerIds: this.pendingIds(),
      retryScheduled: this._retryTimer != null,
    }
  }

  /**
   * 逐服探测"服端实际生效的配置"，并与宿主配置比对。
   * 这是"界面写了什么"与"服端真的按什么在晋升"之间的唯一直接证据（保存响应里只代表提交成功）。
   */
  async probeServers({ serverIds = null } = {}) {
    let servers
    try {
      servers = await this.gameOps.enabledServers()
    } catch (err) {
      return { servers: [], error: `读取服务器列表失败：${err.message}` }
    }
    const wanted = Array.isArray(serverIds) && serverIds.length > 0 ? serverIds.map(String) : null
    const targets = wanted ? servers.filter((s) => wanted.includes(String(s.id))) : servers
    const cfg = normalizeConfig(this.config)
    const out = []

    for (const server of targets) {
      try {
        const state = await this.gameOps.status(server)
        const diff = []

        // QQ 绑定提升：开关 / 目标组 / 模式
        if (state.qqBind.enabled !== cfg.qqBind.enabled) {
          diff.push(`QQ绑定启用=${state.qqBind.enabled}（宿主 ${cfg.qqBind.enabled}）`)
        }
        if (state.qqBind.targetGroup !== cfg.qqBind.targetGroup) {
          diff.push(`QQ绑定目标组=${state.qqBind.targetGroup || '空'}（宿主 ${cfg.qqBind.targetGroup || '空'}）`)
        }
        if (state.qqBind.mode !== cfg.qqBind.mode) {
          diff.push(`QQ绑定模式=${state.qqBind.mode || '空'}（宿主 ${cfg.qqBind.mode}）`)
        }

        // 时长规则：按"规范化后的集合"比对（顺序无关；条目内按 minutes/targetGroup/mode 排序键比较）
        const key = (t) => `${t.minutes}|${t.targetGroup}|${t.mode}`
        const want = cfg.playtimeThresholds.map(key).sort()
        const got = state.playtimeThresholds.map(key).sort()
        if (want.join(',') !== got.join(',')) {
          diff.push(`时长规则=${got.length} 条（宿主 ${want.length} 条）`)
        }

        // 忽略组：集合比对（大小写不敏感，顺序无关）
        const groupSet = (list) => list.map((x) => String(x).toLowerCase()).sort().join(',')
        if (groupSet(state.ignoreGroups) !== groupSet(cfg.ignoreGroups)) {
          diff.push(`忽略组=${state.ignoreGroups.join('/') || '空'}（宿主 ${cfg.ignoreGroups.join('/') || '空'}）`)
        }

        out.push({ id: server.id, name: server.name, ok: true, state, match: diff.length === 0, diff })
      } catch (err) {
        out.push({
          id: server.id,
          name: server.name,
          ok: false,
          error: err.message,
          serverHalfMissing: err.serverHalfMissing === true,
          status: err.status || 502,
        })
      }
    }
    return { servers: out }
  }

  /**
   * 读用户组列表（管理页「目标权限组」下拉）。
   *
   * 走**第一台可用的启用服**：用户组是 TShock 进程内的状态，只能从游戏服取。
   * 逐服尝试、把每台的成败都带回（前端可以显示"哪台取不到"），全都失败时给出明确原因，
   * 让前端**退化为文本输入并说明原因**（绝不静默给一个空下拉，那会让人以为"没有组可选"）。
   */
  async fetchGroups() {
    let servers
    try {
      servers = await this.gameOps.enabledServers()
    } catch (err) {
      return { groups: [], source: null, servers: [], error: `读取服务器列表失败：${err.message}` }
    }
    if (servers.length === 0) {
      return { groups: [], source: null, servers: [], error: '没有启用中的服务器：无法读取用户组列表' }
    }

    const out = []
    let firstOk = null
    for (const server of servers) {
      try {
        const r = await this.gameOps.fetchGroups(server)
        out.push({ id: server.id, name: server.name, ok: true, count: r.groups.length })
        if (!firstOk) firstOk = { id: server.id, name: server.name, groups: r.groups }
      } catch (err) {
        out.push({
          id: server.id, name: server.name, ok: false,
          error: err.message,
          serverHalfMissing: err.serverHalfMissing === true,
        })
      }
    }

    if (!firstOk) {
      const first = out.find((s) => !s.ok) || {}
      return {
        groups: [],
        source: null,
        servers: out,
        error: `所有服务器都取不到用户组列表：${first.error || '原因未知'}`,
      }
    }
    return { groups: firstOk.groups, source: { id: firstOk.id, name: firstOk.name }, servers: out, error: '' }
  }

  // ═══════════════════════ 配置写入 ═══════════════════════

  /**
   * 应用配置更新：白名单/整份校验 → 归一 → 落盘 → 审计 → **立即下发**。
   * 顺序刻意是"先落盘再下发"：落盘失败就不该让服端跑一份只存在于内存的配置。
   */
  async applyUpdates(updates, { actor = 'admin', reason = '配置变更即时下发' } = {}) {
    if (!updates || typeof updates !== 'object' || Array.isArray(updates)) {
      throw httpError(400, '缺少参数: updates（应为 { 配置路径: 值 } 对象）')
    }
    const keys = Object.keys(updates)
    if (keys.length === 0) throw httpError(400, 'updates 为空，没有可写入的配置项')

    const before = normalizeConfig(this.config)
    const draft = JSON.parse(JSON.stringify(before))
    for (const key of keys) setByPath(draft, key, updates[key])

    const next = normalizeConfig(draft)
    return this._persistAndPush(next, { actor, keys, before, reason })
  }

  /**
   * 整份替换（前端"改动即自动保存"用这条：它天然提交整个配置，不必逐字段 diff）。
   * 校验是**严格的**：任何非法值 400，绝不静默兜底（见 config.js:validateConfig）。
   */
  async applyConfig(config, { actor = 'admin', reason = '配置变更即时下发' } = {}) {
    const validated = validateConfig(config)
    const before = normalizeConfig(this.config)
    const next = normalizeConfig(validated)
    const keys = ['qqBind', 'playtimeThresholds', 'ignoreGroups']
    return this._persistAndPush(next, { actor, keys, before, reason })
  }

  async _persistAndPush(next, { actor, keys, before, reason = '配置变更即时下发' }) {
    await saveConfig(this.configFile, next)
    this.config = next
    this.configError = ''
    // 配置内容变了 → 修订号自增：所有服的"已确认"记录随之失效，直到它们各自确认新一轮下发
    this.configRevision += 1

    // 重试退避复位 + 对账定时器按当前节奏重排
    this._clearRetry()
    this.startReconcile()

    await this.audit.append(ACTIONS.configSet, {
      actor,
      keys,
      qqBindEnabled: next.qqBind.enabled,
      qqBindTargetGroup: next.qqBind.targetGroup,
      qqBindMode: next.qqBind.mode,
      thresholdCount: next.playtimeThresholds.length,
      ignoreGroups: next.ignoreGroups,
    })

    // push.pushOnChange 默认 true；只有显式关掉时才不"变更即推"（此时仍有手动重推与周期对账）
    if (this.push.pushOnChange === false) {
      return {
        ok: true,
        config: next,
        warnings: configWarnings(next),
        changed: changedKeys(before, next),
        push: { ok: true, total: 0, okCount: 0, pendingCount: this.pendingIds().length, servers: [], note: 'pushOnChange=false：本次未自动下发（仍有周期对账与手动重推）' },
      }
    }

    const push = await this.pushConfig({ reason })
    return {
      ok: push.ok,
      config: next,
      warnings: configWarnings(next),
      changed: changedKeys(before, next),
      push,
    }
  }
}

/** 顶层字段里哪些真的变了（保存响应里给前端看，避免"看起来保存了其实没变"的困惑） */
function changedKeys(before, after) {
  const out = []
  for (const key of ['qqBind', 'playtimeThresholds', 'ignoreGroups']) {
    if (JSON.stringify(before[key]) !== JSON.stringify(after[key])) out.push(key)
  }
  return out
}

// ═══════════════════════ 插件挂载 ═══════════════════════

export async function apply(ctx, options = {}) {
  try {
    return await applyInner(ctx, options)
  } catch (err) {
    // 约定（docs/插件开发约定.md §2.2）：声明 inject 的插件 apply 是延迟执行的，
    // 期间抛出的异常不会被加载器的 try/catch 捕获，表现为"插件加载成功但什么都没注册"，
    // 所以这里自己兜一层并打印。
    console.error('[promotion] 初始化失败: ' + err.message)
    if (process.env.TSWEB_DEBUG) console.error(err.stack)
    throw err
  }
}

async function applyInner(ctx, options = {}) {
  const dataDir = options.dataDir || ctx.paths.dataOf('promotion')
  const service = new PromotionService({
    ctx,
    dataDir,
    configFile: options.configFile,
    auditFile: options.auditFile,
    push: options.push,
  })
  await service.init()

  const app = ctx.webServer.app
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]
  const fail = (res, err) => {
    const status = err.status || 500
    const body = { error: err.message }
    for (const key of ['serverId', 'serverHalfMissing', 'serverIds', 'missingDll']) {
      if (err[key] !== undefined) body[key] = err[key]
    }
    if (!res.headersSent) res.status(status).json(body)
  }
  const wrap = (handler) => async (req, res) => {
    try {
      res.json(await handler(req, res))
    } catch (err) {
      fail(res, err)
    }
  }

  // 读配置（含损坏提示、生效性警告、软依赖状态）
  app.get('/api/promotion/config', ...admin, wrap(async () => {
    const cfg = normalizeConfig(service.config)
    return {
      ok: true,
      config: cfg,
      configFile: service.configFile,
      configError: service.configError,
      warnings: configWarnings(cfg),
      dependencies: { qqBind: qqBindAvailability(ctx) },
      defaults: {
        ignoreGroups: defaultConfig().ignoreGroups,
        // 注意是 qqBind.mode：defaultConfig() 的顶层没有 mode 字段（那是旧版 qqBindBlock 下的字段），
        // 曾经这里写成 defaultConfig().mode，回给前端的是 undefined
        mode: defaultConfig().qqBind.mode,
        qqBind: defaultConfig().qqBind,
      },
    }
  }))

  /**
   * 保存配置 [+ 立即下发]。三种请求形态都支持：
   *   { config: {...} }       整份替换（前端"改动即自动保存"用这条；严格校验，非法即 400）
   *   { updates: { 路径: 值 } }  按点号路径局部写入（终端/脚本用）
   *   { path, value }          单字段（updates 的语法糖）
   * 返回：{ ok, config, warnings, changed, push: { okCount, total, servers:[...] } }
   *   —— push 的结果**原样**回给前端，让"是否真生效"可见，不假装成功。
   */
  app.post('/api/promotion/config', ...admin, wrap(async (req) => {
    const b = req.body || {}
    if (b.config !== undefined) {
      if (b.updates !== undefined) {
        throw httpError(400, 'config 与 updates 不能同时给出（前者整份替换、后者局部写入）')
      }
      return service.applyConfig(b.config, { actor: 'admin' })
    }
    let updates = b.updates && typeof b.updates === 'object' && !Array.isArray(b.updates) ? b.updates : null
    if (!updates) {
      if (b.path === undefined) throw httpError(400, '缺少参数: config 或 updates 或 path/value')
      updates = { [String(b.path)]: b.value }
    }
    return service.applyUpdates(updates, { actor: 'admin' })
  }))

  // 下发状态（probe=1 时逐服探测服端实际生效的配置）
  app.get('/api/promotion/status', ...admin, wrap(async (req) => {
    const q = req.query || {}
    const out = service.status()
    if (q.probe === '1' || q.probe === 'true') {
      out.probe = await service.probeServers({ serverIds: q.serverId ? [q.serverId] : null })
    }
    return { ok: true, ...out }
  }))

  /**
   * 用户组列表（管理页「目标权限组」下拉的选项）。
   * 取自**实际存在的用户组**（经 base 插件的 /data/base/players/groups）；
   * 取不到时返回 error，前端据此退化为文本输入并说明原因。
   */
  app.get('/api/promotion/groups', ...admin, wrap(async () => {
    const r = await service.fetchGroups()
    return { ok: r.error === '', ...r }
  }))

  /**
   * 手动重推（排障用；也是"某服刚才离线"后的补救入口）。
   * body：{ serverIds?: string[], onlyPending?: boolean }
   */
  app.post('/api/promotion/push', ...admin, wrap(async (req) => {
    const b = req.body || {}
    let serverIds = null
    if (Array.isArray(b.serverIds)) {
      if (b.serverIds.length > PUSH_LIMIT) {
        throw httpError(400, `单次下发服务器上限 ${PUSH_LIMIT} 台（本次 ${b.serverIds.length} 台）`)
      }
      serverIds = b.serverIds.map(String).filter((s) => s !== '')
    }
    const push = b.onlyPending === true
      ? await service.pushPending({ reason: '手动补推（仅未确认的服务器）' })
      : await service.pushConfig({ serverIds, reason: '手动重推' })
    return { ok: push.ok, push }
  }))

  // 审计流水（只记配置变更：晋升动作发生在游戏服侧，宿主拿不到逐次事件）
  app.get('/api/promotion/audit', ...admin, wrap(async (req) => ({
    ok: true,
    rows: await service.audit.tail(Number((req.query || {}).limit) || 50),
  })))

  // ── 连接恢复补推（对齐既有插件的做法）──
  const repush = (why) => {
    if (service.push.pushOnServerConnect === false) return
    service.pushPending({ reason: why }).catch((err) => {
      console.error(`[promotion] ${why}补推失败：${err.message}`)
    })
  }
  try {
    ctx.on('push/connected', () => repush('服务器连接建立'))
    ctx.on('servers/loaded', () => repush('服务器列表加载'))
  } catch (err) {
    // ctx.on 在个别宿主版本上不可用/不允许：补推少一层兜底但插件照常工作，如实记录
    console.error(`[promotion] 事件订阅失败（连接恢复补推不可用）：${err.message}`)
  }

  const dep = qqBindAvailability(ctx)
  console.log(
    `[promotion] 已挂载：QQ 绑定提升${service.config.qqBind.enabled ? `已启用（→${service.config.qqBind.targetGroup}，${service.config.qqBind.mode}）` : '未启用'}、` +
    `时长规则 ${service.config.playtimeThresholds.length} 条、忽略组 ${service.config.ignoreGroups.join('/') || '空'}；` +
    `下发端点 /data/promotion/snapshot（需要游戏服安装 ${DLL_NAME}）；` +
    `qq-bind ${dep.installed ? '已安装（QQ 绑定识别可用）' : '未安装（「QQ 绑定提升」不可用）'}`,
  )

  // 返回 dispose effect：cordis 在插件禁用/卸载时调用（停定时器）
  return () => service.dispose()
}
