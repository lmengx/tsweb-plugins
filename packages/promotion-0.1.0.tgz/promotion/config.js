/**
 * promotion 配置（<dataDir>/promotion/config.json）
 *
 * 这份配置是「权限提升」的**唯一权威**，结构与旧版 TsWeb **一字不差**：
 *   {
 *     "qqBind": { "enabled": false, "targetGroup": "vip", "mode": "auto" },
 *     "playtimeThresholds": [],
 *     "ignoreGroups": ["owner", "superadmin"]
 *   }
 *
 * 为什么是"一块配置同时管两种依据"（这是旧版 TsWeb 的真正形态，也是本件存在的理由）：
 *   旧版 TsWeb/plugin/PromotionConfig.cs:56-70 把「QQ 绑定提升」与「游玩时长提升」
 *   放在**同一份 PromotionConfig** 里，两者共享同一个 IgnoreGroups 保护名单；
 *   执行动作也共用同一个 TryPromote（PromotionConfig.cs:244-307）。
 *   本件照搬这个结构，宿主归一后经自己的端点 `GET /data/promotion/snapshot`
 *   （见 gameOps.js）把**整份配置**下发给游戏服半，服端原子应用并落盘
 *   <TShock.SavePath>/promotion-config.json。
 *
 * 字段默认值（逐字对齐旧版）：
 *   qqBind                PromotionConfig.cs:26-36   → { enabled:false, targetGroup:"vip", mode:"auto" }
 *   playtimeThresholds    PromotionConfig.cs:62      → **空数组**
 *                         （单条阈值的默认值才是 { minutes:3000, targetGroup:"trustedplayer", mode:"auto" }，
 *                           见 PromotionConfig.cs:41-51；空数组与单条默认值是两回事，别混）
 *   ignoreGroups          PromotionConfig.cs:64-69   → ["owner","superadmin"]
 *
 * 关于「忽略组」的两层语义（本件**刻意保留**旧版的全部口径，不"优化"）：
 *   1. 加载/归一：去重（忽略大小写、trim、剔空、**保留首现顺序**），照搬 DedupIgnoreGroups
 *      （PromotionConfig.cs:97-110）。本件的 dedupeGroups/normalizeIgnoreGroups 与它逐条对应。
 *   2. 判定：两处口径**故意重叠**（旧版原样）——
 *        Promotion.TryPromote（旧版 PromotionConfig.cs:262-273）**只比当前组名**；
 *        PromotionThresholds.IsInIgnoreGroup（旧版 OnlineData.cs:203-227）**沿父组链**逐个比对。
 *      本件不做收敛（不把任一处改成另一处的口径），差异与影响写在交付报告的语义对照表里。
 *
 * 时长规则的**匹配顺序**（先按分钟降序、取第一个达标项、命中即 break）见
 * 游戏服半 plugin/PromotionThresholds.cs:CheckAutoPromotion 与它的 JS 镜像
 * test/playtime-rules.test.mjs（本机没有 TShock 环境，那份镜像只是语义双保险，不是 C# 覆盖）。
 */
import { readFile, writeFile, mkdir, copyFile, rename } from 'node:fs/promises'
import path from 'node:path'

/**
 * 忽略组默认值（保护名单）。与旧版 PromotionConfig.cs:64-69 一字不差。
 * 它同时是"载荷不带 ignoreGroups 时服端的保护兜底"（服端 PromotionConfigStore.Sanitize 同值）。
 */
export const DEFAULT_IGNORE_GROUPS = ['owner', 'superadmin']

/** QQ 绑定提升的默认目标组（旧版 PromotionConfig.cs:32；enabled 默认 false，故不会被误用） */
export const DEFAULT_QQ_TARGET_GROUP = 'vip'

/** 单个游玩时长阈值的目标组默认值（旧版 PromotionConfig.cs:47；仅用于"新增一条规则"的初值） */
export const DEFAULT_THRESHOLD_TARGET_GROUP = 'trustedplayer'

/** 单个游玩时长阈值的默认分钟数（旧版 PromotionConfig.cs:44；仅用于"新增一条规则"的初值） */
export const DEFAULT_THRESHOLD_MINUTES = 3000

/**
 * 模式默认值：**只有"字段缺失"才用它**（旧版 C# 的属性初值就是 "auto"：
 * TsWeb/plugin/PromotionConfig.cs:35 与 :50，Newtonsoft 反序列化缺字段时保留初值）。
 * 与"显式给了空值"是两回事：显式 null/空串/纯空白走 normalizeMode，旧版语义是 force。
 */
export const DEFAULT_MODE = 'auto'

/**
 * 下发与对账节奏（**不写进配置文件**）。
 *
 * 为什么不做成可写配置项：本件要保证 config.json 的字段与旧版一字不差
 * （旧版是进程内功能，压根没有"下发节奏"这个概念）。节奏只影响"多快把配置推到服端"，
 * 不影响权限提升的语义，因此作为模块常量 + apply 时的 options 覆盖入口，
 * 不往用户的配置文件里塞第四个字段。
 */
export const PUSH_DEFAULTS = {
  /** 配置变更后立即下发；此项为 false 只影响"变更即推"，手动推送与对账仍在 */
  pushOnChange: true,
  /** 服务器连接建立 / 服务器列表加载后补推（连接恢复补推） */
  pushOnServerConnect: true,
  /** 周期对账：无条件重推一遍（配置极小，代价可忽略；能自愈"服端配置被删改/重置"） */
  reconcileIntervalMs: 600000,
  /** 推送失败后的首次重试间隔 */
  retryIntervalMs: 60000,
  /** 失败重试的退避上限（连续失败时指数增长到此为止） */
  retryMaxIntervalMs: 600000,
}

/** 默认配置（深拷贝，调用方可安全改） */
export function defaultConfig() {
  return {
    qqBind: { enabled: false, targetGroup: DEFAULT_QQ_TARGET_GROUP, mode: DEFAULT_MODE },
    playtimeThresholds: [],
    ignoreGroups: DEFAULT_IGNORE_GROUPS.slice(),
  }
}

/** 新增一条时长规则时的默认值（旧版前端 PromotionConfigView.vue:120-126 的 addThreshold 就是这一组） */
export function defaultThreshold() {
  return { minutes: 60, targetGroup: 'default', mode: 'auto' }
}

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v)
}

/**
 * 数组去重（大小写不敏感，保留首次出现的写法）；非数组 → null（调用方决定回落）。
 * 与旧版 DedupIgnoreGroups（PromotionConfig.cs:97-110）逐条对应：
 *   trim → 剔空 → 大小写不敏感去重 → 保留首现顺序。
 * 差别只有一处：旧版入参是 List<string>（null → 空列表），本件为了区分
 * "数组"与"非数组"返回 null/数组两种形态，null 的语义由 normalizeIgnoreGroups 决定。
 */
export function dedupeGroups(list) {
  if (!Array.isArray(list)) return null
  const seen = new Set()
  const out = []
  for (const item of list) {
    const name = String(item == null ? '' : item).trim()
    if (name === '') continue
    const key = name.toLowerCase()
    if (seen.has(key)) continue
    seen.add(key)
    out.push(name)
  }
  return out
}

/**
 * 忽略组归一。
 *   数组（含空数组）→ 逐项 trim 去空去重：空数组是管理员**显式**选择"不保护任何组"，予以保留，
 *                     但会在 configWarnings 里如实提示（不静默）。
 *   字符串 → 按换行/逗号/分号/空白拆分（配置文件手写常见形态）。
 *   缺失 / null / 其它类型 / 拆分后为空 → DEFAULT_IGNORE_GROUPS（保护默认值）。
 *
 * 最后这条的由来（本件相对旧版的**一处刻意收紧**，理由写在交付报告里）：
 *   旧版 PromotionConfig.cs:124 在加载时执行 `_config.IgnoreGroups = DedupIgnoreGroups(_config.IgnoreGroups)`，
 *   而 DedupIgnoreGroups(null) 返回**空列表**——于是"配置文件里 ignoreGroups 显式为 null"
 *   会让保护名单变成空的（管理员账号可能被 auto 模式改组）。而**字段缺失**时不会：
 *   JsonConvert 保留属性初值 ["owner","superadmin"]。
 *   本件把"缺失"与"显式 null/非法类型"统一按"用保护默认值"处理：空名单只会来自
 *   管理员**显式给的空数组**（那时页面会明确警告），绝不会来自"读不懂的输入"。
 */
export function normalizeIgnoreGroups(value) {
  if (Array.isArray(value)) {
    const deduped = dedupeGroups(value)
    return deduped === null ? DEFAULT_IGNORE_GROUPS.slice() : deduped
  }
  if (typeof value === 'string') {
    const parts = value.split(/[\s,;，；]+/).filter((s) => s !== '')
    const deduped = dedupeGroups(parts)
    return deduped === null || deduped.length === 0 ? DEFAULT_IGNORE_GROUPS.slice() : deduped
  }
  return DEFAULT_IGNORE_GROUPS.slice()
}

/**
 * 模式归一：**与旧版 ParseMode 同判据**（TsWeb/plugin/PromotionConfig.cs:328-333）
 * —— 只有 'auto'（序数忽略大小写比较）是 auto，**其它任何值一律 'force'**，
 * 包含 null / undefined / 空串 / 纯空白 / 带空格包裹的 ' auto '（旧版 ParseMode 也不 trim）。
 * 服端 PromotionConfigStore.NormalizeMode（plugin/PromotionConfig.cs）与本函数同一判据。
 *
 * "字段缺失"**不归这里**：缺失由 DEFAULT_MODE（auto）承担，见
 * normalizeThreshold（下面）与 normalizeQqBind（:199）两处的显式判断。
 * 这两条曾经被合成一条"空值/缺失都算 auto"，与旧版 ParseMode 在**显式空值**上不一致
 * （旧版 ParseMode("") / ParseMode(null) 都是 Force），现已按旧版拆开。
 */
export function normalizeMode(value) {
  return String(value == null ? '' : value).toLowerCase() === 'auto' ? 'auto' : 'force'
}

/** 目标组归一：缺失 → 默认组；其它一律 String().trim()（显式空串保留，由 configWarnings 提示） */
export function normalizeTargetGroup(value, fallback = DEFAULT_QQ_TARGET_GROUP) {
  if (value === undefined || value === null) return fallback
  return String(value).trim()
}

/**
 * 分钟数归一：**非负整数**。
 * 非法（NaN/负数/Infinity）→ 0（0 会在时长晋升里被 `Minutes > 0` 滤掉，等于"这条规则无效"）；
 * 小数向下取整。严格校验（拒绝非法值）在 validateThresholds 里，供管理接口走 400。
 */
export function normalizeMinutes(value) {
  const n = Number(value)
  if (!Number.isFinite(n) || n < 0) return 0
  return Math.floor(n)
}

/** 单条时长阈值归一 */
export function normalizeThreshold(value) {
  const t = isPlainObject(value) ? value : {}
  return {
    minutes: normalizeMinutes(t.minutes),
    // 缺失时用**阈值**默认组（trustedplayer），不是 QQ 绑定的 vip
    targetGroup: normalizeTargetGroup(t.targetGroup, DEFAULT_THRESHOLD_TARGET_GROUP),
    // mode 分两种情况（旧版就是两层：字段缺失 → C# 属性初值 auto；显式给值 → ParseMode 判据）：
    //   字段缺失（undefined，JSON 里没有这个键）→ DEFAULT_MODE
    //   显式给了任何非 auto 值（含 null / 空串）→ normalizeMode → force
    mode: t.mode === undefined ? DEFAULT_MODE : normalizeMode(t.mode),
  }
}

/** 阈值数组归一：非数组 → 空数组（旧版 PromotionConfig.cs:62 的默认就是空数组） */
export function normalizeThresholds(value) {
  if (!Array.isArray(value)) return []
  return value.map(normalizeThreshold)
}

/** qqBind 块归一 */
export function normalizeQqBind(value, base = defaultConfig().qqBind) {
  const q = isPlainObject(value) ? value : {}
  return {
    enabled: q.enabled === undefined ? base.enabled === true : q.enabled === true,
    targetGroup: q.targetGroup === undefined
      ? normalizeTargetGroup(base.targetGroup)
      : normalizeTargetGroup(q.targetGroup),
    mode: q.mode === undefined ? normalizeMode(base.mode) : normalizeMode(q.mode),
  }
}

/** 深合并：对象递归，数组整体替换（配置语义：给了就替换） */
export function mergeConfig(base, patch) {
  if (!isPlainObject(patch)) return base
  const out = Array.isArray(base) ? base.slice() : { ...base }
  for (const [k, v] of Object.entries(patch)) {
    if (v === undefined) continue
    if (isPlainObject(v) && isPlainObject(out[k])) out[k] = mergeConfig(out[k], v)
    else out[k] = v
  }
  return out
}

/** 整份配置归一（读到脏配置时不抛错，也不静默改变"启用/未启用"的取向） */
export function normalizeConfig(cfg) {
  const out = mergeConfig(defaultConfig(), isPlainObject(cfg) ? cfg : {})
  return {
    qqBind: normalizeQqBind(out.qqBind),
    playtimeThresholds: normalizeThresholds(out.playtimeThresholds),
    ignoreGroups: normalizeIgnoreGroups(out.ignoreGroups),
  }
}

/**
 * 生效性检查（**不作为拒绝依据**，只用来把问题显式暴露给管理员）：
 * 返回 [{ level: 'error'|'warn', message }]。管理页与 /status 都会展示，
 * 免得出现"界面显示已启用、实际不可能生效"这种静默失效。
 */
export function configWarnings(cfg) {
  const c = normalizeConfig(cfg)
  const out = []

  if (c.qqBind.enabled && c.qqBind.targetGroup === '') {
    out.push({
      level: 'error',
      message: '「QQ 绑定提升」已启用但目标用户组为空：服端会以 400 拒绝该次下发，这条提升不会生效',
    })
  }
  if (c.qqBind.enabled && c.ignoreGroups.length === 0) {
    out.push({
      level: 'warn',
      message: '忽略组为空：没有任何保护名单，若管理员账号不在目标组父链下方，auto 模式会把管理员改组',
    })
  }

  // 时长规则里"分钟数为 0"或"目标组为空"的条目会被服端算法直接滤掉（Minutes > 0 && TargetGroup 非空），
  // 这是旧版既有行为；但界面上留着这样一条规则会让人以为它生效了，所以显式提示。
  const dead = c.playtimeThresholds.filter((t) => t.minutes <= 0 || t.targetGroup === '')
  if (dead.length > 0) {
    out.push({
      level: 'warn',
      message: `有 ${dead.length} 条游玩时长规则不会生效：分钟数必须大于 0、目标用户组不能为空（服端会跳过这类规则）`,
    })
  }

  if (c.playtimeThresholds.length > 0 && c.ignoreGroups.length === 0) {
    out.push({
      level: 'warn',
      message: '忽略组为空：时长达标时没有任何保护名单，管理员账号也可能被改组',
    })
  }
  return out
}

/**
 * 下发给游戏服的载荷。**3 个字段永远带齐**（含数组为空时也显式发 `[]`）。
 *
 * 为什么必须带齐：服端的取向是"参数缺失 → 沿用服端当前值"（PromotionEndpoints.Parse* 的注释），
 * 那是为了防"老宿主发残缺载荷 → 服端配置被清空"。但**本件作为权威来源**必须永远发全，
 * 否则"管理员把规则删空"这种意图就传不到服端了。
 */
export function toGamePayload(cfg, version) {
  const c = normalizeConfig(cfg)
  return {
    version: Math.max(1, Math.floor(Number(version) || 1)),
    qqBind: { ...c.qqBind },
    playtimeThresholds: c.playtimeThresholds.map((t) => ({ ...t })),
    ignoreGroups: c.ignoreGroups.slice(),
  }
}

/**
 * 读配置：
 *   不存在 → 默认值（未启用，安全方向）
 *   非法 JSON / 结构不符 → **也返回默认值**，同时把错误如实带回（error 字段）
 *
 * 为什么不像 qq-bind 那样抛错：那是"配置损坏就别启动"的取向，本件选择
 * "配置损坏 = 按默认运行 + 明确报错"——原因有二：① 默认是安全方向（不会再自动改组）；
 * ② 插件装载失败会让"界面里连配置都看不到"，管理员没有修复入口。
 * 错误经 GET /api/promotion/config 与 /status 的 configError 回显。
 */
export async function loadConfig(file) {
  let raw
  try {
    raw = await readFile(file, 'utf8')
  } catch (err) {
    if (err.code === 'ENOENT') return { config: defaultConfig(), existed: false, error: '' }
    return {
      config: defaultConfig(),
      existed: true,
      error: `配置文件读取失败（${file}）：${err.message}；已按默认配置（未启用）运行`,
    }
  }
  let parsed
  try {
    parsed = JSON.parse(raw)
  } catch (err) {
    return {
      config: defaultConfig(),
      existed: true,
      error: `配置文件不是合法 JSON（${file}）：${err.message}；已按默认配置（未启用）运行，请修复后重新保存`,
    }
  }
  if (!isPlainObject(parsed)) {
    return {
      config: defaultConfig(),
      existed: true,
      error: `配置文件顶层不是对象（${file}）；已按默认配置（未启用）运行`,
    }
  }
  return { config: normalizeConfig(parsed), existed: true, error: '' }
}

/** 原子落盘（.tmp + rename，保留 .bak）：半个文件不会被下次读取当成配置 */
export async function saveConfig(file, cfg) {
  const payload = JSON.stringify(normalizeConfig(cfg), null, 2)
  await mkdir(path.dirname(file), { recursive: true })
  const tmp = `${file}.tmp`
  await writeFile(tmp, payload, 'utf8')
  try {
    await copyFile(file, `${file}.bak`)
  } catch (err) {
    if (err.code !== 'ENOENT') throw err
  }
  await rename(tmp, file)
  return file
}

// ════════════════════════════════════════════
//  严格校验（管理接口用：非法值 → 400，绝不写进配置）
// ════════════════════════════════════════════

function badRequest(message, extra = {}) {
  const err = new Error(message)
  err.status = 400
  Object.assign(err, extra)
  return err
}

/** 目标组：必须是非空字符串（空目标组会让"已启用"永远无法生效，属于非法输入） */
function requireGroupName(value, label) {
  if (typeof value !== 'string' || value.trim() === '') {
    throw badRequest(`${label} 必须是字符串且不能为空（收到 ${JSON.stringify(value)}）`)
  }
  return value.trim()
}

/** 模式：字符串即合法（非 auto 归一到 force，与旧版 ParseMode 一致），非字符串或空串拒绝 */
function requireMode(value, label) {
  if (typeof value !== 'string') {
    throw badRequest(`${label} 必须是字符串（auto 或 force；收到 ${JSON.stringify(value)}）`)
  }
  const raw = value.trim()
  if (raw === '') throw badRequest(`${label} 不能为空`)
  // 严格校验层不接受空值（上面 400），所以这里传给 normalizeMode 的一定是非空串
  return normalizeMode(raw)
}

/**
 * 时长阈值数组的严格校验：**非法值一律 400**，不做静默回落。
 * 这是"数据错误要看得见"的取向：minutes 写成 "abc" 或 -5 时，
 * 管理员应当看到 400 与明确文案，而不是"保存成功但那条规则永远不生效"。
 */
export function validateThresholds(value) {
  if (!Array.isArray(value)) {
    throw badRequest(`playtimeThresholds 必须是数组（收到 ${JSON.stringify(value)}）`)
  }
  return value.map((item, i) => {
    if (!isPlainObject(item)) throw badRequest(`playtimeThresholds[${i}] 必须是对象`)
    const minutes = Number(item.minutes)
    if (!Number.isFinite(minutes) || !Number.isInteger(minutes) || minutes < 0) {
      throw badRequest(`playtimeThresholds[${i}].minutes 必须是非负整数（收到 ${JSON.stringify(item.minutes)}）`)
    }
    return {
      minutes,
      targetGroup: requireGroupName(item.targetGroup, `playtimeThresholds[${i}].targetGroup`),
      mode: requireMode(item.mode, `playtimeThresholds[${i}].mode`),
    }
  })
}

/** 忽略组数组的严格校验（元素必须是字符串；随后按旧版口径去重） */
export function validateIgnoreGroups(value) {
  if (!Array.isArray(value)) {
    throw badRequest(`ignoreGroups 必须是数组（收到 ${JSON.stringify(value)}）`)
  }
  if (!value.every((x) => typeof x === 'string')) {
    throw badRequest('ignoreGroups 的每一项都必须是字符串')
  }
  return normalizeIgnoreGroups(value)
}

/** qqBind 块的严格校验 */
export function validateQqBind(value) {
  if (!isPlainObject(value)) {
    throw badRequest(`qqBind 必须是对象（收到 ${JSON.stringify(value)}）`)
  }
  if (typeof value.enabled !== 'boolean') {
    throw badRequest(`qqBind.enabled 必须是布尔值（收到 ${JSON.stringify(value.enabled)}）`)
  }
  return {
    enabled: value.enabled,
    targetGroup: requireGroupName(value.targetGroup, 'qqBind.targetGroup'),
    mode: requireMode(value.mode, 'qqBind.mode'),
  }
}

/**
 * 整份配置的严格校验（POST /api/promotion/config 用 { config } 整份替换时走这里）。
 * 与 normalizeConfig 的区别：**不静默兜底**，任何非法值都抛 400。
 */
export function validateConfig(cfg) {
  if (!isPlainObject(cfg)) throw badRequest('config 必须是对象')
  return {
    qqBind: validateQqBind(cfg.qqBind),
    playtimeThresholds: validateThresholds(cfg.playtimeThresholds === undefined ? [] : cfg.playtimeThresholds),
    ignoreGroups: validateIgnoreGroups(cfg.ignoreGroups === undefined ? DEFAULT_IGNORE_GROUPS : cfg.ignoreGroups),
  }
}

/**
 * 管理接口可写的路径白名单（值是校验器）。
 * 只允许按点号路径改已知字段；非法值抛 400（不把非法值写进配置）。
 * 说明：push.* 不在此列（节奏不是配置字段，见 PUSH_DEFAULTS 的注释）。
 */
export const EDITABLE_PATHS = {
  'qqBind.enabled': (v) => typeof v === 'boolean',
  'qqBind.targetGroup': (v) => typeof v === 'string' && v.trim() !== '',
  'qqBind.mode': (v) => typeof v === 'string' && v.trim() !== '',
  playtimeThresholds: (v) => Array.isArray(v),
  ignoreGroups: (v) => Array.isArray(v) && v.every((x) => typeof x === 'string'),
}

/** 按点号路径写值（仅白名单）；写前按该路径的严格校验器归一，非法即 400 */
export function setByPath(cfg, dottedPath, value) {
  const key = String(dottedPath == null ? '' : dottedPath).trim()
  if (!key) throw badRequest('缺少参数: path')
  const validator = EDITABLE_PATHS[key]
  if (!validator) {
    throw badRequest(`不可写的配置项：${key}（可写项：${Object.keys(EDITABLE_PATHS).join('、')}）`)
  }
  if (!validator(value)) throw badRequest(`${key} 的值类型不合法（收到 ${JSON.stringify(value)}）`)

  // 按路径做"严格校验 + 归一"：与 validateConfig 的对应分支同一套口径
  let normalized
  if (key === 'qqBind.enabled') normalized = value === true
  else if (key === 'qqBind.targetGroup') normalized = requireGroupName(value, 'qqBind.targetGroup')
  else if (key === 'qqBind.mode') normalized = requireMode(value, 'qqBind.mode')
  else if (key === 'playtimeThresholds') normalized = validateThresholds(value)
  else normalized = validateIgnoreGroups(value)

  const parts = key.split('.')
  let node = cfg
  for (const part of parts.slice(0, -1)) {
    if (!isPlainObject(node[part])) node[part] = {}
    node = node[part]
  }
  node[parts[parts.length - 1]] = normalized
  return cfg
}
