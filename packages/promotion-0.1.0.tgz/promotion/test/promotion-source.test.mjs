/**
 * 源码层断言：本插件**只读** player_daily_stat、不碰 hourly_online_snapshot
 *
 * 这是"双倍计时长防护"的**源码侧**证据（字节侧证据见 test/dll-content.test.mjs）。
 *
 * 背景（本次任务的硬约束）：player_daily_stat 的每分钟 +1 已经由 online-stats 插件的 DLL
 * 负责（plugins/online-stats/plugin/OnlineStatsData.cs:130-153，同样的 3600 tick 节拍、
 * 同样的 `daily_min = daily_min + 1`）。本插件的时长晋升只**读**这张表的 SUM(daily_min)；
 * 若它也累加一次，玩家的累计时长会翻倍、所有时长阈值提前一半触发。
 *
 * 做法：把本插件**所有源码与脚本**（.cs / .js / .mjs / .csproj，排除 bin、obj 与 test/ 自身）
 * 拼起来做逐行扫描，断言：
 *   1. 出现 player_daily_stat 的每一行都在 SELECT 语境里（SELECT / FROM / SUM / COALESCE / WHERE）
 *   2. 全文不得出现 INSERT / UPDATE / DELETE / REPLACE / CREATE TABLE（对 player_daily_stat 的写操作）
 *   3. 全文不得出现 daily_min + 1 / daily_min+1（自增片段）
 *   4. 全文不得出现 hourly_online_snapshot（那是 online-stats 的另一项职责）
 *   5. 不得出现 UpdatePlayerDailyMin / EnsureHourlyRecord 这类"把 online-stats 的活儿搬过来"的方法名
 *
 * 为什么用逐行扫描而不是全文 grep：全文 grep 只能证明"没有那个串"，
 * 而"出现 player_daily_stat 的行必须是 SELECT 语境"这条才能挡住
 * "把写入语句换个写法（例如 upsert 子句里出现表名）"的新缺陷。
 *
 * 运行：node test/promotion-source.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile, readdir, stat } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginRoot = path.resolve(here, '..')

/** 排除的目录：构建产物与测试自身（测试文件里必然出现这些串，那是断言文本，不是实现） */
const SKIP_DIRS = new Set(['bin', 'obj', 'node_modules', 'test', '.git'])
const EXTS = new Set(['.cs', '.js', '.mjs', '.csproj', '.json'])

/** 递归收集本插件的源码文件 */
async function collect(dir) {
  const out = []
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.')) continue
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue
      out.push(...await collect(full))
      continue
    }
    if (!EXTS.has(path.extname(entry.name).toLowerCase())) continue
    out.push(full)
  }
  return out
}

let cachedTexts = null

/** 读出所有源码文件的行（带 文件:行号，便于报告里引用） */
async function sources() {
  if (cachedTexts) return cachedTexts
  const files = await collect(pluginRoot)
  assert.ok(files.length >= 8, `收集到的源码文件太少（${files.length}），扫描范围可疑：${files.join(', ')}`)
  const texts = []
  for (const f of files) {
    const content = await readFile(f, 'utf8')
    const rel = path.relative(pluginRoot, f).replace(/\\/g, '/')
    content.split(/\r?\n/).forEach((line, i) => texts.push({ file: rel, line: i + 1, text: line }))
  }
  cachedTexts = texts
  return texts
}

/** 去掉行内注释（朴素实现：够用，且注释里出现表名不算"实现里有写操作"） */
function stripComment(text) {
  const t = text.trim()
  if (t.startsWith('//') || t.startsWith('*') || t.startsWith('/*') || t.startsWith('///')) return ''
  const i = text.indexOf('//')
  return i >= 0 ? text.slice(0, i) : text
}

test('扫描范围健全：本插件的 C# / JS / 配置源文件都被纳入（不是扫了个空集）', async () => {
  const rows = await sources()
  const files = new Set(rows.map((r) => r.file))
  for (const must of [
    'plugin/Promotion.cs',
    'plugin/PromotionConfig.cs',
    'plugin/PromotionThresholds.cs',
    'plugin/PromotionEndpoints.cs',
    'plugin/PromotionBindings.cs',
    'plugin/PromotionPlugin.cs',
    'config.js',
    'index.js',
    'gameOps.js',
    'seed.js',
    'audit.js',
    'client/promotion.js',
    'package.json',
  ]) {
    assert.ok(files.has(must), `扫描范围缺少 ${must}（源码扫描必须覆盖全部实现文件）`)
  }
})

test('★★ player_daily_stat 的每一次出现都在 SELECT 语境里（只读） ★★', async () => {
  const rows = await sources()
  const hits = rows.filter((r) => stripComment(r.text).includes('player_daily_stat'))
  assert.ok(hits.length >= 1, '全文找不到 player_daily_stat —— 时长晋升的读取语句缺失，本断言会变成空断言')

  /**
   * "必须在 SELECT 语境里"这条**只对 C# 实现文件**成立：
   * 真正可能写出 INSERT/UPDATE 的地方就是会下发到游戏服的那个 DLL（.cs → Promotion.dll）。
   * 非 C# 文件里出现这个表名只可能是界面文案/注释（例如客户端"时长数据来自 online-stats
   * 记录在 player_daily_stat 的累计分钟数"），要求它也含 SELECT 是小了 ——
   * 对那类文件，写入防护由下面那条"全文不得有写入语句/自增片段"覆盖。
   */
  const csHits = hits.filter((h) => h.file.endsWith('.cs'))
  assert.ok(csHits.length >= 1, 'C# 实现里必须出现 player_daily_stat（时长晋升的读取语句）')

  for (const h of csHits) {
    const code = stripComment(h.text)

    // ① 任何写入动词都不许出现（这一条最硬）
    assert.doesNotMatch(
      code, /\b(INSERT|UPDATE|DELETE|REPLACE|CREATE|DROP)\b/i,
      `${h.file}:${h.line} 对 player_daily_stat 出现了写操作：${code.trim()}`,
    )

    // ② 如果这一行是 SQL（含 SQL 关键字），它必须是读语句
    //    只把"含 SQL 关键字"的行当 SQL 看：`只读 player_daily_stat，不累加时长` 这类
    //    日志/注释文案里出现表名是正常的，不该被要求带 SELECT。
    const isSql = /\b(SELECT|INSERT|UPDATE|DELETE|REPLACE|CREATE|DROP|FROM|INTO|TABLE|SET|VALUES|WHERE|SUM|COALESCE)\b/i.test(code)
    if (isSql) {
      assert.match(
        code, /\bSELECT\b|\bSUM\b|\bCOALESCE\b|\bFROM\b|\bWHERE\b/,
        `${h.file}:${h.line} 出现了 player_daily_stat 的 SQL 但不是读语句：${code.trim()}\n`
        + '  本插件对这张表**只允许 SELECT**（写入由 online-stats 负责，重复写会造成双倍计时长）',
      )
    }
  }

  // 非 C# 文件里出现它只允许是"说明性文本"（不得带任何 SQL 动词）
  for (const h of hits.filter((x) => !x.file.endsWith('.cs'))) {
    assert.doesNotMatch(
      stripComment(h.text), /\b(INSERT|UPDATE|DELETE|REPLACE|CREATE|DROP)\b/i,
      `${h.file}:${h.line} 在非 C# 文件里出现了 SQL 动词：${stripComment(h.text).trim()}`,
    )
  }

  // 这条是"读取语句具体长什么样"的正面锚点：与旧版 OnlineData.cs:161-167 一字一致
  const sumLine = csHits.find((h) => h.text.includes('COALESCE(SUM(daily_min)'))
  assert.ok(sumLine, '必须存在 SELECT COALESCE(SUM(daily_min), 0) ... 的读取语句（旧版 OnlineData.cs:163）')
  assert.match(sumLine.text, /SELECT COALESCE\(SUM\(daily_min\), 0\) AS total FROM player_daily_stat WHERE uid = @0/)
})

test('★★ 全文没有任何"给时长表/快照表"的写入语句或自增片段 ★★', async () => {
  const rows = await sources()
  const forbidden = [
    [/\bINSERT\s+INTO\s+player_daily_stat\b/i, 'INSERT INTO player_daily_stat'],
    [/\bUPDATE\s+player_daily_stat\b/i, 'UPDATE player_daily_stat'],
    [/\bDELETE\s+FROM\s+player_daily_stat\b/i, 'DELETE FROM player_daily_stat'],
    [/daily_min\s*\+\s*1/, 'daily_min + 1（时长自增片段）'],
    [/daily_min\s*=\s*daily_min\s*\+/i, 'daily_min = daily_min + ...（时长自增）'],
    [/CREATE\s+TABLE[^;]*player_daily_stat/i, '为 player_daily_stat 建表'],
    [/hourly_online_snapshot/i, 'hourly_online_snapshot（online-stats 的另一项职责）'],
    [/UpdatePlayerDailyMin/, 'UpdatePlayerDailyMin（online-stats 的方法，不该被搬进本件）'],
    [/EnsureHourlyRecord/, 'EnsureHourlyRecord（online-stats 的方法，不该被搬进本件）'],
    [/SnapshotHourlyOnline/, 'SnapshotHourlyOnline（online-stats 的方法，不该被搬进本件）'],
  ]
  const violations = []
  for (const r of rows) {
    const code = stripComment(r.text)
    if (code.trim() === '') continue
    for (const [re, label] of forbidden) {
      if (re.test(code)) violations.push(`${r.file}:${r.line} [${label}] ${code.trim()}`)
    }
  }
  assert.deepEqual(
    violations, [],
    '本插件不得写入游玩时长，也不得做整点在线快照（那都是 online-stats 插件的职责）：\n'
    + '  plugins/online-stats/plugin/OnlineStatsData.cs:130-153 已经在做 player_daily_stat 的每分钟 +1，\n'
    + '  本插件再写一次就是**双倍计时长**，所有时长阈值会提前一半触发。\n'
    + violations.join('\n'),
  )
})

test('只读语义在代码注释里被明确写出来（防止后来者"顺手补上累加"）', async () => {
  const rows = await sources()
  const text = rows.map((r) => r.text).join('\n')
  assert.match(text, /只\*\*读\*\*|只读/, '源码里必须有"只读 player_daily_stat"的说明')
  assert.match(text, /双倍计时长|翻倍/, '源码里必须写明"重复写入会造成双倍计时长"这条约束')
})

test('C# 侧只有一个 SQL 表名常量出现（player_daily_stat），没有别的统计表', async () => {
  const rows = await sources()
  const tables = new Set()
  for (const r of rows) {
    if (!r.file.startsWith('plugin/')) continue
    for (const m of stripComment(r.text).matchAll(/\b(?:FROM|INTO|UPDATE|TABLE)\s+([A-Za-z_][A-Za-z0-9_]*)/gi)) {
      tables.add(m[1].toLowerCase())
    }
  }
  assert.deepEqual([...tables].sort(), ['player_daily_stat'],
    `C# 侧访问的表只允许 player_daily_stat，实际：${[...tables].join(', ')}`)
})

test('C# 侧计时节拍里只挂 GameUpdate 检查晋升，不做建表/累计', async () => {
  const src = await readFile(path.join(pluginRoot, 'plugin', 'PromotionThresholds.cs'), 'utf8')
  // 节拍里调用的东西只有 CheckAutoPromotion
  const branch = src.slice(src.indexOf('private static void OnGameUpdate'), src.indexOf('internal static void CheckAutoPromotion'))
  assert.match(branch, /_tickCounter\s*%/, '计时节拍必须存在')
  assert.match(branch, /CheckAutoPromotion\(\)/, '节拍里必须调用 CheckAutoPromotion')
  assert.doesNotMatch(branch, /UpdatePlayerDailyMin|EnsureHourlyRecord|Query\(/, '节拍里不得出现建表/写库调用')
  assert.doesNotMatch(src, /CreateTables/, '本件不建表（player_daily_stat 由 online-stats 建）')
})
