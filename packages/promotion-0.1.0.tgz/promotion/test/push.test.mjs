/**
 * 下发链路测试（真实 apply + 假宿主 ctx + 假游戏服半）
 *
 * 覆盖任务要求的下发链路四件事：
 *   1. 配置变更 → **立即下发**（POST /api/promotion/config 内同步完成，不是等对账周期）
 *   2. 下发失败 → 逐服如实回显（含"没装 DLL"的 501 语义），并按退避**自动重试**
 *   3. 连接恢复 / 服务器列表加载 → **补推**（只打还没确认最新配置的服）
 *   4. 服端实际生效状态的**探测**（probe）：与宿主配置逐字段比对，不一致必须报出来
 *
 * 另外锁住这些"不许悄悄退化"的行为：
 *   - 启动即对账一次，且载荷里 ignoreGroups 带的是保护默认值（不是空数组）
 *   - 载荷带齐三块配置（qqBind / playtimeThresholds / ignoreGroups），空数组也显式发 []
 *   - 配置变更写审计 promotion.config.set（旧版语义 config.promotion.set 的对应物）
 *   - 整份替换（{config}）走严格校验，非法值 400 且不落盘
 *   - 手动重推：不存在的服务器 → 404（不静默当成 0 台）；超上限 → 400
 *   - 「目标权限组」下拉的数据源 GET /api/promotion/groups 走 base 的组端点，全失败要给出原因
 *   - dispose 停掉对账与重试定时器（卸载后不再有后台请求）
 *
 * 注意：本测试**不启动任何服务进程**，也不引入 express/cordis（见 test/support/fake-host.mjs 的说明）。
 * 运行：node test/push.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, readFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { apply } from '../index.js'
import { defaultConfig } from '../config.js'
import { ACTIONS } from '../audit.js'
import { makeFakeHost, makeGameHalf, waitFor } from './support/fake-host.mjs'

const SERVERS = [
  { raw: { id: 's1', name: '一服', host: '127.0.0.1', port: 7777, token: 't1', enabled: true } },
  { raw: { id: 's2', name: '二服', host: '127.0.0.1', port: 7778, token: 't2', enabled: true } },
]

let dir
let seq = 0

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), 'promotion-push-'))
})

after(async () => {
  await rm(dir, { recursive: true, force: true })
})

/**
 * 起一个宿主并 await apply。
 * push 选项用来把"对账/重试节奏"调到毫秒级（配置里没有节奏字段了，见 config.js:PUSH_DEFAULTS），
 * 并默认带上 services.qqBind（模拟 qq-bind 已安装，除非用例显式传 qqBind:false）。
 */
async function boot({ servers = SERVERS, push, qqBind = true } = {}) {
  seq += 1
  const dataDir = path.join(dir, `case-${seq}`)
  const gameHalf = makeGameHalf({ serverIds: servers.map((s) => s.raw.id) })
  const services = qqBind === false ? {} : { qqBind: {} }
  const host = makeFakeHost({ dataDir, servers, services, fetchFor: gameHalf.fetchFor })
  const dispose = await apply(host.ctx, { push })
  return { dataDir, host, gameHalf, dispose }
}

/**
 * 插件的数据目录与配置文件路径：index.js 用 ctx.paths.dataOf('promotion')，
 * 而假宿主的 dataOf(n) = <dataDir>/n，所以配置文件在 <dataDir>/promotion/config.json。
 */
function pluginDataDir(dataDir) {
  return path.join(dataDir, 'promotion')
}
function pluginConfigFile(dataDir) {
  return path.join(pluginDataDir(dataDir), 'config.json')
}
function pluginAuditFile(dataDir) {
  return path.join(pluginDataDir(dataDir), 'audit.jsonl')
}

async function readAudit(file) {
  try {
    const raw = await readFile(file, 'utf8')
    return raw.split('\n').filter((l) => l.trim() !== '').map((l) => JSON.parse(l))
  } catch (err) {
    if (err.code === 'ENOENT') return []
    return []
  }
}

/** 让所有服都确认本次启动下发（异步流程，需要等一下） */
async function waitAllAcked(host, count) {
  return waitFor(() => host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length >= count, {
    label: `启动下发打到 ${count} 台服`,
  })
}

// ═══════════════ 1. 挂载与启动对账 ═══════════════

test('apply：注册 5 个管理端点 + 订阅连接恢复事件 + 启动即对账下发', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    for (const p of ['/api/promotion/config', '/api/promotion/status', '/api/promotion/push', '/api/promotion/audit', '/api/promotion/groups']) {
      assert.ok(host.hasRoute('get', p) || host.hasRoute('post', p), `应注册端点 ${p}`)
    }
    assert.ok(host.hasRoute('get', '/api/promotion/config'))
    assert.ok(host.hasRoute('post', '/api/promotion/config'))
    assert.ok(host.hasRoute('get', '/api/promotion/status'))
    assert.ok(host.hasRoute('post', '/api/promotion/push'))
    assert.ok(host.hasRoute('get', '/api/promotion/audit'))
    assert.ok(host.hasRoute('get', '/api/promotion/groups'))

    // 连接恢复补推的两个事件必须订阅（卸载时由 cordis 回收）
    assert.equal(host.fire('push/connected'), true)
    assert.equal(host.fire('servers/loaded'), true)

    await waitAllAcked(host, 2)
    const first = host.calls.find((c) => c.pathname === '/data/promotion/snapshot')
    // 关键断言：载荷必须带保护默认值，而不是空数组（这就是修掉的那处单边缺失）
    assert.deepEqual(JSON.parse(first.params.ignoreGroups), ['owner', 'superadmin'])
    assert.ok(Number(first.params.version) >= 1, 'version 必须是正整数')

    // 三块配置都必须带齐（qqBind / playtimeThresholds / ignoreGroups）
    const qq = JSON.parse(first.params.qqBind)
    assert.deepEqual(qq, { enabled: false, targetGroup: 'vip', mode: 'auto' }, '默认未启用，qqBind 三字段齐全')
    assert.deepEqual(JSON.parse(first.params.playtimeThresholds), [], '默认没有时长规则（旧版默认就是空数组）')

    // 假服端确实收下并生效了
    assert.equal(gameHalf.applied.get('s1').qqBind.enabled, false)
    assert.deepEqual(gameHalf.applied.get('s1').ignoreGroups, ['owner', 'superadmin'])
  } finally {
    dispose()
  }
})

test('启动对账的载荷就是"当前配置"，不是硬编码默认值（配置文件里的值要被推下去）', async () => {
  const { dataDir, host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    const res = await host.call('post', '/api/promotion/config', {
      body: {
        config: {
          qqBind: { enabled: true, targetGroup: 'gold', mode: 'force' },
          playtimeThresholds: [{ minutes: 3000, targetGroup: 'trustedplayer', mode: 'auto' }],
          ignoreGroups: ['owner', 'helper'],
        },
      },
    })
    assert.equal(res.status, 200)

    const last = [...host.calls].reverse().find((c) => c.pathname === '/data/promotion/snapshot')
    assert.deepEqual(JSON.parse(last.params.qqBind), { enabled: true, targetGroup: 'gold', mode: 'force' })
    assert.deepEqual(JSON.parse(last.params.playtimeThresholds), [{ minutes: 3000, targetGroup: 'trustedplayer', mode: 'auto' }])
    assert.deepEqual(JSON.parse(last.params.ignoreGroups), ['owner', 'helper'])

    // 也真的落到服端了
    assert.deepEqual(gameHalf.applied.get('s1').playtimeThresholds, [{ minutes: 3000, targetGroup: 'trustedplayer', mode: 'auto' }])

    // 落盘：字段与旧版一致（顶层三个）
    const written = JSON.parse(await readFile(pluginConfigFile(dataDir), 'utf8'))
    assert.deepEqual(Object.keys(written).sort(), ['ignoreGroups', 'playtimeThresholds', 'qqBind'])
  } finally {
    dispose()
  }
})

// ═══════════════ 2. 变更即下发 ═══════════════

test('配置变更**立即下发**并逐服回显结果（不等对账周期）', async () => {
  const { host, gameHalf, dispose } = await boot({ push: { reconcileIntervalMs: 0 } }) // 关掉对账，确保是"变更本身"触发的
  try {
    await waitAllAcked(host, 2)
    const before = host.calls.length

    const res = await host.call('post', '/api/promotion/config', {
      body: { updates: { 'qqBind.enabled': true, 'qqBind.targetGroup': 'vip' } },
    })
    assert.equal(res.status, 200)
    assert.equal(res.data.ok, true)
    assert.equal(res.data.push.total, 2, '两台启用服都要推')
    assert.equal(res.data.push.okCount, 2)
    assert.deepEqual(res.data.changed, ['qqBind'], 'changed 应指出变了的顶层字段')
    assert.ok(host.calls.length > before, '保存请求内必须已经发生下发')

    assert.equal(gameHalf.applied.get('s2').qqBind.enabled, true)
  } finally {
    dispose()
  }
})

test('局部写入（updates）与单字段（path/value）两种形态都可用，且写的是 qqBind 下的路径', async () => {
  const { host, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    const a = await host.call('post', '/api/promotion/config', { body: { updates: { 'qqBind.mode': 'force' } } })
    assert.equal(a.status, 200)
    assert.equal(a.data.config.qqBind.mode, 'force')

    const b = await host.call('post', '/api/promotion/config', { body: { path: 'ignoreGroups', value: ['owner'] } })
    assert.equal(b.status, 200)
    assert.deepEqual(b.data.config.ignoreGroups, ['owner'])

    // 老扁平路径已不存在 → 400（本件的字段都在 qqBind 下）
    const c = await host.call('post', '/api/promotion/config', { body: { path: 'targetGroup', value: 'vip' } })
    assert.equal(c.status, 400)
    assert.match(c.data.error, /不可写的配置项/)
  } finally {
    dispose()
  }
})

test('整份替换走严格校验：非法值 400 且**不落盘**（配置文件保持原样）', async () => {
  const { dataDir, host, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    const good = await host.call('post', '/api/promotion/config', {
      body: { config: { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: ['owner'] } },
    })
    assert.equal(good.status, 200)
    const after = await readFile(pluginConfigFile(dataDir), 'utf8')

    const cases = [
      { qqBind: { enabled: true, targetGroup: '', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: ['owner'] },
      { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [{ minutes: -1, targetGroup: 'vip', mode: 'auto' }], ignoreGroups: ['owner'] },
      { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: 'owner' },
    ]
    for (const config of cases) {
      const r = await host.call('post', '/api/promotion/config', { body: { config } })
      assert.equal(r.status, 400, `非法配置必须 400：${JSON.stringify(config)}`)
    }
    assert.equal(await readFile(pluginConfigFile(dataDir), 'utf8'), after, '被拒绝的请求不得改动配置文件')

    // config 与 updates 同时给出 → 400（避免语义含糊）
    const both = await host.call('post', '/api/promotion/config', { body: { config: {}, updates: {} } })
    assert.equal(both.status, 400)
  } finally {
    dispose()
  }
})

test('配置变更写审计 promotion.config.set（对齐旧版 config.promotion.set 的语义）', async () => {
  const { dataDir, host, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    await host.call('post', '/api/promotion/config', {
      body: { config: { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [{ minutes: 60, targetGroup: 'vip', mode: 'auto' }], ignoreGroups: ['owner'] } },
    })
    const rows = await readAudit(pluginAuditFile(dataDir))
    const row = rows.find((r) => r.action === 'promotion.config.set')
    assert.ok(row, `审计动作名必须是 ${ACTIONS.configSet}`)
    assert.equal(row.action, 'promotion.config.set')
    assert.equal(row.actor, 'admin')
    assert.equal(row.qqBindEnabled, true)
    assert.equal(row.thresholdCount, 1)
    assert.deepEqual(row.ignoreGroups, ['owner'])

    // 审计接口能读到它
    const api = await host.call('get', '/api/promotion/audit')
    assert.equal(api.status, 200)
    assert.ok(api.data.rows.some((r) => r.action === 'promotion.config.set'))
  } finally {
    dispose()
  }
})

// ═══════════════ 3. 失败回显与重试 ═══════════════

test('服务器半缺失（404）→ 501 + serverHalfMissing，并指出要装的 DLL 名', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    gameHalf.setBehavior('s1', 'missing')
    const res = await host.call('post', '/api/promotion/config', { body: { updates: { 'qqBind.enabled': true } } })
    assert.equal(res.status, 200, '整体仍返回 200（逐服结果在 push 里）')
    assert.equal(res.data.push.ok, false)

    const s1 = res.data.push.servers.find((s) => s.id === 's1')
    assert.equal(s1.ok, false)
    assert.equal(s1.status, 501)
    assert.equal(s1.serverHalfMissing, true)
    assert.match(s1.error, /Promotion\.dll/, '错误文案必须点名要装的 DLL')

    const s2 = res.data.push.servers.find((s) => s.id === 's2')
    assert.equal(s2.ok, true, '另一台服不受影响')
  } finally {
    dispose()
  }
})

test('token 权限不足（403）→ 502；服端 400 → 400 并回传服端原文', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    gameHalf.setBehavior('s1', 'forbidden')
    gameHalf.setBehavior('s2', 'badRequest')
    const res = await host.call('post', '/api/promotion/push', { body: {} })
    const s1 = res.data.push.servers.find((s) => s.id === 's1')
    const s2 = res.data.push.servers.find((s) => s.id === 's2')
    assert.equal(s1.status, 502)
    assert.match(s1.error, /权限不足/)
    assert.equal(s2.status, 400)
    assert.match(s2.error, /不能为空/, '服端的原文必须回传，管理员才知道要改哪里')
    assert.match(s2.error, /targetGroup/, '要能看出是哪个字段被拒')
  } finally {
    dispose()
  }
})

test('服端落盘失败（saveError）→ 该服算失败，原因如实回显（不假装成功）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    gameHalf.setBehavior('s1', 'saveFail')
    const res = await host.call('post', '/api/promotion/push', { body: {} })
    const s1 = res.data.push.servers.find((s) => s.id === 's1')
    assert.equal(s1.ok, false)
    assert.match(s1.error, /落盘失败/)
    assert.match(s1.error, /磁盘只读/)
  } finally {
    dispose()
  }
})

test('服端已有更新版本（stale）→ 该服标为未生效，并给出可读原因', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    gameHalf.setBehavior('s1', 'stale')
    const res = await host.call('post', '/api/promotion/push', { body: {} })
    const s1 = res.data.push.servers.find((s) => s.id === 's1')
    assert.equal(s1.ok, false)
    assert.equal(s1.stale, true)
    assert.match(s1.error, /更新版本/)
  } finally {
    dispose()
  }
})

test('下发失败会按退避自动重试，直到该服确认（且重试带的是**新版本号**）', async () => {
  const { host, gameHalf, dispose } = await boot({ push: { retryIntervalMs: 20, retryMaxIntervalMs: 40, reconcileIntervalMs: 0 } })
  try {
    await waitAllAcked(host, 2)
    gameHalf.setBehavior('s1', 'missing')

    const res = await host.call('post', '/api/promotion/config', { body: { updates: { 'qqBind.enabled': true } } })
    assert.equal(res.data.push.ok, false)
    const firstSentVersion = res.data.push.servers.find((s) => s.id === 's1').sentVersion

    // 服端恢复：重试应当把它补上
    gameHalf.setBehavior('s1', 'ok')
    await waitFor(() => gameHalf.applied.get('s1') && gameHalf.applied.get('s1').qqBind.enabled === true, {
      timeoutMs: 3000, label: '重试把一服补上',
    })
    const retryCall = [...host.calls].reverse().find((c) => c.pathname === '/data/promotion/snapshot' && c.serverId === 's1')
    assert.ok(Number(retryCall.params.version) > Number(firstSentVersion), '重试必须带更新的版本号（否则会被服端当陈旧载荷拒掉）')
  } finally {
    dispose()
  }
})

// ═══════════════ 4. 连接恢复补推 ═══════════════

test('连接恢复/服务器列表加载 → 补推**只打未确认的服**', async () => {
  const { host, dispose } = await boot({ push: { reconcileIntervalMs: 0 } })
  try {
    await waitAllAcked(host, 2)
    // 先把配置改一次，让两台都确认
    await host.call('post', '/api/promotion/config', { body: { updates: { 'qqBind.mode': 'force' } } })
    const before = host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length

    // 都确认了 → 补推不该有任何请求
    assert.equal(host.fire('servers/loaded'), true)
    await new Promise((r) => setTimeout(r, 30))
    assert.equal(host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length, before,
      '全部已确认时补推不该产生流量')
  } finally {
    dispose()
  }
})

test('pushOnServerConnect=false 时不补推（但仍可手动重推）', async () => {
  const { host, dispose } = await boot({ push: { pushOnServerConnect: false, reconcileIntervalMs: 0 } })
  try {
    await waitAllAcked(host, 2)
    const before = host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length
    host.fire('push/connected')
    await new Promise((r) => setTimeout(r, 30))
    assert.equal(host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length, before)
  } finally {
    dispose()
  }
})

// ═══════════════ 5. 周期对账与探测 ═══════════════

test('周期对账：无条件重推（能自愈"服端配置被人删改重置"）', async () => {
  const { host, gameHalf, dispose } = await boot({ push: { reconcileIntervalMs: 25, retryIntervalMs: 0 } })
  try {
    await waitAllAcked(host, 2)
    // 模拟服端配置被清空（进程重启后回到默认）
    gameHalf.applied.set('s1', { version: 0, qqBind: { enabled: false, targetGroup: '', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: [] })
    await host.call('post', '/api/promotion/config', {
      body: { config: { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: ['owner'] } },
    })
    // 再人为清空一次，等对账把它修回来
    gameHalf.applied.set('s1', { version: 0, qqBind: { enabled: false, targetGroup: '', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: [] })
    await waitFor(() => gameHalf.applied.get('s1').qqBind.enabled === true, { timeoutMs: 3000, label: '对账自愈' })
  } finally {
    dispose()
  }
})

test('probe：逐服比对宿主配置与服端实际生效配置，一致/不一致都要说清楚', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    await host.call('post', '/api/promotion/config', {
      body: { config: { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [{ minutes: 60, targetGroup: 'vip', mode: 'auto' }], ignoreGroups: ['owner'] } },
    })

    const ok = await host.call('get', '/api/promotion/status?probe=1')
    assert.equal(ok.status, 200)
    assert.equal(ok.data.probe.servers.length, 2)
    assert.equal(ok.data.probe.servers.every((s) => s.match === true), true, '刚下发成功后应完全一致')
    assert.deepEqual(ok.data.probe.servers[0].diff, [])

    // 服端被改坏：probe 必须报出差异（这是"配置是否真生效"的唯一直接证据）
    gameHalf.applied.set('s1', {
      version: 5,
      qqBind: { enabled: false, targetGroup: 'other', mode: 'force' },
      playtimeThresholds: [],
      ignoreGroups: ['x'],
    })
    const bad = await host.call('get', '/api/promotion/status?probe=1')
    const s1 = bad.data.probe.servers.find((s) => s.id === 's1')
    assert.equal(s1.match, false)
    assert.ok(s1.diff.some((d) => d.includes('QQ绑定启用')), `差异里要指出 QQ 绑定开关：${s1.diff.join('；')}`)
    assert.ok(s1.diff.some((d) => d.includes('QQ绑定目标组')))
    assert.ok(s1.diff.some((d) => d.includes('时长规则')))
    assert.ok(s1.diff.some((d) => d.includes('忽略组')))
    const s2 = bad.data.probe.servers.find((s) => s.id === 's2')
    assert.equal(s2.match, true, '另一台服不受影响')
  } finally {
    dispose()
  }
})

test('status：报告期望版本、未确认台数、逐服下发结果与绑定快照读取状态', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    const res = await host.call('get', '/api/promotion/status')
    assert.equal(res.status, 200)
    assert.equal(res.data.pendingCount, 0)
    assert.ok(res.data.desiredVersion >= 1)
    assert.equal(res.data.servers.length, 2)
    // 服端的绑定快照读取状态要透出来（"配置对、却识别不到绑定"这类问题靠它定位）
    const s1 = res.data.servers.find((s) => s.id === 's1')
    assert.equal(s1.bindings.count, 2)
    assert.equal(s1.bindings.snapshotVersion, 3)
    // 节奏信息（不在配置文件里，但要在状态里可见，便于排障）
    assert.equal(typeof res.data.intervals.reconcileIntervalMs, 'number')
    // 软依赖状态
    assert.equal(res.data.dependencies.qqBind.installed, true)

    // 未确认台数：让一服失败（重试关掉，避免它自己修好）
    gameHalf.setBehavior('s1', 'missing')
    const r2 = await host.call('post', '/api/promotion/push', { body: {} })
    assert.equal(r2.data.push.pendingCount, 1)
    const st = await host.call('get', '/api/promotion/status')
    assert.equal(st.data.pendingCount, 1)
    assert.deepEqual(st.data.pendingServerIds, ['s1'])
  } finally {
    dispose()
  }
})

// ═══════════════ 6. 用户组下拉的数据源 ═══════════════

test('groups：走 base 的用户组端点（/data/base/players/groups），返回实际存在的组', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    gameHalf.setGroups('s1', ['default', 'vip', 'owner'])
    const res = await host.call('get', '/api/promotion/groups')
    assert.equal(res.status, 200)
    assert.equal(res.data.ok, true)
    assert.deepEqual(res.data.groups, ['default', 'vip', 'owner'])
    assert.equal(res.data.source.id, 's1')
    // 确实调的是 base 的端点（不是本件自己的前缀）
    assert.ok(host.calls.some((c) => c.pathname === '/data/base/players/groups'), '必须调用 /data/base/players/groups')
    assert.equal(res.data.servers.length, 2, '逐服成败都要带回来')
    assert.equal(res.data.servers.every((s) => s.ok), true)
  } finally {
    dispose()
  }
})

test('groups：第一台取不到时用下一台；全都取不到时给出明确原因（前端据此退化为文本输入）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    // s1 的 base 没装 → 落到 s2
    gameHalf.setGroupsBehavior('s1', 'missing')
    const res = await host.call('get', '/api/promotion/groups')
    assert.equal(res.status, 200)
    assert.equal(res.data.ok, true)
    assert.equal(res.data.source.id, 's2')
    assert.ok(res.data.servers.find((s) => s.id === 's1').ok === false)

    // 全部失败 → ok=false + error（绝不静默给一个空下拉）
    gameHalf.setGroupsBehavior('s2', 'missing')
    const bad = await host.call('get', '/api/promotion/groups')
    assert.equal(bad.data.ok, false)
    assert.deepEqual(bad.data.groups, [])
    assert.match(bad.data.error, /取不到用户组列表/)
  } finally {
    dispose()
  }
})

test('groups：base 返回空列表也算失败（不静默给出空下拉）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    gameHalf.setGroups('s1', [])
    gameHalf.setGroups('s2', [])
    const res = await host.call('get', '/api/promotion/groups')
    assert.equal(res.data.ok, false)
    assert.match(res.data.error, /用户组列表为空|取不到用户组列表/)
  } finally {
    dispose()
  }
})

// ═══════════════ 7. 手动重推 ═══════════════

test('手动重推：可指定 serverIds；指定不存在的服 → 404（不静默当成 0 台）', async () => {
  const { host, gameHalf, dispose } = await boot({ push: { reconcileIntervalMs: 0 } })
  try {
    await waitAllAcked(host, 2)
    const only = await host.call('post', '/api/promotion/push', { body: { serverIds: ['s1'] } })
    assert.equal(only.status, 200)
    assert.equal(only.data.push.total, 1)
    assert.equal(only.data.push.servers[0].id, 's1')

    const none = await host.call('post', '/api/promotion/push', { body: { serverIds: ['nope'] } })
    assert.equal(none.status, 404)
    assert.match(none.data.error, /不存在或未启用/)

    // onlyPending：全部已确认时不产生请求
    const before = host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length
    const pending = await host.call('post', '/api/promotion/push', { body: { onlyPending: true } })
    assert.equal(pending.data.push.total, 0)
    assert.equal(host.calls.filter((c) => c.pathname === '/data/promotion/snapshot').length, before)
  } finally {
    dispose()
  }
})

test('手动重推：serverIds 超过上限 → 400', async () => {
  const { host, dispose } = await boot()
  try {
    await waitAllAcked(host, 2)
    const ids = Array.from({ length: 51 }, (_, i) => `s${i}`)
    const res = await host.call('post', '/api/promotion/push', { body: { serverIds: ids } })
    assert.equal(res.status, 400)
    assert.match(res.data.error, /上限/)
  } finally {
    dispose()
  }
})

test('没有启用中的服务器：保存成功但如实说明"没有服务器可下发"', async () => {
  const { host, dispose } = await boot({ servers: [] })
  try {
    const res = await host.call('post', '/api/promotion/config', { body: { updates: { 'qqBind.enabled': true } } })
    assert.equal(res.status, 200)
    assert.equal(res.data.push.total, 0)
    assert.match(res.data.push.note, /没有启用中的服务器/)
  } finally {
    dispose()
  }
})

// ═══════════════ 8. dispose ═══════════════

test('dispose：停掉对账与重试定时器（卸载后不再有后台请求）', async () => {
  const { host, gameHalf, dispose } = await boot({ push: { retryIntervalMs: 20, reconcileIntervalMs: 20 } })
  await waitAllAcked(host, 2)
  gameHalf.setBehavior('s1', 'missing')
  await host.call('post', '/api/promotion/config', { body: { updates: { 'qqBind.enabled': true } } })
  dispose()
  const after = host.calls.length
  await new Promise((r) => setTimeout(r, 120))
  assert.equal(host.calls.length, after, 'dispose 后不应再有后台下发')
})

// ═══════════════ 9. 默认配置与配置读取接口 ═══════════════

test('GET /api/promotion/config：返回整份配置 + 默认值参考 + 警告 + 软依赖', async () => {
  const { host, dispose } = await boot()
  try {
    const res = await host.call('get', '/api/promotion/config')
    assert.equal(res.status, 200)
    assert.deepEqual(res.data.config, defaultConfig())
    assert.deepEqual(res.data.defaults.ignoreGroups, ['owner', 'superadmin'])
    assert.deepEqual(res.data.defaults.qqBind, { enabled: false, targetGroup: 'vip', mode: 'auto' })
    assert.equal(res.data.configFile.endsWith(path.join('promotion', 'config.json')), true)
  } finally {
    dispose()
  }
})

test('GET /api/promotion/config：配置损坏时按默认运行并回显原因（不让管理员无路可走）', async () => {
  const { mkdir, writeFile } = await import('node:fs/promises')
  seq += 1
  const dataDir = path.join(dir, `case-broken-${seq}`)
  await mkdir(pluginDataDir(dataDir), { recursive: true })
  await writeFile(pluginConfigFile(dataDir), '{ not json', 'utf8')

  const gameHalf = makeGameHalf({ serverIds: [] })
  const host = makeFakeHost({ dataDir, servers: [], services: { qqBind: {} }, fetchFor: gameHalf.fetchFor })
  const dispose = await apply(host.ctx)
  try {
    const res = await host.call('get', '/api/promotion/config')
    assert.equal(res.status, 200)
    assert.equal(res.data.config.qqBind.enabled, false, '读不懂配置时绝不按启用运行')
    assert.match(res.data.configError, /不是合法 JSON/)
  } finally {
    dispose()
  }
})
