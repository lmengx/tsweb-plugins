/**
 * 前端半（client/promotion.js）测试
 *
 * ★ 先说清本机限制（交付报告里也要如实写）：**本机没有浏览器，也没有跑起 tsweb web 服务**，
 *   所以这里**不是**浏览器渲染测试，而是三层静态/桩验证：
 *     ① 纯函数层：换算/去重/归一/选项生成直接在 Node 里调（无 DOM 依赖）
 *     ② 源码静态层：注册元信息（id/title/section/path）、文案、类名前缀、无 emoji、
 *        HTML 里不得出现 markdown 星号（那会在页面上原样显示）
 *     ③ 桩 DOM 层：用**最小假 DOM**（见下）真的跑一遍 render()，断言四块卡片都渲染出来了、
 *        文案与旧版一致、软依赖缺失时 QQ 卡片给出原因、组列表取不到时退化为文本输入
 *   桩 DOM **不能**证明真实浏览器里的样式/布局/交互观感（那需要人眼或截图工具）。
 *
 * 另外锁住两条本仓踩过的客户端缺陷：
 *   - 事件监听器必须**先按同一引用解绑再绑**：宿主的 route() 每次进入路由都调 render(container)，
 *     container 是常驻节点；无条件下 addEventListener 会让一次点击执行 N 次。
 *   - 数值输入时不整块重渲染（否则光标会跳出输入框）：只更新那一行的汇总文案。
 *
 * 运行：node test/client-ui.test.mjs
 */
import { test, before } from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const clientFile = path.resolve(here, '..', 'client', 'promotion.js')

// ════════════════════════════════════════════════════════════
//  最小假 DOM（只实现客户端插件用到的那几样）
// ════════════════════════════════════════════════════════════

/** 按选择器缓存的假节点：同一选择器多次 query 返回同一个对象，便于读回插件写进去的 HTML */
function makeNode(sel, cache) {
  const listeners = new Map()
  const node = {
    __sel: sel,
    __listeners: listeners,
    children: [],
    textContent: '',
    className: '',
    value: '',
    checked: false,
    style: {},
    _html: '',
    set innerHTML(v) { this._html = String(v) },
    get innerHTML() { return this._html },
    appendChild(child) { this.children.push(child); return child },
    addEventListener(type, fn) { listeners.set(type, fn) },
    removeEventListener(type) { listeners.delete(type) },
    listenerCount(type) { return listeners.has(type) ? 1 : 0 },
    contains(target) { return target != null && (target === this || node.children.includes(target)) },
    getAttribute(name) {
      const m = new RegExp(`\\[?${name}(?:="([^"]*)")?\\]?`).exec(sel)
      return m && m[1] !== undefined ? m[1] : null
    },
    setAttribute(name, value) { node.style[name] = value },
    querySelector(sub) { return getNode(sub, cache) },
    closest() { return null },
    head: null,
  }
  return node
}

function getNode(sel, cache) {
  if (!cache.has(sel)) cache.set(sel, makeNode(sel, cache))
  return cache.get(sel)
}

function installFakeDom() {
  const cache = new Map()
  const head = makeNode('#head', cache)
  head.appendChild = function (child) { this.children.push(child); return child }

  const document = {
    head,
    createElement(tag) {
      const el = makeNode(`<${tag}>`, cache)
      el.tagName = String(tag).toUpperCase()
      return el
    },
  }
  return { document, cache, head }
}

/** 记录 registerView 的元信息与 render 函数 */
const registered = []
const apiCalls = []
let apiResponder = () => ({ ok: true, status: 200, data: {} })

const fakeDom = installFakeDom()
globalThis.document = fakeDom.document
globalThis.window = {
  tsweb: {
    registerView(view) { registered.push(view) },
    async api(p, opts) {
      apiCalls.push({ path: p, opts })
      return apiResponder(p, opts)
    },
  },
}
globalThis.console = console

let mod

before(async () => {
  // 必须在设置好 globalThis.window/document **之后**再 import：
  // 模块顶层就读 window.tsweb 并立刻 registerView（见 client/promotion.js:188-192）
  mod = await import('../client/promotion.js')
})

/** 让插件内部的 promise 链跑完（loadConfig → loadGroups → loadStatus → renderAll） */
async function settle(n = 12) {
  for (let i = 0; i < n; i++) await Promise.resolve()
}

// ════════════════════════════════════════════════════════════
//  ① 纯函数
// ════════════════════════════════════════════════════════════

test('模式下拉文案与旧版一字不改（auto 在前，两条）', () => {
  assert.deepEqual(mod.MODE_OPTIONS, [
    { value: 'auto', label: '自动（检查父组链，不降级）' },
    { value: 'force', label: '强制（忽略当前组直接设为目标组）' },
  ])
})

test('新增规则默认值与旧版 addThreshold 一致（60 分钟 / default / auto）', () => {
  assert.deepEqual(mod.DEFAULT_THRESHOLD, { minutes: 60, targetGroup: 'default', mode: 'auto' })
})

test('天/时/分换算与旧版 toDays/toHours/toMins 一致', () => {
  assert.equal(mod.toDays(0), 0)
  assert.equal(mod.toDays(1439), 0)
  assert.equal(mod.toDays(1440), 1)
  assert.equal(mod.toDays(3000), 2)      // 3000 = 2 天 + 2 小时 + 0 分
  assert.equal(mod.toHours(3000), 2)
  assert.equal(mod.toMins(3000), 0)
  assert.equal(mod.toHours(1439), 23)
  assert.equal(mod.toMins(59), 59)
  assert.equal(mod.toMins(60), 0)
  // 脏输入不抛错
  assert.equal(mod.toDays(undefined), 0)
  assert.equal(mod.toHours(null), 0)
  assert.equal(mod.toMins('x'), 0)
})

test('fromDHM 照旧版含 Math.max(1, ...)：全空/全零 → 1 分钟（不是 0）', () => {
  assert.equal(mod.fromDHM(0, 0, 0), 1, '旧版 Vue:33-38 的 Math.max(1, ...)：0 分钟规则会被服端滤掉，所以最小 1 分钟')
  assert.equal(mod.fromDHM('', '', ''), 1)
  assert.equal(mod.fromDHM(1, 0, 0), 1440)
  assert.equal(mod.fromDHM(0, 2, 30), 150)
  assert.equal(mod.fromDHM(2, 2, 0), 3000)
  assert.equal(mod.fromDHM('2', '2', '0'), 3000)
  assert.equal(mod.fromDHM(-5, 0, 0), 1, '负数结果也被 Math.max(1, ...) 兜到 1')
})

test('汇总文案与徽标文案照旧版（"= N 分钟（X.X 小时）" / "N 条规则"）', () => {
  assert.equal(mod.formatTotal(3000), '= 3000 分钟（50.0 小时）')
  assert.equal(mod.formatTotal(90), '= 90 分钟（1.5 小时）')
  assert.equal(mod.formatTotal(0), '= 0 分钟（0.0 小时）')
  assert.equal(mod.rulesLabel(3), '3 条规则')
  assert.equal(mod.rulesLabel(0), '0 条规则')
  assert.equal(mod.rulesLabel(undefined), '0 条规则')
})

test('忽略组去重与宿主/旧版同口径（忽略大小写、trim、剔空、保留首现写法）', () => {
  assert.deepEqual(mod.dedupeIgnoreGroups(['owner', 'OWNER', ' superadmin ']), ['owner', 'superadmin'])
  assert.deepEqual(mod.dedupeIgnoreGroups(['b', 'a', 'B', 'A']), ['b', 'a'], '保留首现顺序，不排序')
  assert.deepEqual(mod.dedupeIgnoreGroups(['', '  ', 'x']), ['x'])
  assert.deepEqual(mod.dedupeIgnoreGroups(null), [])
  assert.deepEqual(mod.dedupeIgnoreGroups('owner'), [], '非数组 → 空数组（不猜）')
})

test('添加忽略组：空/纯空白不添加；重复（忽略大小写）不添加；成功时追加原写法', () => {
  assert.deepEqual(mod.addIgnoreGroup(['owner'], ''), { list: ['owner'], added: false })
  assert.deepEqual(mod.addIgnoreGroup(['owner'], '   '), { list: ['owner'], added: false })
  assert.deepEqual(mod.addIgnoreGroup(['owner'], 'OWNER'), { list: ['owner'], added: false }, '忽略大小写去重')
  assert.deepEqual(mod.addIgnoreGroup(['owner'], ' Mod '), { list: ['owner', 'Mod'], added: true })
  assert.deepEqual(mod.addIgnoreGroup(null, 'x'), { list: ['x'], added: true })
  // 不改入参
  const src = ['owner']
  mod.addIgnoreGroup(src, 'helper')
  assert.deepEqual(src, ['owner'])
})

test('删除第 i 项：越界/非法下标不抛错且不改动', () => {
  assert.deepEqual(mod.removeAt(['a', 'b', 'c'], 1), ['a', 'c'])
  assert.deepEqual(mod.removeAt(['a'], 5), ['a'])
  assert.deepEqual(mod.removeAt(['a'], -1), ['a'])
  assert.deepEqual(mod.removeAt(['a'], 'x'), ['a'])
  assert.deepEqual(mod.removeAt(null, 0), [])
})

test('归一宿主返回的配置：模式只认 auto、其他一律 force；空目标组保留成空串', () => {
  const c = mod.normalizeLoadedConfig({
    qqBind: { enabled: true, targetGroup: '', mode: 'WHAT' },
    playtimeThresholds: [{ minutes: '90', targetGroup: ' vip ', mode: 'AUTO' }, { minutes: -3 }, null],
    ignoreGroups: ['owner', 'OWNER'],
  })
  assert.deepEqual(c.qqBind, { enabled: true, targetGroup: '', mode: 'force' })
  assert.equal(c.playtimeThresholds[0].minutes, 90)
  assert.equal(c.playtimeThresholds[0].mode, 'auto')
  assert.equal(c.playtimeThresholds[1].minutes, 0, '负数分钟兜到 0')
  assert.equal(c.playtimeThresholds[1].targetGroup, '', '缺目标组保留空串（不偷偷填默认值）')
  assert.equal(c.playtimeThresholds.length, 3, 'null 项也被归一成一条（不丢项、不错位）')
  assert.deepEqual(c.ignoreGroups, ['owner'])
  // 脏输入
  assert.deepEqual(mod.normalizeLoadedConfig(null).qqBind, { enabled: false, targetGroup: '', mode: 'auto' })
})

test('保存请求体是"整份替换"形态：{ config: {...} }', () => {
  const payload = mod.buildSavePayload({
    qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' },
    playtimeThresholds: [],
    ignoreGroups: ['owner'],
  })
  assert.deepEqual(Object.keys(payload), ['config'])
  assert.deepEqual(Object.keys(payload.config).sort(), ['ignoreGroups', 'playtimeThresholds', 'qqBind'])
})

test('组下拉选项：被选中的项按大小写不敏感匹配；值都转义', () => {
  const html = mod.groupOptionsHtml(['vip', 'VIP2'], 'vip')
  assert.ok(html.startsWith('<option value="" disabled'), '占位项在前')
  assert.match(html, /<option value="vip" selected>vip<\/option>/)
  assert.ok(!html.includes('value="VIP2" selected'), '未被选中的项不能带 selected')
  // 大小写不敏感：把 VIP 传给选项 vip
  assert.match(mod.groupOptionsHtml(['vip'], 'VIP'), /value="vip" selected/)
  // 转义
  assert.match(mod.groupOptionsHtml(['a"b<c>'], ''), /value="a&quot;b&lt;c&gt;"/)
  assert.equal(mod.groupOptionsHtml(null, ''), '<option value="" disabled selected>选择权限组...</option>')
})

test('esc 转义全部 5 个字符（值来自配置/服端，必须转义后再拼 HTML）', () => {
  assert.equal(mod.esc('<script>alert("x")&\'y\'</script>'),
    '&lt;script&gt;alert(&quot;x&quot;)&amp;&#39;y&#39;&lt;/script&gt;')
  assert.equal(mod.esc(null), '')
  assert.equal(mod.esc(0), '0')
})

// ════════════════════════════════════════════════════════════
//  ② 源码静态断言
// ════════════════════════════════════════════════════════════

let source

test('注册元信息：id/title/section/path 与任务约定一致', async () => {
  source = await readFile(clientFile, 'utf8')
  assert.equal(registered.length, 1, `必须恰好注册一次视图（实际 ${registered.length} 次）`)
  const v = registered[0]
  assert.equal(v.id, 'promotion')
  assert.equal(v.title, '权限提升')
  assert.equal(v.section, '后端设置')
  assert.equal(v.path, '/b/promotion')
  assert.equal(typeof v.render, 'function')
})

test('源码里没有 emoji（约定：禁止 emoji；✕/＋/— 这类几何符号允许）', () => {
  // 旧版界面本来就用的几何符号：✕（删除）、＋（添加）、—（全角破折号）——先把它们摘掉再查 emoji
  const ALLOWED = /[✕＋−—]/g
  // 真正的 emoji 区段（杂项符号/装饰符号/象形符号/交通/补充符号/区域指示符/变体选择符）
  const emoji = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}\u{1F1E6}-\u{1F1FF}]/u
  const lines = source.split(/\r?\n/)
  const bad = []
  lines.forEach((line, i) => {
    if (emoji.test(line.replace(ALLOWED, ''))) bad.push(`${i + 1}: ${line.trim()}`)
  })
  assert.deepEqual(bad, [], '客户端源码里不得出现 emoji：\n' + bad.join('\n'))
  // 明确允许的几何符号（旧版界面就有）
  assert.ok(source.includes('✕'), '删除按钮沿用旧版的 ✕')
  assert.ok(source.includes('＋'), '添加按钮沿用旧版的 ＋')
})

test('文案锚点：旧版三块卡片的说明文字都在源码里', () => {
  for (const copy of [
    '权限提升配置',
    '配置 QQ 绑定和游玩时长的自动权限提升规则',
    'QQ 绑定提升',
    '玩家绑定 QQ 后自动提升权限组',
    '游玩时长提升',
    '达到指定游玩时长后自动提升权限组（取最高匹配规则）',
    '添加阈值',
    '忽略组',
    '属于以下组的玩家将',
    '始终不会被自动提升',
    '目标权限组',
    '提升模式',
    '下发状态',
    '选择权限组...',
  ]) {
    assert.ok(source.includes(copy), `客户端源码缺少文案：${copy}`)
  }
})

test('局部类名统一 pr- 前缀；不引第三方 UI 库、不用框架', async () => {
  // ① class 属性里的**纯字面量** token：必须都是 pr- 前缀
  const literalTokens = new Set()
  // ② class 属性里含拼接的（class="pr-status ' + cls + '"）：把其中出现的"像类名"的词都抓出来
  //    （看着像类名 = 小写字母开头 + 至少一个连字符，如 vip-card / th-row）
  const dynamicTokens = new Set()

  for (const m of source.matchAll(/class="([^"]*)"/g)) {
    const raw = m[1]
    if (raw.includes("'") || raw.includes('+')) {
      for (const t of raw.match(/[a-z][a-z0-9]*(?:-[a-z0-9]+)+/g) || []) dynamicTokens.add(t)
      continue
    }
    for (const c of raw.split(/\s+/)) if (c !== '') literalTokens.add(c)
  }

  const badLiteral = [...literalTokens].filter((c) => !c.startsWith('pr-'))
  assert.deepEqual(badLiteral, [], `class 属性里出现了非 pr- 前缀的类名：${badLiteral.join(', ')}`)
  const badDynamic = [...dynamicTokens].filter((c) => !c.startsWith('pr-'))
  assert.deepEqual(badDynamic, [], `动态拼装的 class 里出现了非 pr- 前缀的类名：${badDynamic.join(', ')}`)

  // 抽查：确实抓到了一批类名（否则上面的断言是空断言）
  assert.ok(literalTokens.size >= 10, `抓到的类名太少（${literalTokens.size}），检查逻辑可能失效`)
  assert.ok(dynamicTokens.size >= 2, `抓到的动态类名太少（${dynamicTokens.size}）`)

  assert.doesNotMatch(source, /\bimport\s+[^\n]*from\s+['"](?!\.)/, '不得 import 第三方模块')
  assert.doesNotMatch(source, /\brequire\(/, '客户端插件是 ESM，不得用 require')
})

test('HTML 字符串里不得出现 markdown 星号（那会在页面上原样显示）', () => {
  const lines = source.split(/\r?\n/)
  const bad = []
  lines.forEach((line, i) => {
    const trimmed = line.trim()
    if (trimmed.startsWith('*') || trimmed.startsWith('//') || trimmed.startsWith('/*')) return
    // 只看会进 HTML 的行（含 < 标签的字符串拼接）
    if (!/[<>]/.test(line)) return
    if (/\*\*[^*]+\*\*/.test(line)) bad.push(`${i + 1}: ${trimmed}`)
  })
  assert.deepEqual(bad, [], '这些行会把 markdown 星号显示到页面上：\n' + bad.join('\n'))
})

test('事件委托是"先按同一引用解绑再绑"（防止多次进入路由后一次点击执行 N 次）', () => {
  assert.match(source, /removeEventListener\('click'/, '必须解绑 click')
  assert.match(source, /removeEventListener\('change'/, '必须解绑 change')
  assert.match(source, /removeEventListener\('input'/, '必须解绑 input')
  assert.match(source, /removeEventListener\('keydown'/, '必须解绑 keydown')
  // 解绑必须发生在绑定之前（用出现次序判断）
  const firstRemove = source.indexOf("removeEventListener('click'")
  const firstAdd = source.indexOf("addEventListener('click'")
  assert.ok(firstRemove >= 0 && firstAdd > firstRemove, '解绑必须在绑定之前')
  // 解绑用的必须是同一个引用（存在 container.__prXxx 这类引用字段）
  for (const key of ['__prClick', '__prChange', '__prInput', '__prKeydown']) {
    assert.ok(source.includes('container.' + key), `必须用 container.${key} 保存并解绑同一引用`)
  }
})

test('数值输入只更新该行汇总文案，不整块重渲染（否则光标会跳出输入框）', () => {
  const body = source.slice(source.indexOf('function onInput'), source.indexOf('function onClick'))
  assert.match(body, /updateTotalLabel\(/, '输入时必须调用 updateTotalLabel')
  assert.doesNotMatch(body, /renderThresholds\(/, '输入时不得整块重渲染时长卡片（会丢焦点）')
})

test('软依赖缺失时 QQ 卡片**不隐藏**、给出原因；时长卡片照常可编辑', () => {
  const qq = source.slice(source.indexOf('function renderQq'), source.indexOf('function thresholdHtml'))
  assert.match(qq, /dep\.installed !== true/, '必须以 installed 判定可用性')
  assert.match(qq, /当前不可用/, '必须显示"当前不可用"')
  assert.match(qq, /esc\(dep\.reason/, '必须显示宿主给出的原因')
  assert.doesNotMatch(qq, /display:\s*none|return ''/, '不得直接隐藏该卡片（管理员要能看到配置与原因）')
})

test('组列表取不到时退化为文本输入**并说明原因**（绝不静默给空下拉）', () => {
  const g = source.slice(source.indexOf('function groupControlHtml'), source.indexOf('function renderQq'))
  assert.match(g, /state\.groups\.length > 0/, '有组列表才用下拉')
  assert.match(g, /type="text"/, '取不到时退化为文本输入')
  assert.match(g, /取不到服务器上的用户组列表/, '必须说明退化原因')
  assert.match(g, /pr-hint/, '原因要显示在页面上')
})

test('前端只调本件自己的四个管理端点（不复用 qq-bind/online-stats 的路径）', () => {
  const paths = [...source.matchAll(/tsw\.api\(\s*'([^']+)'/g)].map((m) => m[1].replace(/\?.*$/, ''))
  assert.deepEqual([...new Set(paths)].sort(),
    ['/api/promotion/config', '/api/promotion/groups', '/api/promotion/push', '/api/promotion/status'])
})

// ════════════════════════════════════════════════════════════
//  ③ 桩 DOM：真的跑一遍 render()
// ════════════════════════════════════════════════════════════

/** 造一份宿主响应：三条读路径（config / groups / status），读路径用的都是固定夹具 */
function makeResponder({ config, groups, groupsError, qqBindInstalled = true, status }) {
  const depReason = qqBindInstalled
    ? ''
    : '未检测到 qq-bind 插件（本件的软依赖）；「游玩时长提升」不受影响'
  return (p) => {
    if (p.startsWith('/api/promotion/config')) {
      return {
        ok: true, status: 200,
        data: {
          ok: true,
          config,
          configFile: 'X:/data/promotion/config.json',
          configError: '',
          warnings: [],
          dependencies: { qqBind: { installed: qqBindInstalled, reason: depReason } },
        },
      }
    }
    if (p.startsWith('/api/promotion/groups')) {
      if (groupsError) return { ok: true, status: 200, data: { ok: false, groups: [], source: null, servers: [], error: groupsError } }
      return { ok: true, status: 200, data: { ok: true, groups, source: { id: 's1', name: '一服' }, servers: [{ id: 's1', ok: true }], error: '' } }
    }
    if (p.startsWith('/api/promotion/status')) {
      return { ok: true, status: 200, data: { ok: true, desiredVersion: 7, pendingCount: 1, servers: status || [], probe: null, dependencies: { qqBind: { installed: qqBindInstalled, reason: depReason } } } }
    }
    return { ok: true, status: 200, data: { ok: true, push: { total: 0, ok: true, pendingCount: 0, servers: [], note: '没有启用中的服务器' } } }
  }
}

/** 造一份宿主响应，然后调 render 并等它渲染完 */
async function renderView(opts) {
  apiResponder = makeResponder(opts)
  // 必须用 getNode（会写进缓存）而不是 makeNode（只创建不入缓存），否则读不回渲染结果
  const container = getNode('#container', fakeDom.cache)
  container.innerHTML = ''   // 每次重渲染前清掉外壳，断言读到的就是本次渲染结果
  registered[0].render(container)
  await settle(20)
  return container
}

test('render：四块卡片 + 状态行 + 样式都渲染出来了', async () => {
  const container = await renderView({
    config: {
      qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' },
      playtimeThresholds: [{ minutes: 3000, targetGroup: 'trustedplayer', mode: 'auto' }],
      ignoreGroups: ['owner', 'superadmin'],
    },
    groups: ['default', 'vip', 'trustedplayer', 'owner'],
    status: [{ id: 's1', name: '一服', ok: true, version: 7, error: '', bindings: { count: 3, note: '' } }],
  })

  const shell = fakeDom.cache.get('#container')
  assert.ok(shell.innerHTML.includes('权限提升配置'), '外壳标题')
  assert.ok(shell.innerHTML.includes('id="pr-status"'), '状态行容器')
  for (const id of ['#pr-qq', '#pr-thresholds', '#pr-ignore', '#pr-push']) {
    assert.ok(shell.innerHTML.includes(`id="${id.slice(1)}"`), `外壳必须包含 ${id} 容器`)
  }
  assert.ok(fakeDom.head.children.length >= 1, '样式注入到 head')
  assert.ok(fakeDom.head.children[0].textContent.includes('.pr-card'), '样式内容含 pr- 类名')

  const qq = fakeDom.cache.get('#pr-qq').innerHTML
  const th = fakeDom.cache.get('#pr-thresholds').innerHTML
  const ig = fakeDom.cache.get('#pr-ignore').innerHTML
  const push = fakeDom.cache.get('#pr-push').innerHTML

  // QQ 卡片
  assert.ok(qq.includes('QQ 绑定提升'))
  assert.ok(qq.includes('玩家绑定 QQ 后自动提升权限组'))
  assert.ok(qq.includes('自动（检查父组链，不降级）'), '模式文案照旧版')
  assert.ok(qq.includes('value="vip" selected'), '目标组下拉选中 vip')
  assert.ok(qq.includes('登录时'), '说明识别时机')
  assert.ok(!qq.includes('当前不可用'), 'qq-bind 已安装时不该显示不可用')

  // 时长卡片
  assert.ok(th.includes('游玩时长提升'))
  assert.ok(th.includes('1 条规则'), '徽标显示规则条数')
  assert.ok(th.includes('= 3000 分钟（50.0 小时）'), '汇总文案换算正确')
  assert.ok(th.includes('value="2"'), '3000 分钟 → 2 天')
  assert.ok(th.includes('添加阈值'))
  assert.ok(th.includes('data-prth="day"') && th.includes('data-prth="hour"') && th.includes('data-prth="min"'), '天/时/分三个输入框')

  // 忽略组卡片
  assert.ok(ig.includes('忽略组'))
  assert.ok(ig.includes('始终不会被自动提升'))
  assert.ok(ig.includes('owner') && ig.includes('superadmin'))

  // 下发状态卡片
  assert.ok(push.includes('下发状态'))
  assert.ok(push.includes('期望版本 v7'))
  assert.ok(push.includes('未确认 1 台'), '未确认台数要显示出来')
  assert.ok(push.includes('一服'))
  assert.ok(push.includes('X:/data/promotion/config.json'), '配置文件路径')

  // 渲染结果里不许出现 markdown 星号
  for (const [name, html] of [['qq', qq], ['thresholds', th], ['ignore', ig], ['push', push]]) {
    assert.ok(!/\*\*/.test(html), `${name} 卡片渲染结果里出现了 markdown 星号`)
  }
})

test('render：qq-bind 未安装 → QQ 卡片显示不可用 + 原因，但配置项仍在', async () => {
  await renderView({
    config: { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: ['owner'] },
    groups: ['vip'],
    qqBindInstalled: false,
  })
  const qq = fakeDom.cache.get('#pr-qq').innerHTML
  assert.ok(qq.includes('当前不可用'), '必须显示"当前不可用"')
  assert.ok(qq.includes('未检测到 qq-bind 插件'), '必须显示宿主给出的原因')
  assert.ok(qq.includes('游玩时长提升') || qq.includes('不受影响'), '原因里要说明哪些功能不受影响')
  assert.ok(qq.includes('data-prqq="targetGroup"'), '配置项仍然渲染出来（便于查看与后续启用）')
})

test('render：组列表取不到 → 退化为文本输入并说明原因', async () => {
  await renderView({
    config: { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: ['owner'] },
    groupsError: '所有服务器都取不到用户组列表：游戏服端未安装 base 插件',
  })
  const qq = fakeDom.cache.get('#pr-qq').innerHTML
  assert.ok(qq.includes('type="text"'), '必须退化为文本输入')
  assert.ok(qq.includes('取不到服务器上的用户组列表'), '必须说明原因')
  assert.ok(qq.includes('游戏服端未安装 base 插件'), '原因要带上宿主的原文')
  assert.ok(qq.includes('value="vip"'), '当前值要回填到文本框')
})

test('render：空配置也渲染（不能崩、不能空白）', async () => {
  await renderView({ config: {}, groups: [] })
  const th = fakeDom.cache.get('#pr-thresholds').innerHTML
  assert.ok(th.includes('0 条规则'))
  assert.ok(th.includes('还没有规则'), '空态要有提示')
  assert.ok(fakeDom.cache.get('#pr-ignore').innerHTML.includes('忽略组'))
})

// ════════════════════════════════════════════════════════════
//  ④ D8：保存在飞时不能丢编辑
//     （本插件引入的缺陷：旧版 PromotionConfigView.vue:40-61 没有"在飞守卫"，
//       本插件的 `if (state.saving) return` 会把防抖触发的保存整次丢掉、不补尾保存，
//       紧接着的响应又用服务端配置覆盖 state.config，那次编辑就永久丢失且界面回退）
//
//  说明：这里用**真实计时器**等 500ms 防抖（与插件里的语义一致），所以单个用例要等
//        1~2 秒；不用假计时器是为了不替换 globalThis.setTimeout（那会干扰 node:test 自身）。
// ════════════════════════════════════════════════════════════

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

/** 防抖是 500ms，等这么久足够它到期；留出充足余量以免机器繁忙时抖动 */
const AFTER_DEBOUNCE = 620

/**
 * 渲染一次，并把**保存请求**（带 opts.json 的那种）挂起 —— 由测试决定何时返回，
 * 用来制造"请求还在飞"的窗口。读路径（不带 json）照常立即返回。
 * @returns {{ container: object, saves: Array<{payload: object, resolve: Function}> }}
 */
async function renderViewWithHeldSave(opts) {
  const saves = []
  const readResponder = makeResponder(opts)
  apiResponder = (p, o) => {
    if (p.startsWith('/api/promotion/config') && o && o.json) {
      let resolve
      const promise = new Promise((r) => { resolve = r })
      saves.push({ payload: o.json, resolve })
      return promise
    }
    return readResponder(p, o)
  }
  const container = getNode('#container', fakeDom.cache)
  container.innerHTML = ''
  container.children.length = 0
  registered[0].render(container)
  await settle(20)
  return { container, saves }
}

/** 模拟"目标权限组下拉被改选"：假 DOM 的 contains() 只看 children，所以目标节点要挂进 children */
function changeTargetGroup(container, value) {
  const target = {
    getAttribute: (name) => (name === 'data-prqq' ? 'targetGroup' : null),
    hasAttribute: () => false,
    value,
    checked: false,
  }
  container.children.push(target)
  container.__prChange({ target })
}

/** 保存请求的正常响应 */
function saveResponse(config) {
  return {
    ok: true, status: 200,
    data: {
      ok: true,
      config,
      configError: '',
      warnings: [],
      push: { total: 0, ok: true, pendingCount: 0, servers: [], note: '没有启用中的服务器' },
    },
  }
}

/** D8 场景共用的初始配置与组列表 */
const D8_FIXTURE = {
  config: { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: ['owner'] },
  groups: ['default', 'vip', 'g1', 'g2', 'g3', 'g4'],
}

test('D8：保存在飞期间连续 3 次编辑 → 只补 1 次尾保存，且补的是最新值（不丢编辑）', async () => {
  const { container, saves } = await renderViewWithHeldSave(D8_FIXTURE)

  // 第 1 次编辑 → 500ms 防抖后发出第 1 个保存请求，并让它一直挂着
  changeTargetGroup(container, 'g1')
  await delay(AFTER_DEBOUNCE)
  assert.equal(saves.length, 1, '防抖到期后应恰好发出 1 个保存请求')
  assert.equal(saves[0].payload.config.qqBind.targetGroup, 'g1', '第 1 个请求带的是第 1 次编辑的值')

  // 保存还在飞：连续 3 次编辑
  changeTargetGroup(container, 'g2')
  changeTargetGroup(container, 'g3')
  changeTargetGroup(container, 'g4')
  assert.equal(saves.length, 1, '在飞期间不得并发第二个保存请求')

  const qqHtmlWhileSaving = fakeDom.cache.get('#pr-qq').innerHTML

  // 服务端返回的是**旧值 g1**（真实场景里服务端就存着上一次的配置）：
  // 若插件用响应覆盖 state.config，g2/g3/g4 就丢了、界面也回退
  saves[0].resolve(saveResponse({
    qqBind: { enabled: true, targetGroup: 'g1', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: ['owner'],
  }))
  await settle(30)
  assert.equal(saves.length, 1, '响应刚回来时不得立即再发请求（补保存要等 500ms 防抖）')
  assert.equal(
    fakeDom.cache.get('#pr-qq').innerHTML, qqHtmlWhileSaving,
    '保存期间有新编辑 → 不得用响应重渲染（否则界面上"改了又被回退"）',
  )

  // 补的那一次尾保存：必须把最新编辑 g4 提交上去
  await delay(AFTER_DEBOUNCE)
  assert.equal(saves.length, 2, '在飞期间的 3 次编辑只应多补 1 次保存（不是 3 次，也不是 0 次）')
  assert.equal(saves[1].payload.config.qqBind.targetGroup, 'g4', '补的尾保存必须带最新编辑（不丢编辑）')
  assert.equal(saves[1].payload.config.ignoreGroups.length, 1, '请求体仍是整份配置（改动即自动保存）')

  // 收尾：让补的这次也返回，确认不再多补
  saves[1].resolve(saveResponse({
    qqBind: { enabled: true, targetGroup: 'g4', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: ['owner'],
  }))
  await settle(30)
  await delay(AFTER_DEBOUNCE)
  assert.equal(saves.length, 2, '没有新编辑就不该再补（最终只多补 1 次，无保存风暴）')
})

test('D8：防抖计时器在飞期间就到期 → 不并发、只记尾保存，结束后仍只补 1 次', async () => {
  const { container, saves } = await renderViewWithHeldSave(D8_FIXTURE)

  changeTargetGroup(container, 'g1')
  await delay(AFTER_DEBOUNCE)
  assert.equal(saves.length, 1)

  // 这次编辑之后**故意等过防抖窗口**：计时器会在请求仍挂着的时候被叫到
  changeTargetGroup(container, 'g2')
  await delay(AFTER_DEBOUNCE)
  assert.equal(saves.length, 1, '在飞期间到期的防抖不得变成并发请求（编辑不丢，只记尾保存）')

  saves[0].resolve(saveResponse({
    qqBind: { enabled: true, targetGroup: 'g1', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: ['owner'],
  }))
  await settle(30)
  await delay(AFTER_DEBOUNCE)
  assert.equal(saves.length, 2, '只补 1 次尾保存')
  assert.equal(saves[1].payload.config.qqBind.targetGroup, 'g2', '尾保存带的是 g2')

  saves[1].resolve(saveResponse({
    qqBind: { enabled: true, targetGroup: 'g2', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: ['owner'],
  }))
  await settle(30)
  await delay(AFTER_DEBOUNCE)
  assert.equal(saves.length, 2, '无新编辑 → 不再补（有界）')
})

test('D8：保存期间没有新编辑 → 照旧用响应覆盖并重渲染（不误伤正常同步）', async () => {
  const { container, saves } = await renderViewWithHeldSave({
    config: { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: [] },
    groups: ['vip', 'fromserver'],
  })

  changeTargetGroup(container, 'fromserver')
  await delay(AFTER_DEBOUNCE)
  assert.equal(saves.length, 1)

  saves[0].resolve(saveResponse({
    qqBind: { enabled: true, targetGroup: 'fromserver', mode: 'force' }, playtimeThresholds: [], ignoreGroups: [],
  }))
  await settle(30)
  await delay(80)

  assert.equal(saves.length, 1, '保存期间没有新编辑 → 不该补保存')
  const qq = fakeDom.cache.get('#pr-qq').innerHTML
  assert.ok(qq.includes('value="fromserver" selected'), '无新编辑时应照响应重渲染（正常同步没被关掉）')
  assert.ok(qq.includes('value="force" selected'), '模式也照响应回填')
})

// ════════════════════════════════════════════════════════════
//  ⑤ D7：QQ 卡片两个下拉的禁用条件 =（开关关闭）或（qq-bind 不可用）
//     旧版 PromotionConfigView.vue:179、:186 是"开关关闭时禁用"，
//     本插件改成只看软依赖 → 开关关着下拉还能改。两者都要，且禁用必须给出原因。
// ════════════════════════════════════════════════════════════

/** 目标组控件是否被禁用（下拉与退化文本输入两种形态都覆盖），以及模式下拉 */
const TARGET_DISABLED = /data-prqq="targetGroup"[^>]*\sdisabled/
const MODE_DISABLED = /data-prqq="mode"[^>]*\sdisabled/
const SWITCH_DISABLED = /data-prqq="enabled"[^>]*\sdisabled/

test('D7：开关关闭 → 目标组与模式两个下拉都 disabled，并说明原因', async () => {
  await renderView({
    config: { qqBind: { enabled: false, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: [] },
    groups: ['default', 'vip'],
  })
  const qq = fakeDom.cache.get('#pr-qq').innerHTML

  assert.match(qq, TARGET_DISABLED, '开关关闭时目标权限组下拉必须禁用（旧版 PromotionConfigView.vue:179）')
  assert.match(qq, MODE_DISABLED, '开关关闭时提升模式下拉必须禁用（旧版 PromotionConfigView.vue:186）')
  assert.ok(qq.includes('开关已关闭'), '禁用必须给出原因（不能只禁用不说为什么）')
  assert.doesNotMatch(qq, SWITCH_DISABLED, '开关本身不得被禁用，否则关掉后再也打不开')
  assert.ok(qq.includes('value="vip" selected'), '当前值仍然要显示出来（便于查看）')

  const th = fakeDom.cache.get('#pr-thresholds').innerHTML
  assert.doesNotMatch(th, /\sdisabled/, '「游玩时长提升」不依赖 QQ 开关，不得被连带禁用')
})

test('D7：开关打开且 qq-bind 可用 → 两个下拉可编辑（禁用条件不是恒真）', async () => {
  await renderView({
    config: { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: [] },
    groups: ['default', 'vip'],
  })
  const qq = fakeDom.cache.get('#pr-qq').innerHTML
  assert.doesNotMatch(qq, TARGET_DISABLED, '开关打开且依赖可用时目标组下拉必须可编辑')
  assert.doesNotMatch(qq, MODE_DISABLED, '开关打开且依赖可用时模式下拉必须可编辑')
  assert.doesNotMatch(qq, SWITCH_DISABLED, '依赖可用时开关必须可编辑')
  assert.ok(!qq.includes('开关已关闭'), '可编辑时不该出现"开关已关闭"提示')
})

test('D7：qq-bind 不可用 → 两个下拉（含开关）都 disabled，且给出宿主的原因', async () => {
  await renderView({
    config: { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: [] },
    groups: ['vip'],
    qqBindInstalled: false,
  })
  const qq = fakeDom.cache.get('#pr-qq').innerHTML

  assert.match(qq, TARGET_DISABLED, '依赖不可用时目标组下拉必须禁用')
  assert.match(qq, MODE_DISABLED, '依赖不可用时模式下拉必须禁用')
  assert.match(qq, SWITCH_DISABLED, '依赖不可用时开关也禁用')
  assert.ok(qq.includes('当前不可用'), '必须显示"当前不可用"')
  assert.ok(qq.includes('未检测到 qq-bind 插件'), '必须给出宿主给的原因（不能只禁用不说原因）')
})

test('D7：组列表取不到（已退化为文本输入）时，开关关闭照样禁用该输入框', async () => {
  await renderView({
    config: { qqBind: { enabled: false, targetGroup: 'vip', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: [] },
    groupsError: '所有服务器都取不到用户组列表：游戏服端未安装 base 插件',
  })
  const qq = fakeDom.cache.get('#pr-qq').innerHTML
  assert.ok(qq.includes('type="text"'), '仍是退化文本输入')
  assert.match(qq, TARGET_DISABLED, '开关关闭时退化的文本输入同样要禁用')
  assert.match(qq, MODE_DISABLED, '模式下拉同样要禁用')
  assert.ok(qq.includes('开关已关闭'), '同样要说明原因')
  assert.ok(qq.includes('取不到服务器上的用户组列表'), '退化原因照旧显示')
})
