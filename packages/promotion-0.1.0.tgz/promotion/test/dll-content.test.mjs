/**
 * DLL 内容断言（防"DLL 里其实没有这段代码"）
 *
 * 为什么必须有这条测试：
 *   本仓实测发生过这种缺陷——plugins/qq-bind/plugin/QqBind.dll（27136 B）的**二进制里
 *   根本没有** QqPromotion / TryPromoteOnLogin，而同目录 obj/Release/QqBind.dll
 *   里是有的。也就是说"会被打包下发的 DLL 里没有晋升代码"，而构建、打包、
 *   `--check` 全程没有任何报错（根因是打包器从 bin/Release/<tfm>/ 回拷时用了陈旧产物）。
 *   → 于是：**编译通过 ≠ 功能在包里**。这里对**实际会被打包的那个文件**做字节层断言。
 *
 * 判据设计（阳性对照，避免"扫了个空文件也算过"）：
 *   - 阳性对照：几个与本功能无关、但必然存在的元数据字符串（基类名 / 覆写方法名 / 框架类型名）。
 *     对照只要有一个没命中，说明扫错了文件或扫描本身失效，测试直接失败（不是"缺功能"）。
 *   - 目标串：两种晋升依据必然编译进去的类型名、方法名、路由字面量、SQL 表名、快照/配置文件
 *     文件名、以及旧版迁移用的 reason 文案与**保护默认值的字面量**（owner / superadmin）。
 *   - 阴性对照：
 *       ① 一个肯定不存在的串必须扫不到 —— 证明"扫得到"这件事本身是有区分度的；
 *       ② 旧身份（QqPromotion / qq-promotion-config.json）必须扫不到 —— 证明改名真的落进了产物；
 *       ③ 与 qq-bind 的程序集命名空间 TsWebQqBind 必须扫不到 —— 证明没有程序集耦合；
 *       ④ **写入 player_daily_stat 的语句必须扫不到**（见下）。
 *
 * ★★ 双倍计时长防护（本次任务的硬约束）★★
 *   player_daily_stat 的每分钟 +1 已经由 online-stats 插件的 DLL 负责
 *   （plugins/online-stats/plugin/OnlineStatsData.cs:130-153）。本件若也写一次，玩家的
 *   累计时长会**翻倍**、所有时长阈值提前一半触发。所以这里对**实际会被打包的那个 DLL**
 *   断言：不得出现 `INSERT INTO player_daily_stat`、不得出现 `daily_min + 1`，
 *   也不得出现 `hourly_online_snapshot`（那是 online-stats 的另一个职责）。
 *   同时正面断言它**确实**含 `player_daily_stat`（读的那条 SELECT）。
 *
 * 局限（如实说明，不要当成运行时保证）：本机没有 TShock 运行环境，这条测试只能证明
 *   "这段代码在 DLL 的元数据/字符串堆里"，**不能**证明它在真实 TShock 上按预期晋升。
 *
 * 运行：node test/dll-content.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile, readdir, stat } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginDir = path.join(here, '..', 'plugin')
/** 发行目录里的镜像（同步过后两份必须逐字节一致） */
const mirrorPluginDir = path.resolve(here, '..', '..', '..', 'tsweb-dist-lite', 'plugins', 'promotion', 'plugin')

/** 本插件程序集名（改名后的新身份） */
const ASSEMBLY = 'Promotion'

/**
 * 阳性对照：与本功能无关但必然出现在本程序集元数据里的名字。
 * 注意 'TerrariaPlugin' 是基类名、'Initialize' 是覆写方法名、'SecureRestCommand'/'PlayerPostLogin'
 * 是框架类型名——它们的存在只说明"这确实是一个编译好的 TShock 插件程序集"。
 */
const POSITIVE_CONTROLS = ['TerrariaPlugin', 'Initialize', 'SecureRestCommand', 'PlayerPostLogin']

/** 目标串：两类晋升依据的本体（类型名 / 方法名 / 端点 / SQL 表名 / 文件名 / 文案） */
const TARGETS = [
  ['PromotionPlugin', '游戏服半的插件入口类型（注册路由与两种触发点的地方）'],
  ['PromotionConfig', '统一配置模型（qqBind / playtimeThresholds / ignoreGroups）'],
  ['PromotionThresholds', '游玩时长晋升模块（GameUpdate 节拍里检查）'],
  ['PromotionEndpoints', 'REST 端点'],
  ['PromotionBindings', '只读绑定快照的读取器'],
  ['TryPromoteOnLogin', '登录时的 QQ 绑定晋升识别方法'],
  ['TryPromote', '晋升判定与改组方法（两种依据共用）'],
  ['IsGroupAtOrAbove', '父组链判断（防成环）'],
  ['CheckAutoPromotion', '游玩时长晋升的检查方法'],
  ['IsInIgnoreGroup', '忽略组的父链判定（时长晋升入口）'],
  ['/data/promotion/snapshot', '配置接收端点路由字面量'],
  ['/data/promotion/status', '状态端点路由字面量'],
  ['player_daily_stat', '它**只读**计时的表名（SELECT SUM(daily_min)）'],
  ['GameUpdate', '计时节拍挂钩的事件名'],
  ['SetUserGroup', '真正改组的调用'],
  ['SendSuccessMessage', '晋升后给在线玩家的提示'],
  ['promotion_config.json', '旧版配置文件名（冷启动迁移的来源）'],
  ['qqbind-snapshot.json', '它只读的 qq-bind 绑定快照文件名'],
  ['QQ绑定登录识别', '旧版 QQ.cs:194 的 reason 文案，必须逐字进 DLL'],
  ['DefaultIgnoreGroups', '保护默认值的取用点（缺失回落的实现）'],
  ['owner', '保护默认值之一（编译进 DLL 的字面量）'],
  ['superadmin', '保护默认值之一（编译进 DLL 的字面量）'],
]

/**
 * 阴性对照：任何情况下都不该出现在本 DLL 里的串。
 * ① 编造的哨兵串：证明扫描有区分度
 * ② 旧身份：证明"改名"真的落进了产物（插件名/程序集名/旧配置文件名）
 * ③ qq-bind 的程序集命名空间：证明没有程序集耦合（各读快照文件的设计取向）
 * ④ 写入 player_daily_stat 的语句与整点快照表：证明没有双倍计时长、没有越界做 online-stats 的事
 */
const NEGATIVE_CONTROLS = [
  ['TSWEB_DLL_SCAN_NEGATIVE_CONTROL_9f3ab7c1', '编造的哨兵串（阴性对照）'],
  ['QqPromotion', '旧程序集/类型名前缀（改名后不应存在）'],
  ['qq-promotion-config.json', '旧配置文件名（改名后不应存在）'],
  ['TsWebQqBind', 'qq-bind 的程序集命名空间（不该有程序集耦合）'],
  ['INSERT INTO player_daily_stat', '写入时长表的语句（会造成双倍计时长）'],
  ['daily_min + 1', '时长自增片段（会造成双倍计时长）'],
  ['hourly_online_snapshot', '整点在线快照表（那是 online-stats 的职责）'],
]

async function findDll() {
  let entries = []
  try {
    entries = await readdir(pluginDir)
  } catch (err) {
    assert.fail(`读不到 plugin 目录：${pluginDir}（${err.message}）`)
  }
  const dlls = entries.filter((f) => f.toLowerCase().endsWith('.dll'))
  assert.ok(
    dlls.length > 0,
    `plugin/ 下没有任何 .dll —— 请先构建：\n`
    + `    node scripts/pack-plugin.mjs promotion --check\n`
    + `  （或 dotnet build plugins/promotion/plugin/Promotion.csproj -c Release）`,
  )
  assert.equal(dlls.length, 1, `plugin/ 下应只有本插件自己的 DLL（不许留下旧名产物），实际有：${dlls.join(', ')}`)
  assert.equal(dlls[0], `${ASSEMBLY}.dll`, `DLL 文件名必须是 ${ASSEMBLY}.dll（改名后的新身份）`)
  return path.join(pluginDir, dlls[0])
}

/**
 * 在字节里找 .NET 的字符串——**必须同时扫两种编码**，否则会得出错误结论：
 *   - 类型名 / 方法名 / 字段名等元数据字符串 → #Strings 堆，**UTF-8**
 *   - 字符串字面量（如 `"qqbind-snapshot.json"`、`"owner"`）→ #US 堆，**UTF-16LE**
 * 实测教训：先用 PowerShell 的 `[Encoding]::UTF8.GetString(...).IndexOf('owner')` 扫，
 * 竟然"命中"了——因为 UTF-16LE 的 "o\0w\0n\0e\0r" 解码后含 NUL，而 .NET 的
 * `String.IndexOf(string)` 默认是**文化敏感**比较、会忽略零权字符（NUL），于是给出了假阳性。
 * 所以这里用 Node 按字节扫，并显式覆盖两种编码。
 */
function containsString(buf, s) {
  return buf.indexOf(Buffer.from(s, 'utf8')) >= 0 || buf.indexOf(Buffer.from(s, 'utf16le')) >= 0
}

test('插件 DLL 存在且体积合理（空文件/半截文件直接失败）', async () => {
  const dll = await findDll()
  const st = await stat(dll)
  assert.ok(st.size > 4096, `DLL 体积异常小（${st.size} B），疑似构建失败或占位文件：${dll}`)
  const buf = await readFile(dll)
  assert.equal(buf.subarray(0, 2).toString('latin1'), 'MZ', '不是合法的 PE 文件（应为 MZ 开头）')
})

test('阳性对照：本功能无关的元数据字符串必须命中（证明扫描有效、扫的是插件程序集）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const missing = POSITIVE_CONTROLS.filter((s) => !containsString(buf, s))
  assert.deepEqual(
    missing, [],
    `阳性对照未命中：${missing.join('、')} —— 说明扫描本身失效或扫错了文件，此时"目标串命中"没有意义`,
  )
})

test('阴性对照：编造的哨兵串必须扫不到（证明命中是有区分度的）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  assert.equal(containsString(buf, NEGATIVE_CONTROLS[0][0]), false, '阴性对照居然命中了，扫描逻辑不可信')
})

test('目标串：两类晋升依据的类型/方法/端点/SQL/文件名/文案必须都在 DLL 里', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const missing = TARGETS.filter(([s]) => !containsString(buf, s))
  assert.deepEqual(
    missing.map(([s]) => s), [],
    '晋升代码没有真正进到将被打包下发的 DLL 里（这正是 qq-bind 实测踩过的缺陷：\n'
    + '  plugin/QqBind.dll 里没有 QqPromotion/TryPromoteOnLogin，而 obj/Release 里有）。\n'
    + '  缺的是：\n'
    + missing.map(([s, why]) => `    - ${s}：${why}`).join('\n')
    + '\n  修复方向：删掉 plugin/bin、plugin/obj 后重建（或加 --rebuild），并确认打包不再从陈旧 bin 回拷。',
  )
})

test('改名落地：旧身份（QqPromotion / 旧配置文件名）不得出现在 DLL 里', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  for (const [s, why] of NEGATIVE_CONTROLS.slice(1, 3)) {
    assert.equal(containsString(buf, s), false, `DLL 里出现了 "${s}"：${why}`)
  }
  // 反过来必须出现新身份（否则上面的"扫不到"可能是"扫错了文件"）
  assert.equal(containsString(buf, 'PromotionPlugin'), true, '新身份 PromotionPlugin 必须存在')
  assert.equal(containsString(buf, 'promotion-config.json'), true, '新配置文件名必须存在')
})

test('不引用 QqBind.dll：DLL 里不存在 qq-bind 的程序集命名空间 TsWebQqBind', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  // 说明：不能用 "QqBind" 这个大小写做判据 —— 本件自己的配置模型里就有
  // QqBindPromotionConfig 类型与 QqBind 属性（那是**本件的**配置结构，不是对 qq-bind 的引用），
  // 而 qq-bind 的程序集命名空间是 TsWebQqBind，它才是"程序集耦合"的可靠判据。
  assert.equal(
    containsString(buf, 'TsWebQqBind'), false,
    'DLL 里出现了 "TsWebQqBind" —— 说明本插件引用了 QqBind.dll；'
    + '设计 §7.3 要求各自读快照文件以避免程序集耦合（卸载/热重载时"A 卸了 B 就崩"）。',
  )
  assert.equal(containsString(buf, 'qqbind-snapshot.json'), true, '但快照文件名必须存在（它靠这个文件识别绑定）')
})

test('★★ 双倍计时长防护：DLL 里没有任何写入 player_daily_stat 的语句 ★★', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)

  // 正面：读时长的那条 SELECT 必须在（否则"时长晋升"根本没法工作）
  assert.equal(
    containsString(buf, 'player_daily_stat'), true,
    'DLL 里没有 player_daily_stat —— 时长晋升的 SELECT 缺失，这条功能等于没做',
  )
  assert.equal(
    containsString(buf, 'COALESCE(SUM(daily_min)'), true,
    'DLL 里没有 SELECT COALESCE(SUM(daily_min) ...) —— 读时长的语句缺失',
  )

  // 反面：任何写入形式都不许出现
  const forbidden = NEGATIVE_CONTROLS.slice(4)
  for (const [s, why] of forbidden) {
    assert.equal(
      containsString(buf, s), false,
      `DLL 里出现了 "${s}"：${why}。\n`
      + '  player_daily_stat 的每分钟 +1 由 online-stats 插件负责'
      + '（plugins/online-stats/plugin/OnlineStatsData.cs:130-153），\n'
      + '  本插件若再累加一次，玩家的累计时长会翻倍、所有时长阈值提前一半触发。',
    )
  }

  // 再看一眼 SQL 动词：本 DLL 里出现的 player_daily_stat 只能跟在 SELECT 后面
  const sqls = extractSqlStatements(buf)
  const touching = sqls.filter((s) => s.includes('player_daily_stat'))
  assert.ok(touching.length >= 1, '至少应能抽出那条 SELECT（若为 0，说明抽取逻辑失效，本用例的"反面断言"不可信）')
  for (const sql of touching) {
    assert.match(sql, /^\s*SELECT\b/i, `访问 player_daily_stat 的语句必须是 SELECT：${sql}`)
  }
})

test('发行目录镜像里的 DLL 与源码目录逐字节一致（同步后不许有第二份不同内容）', async () => {
  const dll = await findDll()
  const mirror = path.join(mirrorPluginDir, path.basename(dll))
  let mirrorBuf
  try {
    mirrorBuf = await readFile(mirror)
  } catch (err) {
    if (err.code === 'ENOENT') {
      // 镜像目录不存在（例如别人只 checkout 了源码目录）→ 跳过，不误报
      return
    }
    throw err
  }
  const src = await readFile(dll)
  const sha = (b) => createHash('sha256').update(b).digest('hex')
  assert.equal(
    sha(mirrorBuf), sha(src),
    `两份 DLL 内容不一致：\n  源码 ${dll}\n  镜像 ${mirror}\n  请重新同步（镜像必须逐字节一致）`,
  )
})

/**
 * 从 DLL 字节里抽 SQL 语句片段（**只用于上面那条"访问 player_daily_stat 的语句必须是 SELECT"**）。
 *
 * 抽取范围：以 SELECT/INSERT/UPDATE/DELETE/CREATE 开头、到分号或串尾的一段。
 *
 * **两种编码 × 两种对齐都要抽**：字符串字面量在 #US 堆里是 UTF-16LE，而该堆在文件里的
 * 起始偏移**不保证是偶数**（实测本 DLL 就是奇数偏移）——只按 offset 0 解一次会把整段解成乱码，
 * 于是"抽不到任何 SQL"而让反面断言变成空断言（假通过）。所以这里连 `subarray(1)` 一起扫。
 */
function extractSqlStatements(buf) {
  const texts = [
    buf.toString('latin1'),
    buf.toString('utf16le').replace(/\u0000/g, ''),
    buf.subarray(1).toString('utf16le').replace(/\u0000/g, ''),
  ]
  const out = []
  for (const text of texts) {
    const re = /\b(?:SELECT|INSERT|UPDATE|DELETE|CREATE)\b[^\u0000]{0,240}/gi
    let m
    while ((m = re.exec(text)) !== null) {
      const sql = m[0].replace(/[\u0000-\u001f]+/g, ' ').trim()
      // 只保留真的像 SQL 的片段（含 " FROM " / " INTO " / " TABLE " / " SET " 之类）
      if (/\b(FROM|INTO|TABLE|SET)\b/i.test(sql)) out.push(sql)
    }
  }
  return out
}
