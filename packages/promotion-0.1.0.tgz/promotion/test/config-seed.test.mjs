/**
 * 旧配置迁移 seed 测试（qq-bind 的 promotion 块 → 本件 <dataDir>/promotion/config.json）
 *
 * 背景：QQ 绑定晋升原来内嵌在 qq-bind 里，摘除时**刻意保留了用户原值**（qq-bind 的
 * mergeConfig 原样透传未知字段），本机实测该值是
 *   { enabled: false, targetGroup: 'vip', mode: 'auto', ignoreGroups: ['owner','superadmin'] }
 * —— 注意这组值恰好与本件默认值相同，所以"到底采用没采用旧值"用它是测不出来的：
 * 本文件的正式用例都用**与默认值明显不同**的旧值，才能把"采用了"和"回落默认"区分开。
 *
 * ★ 本次改造的核心（相对上一版）：**字段映射变了**。
 *   旧块是扁平的 { enabled, targetGroup, mode, ignoreGroups }，新配置是
 *   { qqBind: { enabled, targetGroup, mode }, playtimeThresholds, ignoreGroups }：
 *     enabled/targetGroup/mode → qqBind 下的同名三字段
 *     ignoreGroups             → **顶层**（两种晋升依据共享的保护名单，照旧版权威结构）
 *     playtimeThresholds       → 保持**空数组**（旧块没有对应字段，迁移不猜测时长规则）
 *   映射表见 seed.js 的 LEGACY_FIELD_MAP。
 *
 * 覆盖（对应任务要求逐条）：
 *   1. 无自己的配置 + qq-bind 有 promotion → 按**新结构**采用旧值（逐字段断言）+ 写审计 + 记日志
 *   2. 无自己的配置 + qq-bind 没有 promotion 块 → 用默认值、不报错、不写审计
 *   3. 无自己的配置 + qq-bind 未安装 → 用默认值、不抛错、**不写"已迁移"日志**
 *   4. 自己的配置已存在 → 不 seed、不覆盖（哪怕旧值不同）；且 seed 只发生一次（幂等）
 *   5. 旧值畸形（mode 非法 / ignoreGroups 非数组 / targetGroup 空）→ 归一后落盘，非法值不落盘
 *   6. 旧块只给了部分字段 → 只采用存在的字段，其余用本件默认值
 *   7. 回归护栏：宿主半不直接属性访问未 inject 的服务（软依赖必须走 ctx.get）
 *   8. **新增**：旧块里的 ignoreGroups 必须落到**顶层**（不是塞进 qqBind 里）
 *   9. **新增**：迁移不得产生任何时长规则（playtimeThresholds 必须是空数组）
 *  10. **新增**：qq-bind 未安装时，管理接口要如实报告"QQ 绑定提升不可用 + 原因"
 *
 * 另外锁住两条副作用要求：
 *   - 迁移**不删除** qq-bind 配置里的旧 promotion 块（读回逐字段比对）
 *   - 迁移日志只报来源与**字段名**，不含配置内容
 *
 * 注意：本测试不启动任何服务进程（复用 test/support/fake-host.mjs 的假宿主）。
 * 运行：node test/config-seed.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, readFile, writeFile, mkdir } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

import { apply } from '../index.js'
import { defaultConfig, normalizeConfig } from '../config.js'
import {
  LEGACY_FIELD_MAP,
  LEGACY_SOURCE_PLUGIN,
  optionalService,
  qqBindAvailability,
  seedFromLegacyPromotion,
} from '../seed.js'
import { makeFakeHost } from './support/fake-host.mjs'

let dir
let seq = 0

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), 'promotion-seed-'))
})

after(async () => {
  await rm(dir, { recursive: true, force: true })
})

/** 本件数据目录 / 配置文件 / 审计文件；假宿主的 dataOf(n) = <dataDir>/n */
function ownConfigFile(dataDir) {
  return path.join(dataDir, 'promotion', 'config.json')
}
function ownAuditFile(dataDir) {
  return path.join(dataDir, 'promotion', 'audit.jsonl')
}
function legacyConfigFile(dataDir) {
  return path.join(dataDir, LEGACY_SOURCE_PLUGIN, 'config.json')
}

/** 读 JSON 文件；不存在返回 null（"文件没被写出来"本身是要断言的事实） */
async function readJsonOrNull(file) {
  try {
    return JSON.parse(await readFile(file, 'utf8'))
  } catch (err) {
    if (err.code === 'ENOENT') return null
    throw err
  }
}

/** 读审计行（不存在 → 空数组） */
async function readAudit(file) {
  try {
    const raw = await readFile(file, 'utf8')
    return raw.split('\n').filter((l) => l.trim() !== '').map((l) => JSON.parse(l))
  } catch (err) {
    if (err.code === 'ENOENT') return []
    throw err
  }
}

/**
 * 起一个宿主并 await apply。
 *   qqBind：false = 模拟"qq-bind 未安装"（ctx.get('qqBind') 取不到）；
 *           对象 = 模拟服务已注册（真实宿主里由 qq-bind 的 Service 注册）
 *   legacy：写进 qq-bind 配置文件的内容（外层对象原样写；promotion 块由调用方给出或省略）
 *   ownConfig：预置本件自己的配置文件内容（模拟"不是首次运行"）
 *
 * 捕获 apply 期间的 console 输出：本用例要断言"迁移日志写了 / 没写"，
 * 而 _seedFromLegacyQqBind 在 init 内同步 await 完成，所以 apply 返回时日志已经产出。
 */
async function boot({ legacy, qqBind = {}, ownConfig } = {}) {
  seq += 1
  const dataDir = path.join(dir, `case-${seq}`)

  if (legacy !== undefined) {
    await mkdir(path.dirname(legacyConfigFile(dataDir)), { recursive: true })
    await writeFile(legacyConfigFile(dataDir), JSON.stringify(legacy, null, 2), 'utf8')
  }
  if (ownConfig !== undefined) {
    await mkdir(path.dirname(ownConfigFile(dataDir)), { recursive: true })
    await writeFile(ownConfigFile(dataDir), JSON.stringify(ownConfig, null, 2), 'utf8')
  }

  const services = qqBind === false ? {} : { qqBind: qqBind === true ? {} : qqBind }
  // 没有启用中的服务器：本用例只关心 seed，不关心下发（去掉异步下发的噪声）
  const host = makeFakeHost({ dataDir, servers: [], services, fetchFor: async () => ({ ok: true, status: 200, data: {} }) })

  const logs = []
  const origLog = console.log
  const origErr = console.error
  console.log = (...a) => logs.push(a.map(String).join(' '))
  console.error = (...a) => logs.push(a.map(String).join(' '))
  let dispose
  try {
    dispose = await apply(host.ctx)
  } finally {
    console.log = origLog
    console.error = origErr
  }
  await new Promise((r) => setTimeout(r, 20)) // 让启动对账走到"没有服务器"的结论

  return { dataDir, host, dispose, logs }
}

// ═══════════════ 1. 采用旧值（按新结构） ═══════════════

test('① 无自己的配置 + qq-bind 有 promotion → 映射进新结构（qqBind 三字段 + 顶层 ignoreGroups）', async () => {
  const { dataDir, dispose, logs } = await boot({
    legacy: { promotion: { enabled: true, targetGroup: 'gold', mode: 'force', ignoreGroups: ['helper', 'moderator'] } },
  })
  try {
    const written = await readJsonOrNull(ownConfigFile(dataDir))
    assert.ok(written, '首次运行必须把迁移结果落盘（否则下次启动又要迁移一遍）')

    // 旧 enabled/targetGroup/mode → qqBind 下同名三字段
    assert.deepEqual(written.qqBind, { enabled: true, targetGroup: 'gold', mode: 'force' })
    // 旧 ignoreGroups → **顶层**（不是塞进 qqBind 里）
    assert.deepEqual(written.ignoreGroups, ['helper', 'moderator'])
    assert.equal(written.ignoreGroups !== undefined && written.qqBind.ignoreGroups === undefined, true,
      'ignoreGroups 必须在顶层：它是两种晋升依据共享的保护名单（旧版权威结构 PromotionConfig.cs:56-70）')
    // 旧块没有时长规则 → 迁移不猜测
    assert.deepEqual(written.playtimeThresholds, [])
    // 顶层字段就是旧版那三个
    assert.deepEqual(Object.keys(written).sort(), ['ignoreGroups', 'playtimeThresholds', 'qqBind'])

    // 审计：promotion.config.seed（actor=system，与人工的 admin/terminal 区分开）
    const audit = await readAudit(ownAuditFile(dataDir))
    const seedRow = audit.find((r) => r.action === 'promotion.config.seed')
    assert.ok(seedRow, '迁移必须写一条 promotion.config.seed 审计')
    assert.equal(seedRow.actor, 'system')
    assert.equal(seedRow.source, LEGACY_SOURCE_PLUGIN)
    assert.deepEqual(seedRow.keys.sort(), ['enabled', 'ignoreGroups', 'mode', 'targetGroup'],
      '审计里记的是**旧字段名**（便于与 qq-bind 文件对照）')

    // 日志：只报来源与字段名，不含配置内容
    const migrated = logs.filter((l) => l.includes('已从 qq-bind 旧配置迁移'))
    assert.equal(migrated.length, 1, '必须恰好记一条迁移日志')
    assert.ok(migrated[0].includes(legacyConfigFile(dataDir)), '日志要点出来源路径')
    assert.ok(!migrated[0].includes('gold'), '日志不得包含配置内容本身')
  } finally {
    dispose()
  }
})

test('①-2 迁移映射表本身：LEGACY_FIELD_MAP 与 seedFromLegacyPromotion 的产物逐条对应', () => {
  assert.deepEqual(LEGACY_FIELD_MAP, {
    enabled: 'qqBind.enabled',
    targetGroup: 'qqBind.targetGroup',
    mode: 'qqBind.mode',
    ignoreGroups: 'ignoreGroups',
  })
  const r = seedFromLegacyPromotion({ enabled: true, targetGroup: 'gold', mode: 'force', ignoreGroups: ['a'] })
  assert.deepEqual(r.config.qqBind, { enabled: true, targetGroup: 'gold', mode: 'force' })
  assert.deepEqual(r.config.ignoreGroups, ['a'])
  assert.deepEqual(r.config.playtimeThresholds, [])
  assert.deepEqual(r.adopted.sort(), ['enabled', 'ignoreGroups', 'mode', 'targetGroup'])
  assert.deepEqual(r.skipped, [])
})

// ═══════════════ 2. 没有可迁移的旧值 ═══════════════

test('② 无自己的配置 + qq-bind 没有 promotion 块 → 用默认值、不报错、不写审计', async () => {
  const { dataDir, dispose, logs } = await boot({ legacy: { schema: 1, syncAccounts: true } })
  try {
    assert.equal(await readJsonOrNull(ownConfigFile(dataDir)), null, '没有可迁移的值就不该写配置文件')
    assert.deepEqual(await readAudit(ownAuditFile(dataDir)), [], '没迁移就不该写审计')
    assert.equal(logs.filter((l) => l.includes('已从 qq-bind 旧配置迁移')).length, 0, '不写"已迁移"日志')
    assert.ok(logs.some((l) => l.includes('按默认配置运行')), '应记一条"按默认配置运行"')
  } finally {
    dispose()
  }
})

test('③ qq-bind 未安装 → 用默认值、不抛错、不写"已迁移"日志', async () => {
  const { dataDir, dispose, logs } = await boot({ qqBind: false })
  try {
    assert.equal(await readJsonOrNull(ownConfigFile(dataDir)), null)
    assert.deepEqual(await readAudit(ownAuditFile(dataDir)), [])
    assert.equal(logs.filter((l) => l.includes('已从 qq-bind 旧配置迁移')).length, 0)
    assert.equal(logs.filter((l) => l.includes('初始化失败')).length, 0, '软依赖缺失绝不能让插件加载失败')
  } finally {
    dispose()
  }
})

// ═══════════════ 3. 只迁移一次（幂等），不覆盖已有配置 ═══════════════

test('④ 自己的配置已存在 → 不 seed、不覆盖（哪怕旧值不同）；重跑一次仍不覆盖', async () => {
  const own = {
    qqBind: { enabled: false, targetGroup: 'vip', mode: 'auto' },
    playtimeThresholds: [{ minutes: 120, targetGroup: 'vip', mode: 'auto' }],
    ignoreGroups: ['owner'],
  }
  const { dataDir, dispose } = await boot({
    legacy: { promotion: { enabled: true, targetGroup: 'gold', mode: 'force', ignoreGroups: ['helper'] } },
    ownConfig: own,
  })
  try {
    const written = await readJsonOrNull(ownConfigFile(dataDir))
    assert.deepEqual(written, own, '已有配置必须原样保留（用户可能已经在本件里改过）')
    assert.deepEqual(await readAudit(ownAuditFile(dataDir)), [], '不该有 seed 审计')

    // 再起一次（模拟第二次启动）：仍然不动
    const second = await boot({
      legacy: { promotion: { enabled: true, targetGroup: 'gold', mode: 'force', ignoreGroups: ['helper'] } },
      ownConfig: own,
    })
    try {
      assert.deepEqual(await readJsonOrNull(second.dataDir === dataDir ? ownConfigFile(dataDir) : ownConfigFile(second.dataDir)), own)
      assert.deepEqual(await readAudit(ownAuditFile(second.dataDir)), [], '第二次启动同样不写审计')
    } finally {
      second.dispose()
    }
  } finally {
    dispose()
  }
})

// ═══════════════ 4. 畸形旧值 ═══════════════

test('⑤ 旧值畸形 → 归一后落盘：非法 mode → force、非数组非字符串 ignoreGroups → 保护默认值、空 targetGroup 不采用', async () => {
  const { dataDir, dispose, logs } = await boot({
    legacy: {
      promotion: {
        enabled: true,
        targetGroup: '   ',     // 空白 → 不采用，回落本件默认组 vip
        mode: 'whatever',       // 非 auto → force
        ignoreGroups: 123,      // 非数组非字符串 → 保护默认值（绝不能是空名单）
      },
    },
  })
  try {
    const written = await readJsonOrNull(ownConfigFile(dataDir))
    assert.deepEqual(written.qqBind, { enabled: true, targetGroup: 'vip', mode: 'force' })
    assert.deepEqual(written.ignoreGroups, ['owner', 'superadmin'], '非法 ignoreGroups 必须回落保护默认值（不能是空名单）')
    const migrated = logs.find((l) => l.includes('已从 qq-bind 旧配置迁移'))
    assert.ok(migrated.includes('未采用'), '被跳过的字段要在日志里点名（targetGroup）')
  } finally {
    dispose()
  }
})

test('⑤-1 旧 ignoreGroups 是字符串时按分隔符拆分（与旧版 DedupIgnoreGroups 口径一致）', () => {
  // 旧版是 List<string>，Newtonsoft 能把 "a,b" 反序列化成列表；本件对字符串也做同样的事，
  // 所以 'oops' 会被当成**一个组名**（而不是"非法值回落默认"）。
  assert.deepEqual(normalizeConfig({ ignoreGroups: 'a,b;c d' }).ignoreGroups, ['a', 'b', 'c', 'd'])
  const r = seedFromLegacyPromotion({ ignoreGroups: 'helper' })
  assert.deepEqual(r.config.ignoreGroups, ['helper'])
  assert.deepEqual(r.adopted, ['ignoreGroups'])
})

test('⑤-2 旧值畸形（纯函数层）：adopted / skipped 的划分逐条正确', () => {
  const r = seedFromLegacyPromotion({
    enabled: 'yes',            // 非布尔 → skipped
    targetGroup: '',           // 空 → skipped
    mode: 'AUTO',              // 归一为 auto
    ignoreGroups: [' A ', 'a', ''], // 去重 + trim + 剔空
  })
  assert.deepEqual(r.config.qqBind, { enabled: false, targetGroup: 'vip', mode: 'auto' })
  assert.deepEqual(r.config.ignoreGroups, ['A'])
  assert.deepEqual(r.skipped.sort(), ['enabled', 'targetGroup'])
  assert.deepEqual(r.adopted.sort(), ['ignoreGroups', 'mode'])

  // enabled 为 null / undefined 也算 skipped（保持默认 false，安全方向）
  const r2 = seedFromLegacyPromotion({ enabled: null, targetGroup: undefined })
  assert.equal(r2.config.qqBind.enabled, false)
  assert.deepEqual(r2.adopted, [])
  assert.deepEqual(r2.skipped.sort(), ['enabled', 'targetGroup'])

  // 整个旧块不是对象 → 原样返回默认配置
  const r3 = seedFromLegacyPromotion('nope')
  assert.deepEqual(r3.config, defaultConfig())
  assert.deepEqual(r3.adopted, [])
})

test('⑥ 旧块只给了部分字段 → 只采用存在的字段，其余用本件默认值', async () => {
  const { dataDir, dispose } = await boot({ legacy: { promotion: { targetGroup: 'gold' } } })
  try {
    const written = await readJsonOrNull(ownConfigFile(dataDir))
    assert.deepEqual(written.qqBind, { enabled: false, targetGroup: 'gold', mode: 'auto' })
    assert.deepEqual(written.ignoreGroups, ['owner', 'superadmin'], '旧块没给 ignoreGroups → 本件默认保护名单')
    assert.deepEqual(written.playtimeThresholds, [])
  } finally {
    dispose()
  }
})

// ═══════════════ 5. 副作用与软依赖护栏 ═══════════════

test('迁移**不删除** qq-bind 配置里的旧 promotion 块（回退/排查要靠它取材）', async () => {
  const legacy = {
    schema: 1,
    syncAccounts: true,
    promotion: { enabled: true, targetGroup: 'gold', mode: 'force', ignoreGroups: ['helper'] },
  }
  const { dataDir, dispose } = await boot({ legacy })
  try {
    const after = await readJsonOrNull(legacyConfigFile(dataDir))
    assert.deepEqual(after, legacy, 'qq-bind 的配置文件必须逐字段保持原样（本件只读它）')
  } finally {
    dispose()
  }
})

test('⑦ 回归护栏：宿主半不直接属性访问未 inject 的服务（软依赖必须走 ctx.get）', async () => {
  const here = path.dirname(fileURLToPath(import.meta.url))
  for (const rel of ['../index.js', '../seed.js']) {
    const src = await readFile(path.resolve(here, rel), 'utf8')
    const lines = src.split(/\r?\n/)
    const hits = []
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]
      // 只查代码部分（朴素去注释：够用且不会漏报本用例关心的形态）
      const trimmed = line.trim()
      if (trimmed.startsWith('//') || trimmed.startsWith('*') || trimmed.startsWith('/*')) continue
      const code = line.includes('//') ? line.slice(0, line.indexOf('//')) : line
      if (/(?:this\.)?ctx\.qqBind\b/.test(code)) hits.push(`${rel}:${i + 1} ${trimmed}`)
    }
    assert.deepEqual(
      hits,
      [],
      'qqBind 是本件的软依赖（不在 inject 里），直接属性访问会抛 cannot get property "qqBind" without inject：\n' + hits.join('\n'),
    )
  }
})

test('⑧ 软依赖判定：qq-bind 未安装时给出"不可用 + 原因"，装了就报可用', () => {
  const no = qqBindAvailability({ get: () => undefined })
  assert.equal(no.installed, false)
  assert.match(no.reason, /qq-bind/, '原因里要点名缺的是哪个插件')
  assert.match(no.reason, /游玩时长提升/, '原因里要说清"哪些功能不受影响"')

  const yes = qqBindAvailability({ get: (n) => (n === 'qqBind' ? {} : undefined) })
  assert.equal(yes.installed, true)
  assert.equal(yes.reason, '')

  // ctx.get 抛错（未 inject 的代理形态）也要被吞掉并按"未安装"处理
  const throwing = qqBindAvailability({
    get: () => { throw new Error('cannot get property "qqBind" without inject') },
  })
  assert.equal(throwing.installed, false)
})

test('⑨ 管理接口如实报告软依赖状态（qq-bind 未安装 → 前端的 QQ 卡片据此显示不可用）', async () => {
  const { host, dispose } = await boot({ qqBind: false })
  try {
    const res = await host.call('get', '/api/promotion/config')
    assert.equal(res.status, 200)
    assert.equal(res.data.dependencies.qqBind.installed, false)
    assert.match(res.data.dependencies.qqBind.reason, /qq-bind/)

    // 「游玩时长提升」不受软依赖影响：配置里的时长规则照常可读可写
    const save = await host.call('post', '/api/promotion/config', {
      body: { updates: { playtimeThresholds: [{ minutes: 60, targetGroup: 'vip', mode: 'auto' }] } },
    })
    assert.equal(save.status, 200, 'QQ 绑定提升不可用时，时长规则必须照常可保存')
    assert.equal(save.data.config.playtimeThresholds.length, 1)
  } finally {
    dispose()
  }
})

test('⑩ 迁移不产生任何时长规则（旧块没有对应字段，迁移不许猜测）', () => {
  // 就算旧块里混进了 playtimeThresholds（理论上不该有），迁移也必须把它当"不认识的字段"忽略
  const r = seedFromLegacyPromotion({
    enabled: true,
    targetGroup: 'gold',
    mode: 'auto',
    ignoreGroups: ['helper'],
    playtimeThresholds: [{ minutes: 999, targetGroup: 'vip', mode: 'auto' }],
  })
  assert.deepEqual(r.config.playtimeThresholds, [], '迁移产物必须是空数组（时长规则由管理员在新界面里配置）')
})

test('落盘产物必须是归一形态（normalizeConfig 认可的形状）', () => {
  const r = seedFromLegacyPromotion({ enabled: true, targetGroup: ' gold ', mode: 'FORCE', ignoreGroups: ['helper', 'HELPER'] })
  assert.deepEqual(r.config, normalizeConfig(r.config), 'seed 产物必须与归一后的形状一致（避免"落盘后又变一次"）')
  assert.equal(r.config.qqBind.targetGroup, 'gold')
  assert.equal(r.config.qqBind.mode, 'force')
  assert.deepEqual(r.config.ignoreGroups, ['helper'])
})
