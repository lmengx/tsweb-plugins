/**
 * 游玩时长晋升算法测试（**JS 等价镜像**，语义双保险）—— 本次改造**新增**的用例
 *
 * 镜像对象：plugins/promotion/plugin/PromotionThresholds.cs
 *   OnGameUpdate      计时节拍       ← 旧版 TsWeb/plugin/OnlineData.cs:71-84
 *   CheckAutoPromotion 晋升算法      ← 旧版 TsWeb/plugin/OnlineData.cs:127-198
 *   IsInIgnoreGroup    忽略组（父链）← 旧版 TsWeb/plugin/OnlineData.cs:203-227
 *   QueryTotalMinutes  只读 SELECT   ← 旧版 TsWeb/plugin/OnlineData.cs:161-167
 *
 * ★ 这条测试能证明什么、不能证明什么（与 promotion-rules.test.mjs 同一口径）：
 *   C# 的 CheckAutoPromotion 依赖 TShock 运行时（TShock.Players / TShock.Groups / TShock.DB），
 *   本机跑不起来。所以这里放一份**逐条对应**的 JS 镜像，把算法顺序与边界情况钉死。
 *   这是**语义双保险**，**不是**对 C# 实现的覆盖；C# 那侧只有编译层与字节层证据。
 *
 * ★ 本文件还额外钉住一条本次任务的硬约束：**本插件不得累加游玩时长**。
 *   镜像里的查询是只读 SELECT（对应 PromotionThresholds.QueryTotalMinutes），
 *   而"写入"这件事在本插件的语义里根本不存在 —— 写入由 online-stats 的 DLL 负责
 *   （plugins/online-stats/plugin/OnlineStatsData.cs:130-153）。源码/字节层的断言见
 *   test/promotion-source.test.mjs 与 test/dll-content.test.mjs。
 *
 * 运行：node test/playtime-rules.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'

import { DEFAULT_IGNORE_GROUPS } from '../config.js'

// ════════════════════════════════════════════════════════════
//  镜像实现（对应 plugins/promotion/plugin/PromotionThresholds.cs）
// ════════════════════════════════════════════════════════════

/** 对应 PromotionThresholds.TicksPerMinute（旧版 OnlineData.cs:74）：60 tick/秒 → 3600 tick ≈ 1 分钟 */
const TICKS_PER_MINUTE = 3600

/**
 * 对应 PromotionThresholds.IsInIgnoreGroup（旧版 OnlineData.cs:203-227）：
 * **沿父组链**逐个比对忽略组，visited 防环，大小写不敏感。
 */
function isInIgnoreGroup(group, config) {
  if (!group || !config.ignoreGroups) return false
  for (const ignore of config.ignoreGroups) {
    if (String(group.name).toLowerCase() === String(ignore).toLowerCase()) return true
    let current = group
    const visited = new Set()
    while (current) {
      const name = String(current.name).toLowerCase()
      if (visited.has(name)) break // 成环：立即退出
      visited.add(name)
      if (name === String(ignore).toLowerCase()) return true
      current = current.parent || null
    }
  }
  return false
}

/**
 * 对应 PromotionThresholds.CheckAutoPromotion（旧版 OnlineData.cs:127-198）。
 *
 * @param {object} input
 *   config   统一配置 { playtimeThresholds, ignoreGroups }
 *   players  在线玩家数组：{ name, active, isLoggedIn, account, group }
 *   query    (playerName) => number，取该玩家累计分钟数；**抛异常**表示查询失败
 *   promote  (account, targetGroup, mode, player, reason) => void，记录一次晋升
 * @returns {{ promotions: object[], skipped: string[] }}
 */
function checkAutoPromotion({ config, players, query, promote }) {
  const promotions = []
  const skipped = []

  // 1. 旧版 OnlineData.cs:133-134：阈值列表为空/为 null → 直接返回
  const thresholds = config.playtimeThresholds
  if (!Array.isArray(thresholds) || thresholds.length === 0) return { promotions, skipped }

  // 2. 旧版 OnlineData.cs:137-143：Minutes > 0 且 TargetGroup 非空，按 Minutes **降序**
  const sorted = thresholds
    .filter((t) => t && t.minutes > 0 && t.targetGroup)
    .slice()
    .sort((a, b) => b.minutes - a.minutes)

  if (sorted.length === 0) return { promotions, skipped }

  for (const player of players) {
    // 3. 旧版 OnlineData.cs:147-151
    if (!player || !player.active || !player.isLoggedIn) continue
    if (!player.account || !player.group) continue

    // 4. 旧版 OnlineData.cs:154-155：忽略组（含父链）→ 跳过
    if (isInIgnoreGroup(player.group, config)) {
      skipped.push(`${player.name}:ignored`)
      continue
    }

    // 5. 旧版 OnlineData.cs:158-173：查询失败 → 记 warn 并 continue（不影响其他玩家）
    let totalMin
    try {
      totalMin = query(player.name)
    } catch (err) {
      skipped.push(`${player.name}:query-error`)
      continue
    }

    // 6. 旧版 OnlineData.cs:176-191：从高到低取第一个达标阈值，然后 break（每轮最多晋升一次）
    for (const threshold of sorted) {
      if (totalMin < threshold.minutes) continue
      promote(
        player.account,
        threshold.targetGroup,
        threshold.mode,
        player,
        // 旧版是**整数除法**折算小时数（3000 分钟 → "50 小时"）
        `游玩时长达到 ${Math.floor(threshold.minutes / 60)} 小时`,
      )
      promotions.push({ player: player.name, targetGroup: threshold.targetGroup, minutes: threshold.minutes })
      break
    }
  }

  return { promotions, skipped }
}

/** 对应 OnGameUpdate（旧版 OnlineData.cs:71-84）：每 3600 tick 触发一次检查 */
function makeTicker(run) {
  let counter = 0
  return {
    tick(n = 1) {
      for (let i = 0; i < n; i++) {
        counter++
        if (counter % TICKS_PER_MINUTE === 0) run()
      }
      return counter
    },
  }
}

// ════════════════════════════════════════════════════════════
//  夹具
// ════════════════════════════════════════════════════════════

function group(name, parent = null) {
  return { name, parent }
}

const GROUPS = (() => {
  const guest = group('guest')
  const vip = group('vip', guest)
  const trusted = group('trustedplayer', vip)
  const owner = group('owner')
  return { guest, vip, trusted, owner }
})()

function player(name, groupObj, patch = {}) {
  return { name, active: true, isLoggedIn: true, account: { name, group: groupObj.name }, group: groupObj, ...patch }
}

function cfg(thresholds, ignoreGroups = DEFAULT_IGNORE_GROUPS.slice()) {
  return { playtimeThresholds: thresholds, ignoreGroups }
}

/** 收集晋升事件的 promote 回调 */
function collector() {
  const events = []
  return { events, promote: (...args) => events.push(args) }
}

// ════════════════════════════════════════════════════════════
//  1. 阈值过滤与排序
// ════════════════════════════════════════════════════════════

test('阈值为空数组 → 直接返回（旧版默认就是空数组，此时时长晋升完全不工作）', () => {
  const { events, promote } = collector()
  const r = checkAutoPromotion({
    config: cfg([]),
    players: [player('Steve', GROUPS.guest)],
    query: () => 999999,
    promote,
  })
  assert.deepEqual(r.promotions, [])
  assert.deepEqual(events, [], '没有任何规则时不允许晋升')
})

test('阈值全部无效（Minutes<=0 或 TargetGroup 为空）→ 过滤后为空 → 直接返回', () => {
  const { events, promote } = collector()
  const r = checkAutoPromotion({
    config: cfg([
      { minutes: 0, targetGroup: 'vip', mode: 'auto' },
      { minutes: -100, targetGroup: 'vip', mode: 'auto' },
      { minutes: 3000, targetGroup: '', mode: 'auto' },
      { minutes: 3000, targetGroup: null, mode: 'auto' },
    ]),
    players: [player('Steve', GROUPS.guest)],
    query: () => 999999,
    promote,
  })
  assert.deepEqual(r.promotions, [], '这类条目会被算法直接滤掉（这是旧版既有行为）')
  assert.deepEqual(events, [])
})

test('阈值按 Minutes 降序匹配：先试高门槛，取**第一个**达标的', () => {
  const { events, promote } = collector()
  const thresholds = [
    { minutes: 3000, targetGroup: 'trustedplayer', mode: 'auto' },
    { minutes: 60, targetGroup: 'vip', mode: 'auto' },
    { minutes: 600, targetGroup: 'vip', mode: 'force' },
  ]
  // 只有 100 分钟：3000 不达标、600 不达标、60 达标 → 晋升到 vip（auto）
  checkAutoPromotion({ config: cfg(thresholds), players: [player('A', GROUPS.guest)], query: () => 100, promote })
  assert.equal(events.length, 1)
  assert.equal(events[0][1], 'vip')
  assert.equal(events[0][2], 'auto')

  // 输入顺序打乱也必须按"从高到低"取最高匹配档
  const shuffled = [thresholds[1], thresholds[2], thresholds[0]]
  const c2 = collector()
  checkAutoPromotion({ config: cfg(shuffled), players: [player('B', GROUPS.guest)], query: () => 1000, promote: c2.promote })
  assert.equal(c2.events.length, 1)
  assert.equal(c2.events[0][1], 'vip', '1000 分钟：3000 不达标，600/60 → 取 600 那档')
  assert.equal(c2.events[0][2], 'force')

  // 6000 分钟：三档都达标 → 只取最高的 3000 档
  const c3 = collector()
  checkAutoPromotion({ config: cfg(shuffled), players: [player('C', GROUPS.guest)], query: () => 6000, promote: c3.promote })
  assert.equal(c3.events.length, 1)
  assert.equal(c3.events[0][1], 'trustedplayer')
  assert.equal(c3.events[0][2], 'auto')
})

test('每轮最多晋升一次：命中最高档后必须 break（不许连跳两档）', () => {
  const { events, promote } = collector()
  const thresholds = [
    { minutes: 60, targetGroup: 'vip', mode: 'auto' },
    { minutes: 120, targetGroup: 'trustedplayer', mode: 'auto' },
    { minutes: 180, targetGroup: 'admin', mode: 'auto' },
  ]
  checkAutoPromotion({
    config: cfg(thresholds),
    players: [player('Steve', GROUPS.guest)],
    query: () => 100000, // 全部达标
    promote,
  })
  assert.equal(events.length, 1, '一个玩家每轮只晋升一次（旧版 OnlineData.cs:189 的 break）')
  assert.equal(events[0][1], 'admin', '取最高匹配档')
})

// ════════════════════════════════════════════════════════════
//  2. 时长折算（整数除法）
// ════════════════════════════════════════════════════════════

test('reason 文案用时长的**整数除法**折算小时（3000 → "50 小时"）；未达标不晋升', () => {
  const { events, promote } = collector()
  checkAutoPromotion({
    config: cfg([{ minutes: 3000, targetGroup: 'trustedplayer', mode: 'auto' }]),
    players: [player('A', GROUPS.guest)],
    query: () => 3000,
    promote,
  })
  assert.equal(events.length, 1, 'totalMin == Minutes 也算达标（判断是 totalMin < Minutes 则 continue）')
  assert.equal(events[0][4], '游玩时长达到 50 小时', '3000 / 60 = 50（整数除法）')

  const c2 = collector()
  checkAutoPromotion({
    config: cfg([{ minutes: 3000, targetGroup: 'trustedplayer', mode: 'auto' }]),
    players: [player('B', GROUPS.guest)],
    query: () => 2999,
    promote: c2.promote,
  })
  assert.deepEqual(c2.events, [], 'totalMin < Minutes 不晋升')

  // 非整除的整数除法：100 分钟 → "1 小时"（不是 1.67）
  const c3 = collector()
  checkAutoPromotion({
    config: cfg([{ minutes: 100, targetGroup: 'vip', mode: 'auto' }]),
    players: [player('C', GROUPS.guest)],
    query: () => 100,
    promote: c3.promote,
  })
  assert.equal(c3.events[0][4], '游玩时长达到 1 小时')
})

// ════════════════════════════════════════════════════════════
//  3. 玩家筛选与忽略组
// ════════════════════════════════════════════════════════════

test('未登录 / 未激活 / 无账号 / 无组的玩家全部跳过', () => {
  const { events, promote } = collector()
  checkAutoPromotion({
    config: cfg([{ minutes: 60, targetGroup: 'vip', mode: 'auto' }]),
    players: [
      null,
      player('notActive', GROUPS.guest, { active: false }),
      player('notLoggedIn', GROUPS.guest, { isLoggedIn: false }),
      player('noAccount', GROUPS.guest, { account: null }),
      player('noGroup', GROUPS.guest, { group: null }),
      player('ok', GROUPS.guest),
    ],
    query: () => 100000,
    promote,
  })
  assert.equal(events.length, 1, '只有最后一个合法玩家被处理')
  assert.equal(events[0][0].name, 'ok')
})

test('忽略组沿**父组链**命中 → 跳过（当前组是 vip，父链上有 guest）', () => {
  const { events, promote } = collector()
  checkAutoPromotion({
    config: cfg([{ minutes: 60, targetGroup: 'trustedplayer', mode: 'auto' }], ['guest']),
    players: [player('Steve', GROUPS.vip)],
    query: () => 100000,
    promote,
  })
  assert.deepEqual(events, [], 'vip 的父组是 guest，命中忽略组 → 不晋升')
})

test('忽略组自身命中 + 大小写不敏感 + 成环不死循环', () => {
  // 自身命中
  assert.equal(isInIgnoreGroup(GROUPS.owner, { ignoreGroups: ['owner'] }), true)
  assert.equal(isInIgnoreGroup(GROUPS.owner, { ignoreGroups: ['OWNER'] }), true, '大小写不敏感')
  assert.equal(isInIgnoreGroup(GROUPS.owner, { ignoreGroups: [] }), false)
  assert.equal(isInIgnoreGroup(null, { ignoreGroups: ['owner'] }), false)
  assert.equal(isInIgnoreGroup(GROUPS.owner, { ignoreGroups: null }), false)

  // 成环：loop-a ↔ loop-b，链上没有命中 → 必须能返回 false（不是死循环）
  const a = group('loop-a')
  const b = group('loop-b', a)
  a.parent = b
  assert.equal(isInIgnoreGroup(a, { ignoreGroups: ['superadmin'] }), false)
  assert.equal(isInIgnoreGroup(a, { ignoreGroups: ['loop-b'] }), true, '成环但链上有命中 → true')
})

test('默认保护名单 owner/superadmin 会挡掉管理员（配置里显式给空数组则挡不住）', () => {
  const c1 = collector()
  checkAutoPromotion({
    config: cfg([{ minutes: 60, targetGroup: 'vip', mode: 'auto' }], DEFAULT_IGNORE_GROUPS.slice()),
    players: [player('Admin', GROUPS.owner)],
    query: () => 100000,
    promote: c1.promote,
  })
  assert.deepEqual(c1.events, [], '默认保护名单必须挡掉 owner')

  const c2 = collector()
  checkAutoPromotion({
    config: cfg([{ minutes: 60, targetGroup: 'vip', mode: 'auto' }], []),
    players: [player('Admin', GROUPS.owner)],
    query: () => 100000,
    promote: c2.promote,
  })
  assert.equal(c2.events.length, 1, '空保护名单下 owner 会被改组（界面上必须警告这件事）')
})

// ════════════════════════════════════════════════════════════
//  4. 查询异常隔离
// ════════════════════════════════════════════════════════════

test('某个玩家查询抛异常 → 只跳过这一个，不中断其他人的处理', () => {
  const { events, promote } = collector()
  const queried = []
  const r = checkAutoPromotion({
    config: cfg([{ minutes: 60, targetGroup: 'vip', mode: 'auto' }]),
    players: [
      player('bad', GROUPS.guest),
      player('good1', GROUPS.guest),
      player('good2', GROUPS.guest),
    ],
    query: (name) => {
      queried.push(name)
      if (name === 'bad') throw new Error('no such table: player_daily_stat')
      return 100000
    },
    promote,
  })
  assert.deepEqual(queried, ['bad', 'good1', 'good2'], '异常后必须继续遍历后续玩家')
  assert.equal(events.length, 2, '两个好玩家照常晋升')
  assert.deepEqual(events.map((e) => e[0].name), ['good1', 'good2'])
  assert.deepEqual(r.skipped, ['bad:query-error'], '失败原因要如实记下来（对应服端的 ConsoleWarn）')
})

test('查询返回 0（表里没有该玩家的记录）→ 不晋升，但不报错', () => {
  const { events, promote } = collector()
  const r = checkAutoPromotion({
    config: cfg([{ minutes: 1, targetGroup: 'vip', mode: 'auto' }]),
    players: [player('Newcomer', GROUPS.guest)],
    query: () => 0,
    promote,
  })
  assert.deepEqual(events, [])
  assert.deepEqual(r.skipped, [], '查得到但为 0 不算错误（COALESCE(SUM(...),0) 的正常结果）')
})

// ════════════════════════════════════════════════════════════
//  5. 计时节拍
// ════════════════════════════════════════════════════════════

test('计时节拍：3600 tick 才执行一次（3599 不触发、3600 触发、7200 再触发）', () => {
  let runs = 0
  const ticker = makeTicker(() => { runs++ })
  ticker.tick(3599)
  assert.equal(runs, 0, '不到 1 分钟不检查')
  ticker.tick(1)
  assert.equal(runs, 1, '第 3600 tick 检查一次')
  ticker.tick(3599)
  assert.equal(runs, 1)
  ticker.tick(1)
  assert.equal(runs, 2, '第 7200 tick 再检查一次')
  assert.equal(TICKS_PER_MINUTE, 3600, '节拍常量必须是 3600（60 tick/秒 × 60 秒）')
})

test('节拍内只做"检查晋升"：镜像里没有任何累加时长的动作（写入是 online-stats 的职责）', () => {
  // 这条断言是"双倍计时长防护"的镜像侧：本插件的节拍回调只调用 checkAutoPromotion，
  // 而 checkAutoPromotion 只经 query 读数据（镜像里 query 是纯读函数）。
  const calls = []
  const ticker = makeTicker(() => {
    checkAutoPromotion({
      config: cfg([{ minutes: 60, targetGroup: 'vip', mode: 'auto' }]),
      players: [player('A', GROUPS.guest)],
      query: (name) => { calls.push(['read', name]); return 100000 },
      promote: (a, t) => calls.push(['promote', a.name, t]),
    })
  })
  ticker.tick(3600)
  assert.deepEqual(calls, [['read', 'A'], ['promote', 'A', 'vip']],
    '节拍里只有"读时长 + 晋升"两个动作；没有任何写入动作')
})
