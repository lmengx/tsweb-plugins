/**
 * 权限提升判定语义测试（**JS 等价镜像**，语义双保险）
 *
 * 镜像对象：plugins/promotion/plugin/Promotion.cs 的
 *   ParseMode / IsAutoMode        （旧版 TsWeb/plugin/PromotionConfig.cs:328-333）
 *   TryPromote                    （旧版 TsWeb/plugin/PromotionConfig.cs:244-307）
 *   IsGroupAtOrAbove              （旧版 TsWeb/plugin/PromotionConfig.cs:309-326）
 *   TryPromoteOnLogin             （旧版 TsWeb/plugin/QQ.cs:172-195）
 *
 * 必须先说清楚这条测试能证明什么、不能证明什么：
 *   - C# 的游戏服半在本机**跑不起来**：它依赖 TShock 运行时（TShock.Groups / UserAccounts /
 *     TSocket 玩家对象），本机没有游戏服环境。C# 那侧本次只有编译层与字节层验证
 *     （见 dll-content.test.mjs）。
 *   - 所以这里放一份与 C# 逻辑**逐条对应**的 JS 镜像，把"判定顺序与边界情况"用可执行的
 *     断言固定下来：这是一份**语义双保险**，用来防止"改动时把顺序/大小写/成环处理弄错"，
 *     **不是**对 C# 实现的覆盖。
 *   - 镜像与 C# 的对应关系逐条写在注释里（含 文件:行号），两边同时改才不会漂移。
 *
 * 还额外锁住两条"界面上说不清就会变静默失效"的行为：
 *   1. **只有 auto 有特殊语义**，其它任何值（含 force、含大小写混写）都按"直接改组"处理；
 *   2. 旧版 TryPromote 的忽略组检查**只比当前组名**（不查父链），
 *      而 PromotionThresholds.IsInIgnoreGroup **查父链** —— 两处**故意重叠**。
 *      本文件把这条重叠写成断言，防止有人"顺手优化"成一致（那会改变 QQ 绑定提升的保护范围）。
 *
 * 运行：node test/promotion-rules.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'

import { DEFAULT_IGNORE_GROUPS, normalizeMode } from '../config.js'

// ════════════════════════════════════════════════════════════
//  镜像实现（对应 plugins/promotion/plugin/Promotion.cs）
// ════════════════════════════════════════════════════════════

/** 对应 Promotion.IsAutoMode（plugin/Promotion.cs）：序数忽略大小写比较 */
function isAutoMode(mode) {
  return String(mode == null ? '' : mode).toLowerCase() === 'auto'
}

/**
 * 对应 Promotion.ParseMode（旧版 PromotionConfig.cs:328-333）：
 * mode == "auto"（忽略大小写）→ Auto，**否则 Force**（任何非 auto 值都是强制）。
 * 这里把它折算成宿主侧同口径的 normalizeMode 结果，便于断言。
 */
function parseMode(mode) {
  return isAutoMode(mode) ? 'Auto' : 'Force'
}

/**
 * 对应 Promotion.IsGroupAtOrAbove（旧版 PromotionConfig.cs:309-326）：
 * 沿父组链向上找目标组；visited 防配置错误造成成环时死循环。
 * 注意成环的语义：成环且链上没有目标组 → 返回 false（不是"到达"），于是 auto 模式会改组。
 */
function isGroupAtOrAbove(group, targetGroupName) {
  const visited = new Set()
  let current = group
  while (current) {
    const name = String(current.name).toLowerCase()
    if (visited.has(name)) break
    visited.add(name)
    if (name === String(targetGroupName).toLowerCase()) return true
    current = current.parent || null
  }
  return false
}

/**
 * 对应 Promotion.TryPromoteOnLogin + TryPromote 的完整判定顺序
 * （plugin/Promotion.cs 的两个方法；TryPromote 与旧版 PromotionConfig.cs:244-307 逐行一致）。
 *
 * @param {object} input
 *   player        登录中的玩家（null 表示没有玩家对象）
 *   bound         账号是否在绑定快照里（PromotionBindings.IsBound）
 *   config        统一配置 { qqBind:{enabled,targetGroup,mode}, ignoreGroups }
 *   groups        组表：{ 组名(小写): { name, parent } }
 * @returns {{ action:'skip'|'promote', step:string, target?:string }}
 */
function decide({ player, bound, config, groups }) {
  const qq = config.qqBind || {}

  // 1. 玩家非空、已登录、有 Account（旧版 QQ.cs:178）
  if (!player || !player.isLoggedIn || !player.account) return { action: 'skip', step: 'no-login' }

  // 2. 该账号在绑定快照里存在（旧版 QQ.cs:183）
  if (!bound) return { action: 'skip', step: 'not-bound' }

  // 3. qqBind.enabled（旧版 QQ.cs:185-186）
  if (qq.enabled !== true) return { action: 'skip', step: 'disabled' }

  // 4. 目标组名为空（旧版 TryPromote 第一行的 string.IsNullOrEmpty 检查，PromotionConfig.cs:251-252）
  //    注意：旧版这里**静默返回 false、不记日志**；本件照搬（不再有 warn）
  const target = String(qq.targetGroup == null ? '' : qq.targetGroup).trim()
  if (target === '') return { action: 'skip', step: 'empty-target-group' }

  // 5. 目标组不存在（旧版 PromotionConfig.cs:256-260）：**故意不记日志**
  if (!groups[target.toLowerCase()]) return { action: 'skip', step: 'target-group-missing' }

  // 6. 当前组命中 ignoreGroups（旧版 PromotionConfig.cs:262-273）：**只比当前组名**，序数忽略大小写
  const currentGroup = groups[String(player.account.group || '').toLowerCase()] || null
  if (currentGroup) {
    const ignore = Array.isArray(config.ignoreGroups) ? config.ignoreGroups : []
    for (const g of ignore) {
      if (String(currentGroup.name).toLowerCase() === String(g).toLowerCase()) {
        return { action: 'skip', step: 'ignored' } // 静默：不产生警告
      }
    }
  }

  // 7. auto 模式且已达目标组 → 跳过（旧版 PromotionConfig.cs:275-286）
  if (isAutoMode(qq.mode) && currentGroup && isGroupAtOrAbove(currentGroup, target)) {
    return { action: 'skip', step: 'already-at-or-above' }
  }

  // 8. 改组（旧版 PromotionConfig.cs:288-297）
  return { action: 'promote', step: 'promoted', target }
}

// ════════════════════════════════════════════════════════════
//  测试夹具
// ════════════════════════════════════════════════════════════

/** 组表：guest → vip → admin（父链自下而上）；owner 无父；loop-a ↔ loop-b 成环 */
function makeGroups() {
  const guest = { name: 'guest', parent: null }
  const vip = { name: 'vip', parent: guest }
  const admin = { name: 'admin', parent: vip }
  const owner = { name: 'owner', parent: null }
  const loopA = { name: 'loop-a', parent: null }
  const loopB = { name: 'loop-b', parent: loopA }
  loopA.parent = loopB // 父链成环
  const out = {}
  for (const g of [guest, vip, admin, owner, loopA, loopB]) out[g.name.toLowerCase()] = g
  return out
}

/** 统一配置夹具（与旧版默认值一致） */
function makeConfig(patch = {}) {
  return {
    qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto', ...(patch.qqBind || {}) },
    playtimeThresholds: patch.playtimeThresholds || [],
    ignoreGroups: patch.ignoreGroups || DEFAULT_IGNORE_GROUPS.slice(),
  }
}

function loginPlayer(group) {
  return { isLoggedIn: true, account: { name: 'Steve', group } }
}

// ════════════════════════════════════════════════════════════
//  判定顺序
// ════════════════════════════════════════════════════════════

test('判定顺序 1-2：未登录/无账号先于一切；未绑定玩家即便启用 + force 也不被动组', () => {
  const groups = makeGroups()
  const cfg = makeConfig()
  assert.equal(decide({ player: null, bound: true, config: cfg, groups }).step, 'no-login')
  assert.equal(
    decide({ player: { isLoggedIn: false, account: { group: 'vip' } }, bound: true, config: cfg, groups }).step,
    'no-login',
  )
  assert.equal(
    decide({ player: { isLoggedIn: true, account: null }, bound: true, config: cfg, groups }).step,
    'no-login',
  )

  // 未绑定：即使启用、即使 force、即使在目标组下方，也必须跳过（未绑定玩家不受影响）
  const force = makeConfig({ qqBind: { mode: 'force' } })
  assert.equal(decide({ player: loginPlayer('guest'), bound: false, config: force, groups }).step, 'not-bound')
})

test('判定顺序 3：未启用时连目标组都不看（只回 disabled）', () => {
  const groups = makeGroups()
  const cfg = makeConfig({ qqBind: { enabled: false } })
  assert.deepEqual(decide({ player: loginPlayer('guest'), bound: true, config: cfg, groups }), {
    action: 'skip', step: 'disabled',
  })
})

test('判定顺序 4：目标组不存在 → 跳过（旧版此处**故意不记日志**，本件照搬静默）', () => {
  const groups = makeGroups()
  const cfg = makeConfig({ qqBind: { targetGroup: 'not-exist' } })
  const r = decide({ player: loginPlayer('guest'), bound: true, config: cfg, groups })
  assert.equal(r.action, 'skip')
  assert.equal(r.step, 'target-group-missing')
  assert.equal(r.warned, undefined, '旧版 PromotionConfig.cs:258 的日志是注释掉的，保持静默')
})

test('判定顺序 4.5：目标组为空 → 跳过（同样静默，与旧版 TryPromote 首行检查一致）', () => {
  const groups = makeGroups()
  for (const targetGroup of ['', '   ', null, undefined]) {
    const r = decide({ player: loginPlayer('guest'), bound: true, config: makeConfig({ qqBind: { targetGroup } }), groups })
    assert.equal(r.action, 'skip', `targetGroup=${JSON.stringify(targetGroup)} 不应晋升`)
    assert.equal(r.step, 'empty-target-group')
  }
})

test('判定顺序 5：命中忽略组 → 静默跳过，force 模式也保护（管理员不被降级）', () => {
  const groups = makeGroups()
  for (const mode of ['auto', 'force', 'whatever']) {
    const r = decide({ player: loginPlayer('owner'), bound: true, config: makeConfig({ qqBind: { mode } }), groups })
    assert.equal(r.action, 'skip', `mode=${mode} 时 owner 组必须被保护`)
    assert.equal(r.step, 'ignored')
    assert.equal(r.warned, undefined, '命中忽略组是静默跳过（旧版 PromotionConfig.cs:269 日志被注释掉）')
  }
  // 大小写不敏感：配置里写 Owner/SUPERADMIN 也要命中
  assert.equal(
    decide({ player: loginPlayer('owner'), bound: true, config: makeConfig({ ignoreGroups: ['Owner', 'SUPERADMIN'] }), groups }).step,
    'ignored',
  )
  // 当前组名大小写不同（TShock 里可能是 Owner）也要命中
  assert.equal(decide({ player: loginPlayer('OWNER'), bound: true, config: makeConfig(), groups }).step, 'ignored')
})

test('判定顺序 6：auto 模式沿父组链判断，已达目标组（或其上级）则跳过', () => {
  const groups = makeGroups()
  const cfg = makeConfig()
  // 当前就是目标组
  assert.equal(decide({ player: loginPlayer('vip'), bound: true, config: cfg, groups }).step, 'already-at-or-above')
  // 当前在目标组上方（admin 的父链：admin → vip → guest）
  assert.equal(decide({ player: loginPlayer('admin'), bound: true, config: cfg, groups }).step, 'already-at-or-above')
  // 父链上没有目标组 → 需要晋升
  assert.equal(decide({ player: loginPlayer('guest'), bound: true, config: cfg, groups }).action, 'promote')
})

test('判定顺序 6 边界：父链成环不死循环，且"成环但没到目标组"要按需改组', () => {
  const groups = makeGroups()
  const r = decide({ player: loginPlayer('loop-a'), bound: true, config: makeConfig(), groups })
  assert.equal(r.action, 'promote', '成环且链上无目标组 → 不视为"已达目标组"，应改组')
  assert.equal(isGroupAtOrAbove(groups['loop-a'], 'loop-b'), true)
  assert.equal(isGroupAtOrAbove(groups['loop-a'], 'guest'), false)
})

test('只有 auto 有特殊语义：其它任何值（含大小写混写）都直接改组', () => {
  const groups = makeGroups()
  // ParseMode：非 auto 一律 Force（旧版 PromotionConfig.cs:328-333）
  assert.equal(parseMode('auto'), 'Auto')
  assert.equal(parseMode('AUTO'), 'Auto', '序数忽略大小写')
  assert.equal(parseMode('Auto'), 'Auto')
  assert.equal(parseMode('force'), 'Force')
  assert.equal(parseMode(''), 'Force', '空串不是 auto → Force（旧版比较用 OrdinalIgnoreCase，空串不相等）')
  assert.equal(parseMode(null), 'Force')
  assert.equal(parseMode('whatever'), 'Force')

  // 宿主侧 normalizeMode 与上面的 parseMode **完全同判据**（含"显式空值算 Force"），
  // 服端 PromotionConfigStore.NormalizeMode 也是同一判据；
  // "字段缺失 → auto"是**另一层**（旧版 C# 属性初值）的职责，见 config.js:normalizeThreshold / normalizeQqBind
  assert.equal(normalizeMode(''), 'force', '旧版 ParseMode("") → Force')
  assert.equal(normalizeMode(null), 'force', '旧版 ParseMode(null) → Force')
  assert.equal(normalizeMode(undefined), 'force')
  assert.equal(normalizeMode('auto'), 'auto')
  assert.equal(normalizeMode(' force '), 'force')

  // vip 是目标组本身：auto 跳过，force 与其它值都改组
  assert.equal(decide({ player: loginPlayer('vip'), bound: true, config: makeConfig({ qqBind: { mode: 'force' } }), groups }).action, 'promote')
  assert.equal(decide({ player: loginPlayer('vip'), bound: true, config: makeConfig({ qqBind: { mode: 'whatever' } }), groups }).action, 'promote')
  assert.equal(decide({ player: loginPlayer('vip'), bound: true, config: makeConfig({ qqBind: { mode: 'AUTO' } }), groups }).action, 'skip')
})

test('当前组解析不到时（TShock.Groups.GetGroupByName 返回 null）忽略组与父链检查都被跳过 —— 与旧版一致', () => {
  const groups = makeGroups()
  // 玩家所在组名不在组表里 → currentGroup = null
  const r = decide({ player: loginPlayer('ghost-group'), bound: true, config: makeConfig(), groups })
  assert.equal(r.action, 'promote', '与旧版一致：解析不到当前组时不看忽略名单，仍按 auto 判断')
  assert.equal(r.step, 'promoted')
})

test('保护默认值：忽略组为空数组时 owner 会被改组（这正是必须保住保护名单的原因）', () => {
  const groups = makeGroups()
  const cfg = makeConfig({ ignoreGroups: DEFAULT_IGNORE_GROUPS.slice() })
  assert.equal(decide({ player: loginPlayer('owner'), bound: true, config: cfg, groups }).step, 'ignored')

  // 反例对照：空保护名单（旧实现的缺陷形态）下 owner 会被 auto 逻辑改组
  const empty = makeConfig({ ignoreGroups: [] })
  assert.equal(
    decide({ player: loginPlayer('owner'), bound: true, config: empty, groups }).action,
    'promote',
    '空保护名单下 owner 会被改组 —— 这正是"缺字段不得回落成空名单"的原因',
  )
})

// ════════════════════════════════════════════════════════════
//  两处忽略组口径"故意重叠"（旧版原样，不许优化）
// ════════════════════════════════════════════════════════════

/**
 * 对应 PromotionThresholds.IsInIgnoreGroup（旧版 OnlineData.cs:203-227）：**沿父组链**查忽略组。
 * 与上面 decide() 里的"只比当前组名"形成对照。
 */
function isInIgnoreGroup(group, config) {
  if (!group) return false
  const ignore = Array.isArray(config.ignoreGroups) ? config.ignoreGroups : []
  for (const g of ignore) {
    if (String(group.name).toLowerCase() === String(g).toLowerCase()) return true
    const visited = new Set()
    let current = group
    while (current) {
      const name = String(current.name).toLowerCase()
      if (visited.has(name)) break
      visited.add(name)
      if (name === String(g).toLowerCase()) return true
      current = current.parent || null
    }
  }
  return false
}

test('忽略组两处口径故意重叠：TryPromote 只比当前组名，IsInIgnoreGroup 查父链', () => {
  const groups = makeGroups()
  const cfg = makeConfig({ ignoreGroups: ['guest'] }) // guest 是 vip 的**父组**

  // 时长晋升的入口检查（查父链）：当前组 vip 的父链上有 guest → 命中，直接跳过
  assert.equal(isInIgnoreGroup(groups['vip'], cfg), true, '父链命中 → 时长晋升不会走到 TryPromote')

  // 但 TryPromote 自身（只比当前组名）在"当前组是 vip"时**不会**命中 guest
  const r = decide({ player: loginPlayer('vip'), bound: true, config: cfg, groups })
  assert.equal(r.step, 'already-at-or-above', 'TryPromote 只比当前组名，所以这里没被忽略组挡住')

  // 若是 force 模式，同一个玩家在 QQ 绑定晋升里就会**真的被改组**（父链保护对它无效）
  const forced = decide({ player: loginPlayer('vip'), bound: true, config: makeConfig({ qqBind: { mode: 'force' }, ignoreGroups: ['guest'] }), groups })
  assert.equal(forced.action, 'promote', '这就是两处口径重叠带来的差异：旧版原样，本件照搬不收敛')
})

test('IsInIgnoreGroup：成环时不死循环；当前组自身即忽略组时命中', () => {
  const groups = makeGroups()
  assert.equal(isInIgnoreGroup(groups['loop-a'], makeConfig({ ignoreGroups: ['superadmin'] })), false, '成环且无命中 → false，且必须能返回')
  assert.equal(isInIgnoreGroup(groups['owner'], makeConfig({ ignoreGroups: ['OWNER'] })), true, '大小写不敏感')
  assert.equal(isInIgnoreGroup(null, makeConfig()), false, '组为空 → false')
  assert.equal(isInIgnoreGroup(groups['vip'], makeConfig({ ignoreGroups: null })), false, '忽略名单缺失 → false（不挡人）')
})
