/**
 * 打包器"构建产物新鲜度"判定测试（scripts/pack-plugin.mjs 的 pickBuildArtifact）
 *
 * 为什么放在本插件的测试里：这条判定直接决定"本插件构建出的 Promotion.dll 会不会被
 * 一个陈旧副本覆盖掉"。本仓实测过那份缺陷：plugins/qq-bind/plugin/QqBind.dll（27136 B）
 * 里没有 QqPromotion/TryPromoteOnLogin，而同目录 obj/Release/QqBind.dll（32768 B）里有 ——
 * 打包器无条件从 bin/Release/<tfm>/ 回拷，把刚构建好的产物覆盖成了陈旧的那份，全程没有任何报错。
 *
 * 这里用**合成文件 + 显式 mtime** 直接验证判定的四种情形，跑得飞快且不依赖 dotnet：
 *   1. plugin/ 那份是本次产物、bin/ 那份是陈旧的 → 必须选 plugin/ 的（这就是修复点）
 *   2. bin/ 那份是本次产物（OutputPath=bin 的常规布局）→ 选 bin/ 的并允许回拷
 *   3. 两份都不是本次产物且内容不同 → **必须报错**（不许静默用旧的）
 *   4. 两份都不是本次产物但内容相同 → 允许（增量构建没重写文件，无陈旧副本冲突）
 *   另外覆盖：没有任何候选、多份新鲜且内容不同（多目标框架）两种情况都必须明确报错。
 *
 * 运行：node test/pack-freshness.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, mkdir, writeFile, utimes } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

// 打包器已导出函数供其它脚本 import（import 时不会执行 main，见其文件末尾的 invokedDirectly 判断）
import { pickBuildArtifact, ALLOWED_TAGS } from '../../../scripts/pack-plugin.mjs'

/** 本插件的程序集名（改名后：Promotion.csproj → Promotion.dll） */
const ASSEMBLY = 'Promotion'
let root

before(async () => {
  root = await mkdtemp(path.join(tmpdir(), 'promotion-pack-'))
})

after(async () => {
  await rm(root, { recursive: true, force: true })
})

let caseSeq = 0

/**
 * 造一个"插件目录"：
 *   pluginDll：{ content, ageMs } 写入 plugin/<Assembly>.dll（ageMs = 相对现在的"多久以前"）
 *   binDlls：  { '<tfm>': { content, ageMs } } 写入 plugin/bin/Release/<tfm>/<Assembly>.dll
 */
async function makeCase({ pluginDll, binDlls = {} } = {}) {
  caseSeq += 1
  const pluginSub = path.join(root, `case-${caseSeq}`, 'plugin')
  await mkdir(pluginSub, { recursive: true })

  const now = Date.now()
  const stamp = async (file, spec) => {
    await writeFile(file, spec.content, 'utf8')
    const t = new Date(now - spec.ageMs)
    await utimes(file, t, t)
  }

  if (pluginDll) await stamp(path.join(pluginSub, `${ASSEMBLY}.dll`), pluginDll)
  for (const [tfm, spec] of Object.entries(binDlls)) {
    const dir = path.join(pluginSub, 'bin', 'Release', tfm)
    await mkdir(dir, { recursive: true })
    await stamp(path.join(dir, `${ASSEMBLY}.dll`), spec)
  }

  return { pluginSub, binDir: path.join(pluginSub, 'bin', 'Release') }
}

const FRESH = { content: '本次构建的新产物', ageMs: 0 }
const STALE = { content: '很久以前的陈旧产物（内容不同）', ageMs: 60 * 60 * 1000 }

test('① plugin/ 是本次产物、bin/ 是陈旧产物 → 选 plugin/ 的（修复点：不再用陈旧 bin 覆盖新构建）', async () => {
  const { pluginSub, binDir } = await makeCase({
    pluginDll: { content: '本次新构建的内容-A', ageMs: 0 },
    binDlls: { 'net9.0': { content: '陈旧内容-B', ageMs: 3600_000 } },
  })
  const { chosen } = pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() })
  assert.equal(chosen.origin, 'plugin', '必须采用构建直接写出的 plugin/ 产物')
  assert.match(chosen.sha256, /^[0-9a-f]{64}$/)
})

test('② bin/ 是本次产物 → 选 bin/ 的（常规布局仍然照旧回拷到 plugin/）', async () => {
  const { pluginSub, binDir } = await makeCase({
    pluginDll: { content: '上一次的旧内容', ageMs: 3600_000 },
    binDlls: { 'net9.0': { content: '本次新构建的内容', ageMs: 0 } },
  })
  const { chosen } = pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() })
  assert.equal(chosen.origin, 'bin/Release/net9.0')
})

test('③ 两份都不是本次产物且内容不同 → 必须报错（旧实现会静默用 bin 的陈旧产物）', async () => {
  const { pluginSub, binDir } = await makeCase({
    pluginDll: { content: '旧内容-plugin（含新代码）', ageMs: 7200_000 },
    binDlls: { 'net9.0': { content: '更旧的 bin 内容（缺新代码）', ageMs: 10 * 24 * 3600_000 } },
  })
  assert.throws(
    () => pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() }),
    (err) => {
      assert.match(err.message, /构建产物不新鲜/)
      assert.match(err.message, /--rebuild/, '报错必须给出可操作的恢复手段')
      return true
    },
  )
})

test('④ 两份都不是本次产物但内容相同 → 允许（增量构建没重写文件，不存在陈旧副本冲突）', async () => {
  const same = '内容完全一致（增量构建空转）'
  const { pluginSub, binDir } = await makeCase({
    pluginDll: { content: same, ageMs: 3600_000 },
    binDlls: { 'net9.0': { content: same, ageMs: 3600_000 } },
  })
  const { chosen, candidates } = pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() })
  assert.equal(candidates.length, 2)
  assert.ok(chosen.sha256)
})

test('⑤ 没有任何候选产物 → 报错并给出两个查找位置', async () => {
  const { pluginSub, binDir } = await makeCase({})
  assert.throws(
    () => pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() }),
    /未找到 Promotion\.dll/,
    '报错文案里必须是新程序集名 Promotion.dll',
  )
})

test('⑥ 多份"本次产物"但内容不同（多目标框架）→ 报错而不是随手挑一份', async () => {
  const { pluginSub, binDir } = await makeCase({
    binDlls: {
      'net8.0': { content: 'net8 产物', ageMs: 0 },
      'net9.0': { content: 'net9 产物', ageMs: 0 },
    },
  })
  assert.throws(
    () => pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() }),
    /多份内容不同/,
  )
})

test('⑦ 多份"本次产物"且内容一致 → 正常选中（不误报）', async () => {
  const same = '一致的内容'
  const { pluginSub, binDir } = await makeCase({
    pluginDll: { content: same, ageMs: 0 },
    binDlls: { 'net9.0': { content: same, ageMs: 0 } },
  })
  const { chosen, fresh } = pickBuildArtifact({ pluginSub, binDir, assembly: ASSEMBLY, buildStartedAt: Date.now() })
  assert.equal(fresh.length, 2)
  assert.ok(chosen.file.endsWith(`${ASSEMBLY}.dll`))
})

test('⑧ 本插件的市场标签在闭集内（tags 白名单未被改动）', () => {
  assert.ok(ALLOWED_TAGS.includes('QQ管理'), 'ALLOWED_TAGS 必须仍含 QQ管理（本插件用它，且不得扩张白名单）')
  assert.deepEqual(
    ['管理工具', '机制拓展', '反作弊', '漏洞修复', '数据统计', '版本兼容', 'QQ管理'].filter((t) => !ALLOWED_TAGS.includes(t)),
    [],
    '七个分类一个都不能少（打包校验依赖这份闭集）',
  )
})

test('⑨ 陈旧产物对照：FRESH/STALE 夹具本身可区分（防止前面用例因 mtime 精度而假通过）', () => {
  assert.notEqual(FRESH.content, STALE.content)
  assert.ok(FRESH.ageMs < STALE.ageMs)
})
