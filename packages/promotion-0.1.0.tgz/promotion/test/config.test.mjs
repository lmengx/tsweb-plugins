/**
 * 配置模块（config.js）单元测试
 *
 * 覆盖四块（对应任务书与旧版语义逐条）：
 *   1. **默认值**与旧版一字不差：qqBind 默认 { false, 'vip', 'auto' }、
 *      playtimeThresholds 默认**空数组**、ignoreGroups 默认 ['owner','superadmin']
 *   2. **归一**：模式只有 auto 有特殊语义（其它一律 force，与旧版 ParseMode 一致）、
 *      分钟数非负整数、忽略组去重（忽略大小写、trim、剔空、保留首现顺序 = 旧版 DedupIgnoreGroups）
 *   3. **严格校验**：非法值必须被 400 拒绝（不写进配置），包括 minutes 非整数/负数、
 *      targetGroup 空、qqBind 结构不符
 *   4. 落盘 / 读取 / 下发载荷必带齐三个字段
 *
 * 运行：node test/config.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import {
  DEFAULT_IGNORE_GROUPS,
  DEFAULT_MODE,
  DEFAULT_QQ_TARGET_GROUP,
  DEFAULT_THRESHOLD_MINUTES,
  DEFAULT_THRESHOLD_TARGET_GROUP,
  PUSH_DEFAULTS,
  configWarnings,
  defaultConfig,
  defaultThreshold,
  dedupeGroups,
  loadConfig,
  mergeConfig,
  normalizeConfig,
  normalizeIgnoreGroups,
  normalizeMinutes,
  normalizeMode,
  normalizeQqBind,
  normalizeThreshold,
  normalizeThresholds,
  saveConfig,
  setByPath,
  toGamePayload,
  validateConfig,
} from '../config.js'

let dir

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), 'promotion-config-'))
})

after(async () => {
  await rm(dir, { recursive: true, force: true })
})

function cfgFile(name) {
  return path.join(dir, `${name}.json`)
}

// ═══════════════ 1. 默认值与旧版逐字对齐 ═══════════════

test('默认配置与旧版一字不差：qqBind{vip,auto,false} + 空数组 + 保护忽略组', () => {
  const c = defaultConfig()
  // 旧版 PromotionConfig.cs:26-36
  assert.deepEqual(c.qqBind, { enabled: false, targetGroup: 'vip', mode: 'auto' })
  // 旧版 PromotionConfig.cs:62：**默认是空数组**（不是含一条 3000 分钟的规则）
  assert.deepEqual(c.playtimeThresholds, [], '默认必须是空数组：旧版 PromotionConfig.cs:62 就是 new List<>()')
  // 旧版 PromotionConfig.cs:64-69
  assert.deepEqual(c.ignoreGroups, ['owner', 'superadmin'])
  assert.deepEqual(DEFAULT_IGNORE_GROUPS, ['owner', 'superadmin'])
  assert.equal(DEFAULT_QQ_TARGET_GROUP, 'vip')
  assert.equal(DEFAULT_MODE, 'auto')
  // 单条阈值的默认值是另一回事（旧版 PromotionConfig.cs:41-51）
  assert.equal(DEFAULT_THRESHOLD_MINUTES, 3000)
  assert.equal(DEFAULT_THRESHOLD_TARGET_GROUP, 'trustedplayer')
  // 界面"新增一条规则"的默认值（旧版 PromotionConfigView.vue:120-126）
  assert.deepEqual(defaultThreshold(), { minutes: 60, targetGroup: 'default', mode: 'auto' })
})

test('下发节奏不是配置字段：config.json 只有旧版那三个顶层字段', () => {
  assert.deepEqual(Object.keys(defaultConfig()).sort(), ['ignoreGroups', 'playtimeThresholds', 'qqBind'])
  // 节奏常量本身必须齐全（重试/对账靠它）
  for (const k of ['pushOnChange', 'pushOnServerConnect', 'reconcileIntervalMs', 'retryIntervalMs', 'retryMaxIntervalMs']) {
    assert.ok(Object.prototype.hasOwnProperty.call(PUSH_DEFAULTS, k), `PUSH_DEFAULTS 缺 ${k}`)
  }
})

// ═══════════════ 2. 忽略组：归一（旧版 DedupIgnoreGroups 口径） ═══════════════

test('忽略组去重照旧版 DedupIgnoreGroups：大小写不敏感 + trim + 剔空 + 保留首现顺序', () => {
  // 旧版 PromotionConfig.cs:97-110 的逐条行为
  assert.deepEqual(normalizeIgnoreGroups(['admin', 'ADMIN', ' vip ']), ['admin', 'vip'])
  assert.deepEqual(normalizeIgnoreGroups(['  ', '', 'x']), ['x'], '空白项剔除')
  assert.deepEqual(normalizeIgnoreGroups(['B', 'a', 'b', 'A']), ['B', 'a'], '保留首现顺序，不排序')
  assert.deepEqual(normalizeIgnoreGroups('owner, superadmin'), ['owner', 'superadmin'])
  assert.deepEqual(normalizeIgnoreGroups('owner\nsuperadmin；vip'), ['owner', 'superadmin', 'vip'])

  // 非数组 → null（这是 dedupeGroups 的契约，供调用方区分"数组"与"非数组"）
  assert.equal(dedupeGroups('not-an-array'), null)
  assert.equal(dedupeGroups(undefined), null)
  assert.equal(dedupeGroups(['a', 'A', '']).length, 1)
})

test('忽略组：缺失/非法 → 保护默认值；显式空数组保留（空名单=管理员的选择，但会有警告）', () => {
  assert.deepEqual(normalizeIgnoreGroups(undefined), ['owner', 'superadmin'])
  assert.deepEqual(normalizeIgnoreGroups(null), ['owner', 'superadmin'], '显式 null 也回落保护默认值（比旧版更严，理由见 config.js 注释）')
  assert.deepEqual(normalizeIgnoreGroups(123), ['owner', 'superadmin'])
  assert.deepEqual(normalizeIgnoreGroups({}), ['owner', 'superadmin'])
  assert.deepEqual(normalizeIgnoreGroups(''), ['owner', 'superadmin'])
  assert.deepEqual(normalizeIgnoreGroups(',,,'), ['owner', 'superadmin'])
  assert.deepEqual(normalizeIgnoreGroups([]), [], '显式空数组是管理员的选择，予以保留（但会有警告）')

  const c = normalizeConfig({ qqBind: { enabled: true, targetGroup: 'vip' } })
  assert.deepEqual(c.ignoreGroups, ['owner', 'superadmin'], '整份配置缺 ignoreGroups 时必须回落保护默认值')
  assert.notEqual(c.ignoreGroups.length, 0, '空保护名单 = 管理员可能被降级，绝不允许静默产生')
})

// ═══════════════ 3. 模式 / 分钟数 / 目标组归一 ═══════════════

test('模式归一：只有 auto 有特殊语义（旧版 ParseMode：非 auto 即 Force，显式空值也算 Force）', () => {
  // normalizeMode 与旧版 ParseMode（TsWeb/plugin/PromotionConfig.cs:328-333）逐条同判据：
  // 只有 'auto'（序数忽略大小写、且不 trim）是 auto，其它任何值（含 null/空串/纯空白）都是 force
  assert.equal(normalizeMode(undefined), 'force')
  assert.equal(normalizeMode(null), 'force', '旧版 ParseMode(null) → Force（不是 auto）')
  assert.equal(normalizeMode(''), 'force', '旧版 ParseMode("") → Force（不是 auto）')
  assert.equal(normalizeMode('  '), 'force')
  assert.equal(normalizeMode(' auto '), 'force', '旧版 ParseMode 不 trim，故 " auto " 也按 Force')
  assert.equal(normalizeMode('auto'), 'auto')
  assert.equal(normalizeMode('AUTO'), 'auto', '比较用序数忽略大小写')
  assert.equal(normalizeMode('AuTo'), 'auto')
  assert.equal(normalizeMode('force'), 'force')
  assert.equal(normalizeMode('whatever'), 'force', '其它任何值一律按 force')
  assert.equal(normalizeMode(0), 'force', '非字符串也要有确定结果，不能变成空')
})

test('模式的两层语义：**字段缺失** → auto（旧版属性初值）；**显式给空值** → force（旧版 ParseMode）', () => {
  // 旧版 C# 的属性初值就是 "auto"（PromotionConfig.cs:35/:50），JSON 里没有 mode 键时保留初值；
  // 而显式写了 null/空串时属性被覆盖成那个值，ParseMode 判据落到 Force。这两条必须分开。
  assert.equal(normalizeThreshold({ minutes: 60, targetGroup: 'vip' }).mode, 'auto', 'mode 字段缺失 → auto')
  assert.equal(normalizeThreshold({ minutes: 60, targetGroup: 'vip', mode: null }).mode, 'force', '显式 null → force')
  assert.equal(normalizeThreshold({ minutes: 60, targetGroup: 'vip', mode: '' }).mode, 'force', '显式空串 → force')
  assert.equal(normalizeThreshold({ minutes: 60, targetGroup: 'vip', mode: 'AUTO' }).mode, 'auto')
  // qqBind 同一套两层语义（normalizeQqBind 对 undefined 有显式判断）
  assert.equal(normalizeQqBind({ enabled: true, targetGroup: 'vip' }).mode, 'auto', 'mode 字段缺失 → auto')
  assert.equal(normalizeQqBind({ enabled: true, targetGroup: 'vip', mode: null }).mode, 'force', '显式 null → force')
  // 整份归一也不能把"缺失"变成 force（默认值层必须仍然给 auto）
  assert.equal(normalizeConfig({ qqBind: { enabled: true, targetGroup: 'vip' } }).qqBind.mode, 'auto')
  assert.equal(
    normalizeConfig({ qqBind: { enabled: true, targetGroup: 'vip' }, playtimeThresholds: [{ minutes: 60, targetGroup: 'default' }] })
      .playtimeThresholds[0].mode,
    'auto',
    '阈值缺 mode 也必须回落 auto（旧版属性初值），否则"新增规则不带 mode"会静默变成强制',
  )
})

test('分钟数归一：非负整数（非法 → 0，小数向下取整）', () => {
  assert.equal(normalizeMinutes(3000), 3000)
  assert.equal(normalizeMinutes('3000'), 3000)
  assert.equal(normalizeMinutes(59.9), 59, '小数向下取整（阈值只到分钟精度）')
  assert.equal(normalizeMinutes(-5), 0, '负数 → 0（否则"任何时长都达标"）')
  assert.equal(normalizeMinutes('abc'), 0)
  assert.equal(normalizeMinutes(NaN), 0)
  assert.equal(normalizeMinutes(Infinity), 0)
  assert.equal(normalizeMinutes(undefined), 0)
})

test('阈值数组归一：非数组 → 空数组；逐条归一三字段（缺目标组时用阈值的默认组，不是 vip）', () => {
  assert.deepEqual(normalizeThresholds(undefined), [])
  assert.deepEqual(normalizeThresholds('x'), [])
  assert.deepEqual(normalizeThresholds([{ minutes: '90', targetGroup: ' vip ', mode: 'FORCE' }]),
    [{ minutes: 90, targetGroup: 'vip', mode: 'force' }])
  assert.deepEqual(normalizeThresholds([{}]),
    [{ minutes: 0, targetGroup: 'trustedplayer', mode: 'auto' }],
    '缺字段时用阈值默认组 trustedplayer（旧版 PromotionConfig.cs:47），不是 QQ 绑定的 vip')
})

test('qqBind 归一：缺失字段用默认；enabled 只认真布尔 true', () => {
  assert.deepEqual(normalizeConfig({}).qqBind, { enabled: false, targetGroup: 'vip', mode: 'auto' })
  assert.deepEqual(normalizeConfig({ qqBind: { enabled: true } }).qqBind,
    { enabled: true, targetGroup: 'vip', mode: 'auto' })
  assert.equal(normalizeConfig({ qqBind: { enabled: 'yes' } }).qqBind.enabled, false, '字符串不是布尔值')
  assert.equal(normalizeConfig({ qqBind: { enabled: true, targetGroup: '  vip  ' } }).qqBind.targetGroup, 'vip')
  assert.equal(normalizeConfig({ qqBind: null }).qqBind.targetGroup, 'vip', 'qqBind 显式 null → 回落默认块')
})

test('整份归一：脏输入不抛错，也不产生 null 子结构', () => {
  const c = normalizeConfig(null)
  assert.deepEqual(c, defaultConfig())
  const d = normalizeConfig({ qqBind: 5, playtimeThresholds: 'x', ignoreGroups: 7 })
  assert.equal(typeof d.qqBind, 'object')
  assert.deepEqual(d.playtimeThresholds, [])
  assert.deepEqual(d.ignoreGroups, ['owner', 'superadmin'])
})

// ═══════════════ 4. 严格校验（非法值 400） ═══════════════

test('validateConfig：合法输入通过并完成归一', () => {
  const c = validateConfig({
    qqBind: { enabled: true, targetGroup: ' vip ', mode: 'AUTO' },
    playtimeThresholds: [{ minutes: 3000, targetGroup: 'trustedplayer', mode: 'auto' }],
    ignoreGroups: ['owner', 'OWNER', ' superadmin '],
  })
  assert.deepEqual(c.qqBind, { enabled: true, targetGroup: 'vip', mode: 'auto' })
  assert.deepEqual(c.playtimeThresholds, [{ minutes: 3000, targetGroup: 'trustedplayer', mode: 'auto' }])
  assert.deepEqual(c.ignoreGroups, ['owner', 'superadmin'])
})

test('validateConfig：非法值一律 400（不静默兜底，管理员必须看得见）', () => {
  const cases = [
    ['顶层不是对象', 'x'],
    ['qqBind 不是对象', { qqBind: 5 }],
    ['enabled 不是布尔', { qqBind: { enabled: 1, targetGroup: 'vip', mode: 'auto' } }],
    ['targetGroup 为空', { qqBind: { enabled: true, targetGroup: '   ', mode: 'auto' } }],
    ['mode 为空', { qqBind: { enabled: true, targetGroup: 'vip', mode: '' } }],
    ['minutes 是小数', { playtimeThresholds: [{ minutes: 1.5, targetGroup: 'vip', mode: 'auto' }] }],
    ['minutes 是负数', { playtimeThresholds: [{ minutes: -1, targetGroup: 'vip', mode: 'auto' }] }],
    ['minutes 不是数字', { playtimeThresholds: [{ minutes: 'abc', targetGroup: 'vip', mode: 'auto' }] }],
    ['阈值缺目标组', { playtimeThresholds: [{ minutes: 60, mode: 'auto' }] }],
    ['阈值不是对象', { playtimeThresholds: ['x'] }],
    ['阈值不是数组', { playtimeThresholds: {} }],
    ['ignoreGroups 不是数组', { ignoreGroups: 'owner' }],
    ['ignoreGroups 含非字符串', { ignoreGroups: ['owner', 3] }],
  ]
  for (const [label, input] of cases) {
    assert.throws(
      () => validateConfig(input),
      (err) => err.status === 400,
      `应拒绝（${label}）：${JSON.stringify(input)}`,
    )
  }
})

test('setByPath：白名单内的合法值写入成功', () => {
  const cfg = defaultConfig()
  setByPath(cfg, 'qqBind.enabled', true)
  setByPath(cfg, 'qqBind.targetGroup', 'vip2')
  setByPath(cfg, 'qqBind.mode', 'force')
  setByPath(cfg, 'ignoreGroups', ['owner'])
  setByPath(cfg, 'playtimeThresholds', [{ minutes: 120, targetGroup: 'vip', mode: 'auto' }])
  assert.equal(cfg.qqBind.enabled, true)
  assert.equal(cfg.qqBind.targetGroup, 'vip2')
  assert.equal(cfg.qqBind.mode, 'force')
  assert.deepEqual(cfg.ignoreGroups, ['owner'])
  assert.deepEqual(cfg.playtimeThresholds, [{ minutes: 120, targetGroup: 'vip', mode: 'auto' }])
})

test('setByPath：非法值与越界路径一律 400 拒绝（不写进配置）', () => {
  const cases = [
    ['unknown.key', 1],
    ['schema', 2],
    ['enabled', 'yes'],           // 老扁平路径已不存在：本件的字段都在 qqBind 下
    ['targetGroup', 'vip'],       // 同上
    ['qqBind', {}],               // 整块不可写（要改请用整份替换或逐字段）
    ['qqBind.enabled', 'yes'],
    ['qqBind.enabled', 1],
    ['qqBind.targetGroup', ''],
    ['qqBind.targetGroup', '   '],
    ['qqBind.targetGroup', 5],
    ['qqBind.mode', ''],
    ['qqBind.mode', null],
    ['ignoreGroups', 'owner'],
    ['ignoreGroups', ['owner', 3]],
    ['playtimeThresholds', {}],
    ['playtimeThresholds', [{ minutes: -1, targetGroup: 'vip', mode: 'auto' }]],
    ['push.retryIntervalMs', 1000],  // 节奏不是配置字段 → 不可写
    ['', true],
  ]
  for (const [key, value] of cases) {
    const cfg = defaultConfig()
    assert.throws(
      () => setByPath(cfg, key, value),
      (err) => err.status === 400,
      `应拒绝 ${JSON.stringify(key)} = ${JSON.stringify(value)}`,
    )
  }
  // 被拒绝时配置必须保持原样
  const cfg = defaultConfig()
  assert.throws(() => setByPath(cfg, 'qqBind.mode', ''))
  assert.equal(cfg.qqBind.mode, 'auto')
})

// ═══════════════ 5. 生效性警告 ═══════════════

test('生效性警告：QQ 绑定启用但目标组空 → error；忽略组空 → warn；无效时长规则 → warn', () => {
  const a = configWarnings({ qqBind: { enabled: true, targetGroup: '', mode: 'auto' } })
  assert.equal(a.some((w) => w.level === 'error'), true, '启用但目标组空必须报 error')

  const b = configWarnings({ qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' }, ignoreGroups: [] })
  assert.equal(b.some((w) => w.level === 'warn'), true, '空保护名单必须被提示')

  const c = configWarnings({ qqBind: { enabled: false, targetGroup: '', mode: 'auto' }, ignoreGroups: [] })
  assert.equal(c.some((w) => w.level === 'error'), false, '未启用时空目标组不是错误')

  // 时长规则里 minutes<=0 或目标组空的条目会被服端算法（Minutes>0 && TargetGroup 非空）滤掉
  const d = configWarnings({ playtimeThresholds: [{ minutes: 0, targetGroup: 'vip', mode: 'auto' }] })
  assert.equal(d.some((w) => w.message.includes('不会生效')), true, '无效时长规则必须被提示')

  const e = configWarnings({ playtimeThresholds: [{ minutes: 60, targetGroup: '', mode: 'auto' }] })
  assert.equal(e.some((w) => w.message.includes('不会生效')), true)

  // 合法配置不该有任何警告
  assert.deepEqual(configWarnings({
    qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' },
    playtimeThresholds: [{ minutes: 3000, targetGroup: 'trustedplayer', mode: 'auto' }],
    ignoreGroups: ['owner', 'superadmin'],
  }), [])
})

// ═══════════════ 6. 下发载荷必带齐字段 ═══════════════

test('toGamePayload：三个字段永远带齐（含空数组也显式发 []）', () => {
  const p = toGamePayload({}, 7)
  assert.equal(p.version, 7)
  assert.deepEqual(p.qqBind, { enabled: false, targetGroup: 'vip', mode: 'auto' })
  assert.ok(Array.isArray(p.playtimeThresholds), 'playtimeThresholds 必须是数组')
  assert.deepEqual(p.playtimeThresholds, [])
  assert.deepEqual(p.ignoreGroups, ['owner', 'superadmin'])

  // 就算传进来一个"残缺"的配置对象，也不能发出缺字段的载荷
  const p2 = toGamePayload({ qqBind: { enabled: true, targetGroup: 'vip' }, ignoreGroups: undefined }, 1)
  assert.ok(Object.prototype.hasOwnProperty.call(p2, 'ignoreGroups'))
  assert.deepEqual(p2.ignoreGroups, ['owner', 'superadmin'])
  assert.equal(p2.version, 1)

  // 管理员显式删除全部时长规则时，必须把"空"这个意图传下去（不能被回落成默认规则）
  const p3 = toGamePayload({ playtimeThresholds: [] }, 2)
  assert.deepEqual(p3.playtimeThresholds, [])

  // 载荷是深拷贝：改载荷不影响源配置（免得下发过程中的改动污染权威配置）
  const src = { playtimeThresholds: [{ minutes: 60, targetGroup: 'vip', mode: 'auto' }] }
  const p4 = toGamePayload(src, 3)
  p4.playtimeThresholds[0].minutes = 999
  assert.equal(src.playtimeThresholds[0].minutes, 60)

  // version 非法时兜到 1（服端要求正整数）
  assert.equal(toGamePayload({}, 0).version, 1)
  assert.equal(toGamePayload({}, -3).version, 1)
  assert.equal(toGamePayload({}, 'x').version, 1)
})

// ═══════════════ 7. 落盘 / 读取 ═══════════════

test('保存 → 读取：字段往返一致，且写入的是归一后的形状', async () => {
  const file = cfgFile('roundtrip')
  await saveConfig(file, {
    qqBind: { enabled: true, targetGroup: ' vip ', mode: 'AUTO' },
    playtimeThresholds: [{ minutes: '3000', targetGroup: ' trustedplayer ', mode: 'AUTO' }],
    ignoreGroups: ['owner', ' OWNER ', 'superadmin'],
  })
  const raw = JSON.parse(await readFile(file, 'utf8'))
  assert.deepEqual(raw.qqBind, { enabled: true, targetGroup: 'vip', mode: 'auto' })
  assert.deepEqual(raw.playtimeThresholds, [{ minutes: 3000, targetGroup: 'trustedplayer', mode: 'auto' }])
  assert.deepEqual(raw.ignoreGroups, ['owner', 'superadmin'])
  // 顶层只有旧版那三个字段（节奏不落盘）
  assert.deepEqual(Object.keys(raw).sort(), ['ignoreGroups', 'playtimeThresholds', 'qqBind'])

  const loaded = await loadConfig(file)
  assert.equal(loaded.existed, true)
  assert.equal(loaded.error, '')
  assert.equal(loaded.config.qqBind.enabled, true)
  assert.deepEqual(loaded.config.ignoreGroups, ['owner', 'superadmin'])
})

test('保存会留 .bak，且再次保存不残留 .tmp', async () => {
  const file = cfgFile('backup')
  await saveConfig(file, { qqBind: { enabled: false, targetGroup: 'vip', mode: 'auto' } })
  await saveConfig(file, { qqBind: { enabled: true, targetGroup: 'vip', mode: 'auto' } })
  const bak = JSON.parse(await readFile(`${file}.bak`, 'utf8'))
  assert.equal(bak.qqBind.enabled, false, '.bak 应是上一份配置')
  await assert.rejects(readFile(`${file}.tmp`, 'utf8'), '临时文件必须已被 rename 掉')
})

test('读取不存在的文件：按默认（未启用）且不报错', async () => {
  const r = await loadConfig(cfgFile('does-not-exist'))
  assert.equal(r.existed, false)
  assert.equal(r.error, '')
  assert.equal(r.config.qqBind.enabled, false)
  assert.deepEqual(r.config.ignoreGroups, ['owner', 'superadmin'])
  assert.deepEqual(r.config.playtimeThresholds, [])
})

test('读取损坏的 JSON：回落默认（未启用）并带回明确错误（不抛错）', async () => {
  const file = cfgFile('broken')
  await writeFile(file, '{ this is not json', 'utf8')
  const r = await loadConfig(file)
  assert.equal(r.existed, true)
  assert.equal(r.config.qqBind.enabled, false, '读不懂配置时绝不允许按启用运行')
  assert.deepEqual(r.config.ignoreGroups, ['owner', 'superadmin'])
  assert.match(r.error, /不是合法 JSON/)
})

test('读取顶层不是对象的文件：同样回落默认并带回错误', async () => {
  const file = cfgFile('array-top')
  await writeFile(file, '[1,2,3]', 'utf8')
  const r = await loadConfig(file)
  assert.equal(r.config.qqBind.enabled, false)
  assert.match(r.error, /顶层不是对象/)
})

test('读取旧形态配置（扁平 enabled/targetGroup）时不会误以为启用了 QQ 绑定提升', async () => {
  const file = cfgFile('flat-legacy')
  // 模拟"老宿主写出来的扁平老结构"：本件不认识这些顶层字段，必须按默认（未启用）处理，
  // 绝不能把它们当成 qqBind 的值（那会造成"配置看着没变、行为却变了"）
  await writeFile(file, JSON.stringify({
    schema: 1, enabled: true, targetGroup: 'vip', mode: 'force', ignoreGroups: ['helper'],
  }), 'utf8')
  const r = await loadConfig(file)
  assert.equal(r.config.qqBind.enabled, false, '扁平老结构的 enabled 不属于 qqBind 块')
  assert.deepEqual(r.config.ignoreGroups, ['helper'], '顶层 ignoreGroups 的名字没变，照旧采用')
  assert.deepEqual(r.config.playtimeThresholds, [])
})

test('mergeConfig：对象递归合并，数组整体替换', () => {
  const merged = mergeConfig({ a: { b: 1, c: 2 }, list: [1, 2] }, { a: { b: 9 }, list: [3] })
  assert.deepEqual(merged, { a: { b: 9, c: 2 }, list: [3] })
})
