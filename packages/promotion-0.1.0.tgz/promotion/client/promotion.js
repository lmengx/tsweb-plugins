/**
 * promotion 前端半 —— 管理页「权限提升」（后端设置 → /b/promotion）
 *
 * 界面照旧版 TsWeb 的 frontend/src/views/console/PromotionConfigView.vue 做：
 * **三块卡片**，文案与交互逐条对齐，只是从 Vue 换成本仓客户端插件的原生写法。
 *   1. 「QQ 绑定提升」    开关 + 目标权限组下拉 + 提升模式下拉；说明"玩家绑定 QQ 后自动提升权限组"
 *   2. 「游玩时长提升」   右上角"N 条规则"；每条规则可删（✕）、含**天/时/分三个数字输入**
 *                        （换算照旧版 toDays/toHours/toMins/fromDHM，注意 fromDHM 有
 *                         Math.max(1, ...) → **最小 1 分钟**）、并显示"= N 分钟（X.X 小时）"；
 *                        底部"＋ 添加阈值"，新增项默认 { minutes:60, targetGroup:'default', mode:'auto' }
 *   3. 「忽略组」        说明"属于以下组的玩家将**始终不会被自动提升**。"；已有组是可删标签，
 *                        输入框回车或点 ＋ 添加，**忽略大小写去重**
 * 模式下拉文案照旧版：
 *   auto  → 「自动（检查父组链，不降级）」
 *   force → 「强制（忽略当前组直接设为目标组）」
 *
 * 保存：照旧版**改动即自动保存**（500ms 防抖），成功显示"已保存"；
 * 另外显示**下发状态**（推给了哪些服、成功/失败），让"配置是否真生效"可见。
 *
 * 与旧版界面的两处**必要差异**（都是新架构带来的，交付报告里也已列出）：
 *   1. 目标权限组下拉的选项来自**实际存在的用户组**：宿主经 base 插件的
 *      /data/base/players/groups 取，取不到就退化为文本输入并**说明原因**
 *      （旧版是后端 /api/tshock/groups，新宿主没有那条链路）。
 *   2. 「QQ 绑定提升」在 qq-bind 未安装时显示为**不可用并给出原因**：
 *      服端要读 qq-bind 落盘的 qqbind-snapshot.json 才能识别绑定，
 *      而「游玩时长提升」不依赖它，照常工作。
 *
 * 依赖宿主能力（window.tsweb，由 web 插件提供）：
 *   - window.tsweb.registerView({ id, title, section, path, render })
 *   - window.tsweb.api(path, opts)   带 Bearer 的统一请求：{ ok, status, data }
 *
 * 约定：禁止 emoji；不引入第三方 UI 库；图标用内联 SVG；局部类名统一 pr- 前缀。
 * 本文件是 **ESM 模块**（宿主用 import(url) 加载），同时把纯函数具名导出，
 * 供 test/client-ui.test.mjs 在 Node 里做无浏览器验证（见该文件顶部说明）。
 */

// ════════════════════════════════════════════
//  纯函数（具名导出；无 DOM 依赖，可在 Node 里直接测）
// ════════════════════════════════════════════

/**
 * 模式下拉文案。**文案照旧版 PromotionConfigView.vue:20-23 一字不改**。
 * 顺序也是旧版顺序（auto 在前）。
 */
export const MODE_OPTIONS = [
  { value: 'auto', label: '自动（检查父组链，不降级）' },
  { value: 'force', label: '强制（忽略当前组直接设为目标组）' },
]

/** 新增一条时长规则的默认值（旧版 PromotionConfigView.vue:120-126 的 addThreshold） */
export const DEFAULT_THRESHOLD = { minutes: 60, targetGroup: 'default', mode: 'auto' }

/** 分钟数兜底成非负整数（脏值/非数字一律 0，绝不让 NaN 流到界面上） */
function toMinuteNumber(minutes) {
  const n = Number(minutes)
  return Number.isFinite(n) ? n : 0
}

/** 分钟 → 天（旧版 toDays，Vue:29） */
export function toDays(minutes) {
  return Math.floor(toMinuteNumber(minutes) / 1440)
}

/** 分钟 → 时（余数部分，旧版 toHours，Vue:30） */
export function toHours(minutes) {
  return Math.floor((toMinuteNumber(minutes) % 1440) / 60)
}

/** 分钟 → 分（余数部分，旧版 toMins，Vue:31） */
export function toMins(minutes) {
  return toMinuteNumber(minutes) % 60
}

/**
 * 模式归一：**只有 auto（序数忽略大小写、不 trim）有特殊语义**，其余一律 force，
 * 与旧版 ParseMode（TsWeb/plugin/PromotionConfig.cs:328-333）、宿主 config.js:normalizeMode
 * 及服端 PromotionConfigStore.NormalizeMode 同一判据。
 * 曾经这里用大小写敏感比较，服端偶尔回 'AUTO' 就会被显示成"强制"，
 * 那种"界面显示的模式不等于实际模式"正是要避免的；也曾经多一个 .trim()，
 * 会把 ' auto ' 显示成"自动"而服端按旧版判据执行的是"强制"（同一种不一致），故去掉。
 * 说明：界面拿到的 mode 已经过宿主归一（只会是 'auto'/'force'），本函数是防御性第二道。
 */
export function normalizeClientMode(value) {
  return String(value == null ? '' : value).toLowerCase() === 'auto' ? 'auto' : 'force'
}


/**
 * 天/时/分 → 分钟。**照旧版 fromDHM（Vue:33-38），含 Math.max(1, ...)**：
 * 全为 0 或全为空时结果是 1 —— 也就是**最小 1 分钟**。
 * 这不是笔误：0 分钟的阈值会被服端算法（Minutes > 0）直接滤掉，
 * 旧版用"最小 1 分钟"保证界面上新增的规则一定是有效的。
 */
export function fromDHM(d, h, m) {
  const dd = parseInt(d, 10) || 0
  const hh = parseInt(h, 10) || 0
  const mm = parseInt(m, 10) || 0
  return Math.max(1, dd * 1440 + hh * 60 + mm)
}

/** 时长规则的汇总文案（旧版 Vue:257 的 `= {{minutes}} 分钟（{{(minutes/60).toFixed(1)}} 小时）`） */
export function formatTotal(minutes) {
  const n = Number(minutes) || 0
  return `= ${n} 分钟（${(n / 60).toFixed(1)} 小时）`
}

/** 右上角徽标文案（旧版 Vue:197 的 `{{ length }} 条规则`） */
export function rulesLabel(count) {
  return `${Number(count) || 0} 条规则`
}

/**
 * 忽略组去重（忽略大小写，保留首现写法）。与宿主 config.js 的 normalizeIgnoreGroups
 * 以及旧版 DedupIgnoreGroups 的口径一致；这里返回**新数组**，不改入参。
 */
export function dedupeIgnoreGroups(list) {
  const seen = {}
  const out = []
  for (const raw of Array.isArray(list) ? list : []) {
    const name = String(raw == null ? '' : raw).trim()
    if (name === '') continue
    const key = name.toLowerCase()
    if (seen[key]) continue
    seen[key] = true
    out.push(name)
  }
  return out
}

/**
 * 添加一个忽略组：空串/纯空白不添加，**忽略大小写去重**（重复时不添加，返回原列表的副本）。
 * @returns {{ list: string[], added: boolean }}
 */
export function addIgnoreGroup(list, name) {
  const current = Array.isArray(list) ? list.slice() : []
  const value = String(name == null ? '' : name).trim()
  if (value === '') return { list: current, added: false }
  if (current.some((g) => String(g).toLowerCase() === value.toLowerCase())) {
    return { list: current, added: false }
  }
  current.push(value)
  return { list: current, added: true }
}

/** 删除第 i 项（越界不抛错，返回新数组） */
export function removeAt(list, i) {
  const current = Array.isArray(list) ? list.slice() : []
  const idx = Number(i)
  if (!Number.isInteger(idx) || idx < 0 || idx >= current.length) return current
  current.splice(idx, 1)
  return current
}

/**
 * 把"服端/宿主返回的配置"归一成界面状态（旧版 Vue:86-108 的 fetchData 归一）。
 * 空 targetGroup 保留成空串（用户能看到"没选"这个事实，而不是被偷偷换成默认值）。
 */
export function normalizeLoadedConfig(raw) {
  const c = raw && typeof raw === 'object' ? raw : {}
  const qq = c.qqBind && typeof c.qqBind === 'object' ? c.qqBind : {}
  const thresholds = Array.isArray(c.playtimeThresholds) ? c.playtimeThresholds : []
  const ignore = Array.isArray(c.ignoreGroups) ? c.ignoreGroups : []

  return {
    qqBind: {
      enabled: qq.enabled === true,
      targetGroup: String(qq.targetGroup == null ? '' : qq.targetGroup),
      mode: normalizeClientMode(qq.mode == null ? 'auto' : qq.mode),
    },
    playtimeThresholds: thresholds.map((t) => ({
      minutes: Math.max(0, Math.floor(Number(t && t.minutes) || 0)),
      targetGroup: String((t && t.targetGroup) == null ? '' : t.targetGroup),
      mode: normalizeClientMode((t && t.mode) == null ? 'auto' : t.mode),
    })),
    ignoreGroups: dedupeIgnoreGroups(ignore),
  }
}

/** 保存请求体（**整份替换**：改动即自动保存天然提交整个配置，不必逐字段 diff） */
export function buildSavePayload(config) {
  return { config: normalizeLoadedConfig(config) }
}

/** 组名下拉的选项 HTML（`selectedValue` 与选项大小写不敏感比对，避免大小写差异导致"看起来没选"） */
export function groupOptionsHtml(groups, selectedValue) {
  const list = Array.isArray(groups) ? groups : []
  const sel = String(selectedValue == null ? '' : selectedValue).toLowerCase()
  const head = '<option value="" disabled' + (sel === '' ? ' selected' : '') + '>选择权限组...</option>'
  const body = list.map((g) => {
    const name = String(g)
    const isSel = name.toLowerCase() === sel
    return '<option value="' + esc(name) + '"' + (isSel ? ' selected' : '') + '>' + esc(name) + '</option>'
  }).join('')
  return head + body
}

/** HTML 转义（值都来自配置文件/服端返回，必须转义后再拼进 innerHTML） */
export function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ))
}

// ════════════════════════════════════════════
//  视图（需要 DOM + window.tsweb；没有就整段跳过）
// ════════════════════════════════════════════

const tsw = typeof window !== 'undefined' ? window.tsweb : null

if (tsw && typeof tsw.registerView === 'function') {
  bootView(tsw)
}

function bootView(tsw) {
  let root = null
  let styleDone = false
  let ready = false
  let saveTimer = null
  let groupsLoading = false
  /** 本地编辑版本号：每次本地编辑 +1。保存请求发出时快照它，响应回来再比一次（D8 的判据） */
  let editSeq = 0
  /** 保存在飞期间又收到编辑 → 置位；本次保存结束后补一次尾保存（D8：不丢编辑，且只补一次） */
  let tailPending = false

  const state = {
    config: { qqBind: { enabled: false, targetGroup: '', mode: 'auto' }, playtimeThresholds: [], ignoreGroups: [] },
    configFile: '',
    configError: '',
    warnings: [],
    dependencies: { qqBind: { installed: true, reason: '' } },
    groups: [],
    groupsError: '',
    groupsSource: null,
    servers: [],
    desiredVersion: 0,
    pendingCount: 0,
    probe: null,
    status: { text: '', cls: 'muted' },
    saving: false,
  }

  function $(id) {
    return root ? root.querySelector('#' + id) : null
  }

  function setStatus(text, cls) {
    state.status = { text: text || '', cls: cls || 'muted' }
    const el = $('pr-status')
    if (el) {
      el.className = 'pr-status ' + state.status.cls
      el.textContent = state.status.text
    }
  }

  function injectStyle() {
    if (styleDone || typeof document === 'undefined') return
    styleDone = true
    const css = '' +
      '.pr-wrap{display:flex;flex-direction:column;gap:18px;max-width:820px}' +
      '.pr-card{border:1px solid var(--border,#2a2f3a);border-radius:10px;padding:18px 20px}' +
      '.pr-card-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:4px}' +
      '.pr-card-head h3{margin:0;font-size:15px}' +
      '.pr-desc{margin:4px 0 16px;font-size:12.5px;color:var(--muted,#9aa4b2);line-height:1.6}' +
      '.pr-desc strong{color:var(--text,#e6e9ef)}' +
      '.pr-badge{font-size:12px;padding:2px 10px;border-radius:12px;background:var(--accent,#3b82f6);color:#fff}' +
      '.pr-row{display:flex;align-items:center;gap:10px;margin:10px 0;flex-wrap:wrap}' +
      '.pr-row>label.pr-label{min-width:96px;color:var(--muted,#9aa4b2);font-size:13px}' +
      '.pr-field{flex:1;min-width:220px}' +
      '.pr-field>label{display:block;margin-bottom:6px;color:var(--muted,#9aa4b2);font-size:12.5px}' +
      '.pr-select,.pr-input{width:100%;box-sizing:border-box;padding:7px 10px;font-size:13px;' +
      'background:var(--bg-2,#171b23);color:var(--text,#e6e9ef);border:1px solid var(--border,#2a2f3a);border-radius:6px}' +
      '.pr-select:disabled,.pr-input:disabled{opacity:.55;cursor:not-allowed}' +
      '.pr-th{border:1px solid var(--border,#2a2f3a);border-radius:8px;padding:14px;margin-bottom:12px}' +
      '.pr-th-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}' +
      '.pr-th-idx{font-weight:600;font-size:12.5px;color:var(--accent,#3b82f6)}' +
      '.pr-x{width:24px;height:24px;border:none;border-radius:50%;cursor:pointer;font-size:12px;' +
      'background:rgba(239,68,68,.15);color:#ef4444;display:flex;align-items:center;justify-content:center}' +
      '.pr-x:hover{background:#ef4444;color:#fff}' +
      '.pr-dhm{display:flex;gap:8px;margin-bottom:4px}' +
      '.pr-dhm-item{display:flex;align-items:center;gap:4px;flex:1}' +
      '.pr-dhm-item .pr-input{text-align:center}' +
      '.pr-dhm-label{color:var(--muted,#9aa4b2);font-size:12px;width:18px}' +
      '.pr-total{display:block;font-size:12px;color:var(--muted,#9aa4b2);margin-top:2px}' +
      '.pr-add{width:100%;padding:9px;border:1px dashed var(--border,#2a2f3a);border-radius:8px;' +
      'background:transparent;color:var(--muted,#9aa4b2);font-size:13px;cursor:pointer}' +
      '.pr-add:hover{border-color:var(--accent,#3b82f6);color:var(--accent,#3b82f6)}' +
      '.pr-tags{display:flex;flex-wrap:wrap;gap:8px;align-items:center}' +
      '.pr-tag{display:inline-flex;align-items:center;gap:4px;padding:3px 4px 3px 10px;' +
      'border:1px solid var(--border,#2a2f3a);border-radius:6px;font-size:13px}' +
      '.pr-tag .pr-x{width:20px;height:20px;font-size:10px}' +
      '.pr-ignore-add{display:inline-flex;align-items:center;gap:6px}' +
      '.pr-ignore-input{width:130px;padding:5px 8px;font-size:12.5px}' +
      '.pr-plus{width:28px;height:28px;border:none;border-radius:50%;cursor:pointer;font-size:14px;' +
      'background:var(--accent,#3b82f6);color:#fff}' +
      '.pr-plus:disabled{opacity:.4;cursor:not-allowed}' +
      '.pr-hint{font-size:12px;color:var(--muted,#9aa4b2);margin:2px 0 0;line-height:1.6}' +
      '.pr-status{font-size:13px;min-height:20px;margin:2px 0 10px}' +
      '.pr-ok{color:#3fae6a}.pr-error{color:#e0533d}.pr-warn{color:#d9a41a}.pr-muted{color:var(--muted,#9aa4b2)}' +
      '.pr-table{width:100%;border-collapse:collapse;font-size:12.5px}' +
      '.pr-table th,.pr-table td{border-bottom:1px solid var(--border,#2a2f3a);padding:6px 8px;text-align:left;vertical-align:top}' +
      '.pr-table th{color:var(--muted,#9aa4b2);font-weight:500}' +
      '.pr-code{font-family:ui-monospace,Consolas,monospace;font-size:12px;word-break:break-all}' +
      '.pr-inline{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}' +
      '.pr-switch{position:relative;display:inline-block;width:46px;height:26px;flex-shrink:0}' +
      '.pr-switch input{opacity:0;width:0;height:0}' +
      '.pr-slider{position:absolute;cursor:pointer;inset:0;border:2px solid var(--border,#2a2f3a);' +
      'border-radius:26px;background:var(--bg-2,#171b23);transition:all .25s}' +
      '.pr-slider:before{content:"";position:absolute;height:16px;width:16px;left:3px;bottom:3px;' +
      'background:var(--muted,#9aa4b2);border-radius:50%;transition:all .25s}' +
      '.pr-switch input:checked+.pr-slider{background:var(--accent,#3b82f6);border-color:var(--accent,#3b82f6)}' +
      '.pr-switch input:checked+.pr-slider:before{transform:translateX(20px);background:#fff}' +
      '.pr-switch input:disabled+.pr-slider{opacity:.45;cursor:not-allowed}'
    const el = document.createElement('style')
    el.textContent = css
    document.head.appendChild(el)
  }

  // ═══════════ 渲染 ═══════════

  function renderShell(container) {
    container.innerHTML =
      '<h2 style="margin:0 0 4px">权限提升配置</h2>' +
      '<p class="pr-desc" style="margin-bottom:14px">配置 QQ 绑定和游玩时长的自动权限提升规则</p>' +
      '<div id="pr-status" class="pr-status ' + esc(state.status.cls) + '">' + esc(state.status.text) + '</div>' +
      '<div class="pr-wrap">' +
      '<div id="pr-qq"></div>' +
      '<div id="pr-thresholds"></div>' +
      '<div id="pr-ignore"></div>' +
      '<div id="pr-push"></div>' +
      '</div>'
  }

  function warningsHtml() {
    let html = ''
    if (state.configError) html += '<p class="pr-error pr-hint">' + esc(state.configError) + '</p>'
    for (const w of state.warnings || []) {
      html += '<p class="' + (w.level === 'error' ? 'pr-error' : 'pr-warn') + ' pr-hint">' + esc(w.message) + '</p>'
    }
    return html
  }

  /** 目标权限组控件：有组列表 → 下拉；取不到 → 文本输入 + 说明原因（绝不静默给空下拉） */
  function groupControlHtml(idAttr, value, disabled) {
    if (state.groups.length > 0) {
      return '<select class="pr-select" ' + idAttr + (disabled ? ' disabled' : '') + '>' +
        groupOptionsHtml(state.groups, value) + '</select>'
    }
    const reason = state.groupsError
      ? '取不到服务器上的用户组列表（' + esc(state.groupsError) + '），已退化为文本输入：请填写各服 TShock 里实际存在的组名'
      : '正在读取服务器上的用户组列表...'
    return '<input class="pr-input" type="text" ' + idAttr + ' value="' + esc(value) + '"' +
      (disabled ? ' disabled' : '') + ' placeholder="例如 vip">' +
      '<p class="pr-hint">' + reason + '</p>'
  }

  function renderQq() {
    const box = $('pr-qq')
    if (!box) return
    const q = state.config.qqBind
    const dep = state.dependencies.qqBind || { installed: true, reason: '' }
    // 软依赖：qq-bind 未安装时服端识别不到绑定 —— 这一块显示为不可用并给出原因，
    // 但**不隐藏**（管理员能看到当前配置，也知道装了什么就能用）
    const depDisabled = dep.installed !== true
    // D7：旧版是这两个下拉在**开关关闭**时禁用（PromotionConfigView.vue:179、:186），
    // 本插件另加了软依赖判定 —— 两者都要：任一为真即禁用这两个下拉。
    // 注意**开关本身只受软依赖约束**：若把它也算进 fieldsDisabled，开关一关就被自己禁用、再也打不开。
    const fieldsDisabled = depDisabled || q.enabled !== true

    box.innerHTML = '<div class="pr-card">' +
      '<div class="pr-card-head"><h3>QQ 绑定提升</h3>' +
      '<label class="pr-switch"><input type="checkbox" data-prqq="enabled"' +
      (q.enabled === true ? ' checked' : '') + (depDisabled ? ' disabled' : '') + '>' +
      '<span class="pr-slider"></span></label></div>' +
      '<p class="pr-desc">玩家绑定 QQ 后自动提升权限组</p>' +
      // 禁用必须说清原因：不可用时给宿主给的原因；开关关闭时说明是开关关的
      (depDisabled
        ? '<p class="pr-warn pr-hint">当前不可用：' + esc(dep.reason || '未检测到 qq-bind 插件') + '</p>'
        : (fieldsDisabled
          ? '<p class="pr-hint">「QQ 绑定提升」开关已关闭：目标权限组与提升模式在开关打开前不可编辑。</p>'
          : '')) +
      warningsHtml() +
      '<div class="pr-row"><div class="pr-field"><label>目标权限组</label>' +
      groupControlHtml('data-prqq="targetGroup"', q.targetGroup, fieldsDisabled) + '</div>' +
      '<div class="pr-field"><label>提升模式</label>' +
      '<select class="pr-select" data-prqq="mode"' + (fieldsDisabled ? ' disabled' : '') + '>' +
      MODE_OPTIONS.map((o) => '<option value="' + esc(o.value) + '"' +
        (String(q.mode) === o.value ? ' selected' : '') + '>' + esc(o.label) + '</option>').join('') +
      '</select></div></div>' +
      '<p class="pr-hint">识别时机：玩家<strong>登录时</strong>（由游戏服半读 qq-bind 落盘的绑定快照文件）。' +
      '保存配置不会立刻晋升在线玩家。</p>' +
      '</div>'
  }

  function thresholdHtml(t, i) {
    return '<div class="pr-th" data-prth-idx="' + i + '">' +
      '<div class="pr-th-head"><span class="pr-th-idx">#' + (i + 1) + '</span>' +
      '<button class="pr-x" data-pract="del-threshold" data-idx="' + i + '" title="删除此规则">✕</button></div>' +
      '<div class="pr-field"><label>游玩时长</label>' +
      '<div class="pr-dhm">' +
      '<div class="pr-dhm-item"><input class="pr-input" type="number" min="0" data-prth="day" data-idx="' + i +
      '" value="' + toDays(t.minutes) + '" placeholder="0"><span class="pr-dhm-label">天</span></div>' +
      '<div class="pr-dhm-item"><input class="pr-input" type="number" min="0" max="23" data-prth="hour" data-idx="' + i +
      '" value="' + toHours(t.minutes) + '" placeholder="0"><span class="pr-dhm-label">时</span></div>' +
      '<div class="pr-dhm-item"><input class="pr-input" type="number" min="0" max="59" data-prth="min" data-idx="' + i +
      '" value="' + toMins(t.minutes) + '" placeholder="0"><span class="pr-dhm-label">分</span></div>' +
      '</div>' +
      '<span class="pr-total" data-prth-total="' + i + '">' + esc(formatTotal(t.minutes)) + '</span></div>' +
      '<div class="pr-field"><label>目标权限组</label>' +
      groupControlHtml('data-prth="targetGroup" data-idx="' + i + '"', t.targetGroup, false) + '</div>' +
      '<div class="pr-field"><label>提升模式</label>' +
      '<select class="pr-select" data-prth="mode" data-idx="' + i + '">' +
      MODE_OPTIONS.map((o) => '<option value="' + esc(o.value) + '"' +
        (String(t.mode) === o.value ? ' selected' : '') + '>' + esc(o.label) + '</option>').join('') +
      '</select></div></div>'
  }

  function renderThresholds() {
    const box = $('pr-thresholds')
    if (!box) return
    const list = state.config.playtimeThresholds
    box.innerHTML = '<div class="pr-card">' +
      '<div class="pr-card-head"><h3>游玩时长提升</h3>' +
      '<span class="pr-badge" id="pr-th-badge">' + esc(rulesLabel(list.length)) + '</span></div>' +
      '<p class="pr-desc">达到指定游玩时长后自动提升权限组（取最高匹配规则）</p>' +
      (list.length === 0 ? '<p class="pr-hint">还没有规则。点下面的「＋ 添加阈值」新增一条。</p>' : '') +
      list.map((t, i) => thresholdHtml(t, i)).join('') +
      '<button class="pr-add" data-pract="add-threshold">＋ 添加阈值</button>' +
      '<p class="pr-hint">守护说明：分钟数必须大于 0、目标组不能为空，否则该条规则会被游戏服跳过' +
      '（页面上会给出警告）。时长数据来自 online-stats 记录在 player_daily_stat 的累计分钟数，' +
      '本插件<strong>只读</strong>它、不重复计时。</p>' +
      '</div>'
  }

  function renderIgnore() {
    const box = $('pr-ignore')
    if (!box) return
    const tags = state.config.ignoreGroups.map((g, i) =>
      '<span class="pr-tag">' + esc(g) +
      '<button class="pr-x" data-pract="del-ignore" data-idx="' + i + '" title="移除此组">✕</button></span>').join('')
    box.innerHTML = '<div class="pr-card">' +
      '<div class="pr-card-head"><h3>忽略组</h3></div>' +
      '<p class="pr-desc">属于以下组的玩家将<strong>始终不会被自动提升</strong>。</p>' +
      '<div class="pr-tags">' + tags +
      '<span class="pr-ignore-add">' +
      '<input class="pr-input pr-ignore-input" type="text" data-prignore="new" placeholder="输入组名...">' +
      '<button class="pr-plus" data-pract="add-ignore" title="添加">＋</button>' +
      '</span></div>' +
      '<p class="pr-hint">忽略大小写去重；回车或点 ＋ 添加。保护名单为空时页面上会给出警告。</p>' +
      '</div>'
  }

  function renderPush() {
    const box = $('pr-push')
    if (!box) return
    const probeByServer = {}
    const probe = state.probe && Array.isArray(state.probe.servers) ? state.probe.servers : []
    probe.forEach((p) => { probeByServer[String(p.id)] = p })

    const rows = state.servers.map((s) => {
      const p = probeByServer[String(s.id)]
      let probeCell
      if (!p) probeCell = '<span class="pr-muted">未探测</span>'
      else if (!p.ok) probeCell = '<span class="pr-error">读取失败：' + esc(p.error || '') + '</span>'
      else if (p.match) probeCell = '<span class="pr-ok">与宿主一致</span>'
      else probeCell = '<span class="pr-warn">不一致：' + esc((p.diff || []).join('；')) + '</span>'

      const bind = s.bindings
      const bindCell = bind
        ? esc(String(bind.count || 0)) + ' 条' + (bind.note ? '<br><span class="pr-muted">' + esc(bind.note) + '</span>' : '')
        : '<span class="pr-muted">-</span>'

      return '<tr>' +
        '<td>' + esc(s.name || s.id) + '<br><span class="pr-muted pr-code">' + esc(s.id) + '</span></td>' +
        '<td>' + (s.ok ? '<span class="pr-ok">成功</span>' : '<span class="pr-error">失败</span>') +
        '<br><span class="pr-muted">v' + esc(s.version) + '</span></td>' +
        '<td>' + (s.error ? '<span class="pr-error">' + esc(s.error) + '</span>' : '<span class="pr-muted">-</span>') + '</td>' +
        '<td>' + probeCell + '</td>' +
        '<td>' + bindCell + '</td>' +
        '</tr>'
    }).join('')

    box.innerHTML = '<div class="pr-card">' +
      '<div class="pr-card-head"><h3>下发状态</h3>' +
      '<span class="pr-hint">期望版本 v' + esc(state.desiredVersion) + '　未确认 ' + esc(state.pendingCount) + ' 台</span></div>' +
      '<p class="pr-desc">配置改动会<strong>立即下发</strong>到启用中的服务器；这里的每一行都是「配置是否真生效」的证据。</p>' +
      (state.servers.length === 0
        ? '<p class="pr-hint">尚未向任何服务器下发（没有启用中的服务器，或宿主刚启动）。</p>'
        : '<table class="pr-table"><thead><tr><th>服务器</th><th>最近下发</th><th>失败原因</th>' +
          '<th>服端实际生效</th><th>服端绑定快照</th></tr></thead><tbody>' + rows + '</tbody></table>') +
      '<div class="pr-inline">' +
      '<button class="pr-plus" style="width:auto;border-radius:6px;padding:6px 12px;font-size:12.5px" ' +
      'data-pract="push-pending">补推未确认的服务器</button>' +
      '<button class="pr-plus" style="width:auto;border-radius:6px;padding:6px 12px;font-size:12.5px" ' +
      'data-pract="push-all">全部重推</button>' +
      '<button class="pr-plus" style="width:auto;border-radius:6px;padding:6px 12px;font-size:12.5px" ' +
      'data-pract="reload">重新读取</button>' +
      '</div>' +
      '<p class="pr-hint pr-code">配置文件：' + esc(state.configFile || '(未知)') + '</p>' +
      '</div>'
  }

  function renderAll() {
    renderQq()
    renderThresholds()
    renderIgnore()
    renderPush()
  }

  /** 只更新某一行的"= N 分钟（X.X 小时）"：输入时不整块重渲染，避免光标跳出输入框 */
  function updateTotalLabel(i) {
    const el = root ? root.querySelector('[data-prth-total="' + i + '"]') : null
    if (el) el.textContent = formatTotal(state.config.playtimeThresholds[i].minutes)
  }

  // ═══════════ 数据 ═══════════

  async function loadConfig() {
    const res = await tsw.api('/api/promotion/config')
    if (!res.ok) {
      setStatus('读取配置失败：' + errText(res.data, res.status), 'pr-error')
      return false
    }
    const d = res.data || {}
    state.config = normalizeLoadedConfig(d.config)
    state.configFile = d.configFile || ''
    state.configError = d.configError || ''
    state.warnings = Array.isArray(d.warnings) ? d.warnings : []
    state.dependencies = d.dependencies && d.dependencies.qqBind
      ? d.dependencies
      : { qqBind: { installed: true, reason: '' } }
    return true
  }

  async function loadGroups() {
    const res = await tsw.api('/api/promotion/groups')
    if (!res.ok) {
      state.groups = []
      state.groupsError = errText(res.data, res.status)
      return false
    }
    const d = res.data || {}
    state.groups = Array.isArray(d.groups) ? d.groups.map(String) : []
    state.groupsSource = d.source || null
    // 宿主已经把"取不到"的两种原因（没有服务器 / 全部失败）写进 error，如实展示
    state.groupsError = state.groups.length > 0 ? '' : (d.error || '服务器没有返回任何用户组')
    return state.groups.length > 0
  }

  async function loadStatus(withProbe) {
    const res = await tsw.api('/api/promotion/status' + (withProbe ? '?probe=1' : ''))
    if (!res.ok) return false
    const d = res.data || {}
    state.servers = Array.isArray(d.servers) ? d.servers : []
    state.desiredVersion = d.desiredVersion != null ? d.desiredVersion : 0
    state.pendingCount = Number(d.pendingCount || 0)
    state.probe = d.probe || null
    // 状态里也有软依赖信息：以它为准（避免"配置接口刚读到时 qq-bind 还没就绪"这类时序差）
    if (d.dependencies && d.dependencies.qqBind) state.dependencies = d.dependencies
    renderQq()
    renderPush()
    return true
  }

  function errText(data, status) {
    if (data && data.serverHalfMissing) {
      return (data.error || '游戏服端未安装 Promotion.dll') +
        ' —— 请到「插件下发」页对该服务器启用 Promotion.dll 后重试'
    }
    return (data && data.error) || ('HTTP ' + status)
  }

  // ═══════════ 保存（改动即自动保存，500ms 防抖） ═══════════

  /** 只重启防抖计时器（**不计编辑版本号**；补尾保存用它，避免"补保存"被当成一次新编辑） */
  function armSaveTimer() {
    if (saveTimer) clearTimeout(saveTimer)
    saveTimer = setTimeout(save, 500)
  }

  /**
   * 本地编辑入口：记版本号 + 按 500ms 防抖触发保存（照旧版 PromotionConfigView.vue:40-61）。
   * 在飞期间的编辑**不在这里丢弃**：防抖计时器照旧重置，真正被叫到时由 save() 决定补尾保存。
   */
  function scheduleSave() {
    if (!ready) return
    editSeq += 1
    armSaveTimer()
  }

  /** 在飞期间攒下的编辑：本次保存结束后补一次尾保存（多次编辑已被防抖合并成一次，不会连发） */
  function runTailIfNeeded() {
    if (!tailPending) return
    tailPending = false
    armSaveTimer()
  }

  /**
   * 发一次保存请求。只有这里会把 state.saving 置位。
   *
   * D8 修复点：旧实现在开头直接 `if (state.saving) return`，把"防抖触发的保存"**整次丢掉**
   * （没有补尾保存）；紧接着的响应又用服务端配置覆盖 state.config，那一次编辑就永久丢失、
   * 界面上还会回退。现在的做法：
   *   1. 在飞时被叫到 → 只置 tailPending（不丢弃），本次结束后补一次尾保存；
   *   2. 只有在"本次请求飞行期间没有新编辑"（editSeq 没变）时才用响应覆盖 state.config／重渲染，
   *      否则保留本地编辑、把最新配置再补交一次（避免"改了又被回退"）。
   * 请求次数是有界的：无论并发多少编辑，每个保存周期最多再多补 1 次请求，不会形成保存风暴。
   */
  async function save() {
    if (saveTimer) { clearTimeout(saveTimer); saveTimer = null }
    if (state.saving) {
      // 在飞：不能丢这次编辑 —— 记下来，等本次结束后补一次尾保存
      tailPending = true
      return
    }
    state.saving = true
    const seqAtStart = editSeq
    setStatus('正在保存并下发...', 'pr-muted')
    const res = await tsw.api('/api/promotion/config', { json: buildSavePayload(state.config) })
    state.saving = false

    /** 本次请求飞行期间是否又发生了本地编辑 */
    const editedDuringSave = editSeq !== seqAtStart

    if (!res.ok) {
      setStatus('保存失败：' + errText(res.data, res.status), 'pr-error')
      runTailIfNeeded()
      return
    }
    if (editedDuringSave) {
      // 保存期间又有编辑：**不用响应覆盖 state.config、也不重渲染**（否则"改了又被回退"），
      // 改为把最新编辑再补交一次；多次编辑已被防抖合并，这里只会多补这一次请求
      setStatus('已保存；保存期间又有改动，将自动再保存一次', 'pr-muted')
      tailPending = false
      armSaveTimer()
      return
    }
    const d = res.data || {}
    state.config = normalizeLoadedConfig(d.config || state.config)
    state.warnings = Array.isArray(d.warnings) ? d.warnings : []
    renderQq()
    renderThresholds()

    const push = d.push || {}
    if (push.total === 0) {
      setStatus('已保存（' + (push.note || '没有启用中的服务器') + '）', 'pr-ok')
    } else if (push.ok) {
      setStatus('已保存，并已下发到全部 ' + Number(push.total) + ' 台服务器', 'pr-ok')
    } else {
      setStatus('已保存，但下发未完全成功：' + Number(push.pendingCount) +
        ' 台未生效（会自动重试，详见下方下发状态）', 'pr-error')
    }
    await loadStatus(true)
    runTailIfNeeded()
  }

  // ═══════════ 交互（事件委托；每次 render 后按钮都是新的，必须用委托） ═══════════

  function findIndex(el, attr) {
    const v = el.getAttribute(attr)
    const n = Number(v)
    return Number.isInteger(n) ? n : -1
  }

  function onChange(e) {
    const t = e.target
    if (!t || !root || !root.contains(t)) return
    const qq = t.getAttribute && t.getAttribute('data-prqq')
    const th = t.getAttribute && t.getAttribute('data-prth')
    const idx = t.getAttribute && t.hasAttribute('data-idx') ? findIndex(t, 'data-idx') : -1

    if (qq === 'enabled') {
      state.config.qqBind.enabled = t.checked === true
      scheduleSave()
      return
    }
    if (qq === 'targetGroup') {
      state.config.qqBind.targetGroup = String(t.value || '').trim()
      scheduleSave()
      return
    }
    if (qq === 'mode') {
      state.config.qqBind.mode = normalizeClientMode(t.value)
      scheduleSave()
      return
    }
    if (th && idx >= 0 && state.config.playtimeThresholds[idx]) {
      if (th === 'targetGroup') state.config.playtimeThresholds[idx].targetGroup = String(t.value || '').trim()
      else if (th === 'mode') state.config.playtimeThresholds[idx].mode = normalizeClientMode(t.value)
      scheduleSave()
    }
  }

  /**
   * 天/时/分输入：照旧版语义**用另外两个框的当前值一起换算**（fromDHM），
   * 且 fromDHM 自带 Math.max(1, ...) —— 三个框都空/为 0 时结果是 1 分钟。
   * 这里只更新这一行的汇总文案，不整块重渲染（否则输入时焦点会丢）。
   */
  function onInput(e) {
    const t = e.target
    if (!t || !root || !root.contains(t)) return
    const part = t.getAttribute && t.getAttribute('data-prth')
    if (!part || part === 'targetGroup' || part === 'mode') return
    const idx = findIndex(t, 'data-idx')
    const row = state.config.playtimeThresholds[idx]
    if (!row) return

    const read = (name) => {
      const el = root.querySelector('[data-prth="' + name + '"][data-idx="' + idx + '"]')
      return el ? el.value : ''
    }
    const values = { day: read('day'), hour: read('hour'), min: read('min') }
    values[part] = t.value
    row.minutes = fromDHM(values.day, values.hour, values.min)
    updateTotalLabel(idx)
    scheduleSave()
  }

  function onClick(e) {
    const t = e.target
    if (!t || !root || !root.contains(t)) return
    const btn = t.closest ? t.closest('[data-pract]') : null
    if (!btn) return
    const act = btn.getAttribute('data-pract')

    if (act === 'add-threshold') {
      state.config.playtimeThresholds.push({ ...DEFAULT_THRESHOLD })
      renderThresholds()
      scheduleSave()
      return
    }
    if (act === 'del-threshold') {
      state.config.playtimeThresholds = removeAt(state.config.playtimeThresholds, findIndex(btn, 'data-idx'))
      renderThresholds()
      scheduleSave()
      return
    }
    if (act === 'del-ignore') {
      state.config.ignoreGroups = removeAt(state.config.ignoreGroups, findIndex(btn, 'data-idx'))
      renderIgnore()
      scheduleSave()
      return
    }
    if (act === 'add-ignore') return commitIgnoreInput()
    if (act === 'reload') return reload()
    if (act === 'push-pending') return manualPush(true)
    if (act === 'push-all') return manualPush(false)
  }

  function commitIgnoreInput() {
    const input = root ? root.querySelector('[data-prignore="new"]') : null
    if (!input) return
    const r = addIgnoreGroup(state.config.ignoreGroups, input.value)
    input.value = ''
    if (!r.added) {
      // 重复或空：不添加（**忽略大小写去重**），也不静默——给一句提示
      setStatus('未添加：组名为空或已存在（忽略大小写去重）', 'pr-warn')
      return
    }
    state.config.ignoreGroups = r.list
    renderIgnore()
    scheduleSave()
  }

  function onKeydown(e) {
    const t = e.target
    if (!t || !t.getAttribute || t.getAttribute('data-prignore') !== 'new') return
    if (e.key === 'Enter') {
      e.preventDefault()
      commitIgnoreInput()
    }
  }

  async function manualPush(onlyPending) {
    setStatus(onlyPending ? '正在补推未确认的服务器...' : '正在全部重推...', 'pr-muted')
    const res = await tsw.api('/api/promotion/push', { json: { onlyPending: onlyPending === true } })
    if (!res.ok) {
      setStatus('重推失败：' + errText(res.data, res.status), 'pr-error')
      return
    }
    const push = (res.data && res.data.push) || {}
    if (push.total === 0) setStatus(push.note || '没有需要下发的服务器', 'pr-ok')
    else if (push.ok) setStatus('重推完成：全部 ' + push.total + ' 台确认生效', 'pr-ok')
    else setStatus('重推完成，仍有 ' + Number(push.pendingCount) + ' 台未生效', 'pr-error')
    await loadStatus(true)
  }

  async function reload() {
    setStatus('正在读取...', 'pr-muted')
    const okCfg = await loadConfig()
    const okGroups = await loadGroups()
    const okStatus = await loadStatus(true)
    renderAll()
    setStatus(
      okCfg && okStatus ? ('已读取最新配置与下发状态' + (okGroups ? '' : '（用户组列表取不到，已退化为文本输入）')) : '读取未完全成功，请重试',
      okCfg && okStatus ? 'pr-ok' : 'pr-error',
    )
  }

  tsw.registerView({
    id: 'promotion',
    title: '权限提升',
    section: '后端设置',
    path: '/b/promotion',
    icon: 'key',
    render: function (container) {
      root = container
      injectStyle()
      ready = false
      renderShell(container)

      /**
       * 事件委托：先按同一引用解绑再绑（不是"只绑一次"标记）。
       * 宿主的 route() 每次进入本路由都调 render(container)，而 container 是常驻节点；
       * 无条件下 addEventListener 会让监听器随访问次数累加（一次点击执行 N 次）。
       * 也不能只靠标记：插件热重载会用新的 cache-busting query 重新 import，
       * 新实例若因标记仍在而跳过绑定，点击会继续由旧 bundle 的闭包处理。
       */
      if (container.__prClick) container.removeEventListener('click', container.__prClick)
      if (container.__prChange) container.removeEventListener('change', container.__prChange)
      if (container.__prInput) container.removeEventListener('input', container.__prInput)
      if (container.__prKeydown) container.removeEventListener('keydown', container.__prKeydown)

      container.__prClick = (ev) => guard('点击', () => onClick(ev))
      container.__prChange = (ev) => guard('变更', () => onChange(ev))
      container.__prInput = (ev) => guard('输入', () => onInput(ev))
      container.__prKeydown = (ev) => guard('按键', () => onKeydown(ev))
      container.addEventListener('click', container.__prClick)
      container.addEventListener('change', container.__prChange)
      container.addEventListener('input', container.__prInput)
      container.addEventListener('keydown', container.__prKeydown)

      // 读顺序：先拿配置与组列表，再拿状态（状态里含软依赖与逐服下发结果）
      loadConfig()
        .then((ok) => {
          if (!ok) return null
          return loadGroups()
        })
        .then(() => loadStatus(true))
        .then(() => {
          renderAll()
          ready = true
        })
        .catch((err) => {
          setStatus('加载失败：' + ((err && err.message) || err), 'pr-error')
        })
    },
  })

  function guard(what, fn) {
    try {
      fn()
    } catch (err) {
      console.warn('[promotion] ' + what + '处理异常：' + ((err && err.message) || err))
    }
  }

  if (typeof console !== 'undefined') {
    console.log('[tsweb] promotion 客户端插件已注册: #/b/promotion')
  }
}
