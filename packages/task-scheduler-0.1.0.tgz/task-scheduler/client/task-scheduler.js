/**
 * 自动任务插件 —— 客户端半（任务界面）
 *
 * 布局与交互照着旧版 TsWeb/frontend/src/views/console/TasksView.vue（898 行）复刻：
 *   工具条（刷新 / 重新下发 / 新建任务）→ 下发状态条 → 提示条 → **任务卡片网格**
 *   （每张卡：名称 + 执行中标记 + 启用开关 → 触发/执行方式/命令数 标签 → 前提 →
 *    执行次数/上次执行/上次状态 三格统计 → 执行/编辑/记录/删除 四个按钮）
 *   → 新建/编辑弹窗（模板区 + 名称 + 触发模式 + 间隔/每日时间 + 执行方式 +
 *    执行前提（条件类型/取否/人数区间/BOSS 多选/玩家名单）+ 命令列表（拖拽排序）+ 取消/保存）
 *   → 执行记录弹窗 → 执行详情二级弹窗。
 *
 * 逐字保留的文案（旧版 TasksView.vue 的行号）：
 *   标题 自动任务 / 副标题 定时执行 TShock 命令，支持条件触发与执行记录追溯（:374-375）
 *   ＋ 新建任务（:387）  暂无任务，点击「＋ 新建任务」开始创建（:391）
 *   执行中...（:400）  启用/禁用（:402）  前提（:417）  执行次数/上次执行/上次状态（:425-435）
 *   执行 + 立即强制执行（跳过条件）（:441）  编辑/记录/删除（:442-444）
 *   从模板创建（:462）  任务名称 + 例如：凌晨自动重启（:479-480）
 *   触发模式/间隔（秒）/每日时间/执行方式（:487-504）  执行前提（:510）
 *   条件类型/取否（结果反转）（:513-517）  最少人数/最多人数（:528-533）
 *   已击败的 BOSS（可多选，全部满足）（:539）  需要同时在线的玩家（:553）
 *   输入玩家名...（:561）  添加（:562）
 *   命令列表 + 拖动排序 · 顺序模式支持 /wait <毫秒>（:569）  /broadcast 示例（:585）
 *   ＋ 添加命令（:588）  取消/保存/保存中...（:593-594）
 *   执行记录 — <任务名>（:603）  暂无执行记录（:610）  条件未通过（:619）
 *   执行详情（:630）  任务:/触发:/状态:（:635-637）
 *   成功/失败/跳过/执行中/未执行（statusLabel，:180-183）
 *
 * ★ 与旧版**有意的差异**（都属于本次任务要求修的缺陷，逐条列明）★
 *
 *  1) 【下发状态可见（D-静默失败）】新增"下发状态"条与「重新下发」按钮。
 *     旧版是"宿主配置 → 游戏服"的单向**静默**下发：保存成功界面只说"任务已保存"，
 *     任务有没有真的下发到游戏服、服端确认到哪个版本、上次为什么失败，界面上完全看不到。
 *     本件把宿主版本 / 服端已确认版本 / 待下发 / 上次失败原因 / 重试次数直接显示在工具条下方，
 *     且保存或删除后若下发失败会**同时**弹出明确的错误提示（不再只显示"已保存"）。
 *
 *  2) 【运行状态可用性标注（D-静默失败）】列表接口带回 runtimeAvailable / presentOnServer：
 *     服端读不到运行状态时卡片明确显示"不可用"，而不是把空白当成"还没执行过"
 *     ——旧版 lastRunAt 为空一律显示"—/未执行"，这两种含义完全不同。
 *     宿主有、服端还没有的任务显示"未下发"标记。
 *
 *  3) 【逐命令状态：成功/失败/不适用（D-失败检测）】执行详情里每条命令的状态按服端给的
 *     statusText 显示（成功/失败/不适用），旧版只有布尔 success，把"命令没注册""仅限游戏内执行"
 *     这类**根本没执行成功**的情况也显示成"成功"。缺 status 字段的历史记录回退到布尔判断。
 *
 *  4) 【执行记录分页】旧版记录弹窗固定第 1 页 20 条且无法翻页（TasksView.vue:341），
 *     记录一多就看不到更早的。本件加上一页/下一页与总数显示（默认仍 20 条/页）。
 *
 *  5) 【旧版数据采纳入口】宿主没有该服任务、而游戏服上已有任务（从旧版
 *     <TShock.SavePath>/TSWeb/Tasks/tasks.json 迁移而来）时，显示提示条与「采纳服端配置」按钮。
 *
 *  6) 【模板与表单默认值全部保留】三个模板（凌晨关服重启 / 自动清理地面物品 / 定时自动保存）
 *     的名称、说明、生成的字段值**逐字沿用**（TasksView.vue:53-103）；新建默认值也照旧
 *     （manual / 间隔 600 / 04:00 / sequential / min 0 / max 9999）。
 *     开关在 triggerMode === 'manual' 时隐藏（旧版 :402 的理由是"手动任务无自动触发"）。
 *
 * 宿主 API：window.tsweb.registerView / api / getServerId
 *   - Bearer 由宿主附加；**x-server-id 必须本文件自己加**（宿主的 api() 不加；
 *     缺了它后端会退化成"取服务器列表第一台"，等于把任务改到另一台服务器上）。
 * 样式：复用宿主 index.html 的类（button.primary/ghost/danger/sm、.badge、.toolbar、
 *       .muted、.error、.hidden），只为本视图补 tsk- 前缀的 CSS。
 *
 * 本文件是 **ESM 模块**（宿主用 import(url) 加载），同时把纯函数具名导出，
 * 供 test/client-ui.test.mjs 在 Node 里做无浏览器验证。因此：
 *   - 所有**HTML 生成**都是纯函数（输入普通对象，输出字符串），不需要 DOM 即可断言；
 *   - 只有 mountTasksView(container) 需要 DOM（事件绑定 + 读写输入框）。
 */

// ═══════════════════════════════════════════════════
//  常量（旧版 TasksView.vue:30-103 逐字照搬）
// ═══════════════════════════════════════════════════

export const CONDITION_TYPES = [
  { value: 'always', label: '无条件' },
  { value: 'online_count', label: '在线人数' },
  { value: 'boss_defeated', label: 'BOSS已击败' },
  { value: 'player_online', label: '指定玩家在线' },
]

export const TRIGGER_MODES = [
  { value: 'manual', label: '手动执行' },
  { value: 'interval', label: '间隔执行' },
  { value: 'daily', label: '每天定时' },
]

export const EXEC_MODES = [
  { value: 'sequential', label: '顺序执行' },
  { value: 'concurrent', label: '并发执行' },
]

/**
 * 18 个 BOSS 名称。顺序必须与游戏服半 TaskSchedulerEngine.BossNpcIds 的键顺序一致
 * （旧版 tasksApi.js 的 BOSS_NAMES 与 TaskScheduler.cs:139-159 也是这个顺序）。
 * test/client-ui.test.mjs 会把它与 DLL 源码里的键逐项比对。
 */
export const BOSS_NAMES = [
  '史莱姆王', '克苏鲁之眼', '世界吞噬者', '克苏鲁之脑', '蜂后', '巨鹿',
  '骷髅王', '血肉墙', '史莱姆皇后', '毁灭者', '机械骷髅王', '双子魔眼',
  '世纪之花', '石巨人', '猪龙鱼公爵', '光之女皇', '拜月教教徒', '月亮领主',
]

export function pad2(n) {
  return (n < 10 ? '0' : '') + n
}

/** 时间选择器选项（00-23 / 00-59；旧版 TasksView.vue:49-50） */
export const HOURS = Array.from({ length: 24 }, (_, i) => pad2(i))
export const MINUTES = Array.from({ length: 60 }, (_, i) => pad2(i))

/** 三个任务模板（旧版 TasksView.vue:53-103 逐字照搬） */
export const TASK_TEMPLATES = [
  {
    name: '凌晨关服重启',
    desc: '每天 03:00，玩家数为 0 时执行关服（重启需自行配置）',
    build: () => ({
      name: '凌晨关服重启',
      enabled: true,
      triggerMode: 'daily',
      dailyTime: '03:00',
      condition: { type: 'online_count', not: false, params: { min: 0, max: 0, bossNames: [], playerNames: [] } },
      execMode: 'sequential',
      commands: ['/bc 服务器即将关闭', '/off confirm'],
    }),
  },
  {
    name: '自动清理地面物品',
    desc: '每 2 小时广播提示，1 分钟后清理地面掉落物',
    build: () => ({
      name: '自动清理地面物品',
      enabled: true,
      triggerMode: 'interval',
      intervalSeconds: 7200,
      condition: { type: 'always', not: false, params: { min: 0, max: 9999, bossNames: [], playerNames: [] } },
      execMode: 'sequential',
      commands: ['/bc 1分钟后将清理地面物品', '/wait 60000', '/clear item 9999'],
    }),
  },
  {
    name: '定时自动保存',
    desc: '每 30 分钟自动保存世界',
    build: () => ({
      name: '定时自动保存',
      enabled: true,
      triggerMode: 'interval',
      intervalSeconds: 1800,
      condition: { type: 'always', not: false, params: { min: 0, max: 9999, bossNames: [], playerNames: [] } },
      execMode: 'sequential',
      commands: ['/bc 正在保存世界', '/save'],
    }),
  },
]

/** 新建任务的默认值（旧版 TasksView.vue:120-132 逐字照搬） */
export function emptyTask() {
  return {
    id: '',
    name: '',
    enabled: true,
    triggerMode: 'manual',
    intervalSeconds: 600,
    dailyTime: '04:00',
    condition: { type: 'always', not: false, params: { min: 0, max: 9999, bossNames: [], playerNames: [] } },
    execMode: 'sequential',
    commands: [],
  }
}

/** 表单补齐：服务端回来的任务可能缺字段，缺什么补什么，绝不让表单字段悬空 */
export function normalizeForm(t) {
  const base = emptyTask()
  const o = Object.assign(base, t || {})
  o.condition = o.condition || base.condition
  o.condition.params = o.condition.params || base.condition.params
  o.condition.params.bossNames = o.condition.params.bossNames || []
  o.condition.params.playerNames = o.condition.params.playerNames || []
  if (!Array.isArray(o.commands)) o.commands = []
  return o
}

// ═══════════════════════════════════════════════════
//  纯展示函数（旧版 TasksView.vue:152-188 逐行照搬）
// ═══════════════════════════════════════════════════

export function esc(s) {
  return String(s === undefined || s === null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;')
}

export function conditionSummary(cond) {
  if (!cond) return '—'
  let text = ''
  switch (cond.type) {
    case 'always': text = '无条件'; break
    case 'online_count': {
      const p = cond.params || {}
      const parts = []
      if (p.min !== undefined && p.min !== null && p.min !== 0) parts.push(`≥${p.min}人`)
      if (p.max !== undefined && p.max !== null && p.max !== 9999) parts.push(`≤${p.max}人`)
      text = parts.length ? parts.join(' 且 ') : '无条件'
      break
    }
    case 'boss_defeated': text = `击败 ${(cond.params?.bossNames || []).join('/') || '—'}`; break
    case 'player_online': text = `在线: ${(cond.params?.playerNames || []).join('/') || '—'}`; break
    default: text = cond.type
  }
  return cond.not ? `非(${text})` : text
}

export function triggerSummary(t) {
  switch (t.triggerMode) {
    case 'interval': return `每 ${t.intervalSeconds} 秒`
    case 'daily': return `每天 ${t.dailyTime}`
    default: return '手动'
  }
}

/** 任务状态文案。新增 interrupted：服端会把上次进程遗留的"执行中"记录标成它（修 D26） */
export function statusLabel(status) {
  const map = { success: '成功', failed: '失败', skipped: '跳过', running: '执行中', interrupted: '已中断' }
  return map[status] || status || '未执行'
}

export function statusClass(status) {
  const map = { success: 'ok', failed: 'bad', skipped: 'warn', running: 'run', interrupted: 'bad' }
  return map[status] || ''
}

/** 逐命令状态文案：优先服端 statusText（成功/失败/不适用），缺则回退旧版布尔判断 */
export function cmdStatusLabel(c) {
  if (c && c.statusText) return c.statusText
  if (c && c.status === 'not_applicable') return '不适用'
  return (c && c.success) ? '成功' : '失败'
}

export function cmdStatusClass(c) {
  if (c && c.status === 'not_applicable') return 'warn'
  return (c && c.success) ? 'ok' : 'bad'
}

/**
 * 配置警告统一成一行文字。
 * 兼容两种形态：taskWarnings() 给的是**字符串数组**，
 * configWarnings() 给的是**对象数组** `{ taskId, taskName, warning }`（见 config.js:277）。
 */
export function warningText(w) {
  if (typeof w === 'string') return w
  // null/undefined 要回空串：早先落到最后一行 String(w)，界面上会显示一个"null"
  if (w === null || w === undefined) return ''
  if (typeof w === 'object') {
    if (w.warning) return (w.taskName ? w.taskName + '：' : '') + w.warning
    return w.message || w.text || JSON.stringify(w)
  }
  return String(w)
}

/** 毫秒 → 秒文案（列表 1 位小数，旧版 :618；详情 2 位小数，旧版 :637） */
export function fmtDur(ms, digits) {
  const n = Number(ms || 0) / 1000
  return n.toFixed(digits === undefined ? 1 : digits) + 's'
}

/** 分页总页数（至少 1） */
export function pageCount(total, pageSize) {
  return Math.max(1, Math.ceil(Number(total || 0) / Number(pageSize || 20)))
}

// ═══════════════════════════════════════════════════
//  HTML 生成（纯函数：输入普通对象，输出字符串；无需 DOM 即可断言）
// ═══════════════════════════════════════════════════

function svg(inner, size) {
  const s = size || 16
  return '<svg xmlns="http://www.w3.org/2000/svg" width="' + s + '" height="' + s +
    '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
    'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + inner + '</svg>'
}

const ICON = {
  plus: '<path d="M12 5v14M5 12h14"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>',
  play: '<polygon points="6 4 20 12 6 20 6 4"/>',
  pencil: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
  list: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="3.5" cy="6" r="1.2"/><circle cx="3.5" cy="12" r="1.2"/><circle cx="3.5" cy="18" r="1.2"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
  up: '<path d="M12 19V5"/><path d="M5 12l7-7 7 7"/>',
  warn: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
}

/** 单张任务卡（旧版 TasksView.vue:394-447 的字段与按钮一一对应） */
export function renderTaskCard(t) {
  const disabled = t.triggerMode !== 'manual' && !t.enabled
  const runtimeBad = t.runtimeAvailable === false
  const notPushed = t.presentOnServer === false
  const runCount = (t.runCount === undefined || t.runCount === null) ? 0 : t.runCount
  return [
    '<div class="tsk-card' + (disabled ? ' disabled' : '') + '" data-id="' + esc(t.id) + '">',
    '<div class="tsk-card-head">',
    '<div class="tsk-card-title"><span class="tsk-name">' + esc(t.name) + '</span>',
    t.running ? '<span class="tsk-running">执行中...</span>' : '',
    notPushed ? '<span class="tsk-badge warn">未下发</span>' : '',
    runtimeBad ? '<span class="tsk-badge warn">运行状态不可用</span>' : '',
    '</div>',
    // 手动任务无自动触发，不显示开关（旧版 :402）
    t.triggerMode !== 'manual'
      ? '<label class="tsk-switch" title="启用/禁用" data-act="toggle"><input type="checkbox"'
        + (t.enabled ? ' checked' : '') + ' /><span class="tsk-slider"></span></label>'
      : '',
    '</div>',
    '<div class="tsk-triggers">',
    '<span class="tsk-tag">' + esc(triggerSummary(t)) + '</span>',
    '<span class="tsk-tag">' + (t.execMode === 'concurrent' ? '并发' : '顺序') + '</span>',
    '<span class="tsk-tag">' + esc(t.commandCount) + ' 条命令</span>',
    '</div>',
    '<div class="tsk-cond"><span class="tsk-cond-label">前提</span>',
    '<span class="tsk-cond-text">' + esc(conditionSummary(t.condition)) + '</span></div>',
    '<div class="tsk-stats">',
    '<div class="tsk-stat"><span class="tsk-stat-value">' + esc(runCount) + '</span>',
    '<span class="tsk-stat-label">执行次数</span></div>',
    '<div class="tsk-stat-divider"></div>',
    '<div class="tsk-stat"><span class="tsk-stat-value time">'
      + esc(runtimeBad ? '不可用' : (t.lastRunAt || '—')) + '</span>',
    '<span class="tsk-stat-label">上次执行</span></div>',
    '<div class="tsk-stat-divider"></div>',
    '<div class="tsk-stat"><span class="tsk-badge ' + statusClass(runtimeBad ? '' : t.lastRunStatus) + '">'
      + esc(runtimeBad ? '不可用' : statusLabel(t.lastRunStatus)) + '</span>',
    '<span class="tsk-stat-label">上次状态</span></div>',
    '</div>',
    '<div class="tsk-actions">',
    '<button class="primary sm" data-act="run" title="立即强制执行（跳过条件）">' + svg(ICON.play, 13) + '执行</button>',
    '<button class="ghost sm" data-act="edit">' + svg(ICON.pencil, 13) + '编辑</button>',
    '<button class="ghost sm" data-act="logs">' + svg(ICON.list, 13) + '记录</button>',
    '<button class="danger sm" data-act="del">' + svg(ICON.trash, 13) + '删除</button>',
    '</div>',
    '</div>',
  ].join('')
}

/** 卡片网格（含空态） */
export function renderGridHtml(tasks, loading) {
  if (loading) return '<div class="tsk-empty">加载中...</div>'
  if (!tasks || !tasks.length) return '<div class="tsk-empty">暂无任务，点击「＋ 新建任务」开始创建</div>'
  return tasks.map(renderTaskCard).join('')
}

/**
 * 下发状态条。
 * @param status  宿主 GET /api/task-scheduler/status 的返回体（可能为 null）
 * @param statusError 读不到状态时的原因（空 = 读到了）
 * @param serverId 当前服务器 id
 */
export function renderBarHtml(status, statusError, serverId) {
  const rows = (status && Array.isArray(status.servers)) ? status.servers : []
  let row = null
  for (const r of rows) if (String(r.serverId) === String(serverId)) { row = r; break }
  if (!row && rows.length === 1) row = rows[0]

  let cls = 'tsk-bar'
  const html = []
  if (statusError) {
    cls += ' err'
    html.push('<span>' + svg(ICON.warn, 13) + '</span>')
    html.push('<span class="grow">无法读取下发状态：' + esc(statusError) + '</span>')
  } else if (!row) {
    cls += ' off'
    html.push('<span class="grow muted">尚未为当前服务器配置任务（保存任务后会自动下发到游戏服）</span>')
  } else {
    const pending = row.pending === true
    if (pending || row.lastError) cls += ' off'
    html.push('<span class="grow">')
    html.push('<span class="tsk-kv">下发状态 <b>'
      // 字段名是 ackRevision（宿主 pushStatus 的行字段，见 index.js 的 pushStatus）。
      // 早先这里写成 row.ackedRevision（多了一个 ed），恒为 undefined，
      // 于是**下发成功之后状态条也永远显示"未下发"** —— 管理员会以为配置没生效。
      + (pending ? '待下发' : (row.ackRevision ? '已确认' : '未下发')) + '</b></span>')
    html.push(' <span class="muted">·</span> ')
    html.push('<span class="tsk-kv">宿主版本 <b>' + esc(row.revision) + '</b></span>')
    html.push(' <span class="muted">·</span> ')
    html.push('<span class="tsk-kv">服端已确认 <b>' + esc(row.ackRevision) + '</b></span>')
    html.push(' <span class="muted">·</span> ')
    html.push('<span class="tsk-kv">任务 <b>' + esc(row.taskCount) + '</b> 个</span>')
    if (row.orphan) html.push(' <span class="tsk-badge warn">服务器已删除，配置保留但不会下发</span>')
    if (pending && row.retryAttempts > 0) {
      html.push(' <span class="muted">·</span> <span class="tsk-kv">重试 <b>' + esc(row.retryAttempts) + '</b> 次</span>')
    }
    if (row.lastError) html.push(' <span class="tsk-badge bad">上次失败：' + esc(row.lastError) + '</span>')
    if (row.probe) {
      /**
       * probe 有两个不同的字段，**不能混为一谈**（这两个语义是本件在 index.js:probeServer 里定下的）：
       *   probe.ok      = "这次自证**读取**成功了吗"
       *   probe.inSync  = "宿主与服端**内容**一致吗"
       * 早先这里只判 `probe.ok === false`，于是"读到了但两边不一致"这种**最需要报出来**的情况
       * 反而不显示——对账功能等于只在读不到的时候才生效，属于静默失效。
       */
      if (row.probe.ok === false) {
        html.push(' <span class="tsk-badge bad">服端状态读取失败：' + esc(row.probe.reason || '') + '</span>')
      } else if (row.probe.inSync === false) {
        const diffs = []
        const only = Array.isArray(row.probe.onlyInHost) ? row.probe.onlyInHost.length : 0
        const extra = Array.isArray(row.probe.onlyInServer) ? row.probe.onlyInServer.length : 0
        const diff = Array.isArray(row.probe.differing) ? row.probe.differing.length : 0
        if (only) diffs.push('仅宿主有 ' + only + ' 个')
        if (extra) diffs.push('仅服端有 ' + extra + ' 个')
        if (diff) diffs.push('两端不一致 ' + diff + ' 个')
        html.push(' <span class="tsk-badge bad">服端对账不一致'
          + (diffs.length ? '：' + esc(diffs.join('、')) : '') + '</span>')
      }
    }
    html.push('</span>')
  }
  return '<div class="' + cls + '">' + html.join('') + '</div>'
}

/** 提示条：服端状态不可用 / 服端有未采纳任务 / 服端本地改动 / 配置警告 */
export function renderAlertsHtml(meta, warnings) {
  const out = []
  const m = meta || {}
  if (m.runtimeError) {
    out.push('<div class="tsk-alert error">读取游戏服任务运行状态失败，'
      + '卡片上的"执行次数/上次执行/上次状态"不可用（不等于"还没执行过"）：' + esc(m.runtimeError) + '</div>')
  }
  if (m.storeError) {
    out.push('<div class="tsk-alert error">宿主任务配置读取有问题：' + esc(m.storeError) + '</div>')
  }
  if (m.serverEditsPending > 0) {
    out.push('<div class="tsk-alert error">游戏服上有 ' + esc(m.serverEditsPending)
      + ' 次未经宿主下发的本地改动（有人直接调用了服端 /data/tasks/save 或 /delete）。'
      + '下一次下发会覆盖它们；若要保留请在覆盖前先在服端确认。</div>')
  }
  if (m.unadopted && m.unadopted.count > 0) {
    out.push('<div class="tsk-alert error">宿主里还没有本服的任务配置，而游戏服上已有 '
      + esc(m.unadopted.count) + ' 个任务（来源 ' + esc(m.unadopted.source || '未知')
      + (m.unadopted.legacyFile ? '，旧版文件 ' + esc(m.unadopted.legacyFile) : '') + '）'
      + '<ul class="tsk-alert-list">'
      + (m.unadopted.names || []).slice(0, 10).map((n) => '<li>' + esc(n) + '</li>').join('')
      + '</ul>'
      + '<div style="margin-top:8px"><button class="primary sm" id="tsk-adopt" type="button">采纳服端配置</button>'
      + '<span class="muted" style="margin-left:8px">采纳后这些任务即由宿主管理并可在此编辑</span></div></div>')
  }
  if (warnings && warnings.length) {
    out.push('<div class="tsk-alert error">配置提示：<ul class="tsk-alert-list">'
      + warnings.map((w) => '<li>' + esc(warningText(w)) + '</li>').join('')
      + '</ul></div>')
  }
  return out.join('')
}

/** 下拉框 */
export function renderSelect(id, options, value) {
  return '<select class="tsk-select" id="' + id + '">' + options.map((o) => {
    const v = typeof o === 'string' ? o : o.value
    const l = typeof o === 'string' ? o : o.label
    return '<option value="' + esc(v) + '"' + (String(v) === String(value) ? ' selected' : '') + '>'
      + esc(l) + '</option>'
  }).join('') + '</select>'
}

/**
 * 新建/编辑弹窗（旧版 TasksView.vue:452-597 的字段与按钮一一对应）。
 * @param s { form, editing, saving, warnings, newPlayerName, dragIndex }
 */
export function renderEditorHtml(s) {
  const f = s.form
  const p = f.condition.params
  const out = []
  out.push('<div class="tsk-overlay" data-close="1"><div class="tsk-modal">')
  out.push('<div class="tsk-modal-head"><h3>' + (s.editing ? '编辑任务' : '新建任务') + '</h3>'
    + '<button class="tsk-x" data-close="1" type="button">✕</button></div>')
  out.push('<div class="tsk-modal-body">')

  // 模板区仅新建时显示（旧版 :461）
  if (!s.editing) {
    out.push('<div class="tsk-section"><h4>从模板创建</h4><div class="tsk-tpl-grid">')
    TASK_TEMPLATES.forEach((tpl, i) => {
      out.push('<button class="tsk-tpl" data-tpl="' + i + '" type="button">'
        + '<span class="tsk-tpl-name">' + esc(tpl.name) + '</span>'
        + '<span class="tsk-tpl-desc">' + esc(tpl.desc) + '</span></button>')
    })
    out.push('</div></div>')
  }

  out.push('<div class="tsk-section">')
  out.push('<div class="tsk-row"><div class="tsk-field grow"><span>任务名称</span>'
    + '<input class="tsk-input" id="tsk-f-name" placeholder="例如：凌晨自动重启" value="' + esc(f.name) + '"></div></div>')

  out.push('<div class="tsk-row">')
  out.push('<div class="tsk-field"><span>触发模式</span>' + renderSelect('tsk-f-trigger', TRIGGER_MODES, f.triggerMode) + '</div>')
  if (f.triggerMode === 'interval') {
    out.push('<div class="tsk-field"><span>间隔（秒）</span>'
      + '<input class="tsk-input" id="tsk-f-interval" type="number" min="1" value="' + esc(f.intervalSeconds) + '"></div>')
  }
  if (f.triggerMode === 'daily') {
    const parts = String(f.dailyTime || '00:00').split(':')
    out.push('<div class="tsk-field"><span>每日时间</span><div class="tsk-time">'
      + renderSelect('tsk-f-hour', HOURS, parts[0])
      + '<span class="colon">:</span>'
      + renderSelect('tsk-f-minute', MINUTES, parts[1])
      + '</div></div>')
  }
  out.push('<div class="tsk-field"><span>执行方式</span>' + renderSelect('tsk-f-exec', EXEC_MODES, f.execMode) + '</div>')
  out.push('</div></div>')

  out.push('<div class="tsk-section"><h4>执行前提</h4>')
  out.push('<div class="tsk-row">')
  out.push('<div class="tsk-field"><span>条件类型</span>'
    + renderSelect('tsk-f-ctype', CONDITION_TYPES, f.condition.type) + '</div>')
  out.push('<div class="tsk-field"><span>取否（结果反转）</span>'
    + '<label class="tsk-switch"><input type="checkbox" id="tsk-f-cnot"' + (f.condition.not ? ' checked' : '')
    + ' /><span class="tsk-slider"></span></label></div>')
  out.push('</div>')

  if (f.condition.type === 'online_count') {
    out.push('<div class="tsk-row">')
    out.push('<div class="tsk-field"><span>最少人数</span>'
      + '<input class="tsk-input" id="tsk-f-min" type="number" min="0" value="' + esc(p.min) + '"></div>')
    out.push('<div class="tsk-field"><span>最多人数</span>'
      + '<input class="tsk-input" id="tsk-f-max" type="number" min="0" value="' + esc(p.max) + '"></div>')
    out.push('</div>')
  }
  if (f.condition.type === 'boss_defeated') {
    out.push('<div class="tsk-field" style="margin-bottom:12px"><span>已击败的 BOSS（可多选，全部满足）</span>'
      + '<div class="tsk-boss">' + BOSS_NAMES.map((n) => {
        const on = p.bossNames.indexOf(n) >= 0
        return '<button class="tsk-chip' + (on ? ' on' : '') + '" data-boss="' + esc(n) + '" type="button">'
          + esc(n) + '</button>'
      }).join('') + '</div></div>')
  }
  if (f.condition.type === 'player_online') {
    out.push('<div class="tsk-field"><span>需要同时在线的玩家</span>')
    out.push('<div class="tsk-players">' + p.playerNames.map((n, i) =>
      '<span class="tsk-ptag">' + esc(n) + '<button data-pdel="' + i + '" type="button">✕</button></span>').join('') + '</div>')
    out.push('<div class="tsk-addrow"><input class="tsk-input" id="tsk-f-newplayer" placeholder="输入玩家名..." value="'
      + esc(s.newPlayerName || '') + '"><button class="ghost sm" id="tsk-f-addplayer" type="button">添加</button></div>')
    out.push('</div>')
  }
  out.push('</div>')

  out.push('<div class="tsk-section"><h4>命令列表 <span class="hint">拖动排序 · 顺序模式支持 /wait &lt;毫秒&gt;</span></h4>')
  out.push('<div id="tsk-cmds">' + f.commands.map((c, i) =>
    '<div class="tsk-cmd' + (s.dragIndex === i ? ' dragging' : '') + '" data-cmd="' + i + '">'
    + '<span class="tsk-handle" title="按住拖动排序" draggable="true" data-handle="' + i + '">⠿</span>'
    + '<span class="tsk-idx">' + (i + 1) + '</span>'
    + '<input class="tsk-input" data-cmdinput="' + i + '" placeholder="/broadcast 示例" value="' + esc(c) + '">'
    + '<button class="danger sm" data-cmdel="' + i + '" title="删除" type="button">✕</button>'
    + '</div>').join('') + '</div>')
  out.push('<button class="ghost sm" id="tsk-f-addcmd" type="button">' + svg(ICON.plus, 13) + '添加命令</button>')
  out.push('</div>')

  if (s.warnings && s.warnings.length) {
    out.push('<div class="tsk-alert error" style="margin-top:14px">该任务存在配置问题：<ul class="tsk-alert-list">'
      + s.warnings.map((w) => '<li>' + esc(warningText(w)) + '</li>').join('') + '</ul></div>')
  }

  out.push('</div>')
  out.push('<div class="tsk-modal-foot">'
    + '<button class="ghost" data-close="1" type="button">取消</button>'
    + '<button class="primary" id="tsk-f-save" type="button">' + (s.saving ? '保存中...' : '保存') + '</button>'
    + '</div>')
  out.push('</div></div>')
  return out.join('')
}

/** 执行记录列表（旧版 TasksView.vue:599-624 + 本件新增分页） */
export function renderLogsHtml(s) {
  const out = []
  out.push('<div class="tsk-overlay" data-close="2"><div class="tsk-modal narrow">')
  out.push('<div class="tsk-modal-head"><h3>执行记录 — ' + esc(s.logTask ? s.logTask.name : '') + '</h3>'
    + '<button class="tsk-x" data-close="2" type="button">✕</button></div>')
  out.push('<div class="tsk-modal-body">')
  if (s.logsLoading) {
    out.push('<div class="tsk-empty">加载中...</div>')
  } else if (!s.logs || !s.logs.length) {
    out.push('<div class="tsk-empty">暂无执行记录</div>')
  } else {
    out.push(s.logs.map((l) =>
      '<div class="tsk-logitem" data-log="' + esc(l.id) + '">'
      + '<span class="tsk-logtime">' + esc(l.triggeredAt || '—') + '</span>'
      + '<span class="tsk-badge ' + statusClass(l.status) + '">' + esc(statusLabel(l.status)) + '</span>'
      + '<span style="flex:1"></span>'
      + '<span class="tsk-logdur">' + (l.durationMs ? fmtDur(l.durationMs, 1) : '—') + '</span>'
      + (l.skipped ? '<span class="tsk-logcond">条件未通过</span>' : '')
      + (l.errorSummary ? '<span class="tsk-logcond" title="' + esc(l.errorSummary) + '">有错误</span>' : '')
      + '</div>').join(''))
    const pages = pageCount(s.logTotal, s.logPageSize)
    out.push('<div class="tsk-pager">'
      + '<span>共 ' + Number(s.logTotal || 0) + ' 条 · 第 ' + Number(s.logPage || 1) + '/' + pages + ' 页</span>'
      + '<button class="ghost sm" id="tsk-lprev" type="button"' + (Number(s.logPage || 1) <= 1 ? ' disabled' : '') + '>上一页</button>'
      + '<button class="ghost sm" id="tsk-lnext" type="button"' + (Number(s.logPage || 1) >= pages ? ' disabled' : '') + '>下一页</button>'
      + '</div>')
  }
  out.push('</div></div></div>')
  return out.join('')
}

/** 执行详情二级弹窗（旧版 TasksView.vue:626-653；逐命令状态按服端三态显示） */
export function renderLogDetailHtml(d) {
  const out = []
  out.push('<div class="tsk-overlay lv2" data-close="3"><div class="tsk-modal">')
  out.push('<div class="tsk-modal-head"><h3>执行详情</h3>'
    + '<button class="tsk-x" data-close="3" type="button">✕</button></div>')
  out.push('<div class="tsk-modal-body">')
  out.push('<div class="tsk-detail-meta">')
  out.push('<span>任务: ' + esc(d.taskName) + '</span>')
  out.push('<span>触发: ' + esc(d.triggeredAt || '—') + ' (' + esc(d.triggerMode) + ')</span>')
  out.push('<span>状态: ' + esc(statusLabel(d.status)) + ' · ' + fmtDur(d.durationMs, 2) + '</span>')
  if (d.triggerMode === 'manual') {
    // 旧版把强制执行的 conditionResult 记成 true（其实没求值条件），这里如实说明，避免误读
    out.push('<span class="muted">本次为手动执行：未评估执行前提（无条件直接执行）</span>')
  } else if (d.skipped) {
    out.push('<span class="muted">本次因执行前提不满足被跳过，未执行任何命令</span>')
  } else if (d.conditionResult === false) {
    out.push('<span class="muted">本次执行前提判定为不通过</span>')
  }
  out.push('</div>')
  if (d.errorSummary) out.push('<div class="tsk-detail-err">' + esc(d.errorSummary) + '</div>')
  out.push('<div>' + (d.commands || []).map((c) =>
    '<div class="tsk-dcmd">'
    + '<div class="tsk-dcmd-head">'
    + '<span class="tsk-idx">' + (Number(c.index || 0) + 1) + '</span>'
    + '<code class="tsk-dcmd-code">' + esc(c.command) + '</code>'
    + '<span class="tsk-badge ' + cmdStatusClass(c) + '">' + esc(cmdStatusLabel(c)) + '</span>'
    + '</div>'
    + (c.output ? '<div class="tsk-dcmd-out">' + esc(c.output) + '</div>' : '')
    + (c.error ? '<div class="tsk-dcmd-err">' + esc(c.error) + '</div>' : '')
    + '</div>').join('') + '</div>')
  out.push('</div></div></div>')
  return out.join('')
}

/** 视图注册元信息（导出以便测试断言，不必真的注册） */
export const VIEW_META = {
  id: 'tasks',
  title: '自动任务',
  section: '服务器设置',
  path: '/s/tasks',
  icon: 'layers',
}

/** 本视图的 CSS（与 mountTasksView 分离，便于静态检查类名前缀/无 emoji） */
export const VIEW_CSS = [
  '.tsk-page{padding:0 4px}',
  '.tsk-toolbar{display:flex;align-items:center;gap:8px;margin-bottom:14px}',
  '.tsk-toolbar h2{margin:0;font-size:20px;font-weight:600}',
  '.tsk-toolbar .spacer{flex:1}',
  '.tsk-desc{margin:0 0 14px;font-size:12.5px;color:var(--muted-foreground)}',
  '.tsk-bar{display:flex;align-items:center;gap:10px;padding:9px 12px;margin-bottom:12px;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-sm);font-size:12.5px}',
  '.tsk-bar .grow{flex:1;min-width:120px}',
  '.tsk-bar.off{border-color:hsla(38,92%,50%,.45);background:hsla(38,92%,50%,.07)}',
  '.tsk-bar.err{border-color:hsla(0,72%,51%,.45);background:hsla(0,72%,51%,.07)}',
  '.tsk-kv{display:inline-flex;align-items:center;gap:5px}',
  '.tsk-kv b{font-weight:600;color:var(--foreground)}',
  '.tsk-alert{padding:10px 14px;border-radius:10px;margin-bottom:12px;font-size:12.5px;border:1px solid transparent}',
  '.tsk-alert.error{background:hsla(0,72%,51%,.1);color:var(--danger);border-color:hsla(0,72%,51%,.3)}',
  '.tsk-alert .tsk-alert-list{margin:6px 0 0;padding-left:18px}',
  '.tsk-alert .tsk-alert-list li{margin:2px 0}',
  '.tsk-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:18px;align-items:stretch}',
  '.tsk-card{display:flex;flex-direction:column;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-md);padding:15px 17px;transition:box-shadow .15s ease,border-color .15s ease}',
  '.tsk-card:hover{border-color:var(--ring);box-shadow:var(--shadow)}',
  '.tsk-card.disabled{opacity:.55}',
  '.tsk-card-head{display:flex;align-items:flex-start;gap:8px;margin-bottom:11px}',
  '.tsk-card-title{display:flex;align-items:center;gap:7px;flex:1;min-width:0;flex-wrap:wrap}',
  '.tsk-name{font-size:15px;font-weight:600;color:var(--text);word-break:break-all}',
  '.tsk-running{display:inline-flex;align-items:center;padding:1px 7px;font-size:11px;border-radius:99px;background:hsla(212,90%,55%,.14);color:hsl(212,90%,60%);white-space:nowrap}',
  '.tsk-switch{position:relative;display:inline-block;width:36px;height:19px;flex:0 0 auto}',
  '.tsk-switch input{opacity:0;width:0;height:0;position:absolute}',
  '.tsk-switch .tsk-slider{position:absolute;inset:0;background:var(--border);border-radius:99px;transition:background .15s;cursor:pointer}',
  '.tsk-switch .tsk-slider:before{content:"";position:absolute;width:13px;height:13px;left:3px;top:3px;background:#fff;border-radius:50%;transition:transform .15s}',
  '.tsk-switch input:checked+.tsk-slider{background:hsl(140,55%,45%)}',
  '.tsk-switch input:checked+.tsk-slider:before{transform:translateX(17px)}',
  '.tsk-triggers{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:10px}',
  '.tsk-tag{padding:1px 7px;font-size:11px;border-radius:var(--radius-sm);background:var(--accent-subtle);border:1px solid var(--border);color:var(--muted-foreground)}',
  '.tsk-cond{display:flex;gap:7px;align-items:baseline;margin-bottom:12px;font-size:12.5px}',
  '.tsk-cond-label{color:var(--muted-foreground);flex:0 0 auto;font-weight:600}',
  '.tsk-cond-text{color:var(--text);word-break:break-all}',
  '.tsk-stats{display:flex;align-items:stretch;gap:10px;padding:10px 0;border-top:1px solid var(--border);border-bottom:1px solid var(--border);margin-bottom:12px}',
  '.tsk-stat{display:flex;flex-direction:column;gap:3px;flex:1;min-width:0}',
  '.tsk-stat-value{font-size:14px;font-weight:600;color:var(--text);word-break:break-all}',
  '.tsk-stat-value.time{font-size:12px;font-weight:500}',
  '.tsk-stat-label{font-size:11px;color:var(--muted-foreground)}',
  '.tsk-stat-divider{width:1px;background:var(--border);flex:0 0 auto}',
  '.tsk-actions{display:flex;flex-wrap:wrap;gap:6px;margin-top:auto}',
  '.tsk-badge{display:inline-flex;align-items:center;gap:4px;padding:1px 7px;font-size:11px;border-radius:var(--radius-sm);border:1px solid var(--border);color:var(--muted-foreground);white-space:nowrap}',
  '.tsk-badge.ok{color:var(--ok);border-color:hsla(140,60%,45%,.4);background:hsla(140,60%,45%,.1)}',
  '.tsk-badge.bad{color:var(--danger);border-color:hsla(0,72%,51%,.4);background:hsla(0,72%,51%,.1)}',
  '.tsk-badge.warn{color:hsl(38,92%,55%);border-color:hsla(38,92%,50%,.4);background:hsla(38,92%,50%,.1)}',
  '.tsk-badge.run{color:hsl(212,90%,60%);border-color:hsla(212,90%,55%,.4);background:hsla(212,90%,55%,.12)}',
  '.tsk-empty{grid-column:1/-1;padding:46px 20px;text-align:center;color:var(--muted-foreground);font-size:13px}',
  '.tsk-overlay{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:200;display:flex;align-items:center;justify-content:center}',
  '.tsk-overlay.lv2{z-index:210}',
  '.tsk-modal{width:720px;max-width:95vw;max-height:88vh;display:flex;flex-direction:column;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-md);box-shadow:var(--shadow-lg);overflow:hidden}',
  '.tsk-modal.narrow{width:560px}',
  '.tsk-modal-head{display:flex;align-items:center;gap:10px;padding:14px 18px;border-bottom:1px solid var(--border)}',
  '.tsk-modal-head h3{margin:0;font-size:15px;flex:1;color:var(--text);word-break:break-all}',
  '.tsk-x{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;padding:0;background:transparent;border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--muted-foreground);font-size:13px;line-height:1;box-shadow:none}',
  '.tsk-x:hover{background:var(--accent-subtle);color:var(--foreground);transform:none}',
  '.tsk-modal-body{padding:16px 18px;overflow:auto;flex:1}',
  '.tsk-modal-foot{display:flex;gap:8px;justify-content:flex-end;padding:12px 18px;border-top:1px solid var(--border)}',
  '.tsk-section{border-top:1px solid var(--border);margin-top:16px;padding-top:14px}',
  '.tsk-section:first-child{border-top:none;margin-top:0;padding-top:0}',
  '.tsk-section h4{margin:0 0 11px;font-size:13px;color:var(--text);font-weight:600}',
  '.tsk-section h4 .hint{font-weight:400;font-size:11.5px;color:var(--muted-foreground);margin-left:6px}',
  '.tsk-tpl-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:9px}',
  '.tsk-tpl{display:flex;flex-direction:column;gap:4px;align-items:flex-start;padding:10px 12px;background:var(--background);border:1px solid var(--border);border-radius:var(--radius-sm);text-align:left;box-shadow:none;font-weight:400;height:auto}',
  '.tsk-tpl:hover{border-color:var(--ring);background:var(--accent-subtle);transform:none}',
  '.tsk-tpl-name{font-size:12.5px;font-weight:600;color:var(--text)}',
  '.tsk-tpl-desc{font-size:11.5px;color:var(--muted-foreground);line-height:1.5}',
  '.tsk-row{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:12px}',
  '.tsk-field{display:flex;flex-direction:column;gap:6px;font-size:12.5px;color:var(--muted-foreground);min-width:150px}',
  '.tsk-field.grow{flex:1}',
  '.tsk-field>span{font-weight:600;color:var(--foreground)}',
  '.tsk-time{display:flex;align-items:center;gap:6px}',
  '.tsk-time .colon{color:var(--muted-foreground)}',
  '.tsk-boss{display:flex;flex-wrap:wrap;gap:6px}',
  '.tsk-chip{padding:3px 9px;font-size:11.5px;background:var(--background);border:1px solid var(--border);border-radius:99px;color:var(--muted-foreground);box-shadow:none;font-weight:400;height:auto}',
  '.tsk-chip:hover{border-color:var(--ring);transform:none}',
  '.tsk-chip.on{background:var(--accent-subtle);border-color:var(--ring);color:var(--foreground);font-weight:600}',
  '.tsk-players{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:8px;min-height:4px}',
  '.tsk-ptag{display:inline-flex;align-items:center;gap:5px;padding:2px 4px 2px 8px;font-size:11.5px;background:var(--accent-subtle);border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text)}',
  '.tsk-ptag button{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;padding:0;background:transparent;border:none;border-radius:3px;color:var(--muted-foreground);font-size:12px;line-height:1;box-shadow:none}',
  '.tsk-ptag button:hover{background:var(--danger);color:#fff;transform:none}',
  '.tsk-addrow{display:flex;gap:8px;align-items:center}',
  '.tsk-cmd{display:flex;align-items:center;gap:8px;padding:5px 0}',
  '.tsk-cmd.dragging{opacity:.45}',
  '.tsk-handle{cursor:grab;color:var(--muted-foreground);font-size:14px;line-height:1;flex:0 0 auto;user-select:none}',
  '.tsk-idx{width:20px;text-align:right;font-size:11.5px;color:var(--muted-foreground);flex:0 0 auto}',
  '.tsk-input{height:30px;padding:4px 10px;font-size:13px;box-sizing:border-box;background:var(--background);border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text);width:100%}',
  '.tsk-input:focus{outline:none;border-color:var(--ring)}',
  '.tsk-cmd .tsk-input{flex:1;font-family:ui-monospace,Consolas,monospace}',
  '.tsk-select{height:30px;padding:4px 8px;font-size:13px;background:var(--background);border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text)}',
  '.tsk-logitem{display:flex;align-items:center;gap:10px;padding:9px 10px;border-bottom:1px solid var(--border);cursor:pointer;font-size:12.5px}',
  '.tsk-logitem:hover{background:var(--accent-subtle)}',
  '.tsk-logtime{flex:0 0 auto;color:var(--text);font-family:ui-monospace,Consolas,monospace;font-size:11.5px}',
  '.tsk-logdur{flex:0 0 auto;color:var(--muted-foreground);min-width:48px;text-align:right}',
  '.tsk-logcond{flex:0 0 auto;color:hsl(38,92%,55%);font-size:11.5px}',
  '.tsk-pager{display:flex;align-items:center;gap:10px;justify-content:flex-end;padding-top:12px;font-size:12px;color:var(--muted-foreground)}',
  '.tsk-detail-meta{display:flex;flex-direction:column;gap:4px;font-size:12.5px;color:var(--muted-foreground);margin-bottom:12px}',
  '.tsk-detail-err{padding:8px 11px;margin-bottom:12px;font-size:12px;background:hsla(0,72%,51%,.09);border:1px solid hsla(0,72%,51%,.3);border-radius:var(--radius-sm);color:var(--danger);white-space:pre-wrap;word-break:break-all}',
  '.tsk-dcmd{padding:9px 0;border-top:1px solid var(--border)}',
  '.tsk-dcmd:first-child{border-top:none}',
  '.tsk-dcmd-head{display:flex;align-items:center;gap:8px}',
  '.tsk-dcmd-code{flex:1;font-family:ui-monospace,Consolas,monospace;font-size:11.5px;color:var(--text);word-break:break-all}',
  '.tsk-dcmd-out{margin-top:6px;padding:7px 9px;background:var(--background);border:1px solid var(--border);border-radius:var(--radius-sm);font-family:ui-monospace,Consolas,monospace;font-size:11.5px;color:var(--muted-foreground);white-space:pre-wrap;word-break:break-all;max-height:180px;overflow:auto}',
  '.tsk-dcmd-err{margin-top:6px;font-size:11.5px;color:var(--danger);white-space:pre-wrap;word-break:break-all}',
  '#tsk-msg.ok{color:var(--ok)}',
]

// ═══════════════════════════════════════════════════
//  宿主交互 + DOM 挂载
// ═══════════════════════════════════════════════════

const tsw = typeof window !== 'undefined' ? window.tsweb : null

/** 带 x-server-id 的请求封装（宿主只加 Bearer，不加 x-server-id，见文件头说明） */
export function makeApi(tswRef) {
  return function api(path, opts) {
    const t = tswRef || (typeof window !== 'undefined' ? window.tsweb : null)
    if (!t || typeof t.api !== 'function') {
      return Promise.reject(new Error('宿主 API 不可用（window.tsweb.api）'))
    }
    const o = opts || {}
    const headers = o.headers || {}
    const sid = typeof t.getServerId === 'function' ? t.getServerId() : ''
    if (sid) headers['x-server-id'] = sid
    o.headers = headers
    return t.api(path, o)
  }
}

/** 把 { ok, status, data } 统一成"成功给 data，失败抛错" */
export function unwrap(res) {
  const data = res && res.data !== undefined ? res.data : null
  if (res && res.ok && data) return data
  const msg = (data && data.error) || (res && ('HTTP ' + res.status)) || '请求失败'
  const err = new Error(msg)
  err.status = res ? res.status : 0
  err.data = data
  throw err
}

/** 下发结果回显文案：保存/删除成功后**必须**让下发失败可见（旧版这里彻底静默） */
export function pushFeedback(res, action) {
  if (!res) return { ok: true, text: '' }
  if (res.pushOk === false) {
    return {
      ok: false,
      text: action + '，但下发到游戏服失败：' + (res.pushError || '原因未知') + '（可点「重新下发」重试）',
    }
  }
  return { ok: true, text: '' }
}

/**
 * 挂载视图。只有这一步需要 DOM；所有 HTML 生成都是上面的纯函数。
 * 事件用**事件委托**挂在 container 上，并且先按同一引用解绑再绑：
 * 宿主的 route() 每次进入本路由都调 render(container)，而 container 是常驻节点，
 * 无条件下 addEventListener 会让监听器随访问次数累加（一次点击执行 N 次）。
 * 也不能只靠标记：插件热重载会用新的 cache-busting query 重新 import，
 * 新实例若因标记仍在而跳过绑定，点击会继续由旧 bundle 的闭包处理。
 */
export function mountTasksView(container) {
  const api = makeApi()
  const call = (path, opts) => api(path, opts).then(unwrap)

  const state = {
    loading: true,
    tasks: [],
    meta: null,
    warnings: [],
    status: null,
    statusError: '',
    showEditor: false,
    editing: false,
    saving: false,
    form: emptyTask(),
    formWarnings: [],
    newPlayerName: '',
    dragIndex: -1,
    showLogs: false,
    logsLoading: false,
    logTask: null,
    logs: [],
    logPage: 1,
    logPageSize: 20,
    logTotal: 0,
    logDetail: null,
    flashTimer: null,
  }

  container.innerHTML = [
    '<style>', VIEW_CSS.join(''), '</style>',
    '<div class="tsk-page">',
    '<div class="tsk-toolbar">',
    '<h2>自动任务</h2>',
    '<span id="tsk-server" class="tsk-badge hidden"></span>',
    '<div class="spacer"></div>',
    '<button id="tsk-refresh" class="ghost sm" type="button">' + svg(ICON.refresh, 14) + '刷新</button>',
    '<button id="tsk-repush" class="ghost sm" type="button">' + svg(ICON.up, 14) + '重新下发</button>',
    '<button id="tsk-create" class="primary sm" type="button">' + svg(ICON.plus, 14) + '新建任务</button>',
    '</div>',
    '<p class="tsk-desc">定时执行 TShock 命令，支持条件触发与执行记录追溯</p>',
    '<div id="tsk-bar"></div>',
    '<div id="tsk-alerts"></div>',
    '<div id="tsk-grid" class="tsk-grid"></div>',
    '<p id="tsk-msg" class="muted hidden" style="margin:12px 0 0;font-size:12.5px"></p>',
    '<p id="tsk-error" class="error hidden" style="margin:12px 0 0"></p>',
    '</div>',
    '<div id="tsk-modal"></div>',
  ].join('')

  const els = {
    bar: container.querySelector('#tsk-bar'),
    alerts: container.querySelector('#tsk-alerts'),
    grid: container.querySelector('#tsk-grid'),
    modal: container.querySelector('#tsk-modal'),
    msg: container.querySelector('#tsk-msg'),
    error: container.querySelector('#tsk-error'),
    server: container.querySelector('#tsk-server'),
  }

  function flash(text) {
    els.msg.textContent = text
    els.msg.classList.remove('hidden')
    if (state.flashTimer) clearTimeout(state.flashTimer)
    state.flashTimer = setTimeout(() => els.msg.classList.add('hidden'), 2600)
  }

  function showError(text) {
    els.error.textContent = text || ''
    if (text) els.error.classList.remove('hidden')
    else els.error.classList.add('hidden')
  }

  function guard(fn) {
    return Promise.resolve().then(fn).catch((err) => {
      showError((err && err.message) || String(err))
    })
  }

  function patch() {
    els.bar.innerHTML = renderBarHtml(state.status, state.statusError, currentServerId())
    els.alerts.innerHTML = renderAlertsHtml(state.meta, state.warnings)
    els.grid.innerHTML = renderGridHtml(state.tasks, state.loading)
  }

  function patchModal() {
    let html = ''
    if (state.showLogs) {
      html += renderLogsHtml({
        logTask: state.logTask,
        logs: state.logs,
        logsLoading: state.logsLoading,
        logPage: state.logPage,
        logPageSize: state.logPageSize,
        logTotal: state.logTotal,
      })
    }
    if (state.showEditor) {
      html += renderEditorHtml({
        form: state.form,
        editing: state.editing,
        saving: state.saving,
        warnings: state.formWarnings,
        newPlayerName: state.newPlayerName,
        dragIndex: state.dragIndex,
      })
    }
    if (state.logDetail) html += renderLogDetailHtml(state.logDetail)
    els.modal.innerHTML = html
  }

  function currentServerId() {
    return (tsw && typeof tsw.getServerId === 'function' && tsw.getServerId()) || ''
  }

  function findTask(id) {
    return state.tasks.find((t) => String(t.id) === String(id)) || null
  }

  // ── 数据 ────────────────────────────────────────────────
  function loadAll() {
    state.loading = true
    showError('')
    patch()
    const sid = currentServerId()
    els.server.textContent = sid ? ('服务器 ' + sid) : ''
    if (sid) els.server.classList.remove('hidden')
    else els.server.classList.add('hidden')

    return Promise.all([
      call('/api/task-scheduler/tasks/list'),
      call('/api/task-scheduler/status').catch((err) => {
        state.statusError = err.message
        return null
      }),
    ]).then(([data, status]) => {
      const d = data || {}
      state.meta = d
      state.tasks = Array.isArray(d.tasks) ? d.tasks : []
      state.warnings = Array.isArray(d.warnings) ? d.warnings : []
      state.status = status
      if (status) state.statusError = ''
      state.loading = false
      patch()
    }).catch((err) => {
      state.loading = false
      patch()
      showError('加载失败: ' + ((err && err.message) || err))
    })
  }

  function save() {
    if (!String(state.form.name || '').trim()) {
      showError('请输入任务名称')
      return Promise.resolve()
    }
    state.saving = true
    showError('')
    patchModal()
    const payload = JSON.parse(JSON.stringify(state.form))
    if (payload.id === '') delete payload.id
    return call('/api/task-scheduler/tasks/save', { method: 'POST', json: { task: payload } })
      .then((res) => {
        state.saving = false
        state.showEditor = false
        patchModal()
        flash('任务已保存')
        return loadAll().then(() => {
          const fb = pushFeedback(res, '任务已保存到宿主')
          if (!fb.ok) showError(fb.text)
        })
      })
      .catch((err) => {
        state.saving = false
        patchModal()
        showError('保存失败: ' + ((err && err.message) || err))
      })
  }

  function fetchLogs() {
    if (!state.logTask) return Promise.resolve()
    state.logsLoading = true
    patchModal()
    return call('/api/task-scheduler/tasks/log?taskId=' + encodeURIComponent(state.logTask.id)
      + '&page=' + state.logPage + '&pageSize=' + state.logPageSize)
      .then((data) => {
        state.logs = Array.isArray(data.logs) ? data.logs : []
        state.logTotal = Number(data.total || 0)
        state.logPage = Number(data.page || state.logPage)
        state.logPageSize = Number(data.pageSize || state.logPageSize)
        state.logsLoading = false
        patchModal()
      })
      .catch((err) => {
        state.logs = []
        state.logsLoading = false
        patchModal()
        showError('加载记录失败: ' + ((err && err.message) || err))
      })
  }

  function openLogs(task) {
    state.logTask = task
    state.showLogs = true
    state.logDetail = null
    state.logPage = 1
    state.logs = []
    state.logTotal = 0
    return fetchLogs()
  }

  function openEdit(task) {
    return call('/api/task-scheduler/tasks/get?id=' + encodeURIComponent(task.id)).then((data) => {
      state.form = normalizeForm(JSON.parse(JSON.stringify(data.task)))
      state.editing = true
      state.formWarnings = Array.isArray(data.warnings) ? data.warnings : []
      state.newPlayerName = ''
      state.dragIndex = -1
      state.showEditor = true
      patchModal()
    }).catch((err) => showError('加载任务失败: ' + ((err && err.message) || err)))
  }

  function openCreate() {
    state.form = emptyTask()
    state.editing = false
    state.formWarnings = []
    state.newPlayerName = ''
    state.dragIndex = -1
    state.showEditor = true
    patchModal()
  }

  function closeEditor() {
    state.showEditor = false
    patchModal()
  }

  function toggleEnabled(task) {
    showError('')
    const want = !task.enabled
    return call('/api/task-scheduler/tasks/get?id=' + encodeURIComponent(task.id))
      .then((data) => {
        const full = JSON.parse(JSON.stringify(data.task))
        full.enabled = want
        return call('/api/task-scheduler/tasks/save', { method: 'POST', json: { task: full } })
      })
      .then((res) => {
        task.enabled = want
        patch()
        const fb = pushFeedback(res, '开关已保存到宿主')
        if (!fb.ok) showError(fb.text)
      })
      .catch((err) => {
        patch()
        showError('切换失败: ' + ((err && err.message) || err))
      })
  }

  function execTask(task, force) {
    showError('')
    return call('/api/task-scheduler/tasks/run', { method: 'POST', json: { id: task.id, force: force ? 1 : 0 } })
      .then(() => {
        flash('任务「' + task.name + '」已开始执行')
        // 旧版 TasksView.vue:282 在 1.5 秒后刷新，等服端把 running 写进状态
        return new Promise((r) => setTimeout(r, 1500))
      })
      .then(() => loadAll())
      .catch((err) => showError('执行失败: ' + ((err && err.message) || err)))
  }

  function removeTask(task) {
    const ok = (typeof window !== 'undefined' && typeof window.confirm === 'function')
      ? window.confirm('确定删除任务「' + task.name + '」？') : true
    if (!ok) return Promise.resolve()
    showError('')
    return call('/api/task-scheduler/tasks/delete', { method: 'POST', json: { id: task.id } })
      .then((res) => {
        const fb = pushFeedback(res, '任务已从宿主删除')
        if (!fb.ok) showError(fb.text)
        else flash('任务已删除')
        return loadAll()
      })
      .catch((err) => showError('删除失败: ' + ((err && err.message) || err)))
  }

  function repush() {
    const sid = currentServerId()
    return call('/api/task-scheduler/push', { method: 'POST', json: sid ? { serverId: sid } : {} })
      .then((data) => {
        const push = (data && data.push) || {}
        if (push.ok) flash('已重新下发到游戏服')
        else {
          const reason = (push.results && push.results.length) ? (push.results[0].reason || '') : ''
          showError('重新下发失败：' + (reason || '原因未知'))
        }
        return loadAll()
      })
  }

  function adopt() {
    return call('/api/task-scheduler/adopt', { method: 'POST', json: {} }).then((data) => {
      flash(data.message || '已采纳服端配置')
      return loadAll()
    })
  }

  // ── 事件委托 ─────────────────────────────────────────────
  function onClick(ev) {
    const target = ev.target
    const closeEl = target.closest ? target.closest('[data-close]') : null
    if (closeEl) {
      const lvl = closeEl.getAttribute('data-close')
      // overlay 只在点自己时关闭（等价旧版的 @click.self）
      if (closeEl.classList.contains('tsk-overlay') && target !== closeEl) return
      if (lvl === '1') closeEditor()
      else if (lvl === '2') { state.showLogs = false; state.logDetail = null; patchModal() }
      else if (lvl === '3') { state.logDetail = null; patchModal() }
      return
    }

    const id = target.id
    if (id === 'tsk-create') { openCreate(); return }
    if (id === 'tsk-refresh') { guard(() => loadAll().then(() => flash('已刷新'))); return }
    if (id === 'tsk-repush') { guard(repush); return }
    if (id === 'tsk-adopt') { guard(adopt); return }
    if (id === 'tsk-f-save') { guard(save); return }
    if (id === 'tsk-f-addplayer') {
      const name = String(state.newPlayerName || '').trim()
      if (!name) return
      if (state.form.condition.params.playerNames.indexOf(name) < 0) {
        state.form.condition.params.playerNames.push(name)
      }
      state.newPlayerName = ''
      patchModal()
      return
    }
    if (id === 'tsk-f-addcmd') { state.form.commands.push(''); patchModal(); return }
    if (id === 'tsk-lprev') {
      if (state.logPage <= 1) return
      state.logPage--
      guard(fetchLogs)
      return
    }
    if (id === 'tsk-lnext') { state.logPage++; guard(fetchLogs); return }

    const tpl = target.closest ? target.closest('[data-tpl]') : null
    if (tpl) {
      const t = TASK_TEMPLATES[Number(tpl.getAttribute('data-tpl'))]
      if (t) {
        state.form = normalizeForm(t.build())
        state.editing = false
        patchModal()
      }
      return
    }

    const boss = target.closest ? target.closest('[data-boss]') : null
    if (boss) {
      const n = boss.getAttribute('data-boss')
      const arr = state.form.condition.params.bossNames
      const i = arr.indexOf(n)
      if (i >= 0) arr.splice(i, 1)
      else arr.push(n)
      patchModal()
      return
    }

    const pdel = target.closest ? target.closest('[data-pdel]') : null
    if (pdel) {
      state.form.condition.params.playerNames.splice(Number(pdel.getAttribute('data-pdel')), 1)
      patchModal()
      return
    }

    const cmdel = target.closest ? target.closest('[data-cmdel]') : null
    if (cmdel) {
      state.form.commands.splice(Number(cmdel.getAttribute('data-cmdel')), 1)
      patchModal()
      return
    }

    const logRow = target.closest ? target.closest('[data-log]') : null
    if (logRow) {
      const logId = logRow.getAttribute('data-log')
      guard(() => call('/api/task-scheduler/tasks/log/detail?id=' + encodeURIComponent(logId))
        .then((data) => { state.logDetail = data.log; patchModal() })
        .catch((err) => showError('加载记录失败: ' + ((err && err.message) || err))))
      return
    }

    const card = target.closest ? target.closest('.tsk-card') : null
    if (card) {
      const actEl = target.closest('[data-act]')
      const act = actEl ? actEl.getAttribute('data-act') : ''
      const task = findTask(card.getAttribute('data-id'))
      if (!task) return
      if (act === 'toggle') return // 开关走 change 事件
      if (act === 'run') guard(() => execTask(task, true))
      else if (act === 'edit') guard(() => openEdit(task))
      else if (act === 'logs') guard(() => openLogs(task))
      else if (act === 'del') guard(() => removeTask(task))
    }
  }

  function onChange(ev) {
    const t = ev.target
    if (t.id === 'tsk-f-trigger') { state.form.triggerMode = t.value; patchModal(); return }
    if (t.id === 'tsk-f-exec') { state.form.execMode = t.value; return }
    if (t.id === 'tsk-f-ctype') { state.form.condition.type = t.value; patchModal(); return }
    if (t.id === 'tsk-f-cnot') { state.form.condition.not = t.checked; return }
    if (t.id === 'tsk-f-hour' || t.id === 'tsk-f-minute') {
      const h = container.querySelector('#tsk-f-hour')
      const m = container.querySelector('#tsk-f-minute')
      state.form.dailyTime = (h ? h.value : '00') + ':' + (m ? m.value : '00')
      return
    }
    if (t.getAttribute && t.getAttribute('data-act') === 'toggle') {
      const card = t.closest ? t.closest('.tsk-card') : null
      const task = card ? findTask(card.getAttribute('data-id')) : null
      if (task) guard(() => toggleEnabled(task))
      return
    }
  }

  function onInput(ev) {
    const t = ev.target
    // 文本输入只更新状态、**不重渲染**（否则光标会跳出输入框）
    if (t.id === 'tsk-f-name') { state.form.name = t.value; return }
    if (t.id === 'tsk-f-interval') { state.form.intervalSeconds = Number(t.value) || 0; return }
    if (t.id === 'tsk-f-min') { state.form.condition.params.min = Number(t.value) || 0; return }
    if (t.id === 'tsk-f-max') { state.form.condition.params.max = Number(t.value) || 0; return }
    if (t.id === 'tsk-f-newplayer') { state.newPlayerName = t.value; return }
    const ci = t.getAttribute ? t.getAttribute('data-cmdinput') : null
    if (ci !== null) { state.form.commands[Number(ci)] = t.value }
  }

  function onDragStart(ev) {
    const h = ev.target.closest ? ev.target.closest('[data-handle]') : null
    if (!h) return
    state.dragIndex = Number(h.getAttribute('data-handle'))
    if (ev.dataTransfer) {
      ev.dataTransfer.effectAllowed = 'move'
      try { ev.dataTransfer.setData('text/plain', String(state.dragIndex)) } catch { /* 某些环境受限 */ }
    }
  }

  function onDragOver(ev) {
    const row = ev.target.closest ? ev.target.closest('[data-cmd]') : null
    if (!row) return
    ev.preventDefault()
    const to = Number(row.getAttribute('data-cmd'))
    const from = state.dragIndex
    if (from === -1 || from === to) return
    const item = state.form.commands.splice(from, 1)[0]
    state.form.commands.splice(to, 0, item)
    state.dragIndex = to
    patchModal()
  }

  function onDragEnd() {
    state.dragIndex = -1
  }

  function onKeydown(ev) {
    if (ev.key === 'Escape') {
      if (state.logDetail) { state.logDetail = null; patchModal() }
      else if (state.showLogs) { state.showLogs = false; patchModal() }
      else if (state.showEditor) closeEditor()
      return
    }
    // 玩家名输入框回车即添加（旧版 :561 的 @keyup.enter）
    if (ev.key === 'Enter' && ev.target && ev.target.id === 'tsk-f-newplayer') {
      ev.preventDefault()
      const name = String(state.newPlayerName || '').trim()
      if (!name) return
      if (state.form.condition.params.playerNames.indexOf(name) < 0) {
        state.form.condition.params.playerNames.push(name)
      }
      state.newPlayerName = ''
      patchModal()
    }
  }

  // 先按同一引用解绑再绑（见函数头说明）
  if (container.__tskClick) container.removeEventListener('click', container.__tskClick)
  if (container.__tskChange) container.removeEventListener('change', container.__tskChange)
  if (container.__tskInput) container.removeEventListener('input', container.__tskInput)
  if (container.__tskKeydown) container.removeEventListener('keydown', container.__tskKeydown)
  if (container.__tskDragStart) container.removeEventListener('dragstart', container.__tskDragStart)
  if (container.__tskDragOver) container.removeEventListener('dragover', container.__tskDragOver)
  if (container.__tskDragEnd) container.removeEventListener('dragend', container.__tskDragEnd)

  container.__tskClick = (ev) => { try { onClick(ev) } catch (e) { console.warn('[task-scheduler] 点击处理异常：' + (e && e.message)) } }
  container.__tskChange = (ev) => { try { onChange(ev) } catch (e) { console.warn('[task-scheduler] 变更处理异常：' + (e && e.message)) } }
  container.__tskInput = (ev) => { try { onInput(ev) } catch (e) { console.warn('[task-scheduler] 输入处理异常：' + (e && e.message)) } }
  container.__tskKeydown = (ev) => { try { onKeydown(ev) } catch (e) { console.warn('[task-scheduler] 按键处理异常：' + (e && e.message)) } }
  container.__tskDragStart = (ev) => { try { onDragStart(ev) } catch (e) { console.warn('[task-scheduler] 拖拽处理异常：' + (e && e.message)) } }
  container.__tskDragOver = (ev) => { try { onDragOver(ev) } catch (e) { console.warn('[task-scheduler] 拖拽处理异常：' + (e && e.message)) } }
  container.__tskDragEnd = () => { state.dragIndex = -1 }

  container.addEventListener('click', container.__tskClick)
  container.addEventListener('change', container.__tskChange)
  container.addEventListener('input', container.__tskInput)
  container.addEventListener('keydown', container.__tskKeydown)
  container.addEventListener('dragstart', container.__tskDragStart)
  container.addEventListener('dragover', container.__tskDragOver)
  container.addEventListener('dragend', container.__tskDragEnd)

  const first = loadAll()

  return function cleanup() {
    if (state.flashTimer) clearTimeout(state.flashTimer)
    if (container.__tskClick) container.removeEventListener('click', container.__tskClick)
    if (container.__tskChange) container.removeEventListener('change', container.__tskChange)
    if (container.__tskInput) container.removeEventListener('input', container.__tskInput)
    if (container.__tskKeydown) container.removeEventListener('keydown', container.__tskKeydown)
    if (container.__tskDragStart) container.removeEventListener('dragstart', container.__tskDragStart)
    if (container.__tskDragOver) container.removeEventListener('dragover', container.__tskDragOver)
    if (container.__tskDragEnd) container.removeEventListener('dragend', container.__tskDragEnd)
    first.catch(() => { /* 首次加载失败已在界面上显示 */ })
  }
}

// ═══════════════════════════════════════════════════
//  注册（宿主按 import(url) 加载本模块，顶层立刻注册）
// ═══════════════════════════════════════════════════

if (tsw && typeof tsw.registerView === 'function') {
  tsw.registerView(Object.assign({}, VIEW_META, { render: mountTasksView }))
  if (typeof console !== 'undefined') {
    console.log('[tsweb] task-scheduler 客户端插件已注册: #/s/tasks')
  }
}
