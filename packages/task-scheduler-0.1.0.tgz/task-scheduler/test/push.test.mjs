/**
 * 下发链路测试（真实 apply + 假宿主 ctx + 假游戏服半）
 *
 * 覆盖任务要求的下发链路四件事，以及"静默失败"缺陷的修法：
 *   1. 配置变更 → **立即下发**（POST /api/task-scheduler/tasks/save 在同一请求里完成，不等对账周期）
 *   2. 下发失败 → 逐服**如实回显**（含"没装 DLL"的 501 语义），并按退避**自动重试**
 *   3. 连接恢复 / 服务器列表加载 → **补推**（只打还没确认最新配置的服）
 *   4. 服端实际生效状态的**探测**（probe）：与宿主配置逐字段比对，不一致必须报出来
 *
 * 另外锁住这些"不许悄悄退化"的行为：
 *   - **空列表双端守卫**：宿主配置读取失败且任务为空时拒绝下发；宿主明确删光时带 allowEmpty=1
 *   - 服端拒绝更旧的载荷（stale=true）→ 宿主**不**记成功，且重试会带**新**版本号
 *   - 服端"已应用但落盘失败"→ 必须报出来（内存生效、重启会丢）
 *   - 服务器未启用 → 不下发（不算失败，启用后由对账补推）
 *   - 已删除服务器的孤儿配置必须显示出来
 *   - dispose 停掉对账与重试定时器（卸载后不再有后台请求）
 *
 * 注意：本测试**不启动任何服务进程**，也不引入 express/cordis（见 test/support/fake-host.mjs 的说明）。
 * 运行：node test/push.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, writeFile, mkdir, readFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { apply } from '../index.js'
import { ACTIONS } from '../audit.js'
import { makeFakeHost, makeGameHalf, waitFor, makeTask } from './support/fake-host.mjs'

const SERVERS = [
  { raw: { id: 's1', name: '一服', host: '127.0.0.1', port: 7777, token: 't1', enabled: true } },
  { raw: { id: 's2', name: '二服', host: '127.0.0.1', port: 7778, token: 't2', enabled: true } },
]

/** 毫秒级的重试/对账节奏，避免测试等几十秒 */
const FAST = { retryBaseMs: 5, retryMaxMs: 40, reconcileMs: 100000 }

let dir
let seq = 0

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), 'tasks-push-'))
})

after(async () => {
  await rm(dir, { recursive: true, force: true })
})

async function boot({ servers = SERVERS, push = FAST } = {}) {
  seq += 1
  const dataDir = path.join(dir, `case-${seq}`)
  const gameHalf = makeGameHalf({ serverIds: servers.map((s) => s.raw.id) })
  const host = makeFakeHost({ dataDir, servers, fetchFor: gameHalf.fetchFor })
  const dispose = await apply(host.ctx, { push })
  return { dataDir, host, gameHalf, dispose }
}

/** 插件数据目录：ctx.paths.dataOf('task-scheduler') = <dataDir>/task-scheduler */
function pluginDataDir(dataDir) {
  return path.join(dataDir, 'task-scheduler')
}
function pluginConfigFile(dataDir) {
  return path.join(pluginDataDir(dataDir), 'tasks.json')
}

function snapshotCalls(host) {
  return host.calls.filter((c) => c.pathname === '/data/tasks/snapshot')
}

async function saveTaskVia(host, task, serverId = 's1') {
  const res = await host.call('post', '/api/task-scheduler/tasks/save', {
    headers: { 'x-server-id': serverId },
    body: { task },
  })
  return res
}

/**
 * 按**界面真实流程**新建任务：不带 id（旧版 TasksView.vue:120-132 的 emptyTask 里 id 是空串，
 * saveTask 会把空 id 删掉再提交），由服务端生成 id。
 * 返回 { res, id }。
 *
 * 为什么不直接给一个固定 id 提交：宿主侧 `saveTask` 对"给了 id 但该 id 不存在"是**硬失败 404 任务不存在**
 * （见 index.js:saveTask 的 isUpdate 分支），这是本件相对旧版**有意收紧**的一点——
 * 旧版 /data/tasks/save 收到未知 id 会直接新建（TaskScheduler.cs:693-696），
 * 那等于允许调用方用任意 id 悄悄插入任务。收紧的理由与"越权"缺陷同源：配置写入必须可预期。
 * 下面另有专门用例钉住这个 404 语义。
 */
async function createTaskVia(host, patch = {}, serverId = 's1') {
  const task = patch
  delete task.id
  const res = await saveTaskVia(host, task, serverId)
  // 直接回传响应本体，并把服务端生成的 id 挂在 `newId` 上（调用方仍按 res.status/res.data 读）
  res.newId = (res.data && res.data.id) || ''
  return res
}

// ═══════════════ 1. 挂载与启动 ═══════════════

test('apply：注册全部端点（旧版 7 条契约 + 别名 + 新增协议）+ 订阅连接恢复事件', async () => {
  const { host, dispose } = await boot()
  try {
    for (const p of [
      '/api/task-scheduler/tasks/list', '/api/task-scheduler/tasks/get',
      '/api/task-scheduler/tasks/save', '/api/task-scheduler/tasks/delete',
      '/api/task-scheduler/tasks/run',
      '/api/task-scheduler/tasks/log', '/api/task-scheduler/tasks/logs',
      '/api/task-scheduler/tasks/log/detail', '/api/task-scheduler/tasks/logs/detail',
      '/api/task-scheduler/status', '/api/task-scheduler/push',
      '/api/task-scheduler/adopt', '/api/task-scheduler/audit',
    ]) {
      assert.ok(host.hasRoute('get', p) || host.hasRoute('post', p), `应注册端点 ${p}`)
    }
    // 旧契约里 save/delete/run 是 GET 注册（宿主侧用 POST，两条都要在）
    assert.ok(host.hasRoute('post', '/api/task-scheduler/tasks/save'))
    assert.ok(host.hasRoute('post', '/api/task-scheduler/tasks/delete'))
    assert.ok(host.hasRoute('post', '/api/task-scheduler/tasks/run'))
    assert.equal(host.listenerCount(), 2, '应订阅 push/connected 与 servers/loaded 两个事件')
  } finally {
    dispose()
  }
})

test('启动时不推任何东西（宿主还没有任何服务器配置）', async () => {
  const { host, dispose } = await boot()
  try {
    assert.equal(snapshotCalls(host).length, 0)
  } finally {
    dispose()
  }
})

test('已有配置时启动即补推（等价于"连接恢复补推"的首次触发）', async () => {
  const { dataDir, host, gameHalf, dispose } = await boot()
  dispose()
  // 直接写一份宿主持久化配置，再重新挂载
  await mkdir(pluginDataDir(dataDir), { recursive: true })
  await writeFile(pluginConfigFile(dataDir), JSON.stringify({
    version: 1,
    updatedAt: '',
    servers: { s1: { revision: 3, updatedAt: '', tasks: [makeTask({ id: 'a1', name: '启动补推' })] } },
  }), 'utf8')

  const host2 = makeFakeHost({ dataDir, servers: SERVERS, fetchFor: gameHalf.fetchFor })
  const dispose2 = await apply(host2.ctx, { push: FAST })
  try {
    await waitFor(() => snapshotCalls(host2).length >= 1, { label: '启动补推打到 s1' })
    const call = snapshotCalls(host2)[0]
    assert.equal(call.serverId, 's1')
    assert.equal(call.params.version, '1', '版本号应从 1 开始单调递增')
    const tasks = JSON.parse(call.params.tasks)
    assert.equal(tasks.length, 1)
    assert.equal(tasks[0].name, '启动补推')
  } finally {
    dispose2()
  }
})

// ═══════════════ 2. 配置变更 → 立即下发 ═══════════════

test('保存任务：落盘 + **同一请求内**立即下发 + 返回下发结果', async () => {
  const { dataDir, host, gameHalf, dispose } = await boot()
  try {
    const res = await createTaskVia(host, makeTask({ name: '立即下发', triggerMode: 'interval', intervalSeconds: 60 }))
    assert.equal(res.status, 200)
    assert.equal(res.data.ok, true)
    assert.equal(res.data.message, '任务已保存')
    assert.ok(res.data.id, '必须回 id')
    assert.equal(res.data.created, true)
    assert.equal(res.data.pushOk, true, '保存响应里必须带下发结果')
    assert.equal(res.data.pushError, '')
    assert.equal(res.data.push.ok, true)

    // 下发确实打到了服端，且载荷是"整份配置"
    const calls = snapshotCalls(host)
    assert.equal(calls.length, 1)
    const tasks = JSON.parse(calls[0].params.tasks)
    assert.equal(tasks.length, 1)
    assert.equal(tasks[0].name, '立即下发')
    assert.equal(calls[0].params.allowEmpty, '0', '非空列表带 allowEmpty=0')

    // 落盘（重挂载后还在）
    const raw = JSON.parse(await readFile(pluginConfigFile(dataDir), 'utf8'))
    assert.equal(raw.servers.s1.tasks.length, 1)
    assert.equal(raw.servers.s1.revision, 1)
  } finally {
    dispose()
  }
})

test('保存后宿主 store 的 revision 递增（用于"服端是否已确认最新"的判定）', async () => {
  const { host, dispose } = await boot()
  try {
    const first = await createTaskVia(host, makeTask({ name: '一' }))
    assert.ok(first.newId, '新建应回 id')
    await saveTaskVia(host, makeTask({ id: first.newId, name: '一改' }))
    const status = (await host.call('get', '/api/task-scheduler/status')).data
    const row = status.servers.find((s) => s.serverId === 's1')
    // 新建把 revision 从 0 抬到 1，再改一次抬到 2；关键是**单调递增**且两次都被服端确认
    assert.equal(row.revision, 2)
    assert.equal(row.ackRevision, 2, '两次都成功下发，服端应已确认到 revision=2')
    assert.equal(row.pending, false)
  } finally {
    dispose()
  }
})

test('按服务器隔离：改 s1 不影响 s2（旧版任务天生是服专属的）', async () => {
  const { host, dispose } = await boot()
  try {
    await createTaskVia(host, makeTask({ id: 'a', name: '一服的任务' }), 's1')
    const s2 = await host.call('get', '/api/task-scheduler/tasks/list', { headers: { 'x-server-id': 's2' } })
    assert.equal(s2.data.tasks.length, 0, 's2 不应看到 s1 的任务')
    const s1 = await host.call('get', '/api/task-scheduler/tasks/list', { headers: { 'x-server-id': 's1' } })
    assert.equal(s1.data.tasks.length, 1)
    // 只推了 s1
    const ids = new Set(snapshotCalls(host).map((c) => c.serverId))
    assert.deepEqual([...ids], ['s1'])
  } finally {
    dispose()
  }
})

// ═══════════════ 3. 下发失败 → 如实回显 + 自动重试 ═══════════════

test('未装 DLL（404）→ 映射成 501 + serverHalfMissing + 可操作提示，并回显到保存响应', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setBehavior('s1', 'missing')
    const res = await createTaskVia(host, makeTask({ name: '没装DLL' }))
    assert.equal(res.status, 200, '保存本身成功（配置已落盘），下发失败在响应里如实标注')
    assert.equal(res.data.pushOk, false, '下发失败**必须**在保存响应里可见（旧版此处彻底静默）')
    assert.ok(res.data.pushError.includes('TaskScheduler.dll'), res.data.pushError)
    assert.equal(res.data.push.results[0].serverHalfMissing, true)
    assert.ok(res.data.push.results[0].hint, '必须给出可操作的下一步提示')
  } finally {
    dispose()
  }
})

test('REST token 权限不足（403）→ 报出需要哪个权限', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setBehavior('s1', 'forbidden')
    const res = await createTaskVia(host, makeTask({ name: '权限不足' }))
    assert.equal(res.data.pushOk, false)
    assert.ok(res.data.pushError.includes('data.rest.invsee'), res.data.pushError)
  } finally {
    dispose()
  }
})

test('参数被拒（400）→ 把服端原文带上来（不吞掉原因）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setBehavior('s1', 'badRequest')
    const res = await createTaskVia(host, makeTask({ name: '参数被拒' }))
    assert.equal(res.data.pushOk, false)
    assert.ok(res.data.pushError.includes('version 必须是正整数'), res.data.pushError)
  } finally {
    dispose()
  }
})

test('服端 500 / fetchFor 抛错 → 都归为失败并给出原因（绝不静默）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setBehavior('s1', 'serverError')
    let res = await createTaskVia(host, makeTask({ id: 'x1', name: '服端500' }))
    assert.equal(res.data.pushOk, false)
    assert.ok(res.data.pushError.length > 0)

    gameHalf.setBehavior('s1', 'raise')
    res = await createTaskVia(host, makeTask({ id: 'x2', name: '调用抛错' }))
    assert.equal(res.data.pushOk, false)
    assert.ok(res.data.pushError.includes('调用游戏服失败'), res.data.pushError)
  } finally {
    dispose()
  }
})

test('下发失败后按退避自动重试，最终成功并清除失败状态', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setBehavior('s1', 'missing')
    const res = await createTaskVia(host, makeTask({ name: '重试后成功' }))
    assert.equal(res.data.pushOk, false)

    // 重试期间服端恢复
    gameHalf.setBehavior('s1', 'ok')
    await waitFor(async () => {
      const st = (await host.call('get', '/api/task-scheduler/status')).data
      const row = st.servers.find((s) => s.serverId === 's1')
      return row && row.pending === false
    }, { timeoutMs: 4000, intervalMs: 20, label: '自动重试后服端确认' })

    const st = (await host.call('get', '/api/task-scheduler/status')).data
    const row = st.servers.find((s) => s.serverId === 's1')
    assert.equal(row.pending, false)
    assert.equal(row.lastError, '', '成功之后不应再挂着上次的错误')
    assert.ok(snapshotCalls(host).length >= 2, '确实重试过')
  } finally {
    dispose()
  }
})

test('重试带的是**新版本号**（服端会拒旧载荷，用旧号重试等于永远推不上去）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setBehavior('s1', 'missing')
    await createTaskVia(host, makeTask({ name: '版本号单调' }))
    gameHalf.setBehavior('s1', 'ok')
    await waitFor(() => snapshotCalls(host).length >= 2, { label: '发生重试', timeoutMs: 4000 })

    const versions = snapshotCalls(host).map((c) => Number(c.params.version))
    for (let i = 1; i < versions.length; i++) {
      assert.ok(versions[i] > versions[i - 1], `版本号必须严格递增：${versions.join(',')}`)
    }
  } finally {
    dispose()
  }
})

test('服端拒绝更旧载荷（stale）→ 不算成功，且状态里说明原因', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setBehavior('s1', 'stale')
    await createTaskVia(host, makeTask({ name: 'stale' }))
    // 会一直重试并一直 stale，所以只断言"没有被记成已确认"
    await waitFor(async () => {
      const st = (await host.call('get', '/api/task-scheduler/status')).data
      const row = st.servers.find((s) => s.serverId === 's1')
      return row && row.pending === true && row.lastError.includes('版本更旧')
    }, { timeoutMs: 4000, intervalMs: 20, label: 'stale 被如实记为未确认' })
  } finally {
    dispose()
  }
})

test('服端"已应用但落盘失败"→ 记为失败并带出 saveError（重启会丢，必须让管理员看见）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setBehavior('s1', 'saveFail')
    const res = await createTaskVia(host, makeTask({ name: '落盘失败' }))
    assert.equal(res.data.pushOk, false)
    assert.ok(res.data.pushError.includes('落盘失败'), res.data.pushError)
  } finally {
    dispose()
  }
})

test('服务器未启用 → 不下发、不算失败、也不算已确认（启用后由对账补推）', async () => {
  const { host, dispose } = await boot({
    servers: [{ raw: { id: 's1', name: '停用服', host: '127.0.0.1', port: 7777, token: 't', enabled: false } }],
  })
  try {
    const res = await createTaskVia(host, makeTask({ name: '停用服任务' }))
    assert.equal(res.data.pushOk, false)
    assert.ok(res.data.pushError.includes('未启用'), res.data.pushError)
    assert.equal(snapshotCalls(host).length, 0, '未启用的服不应收到请求')
    const st = (await host.call('get', '/api/task-scheduler/status')).data
    const row = st.servers.find((s) => s.serverId === 's1')
    assert.equal(row.pending, true, '未启用的服仍属于"未确认"，启用后会补推')
  } finally {
    dispose()
  }
})

// ═══════════════ 4. 连接恢复补推 / 对账 ═══════════════

test('push/connected 事件 → 补推未确认的服（且不重复推已确认的）', async () => {
  const { host, dispose } = await boot()
  try {
    await createTaskVia(host, makeTask({ name: '已确认' }))
    const before = snapshotCalls(host).length
    assert.ok(host.fire('push/connected'), '应能触发 push/connected')
    await new Promise((r) => setTimeout(r, 120))
    assert.equal(snapshotCalls(host).length, before, '已确认最新的服不应被重复下发')
  } finally {
    dispose()
  }
})

test('servers/loaded 事件 → 补推（新出现的服会被打上）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    // 先在 s1 上制造"未确认"：让 s1 失败
    gameHalf.setBehavior('s1', 'missing')
    await createTaskVia(host, makeTask({ name: '待补推' }))
    const before = snapshotCalls(host).length
    gameHalf.setBehavior('s1', 'ok')
    assert.ok(host.fire('servers/loaded'))
    await waitFor(() => snapshotCalls(host).length > before, { label: 'servers/loaded 触发补推', timeoutMs: 4000 })
  } finally {
    dispose()
  }
})

test('对账：服端配置被外部改动 → probe 报出不一致（不许假装一致）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await createTaskVia(host, makeTask({ name: '对账用' }))
    const before = (await host.call('get', '/api/task-scheduler/status')).data
    const beforeRow = before.servers.find((s) => s.serverId === 's1')
    assert.equal(beforeRow.pending, false, '刚下发完应当是已确认状态')

    // 服端被直接改掉（模拟有人调服端 /data/tasks/save）：任务没了、版本号还更高
    gameHalf.setServerTaskCount('s1', 0)
    gameHalf.applied.set('s1', { version: 999, tasks: [] })

    const st = (await host.call('get', '/api/task-scheduler/status?probe=1')).data
    const row = st.servers.find((s) => s.serverId === 's1')
    assert.ok(row.probe, 'probe=1 时必须带 probe 结果')
    // 语义说明：ok = "这次自证**读取**成功"，inSync = "两端是否一致"。两者不能混为一谈——
    // 把不一致写成 ok:false 会让人以为"探测失败"，反而看不到真正的原因。
    assert.equal(row.probe.ok, true, '读取成功即为 ok')
    assert.equal(row.probe.inSync, false, '服端与宿主不一致必须报 inSync=false')
    assert.equal(row.probe.onlyInHost.length, 1, '必须指名"只在宿主有"的任务')
    assert.equal(row.probe.serverTaskCount, 0)
    assert.equal(row.probe.hostTaskCount, 1)
  } finally {
    dispose()
  }
})

test('对账：两端一致时 probe.inSync 为 true（正对照，避免"永远报不一致"的假告警）', async () => {
  const { host, dispose } = await boot()
  try {
    await createTaskVia(host, makeTask({ name: '一致的任务' }))
    const st = (await host.call('get', '/api/task-scheduler/status?probe=1')).data
    const row = st.servers.find((s) => s.serverId === 's1')
    assert.equal(row.probe.inSync, true)
    assert.equal(row.probe.differing.length, 0)
    assert.equal(row.probe.onlyInHost.length, 0)
    assert.equal(row.probe.onlyInServer.length, 0)
    assert.equal(row.probe.same.length, 1)
  } finally {
    dispose()
  }
})

test('对账：同一 id 但字段被改过 → 算"不一致"，不能因为 id 相同就放过', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    const made = await createTaskVia(host, makeTask({ name: '原名', commands: ['/bc a'] }))
    // 服端同名 id 但命令被改掉
    gameHalf.applied.set('s1', {
      version: 1,
      tasks: [makeTask({ id: made.newId, name: '原名', commands: ['/bc 被别人改了'] })],
    })
    const st = (await host.call('get', '/api/task-scheduler/status?probe=1')).data
    const row = st.servers.find((s) => s.serverId === 's1')
    assert.equal(row.probe.inSync, false)
    assert.equal(row.probe.differing.length, 1)
    assert.equal(row.probe.differing[0].id, made.newId)
  } finally {
    dispose()
  }
})

test('registry 之外的孤儿配置（服务器已删除）必须显示出来', async () => {
  const { dataDir, host, gameHalf, dispose } = await boot()
  dispose()
  await mkdir(pluginDataDir(dataDir), { recursive: true })
  await writeFile(pluginConfigFile(dataDir), JSON.stringify({
    version: 1,
    updatedAt: '',
    servers: { ghost: { revision: 1, updatedAt: '', tasks: [makeTask({ id: 'g1', name: '孤儿' })] } },
  }), 'utf8')

  const host2 = makeFakeHost({ dataDir, servers: SERVERS, fetchFor: gameHalf.fetchFor })
  const dispose2 = await apply(host2.ctx, { push: FAST })
  try {
    const st = (await host2.call('get', '/api/task-scheduler/status')).data
    const row = st.servers.find((s) => s.serverId === 'ghost')
    assert.ok(row, '孤儿服务器必须出现在状态里')
    assert.equal(row.orphan, true)
    assert.equal(row.name, '(服务器已删除)')
    assert.ok(row.lastError.includes('不会'), '必须说明它的配置不会被下发')
  } finally {
    dispose2()
  }
})

test('dispose 停掉对账与重试定时器：卸载后不再有后台请求', async () => {
  const { host, gameHalf, dispose } = await boot()
  gameHalf.setBehavior('s1', 'missing')
  await createTaskVia(host, makeTask({ name: '卸载前' }))
  const before = snapshotCalls(host).length
  dispose()
  await new Promise((r) => setTimeout(r, 300))
  assert.equal(snapshotCalls(host).length, before, 'dispose 之后不应再下发')
})

// ═══════════════ 5. 空列表双端守卫（防"配置被清空"）═══════════════

test('管理员删光全部任务 → 下发带 allowEmpty=1（否则服端 409，永远删不掉）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    const saved = await createTaskVia(host, makeTask({ name: '待删除' }))
    assert.ok(saved.newId)
    assert.equal(saved.data.pushOk, true)
    assert.equal(gameHalf.serverTaskCount.get('s1'), 1)

    const del = await host.call('post', '/api/task-scheduler/tasks/delete', {
      headers: { 'x-server-id': 's1' },
      body: { id: saved.newId },
    })
    assert.equal(del.status, 200)
    assert.equal(del.data.pushOk, true, '删光后必须能真的下发到服端')

    const last = snapshotCalls(host).at(-1)
    assert.deepEqual(JSON.parse(last.params.tasks), [])
    assert.equal(last.params.allowEmpty, '1', '空列表必须带 allowEmpty=1')
    assert.equal(gameHalf.serverTaskCount.get('s1'), 0)
  } finally {
    dispose()
  }
})

test('宿主配置文件损坏且任务为空 → **拒绝下发空配置**（防把服端任务清空）', async () => {
  const { dataDir, host, gameHalf, dispose } = await boot()
  dispose()
  await mkdir(pluginDataDir(dataDir), { recursive: true })
  // 服端当前有任务
  gameHalf.setServerTaskCount('s1', 3)
  // 宿主配置损坏（这里故意先放一份合法配置，再改成坏 JSON）
  await writeFile(pluginConfigFile(dataDir),
    JSON.stringify({ version: 1, updatedAt: '', servers: { s1: { revision: 1, updatedAt: '', tasks: [makeTask({ id: 'k1', name: 'x' })] } } }),
    'utf8')
  await writeFile(pluginConfigFile(dataDir), '{ this is not json', 'utf8')

  const host2 = makeFakeHost({ dataDir, servers: SERVERS, fetchFor: gameHalf.fetchFor })
  const dispose2 = await apply(host2.ctx, { push: FAST })
  try {
    const list = (await host2.call('get', '/api/task-scheduler/tasks/list', { headers: { 'x-server-id': 's1' } })).data
    assert.ok(list.storeError, 'storeError 必须回给界面')
    assert.ok(list.storeError.includes('无法解析'), list.storeError)
    assert.equal(list.tasks.length, 0)

    const st = (await host2.call('get', '/api/task-scheduler/status')).data
    assert.equal(st.storeError, list.storeError)
    assert.equal(st.pendingCount, 0, '没有任何配置条目 → 没有待下发的服')
    assert.equal(snapshotCalls(host2).length, 0, '损坏状态下不得向服端下发空配置')
  } finally {
    dispose2()
  }
})

// ═══════════════ 6. 采纳服端已有配置（旧版数据迁移入口）═══════════════

test('服端已有任务、宿主没有 → 列表接口给出 unadopted 提示', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setServerTaskCount('s1', 2)
    gameHalf.applied.set('s1', {
      version: 0,
      tasks: [makeTask({ id: 'L1', name: '旧版任务甲' }), makeTask({ id: 'L2', name: '旧版任务乙' })],
    })
    gameHalf.setSource('s1', 'legacy')

    const list = (await host.call('get', '/api/task-scheduler/tasks/list', { headers: { 'x-server-id': 's1' } })).data
    assert.ok(list.unadopted, '必须提示服端有未采纳的任务')
    assert.equal(list.unadopted.count, 2)
    assert.deepEqual(list.unadopted.names, ['旧版任务甲', '旧版任务乙'])
    assert.equal(list.unadopted.source, 'legacy')
  } finally {
    dispose()
  }
})

test('adopt：采纳服端配置到宿主，并随即下发一次', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.setServerTaskCount('s1', 2)
    gameHalf.applied.set('s1', {
      version: 0,
      tasks: [makeTask({ id: 'L1', name: '旧版任务甲' }), makeTask({ id: 'L2', name: '旧版任务乙' })],
    })
    const res = await host.call('post', '/api/task-scheduler/adopt', { headers: { 'x-server-id': 's1' }, body: {} })
    assert.equal(res.status, 200)
    assert.equal(res.data.taskCount, 2)
    assert.ok(res.data.message.includes('2'))

    const list = (await host.call('get', '/api/task-scheduler/tasks/list', { headers: { 'x-server-id': 's1' } })).data
    assert.equal(list.tasks.length, 2)
    assert.equal(list.tasks[0].name, '旧版任务甲')
  } finally {
    dispose()
  }
})

// ═══════════════ 6.5 宿主侧端点的错误语义（旧版这里全是 200）═══════════════

test('保存时给了不存在的 id → 404 任务不存在（本件有意收紧：旧版会拿这个 id 直接新建）', async () => {
  const { host, dispose } = await boot()
  try {
    // 旧版 /data/tasks/save 收到未知 id 会 Tasks.Add（TaskScheduler.cs:693-696），
    // 等于允许调用方用任意 id 悄悄插入任务；宿主侧改为硬失败，避免"以为是编辑、实际是新建"。
    // 注意：**服端那个旧契约端点仍保持旧行为**（plugin/TaskSchedulerEndpoints.cs 的 Save），
    // 所以按旧契约调用的脚本不受影响。
    const res = await saveTaskVia(host, makeTask({ id: 'does-not-exist', name: '未知id' }))
    assert.equal(res.status, 404)
    assert.equal(res.data.error, '任务不存在')

    const list = (await host.call('get', '/api/task-scheduler/tasks/list', { headers: { 'x-server-id': 's1' } })).data
    assert.equal(list.tasks.length, 0, '404 时不得落盘')
  } finally {
    dispose()
  }
})

test('删除不存在的任务 → 404；删除正在执行的任务 → 400 任务正在执行中，无法删除（旧版文案）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    const miss = await host.call('post', '/api/task-scheduler/tasks/delete', {
      headers: { 'x-server-id': 's1' }, body: { id: 'nope' },
    })
    assert.equal(miss.status, 404)
    assert.equal(miss.data.error, '任务不存在')

    const made = await createTaskVia(host, makeTask({ name: '正在执行' }))
    gameHalf.setRuntime('s1', made.newId, { running: true })
    const busy = await host.call('post', '/api/task-scheduler/tasks/delete', {
      headers: { 'x-server-id': 's1' }, body: { id: made.newId },
    })
    // 文案照搬旧版；状态码是宿主侧新定的：用 409 Conflict 表达"当前状态不允许该操作"。
    // 旧版根本没有状态码可言（服端匿名对象恒返回 HTTP 200，靠 body.success 判成败），
    // 所以这里不存在"与旧版不一致"的问题，只有"比旧版更可判"。
    assert.equal(busy.status, 409)
    assert.equal(busy.data.error, '任务正在执行中，无法删除')
  } finally {
    dispose()
  }
})

test('手动执行：force 只接受 0/1/true/false，其余取值明确 400（旧版静默当 false）', async () => {
  const { host, dispose } = await boot()
  try {
    const made = await createTaskVia(host, makeTask({ name: 'force' }))
    for (const good of ['1', 'true', '0', 'false']) {
      const r = await host.call('post', '/api/task-scheduler/tasks/run', {
        headers: { 'x-server-id': 's1' }, body: { id: made.newId, force: good },
      })
      assert.equal(r.status, 200, `force=${good} 应被接受`)
    }
    for (const bad of ['yes', '2', 'on']) {
      const r = await host.call('post', '/api/task-scheduler/tasks/run', {
        headers: { 'x-server-id': 's1' }, body: { id: made.newId, force: bad },
      })
      assert.equal(r.status, 400, `force=${bad} 应被拒绝`)
      assert.ok(r.data.error.includes('force'), r.data.error)
    }
  } finally {
    dispose()
  }
})

test('手动执行 force=1 会原样传到服端（旧版 /run?id=&force=1）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    const made = await createTaskVia(host, makeTask({ name: '强制' }))
    await host.call('post', '/api/task-scheduler/tasks/run', {
      headers: { 'x-server-id': 's1' }, body: { id: made.newId, force: 1 },
    })
    assert.equal(gameHalf.runCalls.length, 1)
    assert.equal(gameHalf.runCalls[0].id, made.newId)
    assert.equal(gameHalf.runCalls[0].force, 1)
  } finally {
    dispose()
  }
})

// ═══════════════ 7. 审计 ═══════════════

test('保存/删除/手动执行/下发都写审计（旧版没有审计）', async () => {
  const { host, dispose } = await boot()
  try {
    const made = await createTaskVia(host, makeTask({ name: '审计' }))
    assert.ok(made.newId)
    await host.call('post', '/api/task-scheduler/tasks/run', { headers: { 'x-server-id': 's1' }, body: { id: made.newId, force: 1 } })
    await host.call('post', '/api/task-scheduler/tasks/delete', { headers: { 'x-server-id': 's1' }, body: { id: made.newId } })

    const audit = (await host.call('get', '/api/task-scheduler/audit')).data
    const actions = audit.entries.map((e) => e.action)
    assert.ok(actions.includes(ACTIONS.configWrite), JSON.stringify(actions))
    assert.ok(actions.includes(ACTIONS.taskRun), JSON.stringify(actions))
    assert.ok(actions.includes(ACTIONS.configPush), JSON.stringify(actions))
    for (const e of audit.entries) {
      // 审计条目字段是 t（时间）/ action（动作名）/ actor（操作者）
      assert.ok(e.t, '每条审计都要有时间')
      assert.ok(e.actor !== undefined, '每条审计都要有操作者字段')
    }
  } finally {
    dispose()
  }
})

test('审计动作名带 task-scheduler 前缀（与插件名一致，便于在多插件审计里过滤）', () => {
  for (const v of Object.values(ACTIONS)) {
    assert.ok(String(v).startsWith('task-scheduler.'), `${v} 应以 task-scheduler. 开头`)
  }
})
