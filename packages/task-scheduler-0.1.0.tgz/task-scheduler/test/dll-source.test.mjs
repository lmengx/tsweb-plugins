/**
 * 源码层断言：自动任务插件的调度 / 条件 / 执行 / 落库语义（游戏服半）
 *
 * 这是"功能真的按约定实现"的**源码侧**证据（字节侧证据见 test/dll-content.test.mjs）。
 * 分工：
 *   - dll-content.test.mjs 证明"这段代码进了将被打包下发的 DLL"；
 *   - 本文件证明"这段代码的语义就是规格要求的那样"（节拍、等值比较、取否、预检、只读表……）。
 * 两者都不能替代运行期验证——本机没有 TShock 运行环境，因此这里断言的是**编译层语义**，
 * 不是"在真实服务器上跑起来会怎样"。
 *
 * 本文件覆盖的关键语义（每条都对应一个旧版缺陷或规格硬约束）：
 *   1. 1 秒节拍 + AutoReset（节拍是 interval / daily 两种触发的唯一时间来源）
 *   2. daily 判定用**字符串等值比较** "HH:mm" + 当天去重（旧版既定语义，刻意保留）
 *   3. 条件求值的四种类型字面量 + not 取反 + 未知类型恒 true（旧版行为）
 *   4. wait 虚拟命令的正则与 IgnoreCase（并带 24 小时上限，修旧版 D18）
 *   5. 命令规范化补 Commands.Specifier 前缀（任务里可以直接写 broadcast xxx）
 *   6. 执行身份取 superadmin 用户组（旧版硬编码，本件补了"组不存在"的回落与日志）
 *   7. 执行记录表 task_execution_logs，且**不建** player_daily_stat（那是别的插件的表）
 *   8. ★ 不把 Commands.HandleCommand 的返回值当成功判据（它恒返回 true），
 *      改用执行前分类 HasAlias / CanRun / AllowServer ★（旧版必改缺陷之二）
 *   9. boss_defeated 读的是图鉴击杀数 Main.BestiaryTracker（宿主进程读不到，这正是本件
 *      必须落在游戏服半的原因之一）
 *  10. 并发模式用 Task.Run + Task.WaitAll（每条命令一个 Task，结果不丢）
 *  11. Thread.Sleep 只出现在 wait 分支（Dispatcher 里的等待用事件，绝不阻塞主线程）
 *  12. 18 个 BOSS 名称表逐项且**顺序**一致
 *  13. REST 路由 11 条与权限名（注册与分派共用同一份清单）
 *  14. 中文注释存在（本仓约定）
 *  15. 禁止 emoji（本仓约定）
 *
 * 做法：把本插件的**全部源码与脚本**（.cs / .js / .mjs / .csproj / .json，排除 bin、obj
 * 与 test/ 自身）读成逐行文本后扫描。为什么排除 test/：测试文件里必然出现这些串
 * （那是断言文本，不是实现），把测试自己的文案当成"实现"来判定是无效判据。
 *
 * 运行：node test/dll-source.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile, readdir } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginRoot = path.resolve(here, '..')

/** 排除的目录：构建产物与测试自身（测试文件里必然出现这些串，那是断言文本，不是实现） */
const SKIP_DIRS = new Set(['bin', 'obj', 'node_modules', 'test', '.git'])
const EXTS = new Set(['.cs', '.js', '.mjs', '.csproj', '.json'])

/** 递归收集本插件的源码文件 */
async function collect(dir) {
  const out = []
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.')) continue
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue
      out.push(...await collect(full))
      continue
    }
    if (!EXTS.has(path.extname(entry.name).toLowerCase())) continue
    out.push(full)
  }
  return out
}

let cachedTexts = null

/** 读出所有源码文件的行（带 文件:行号，便于报告里引用） */
async function sources() {
  if (cachedTexts) return cachedTexts
  const files = await collect(pluginRoot)
  assert.ok(files.length >= 8, `收集到的源码文件太少（${files.length}），扫描范围可疑：${files.join(', ')}`)
  const texts = []
  for (const f of files) {
    const content = await readFile(f, 'utf8')
    const rel = path.relative(pluginRoot, f).replace(/\\/g, '/')
    content.split(/\r?\n/).forEach((line, i) => texts.push({ file: rel, line: i + 1, text: line }))
  }
  cachedTexts = texts
  return texts
}

/** 读单个源文件（相对于本插件根） */
async function readSrc(rel) {
  return readFile(path.join(pluginRoot, rel), 'utf8')
}

/** 去掉行内注释（朴素实现：够用，且注释里出现表名/方法名不算"实现里有这段代码"） */
function stripComment(text) {
  const t = text.trim()
  if (t.startsWith('//') || t.startsWith('*') || t.startsWith('/*') || t.startsWith('///')) return ''
  const i = text.indexOf('//')
  return i >= 0 ? text.slice(0, i) : text
}

/** 整份源码的"去注释版"（用于"只出现在某处"这类判定） */
function codeOnly(src) {
  return src.split(/\r?\n/).map(stripComment).join('\n')
}

/**
 * BOSS 名称表：中文名 → NPCID 常量，**顺序与 TaskSchedulerEngine.cs 的 BossNpcIds 一致**。
 * 顺序也是判据：这张表会整份回显给宿主（/data/tasks/status 的 knownBossNames），
 * 顺序变动说明有人改过它，需要一眼看出来。
 */
const BOSS_ENTRIES = [
  ['史莱姆王', 'KingSlime'],
  ['克苏鲁之眼', 'EyeofCthulhu'],
  ['世界吞噬者', 'EaterofWorldsHead'],
  ['克苏鲁之脑', 'BrainofCthulhu'],
  ['蜂后', 'QueenBee'],
  ['巨鹿', 'Deerclops'],
  ['骷髅王', 'SkeletronHead'],
  ['血肉墙', 'WallofFlesh'],
  ['史莱姆皇后', 'QueenSlimeBoss'],
  ['毁灭者', 'TheDestroyer'],
  ['机械骷髅王', 'SkeletronPrime'],
  ['双子魔眼', 'Retinazer'],
  ['世纪之花', 'Plantera'],
  ['石巨人', 'Golem'],
  ['猪龙鱼公爵', 'DukeFishron'],
  ['光之女皇', 'HallowBoss'],
  ['拜月教教徒', 'CultistBoss'],
  ['月亮领主', 'MoonLordCore'],
]

/** 本插件注册的 11 条 REST 路由（顺序与 TaskSchedulerPlugin.OwnRoutes 一致） */
const OWN_ROUTES = [
  '/data/tasks/list',
  '/data/tasks/get',
  '/data/tasks/save',
  '/data/tasks/delete',
  '/data/tasks/run',
  '/data/tasks/log',
  '/data/tasks/log/detail',
  '/data/tasks/logs',
  '/data/tasks/logs/detail',
  '/data/tasks/snapshot',
  '/data/tasks/status',
]

/**
 * 允许的几何 / 装饰符号（本项目既有文案字符，**不得**判成 emoji）：
 *   ✕ 删除、＋ 添加、− 与 — 破折号、⠿ 与 ▶ 界面符号、★ 章节标题装饰。
 * ★ 的说明：它是全仓 C# 注释通用的章节标记（本插件的 C# 注释里出现 12 次），
 * 落在 U+2605、正好在 promotion 那份 emoji 正则的 U+2600-U+27BF 区间内；
 * 沿用同一份正则时必须显式摘掉它，否则会把既有排版约定误判成 emoji。
 * 下面那条"emoji 扫描器有区分度"的用例会断言这些符号确实存在（ALLOWED 不是空转）。
 */
const ALLOWED_GEOMETRY = /[✕＋−—⠿▶★]/g
/** 真正的 emoji 区段（与 plugins/promotion/test/client-ui.test.mjs:262 完全一致） */
const EMOJI_RE = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}\u{1F1E6}-\u{1F1FF}]/u

test('扫描范围健全：本插件的 C# / JS / 配置源文件都被纳入（不是扫了个空集）', async () => {
  const rows = await sources()
  const files = new Set(rows.map((r) => r.file))
  for (const must of [
    'plugin/TaskScheduler.csproj',
    'plugin/TaskSchedulerPlugin.cs',
    'plugin/TaskSchedulerEngine.cs',
    'plugin/TaskSchedulerEndpoints.cs',
    'plugin/TaskSchedulerLogStore.cs',
    'plugin/TaskSchedulerModel.cs',
    'plugin/TaskSchedulerDispatcher.cs',
    'plugin/SqlCompat.cs',
    'config.js',
    'index.js',
    'gameOps.js',
    'audit.js',
    'client/task-scheduler.js',
    'package.json',
  ]) {
    assert.ok(files.has(must), `扫描范围缺少 ${must}（源码扫描必须覆盖全部实现文件）`)
  }
  // 构建产物与测试自身必须被排除（否则判据会被自己的文案污染）
  for (const r of rows) {
    assert.doesNotMatch(r.file, /(^|\/)(bin|obj|test)\//, `扫描范围不该包含构建产物或测试自身：${r.file}`)
  }
})

test('插件身份与构建布局：程序集名 / 命名空间 / 类名 / 作者 / 版本 / 日志前缀', async () => {
  const csproj = await readSrc('plugin/TaskScheduler.csproj')
  assert.match(csproj, /<AssemblyName>TaskScheduler<\/AssemblyName>/, '程序集名必须是 TaskScheduler（决定 DLL 文件名）')
  assert.match(csproj, /<RootNamespace>TsWebTaskScheduler<\/RootNamespace>/, '根命名空间必须是 TsWebTaskScheduler')
  assert.match(csproj, /<TargetFramework>net9\.0<\/TargetFramework>/, '目标框架必须是 net9.0')
  assert.match(csproj, /<OutputPath>bin\\\$\(Configuration\)\\<\/OutputPath>/,
    'OutputPath 必须是 bin\\$(Configuration)\\（产物落在 bin/Release/net9.0/，由打包器回拷到 plugin/）')

  const plugin = await readSrc('plugin/TaskSchedulerPlugin.cs')
  assert.match(plugin, /namespace TsWebTaskScheduler/, '命名空间必须是 TsWebTaskScheduler')
  assert.match(plugin, /\[ApiVersion\(2, 1\)\]/, '必须声明 [ApiVersion(2, 1)]（TShock 插件 API 版本）')
  assert.match(plugin, /public class TaskSchedulerPlugin : TerrariaPlugin/, '入口类必须继承 TerrariaPlugin')
  assert.match(plugin, /public override string Name => "TaskScheduler";/, '插件名必须是 TaskScheduler')
  assert.match(plugin, /public override string Author => "TSWeb";/, '作者必须是 TSWeb')
  assert.match(plugin, /public override Version Version => new\(0, 1, 0\);/, '版本必须是 0.1.0')

  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')
  assert.match(engine, /public const string LogPrefix = "\[TaskScheduler\]";/,
    '日志前缀常量必须是 [TaskScheduler]（独立插件身份，正文逐字沿用旧版）')
})

test('1 秒节拍：TickIntervalMs = 1000 且定时器 AutoReset = true（两种触发的唯一时间来源）', async () => {
  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')
  assert.match(engine, /private const int TickIntervalMs = 1000;/, '节拍常量必须是 1000 毫秒（旧版 TaskScheduler.cs:169 的 timer 周期）')
  assert.match(engine, /_timer = new System\.Timers\.Timer\(TickIntervalMs\);/, '定时器必须用节拍常量构造（常量被真正使用，不是死代码）')
  assert.match(engine, /_timer\.Elapsed \+= OnSecondTick;/, '必须挂 OnSecondTick')
  assert.match(engine, /_timer\.AutoReset = true;/, 'AutoReset 必须为 true（否则只触发一次，interval / daily 全都不会到点）')
  assert.match(engine, /_timer\.Start\(\);/, '必须启动定时器')
  // 防重入：一次慢 tick 不能与下一次并发跑同一批任务
  assert.match(engine, /Interlocked\.CompareExchange\(ref _tickBusy, 1, 0\)/,
    'tick 必须用 Interlocked 做防重入（旧版没有任何防重入，慢 tick 会与下一次并发跑同一批任务）')
})

test('热重载安全：Initialize 必须先停旧定时器再建新的（否则重复 Initialize 会跑两份 1 秒节拍）', async () => {
  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')

  // _timer 是 static，宿主热重载若只调 Initialize 而没走 Dispose（规格 §14.2 明确列为未确认），
  // 旧定时器既没人引用也没人停，会继续按 1 秒节奏跑 OnSecondTick：同一个任务被两个定时器各判一次，
  // 间隔任务可能连触发两次，且每次热重载再泄漏一个（旧版 D30 同类前科）。
  // 因此 Initialize 里必须是"先 StopTimer() 再 new"，且这行要出现在 new 之前。
  const initBody = engine.slice(engine.indexOf('public static void Initialize(TerrariaPlugin plugin)'))
  const initEnd = initBody.indexOf('private static void StopTimer()')
  assert.ok(initEnd > 0, '应能定位到 Initialize 的方法体（StopTimer 定义之前的部分）')
  const init = initBody.slice(0, initEnd)

  const stopIdx = init.indexOf('StopTimer();')
  const newIdx = init.indexOf('_timer = new System.Timers.Timer(TickIntervalMs);')
  assert.ok(stopIdx > 0, 'Initialize 必须先调用 StopTimer() 停掉旧定时器')
  assert.ok(newIdx > 0, 'Initialize 必须新建定时器')
  assert.ok(stopIdx < newIdx, 'StopTimer() 必须在 new Timer 之前（顺序反了就等于没停）')

  // 停逻辑只有一处实现：Dispose 也复用它，避免两条路径行为不一致
  assert.match(engine, /private static void StopTimer\(\)/, 'StopTimer 必须存在')
  const dispose = engine.slice(engine.indexOf('public static void Dispose()'))
  assert.match(dispose, /StopTimer\(\);/, 'Dispose 也必须走 StopTimer（只有一处停逻辑）')
  // StopTimer 内部要真的停 + 摘事件 + 释放，并把字段置空（否则下次判断 _timer != null 失效）
  const stopBody = engine.slice(engine.indexOf('private static void StopTimer()'), engine.indexOf('/// <summary>停止调度器'))
  assert.match(stopBody, /_timer\.Stop\(\);/, 'StopTimer 要 Stop')
  assert.match(stopBody, /_timer\.Elapsed -= OnSecondTick;/, 'StopTimer 要摘掉事件处理器（避免残留引用）')
  assert.match(stopBody, /_timer\.Dispose\(\);/, 'StopTimer 要 Dispose')
  assert.match(stopBody, /_timer = null;/, 'StopTimer 必须把字段置空（幂等的前提）')
  assert.match(stopBody, /if \(_timer == null\) return;/, 'StopTimer 必须可重复调用（幂等）')

  // 反面：不能再出现"绕过 StopTimer 直接释放定时器"的写法
  const directDispose = engine.match(/_timer\.Dispose\(\);/g) || []
  assert.equal(directDispose.length, 1,
    `_timer.Dispose() 只应出现在 StopTimer 里（实际 ${directDispose.length} 处）——多出来说明有路径绕过统一停逻辑`)
})

test('daily 判定：字符串等值比较 "HH:mm" + 当天去重（旧版既定语义，刻意保留）', async () => {
  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')
  assert.ok(
    engine.includes('now.ToString("HH:mm") != task.DailyTime'),
    'daily 到点判定必须是字符串等值比较 now.ToString("HH:mm") != task.DailyTime（旧版 :282 的既定语义，'
    + '改成区间/解析会让"每天 03:00"变成别的意思）',
  )
  assert.ok(
    engine.includes('task.LastDailyRunAt.Date == now.Date'),
    'daily 必须靠"日期相等"做当天去重（LastDailyRunAt.Date == now.Date），否则同一个 HH:mm 的这一分钟内会反复触发',
  )
  assert.match(engine, /if \(task\.LastDailyRunAt\.Date == now\.Date\)\s*\r?\n\s*return false;/,
    '当天已跑过必须直接 return false（当天只触发一次的判据）')
  // 去重依据要在"触发时刻"就写入（TryBeginRun 的 isDaily 分支），否则条件不满足被跳过后当天会反复重试
  const model = await readSrc('plugin/TaskSchedulerModel.cs')
  assert.match(model, /public static bool TryBeginRun\(string id, DateTime now, bool isDaily\)/,
    '原子占位入口必须带 isDaily 参数')
  assert.match(model, /if \(isDaily\) t\.LastDailyRunAt = now;/, 'daily 的当天标志必须在占位时写入（旧版 :270 语义）')
})

test('条件求值：四种类型字面量 + not 取反 + 未知类型恒 true', async () => {
  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')
  const start = engine.indexOf('public static bool EvaluateCondition')
  const end = engine.indexOf('private static int OnlinePlayerCount')
  assert.ok(start >= 0 && end > start, '找不到 EvaluateCondition 方法体（扫描边界失效）')
  const body = engine.slice(start, end)

  for (const [lit, why] of [
    ['"always"', '无条件'],
    ['"online_count"', '在线人数闭区间'],
    ['"boss_defeated"', '所选 BOSS 全部被击败'],
    ['"player_online"', '指定玩家全部在线'],
  ]) {
    assert.ok(body.includes(lit), `条件类型字面量 ${lit} 缺失（${why}）——/data/tasks/save 的校验与求值必须用同一组字面量`)
  }
  assert.match(body, /_ => true,/, '未知条件类型必须恒 true（旧版 :303-304 行为；REST 保存会拒绝未知类型，只有手改文件才可能）')
  assert.ok(
    body.includes('return condition.Not ? !result : result;'),
    '取否逻辑必须是 condition.Not ? !result : result（否则"不满足时执行"这类任务会全部反过来）',
  )
  assert.match(body, /"online_count" => IsOnlineCountInRange\(condition\.Params\)/, 'online_count 必须走闭区间判定')
  assert.match(body, /"boss_defeated" => AreBossesDefeated\(condition\.Params\)/, 'boss_defeated 必须读 BOSS 列表')
  assert.match(body, /"player_online" => ArePlayersOnline\(condition\.Params\)/, 'player_online 必须读玩家名列表')
  // 在线人数只数 Active 的玩家（旧版 :309-310）
  assert.match(engine, /TShock\.Players\.Count\(p => p != null && p\.Active\)/, '在线人数必须只数 p != null && p.Active 的玩家')
  // 人数区间是闭区间（旧版 :312-316）：min/max 默认 0/9999
  assert.match(engine, /return count >= p\.Min && count <= p\.Max;/, '在线人数判定必须是闭区间 count >= Min && count <= Max')
  const model = await readSrc('plugin/TaskSchedulerModel.cs')
  assert.match(model, /\[JsonProperty\("min"\)\] public int Min \{ get; set; \} = 0;/, 'min 默认值必须是 0')
  assert.match(model, /\[JsonProperty\("max"\)\] public int Max \{ get; set; \} = 9999;/, 'max 默认值必须是 9999')
})

test('wait 虚拟命令：正则 ^wait\\s+(\\d+)$ + IgnoreCase，且有 24 小时上限（修旧版 D18）', async () => {
  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')
  const waitLine = engine.split(/\r?\n/).find((l) => l.includes('WaitRegex = new('))
  assert.ok(waitLine, '找不到 WaitRegex 的定义（wait 虚拟命令缺失）')
  assert.ok(
    waitLine.includes('@"^wait\\s+(\\d+)$"'),
    `wait 的正则必须是 @"^wait\\s+(\\d+)$"（只接受纯毫秒数字），实际：${waitLine.trim()}`,
  )
  assert.match(waitLine, /RegexOptions\.IgnoreCase/, 'wait 必须 IgnoreCase（旧版 :528 同，"WAIT 1000" 也要认）')
  assert.match(engine, /var match = WaitRegex\.Match\(StripPrefix\(normalized\)\);/, 'wait 必须在剥掉执行符号后再匹配（"/wait 1000" 也要认）')
  assert.match(engine, /private const int MaxWaitMs = 24 \* 60 \* 60 \* 1000;/, 'wait 必须有 24 小时上限常量（旧版无上限，D18）')
  assert.match(engine, /if \(ms > MaxWaitMs\)/, 'wait 超上限必须是明确的失败结论，而不是真的睡那么久')
  assert.match(engine, /return Fail\(result, "wait_too_long"/, 'wait 超上限的错误分类必须是 wait_too_long')
  assert.match(engine, /return Fail\(result, "wait_overflow"/, 'wait 参数溢出 int 时必须给出 wait_overflow（不能让 int.Parse 抛异常）')
})

test('命令规范化：不以执行符号 / 静默符号开头时补 Commands.Specifier 前缀', async () => {
  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')
  assert.match(engine, /public static string NormalizeCommand\(string cmd\)/, '必须有 NormalizeCommand')
  assert.match(
    engine,
    /var specifier = string\.IsNullOrWhiteSpace\(Commands\.Specifier\) \? "\/" : Commands\.Specifier;/,
    '执行符号必须取 Commands.Specifier（空则回落 "/"）——这样任务里可以直接写 broadcast xxx',
  )
  assert.match(
    engine,
    /var silentSpecifier = string\.IsNullOrWhiteSpace\(Commands\.SilentSpecifier\) \? "\." : Commands\.SilentSpecifier;/,
    '静默符号必须取 Commands.SilentSpecifier（空则回落 "."）',
  )
  assert.match(engine, /return specifier \+ trimmed;/, '未带前缀的命令必须补上执行符号前缀')
  assert.match(engine, /if \(string\.IsNullOrWhiteSpace\(cmd\)\)\s*\r?\n\s*return cmd;/, '空命令必须原样返回（由执行器给出"命令为空"的明确结论，而不是抛下标越界）')
})

test('执行身份：用户组来自 TShock.Groups.GetGroupByName("superadmin")，并带回落与显式日志', async () => {
  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')
  assert.ok(
    engine.includes('TShock.Groups.GetGroupByName("superadmin")'),
    '执行身份所在的用户组必须取自 TShock.Groups.GetGroupByName("superadmin")（旧版硬编码 "superadmin"，:470）',
  )
  assert.match(engine, /private static void ResolveExecutorGroup\(\)/, '必须有执行身份解析方法（并在启动时缓存一次）')
  assert.match(engine, /new TSRestPlayer\("TaskExecutor", _executorGroup!\)/, '必须用 TSRestPlayer 构造执行身份')
  // 组不存在时必须留下日志（旧版会静默地让所有命令因权限不足失败，D8）
  assert.match(engine, /未找到 superadmin 用户组/, '组不存在时必须显式报出来（旧版是静默失败，D8）')
  assert.match(engine, /HasPermission\(Permissions\.su\)/, '必须按"拥有最高权限的组"回落，而不是直接放弃')
})

test('执行记录表：task_execution_logs，且全文不建 player_daily_stat（CREATE TABLE 全部幂等）', async () => {
  const logStore = await readSrc('plugin/TaskSchedulerLogStore.cs')
  assert.match(logStore, /public const string Table = "task_execution_logs";/,
    '记录表名必须逐字沿用旧版 task_execution_logs（改名会让历史执行记录"看不见"）')
  assert.match(logStore, /CREATE TABLE IF NOT EXISTS \{Table\} \(/,
    '建表语句必须是 CREATE TABLE IF NOT EXISTS {Table} (（幂等：存量库上是 no-op，旧表与数据原样保留）')
  assert.match(logStore, /Id \{SqlCompat\.AutoIncrementIdColumn\},/,
    'Id 列必须走 SqlCompat.AutoIncrementIdColumn（三方言：SQLite/MySQL/Postgres）')
  // 列结构逐项断言（旧版同名列，历史记录才能继续读出来）
  for (const col of [
    'TaskId VARCHAR(64) NOT NULL', 'TaskName VARCHAR(255) NOT NULL', 'TriggeredAt VARCHAR(19) NOT NULL',
    'TriggerMode VARCHAR(16) NOT NULL', 'ConditionResult INTEGER NOT NULL', 'Skipped INTEGER NOT NULL DEFAULT 0',
    'Status VARCHAR(16) NOT NULL', 'StartedAt VARCHAR(19)', 'CompletedAt VARCHAR(19)',
    'DurationMs INTEGER DEFAULT 0', 'CommandResults TEXT', 'ErrorSummary TEXT', 'CreatedAt TEXT',
  ]) {
    assert.ok(logStore.includes(col), `建表语句缺少列定义：${col}（列结构必须逐字沿用旧版）`)
  }
  assert.match(logStore, /SqlCompat\.CreateIndexIfNotExists\("idx_tel_taskid", Table, "TaskId"\);/, '必须建 idx_tel_taskid 索引（旧版一个索引都没建，D12）')
  assert.match(logStore, /SqlCompat\.CreateIndexIfNotExists\("idx_tel_triggered", Table, "TriggeredAt"\);/, '必须建 idx_tel_triggered 索引')
  assert.match(logStore, /\$@"INSERT INTO \{Table\}/, '必须有插入语句（先落一条 running 记录，崩溃也留痕）')
  assert.match(logStore, /public static bool InsertStart\(TaskExecutionLog log\)/, '必须有"执行开始先落 running 记录"的入口（D26）')
  assert.match(logStore, /WHERE TaskId = @7 AND TriggeredAt = @8 AND Status = @9/, '结束时必须按 (TaskId, TriggeredAt, running) 更新同一条记录')
  assert.match(logStore, /SweepInterrupted\(\)/, '必须有启动收尾（把遗留 running 记录标成 interrupted）')

  // 表名唯一性：C# 侧所有 SQL 位置捕获到的标识符必须只有这两个
  //   if                  —— 来自 "CREATE TABLE IF NOT EXISTS" 里的 IF（不是表名）
  //   information_schema  —— MySQL 的系统视图（用于查索引是否已存在）
  // 其余表名一律走 {Table} 插值常量，所以这里不该出现别的库表名。
  const rows = await sources()
  const captured = new Set()
  for (const r of rows) {
    if (!r.file.startsWith('plugin/') || !r.file.endsWith('.cs')) continue
    for (const m of stripComment(r.text).matchAll(/\b(?:FROM|INTO|UPDATE|TABLE)\s+([A-Za-z_][A-Za-z0-9_]*)/gi)) {
      captured.add(m[1].toLowerCase())
    }
  }
  assert.deepEqual([...captured].sort(), ['if', 'information_schema'],
    `C# 侧 SQL 位置出现的表标识符只允许 if / information_schema，实际：${[...captured].join(', ')}\n`
    + '  出现别的表名说明有人硬编码了库表（本件只允许操作 task_execution_logs，且必须走 Table 常量）。')

  // CREATE TABLE 只允许出现在记录表这一处，且必须带 IF NOT EXISTS
  const createLines = rows.filter((r) => /CREATE\s+TABLE/i.test(stripComment(r.text)))
  assert.equal(createLines.length, 1, `CREATE TABLE 只允许出现一次，实际 ${createLines.length} 处：${createLines.map((r) => `${r.file}:${r.line}`).join('、')}`)
  assert.ok(createLines[0].file.endsWith('TaskSchedulerLogStore.cs'), '建表语句必须在 TaskSchedulerLogStore.cs 里')
  assert.match(stripComment(createLines[0].text), /CREATE TABLE IF NOT EXISTS \{Table\}/, '唯一的建表语句必须是幂等写法')

  // 反面：本件与游玩时长统计表毫无关系
  for (const forbidden of ['player_daily_stat', 'daily_min', 'hourly_online_snapshot']) {
    assert.equal(
      rows.some((r) => r.text.includes(forbidden)), false,
      `源码里出现了 "${forbidden}" —— 那是 online-stats 插件的表/字段，本件碰它就会造成双倍计时长或职责越界`,
    )
  }
})

test('★★ 不把 Commands.HandleCommand 的返回值当成功判据（它恒返回 true），改用 CanRun / AllowServer 预检 ★★', async () => {
  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')
  const code = codeOnly(engine)

  // ① 正面：执行前必须做三件事的分类
  assert.ok(code.includes('Commands.ChatCommands.FindAll(c => c.HasAlias(cmdName))'),
    '必须有"命令是否注册"的预检：Commands.ChatCommands.FindAll(c => c.HasAlias(cmdName))')
  // 说明：代码里是在已解析出的匹配命令集合上逐个判权限（`matches.Where(c => c.CanRun(tr)).ToList()`），
  // 所以这里断言 .CanRun(tr) —— 它才是"执行前分类"的第 2 步（第 1 步是 HasAlias 找注册命令）。
  // （方法注释里那行 `cmd.CanRun(tr)` 是文档，代码里不出现，故不能拿它当判据。）
  assert.ok(code.includes('.CanRun(tr)'),
    '必须有"权限是否足够"的预检：cmd.CanRun(tr)（代码里的形态是 matches.Where(c => c.CanRun(tr)).ToList()）')
  assert.ok(code.includes('var runnable = matches.Where(c => c.CanRun(tr)).ToList();'),
    '权限预检必须把"能跑的命令"单独收敛成一份集合（runnable.Count == 0 就是 permission_denied）')
  assert.ok(code.includes('c.AllowServer || tr.RealPlayer'),
    '必须有"是否仅游戏内"的预检：c.AllowServer（AllowServer=false 且执行者不是真实玩家时 TShock 一定拒绝）')
  assert.ok(code.includes('permission_denied') && code.includes('unknown_command') && code.includes('not_applicable'),
    '三类结论必须各有机器可读分类（unknown_command / permission_denied / not_applicable）')
  assert.ok(code.includes('Commands.HandleCommand(tr, normalized);'),
    '分类之后仍然要真的调用 HandleCommand（把 TShock 的原始回显抓进 output 作为证据）')

  // ② 反面（核心）：RunOnMainThread 是唯一调用 HandleCommand 的地方，
  //    它**不允许**出现任何"无条件成功"的赋值——旧版正是在这里忽略返回值、无条件 result.Success = true。
  const runStart = engine.indexOf('private static void RunOnMainThread(')
  const runEnd = engine.indexOf('private static bool ClassifyFromOutput(')
  assert.ok(runStart >= 0 && runEnd > runStart, '找不到 RunOnMainThread 方法体（扫描边界失效）')
  const runBody = engine.slice(runStart, runEnd)
  assert.ok(runBody.includes('Commands.HandleCommand('), 'HandleCommand 的调用必须在 RunOnMainThread 里（投递到主线程执行）')
  assert.doesNotMatch(
    codeOnly(runBody), /\.Success\s*=\s*true/,
    'RunOnMainThread 里出现了 .Success = true —— 这就是旧版缺陷（HandleCommand 恒返回 true，'
    + '把未注册命令与仅游戏内命令全记成"成功"）。结论必须由执行前的分类给出。',
  )

  // ③ 反面（逐调用点）：任何一个 HandleCommand 调用之后，紧邻的若干字符里都不许出现无条件成功赋值
  for (const m of code.matchAll(/Commands\.HandleCommand\(/g)) {
    const after = code.slice(m.index, m.index + 300)
    assert.doesNotMatch(
      after, /\.Success\s*=\s*true/,
      `HandleCommand 调用之后 300 字符内出现了 .Success = true：\n${after.split(/\r?\n/).slice(0, 6).join('\n')}\n`
      + '  HandleCommand 在任何路径都返回 true（TShock 源码 Commands.cs:715-732 三条分支统一 return true），'
      + '所以它的返回值不可用；成功与否必须由 CanRun / AllowServer 预检与输出二次校验决定。',
    )
  }

  // ④ 注释里必须写明"HandleCommand 恒返回 true"这条事实（防止后来者又改回去）
  assert.match(engine, /任何路径都返回 true/, '源码注释必须写明 HandleCommand 在任何路径都返回 true（这条事实是分类预检的存在理由）')

  // ⑤ 只降不升的二次校验必须存在，且"提升"的方向不存在
  assert.match(code, /ClassifyFromOutput\(result\.Output, out var kind, out var text\)/, '必须有输出二次校验（兜住"预检通过但 TShock 仍然拒绝"）')
  for (const s of ['You must use this command in-game', 'You do not have access to this command', 'Invalid command entered']) {
    assert.ok(code.includes(s), `二次校验必须识别 TShock 的拒绝文案：${s}`)
  }
  // 单条命令的三种结论文案
  for (const [s, why] of [['"成功"', '成功'], ['"失败"', '失败'], ['"不适用"', '仅游戏内命令']]) {
    assert.ok(code.includes(s), `单条命令结果必须有 ${why} 的文案 ${s}`)
  }
  // 并发模式下拿不到结果时必须如实记失败，绝不静默丢弃
  assert.ok(code.includes('no_result'), '并发模式必须为"拿不到结果"的条目留兜底分类 no_result（绝不静默丢弃）')
  assert.match(code, /Success = false,/, '兜底条目必须记 Success = false')
})

test('boss_defeated 读图鉴击杀数：Main.BestiaryTracker.Kills.GetKillCount（宿主进程读不到）', async () => {
  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')
  assert.ok(
    engine.includes('Main.BestiaryTracker.Kills.GetKillCount('),
    'boss_defeated 必须读图鉴击杀数 Main.BestiaryTracker.Kills.GetKillCount(...)'
    + '（宿主进程读不到这份数据，这正是本件必须落在游戏服半的原因之一）',
  )
  assert.ok(engine.includes('ContentSamples.NpcBestiaryCreditIdsByNpcNetIds['),
    '图鉴击杀数必须按 ContentSamples.NpcBestiaryCreditIdsByNpcNetIds 映射后再取（不是直接拿 NPCID 当图鉴 id）')
  // 形态必须包在 try/catch 里：读不到数据一律返回 0，绝不让 tick 反复炸
  const start = engine.indexOf('private static int GetKillCount(')
  const end = engine.indexOf('// ═══', start)
  assert.ok(start >= 0 && end > start, '找不到 GetKillCount 方法体（扫描边界失效）')
  const body = engine.slice(start, end)
  assert.match(body, /catch\s*\{[\s\S]*return 0;/, 'GetKillCount 必须吞掉异常并返回 0（条件求值绝不能因为读不到数据而抛，否则 tick 会反复炸）')
  assert.ok(engine.includes('宿主进程读不到'), '注释必须写明"宿主进程读不到图鉴数据"这条设计理由')
  // 名字不认识 / 空列表都必须 false（旧版行为）
  const areStart = engine.indexOf('private static bool AreBossesDefeated(')
  const areEnd = engine.indexOf('private static bool ArePlayersOnline(')
  const areBody = engine.slice(areStart, areEnd)
  assert.match(areBody, /if \(p\.BossNames == null \|\| p\.BossNames\.Count == 0\)\s*\r?\n\s*return false;/, '空 BOSS 列表必须 false')
  assert.match(areBody, /if \(!BossNpcIds\.TryGetValue\(name, out var npcId\)\)\s*\r?\n\s*return false;/, '名字不认识必须 false')
  assert.match(areBody, /if \(GetKillCount\(npcId\) <= 0\)\s*\r?\n\s*return false;/, '击杀数为 0 必须 false（全部被击败才通过）')
})

test('并发模式：每条命令一个 Task.Run + Task.WaitAll（结果不丢）', async () => {
  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')
  const code = codeOnly(engine)
  assert.ok(code.includes('task.ExecMode == "concurrent"'), '必须按 ExecMode 区分顺序 / 并发两种执行方式')
  assert.match(code, /\.Select\(\(cmd, i\) => Task\.Run\(\(\) => ExecuteSingleCommand\(cmd, i, task\.Name\)\)\)/,
    '并发模式必须每条命令一个 Task（旧版 :399-405 的语义）')
  assert.ok(code.includes('Task.WaitAll(results)'), '并发模式必须用 Task.WaitAll 收敛结果')
  // WaitAll 必须包在 try/catch 里（任一条命令抛出未捕获异常时，已跑完的结果不能全丢，D19）
  const waitIdx = code.indexOf('Task.WaitAll(results)')
  const around = code.slice(Math.max(0, waitIdx - 200), waitIdx + 200)
  assert.match(around, /try\s*\{/, 'Task.WaitAll 必须包在 try/catch 里（否则一条命令抛异常会让已跑完的结果全部丢失，D19）')
  // 顺序模式：逐条执行
  assert.match(code, /for \(int i = 0; i < task\.Commands\.Count; i\+\+\)\s*\r?\n\s*log\.Commands\.Add\(ExecuteSingleCommand\(task\.Commands\[i\], i, task\.Name\)\);/, '顺序模式必须逐条执行并收集结果')
  // 整体结论按真实结果判定（D5）：任一条不成功则整体 failed
  assert.match(code, /log\.Status = bad\.Count > 0 \? "failed" : "success";/, '整体状态必须由每条命令的真实结果决定（旧版无条件 success=true）')
})

test('Thread.Sleep 只出现在 wait 分支（主线程等待用事件，绝不阻塞主线程）', async () => {
  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')
  const engineCode = codeOnly(engine)
  const sleeps = [...engineCode.matchAll(/Thread\.Sleep/g)]
  assert.equal(
    sleeps.length, 1,
    `TaskSchedulerEngine 的代码里 Thread.Sleep 必须恰好出现 1 次（wait 分支），实际 ${sleeps.length} 次：\n`
    + engineCode.split(/\r?\n/).filter((l) => l.includes('Thread.Sleep')).join('\n'),
  )
  // 那一次必须在 wait 分支内部。
  // 注意：分支的**结束边界**是行注释 `// (C) 执行前分类`，它会被 codeOnly 抹掉，
  // 所以边界必须在**原文**上取，而计数在**去注释版**上做（两边各取所长）。
  const branchStart = engine.indexOf('var match = WaitRegex.Match(')
  const branchEnd = engine.indexOf('// (C) 执行前分类')
  assert.ok(branchStart >= 0 && branchEnd > branchStart, '找不到 wait 分支的边界（扫描失效）')
  const waitBranch = codeOnly(engine.slice(branchStart, branchEnd))
  assert.match(waitBranch, /if \(ms > 0\) Thread\.Sleep\(ms\);/, 'wait 分支必须按解析出的毫秒数休眠（且 0 毫秒不休眠）')
  assert.equal((codeOnly(engine.slice(0, branchStart)).match(/Thread\.Sleep/g) || []).length, 0, 'wait 分支之前不得有 Thread.Sleep')
  assert.equal((codeOnly(engine.slice(branchEnd)).match(/Thread\.Sleep/g) || []).length, 0, 'wait 分支之后不得有 Thread.Sleep')

  // 主线程投递器用事件等待，不睡眠、也不在主线程上跑命令
  const dispatcher = codeOnly(await readSrc('plugin/TaskSchedulerDispatcher.cs'))
  assert.equal(dispatcher.includes('Thread.Sleep'), false, 'MainThreadDispatcher 不得出现 Thread.Sleep（它必须用事件等待）')
  assert.ok(dispatcher.includes('ManualResetEventSlim'), 'MainThreadDispatcher 必须用 ManualResetEventSlim 等待动作完成')
  assert.match(dispatcher, /if \(!done\.Wait\(timeoutMs\)\)/, 'Post 必须带超时等待')
  assert.match(dispatcher, /public static void Drain\(\)/, '必须有主线程侧的 Drain（由 GameUpdate 每 tick 排空）')
  const engine2 = codeOnly(engine)
  assert.match(engine2, /ServerApi\.Hooks\.GameUpdate\.Register\(_plugin, OnGameUpdate\);/, '必须挂 GameUpdate 钩子（主线程排空的入口）')
  assert.match(engine2, /ServerApi\.Hooks\.GamePostInitialize\.Register\(_plugin, OnGamePostInitialize\);/, '必须挂 GamePostInitialize（世界就绪的门，D21）')
  assert.match(engine2, /if \(!MainThreadDispatcher\.Ready\) return;/, '世界未就绪时整轮 tick 必须跳过（D21：世界没加载完不许跑命令）')
})

test('BOSS 名称表：18 项、逐项 NPCID 映射、顺序与源码一致', async () => {
  const engine = await readSrc('plugin/TaskSchedulerEngine.cs')
  assert.equal(BOSS_ENTRIES.length, 18, 'BOSS 名称表必须是 18 项（与旧版 TaskScheduler.cs:139-159 一致）')

  const dictStart = engine.indexOf('private static readonly Dictionary<string, int> BossNpcIds = new()')
  const dictEnd = engine.indexOf('};', dictStart)
  assert.ok(dictStart >= 0 && dictEnd > dictStart, '找不到 BossNpcIds 字典（扫描边界失效）')
  const dict = engine.slice(dictStart, dictEnd)
  const entryCount = (dict.match(/NPCID\./g) || []).length
  assert.equal(entryCount, 18, `BossNpcIds 必须恰好 18 项，实际 ${entryCount} 项`)

  let cursor = -1
  for (const [name, npcId] of BOSS_ENTRIES) {
    const literal = `{ "${name}", NPCID.${npcId} },`
    const idx = dict.indexOf(literal)
    assert.ok(idx >= 0, `BOSS 名称表缺少或写错了这一项：${literal}（boss_defeated 条件会认不出这个 BOSS）`)
    assert.ok(idx > cursor, `BOSS 名称顺序与约定的顺序不一致：${literal} 出现在前一项之前（这张表会整份回显给宿主，顺序变动需复核）`)
    cursor = idx
  }
})

test('REST 路由 11 条与权限名：注册清单与分派 switch 必须一一对应', async () => {
  const plugin = await readSrc('plugin/TaskSchedulerPlugin.cs')
  assert.ok(plugin.includes('new SecureRestCommand(route, Dispatch(route), "data.rest.invsee")'),
    '必须用 SecureRestCommand 注册，权限名与其他 data.* 端点一致（data.rest.invsee）')
  assert.match(plugin, /private static readonly string\[\] OwnRoutes =/, '必须有 OwnRoutes 路由清单')
  assert.match(plugin, /new HashSet<string>\(OwnRoutes, StringComparer\.OrdinalIgnoreCase\)/,
    '卸载时必须按同一份清单反注册（注册与反注册共用一个来源，避免"注册了但没反注册"的漏项）')
  assert.equal(OWN_ROUTES.length, 11, '本件注册 11 条路由（旧版 7 条 + 别名 2 条 + 新增协议 2 条）')
  for (const route of OWN_ROUTES) {
    const quoted = new RegExp(`"${route.replace(/\//g, '\\/')}"`, 'g')
    const hits = (plugin.match(quoted) || []).length
    assert.ok(hits >= 2,
      `路由 ${route} 在 TaskSchedulerPlugin.cs 里只出现 ${hits} 次：`
      + '注册清单（OwnRoutes）与分派 switch（Dispatch）各需一处，'
      + '少于两次说明"注册了但没有分派"或"分派了但没注册"。')
  }
  // 别名的两条必须映射到同一个实现（旧版契约用 log/log/detail，需求文字用 logs/logs/detail）
  assert.match(plugin, /"\/data\/tasks\/log" or "\/data\/tasks\/logs" => TaskSchedulerEndpoints\.LogList\(args\)/,
    'log 与 logs 必须是同一实现的两个别名')
  assert.match(plugin, /"\/data\/tasks\/log\/detail" or "\/data\/tasks\/logs\/detail" => TaskSchedulerEndpoints\.LogDetail\(args\)/,
    'log/detail 与 logs/detail 必须是同一实现的两个别名')
  // 端点的失败返回值必须是真实 HTTP 状态（匿名对象一律以 200 返回，调用方看不出失败）
  const endpoints = await readSrc('plugin/TaskSchedulerEndpoints.cs')
  assert.match(endpoints, /new RestObject\(status\.ToString\(CultureInfo\.InvariantCulture\)\)/,
    '失败回包必须是 RestObject（匿名对象会被 TShock 一律以 HTTP 200 返回，"任务不存在"与"成功"在 HTTP 层长得一样）')
  assert.match(endpoints, /private static RestObject Fail\(int status, string error/, '失败回包必须走统一的 Fail 构造器')
  assert.match(endpoints, /private static RestObject Ok\(/, '成功回包必须走统一的 Ok 构造器')
  assert.match(endpoints, /if \(current\.Version > 0 && version < current\.Version\)/, '必须拒绝更旧的配置载荷（并发/重试乱序到达时不许用旧配置覆盖新配置）')
  assert.match(endpoints, /if \(incoming\.Count == 0 && existing\.Count > 0 && !allowEmpty\)/, '必须拒绝非预期的空任务列表（D29 家族：配置被意外清空）')
})

test('配置与旧版迁移路径：task-scheduler-config.json + <SavePath>/TSWeb/Tasks/tasks.json', async () => {
  const model = await readSrc('plugin/TaskSchedulerModel.cs')
  assert.match(model, /Path\.Combine\(TShock\.SavePath, "task-scheduler-config\.json"\)/, '配置文件必须是 <SavePath>/task-scheduler-config.json')
  assert.match(model, /Path\.Combine\(TShock\.SavePath, "TSWeb", "Tasks", "tasks\.json"\)/, '旧版迁移路径必须是 <SavePath>/TSWeb/Tasks/tasks.json（旧版 TaskScheduler.cs:132）')
  assert.match(model, /public static string LegacyFilePathAlt => Path\.Combine\(TShock\.SavePath, "tasks\.json"\);/, '另一个候选旧路径必须是 <SavePath>/tasks.json')
  // 旧版文件**只读**：迁移时只读不写，判断错了还能人工回退
  assert.match(model, /foreach \(var path in new\[\] \{ LegacyFilePath, LegacyFilePathAlt \}\)/, '两个候选旧路径都要试')
  assert.match(model, /var json = File\.ReadAllText\(path\);\s*\r?\n\s*var parsed = JsonConvert\.DeserializeObject<TaskConfig>\(json\);/,
    '旧版文件只允许 ReadAllText + 反序列化（只读，绝不改动旧文件）')
  assert.match(model, /File\.WriteAllText\(tmp, json\);/, '本件自己的配置必须"先写临时文件再替换"（旧版直接写，掉电会得到半个文件）')
  assert.match(model, /File\.Move\(tmp, FilePath\);/,
    '临时文件必须原子替换目标（先写 .tmp 再 Move；直接覆盖写会在掉电时留下半个文件，下一次启动会按"解析失败"清空任务）')
  assert.match(model, /Directory\.CreateDirectory\(dir\)/, '写盘前必须确保目录存在（否则首次启动就落盘失败）')
  assert.match(model, /File\.Copy\(FilePath, FilePath \+ "\.bak", true\)/, '改动配置前必须留 .bak 备份（恢复手段）')
  assert.match(model, /BackupCorrupt\(FilePath\)/, '解析失败时必须把坏文件另存为 *.corrupt-<时间戳>（保留证据，不许静默丢弃用户的任务）')
  assert.match(model, /绝不[\s\S]{0,10}在读取失败后自动写盘/,
    '注释必须写明"读取失败后绝不自动写盘"这条保证（旧版解析失败把 Tasks 置空并继续，下一次保存就把文件覆盖成空，D29）')
})

test('中文注释存在（本仓约定：注释用中文，并写明与旧版的差异）', async () => {
  const rows = await sources()
  const docLines = rows.filter((r) => r.text.trim().startsWith('///') || r.text.trim().startsWith('//'))
  assert.ok(docLines.length >= 100, `中文注释行太少（${docLines.length} 行），本仓要求实现处写明理由`)
  const text = rows.map((r) => r.text).join('\n')
  assert.match(text, /[\u4e00-\u9fff]/, '源码里必须有中文（本仓约定：注释与文案用中文）')
  // 必须写明与旧版的关系（本件是旧版功能的插件化，差异必须逐条可查）
  assert.match(text, /旧版/, '注释里必须引用旧版实现位置（本件的语义逐条对照旧版）')
})

test('禁止 emoji：所有 .cs / .js / .mjs / .csproj / .json 源码里没有 emoji 码点', async () => {
  const rows = await sources()
  const bad = []
  for (const r of rows) {
    if (EMOJI_RE.test(r.text.replace(ALLOWED_GEOMETRY, ''))) {
      bad.push(`${r.file}:${r.line}  ${r.text.trim()}`)
    }
  }
  assert.deepEqual(bad, [], '源码里不得出现 emoji（本仓硬性约定）：\n' + bad.join('\n'))
})

test('emoji 扫描器有区分度：真正的 emoji 必被抓到，允许的几何符号不被误判', async () => {
  // 阳性对照：真正的 emoji 必须命中（用码点构造，文件里不出现 emoji 字符本身）
  assert.equal(EMOJI_RE.test(String.fromCodePoint(0x1F600)), true, 'emoji 正则抓不到真正的 emoji（U+1F600）——扫描无效')
  assert.equal(EMOJI_RE.test(String.fromCodePoint(0x1F4A1)), true, 'emoji 正则抓不到 U+1F4A1——扫描无效')
  // 阴性对照：允许的几何符号（摘掉之后）不得命中
  const allowed = '✕ ＋ − — ⠿ ▶ ★'
  assert.equal(EMOJI_RE.test(allowed), true, '先把允许符号串整串喂进去必须命中（否则下面的"摘掉后不命中"没有意义）')
  assert.equal(EMOJI_RE.test(allowed.replace(ALLOWED_GEOMETRY, '')), false, '允许的几何符号摘掉后不得命中')
  // 这些允许符号必须是**真实存在**的（说明 ALLOWED 不是空转、也不是为了绕过扫描而加的）
  const rows = await sources()
  const text = rows.map((r) => r.text).join('\n')
  for (const ch of ['★', '✕', '＋', '⠿']) {
    assert.ok(text.includes(ch), `源码里必须真的存在既有文案字符 "${ch}"（ALLOWED 白名单不是空转）`)
  }
})

test('阴性对照：没有别的插件的表与方法（player_daily_stat / daily_min / 整点快照 / 其它插件命名空间）', async () => {
  const rows = await sources()
  const forbidden = [
    [/player_daily_stat/, 'player_daily_stat（online-stats 的游玩时长表）'],
    [/daily_min/, 'daily_min（online-stats 的时长字段）'],
    [/INSERT\s+INTO\s+player_daily_stat/i, 'INSERT INTO player_daily_stat（会造成双倍计时长）'],
    [/daily_min\s*\+\s*1/, 'daily_min + 1（时长自增片段）'],
    [/hourly_online_snapshot/, 'hourly_online_snapshot（online-stats 的整点快照职责）'],
    [/UpdatePlayerDailyMin/, 'UpdatePlayerDailyMin（online-stats 的方法）'],
    [/EnsureHourlyRecord/, 'EnsureHourlyRecord（online-stats 的方法）'],
    [/SnapshotHourlyOnline/, 'SnapshotHourlyOnline（online-stats 的方法）'],
    [/promotion-config\.json/, 'promotion 插件的配置文件名'],
    [/qqbind-snapshot\.json/, 'qq-bind 插件只读的快照文件名'],
    [/TsWebQqBind|TsWebPromotion/, '其它插件的程序集命名空间（不该有跨插件耦合）'],
  ]
  const violations = []
  for (const r of rows) {
    // 注释里也不许出现：本件与这些表/插件毫无关系，出现即说明是从别的插件复制粘贴来的
    for (const [re, label] of forbidden) {
      if (re.test(r.text)) violations.push(`${r.file}:${r.line} [${label}] ${r.text.trim()}`)
    }
  }
  assert.deepEqual(
    violations, [],
    '本件不得碰别的插件的表/方法，也不得与别的插件有命名空间耦合：\n' + violations.join('\n'),
  )
  // 反过来：本件自己的表名与身份必须存在（否则上面的"扫不到"可能是"扫错了文件"）
  const text = rows.map((r) => r.text).join('\n')
  assert.ok(text.includes('task_execution_logs'), '本件的执行记录表名必须存在')
  assert.ok(text.includes('task-scheduler-config.json'), '本件的配置文件名必须存在')
})
