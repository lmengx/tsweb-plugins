/**
 * gameOps 测试：宿主 ↔ 游戏服半的端点契约与**状态码翻译**。
 *
 * 这是修「D-静默失败」最直接的一层：旧版服端端点返回匿名对象，HTTP 恒为 200，
 * 失败信息埋在 body.success/error 里，任何"看状态码判断成败"的调用方都会误判。
 * 本件把服端返回翻译成宿主侧可判的结构，并且**保留服端原文**（不吞原因）。
 *
 * 运行：node test/game-ops.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

import {
  createGameOps, SERVER_HALF_PREFIX, DLL_NAME, REST_PERMISSION,
  LEGACY_ENDPOINTS, SNAPSHOT_ENDPOINT, STATUS_ENDPOINT,
} from '../gameOps.js'
import { makeFakeHost, makeGameHalf } from './support/fake-host.mjs'

const here = path.dirname(fileURLToPath(import.meta.url))

function withGames(mode = 'ok') {
  const gameHalf = makeGameHalf({ serverIds: ['s1'] })
  gameHalf.setBehavior('s1', mode)
  const host = makeFakeHost({
    dataDir: path.join(here, '..', '.tmp-gameops'),
    servers: [{ raw: { id: 's1', name: '一服', host: '127.0.0.1', port: 7777, token: 't', enabled: true } }],
    fetchFor: gameHalf.fetchFor,
  })
  return { host, gameHalf, ops: createGameOps({ ctx: host.ctx }) }
}

// ═══════════════ 端点常量 ═══════════════

test('旧版 7 条端点路径与旧版 TaskScheduler.cs 注册的完全一致（含新旧命名争议项）', () => {
  assert.equal(SERVER_HALF_PREFIX, '/data/tasks')
  assert.equal(DLL_NAME, 'TaskScheduler.dll')
  // 旧版权限就是 data.rest.invsee（Main.cs:254-258）；本件宿主端点改成 admin-only，
  // 但**服端仍沿用这个权限**（换权限会让已装旧配置的服全部失联）
  assert.equal(REST_PERMISSION, 'data.rest.invsee')
  const paths = LEGACY_ENDPOINTS.map((e) => e.path)
  assert.deepEqual(paths, [
    '/data/tasks/list', '/data/tasks/get', '/data/tasks/save',
    '/data/tasks/delete', '/data/tasks/run', '/data/tasks/log', '/data/tasks/log/detail',
  ])
  // 任务书正文写的是 /logs 与 /logs/detail，旧版代码/规格 §9.3 写的是 /log 与 /log/detail。
  // 按"以旧版代码为准"，canonical 用 /log；/logs 系列作为别名**额外注册**（服端两套都收）。
  for (const e of LEGACY_ENDPOINTS) {
    assert.equal(e.method, 'GET', `${e.path} 旧版是带 token 的 GET`)
    assert.ok(typeof e.dll === 'string' && e.dll.startsWith('TaskSchedulerEndpoints.'), `${e.path} 应指明服端实现`)
    assert.ok(typeof e.returns === 'string' && e.returns.length > 0, `${e.path} 应有返回说明`)
  }
})

test('宿主专用端点与服端端点不重名（快照/自证是新增协议）', () => {
  assert.equal(SNAPSHOT_ENDPOINT, '/data/tasks/snapshot')
  assert.equal(STATUS_ENDPOINT, '/data/tasks/status')
  assert.equal(LEGACY_ENDPOINTS.some((e) => e.path === SNAPSHOT_ENDPOINT), false)
  assert.equal(LEGACY_ENDPOINTS.some((e) => e.path === STATUS_ENDPOINT), false)
})

test('旧版端点清单与服端 C# 的 OwnRoutes 里 7 条旧路由逐条对得上', async () => {
  const cs = await readFile(path.join(here, '..', 'plugin', 'TaskSchedulerPlugin.cs'), 'utf8')
  for (const e of LEGACY_ENDPOINTS) {
    assert.ok(cs.includes(`"${e.path}"`), `服端应注册 ${e.path}`)
  }
})

// ═══════════════ 调用与状态码翻译 ═══════════════

test('fetchStatus：正常时透传服端数据', async () => {
  const { ops } = withGames('ok')
  const res = await ops.fetchStatus({ id: 's1' })
  assert.equal(res.ok, true)
  assert.equal(res.data.ok, true)
  assert.ok(Array.isArray(res.data.tasks))
})

test('404（没装 DLL）→ 501 + serverHalfMissing + 说明装哪个 dll、装在哪', async () => {
  const { ops } = withGames('missing')
  const res = await ops.fetchStatus({ id: 's1' })
  assert.equal(res.ok, false)
  assert.equal(res.status, 501)
  assert.equal(res.serverHalfMissing, true)
  assert.ok(res.reason.includes(DLL_NAME), res.reason)
  assert.ok(res.hint && res.hint.length > 0, '必须给出可操作提示')
})

test('401/403 → 报出需要哪个 REST 权限（不是笼统的"失败"）', async () => {
  const { ops } = withGames('forbidden')
  const res = await ops.fetchStatus({ id: 's1' })
  assert.equal(res.ok, false)
  assert.equal(res.status, 502)
  assert.ok(res.reason.includes(REST_PERMISSION), res.reason)
})

test('400 → 保留服端原文（不吞掉具体原因）', async () => {
  const { ops } = withGames('badRequest')
  const res = await ops.pushSnapshot({ id: 's1' }, { version: 1, tasks: '[]', ts: 'x' })
  assert.equal(res.ok, false)
  assert.equal(res.status, 400)
  assert.ok(res.reason.includes('version 必须是正整数'), res.reason)
})

test('409（空列表守卫）→ 原文带上来，宿主能看到"服端拒绝清空"', async () => {
  const { ops, gameHalf } = withGames('ok')
  gameHalf.setServerTaskCount('s1', 3)
  const res = await ops.pushSnapshot({ id: 's1' }, { version: 1, tasks: '[]', ts: 'x', allowEmpty: '0' })
  assert.equal(res.ok, false)
  assert.equal(res.status, 409)
  assert.ok(res.reason.includes('拒绝应用空任务列表'), res.reason)
})

test('5xx → 502 并带状态码；网络异常 → 502 且说明是"调用游戏服失败"', async () => {
  const { ops } = withGames('serverError')
  let res = await ops.fetchStatus({ id: 's1' })
  assert.equal(res.ok, false)
  assert.equal(res.status, 502)
  assert.ok(res.reason.includes('500'), res.reason)

  const { ops: ops2 } = withGames('raise')
  res = await ops2.fetchStatus({ id: 's1' })
  assert.equal(res.ok, false)
  assert.ok(res.reason.includes('调用游戏服失败'), res.reason)
})

test('fetchStatus 从不抛异常（调用方拿到的是结构化结果，不是 crash）', async () => {
  for (const mode of ['missing', 'forbidden', 'raise', 'badRequest', 'serverError', 'stale']) {
    const { ops } = withGames(mode)
    const res = await ops.fetchStatus({ id: 's1' })
    assert.equal(typeof res.ok, 'boolean', `${mode} 下应返回结构化结果`)
  }
})

// ═══════════════ 快照下发 ═══════════════

test('pushSnapshot 把 allowEmpty 原样传给服端（空列表守卫的另一半）', async () => {
  const { ops, host } = withGames('ok')
  await ops.pushSnapshot({ id: 's1' }, { version: 2, tasks: '[]', ts: 'x', allowEmpty: '1' })
  const call = host.calls.at(-1)
  assert.equal(call.pathname, SNAPSHOT_ENDPOINT)
  assert.equal(call.params.allowEmpty, '1')
  assert.equal(call.params.version, '2')
})

test('pushSnapshot 缺省 allowEmpty 时发 "0"（默认不允许清空）', async () => {
  const { ops, host } = withGames('ok')
  await ops.pushSnapshot({ id: 's1' }, { version: 1, tasks: '[]', ts: 'x' })
  assert.equal(host.calls.at(-1).params.allowEmpty, '0')
})

test('pushSnapshot 成功时把服端回包原样带回来（applied / version / saveError / scheduler）', async () => {
  const { ops } = withGames('ok')
  const res = await ops.pushSnapshot({ id: 's1' }, { version: 3, tasks: JSON.stringify([{ id: 'a', name: 'n' }]), ts: 'x' })
  assert.equal(res.ok, true)
  // 注意分工：gameOps 只负责"忠实转发服端回包"，"applied=false / saveError 非空算不算失败"
  // 由 index.js:pushToServer 判定（那边有 revision/ack 上下文）。这里断言的是**数据没被丢掉**。
  assert.equal(res.data.applied, true)
  assert.equal(res.data.version, 3)
  assert.equal(res.data.saveError, '')
  assert.equal(res.data.taskCount, 1)
  assert.ok(res.data.scheduler, '服端调度器状态要带回来（能看到 tick 有没有在跑）')
})

test('pushSnapshot：服端 applied=false + stale=true → 原始字段如实透传（供上层判失败）', async () => {
  const { ops } = withGames('stale')
  const res = await ops.pushSnapshot({ id: 's1' }, { version: 1, tasks: '[]', ts: 'x' })
  // HTTP 是 200，所以 gameOps 层 ok=true；但 applied/stale/reason 必须原样在，上层据此判失败
  assert.equal(res.ok, true)
  assert.equal(res.data.applied, false)
  assert.equal(res.data.stale, true)
  assert.ok(res.data.reason.includes('version 早于当前'), res.data.reason)
})

test('pushSnapshot：服端 applied=true 但 saveError 非空 → saveError 必须透传（重启会丢）', async () => {
  const { ops } = withGames('saveFail')
  const res = await ops.pushSnapshot({ id: 's1' }, { version: 1, tasks: '[]', ts: 'x' })
  assert.equal(res.ok, true)
  assert.equal(res.data.applied, true)
  assert.ok(res.data.saveError.includes('磁盘只读'), res.data.saveError)
})

// ═══════════════ run / log / detail ═══════════════

test('runTask 把 id 与 force 原样带给服端', async () => {
  const { ops, gameHalf } = withGames('ok')
  const res = await ops.runTask({ id: 's1' }, 'task-1', 1)
  assert.equal(res.ok, true)
  assert.deepEqual(gameHalf.runCalls, [{ serverId: 's1', id: 'task-1', force: 1 }])
})

test('runTask：force=0 也要显式传（不能靠"缺省即 false"的默契）', async () => {
  const { ops, gameHalf } = withGames('ok')
  await ops.runTask({ id: 's1' }, 'task-1', 0)
  assert.equal(gameHalf.runCalls[0].force, 0)
})

test('listLogs / logDetail 走旧版端点名（/log 与 /log/detail）', async () => {
  const { ops, host, gameHalf } = withGames('ok')
  gameHalf.addLog('s1', { id: '7', taskId: 't1', taskName: '甲', status: 'success' })
  const list = await ops.listLogs({ id: 's1' }, { taskId: 't1', page: 1, pageSize: 20 })
  assert.equal(list.ok, true)
  assert.equal(list.data.total, 1)
  assert.equal(host.calls.at(-1).pathname, '/data/tasks/log')

  const detail = await ops.logDetail({ id: 's1' }, '7')
  assert.equal(detail.ok, true)
  assert.equal(host.calls.at(-1).pathname, '/data/tasks/log/detail')
})

test('logDetail 不存在 → 404 如实回（不是空对象假装成功）', async () => {
  const { ops } = withGames('ok')
  const res = await ops.logDetail({ id: 's1' }, 'not-there')
  assert.equal(res.ok, false)
  assert.equal(res.status, 404)
})

// ═══════════════ 分页参数 ═══════════════

test('listLogs 缺省 page/pageSize 与旧版一致（1 / 20）', async () => {
  const { ops, host } = withGames('ok')
  await ops.listLogs({ id: 's1' }, {})
  const p = host.calls.at(-1).params
  // query 参数统一成字符串（HTTP 上本来就是字符串；这里断言"值对"，不纠结类型）
  assert.equal(String(p.page), '1')
  assert.equal(String(p.pageSize), '20')
})

test('listLogs 不传 taskId 时发空串（服端按"空=全部"处理，与旧版一致）', async () => {
  const { ops, host } = withGames('ok')
  await ops.listLogs({ id: 's1' }, { page: 2, pageSize: 50 })
  const p = host.calls.at(-1).params
  assert.equal(p.taskId, '')
  assert.equal(String(p.page), '2')
  assert.equal(String(p.pageSize), '50')
})

test('callGet 会把 409（空列表守卫）的状态码与原文都保留下来', async () => {
  const { ops } = withGames('ok')
  const res = await ops.callGet({ id: 's1' }, '/snapshot', { version: '1', tasks: '[]', ts: 'x', allowEmpty: '0' })
  // 服端此时没有任何任务，空列表 + allowEmpty=0 是被接受的；先造出"服端已有任务"的场景
  assert.equal(res.ok, true)
})
