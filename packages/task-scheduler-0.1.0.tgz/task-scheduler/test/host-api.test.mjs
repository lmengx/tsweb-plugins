/**
 * 宿主 REST 端点测试（列表 / 详情 / 分页 / 鉴权接线 / 配置损坏降级 / 载荷上限）
 *
 * 与 push.test.mjs 的分工：那边测**下发链路**，这边测**宿主自身**的接口语义与边界。
 *
 * 特别是接口形状必须与旧前端 tasksApi.js 的调用形态对得上：
 *   getTasks() → GET  /tasks/list     （不含 commands，含 commandCount 与运行期状态）
 *   getTask(id) → GET /tasks/get      （含 commands，编辑表单要用）
 *   saveTask(t) → POST /tasks/save
 *   deleteTask(id) → POST /tasks/delete
 *   runTask(id) → POST /tasks/run
 *   getLogs(params) → GET /tasks/log  （旧版固定 page=1&pageSize=20）
 *
 * 运行：node test/host-api.test.mjs
 */
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, writeFile, mkdir, readFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { apply } from '../index.js'
import { makeFakeHost, makeGameHalf, makeTask, waitFor } from './support/fake-host.mjs'

const SERVERS = [
  { raw: { id: 's1', name: '一服', host: '127.0.0.1', port: 7777, token: 't1', enabled: true } },
  { raw: { id: 's2', name: '二服', host: '127.0.0.1', port: 7778, token: 't2', enabled: true } },
]
const FAST = { retryBaseMs: 5, retryMaxMs: 40, reconcileMs: 100000 }

let dir
let seq = 0

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), 'tasks-api-'))
})

after(async () => {
  await rm(dir, { recursive: true, force: true })
})

async function boot({ servers = SERVERS } = {}) {
  seq += 1
  const dataDir = path.join(dir, `case-${seq}`)
  const gameHalf = makeGameHalf({ serverIds: servers.map((s) => s.raw.id) })
  const host = makeFakeHost({ dataDir, servers, fetchFor: gameHalf.fetchFor })
  const dispose = await apply(host.ctx, { push: FAST })
  return { dataDir, host, gameHalf, dispose }
}

const H = (id) => ({ 'x-server-id': id })

async function create(host, patch = {}, serverId = 's1') {
  const task = { ...makeTask(patch) }
  delete task.id
  const res = await host.call('post', '/api/task-scheduler/tasks/save', { headers: H(serverId), body: { task } })
  return res
}

// ═══════════════ 列表 ═══════════════

test('list：返回界面需要的全部元信息（warnings / dllName / legacyEndpoints / configFile）', async () => {
  const { host, dispose } = await boot()
  try {
    const res = await host.call('get', '/api/task-scheduler/tasks/list', { headers: H('s1') })
    assert.equal(res.status, 200)
    const d = res.data
    assert.equal(d.ok, true)
    assert.equal(d.serverId, 's1')
    assert.equal(d.serverName, '一服')
    assert.ok(Array.isArray(d.tasks))
    assert.ok(Array.isArray(d.warnings))
    assert.equal(typeof d.configFile, 'string')
    assert.equal(d.dllName, 'TaskScheduler.dll')
    assert.ok(Array.isArray(d.legacyEndpoints) && d.legacyEndpoints.length === 7)
    assert.equal(d.storeError, '')
  } finally {
    dispose()
  }
})

test('list：任务项字段与旧版 /list 对齐（不含 commands，含 commandCount）', async () => {
  const { host, dispose } = await boot()
  try {
    await create(host, { name: '甲', commands: ['/bc a', '/bc b'] })
    const d = (await host.call('get', '/api/task-scheduler/tasks/list', { headers: H('s1') })).data
    assert.equal(d.tasks.length, 1)
    const t = d.tasks[0]
    for (const k of ['id', 'name', 'enabled', 'triggerMode', 'intervalSeconds', 'dailyTime',
      'condition', 'execMode', 'commandCount', 'lastRunAt', 'lastRunStatus', 'runCount', 'running']) {
      assert.ok(k in t, `列表项应含 ${k}`)
    }
    assert.equal(t.commandCount, 2)
    // 旧版 /list 明确不返回 commands（TaskScheduler.cs:604-631），要编辑必须再调 /get
    const raw = JSON.stringify(d.tasks)
    assert.equal(raw.includes('"commands"'), false, 'list 不应返回 commands（与旧版一致）')
  } finally {
    dispose()
  }
})

test('list：宿主有任务、服端没有 → presentOnServer=false 且 running=false（而非假装在跑）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await create(host, { name: '甲' })
    // 模拟服端后来被重装/清空
    gameHalf.applied.set('s1', { version: 99, tasks: [] })
    const d = (await host.call('get', '/api/task-scheduler/tasks/list', { headers: H('s1') })).data
    assert.equal(d.tasks[0].presentOnServer, false)
    assert.equal(d.tasks[0].running, false)
    assert.equal(d.tasks[0].runtimeAvailable, true, '服端可读 → 运行期信息可用（只是没有这个任务）')
  } finally {
    dispose()
  }
})

test('list：服端读不到运行期状态 → runtimeError 如实回显，且不把任务说成"未执行"', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    await create(host, { name: '甲' })
    gameHalf.setBehavior('s1', 'missing')
    const d = (await host.call('get', '/api/task-scheduler/tasks/list', { headers: H('s1') })).data
    assert.ok(d.runtimeError, '必须说明读不到运行期状态')
    assert.ok(d.runtimeError.includes('TaskScheduler.dll'), d.runtimeError)
    assert.equal(d.tasks[0].runtimeAvailable, false)
    assert.equal(d.tasks[0].presentOnServer, false)
  } finally {
    dispose()
  }
})

test('list：把软警告带上来（间隔为 0 这类"看起来配好了其实永不触发"的配置）', async () => {
  const { host, dispose } = await boot()
  try {
    await create(host, { name: '永不触发', triggerMode: 'interval', intervalSeconds: 0, commands: ['/bc x'] })
    const d = (await host.call('get', '/api/task-scheduler/tasks/list', { headers: H('s1') })).data
    assert.ok(d.warnings.length >= 1, JSON.stringify(d.warnings))
    assert.equal(d.warnings[0].taskName, '永不触发')
    assert.ok(d.warnings[0].warning.includes('永远'))
  } finally {
    dispose()
  }
})

test('list：未指定 x-server-id 时回落到第一台服务器（旧版后端同样是"当前服务器"语义）', async () => {
  const { host, dispose } = await boot()
  try {
    const d = (await host.call('get', '/api/task-scheduler/tasks/list')).data
    assert.equal(d.serverId, 's1')
  } finally {
    dispose()
  }
})

test('list：x-server-id 指向不存在的服务器 → 404（不静默当成第一台）', async () => {
  const { host, dispose } = await boot()
  try {
    const res = await host.call('get', '/api/task-scheduler/tasks/list', { headers: H('nope') })
    assert.equal(res.status, 404)
    assert.equal(res.data.ok, false)
    assert.ok(res.data.error.includes('不存在'), res.data.error)
  } finally {
    dispose()
  }
})

test('list：一台服务器都没有 → 400 且说明原因', async () => {
  const { host, dispose } = await boot({ servers: [] })
  try {
    const res = await host.call('get', '/api/task-scheduler/tasks/list')
    assert.equal(res.status, 400)
    assert.ok(res.data.error.includes('尚未配置'), res.data.error)
  } finally {
    dispose()
  }
})

// ═══════════════ 详情 ═══════════════

test('get：返回含 commands 的完整定义（编辑表单要用）', async () => {
  const { host, dispose } = await boot()
  try {
    const made = await create(host, { name: '甲', commands: ['/bc a', '^wait 5', '/bc b'] })
    const d = (await host.call('get', '/api/task-scheduler/tasks/get', {
      headers: H('s1'), query: { id: made.data.id },
    })).data
    assert.ok(d.task)
    assert.deepEqual(d.task.commands, ['/bc a', '^wait 5', '/bc b'])
    assert.equal(d.task.id, made.data.id)
  } finally {
    dispose()
  }
})

test('get：缺 id → 400；id 不存在 → 404（都不是空对象）', async () => {
  const { host, dispose } = await boot()
  try {
    let res = await host.call('get', '/api/task-scheduler/tasks/get', { headers: H('s1') })
    assert.equal(res.status, 400)
    assert.ok(res.data.error.includes('id'), res.data.error)

    res = await host.call('get', '/api/task-scheduler/tasks/get', { headers: H('s1'), query: { id: 'nope' } })
    assert.equal(res.status, 404)
  } finally {
    dispose()
  }
})

// ═══════════════ 执行记录分页 ═══════════════

test('log：默认 page=1 / pageSize=20（与旧版界面一致），并回显分页字段', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    for (let i = 0; i < 25; i++) {
      gameHalf.addLog('s1', { id: String(i + 1), taskId: 'T', taskName: '甲', status: 'success', triggeredAt: `2026-01-01 00:00:${String(i).padStart(2, '0')}` })
    }
    const d = (await host.call('get', '/api/task-scheduler/tasks/log', { headers: H('s1') })).data
    assert.equal(d.total, 25)
    assert.equal(d.page, 1)
    assert.equal(d.pageSize, 20)
    assert.equal(d.logs.length, 20)
  } finally {
    dispose()
  }
})

test('log：翻页真的接通（旧版固定 page=1，规格 D10 指出的缺陷）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    for (let i = 0; i < 25; i++) gameHalf.addLog('s1', { id: String(i + 1), taskId: 'T', status: 'success' })
    const d = (await host.call('get', '/api/task-scheduler/tasks/log', {
      headers: H('s1'), query: { page: 2, pageSize: 20 },
    })).data
    assert.equal(d.page, 2)
    assert.equal(d.logs.length, 5, '第二页应当只剩 5 条')
    assert.equal(d.logs[0].id, '21')
  } finally {
    dispose()
  }
})

test('log：pageSize 上限 200（防止一次把整表拉爆），下界 1', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.addLog('s1', { id: '1', taskId: 'T', status: 'success' })
    let d = (await host.call('get', '/api/task-scheduler/tasks/log', {
      headers: H('s1'), query: { pageSize: 99999 },
    })).data
    assert.equal(d.pageSize, 200)

    d = (await host.call('get', '/api/task-scheduler/tasks/log', {
      headers: H('s1'), query: { pageSize: 0 },
    })).data
    assert.equal(d.pageSize, 20, '0 视为未指定 → 默认 20')

    d = (await host.call('get', '/api/task-scheduler/tasks/log', {
      headers: H('s1'), query: { pageSize: -5, page: -3 },
    })).data
    assert.equal(d.page, 1)
    // 负数被钳到**下界 1**（与"下界 1"的约定一致）；0 则视为"未指定"回落 20。
    // 两者都不是错误输入，只要行为明确即可。
    assert.equal(d.pageSize, 1)
  } finally {
    dispose()
  }
})

test('log：pageSize 非法字符串不炸，回落 20（旧版服端同样回落 20）', async () => {
  const { host, dispose } = await boot()
  try {
    const d = (await host.call('get', '/api/task-scheduler/tasks/log', {
      headers: H('s1'), query: { pageSize: 'abc', page: 'xyz' },
    })).data
    assert.equal(d.page, 1)
    assert.equal(d.pageSize, 20)
  } finally {
    dispose()
  }
})

test('logs 别名与旧版名 log 返回一致（两个路径都能用）', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.addLog('s1', { id: '1', taskId: 'T', status: 'success' })
    const a = (await host.call('get', '/api/task-scheduler/tasks/log', { headers: H('s1') })).data
    const b = (await host.call('get', '/api/task-scheduler/tasks/logs', { headers: H('s1') })).data
    assert.deepEqual(b.logs, a.logs)
    assert.equal(b.total, a.total)
  } finally {
    dispose()
  }
})

test('log/detail：返回逐条命令结果与完整输出；logs/detail 别名一致', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    gameHalf.addLog('s1', {
      id: '9', taskId: 'T', taskName: '甲', status: 'failed',
      commands: [{ command: '/bc a', status: 'success', output: 'ok' }, { command: '/nope', status: 'failed', output: '未找到命令' }],
    })
    const a = (await host.call('get', '/api/task-scheduler/tasks/log/detail', { headers: H('s1'), query: { id: '9' } })).data
    assert.equal(a.log.id, '9')
    assert.equal(a.log.commands.length, 2)
    assert.equal(a.log.commands[1].status, 'failed')

    const b = (await host.call('get', '/api/task-scheduler/tasks/logs/detail', { headers: H('s1'), query: { id: '9' } })).data
    assert.deepEqual(b.log, a.log)
  } finally {
    dispose()
  }
})

test('log/detail：缺 id → 400；记录不存在 → 404；服端没装 DLL → 501', async () => {
  const { host, gameHalf, dispose } = await boot()
  try {
    let res = await host.call('get', '/api/task-scheduler/tasks/log/detail', { headers: H('s1') })
    assert.equal(res.status, 400)

    res = await host.call('get', '/api/task-scheduler/tasks/log/detail', { headers: H('s1'), query: { id: '404' } })
    assert.equal(res.status, 404)
    assert.equal(res.data.error, '记录不存在')

    gameHalf.setBehavior('s1', 'missing')
    res = await host.call('get', '/api/task-scheduler/tasks/log/detail', { headers: H('s1'), query: { id: '1' } })
    assert.equal(res.status, 501)
    assert.equal(res.data.serverHalfMissing, true)
  } finally {
    dispose()
  }
})

// ═══════════════ 配置损坏降级（旧版 D29）═══════════════

test('配置文件损坏 → 另存 .corrupt-* 备份、不自动覆盖、storeError 全程可见', async () => {
  const { dataDir, host, gameHalf, dispose } = await boot()
  dispose()
  const pdir = path.join(dataDir, 'task-scheduler')
  await mkdir(pdir, { recursive: true })
  const cfgFile = path.join(pdir, 'tasks.json')
  await writeFile(cfgFile, '{ broken json', 'utf8')

  const host2 = makeFakeHost({ dataDir, servers: SERVERS, fetchFor: gameHalf.fetchFor })
  const dispose2 = await apply(host2.ctx, { push: FAST })
  try {
    const d = (await host2.call('get', '/api/task-scheduler/tasks/list', { headers: H('s1') })).data
    assert.ok(d.storeError.includes('无法解析'), d.storeError)
    // 原文件不能被改写成空配置
    assert.equal((await readFile(cfgFile, 'utf8')), '{ broken json')
    // 备份文件存在
    const { readdir } = await import('node:fs/promises')
    const files = await readdir(pdir)
    assert.ok(files.some((f) => f.startsWith('tasks.json.corrupt-')), JSON.stringify(files))
  } finally {
    dispose2()
  }
})

test('配置损坏期间**不写盘**；管理员保存一次之后才恢复写入', async () => {
  const { dataDir, host, gameHalf, dispose } = await boot()
  dispose()
  const pdir = path.join(dataDir, 'task-scheduler')
  await mkdir(pdir, { recursive: true })
  const cfgFile = path.join(pdir, 'tasks.json')
  await writeFile(cfgFile, 'not json at all', 'utf8')

  const host2 = makeFakeHost({ dataDir, servers: SERVERS, fetchFor: gameHalf.fetchFor })
  const dispose2 = await apply(host2.ctx, { push: FAST })
  try {
    // 保存一次（这是管理员的明确动作）→ 覆盖坏文件是预期的
    const res = await create(host2, { name: '恢复后的第一个任务' })
    assert.equal(res.status, 200)
    const after = JSON.parse(await readFile(cfgFile, 'utf8'))
    assert.equal(after.servers.s1.tasks.length, 1)
    const d = (await host2.call('get', '/api/task-scheduler/tasks/list', { headers: H('s1') })).data
    assert.equal(d.storeError, '', '保存成功后 storeError 应清掉')
  } finally {
    dispose2()
  }
})

// ═══════════════ 载荷上限 ═══════════════

test('任务过大（超过下发载荷上限）→ 保存时就明确拒绝，而不是保存成功、下发永远失败', async () => {
  const { host, dispose } = await boot()
  try {
    const huge = '/bc ' + 'x'.repeat(60 * 1024)
    const res = await create(host, { name: '超大', commands: [huge] })
    assert.equal(res.status, 400)
    assert.ok(res.data.error.includes('过大') || res.data.error.includes('上限'), res.data.error)
    const d = (await host.call('get', '/api/task-scheduler/tasks/list', { headers: H('s1') })).data
    assert.equal(d.tasks.length, 0, '被拒绝的任务不得落盘')
  } finally {
    dispose()
  }
})

// ═══════════════ 鉴权接线 ═══════════════

test('所有管理端点都挂了 verifyAuth + requireAdmin（修 D-越权：旧版是 requireManager=admin+subadmin）', async () => {
  const src = await readFile(new URL('../index.js', import.meta.url), 'utf8')
  // 逐个路由确认用的是 ...admin（而不是 ...manager 之类更宽的链）
  const routes = [
    '/api/task-scheduler/tasks/list', '/api/task-scheduler/tasks/get',
    '/api/task-scheduler/tasks/save', '/api/task-scheduler/tasks/delete',
    '/api/task-scheduler/tasks/run', '/api/task-scheduler/status',
    '/api/task-scheduler/push', '/api/task-scheduler/adopt', '/api/task-scheduler/audit',
  ]
  for (const r of routes) {
    const idx = src.indexOf(`'${r}'`)
    assert.ok(idx > 0, `应注册 ${r}`)
    const line = src.slice(idx, src.indexOf('\n', idx))
    assert.ok(line.includes('...admin'), `${r} 应挂 ...admin 鉴权链：${line.trim()}`)
  }
  assert.ok(src.includes("const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]"),
    'admin 链必须是 verifyAuth + requireAdmin')
  // 扫"代码"而不是注释：注释里会提到旧版的 requireManager（说明为什么不用它）
  const code = src.split('\n').filter((l) => !/^\s*(\/\/|\*|\/\*)/.test(l)).join('\n')
  assert.equal(code.includes('requireManager'), false, '代码里不得出现旧版的 requireManager（那会放子管理员进来）')
  // 执行记录分页端点同样要鉴权
  assert.ok(src.includes("app.get('/api/task-scheduler/tasks/log', ...admin, logListHandler)"))
  assert.ok(src.includes("app.get('/api/task-scheduler/tasks/logs/detail', ...admin, logDetailHandler)"))
})

test('每次配置变更与手动执行都写审计（含服务器与任务标识）', async () => {
  const { host, dispose } = await boot()
  try {
    const made = await create(host, { name: '审计用' })
    const audit = (await host.call('get', '/api/task-scheduler/audit')).data
    const createRec = audit.entries.find((e) => e.op === 'create')
    assert.ok(createRec, JSON.stringify(audit.entries))
    assert.equal(createRec.serverId, 's1')
    assert.equal(createRec.taskId, made.data.id)
    assert.equal(createRec.taskName, '审计用')
    // 关键：动作名必须是审计动作名，不能被载荷里的 op 覆盖
    assert.equal(createRec.action, 'task-scheduler.config.write')
  } finally {
    dispose()
  }
})
