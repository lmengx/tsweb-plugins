/**
 * 前端半（client/task-scheduler.js）测试
 *
 * ★ 先说清本机限制（交付报告里也如实写明）：**本机没有浏览器**，所以这里不是浏览器渲染测试，
 *   而是三层静态/桩验证：
 *     ① 纯函数层：模板/默认值/汇总文案/状态标签/分页计算直接在 Node 里调（无 DOM 依赖）
 *     ② 源码静态层：注册元信息（id/title/section/path）、旧版文案、类名前缀、
 *        无 emoji、HTML 里不得出现 markdown 星号（会原样显示）
 *     ③ 桩 DOM 层：用最小假 DOM 真的跑一遍 render()，断言工具栏/卡片/告警块渲染出来、
 *        软失败可见（下发失败文案）、事件重复绑定被挡住
 *   桩 DOM **不能**证明真实浏览器里的样式与观感，那需要人眼或截图工具。
 *
 * 运行：node test/client-ui.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const clientFile = path.resolve(here, '..', 'client', 'task-scheduler.js')

/**
 * 写操作测试用的任务样本。
 * 形状照 GET /api/task-scheduler/tasks/list 的真实返回（见本件 client 的 renderTaskCard 取值），
 * 并且 triggerMode 故意取 'interval'：只有**非手动**任务才会渲染开关，切开关的用例才驱动得到。
 */
const TEST_TASK = {
  id: 'a',
  name: '晨间公告',
  enabled: true,
  triggerMode: 'interval',
  intervalSeconds: 3600,
  condition: { type: 'always', not: false, params: { min: 0, max: 9999, bossNames: [], playerNames: [] } },
  execMode: 'sequential',
  commands: ['/bc 早'],
  commandCount: 1,
  runCount: 0,
  lastRunAt: '',
  lastRunStatus: '',
  running: false,
}

// ════════════════════════════════════════════
//  最小假 DOM
// ════════════════════════════════════════════

function makeClassList() {
  const set = new Set()
  return {
    add: (...cs) => cs.forEach((c) => set.add(c)),
    remove: (...cs) => cs.forEach((c) => set.delete(c)),
    contains: (c) => set.has(c),
    _all: () => [...set],
  }
}

/** 一个够用的假节点：innerHTML / textContent / classList / querySelector / 事件 */
function makeEl(id) {
  const listeners = new Map()
  const el = {
    id: id || '',
    innerHTML: '',
    textContent: '',
    value: '',
    tagName: 'DIV',
    dataset: {},
    style: {},
    classList: makeClassList(),
    // 只支持 '#id' 选择器：客户端只用这一种
    querySelector(sel) {
      const key = String(sel)
      if (!this.__cache) this.__cache = new Map()
      if (!this.__cache.has(key)) this.__cache.set(key, makeEl(key.replace(/^#/, '')))
      return this.__cache.get(key)
    },
    addEventListener(type, fn) {
      if (!listeners.has(type)) listeners.set(type, [])
      listeners.get(type).push(fn)
    },
    removeEventListener(type, fn) {
      const arr = listeners.get(type) || []
      const i = arr.indexOf(fn)
      if (i >= 0) arr.splice(i, 1)
    },
    __count: (type) => (listeners.get(type) || []).length,
    __fire(type, ev) {
      for (const fn of [...(listeners.get(type) || [])]) fn(ev || {})
    },
  }
  return el
}

/**
 * 按宿主**真实契约**算出这次请求的方法与请求体。
 *
 * 权威实现：plugins/web/public/app.js:222-244。契约只有三条：
 *   1. 只有 `options.json` 会进请求体（`JSON.stringify(options.json)` → fetch 的 body）；
 *      实现里**没有 `options.body` 分支** —— 传 `body` 等于发空 body（缺陷 A 的成因）；
 *   2. 方法 = `options.method` 优先，否则"给了 json 就 POST、没给就 GET"；
 *   3. `options.headers` 被合并进请求头（x-server-id 靠它）。
 *
 * 桩必须照这个口径算。原先那种 `api: () => Promise.resolve({...})` 完全忽略 options，
 * 于是"前端把参数放在 api 不认的键上"在桩里**永远看不见** —— 缺陷 A 的 6 处空 body
 * 就是这样在 190 个全绿用例里藏住的。
 */
function requestShapeOf(opts) {
  const o = opts || {}
  const hasJson = o.json !== undefined
  return {
    method: o.method || (hasJson ? 'POST' : 'GET'),
    body: hasJson ? JSON.stringify(o.json) : undefined,
  }
}

/**
 * 挂载视图并等首屏加载完成。
 * 假 window.tsweb.api 按路径回可编程数据；**记录每次调用**，用于断言"一次点击只发一次请求"，
 * 并额外记录按真实契约算出的 method/body，供写操作的成功路径断言使用。
 */
async function mount({ list, status, task } = {}) {
  const calls = []
  /** 按真实契约本会是"空 body 的 POST"的调用 —— 写操作静默失效的直接证据 */
  const emptyPostBodies = []
  const container = makeEl('root')
  const tsw = {
    getServerId: () => 's1',
    api(callPath, opts) {
      const o = opts || {}
      const shape = requestShapeOf(o)
      const rec = { path: callPath, opts: o, method: shape.method, body: shape.body }
      if (shape.method === 'POST' && shape.body === undefined) {
        rec.emptyPostBody = true
        emptyPostBodies.push(rec)
      }
      calls.push(rec)
      let data = { ok: true }
      if (callPath.includes('/tasks/list')) data = list !== undefined ? list : { ok: true, tasks: [], warnings: [] }
      else if (callPath.includes('/status')) data = status || { ok: true, servers: [], pendingCount: 0 }
      else if (callPath.includes('/tasks/get')) {
        data = { ok: true, task: task || TEST_TASK }
      }
      return Promise.resolve({ ok: true, status: 200, data })
    },
    registerView() {},
  }
  globalThis.window = { tsweb: tsw, confirm: () => true, setTimeout, clearTimeout }
  globalThis.setTimeout = setTimeout
  globalThis.clearTimeout = clearTimeout

  // 每次 import 都需要独立实例（模块级注册只跑一次），用 cache-busting query 拿到新实例
  const mod = await import(url(clientFile) + `?case=${Math.random()}`)
  const cleanup = mod.mountTasksView(container)
  await settle()
  return { container, calls, cleanup, mod, tsw, emptyPostBodies }
}

function url(p) {
  return 'file:///' + p.replace(/\\/g, '/')
}

/** 让已排队的 promise 链跑完 */
async function settle(times = 6) {
  for (let i = 0; i < times; i++) await new Promise((r) => setImmediate(r))
}

// ════════════════════════════════════════════
//  ① 纯函数层
// ════════════════════════════════════════════

test('VIEW_META：与旧版 console 路由和本件约定一致（id/title/section/path/icon）', async () => {
  const m = await import(url(clientFile) + '?meta=1')
  assert.deepEqual(m.VIEW_META, {
    id: 'tasks',
    title: '自动任务',
    section: '服务器设置',
    path: '/s/tasks',
    icon: 'layers',
  })
})

test('emptyTask：与旧版 TasksView.vue:120-132 的新建表单默认值一致', async () => {
  const m = await import(url(clientFile) + '?empty=1')
  const t = m.emptyTask()
  assert.equal(t.id, '')
  assert.equal(t.name, '')
  assert.equal(t.enabled, true)
  assert.equal(t.triggerMode, 'manual')
  // 旧版新建表单给 600 / '04:00'（与 C# 模型默认 0 / '00:00' 不同，这是旧版本来就有的差异，
  // 两侧分别照搬，不能混成一个——见 test/config.test.mjs 的对应断言）
  assert.equal(t.intervalSeconds, 600)
  assert.equal(t.dailyTime, '04:00')
  assert.equal(t.execMode, 'sequential')
  assert.deepEqual(t.commands, [])
  assert.deepEqual(t.condition, { type: 'always', not: false, params: { min: 0, max: 9999, bossNames: [], playerNames: [] } })
})

test('TASK_TEMPLATES：与旧版 TasksView.vue:53-103 的三个模板逐字一致（含 build() 形态）', async () => {
  const m = await import(url(clientFile) + '?tpl=1')
  assert.equal(m.TASK_TEMPLATES.length, 3)
  assert.deepEqual(m.TASK_TEMPLATES.map((t) => t.name), ['凌晨关服重启', '自动清理地面物品', '定时自动保存'])
  assert.deepEqual(m.TASK_TEMPLATES.map((t) => t.desc), [
    '每天 03:00，玩家数为 0 时执行关服（重启需自行配置）',
    '每 2 小时广播提示，1 分钟后清理地面掉落物',
    '每 30 分钟自动保存世界',
  ])
  for (const t of m.TASK_TEMPLATES) {
    // 旧版是 build: () => ({...})，不是静态对象——照搬这个形态（每次点模板拿到新对象）
    assert.equal(typeof t.build, 'function', `${t.name} 应是 build() 形式`)
    const built = t.build()
    assert.equal(built.name, t.name)
    assert.ok(Array.isArray(built.commands) && built.commands.length > 0, `${t.name} 应有命令`)
    assert.notEqual(t.build(), built, 'build() 每次应给新对象（避免多个任务共享同一份引用）')
  }
  // 三个模板的关键取值逐项对齐旧版
  const [shutdown, clear, save] = m.TASK_TEMPLATES.map((t) => t.build())
  assert.equal(shutdown.triggerMode, 'daily')
  assert.equal(shutdown.dailyTime, '03:00')
  assert.deepEqual(shutdown.commands, ['/bc 服务器即将关闭', '/off confirm'])
  assert.equal(shutdown.condition.type, 'online_count')
  assert.deepEqual(shutdown.condition.params.min, 0)
  assert.deepEqual(shutdown.condition.params.max, 0)
  assert.equal(clear.intervalSeconds, 7200)
  assert.deepEqual(clear.commands, ['/bc 1分钟后将清理地面物品', '/wait 60000', '/clear item 9999'])
  assert.equal(save.intervalSeconds, 1800)
  assert.deepEqual(save.commands, ['/bc 正在保存世界', '/save'])
})

test('HOURS / MINUTES：00-23 与 00-59，且都是两位（旧版下拉的数据源）', async () => {
  const m = await import(url(clientFile) + '?time=1')
  assert.equal(m.HOURS.length, 24)
  assert.equal(m.MINUTES.length, 60)
  assert.equal(m.HOURS[0], '00')
  assert.equal(m.HOURS[23], '23')
  assert.equal(m.MINUTES[0], '00')
  assert.equal(m.MINUTES[59], '59')
  assert.equal(m.pad2(3), '03')
  assert.equal(m.pad2(12), '12')
})

test('conditionSummary：四种条件类型的人话汇总（含"取反"）', async () => {
  const m = await import(url(clientFile) + '?cond=1')
  assert.ok(m.conditionSummary({ type: 'always' }).includes('无条件'))
  assert.ok(m.conditionSummary({ type: 'online_count', params: { min: 2, max: 10 } }).includes('2'))
  assert.ok(m.conditionSummary({ type: 'online_count', params: { min: 2, max: 10 } }).includes('10'))
  const boss = m.conditionSummary({ type: 'boss_defeated', params: { bossNames: ['克苏鲁之眼'] } })
  assert.ok(boss.includes('克苏鲁之眼'), boss)
  const players = m.conditionSummary({ type: 'player_online', params: { playerNames: ['Alice'] } })
  assert.ok(players.includes('Alice'), players)
  const negated = m.conditionSummary({ type: 'online_count', not: true, params: { min: 1, max: 5 } })
  assert.ok(negated.startsWith('非'), `取反要有明显的"非"前缀：${negated}`)
  // 未知类型不能炸，也不能静默显示空白
  assert.ok(m.conditionSummary({ type: 'nonsense' }).length > 0)
})

test('triggerSummary：手动 / 间隔 / 每天定时三种触发的人话', async () => {
  const m = await import(url(clientFile) + '?trig=1')
  assert.ok(m.triggerSummary({ triggerMode: 'manual' }).includes('手动'))
  const iv = m.triggerSummary({ triggerMode: 'interval', intervalSeconds: 90 })
  assert.ok(iv.includes('90') || iv.includes('1'), iv)
  const dl = m.triggerSummary({ triggerMode: 'daily', dailyTime: '03:30' })
  assert.ok(dl.includes('03:30'), dl)
})

test('statusLabel / statusClass：含本件新增的"已中断"（旧版没有这个状态）', async () => {
  const m = await import(url(clientFile) + '?status=1')
  assert.equal(m.statusLabel('success'), '成功')
  assert.equal(m.statusLabel('failed'), '失败')
  assert.equal(m.statusLabel('running'), '执行中')
  assert.equal(m.statusLabel('skipped'), '跳过')
  assert.equal(m.statusLabel('interrupted'), '已中断')
  assert.equal(m.statusLabel(''), '未执行')
  assert.equal(typeof m.statusClass('success'), 'string')
  assert.notEqual(m.statusClass('success'), m.statusClass('failed'))
})

test('cmdStatusLabel / cmdStatusClass：逐条命令要能区分 成功/失败/不适用（旧版只有成功/失败）', async () => {
  const m = await import(url(clientFile) + '?cmd=1')
  // 入参是**命令执行记录对象**（服端 TaskCommandLog），不是状态字符串
  assert.equal(m.cmdStatusLabel({ status: 'success', success: true }), '成功')
  assert.equal(m.cmdStatusLabel({ status: 'failed', success: false }), '失败')
  assert.equal(m.cmdStatusLabel({ status: 'not_applicable', success: false }), '不适用')
  // 服端给了 statusText 时以它为准（保留服端原话）
  assert.equal(m.cmdStatusLabel({ status: 'failed', statusText: '命令不存在' }), '命令不存在')
  // 历史记录没有 status 字段 → 回退旧版布尔判断（不能崩）
  assert.equal(m.cmdStatusLabel({ success: true }), '成功')
  assert.equal(m.cmdStatusLabel({ success: false }), '失败')
  assert.equal(m.cmdStatusLabel(null), '失败')
  assert.notEqual(m.cmdStatusClass({ status: 'success', success: true }), m.cmdStatusClass({ status: 'failed', success: false }))
  assert.notEqual(m.cmdStatusClass({ status: 'failed', success: false }), m.cmdStatusClass({ status: 'not_applicable', success: false }))
})

test('fmtDur：毫秒转秒文案（列表 1 位、详情 2 位小数；旧版 :618 / :637）', async () => {
  const m = await import(url(clientFile) + '?dur=1')
  assert.equal(m.fmtDur(500), '0.5s')
  assert.equal(m.fmtDur(1500), '1.5s')
  assert.equal(m.fmtDur(90000), '90.0s')
  assert.equal(m.fmtDur(1234, 2), '1.23s')
  assert.equal(m.fmtDur(0), '0.0s')
  assert.equal(m.fmtDur(null), '0.0s')
  assert.equal(m.fmtDur(undefined), '0.0s')
})

test('pageCount：分页计算（0 条也要给 1 页，避免界面显示 0/0）', async () => {
  const m = await import(url(clientFile) + '?page=1')
  assert.equal(m.pageCount(0, 20), 1)
  assert.equal(m.pageCount(1, 20), 1)
  assert.equal(m.pageCount(20, 20), 1)
  assert.equal(m.pageCount(21, 20), 2)
  assert.equal(m.pageCount(100, 20), 5)
  assert.equal(m.pageCount(5, 0), 1, 'pageSize 非法时不能除以 0')
})

test('esc：HTML 转义（任务名/玩家名可以含尖括号，不能变成注入）', async () => {
  const m = await import(url(clientFile) + '?esc=1')
  assert.equal(m.esc('<b>&"x"</b>'), '&lt;b&gt;&amp;&quot;x&quot;&lt;/b&gt;')
  assert.equal(m.esc(null), '')
  assert.equal(m.esc(undefined), '')
})

test('warningText：同时吃字符串与 {taskId,taskName,warning} 两种形态', async () => {
  const m = await import(url(clientFile) + '?warn=1')
  assert.equal(m.warningText('就是一句话'), '就是一句话')
  assert.equal(m.warningText({ taskName: '甲', warning: '间隔为 0' }), '甲：间隔为 0')
  assert.equal(m.warningText({ taskId: 'x', warning: '无名字' }), '无名字')
  assert.equal(m.warningText(null), '')
})

test('pushFeedback：下发失败必须出现在保存/删除的反馈里（旧版此处彻底静默）', async () => {
  const m = await import(url(clientFile) + '?push=1')
  assert.equal(m.pushFeedback({ pushOk: true }, '任务已保存').ok, true)
  const bad = m.pushFeedback({ pushOk: false, pushError: '游戏服端未安装 TaskScheduler.dll' }, '任务已保存')
  assert.equal(bad.ok, false)
  assert.ok(bad.text.includes('任务已保存'), bad.text)
  assert.ok(bad.text.includes('TaskScheduler.dll'), bad.text)
  assert.ok(bad.text.includes('重新下发'), '要告诉管理员下一步怎么办')
})

test('renderBarHtml：下发状态条包含 已确认 / 待下发 / 未配置 / 读不到 四种面貌', async () => {
  const m = await import(url(clientFile) + '?bar=1')
  const acked = m.renderBarHtml({ servers: [{ serverId: 's1', name: '一服', configured: true, taskCount: 2, revision: 3, ackRevision: 3, pending: false, lastError: '' }] }, '', 's1')
  // 这条用例挡的是一个真实缺陷：字段名曾写成 ackedRevision（多一个 ed），恒 undefined，
  // 于是**下发成功之后状态条也永远显示"未下发"**。所以这里必须断言"已确认"真的出现。
  assert.ok(acked.includes('已确认'), acked)
  assert.equal(acked.includes('未下发'), false, acked)

  const pending = m.renderBarHtml({ servers: [{ serverId: 's1', name: '一服', configured: true, taskCount: 2, revision: 4, ackRevision: 3, pending: true, lastError: '游戏服端未安装 TaskScheduler.dll', retryAttempts: 2 }] }, '', 's1')
  assert.ok(pending.includes('待下发'), pending)
  assert.ok(pending.includes('TaskScheduler.dll'), '失败原因要显示出来')
  assert.ok(pending.includes('重试'), '重试次数要显示出来')

  const never = m.renderBarHtml({ servers: [{ serverId: 's1', name: '一服', configured: true, taskCount: 0, revision: 1, ackRevision: 0, pending: true, lastError: '' }] }, '', 's1')
  assert.ok(never.includes('待下发'), never)

  const empty = m.renderBarHtml({ servers: [] }, '', 's1')
  assert.ok(empty.includes('尚未为当前服务器配置任务'), empty)

  const err = m.renderBarHtml(null, '读取状态失败', 's1')
  assert.ok(err.includes('读取状态失败'), err)
  assert.ok(err.includes('tsk-bar err'), '读不到状态时状态条要有错误样式')
})

test('renderBarHtml：孤儿配置（服务器已删除）要标明不会下发', async () => {
  const m = await import(url(clientFile) + '?bar2=1')
  const html = m.renderBarHtml({ servers: [{ serverId: 'ghost', name: '(服务器已删除)', configured: true, orphan: true, taskCount: 1, revision: 1, ackRevision: 0, pending: true, lastError: '' }] }, '', 'ghost')
  assert.ok(html.includes('服务器已删除'), html)
  assert.ok(html.includes('不会下发'), html)
})

test('renderBarHtml：probe 的两种失败都要显眼报出来（读不到 / 读到但不一致）', async () => {
  const m = await import(url(clientFile) + '?bar3=1')
  // 不一致：宿主 probeServer 给的是 { ok:true, inSync:false }——早先客户端只判 ok===false，
  // 于是"两边内容不一致"这个最该报的情况反而不显示，等于对账只在读不到时才生效。
  const mismatch = m.renderBarHtml({
    servers: [{
      serverId: 's1', name: '一服', configured: true, taskCount: 1, revision: 1, ackRevision: 1,
      pending: false, lastError: '',
      probe: { ok: true, inSync: false, onlyInHost: [{ id: 'a' }], onlyInServer: [], differing: [{ id: 'b' }] },
    }],
  }, '', 's1')
  assert.ok(mismatch.includes('对账不一致'), mismatch)
  assert.ok(mismatch.includes('仅宿主有 1 个'), mismatch)
  assert.ok(mismatch.includes('两端不一致 1 个'), mismatch)

  // 读取失败：ok===false
  const unreadable = m.renderBarHtml({
    servers: [{
      serverId: 's1', name: '一服', configured: true, taskCount: 1, revision: 1, ackRevision: 1,
      pending: false, lastError: '', probe: { ok: false, reason: '游戏服端未安装 TaskScheduler.dll' },
    }],
  }, '', 's1')
  assert.ok(unreadable.includes('服端状态读取失败'), unreadable)
  assert.ok(unreadable.includes('TaskScheduler.dll'), unreadable)

  // 一致时不得报警（正对照，避免"永远报不一致"）
  const inSync = m.renderBarHtml({
    servers: [{
      serverId: 's1', name: '一服', configured: true, taskCount: 1, revision: 1, ackRevision: 1,
      pending: false, lastError: '', probe: { ok: true, inSync: true, onlyInHost: [], onlyInServer: [], differing: [] },
    }],
  }, '', 's1')
  assert.equal(inSync.includes('对账不一致'), false, inSync)
  assert.equal(inSync.includes('读取失败'), false, inSync)
})

test('renderAlertsHtml：storeError 与 warnings 都要显示（旧版这两类都是静默的）', async () => {
  const m = await import(url(clientFile) + '?alerts=1')
  const html = m.renderAlertsHtml({ storeError: '任务配置文件无法解析' }, [{ taskName: '甲', warning: '间隔为 0，任务永远不会触发' }])
  assert.ok(html.includes('任务配置文件无法解析'), html)
  assert.ok(html.includes('间隔为 0'), html)
  assert.equal(m.renderAlertsHtml({}, []), '')
})

test('renderTaskCard：卡片含 名称/触发/条件/统计/按钮，且禁用态有标记', async () => {
  const m = await import(url(clientFile) + '?card=1')
  const html = m.renderTaskCard({
    id: 'a', name: '公告', enabled: true, triggerMode: 'interval', intervalSeconds: 60,
    dailyTime: '00:00', condition: { type: 'always', params: {} }, execMode: 'sequential',
    commandCount: 2, lastRunAt: '2026-01-01 10:00:00', lastRunStatus: 'success', runCount: 5, running: false,
  })
  for (const s of ['公告', '每 60 秒', '无条件', '顺序', '2', '2026-01-01 10:00:00', '成功']) {
    assert.ok(html.includes(s), `卡片应含「${s}」`)
  }
  // 自动触发的任务才有启用开关（旧版 :402 对手动任务不显示开关）
  assert.ok(html.includes('tsk-switch'), '自动任务应有启用开关')

  // 禁用态：只有**自动触发**的任务才显示为灰（手动任务没有开关，本来就不该灰）
  const off = m.renderTaskCard({ id: 'b', name: '停用', enabled: false, triggerMode: 'interval', intervalSeconds: 60, condition: { type: 'always', params: {} }, execMode: 'sequential', commandCount: 1, runCount: 0 })
  assert.ok(off.includes('disabled'), '停用的自动任务应有灰化标记')

  // 手动任务不显示开关
  const manual = m.renderTaskCard({ id: 'c', name: '手动', enabled: false, triggerMode: 'manual', condition: { type: 'always', params: {} }, execMode: 'sequential', commandCount: 1, runCount: 0 })
  assert.equal(manual.includes('tsk-switch'), false, '手动任务不应显示启用开关（旧版同）')

  // 服端读不到运行期状态 / 服端没有这个任务 → 都要有明确徽标，不能让"0 次"冒充"没执行过"
  const bad = m.renderTaskCard({ id: 'd', name: '未知', enabled: true, triggerMode: 'manual', condition: { type: 'always', params: {} }, execMode: 'sequential', commandCount: 1, runCount: 0, runtimeAvailable: false, presentOnServer: false })
  assert.ok(bad.includes('运行状态不可用'), bad)
  assert.ok(bad.includes('未下发'), bad)
})

test('renderGridHtml：空列表给出引导文案而不是一片空白', async () => {
  const m = await import(url(clientFile) + '?grid=1')
  const empty = m.renderGridHtml([], false)
  assert.ok(empty.includes('tsk-empty'), empty)
  assert.ok(empty.includes('新建') || empty.includes('还没有'), empty)
  const loading = m.renderGridHtml([], true)
  assert.ok(loading.includes('加载'), loading)
})

// ════════════════════════════════════════════
//  ② 源码静态层
// ════════════════════════════════════════════

test('源码：注册被守卫（Node 里 import 不能炸），且用 VIEW_META', async () => {
  const src = await readFile(clientFile, 'utf8')
  assert.ok(src.includes("typeof tsw.registerView === 'function'"), '必须守卫 registerView 的存在')
  assert.ok(src.includes("tsw.registerView(Object.assign({}, VIEW_META, { render: mountTasksView }))"))
  assert.ok(src.includes("typeof window !== 'undefined' ? window.tsweb : null") || src.includes("typeof window !== 'undefined'"),
    '不能在模块顶层直接摸 window（Node 里没有 window）')
})

test('源码：CSS 顶层选择器统一 tsk- 前缀（宿主既有类名除外）', async () => {
  const src = await readFile(clientFile, 'utf8')
  const css = src.slice(src.indexOf('export const VIEW_CSS'), src.indexOf('export function makeApi'))
  // VIEW_CSS 是"每条规则一个数组元素"的字符串数组，所以「选择器」= 每个 `'...{` 里 `{` 之前那段。
  // 只取**选择器的起始简单选择器**：
  //   - 以 `.` 开头 → 取这个类名，它才是顶层命名空间
  //   - 以 `#` 开头 → id 作用域（本插件的 id 都带 tsk- 前缀），不参与类名检查
  //   - 其它（标签、@media）→ 跳过
  // `.tsk-bar.off` 的 off 是本插件自己的修饰类，跟着 .tsk-bar 走不会与别的插件撞名。
  const selectors = [...css.matchAll(/'([^']*)\{/g)].map((m) => m[1].trim())
  const primary = selectors
    .filter((s) => s.startsWith('.'))
    .map((s) => (s.match(/^\.([a-zA-Z][\w-]*)/) || [])[1])
    .filter(Boolean)
  assert.ok(primary.length > 25, `应有较多规则，实际 ${primary.length}`)
  // 宿主提供的通用类名（工具栏、按钮、状态色）在本插件里复用是对的，不算撞样式
  const HOST = new Set(['spacer', 'hidden', 'muted', 'error', 'primary', 'ghost', 'sm', 'danger', 'badge', 'toolbar', 'grow'])
  const bad = primary.filter((c) => !c.startsWith('tsk-') && !HOST.has(c))
  assert.deepEqual([...new Set(bad)], [], `出现了非 tsk- 前缀的顶层样式类：${[...new Set(bad)].join(' ')}`)
})

test('源码：不得出现 emoji（全仓约定），但允许本仓既有的几何/箭头字符', async () => {
  const src = await readFile(clientFile, 'utf8')
  // 本仓既有且允许的字符：界面按钮符号与注释里的箭头/章节装饰
  const ALLOWED = new Set(['✕', '＋', '▶', '⠿', '★', '−', '—', '→', '←', '↑', '↓', '·'])
  const EMOJI = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}\u{2190}-\u{21FF}]/gu
  const hits = [...src.matchAll(EMOJI)].map((m) => m[0]).filter((c) => !ALLOWED.has(c))
  assert.deepEqual([...new Set(hits)], [], `源码里出现了 emoji：${[...new Set(hits)].join(' ')}`)

  // 正/负对照：证明这个扫描器真的能抓到 emoji（用码点构造，文件里不出现 emoji 字符）
  const real = 'hello ' + String.fromCodePoint(0x1F600) + ' world'
  const caught = [...real.matchAll(EMOJI)].map((m) => m[0])
  assert.equal(caught.length, 1, '扫描器应能抓到真 emoji（否则本用例是空转）')
})

test('源码：界面文案里不得用 markdown 星号（会原样显示成 *）', async () => {
  const src = await readFile(clientFile, 'utf8')
  // 排除注释行（注释里用 * 是正常的）
  const code = src.split('\n').filter((l) => !/^\s*(\*|\/\*|\/\/)/.test(l)).join('\n')
  const bad = [...code.matchAll(/'[^'\n]*\*[^'\n]*'/g)].map((m) => m[0]).filter((s) => !s.includes('/*') && !s.startsWith("'*'"))
  assert.deepEqual(bad, [], `单引号字符串里出现了星号：${bad.join(' | ')}`)
})

test('源码：事件监听必须先按同一引用解绑再绑（宿主 route() 会重复调 render）', async () => {
  const src = await readFile(clientFile, 'utf8')
  for (const t of ['Click', 'Change', 'Input', 'Keydown', 'DragStart', 'DragOver', 'DragEnd']) {
    assert.ok(src.includes(`if (container.__tsk${t}) container.removeEventListener`), `${t} 缺少解绑`)
    assert.ok(src.includes(`container.__tsk${t} = `), `${t} 缺少引用保存`)
  }
  // cleanup 也要解绑，否则离开路由后监听器仍在
  const cleanup = src.slice(src.indexOf('return function cleanup()'))
  for (const t of ['Click', 'Change', 'Input', 'Keydown', 'DragStart', 'DragOver', 'DragEnd']) {
    assert.ok(cleanup.includes(`container.removeEventListener('${t.toLowerCase().replace('dragstart', 'dragstart')}'`),
      `cleanup 应解绑 ${t}`)
  }
})

test('源码：宿主 API 调用一律带 x-server-id（本件多服务器隔离的前提）', async () => {
  const src = await readFile(clientFile, 'utf8')
  const api = src.slice(src.indexOf('export function makeApi'), src.indexOf('export function unwrap'))
  assert.ok(api.includes("headers['x-server-id'] = sid"), 'makeApi 必须注入 x-server-id')
  assert.ok(api.includes('t.getServerId()'), '服务器 id 取自宿主 getServerId')
})

test('源码：旧版界面文案保留（工具栏与提示）', async () => {
  const src = await readFile(clientFile, 'utf8')
  for (const s of ['自动任务', '新建任务', '刷新', '重新下发', '确定删除任务「', '定时执行 TShock 命令，支持条件触发与执行记录追溯']) {
    assert.ok(src.includes(s), `缺少旧版文案「${s}」`)
  }
})

test('源码：不得把执行记录写死成一页（旧版固定 page=1，规格 D10）', async () => {
  const src = await readFile(clientFile, 'utf8')
  assert.ok(src.includes('logPage'), '应有页码状态')
  assert.ok(src.includes('logPageSize'), '应有每页条数状态')
  assert.ok(src.includes('logTotal'), '应有总数状态')
  assert.ok(src.includes('pageCount('), '应使用分页计算')
  assert.ok(src.includes('tsk-log-prev') || src.includes('上一页'), '应有上一页按钮')
  assert.ok(src.includes('tsk-log-next') || src.includes('下一页'), '应有下一页按钮')
})

// ════════════════════════════════════════════
//  ③ 桩 DOM 层
// ════════════════════════════════════════════

test('挂载：工具栏与四个容器都渲染出来，且首屏只调 list + status', async () => {
  const { container, calls, cleanup } = await mount()
  try {
    const html = container.innerHTML
    for (const id of ['tsk-bar', 'tsk-alerts', 'tsk-grid', 'tsk-modal', 'tsk-msg', 'tsk-error', 'tsk-server']) {
      assert.ok(html.includes(`id="${id}"`), `应渲染 #${id}`)
    }
    for (const s of ['自动任务', '刷新', '重新下发', '新建任务']) {
      assert.ok(html.includes(s), `工具栏应含「${s}」`)
    }
    const paths = calls.map((c) => c.path)
    assert.equal(paths.filter((p) => p.includes('/tasks/list')).length, 1)
    assert.equal(paths.filter((p) => p.includes('/status')).length, 1)
    assert.equal(paths.length, 2, `首屏只应发 2 个请求，实际：${paths.join(', ')}`)
    for (const c of calls) {
      assert.equal(c.opts.headers['x-server-id'], 's1', '每个请求都要带 x-server-id')
    }
  } finally {
    cleanup()
  }
})

test('挂载：任务列表渲染成卡片（名称/触发/条件可见）', async () => {
  const { container, cleanup } = await mount({
    list: {
      ok: true,
      tasks: [
        { id: 'a', name: '晨间公告', enabled: true, triggerMode: 'daily', dailyTime: '08:00', condition: { type: 'always', params: {} }, execMode: 'sequential', commandCount: 1, runCount: 0, lastRunAt: '', lastRunStatus: '', running: false },
        { id: 'b', name: '关服', enabled: false, triggerMode: 'interval', intervalSeconds: 3600, condition: { type: 'always', params: {} }, execMode: 'concurrent', commandCount: 2, runCount: 3, lastRunAt: '2026-01-01 03:00:00', lastRunStatus: 'success', running: false },
      ],
      warnings: [],
    },
  })
  try {
    const grid = container.querySelector('#tsk-grid').innerHTML
    assert.ok(grid.includes('晨间公告'), grid.slice(0, 300))
    assert.ok(grid.includes('关服'), grid.slice(0, 300))
    assert.ok(grid.includes('08:00'), '每天定时要显示时间')
    // 第二条是**手动**任务（即使 enabled=false 也不灰化，且不显示开关）
    assert.equal(grid.includes('tsk-switch'), true, '第一条是定时任务，应有开关')
  } finally {
    cleanup()
  }
})

test('挂载：软失败可见——storeError 与警告都出现在告警块里', async () => {
  const { container, cleanup } = await mount({
    list: {
      ok: true,
      tasks: [],
      storeError: '任务配置文件无法解析（Bad JSON）',
      warnings: [{ taskId: 'x', taskName: '甲', warning: '间隔为 0，任务永远不会触发' }],
    },
  })
  try {
    const alerts = container.querySelector('#tsk-alerts').innerHTML
    assert.ok(alerts.includes('无法解析'), alerts)
    assert.ok(alerts.includes('永远不会触发'), alerts)
    assert.ok(alerts.includes('甲'), '警告要带任务名，否则不知道是哪条')
  } finally {
    cleanup()
  }
})

test('挂载：下发失败在状态条里可见（不是只在控制台）', async () => {
  const { container, cleanup } = await mount({
    status: {
      ok: true,
      servers: [{ serverId: 's1', name: '一服', configured: true, taskCount: 1, revision: 2, ackRevision: 1, pending: true, lastError: '游戏服端未安装 TaskScheduler.dll', retryAttempts: 3, retryNextAt: '' }],
      pendingCount: 1,
    },
  })
  try {
    const bar = container.querySelector('#tsk-bar').innerHTML
    assert.ok(bar.includes('未安装') || bar.includes('TaskScheduler.dll'), bar)
    assert.ok(bar.includes('待下发'), bar)
  } finally {
    cleanup()
  }
})

test('重复挂载：同一 container 上事件不会累加（一次点击只触发一次）', async () => {
  const { container, calls, cleanup } = await mount()
  try {
    const before = calls.length
    // 模拟宿主重复进入该路由：再次调用同一个 render(container)
    const mod = await import(url(clientFile) + '?remount=1')
    const cleanup2 = mod.mountTasksView(container)
    await settle()
    // 第二次挂载后，click 监听器应当只有 1 个（旧的按同引用解绑了）
    assert.equal(container.__count('click'), 1, `click 监听器应只有 1 个，实际 ${container.__count('click')}`)
    assert.equal(container.__count('change'), 1)
    assert.equal(container.__count('input'), 1)

    // 真的点一次「刷新」→ 只应发一次 list 请求
    const mid = calls.length
    container.__fire('click', { target: { id: 'tsk-refresh', closest: () => null } })
    await settle()
    const after = calls.slice(mid).filter((c) => c.path.includes('/tasks/list')).length
    assert.equal(after, 1, `点一次刷新应只发 1 个 list 请求，实际 ${after}`)
    assert.ok(calls.length > before)
    cleanup2()
  } finally {
    cleanup()
  }
})

test('卸载：cleanup 之后事件全部解绑（离开路由不再有回调）', async () => {
  const { container, cleanup } = await mount()
  cleanup()
  for (const t of ['click', 'change', 'input', 'keydown', 'dragstart', 'dragover', 'dragend']) {
    assert.equal(container.__count(t), 0, `cleanup 后 ${t} 监听器应为 0`)
  }
})

test('点击「新建任务」→ 打开编辑弹窗，含四种条件类型与时间下拉', async () => {
  const { container, cleanup } = await mount()
  try {
    container.__fire('click', { target: { id: 'tsk-create', closest: () => null } })
    await settle()
    const modal = container.querySelector('#tsk-modal').innerHTML
    assert.ok(modal.includes('新建任务') || modal.includes('任务名称'), modal.slice(0, 300))
    for (const s of ['无条件', '在线人数', 'BOSS已击败', '指定玩家在线']) {
      assert.ok(modal.includes(s), `编辑表单应含条件类型「${s}」`)
    }
    assert.ok(modal.includes('手动执行') && modal.includes('间隔执行') && modal.includes('每天定时'), '应含三种触发方式')
    assert.ok(modal.includes('顺序执行') && modal.includes('并发执行'), '应含两种执行方式')
  } finally {
    cleanup()
  }
})

test('点击「刷新」→ 重新拉取列表（用户能看到数据变新）', async () => {
  const { container, calls, cleanup } = await mount()
  try {
    const before = calls.filter((c) => c.path.includes('/tasks/list')).length
    container.__fire('click', { target: { id: 'tsk-refresh', closest: () => null } })
    await settle()
    const after = calls.filter((c) => c.path.includes('/tasks/list')).length
    assert.equal(after, before + 1)
  } finally {
    cleanup()
  }
})

test('列表接口失败 → 错误区显示原因（不静默留白）', async () => {
  // 说明：本用例的桩 `api: () => Promise.resolve({ ok:false, ... })` **故意忽略 options**，
  // 因为它是纯**失败路径**用例（所有请求都失败，只看错误区是否渲染原因），
  // 不用于任何写操作的成功路径断言，所以不需要按契约消费 options.json。
  // 写操作的成功路径由本文件末尾的 ④ 组用例覆盖（那里的桩按真实契约算 method/body）。
  const container = makeEl('root')
  const tsw = {
    getServerId: () => 's1',
    api: () => Promise.resolve({ ok: false, status: 500, data: { error: '读取任务列表失败：游戏服端未安装 TaskScheduler.dll' } }),
    registerView() {},
  }
  globalThis.window = { tsweb: tsw, confirm: () => true, setTimeout, clearTimeout }
  const mod = await import(url(clientFile) + `?fail=${Math.random()}`)
  const cleanup = mod.mountTasksView(container)
  await settle()
  try {
    const err = container.querySelector('#tsk-error')
    assert.equal(err.classList.contains('hidden'), false, '错误区应显示出来')
    assert.ok(err.textContent.includes('TaskScheduler.dll'), err.textContent)
  } finally {
    cleanup()
  }
})

// ════════════════════════════════════════════
//  ④ 写操作的成功路径（缺陷 A 的行为层闸门）
// ════════════════════════════════════════════
//
// 为什么还要这一层：`test/api-contract.test.mjs` 是**静态**断言，它能抓住"键名写错"，
// 但抓不住"事件没绑上 / 点了不发请求 / 发到错的端点 / 只发了 GET"。
// 这一层真的**点按钮**，再用 `requestShapeOf()`（照 plugins/web/public/app.js:222-244 的
// 真实契约）算出这次请求的 method 与 body —— 两条腿一起才叫把写路径覆盖住。
// 缺陷 A 的 6 处 `body:` 在这层里会直接表现为"POST 却是空 body"。

/** 造一个事件目标：`closest(sel)` 按选择器返回对应元素（模拟真实 DOM 的祖先链） */
function fakeTarget(map, extra) {
  return Object.assign({
    id: '',
    value: '',
    checked: false,
    closest(sel) {
      if (!map) return null
      return Object.prototype.hasOwnProperty.call(map, sel) ? map[sel] : null
    },
    getAttribute() { return null },
  }, extra || {})
}

/**
 * 造"任务卡片上的按钮"事件目标。
 *
 * 关键：被点/被切换的**就是这个带 data-act 的元素**（真实 DOM 里按钮/开关自己带该属性），
 * 所以 target 自身的 `getAttribute('data-act')` 必须能答上来 —— onChange 正是这样判断开关的
 * （client/task-scheduler.js:1216）。同时它的祖先链里有一个 .tsk-card，onClick 与 onChange
 * 都靠 `closest('.tsk-card')` 找到任务 id（:1190、:1217）。
 */
function cardActionTarget(taskId, act) {
  const card = { getAttribute: (k) => (k === 'data-id' ? String(taskId) : null) }
  const el = fakeTarget({ '.tsk-card': card }, {
    getAttribute(k) { return k === 'data-act' ? act : null },
  })
  el.closest = (sel) => {
    if (sel === '.tsk-card') return card
    if (sel === '[data-act]') return el   // 元素自己带 data-act
    return null
  }
  return el
}

/** 断言这次调用按真实契约带上了请求体，并返回解析后的 body */
function assertBodyCarried(call, where) {
  assert.ok(call, `${where}：没有发出请求`)
  assert.equal(call.method, 'POST', `${where}：必须是 POST，实际是 ${call.method}`)
  assert.notEqual(call.body, undefined,
    `${where}：真实契约下这次请求是**空 body**（参数放在了 api() 不认的键上，缺陷 A）`)
  return JSON.parse(call.body)
}

test('写路径：点「重新下发」→ POST /push，body 带当前服务器 id', async () => {
  const { container, calls, emptyPostBodies, cleanup } = await mount()
  try {
    container.__fire('click', { target: fakeTarget(null, { id: 'tsk-repush' }) })
    await settle()
    const body = assertBodyCarried(calls.find((c) => c.path.includes('/api/task-scheduler/push')), '重新下发')
    assert.deepEqual(body, { serverId: 's1' }, '重推要带当前服务器 id')
    assert.deepEqual(emptyPostBodies, [], '不应出现"空 body 的 POST"')
  } finally {
    cleanup()
  }
})

test('写路径：点「采纳」→ POST /adopt，body 是空对象而不是 undefined', async () => {
  const { container, calls, emptyPostBodies, cleanup } = await mount()
  try {
    container.__fire('click', { target: fakeTarget(null, { id: 'tsk-adopt' }) })
    await settle()
    const body = assertBodyCarried(calls.find((c) => c.path.includes('/api/task-scheduler/adopt')), '采纳')
    assert.deepEqual(body, {}, '采纳没有参数，但必须传 json:{}（否则仍是空 body）')
    assert.deepEqual(emptyPostBodies, [])
  } finally {
    cleanup()
  }
})

test('写路径：点卡片「执行」→ POST /run，body 带 id 与 force', async () => {
  const { container, calls, emptyPostBodies, cleanup } = await mount({
    list: { ok: true, tasks: [TEST_TASK], warnings: [] },
  })
  try {
    container.__fire('click', { target: cardActionTarget('a', 'run') })
    await settle()
    const body = assertBodyCarried(calls.find((c) => c.path.includes('/api/task-scheduler/tasks/run')), '执行')
    assert.equal(body.id, 'a', '执行要带任务 id')
    assert.equal(body.force, 1, '卡片上的「执行」是强制跳过条件的（execTask(task, true)）')
    assert.deepEqual(emptyPostBodies, [])
  } finally {
    cleanup()
  }
})

test('写路径：点卡片「删除」→ POST /delete，body 带 id', async () => {
  const { container, calls, emptyPostBodies, cleanup } = await mount({
    list: { ok: true, tasks: [TEST_TASK], warnings: [] },
  })
  try {
    container.__fire('click', { target: cardActionTarget('a', 'del') })
    await settle()
    const body = assertBodyCarried(calls.find((c) => c.path.includes('/api/task-scheduler/tasks/delete')), '删除')
    assert.equal(body.id, 'a', '删除要带任务 id')
    assert.deepEqual(emptyPostBodies, [])
  } finally {
    cleanup()
  }
})

test('写路径：填名后点「保存」→ POST /tasks/save，body.task 是整份表单且新建不带 id', async () => {
  const { container, calls, emptyPostBodies, cleanup } = await mount()
  try {
    container.__fire('click', { target: fakeTarget(null, { id: 'tsk-create' }) })
    container.__fire('input', { target: fakeTarget(null, { id: 'tsk-f-name', value: '新任务甲' }) })
    container.__fire('click', { target: fakeTarget(null, { id: 'tsk-f-save' }) })
    await settle()
    const body = assertBodyCarried(calls.find((c) => c.path.includes('/api/task-scheduler/tasks/save')), '保存')
    assert.ok(body.task, '保存要带 task 字段')
    assert.equal(body.task.name, '新任务甲', '表单里的名字要落到载荷里')
    assert.equal(Object.prototype.hasOwnProperty.call(body.task, 'id'), false,
      '新建（id 为空）时不应带 id，否则宿主会当成改名/覆盖已有任务')
    assert.deepEqual(emptyPostBodies, [])
  } finally {
    cleanup()
  }
})

test('写路径：切开关（change）→ 先 GET 取整份任务，再 POST /tasks/save 带回新的 enabled', async () => {
  const { container, calls, emptyPostBodies, cleanup } = await mount({
    list: { ok: true, tasks: [TEST_TASK], warnings: [] },
  })
  try {
    container.__fire('change', { target: cardActionTarget('a', 'toggle') })
    await settle()
    assert.ok(calls.some((c) => c.path.includes('/api/task-scheduler/tasks/get')),
      '开关必须先把整份任务读回来（否则保存会用残缺对象覆盖整条任务）')
    const body = assertBodyCarried(calls.find((c) => c.path.includes('/api/task-scheduler/tasks/save')), '切开关')
    assert.equal(body.task.enabled, false, '开关从 true 切到 false 要落到载荷里')
    assert.equal(body.task.id, 'a')
    assert.deepEqual(emptyPostBodies, [])
  } finally {
    cleanup()
  }
})

test('写路径汇总：6 处写操作全部走一遍，真实契约下不出现任何 "空 body 的 POST"', async () => {
  // 这一条是"这一类错误"的总闸门：桩按真实契约（只认 options.json）算 body，
  // 只要有任意一处写操作把参数放在别的键上（例如 body:/data:/payload:），
  // 这里就会收集到 emptyPostBody 并失败。
  const { container, calls, emptyPostBodies, cleanup } = await mount({
    list: { ok: true, tasks: [TEST_TASK], warnings: [] },
  })
  try {
    // 1 补推  2 采纳  3 执行  4 删除  5 切开关  6 保存（新建）
    container.__fire('click', { target: fakeTarget(null, { id: 'tsk-repush' }) })
    container.__fire('click', { target: fakeTarget(null, { id: 'tsk-adopt' }) })
    container.__fire('click', { target: cardActionTarget('a', 'run') })
    container.__fire('click', { target: cardActionTarget('a', 'del') })
    container.__fire('change', { target: cardActionTarget('a', 'toggle') })
    container.__fire('click', { target: fakeTarget(null, { id: 'tsk-create' }) })
    container.__fire('input', { target: fakeTarget(null, { id: 'tsk-f-name', value: '乙' }) })
    container.__fire('click', { target: fakeTarget(null, { id: 'tsk-f-save' }) })
    await settle()

    const posts = calls.filter((c) => c.method === 'POST')
    assert.ok(posts.length >= 6,
      `应至少发出 6 个写请求（补推/采纳/执行/删除/切开关/保存），实际 ${posts.length}：` +
      posts.map((p) => p.path).join(', '))
    assert.deepEqual(emptyPostBodies.map((c) => c.path), [],
      '这些 POST 真实契约下会是空 body（参数被静默丢弃）：' + emptyPostBodies.map((c) => c.path).join(', '))
    // 每个 POST 都必须有可解析的 JSON 体
    for (const p of posts) {
      assert.doesNotThrow(() => JSON.parse(p.body), `POST ${p.path} 的 body 应是合法 JSON`)
    }
  } finally {
    cleanup()
  }
})
