/**
 * host 侧任务模型测试（config.js）
 *
 * 本文件锁住"与旧版逐字一致"的语义，以及本次任务要求修的三类缺陷在**模型层**的落点。
 * 旧版对照位置：TsWeb/plugin/TaskScheduler.cs（C# 模型与校验）、
 * TsWeb/frontend/src/views/console/TasksView.vue 与 api/tasksApi.js（界面默认值与 BOSS 名单）。
 *
 * 运行：node test/config.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

import {
  TRIGGER_MODES, EXEC_MODES, CONDITION_TYPES, BOSS_NAMES, DAILY_TIME_RE,
  defaultParams, defaultCondition, defaultTask, emptyConfig, newTaskId,
  normalizeTask, normalizeConfig, validateTask, taskWarnings, configWarnings,
  toGamePayload, payloadTooLarge, MAX_PAYLOAD_CHARS, httpError,
} from '../config.js'

const here = path.dirname(fileURLToPath(import.meta.url))

// ════════════════════════════════════════════
//  与旧版逐字一致：枚举标签与默认值
// ════════════════════════════════════════════

test('枚举标签与旧版 TasksView.vue:30-46 逐字一致', () => {
  assert.deepEqual(TRIGGER_MODES, [
    { value: 'manual', label: '手动执行' },
    { value: 'interval', label: '间隔执行' },
    { value: 'daily', label: '每天定时' },
  ])
  assert.deepEqual(EXEC_MODES, [
    { value: 'sequential', label: '顺序执行' },
    { value: 'concurrent', label: '并发执行' },
  ])
  assert.deepEqual(CONDITION_TYPES, [
    { value: 'always', label: '无条件' },
    { value: 'online_count', label: '在线人数' },
    { value: 'boss_defeated', label: 'BOSS已击败' },
    { value: 'player_online', label: '指定玩家在线' },
  ])
})

test('服务端默认值与旧版 C# 模型逐字一致（triggerMode=manual / intervalSeconds=0 / dailyTime=00:00）', () => {
  const t = defaultTask()
  assert.equal(t.id, '')
  assert.equal(t.name, '')
  assert.equal(t.enabled, true)
  assert.equal(t.triggerMode, 'manual')
  // 注意：旧版 C# 默认值是 0，而旧版**前端新建表单**给的是 600（TasksView.vue:126）。
  // 这两处差异是旧版本来就有的（规格 §10.4），本件分别照搬，不能混成一个。
  assert.equal(t.intervalSeconds, 0)
  assert.equal(t.dailyTime, '00:00')
  assert.equal(t.execMode, 'sequential')
  assert.deepEqual(t.commands, [])
  assert.deepEqual(t.condition, { type: 'always', not: false, params: { min: 0, max: 9999, bossNames: [], playerNames: [] } })
})

test('condition.params 默认 min=0 / max=9999（旧版 TaskScheduler.cs:92-95）', () => {
  assert.deepEqual(defaultParams(), { min: 0, max: 9999, bossNames: [], playerNames: [] })
  assert.deepEqual(defaultCondition(), { type: 'always', not: false, params: { min: 0, max: 9999, bossNames: [], playerNames: [] } })
})

test('emptyConfig 是 { tasks: [] }（旧版 TaskConfig，TaskScheduler.cs:22-26）', () => {
  assert.deepEqual(emptyConfig(), { tasks: [] })
})

test('BOSS 名单 18 项、顺序与旧版 tasksApi.js 一致', () => {
  assert.equal(BOSS_NAMES.length, 18)
  assert.deepEqual(BOSS_NAMES, [
    '史莱姆王', '克苏鲁之眼', '世界吞噬者', '克苏鲁之脑', '蜂后', '巨鹿',
    '骷髅王', '血肉墙', '史莱姆皇后', '毁灭者', '机械骷髅王', '双子魔眼',
    '世纪之花', '石巨人', '猪龙鱼公爵', '光之女皇', '拜月教教徒', '月亮领主',
  ])
  assert.equal(new Set(BOSS_NAMES).size, 18, 'BOSS 名单不得有重复项')
})

test('BOSS 名单与服端 C# 的 BossNpcIds 键**逐项且同序**一致（跨语言一致性）', async () => {
  const cs = await readFile(path.join(here, '..', 'plugin', 'TaskSchedulerEngine.cs'), 'utf8')
  const block = cs.slice(cs.indexOf('BossNpcIds = new()'), cs.indexOf('};', cs.indexOf('BossNpcIds = new()')))
  const names = [...block.matchAll(/\{\s*"([^"]+)"\s*,\s*NPCID\./g)].map((m) => m[1])
  assert.deepEqual(names, BOSS_NAMES,
    '服端 BossNpcIds 的键必须与宿主/前端的 BOSS_NAMES 完全一致且同序；不一致会让条件永远不满足')
})

test('newTaskId 是 32 位小写十六进制无连字符（旧版 Guid.ToString("N")）', () => {
  const id = newTaskId()
  assert.match(id, /^[0-9a-f]{32}$/)
  assert.notEqual(newTaskId(), newTaskId())
})

test('DAILY_TIME_RE 只接受 00:00-23:59 的严格 HH:mm', () => {
  assert.ok(DAILY_TIME_RE.test('00:00'))
  assert.ok(DAILY_TIME_RE.test('23:59'))
  assert.ok(DAILY_TIME_RE.test('04:00'))
  assert.ok(!DAILY_TIME_RE.test('24:00'))
  assert.ok(!DAILY_TIME_RE.test('3:00'), '旧版是字符串等值比较，"3:00" 永远匹配不上')
  assert.ok(!DAILY_TIME_RE.test('03:0'))
  assert.ok(!DAILY_TIME_RE.test(' 03:00'))
  assert.ok(!DAILY_TIME_RE.test('0300'))
})

// ════════════════════════════════════════════
//  归一
// ════════════════════════════════════════════

test('normalizeTask 把脏输入折成字段齐全的一份，且不做取值裁剪', () => {
  const t = normalizeTask({
    name: 123, enabled: 'yes', triggerMode: '', intervalSeconds: '60',
    dailyTime: null, condition: { type: '', not: 1, params: { min: '3', max: null, bossNames: 'x' } },
    commands: 'not-an-array',
  })
  assert.equal(t.name, '123')
  assert.equal(t.enabled, false, '只有严格的 true 才算启用（避免 "yes"/1 之类的模糊真值）')
  assert.equal(t.triggerMode, 'manual', '空串回落默认值')
  assert.equal(t.intervalSeconds, 60, '数字字符串可转成数字')
  assert.equal(t.dailyTime, '00:00')
  assert.equal(t.condition.type, 'always')
  assert.equal(t.condition.not, false)
  assert.equal(t.condition.params.min, 3)
  assert.equal(t.condition.params.max, 9999)
  assert.deepEqual(t.condition.params.bossNames, [])
  assert.deepEqual(t.commands, [])
})

test('normalizeTask **不接受**客户端塞运行期字段（修 D14：客户端可塞 lastDailyRunAt 让当天不触发）', () => {
  const t = normalizeTask({
    id: 'a', name: 'x',
    lastRunAt: '2026-01-01 00:00:00',
    lastRunStatus: 'success',
    runCount: 999,
    running: true,
    lastDailyRunAt: '2026-01-01 00:00:00',
  })
  assert.equal('lastRunAt' in t, false)
  assert.equal('lastRunStatus' in t, false)
  assert.equal('runCount' in t, false)
  assert.equal('running' in t, false)
  assert.equal('lastDailyRunAt' in t, false)
})

test('normalizeTask 不裁剪非法取值（交给 validateTask/warnings，绝不悄悄改数）', () => {
  const t = normalizeTask({ name: 'x', triggerMode: 'nonsense', execMode: 'nonsense', condition: { type: 'nonsense' } })
  assert.equal(t.triggerMode, 'nonsense')
  assert.equal(t.execMode, 'nonsense')
  assert.equal(t.condition.type, 'nonsense')
})

test('normalizeConfig 丢掉非对象项并逐个归一', () => {
  const c = normalizeConfig({ tasks: [null, 1, 'x', { name: 'ok' }] })
  assert.equal(c.tasks.length, 1)
  assert.equal(c.tasks[0].name, 'ok')
  assert.deepEqual(normalizeConfig(null), { tasks: [] })
  assert.deepEqual(normalizeConfig({}), { tasks: [] })
})

// ════════════════════════════════════════════
//  硬校验（旧版文案逐字）
// ════════════════════════════════════════════

test('三种枚举的报错文案逐字照搬旧版 TaskScheduler.cs:669-680', () => {
  const base = { id: 'a', name: 'x', triggerMode: 'manual', execMode: 'sequential', condition: { type: 'always' } }
  assert.throws(() => validateTask({ ...base, triggerMode: 'bad' }), (e) => e.status === 400 && e.message === 'Invalid triggerMode')
  assert.throws(() => validateTask({ ...base, execMode: 'bad' }), (e) => e.status === 400 && e.message === 'Invalid execMode')
  assert.throws(() => validateTask({ ...base, condition: { type: 'bad' } }), (e) => e.status === 400 && e.message === 'Invalid condition type')
  assert.throws(() => validateTask({ ...base, condition: null }), (e) => e.status === 400 && e.message === 'Invalid condition type')
})

test('服务端补上"任务名称非空"（旧版只有前端强制，见 D13）', () => {
  const t = { id: 'a', name: '   ', triggerMode: 'manual', execMode: 'sequential', condition: { type: 'always' } }
  assert.throws(() => validateTask(t), (e) => e.status === 400 && e.message === '请输入任务名称')
})

test('validateTask 接受四种条件类型与三种触发模式', () => {
  for (const triggerMode of ['manual', 'interval', 'daily']) {
    for (const type of ['always', 'online_count', 'boss_defeated', 'player_online']) {
      for (const execMode of ['sequential', 'concurrent']) {
        assert.doesNotThrow(() => validateTask({ id: 'a', name: 'x', triggerMode, execMode, condition: { type } }))
      }
    }
  }
})

test('strictId 时要求 id 非空；非对象一律 Invalid task format', () => {
  assert.throws(() => validateTask({ id: '', name: 'x', triggerMode: 'manual', execMode: 'sequential', condition: { type: 'always' } }, { strictId: true }),
    (e) => e.message === 'Missing task id')
  assert.throws(() => validateTask(null), (e) => e.message === 'Invalid task format')
  assert.throws(() => validateTask('x'), (e) => e.message === 'Invalid task format')
})

test('httpError 带上 status 与附加字段', () => {
  const e = httpError(409, '冲突', { serverHalfMissing: true })
  assert.equal(e.status, 409)
  assert.equal(e.message, '冲突')
  assert.equal(e.serverHalfMissing, true)
})

// ════════════════════════════════════════════
//  软校验（D13：旧版静默放行，界面看不出来）
// ════════════════════════════════════════════

test('interval 间隔非正数 → 警告（旧版静默放行，任务永不触发）', () => {
  const w = taskWarnings(normalizeTask({ name: 'x', triggerMode: 'interval', intervalSeconds: 0, commands: ['/bc x'] }))
  assert.ok(w.some((s) => s.includes('永远') && s.includes('间隔')), JSON.stringify(w))
})

test('daily 时间格式不对 → 警告', () => {
  const w = taskWarnings(normalizeTask({ name: 'x', triggerMode: 'daily', dailyTime: '25:00', commands: ['/bc x'] }))
  assert.ok(w.some((s) => s.includes('HH:mm')), JSON.stringify(w))
  const ok = taskWarnings(normalizeTask({ name: 'x', triggerMode: 'daily', dailyTime: '03:00', commands: ['/bc x'] }))
  assert.equal(ok.some((s) => s.includes('HH:mm')), false)
})

test('命令列表为空 → 警告（旧版仍会记一条成功记录，这是谎）', () => {
  const w = taskWarnings(normalizeTask({ name: 'x', commands: [] }))
  assert.ok(w.some((s) => s.includes('命令列表为空')))
})

test('空命令条目被指名是第几条', () => {
  const w = taskWarnings(normalizeTask({ name: 'x', commands: ['/bc a', '  ', '/save', ''] }))
  assert.ok(w.some((s) => s.includes('第 2、4 条命令为空')), JSON.stringify(w))
})

test('online_count 区间为空 → 警告', () => {
  const w = taskWarnings(normalizeTask({
    name: 'x', commands: ['/bc x'],
    condition: { type: 'online_count', params: { min: 5, max: 1 } },
  }))
  assert.ok(w.some((s) => s.includes('区间为空')))
})

test('boss_defeated 未选 BOSS / 名字不认识 → 警告（服端遇到不认识的名字判不满足）', () => {
  const a = taskWarnings(normalizeTask({ name: 'x', commands: ['/bc x'], condition: { type: 'boss_defeated', params: { bossNames: [] } } }))
  assert.ok(a.some((s) => s.includes('未选择任何 BOSS')), JSON.stringify(a))
  const b = taskWarnings(normalizeTask({ name: 'x', commands: ['/bc x'], condition: { type: 'boss_defeated', params: { bossNames: ['克苏鲁之眼', '不存在的BOSS'] } } }))
  assert.ok(b.some((s) => s.includes('无法识别的 BOSS 名称') && s.includes('不存在的BOSS')), JSON.stringify(b))
  const c = taskWarnings(normalizeTask({ name: 'x', commands: ['/bc x'], condition: { type: 'boss_defeated', params: { bossNames: ['克苏鲁之眼'] } } }))
  assert.equal(c.some((s) => s.includes('无法识别')), false)
})

test('player_online 未指定玩家 → 警告；指定了则提示区分大小写', () => {
  const a = taskWarnings(normalizeTask({ name: 'x', commands: ['/bc x'], condition: { type: 'player_online', params: { playerNames: [] } } }))
  assert.ok(a.some((s) => s.includes('未指定任何玩家')))
  const b = taskWarnings(normalizeTask({ name: 'x', commands: ['/bc x'], condition: { type: 'player_online', params: { playerNames: ['Alice'] } } }))
  assert.ok(b.some((s) => s.includes('区分大小写')))
})

test('manual 模式提示"不会自动触发"（旧版界面对此没有任何说明）', () => {
  const w = taskWarnings(normalizeTask({ name: 'x', triggerMode: 'manual', commands: ['/bc x'] }))
  assert.ok(w.some((s) => s.includes('不会自动触发')))
})

test('configWarnings 逐条带任务名与 id，便于界面定位', () => {
  // 注意这条任务本来就该有两条警告（manual 不自动触发 + 命令列表为空），
  // 这里断言的是"每条警告都挂上了定位信息"，不是条数。
  const t = normalizeTask({ id: 't1', name: '任务甲', commands: [] })
  const w = configWarnings({ tasks: [t] })
  assert.equal(w.length, taskWarnings(t).length)
  assert.ok(w.length >= 2)
  for (const row of w) {
    assert.equal(row.taskId, 't1')
    assert.equal(row.taskName, '任务甲')
    assert.ok(typeof row.warning === 'string' && row.warning.length > 0)
  }
})

test('configWarnings 对未命名任务用 (未命名) 占位，界面不至于显示空白', () => {
  const w = configWarnings({ tasks: [normalizeTask({ commands: [] })] })
  assert.ok(w.length > 0)
  assert.equal(w[0].taskName, '(未命名)')
})

// ════════════════════════════════════════════
//  下发载荷
// ════════════════════════════════════════════

test('toGamePayload 产出 { version, tasks(JSON 串), ts }', () => {
  const p = toGamePayload({ tasks: [{ name: 'x' }] }, 7)
  assert.equal(p.version, 7)
  assert.equal(typeof p.tasks, 'string')
  const parsed = JSON.parse(p.tasks)
  assert.equal(parsed.length, 1)
  assert.equal(parsed[0].name, 'x')
  assert.ok(typeof p.ts === 'string' && p.ts.length > 0)
  // 载荷里不得夹带运行期字段（服端独占）
  assert.equal('lastRunAt' in parsed[0], false)
  assert.equal('running' in parsed[0], false)
})

test('toGamePayload 会先归一，脏配置不会把非数组塞下去', () => {
  const p = toGamePayload({ tasks: 'oops' }, 1)
  assert.deepEqual(JSON.parse(p.tasks), [])
})

test('toGamePayload 收到**数组**时当场报错，绝不静默下发空配置（本仓真实踩过的缺陷）', () => {
  // 曾经的写法 toGamePayload(entry.tasks, v) 会把数组归一成 { tasks: [] }，
  // 于是每次下发的都是空任务列表，服端被静默清空而宿主显示"已生效"。
  assert.throws(() => toGamePayload([{ name: 'x' }], 1), /需要配置对象/)
  assert.throws(() => toGamePayload([], 1), /需要配置对象/)
})

test('payloadTooLarge 超限时给出可读原因（含实际字符数与上限）', () => {
  const small = { tasks: '[]' }
  assert.equal(payloadTooLarge(small), null)
  const big = { tasks: 'x'.repeat(MAX_PAYLOAD_CHARS + 1) }
  const msg = payloadTooLarge(big)
  assert.ok(msg && msg.includes(String(MAX_PAYLOAD_CHARS)))
  assert.ok(msg.includes('拆分任务'))
})
