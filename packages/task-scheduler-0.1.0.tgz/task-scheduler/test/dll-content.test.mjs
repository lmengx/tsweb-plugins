/**
 * DLL 内容断言（防"DLL 里其实没有这段代码"）
 *
 * 为什么必须有这条测试：
 *   本仓实测发生过这种缺陷——plugins/qq-bind/plugin/QqBind.dll（27136 B）的**二进制里
 *   根本没有** QqPromotion / TryPromoteOnLogin，而同目录 obj/Release/QqBind.dll
 *   里是有的。也就是说"会被打包下发的 DLL 里没有晋升代码"，而构建、打包、
 *   `--check` 全程没有任何报错（根因是打包器从 bin/Release/<tfm>/ 回拷时用了陈旧产物）。
 *   → 于是：**编译通过 ≠ 功能在包里**。这里对**实际会被打包的那个文件**做字节层断言。
 *
 * 判据设计（阳性对照，避免"扫了个空文件也算过"）：
 *   - 阳性对照：几个与本功能无关、但必然存在的元数据字符串（基类名 / 覆写方法名 / 框架类型名）。
 *     对照只要有一个没命中，说明扫错了文件或扫描本身失效，测试直接失败（不是"缺功能"）。
 *   - 目标串：调度器内核、条件求值、命令执行分类、11 条 REST 路由、权限名、执行记录表名与
 *     列名、旧版配置迁移路径、插件身份（程序集/命名空间/作者/描述）、以及**逐字沿用旧版的中文文案**。
 *   - 阴性对照：
 *       ① 一个肯定不存在的串必须扫不到 —— 证明"扫得到"这件事本身是有区分度的；
 *       ② 另一个插件的活儿必须扫不到（player_daily_stat / daily_min + 1 / hourly_online_snapshot）
 *          —— 证明没有从 promotion / online-stats 复制粘贴；
 *       ③ 另外几个插件的配置文件名与命名空间必须扫不到 —— 证明没有跨插件耦合。
 *
 * ★★ 本插件的三处字节层特殊性（都不是"偷懒"，是字节事实，逐条说明）★★
 *   1. **建表语句在 DLL 里不是一个连续字面量。**
 *      TaskSchedulerLogStore.CreateTable 用的是插值逐字字符串 `$@"CREATE TABLE IF NOT EXISTS {Table} ..."`，
 *      而 Roslyn **不会**把插值洞（{Table}）折叠进相邻字面量：#US 堆里是两段独立的 blob
 *      （实测："CREATE TABLE IF NOT EXISTS " 在奇数偏移，"task_execution_logs" 是另一段，两者之间
 *      隔着堆的长度前缀）。因此 `CREATE TABLE IF NOT EXISTS task_execution_logs` 这个合并串
 *      在字节里**物理上不存在**，直接断言它必然失败。
 *      → 改用的等价判据（见下方 SQL 用例）：把字节按**双编码 × 双对齐**解成文本、把 #US 堆的
 *        长度前缀等非 ASCII 片段归一成空格后，断言 /CREATE TABLE IF NOT EXISTS\s+task_execution_logs\s*\(/
 *        能命中（证明"建表头部 + 表名 + 左括号"是按 DDL 顺序发出的），
 *        并且 13 个列定义必须在另一对齐下**按源码顺序**逐个命中。
 *        表名与 DDL 模板的绑定关系（`Table` 常量 == "task_execution_logs"、模板里确实用 {Table}）
 *        由 test/dll-source.test.mjs 在源码层断言。
 *   2. **中文文案只出现在 #US 堆（UTF-16LE），不会以 UTF-8 出现。**
 *      实测：'自动任务系统已启动，共 ' / '成功' / '不适用' 等全部只以 UTF-16LE 命中。
 *      所以除了双编码扫描，另有一条用例专门断言这些文案**必须以 UTF-16LE 命中**
 *      （避免"两字节中文串恰好被 UTF-8 字节序列蒙中"这种假阳性）。
 *   3. **emoji 不在字节层断言。** 把任意 PE 字节按 UTF-16 解码会造出大量落在
 *      U+2600-U+27BF / U+2B00-U+2BFF 的假码点（实测解码出上百个，例如 U+2700、U+2B2F、
 *      U+2B14、U+2728 这类，全部是长度前缀/元数据字节的巧合），那个判据没有区分度。
 *      emoji 禁令改在源码层断言（test/dll-source.test.mjs，覆盖所有 .cs 与 .js/.mjs 文件）。
 *
 * 局限（如实说明，不要当成运行时保证）：本机没有 TShock 运行环境，这条测试只能证明
 *   "这段代码在 DLL 的元数据/字符串堆里"，**不能**证明它在真实 TShock 上按预期触发、
 *   求值条件或执行命令。触发语义的证据在 test/dll-source.test.mjs（源码层），
 *   运行期行为需要真实服务器才能验证。
 *
 * 运行：node test/dll-content.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile, readdir, stat } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginDir = path.join(here, '..', 'plugin')
/** 发行目录里的镜像（同步过后两份必须逐字节一致） */
const mirrorPluginDir = path.resolve(here, '..', '..', '..', 'tsweb-dist-lite', 'plugins', 'task-scheduler', 'plugin')

/** 本插件程序集名（TaskScheduler.csproj 的 <AssemblyName>TaskScheduler</AssemblyName>） */
const ASSEMBLY = 'TaskScheduler'

/**
 * 阳性对照：与本功能无关但必然出现在本程序集元数据里的名字。
 * 注意 'TerrariaPlugin' 是基类名、'Dispose'/'Initialize' 是覆写方法名、
 * 'SecureRestCommand' 是框架类型名——它们的存在只说明"这确实是一个编译好的 TShock 插件程序集"。
 * （本件不挂钩 PlayerPostLogin —— 它挂的是 GameUpdate / GamePostInitialize，
 *   所以那两个名字放在目标串里而不是阳性对照里。）
 */
const POSITIVE_CONTROLS = ['TerrariaPlugin', 'Initialize', 'Dispose', 'SecureRestCommand']

/**
 * 目标串：调度器内核 / 条件求值 / 命令执行分类 / 路由 / 权限 / SQL / 迁移路径 / 文案。
 * 每条都是"这个功能真的进了将被打包下发的 DLL"的正面证据。
 */
const TARGETS = [
  // ── 类型与方法（游戏服半的实现本体）──
  ['TaskSchedulerPlugin', '插件入口类型（注册 11 条路由并启动调度器）'],
  ['TaskSchedulerEngine', '调度 / 条件 / 执行内核'],
  ['TaskSchedulerEndpoints', 'REST 端点实现'],
  ['TaskLogStore', '执行记录落库（表 task_execution_logs）'],
  ['TaskConfigStore', '服端任务配置存储（落盘 + 旧版迁移）'],
  ['MainThreadDispatcher', '命令本体投递到游戏主线程的执行器（D20 的修法）'],
  ['SqlCompat', '跨库方言兼容助手（SQLite / MySQL / Postgres）'],
  ['AutoTask', '单个任务模型'],
  ['TaskCondition', '执行前提模型（单一条件 + 取否）'],
  ['ConditionParams', '条件参数模型（min/max/bossNames/playerNames）'],
  ['TaskCommandLog', '单条命令结果模型（含 status/statusText/errorKind）'],
  ['TaskExecutionLog', '一次执行记录模型'],
  ['BossNpcIds', 'BOSS 名 → NPCID 的字典（boss_defeated 条件用）'],
  ['TryRunManual', '手动执行入口（/data/tasks/run 调用它）'],
  ['EvaluateCondition', '条件求值'],
  ['NormalizeCommand', '命令规范化（自动补执行符号前缀）'],
  ['ExecuteSingleCommand', '单条命令执行（执行前分类 + 只降不升的二次校验）'],
  ['ApplySnapshot', '宿主下发配置的原子应用（按 id 保留运行期状态）'],
  ['IsDailyTimeDue', 'daily 到点判定（字符串等值比较 + 当天去重）'],
  ['AutoIncrementIdColumn', '自增主键列定义（SQLite/MySQL/Postgres 三方言，旧版缺 Postgres 支）'],
  ['CreateIndexIfNotExists', '幂等建索引（MySQL 先查 information_schema）'],
  ['SweepInterrupted', '启动时把遗留 running 记录标成 interrupted（D26）'],
  ['ClassifyFromOutput', 'TShock 拒绝文案的兜底识别（只降不升）'],
  ['ResolveExecutorGroup', '执行身份用户组的解析与回落（D8）'],
  ['KnownBossNames', '服端认得的 BOSS 名（端点回显给宿主）'],
  ['TriggerCount', '进程内累计触发次数（/status 用）'],
  ['CreateTable', '建表入口（幂等，存量库上是 no-op）'],
  ['InsertStart', '执行开始时先落一条 running 记录（D26）'],
  ['GameUpdate', '主线程排空的挂钩事件名'],
  ['GamePostInitialize', '世界就绪的门（D21）'],

  // ── REST 路由与权限（旧版 7 条 + 别名 2 条 + 新增协议 2 条）──
  ['/data/tasks/snapshot', '新协议：接收宿主下发的整份任务配置'],
  ['/data/tasks/status', '新协议：服端自证（配置 + 调度器状态 + 迁移来源）'],
  ['/data/tasks/list', '旧版契约：任务列表（不含 commands）'],
  ['/data/tasks/get', '旧版契约：单个任务完整定义'],
  ['/data/tasks/save', '旧版契约：创建 / 更新'],
  ['/data/tasks/delete', '旧版契约：删除'],
  ['/data/tasks/run', '旧版契约：手动执行'],
  ['/data/tasks/log', '旧版契约：执行记录分页'],
  ['/data/tasks/log/detail', '旧版契约：执行记录详情'],
  ['/data/tasks/logs', '旧版契约的别名（需求文字里的命名）'],
  ['/data/tasks/logs/detail', '旧版契约的别名（需求文字里的命名）'],
  ['data.rest.invsee', 'REST 权限名（与 base / promotion / online-stats 的 data.* 端点一致）'],

  // ── 日志文案（[TaskScheduler] 前缀 + 正文逐字沿用旧版）──
  ['[TaskScheduler]', '日志前缀常量（独立插件身份，避免与其它 TSWeb 系插件混淆）'],
  ['自动任务系统已启动，共 ', '启动日志正文'],
  ['自动任务系统已停止', '停止日志正文'],
  ['任务已保存: ', '保存任务的日志正文'],
  ['任务已删除: ', '删除任务的日志正文'],
  ['任务手动执行: ', '手动执行的日志正文'],
  ['写入任务执行记录失败', '执行记录落库失败的日志（失败永不静默）'],
  ['世界已就绪，自动任务开始参与调度', '世界就绪的日志（D21 的门置位处）'],

  // ── 端点错误文案与状态文案（旧版逐字，按关键字检索日志/排障要用）──
  ['任务不存在', '404：任务 id 不存在'],
  ['任务正在执行中', '400：任务正在执行，无法重复触发'],
  ['任务正在执行中，无法删除', '400：执行中的任务不允许删除'],
  ['任务已保存', '成功回包文案'],
  ['任务已删除', '成功回包文案'],
  ['任务已开始执行', '手动触发的成功回包文案'],
  ['Missing task parameter', '400：缺少 task 参数（旧版英文文案）'],
  ['Invalid task format', '400：task 不是合法 JSON（旧版英文文案）'],
  ['Invalid triggerMode', '400：triggerMode 非法（旧版英文文案）'],
  ['Invalid execMode', '400：execMode 非法（旧版英文文案）'],
  ['Invalid condition type', '400：条件类型非法（旧版英文文案）'],
  ['记录不存在', '404：执行记录 id 不存在'],

  // ── 单条命令的三种结论与机器可读分类（本件必改缺陷之二的落点）──
  ['成功', '单条命令成功（StatusText）'],
  ['失败', '单条命令失败（StatusText）'],
  ['不适用', '单条命令不适用（AllowServer=false 的仅游戏内命令）'],
  ['not_applicable', 'errorKind：仅游戏内命令（TShock 一定会拒绝）'],
  ['unknown_command', 'errorKind：TShock 里没注册的命令'],
  ['permission_denied', 'errorKind：执行身份所在组权限不足'],
  ['wait_too_long', 'errorKind：wait 超过 24 小时上限（旧版无上限，会占住线程近 25 天）'],
  ['wait_overflow', 'errorKind：wait 参数超出 int 范围'],
  ['empty_command', 'errorKind：命令条目为空（旧版会抛下标越界）'],
  ['executor_unavailable', 'errorKind：构造不出执行身份'],
  ['main_thread', 'errorKind：主线程执行超时 / 异常'],
  ['no_result', 'errorKind：并发模式下拿不到某条命令的结果（兜底如实记失败）'],
  ['parse_error', 'errorKind：旧记录 CommandResults 解析失败（详情页降级显示）'],
  ['You must use this command in-game', 'TShock 的仅游戏内拒绝文案（二次校验的锚点）'],
  ['You do not have access to this command', 'TShock 的权限不足拒绝文案（二次校验的锚点）'],
  ['Invalid command entered', 'TShock 的未知命令拒绝文案（二次校验的锚点）'],
  ['interrupted', '启动收尾把遗留 running 记录标成的终态'],

  // ── 触发模式 / 执行模式 / 状态字面量 ──
  ['manual', 'triggerMode：手动（自动路径恒不触发）'],
  ['interval', 'triggerMode：按间隔'],
  ['daily', 'triggerMode：每日 HH:mm'],
  ['sequential', 'execMode：顺序执行'],
  ['concurrent', 'execMode：并发执行（每条命令一个 Task + WaitAll）'],
  ['running', '执行记录状态：执行中（先落一条，崩溃也留痕）'],
  ['skipped', '执行记录状态：条件不满足被跳过'],
  ['success', '执行记录状态：成功'],
  ['failed', '执行记录状态：失败'],
  ['always', '条件类型：无条件'],
  ['online_count', '条件类型：在线人数闭区间'],
  ['boss_defeated', '条件类型：所选 BOSS 全部被击败'],
  ['player_online', '条件类型：指定玩家全部在线'],

  // ── 配置与旧版迁移路径 ──
  ['task-scheduler-config.json', '本件自己的配置文件（TShock.SavePath 下）'],
  ['TSWeb', '旧版迁移路径片段 1（<SavePath>/TSWeb/Tasks/tasks.json）'],
  ['Tasks', '旧版迁移路径片段 2'],
  ['tasks.json', '旧版迁移路径片段 3（另一个候选路径是 <SavePath>/tasks.json）'],
  ['legacy-alt', '配置来源标记：SavePath 根下那份旧文件'],

  // ── SQL（表名 / 语句片段 / 索引名 / 方言关键字）──
  ['task_execution_logs', '执行记录表名（旧版同名，历史记录继续可见）'],
  ['CREATE TABLE IF NOT EXISTS ', '建表语句头部（插值洞 {Table} 之前的字面量）'],
  ['INSERT INTO ', '插入语句片段'],
  ['SELECT TaskId, COUNT(*) AS cnt FROM ', '按任务统计记录条数的 SELECT'],
  ['SELECT COUNT(*) AS cnt FROM ', '分页总条数的 SELECT'],
  ['information_schema.statistics', 'MySQL 分支：先查索引是否已存在'],
  ['CREATE INDEX IF NOT EXISTS ', 'SQLite / Postgres 分支的幂等建索引'],
  ['idx_tel_taskid', '索引名 1（旧版一个索引都没建，D12）'],
  ['idx_tel_triggered', '索引名 2'],
  ['AUTOINCREMENT', 'SQLite 自增主键'],
  ['AUTO_INCREMENT', 'MySQL 自增主键'],
  ['SERIAL PRIMARY KEY', 'Postgres 自增主键（旧版缺这一支，Postgres 下建表会失败 D28）'],

  // ── boss_defeated 依赖的图鉴读取（宿主进程读不到，所以必须落在游戏服半）──
  // 说明：源码里的写法是 Main.BestiaryTracker.Kills.GetKillCount(ContentSamples.NpcBestiaryCreditIdsByNpcNetIds[...])，
  // 但编译成 IL 之后它是一个个 MemberRef（类型名/成员名分开进 #Strings 堆），
  // 那串带点的完整调用**不以连续字面量存在**于 DLL 里，所以这里断言四个成员名；
  // 完整调用链的确切写法由 test/dll-source.test.mjs 在源码层断言。
  ['BestiaryTracker', '图鉴击杀数的取数对象（Main.BestiaryTracker）'],
  ['GetKillCount', '图鉴击杀数的读取方法'],
  ['ContentSamples', '图鉴 id 映射的取数类型'],
  ['NpcBestiaryCreditIdsByNpcNetIds', '图鉴条目 id 的映射（NPCID → 图鉴 id）'],

  // ── 插件身份 ──
  ['TaskScheduler', '程序集名 / 插件名（决定 DLL 文件名）'],
  ['TsWebTaskScheduler', '根命名空间'],
  ['TSWeb', '作者'],
  ['按手动/间隔/每日触发', '插件描述正文（说明本件的职责）'],
]

/**
 * 阴性对照：任何情况下都不该出现在本 DLL 里的串。
 * ① 编造的哨兵串：证明扫描有区分度
 * ② 另一个插件的活儿：证明没有从 online-stats / promotion 复制粘贴（同名表会被双写、双倍计时长）
 * ③ 另外几个插件的配置文件名 / 命名空间：证明没有跨插件耦合
 */
const NEGATIVE_CONTROLS = [
  ['TSWEB_DLL_SCAN_NEGATIVE_CONTROL_9f3ab7c1', '编造的哨兵串（阴性对照：证明命中是有区分度的）'],
  ['daily_min + 1', '游玩时长自增片段（那是 online-stats 插件的职责，本件出现即说明复制粘贴）'],
  ['INSERT INTO player_daily_stat', '写入游玩时长表的语句（那是 online-stats 的职责）'],
  ['player_daily_stat', '游玩时长统计表（本件与它无关，出现即说明复制粘贴）'],
  ['hourly_online_snapshot', '整点在线快照表（online-stats 的另一项职责）'],
  ['promotion-config.json', 'promotion 插件的配置文件名'],
  ['qqbind-snapshot.json', 'qq-bind 插件只读的绑定快照文件名'],
  ['TsWebQqBind', 'qq-bind 的程序集命名空间（本件不该与它耦合）'],
  ['TsWebPromotion', 'promotion 的程序集命名空间（本件不该与它耦合）'],
]

/**
 * 18 个 BOSS 的中文名，**顺序与源码 TaskSchedulerEngine.cs 的 BossNpcIds 字典一致**。
 * 顺序也要断言的理由：这份字典是"服端认得的 BOSS 名"的唯一来源，
 * /data/tasks/status 会把它整份回显给宿主；顺序变了虽然不影响匹配，
 * 但说明有人改动过这张表，需要一眼能看出来。
 */
const BOSS_NAMES = [
  '史莱姆王',
  '克苏鲁之眼',
  '世界吞噬者',
  '克苏鲁之脑',
  '蜂后',
  '巨鹿',
  '骷髅王',
  '血肉墙',
  '史莱姆皇后',
  '毁灭者',
  '机械骷髅王',
  '双子魔眼',
  '世纪之花',
  '石巨人',
  '猪龙鱼公爵',
  '光之女皇',
  '拜月教教徒',
  '月亮领主',
]

/**
 * 建表语句里的列定义，**顺序与源码 TaskSchedulerLogStore.CreateTable 的 SQL 模板一致**
 * （Id 列的自增部分被 {SqlCompat.AutoIncrementIdColumn} 插值洞占掉，所以 Id 只断言列名本身）。
 */
const DDL_COLUMNS = [
  'TaskId VARCHAR(64) NOT NULL',
  'TaskName VARCHAR(255) NOT NULL',
  'TriggeredAt VARCHAR(19) NOT NULL',
  'TriggerMode VARCHAR(16) NOT NULL',
  'ConditionResult INTEGER NOT NULL',
  'Skipped INTEGER NOT NULL DEFAULT 0',
  'Status VARCHAR(16) NOT NULL',
  'StartedAt VARCHAR(19)',
  'CompletedAt VARCHAR(19)',
  'DurationMs INTEGER DEFAULT 0',
  'CommandResults TEXT',
  'ErrorSummary TEXT',
  'CreatedAt TEXT',
]

/** 任务要求逐项断言的列名（Id 等 14 个），与上面的定义表交叉校验用 */
const DDL_COLUMN_NAMES = [
  'Id', 'TaskId', 'TaskName', 'TriggeredAt', 'TriggerMode', 'ConditionResult',
  'Skipped', 'Status', 'StartedAt', 'CompletedAt', 'DurationMs',
  'CommandResults', 'ErrorSummary', 'CreatedAt',
]

async function findDll() {
  let entries = []
  try {
    entries = await readdir(pluginDir)
  } catch (err) {
    assert.fail(`读不到 plugin 目录：${pluginDir}（${err.message}）`)
  }
  const dlls = entries.filter((f) => f.toLowerCase().endsWith('.dll'))
  assert.ok(
    dlls.length > 0,
    `plugin/ 下没有任何 .dll —— 请先构建：\n`
    + `    node scripts/pack-plugin.mjs task-scheduler --check\n`
    + `  （或 dotnet build plugins/task-scheduler/plugin/TaskScheduler.csproj -c Release）`,
  )
  assert.equal(dlls.length, 1, `plugin/ 下应只有本插件自己的 DLL（不许留下旧名产物），实际有：${dlls.join(', ')}`)
  assert.equal(dlls[0], `${ASSEMBLY}.dll`, `DLL 文件名必须是 ${ASSEMBLY}.dll`)
  return path.join(pluginDir, dlls[0])
}

/**
 * 在字节里找 .NET 的字符串——**必须同时扫两种编码**，否则会得出错误结论：
 *   - 类型名 / 方法名 / 字段名等元数据字符串 → #Strings 堆，**UTF-8**
 *   - 字符串字面量（如 `"task_execution_logs"`、`"成功"`）→ #US 堆，**UTF-16LE**
 * 实测教训（照 promotion 的 dll-content.test.mjs 记下来）：先用 PowerShell 的
 * `[Encoding]::UTF8.GetString(...).IndexOf('owner')` 扫，竟然"命中"了——因为 UTF-16LE 的
 * "o\0w\0n\0e\0r" 解码后含 NUL，而 .NET 的 `String.IndexOf(string)` 默认是**文化敏感**比较、
 * 会忽略零权字符（NUL），于是给出了假阳性。所以这里用 Node 按字节扫，并显式覆盖两种编码。
 */
function containsString(buf, s) {
  return buf.indexOf(Buffer.from(s, 'utf8')) >= 0 || buf.indexOf(Buffer.from(s, 'utf16le')) >= 0
}

/** 只按 UTF-16LE 找（字符串字面量必然在 #US 堆里；用于短中文串，避免字节巧合造成假阳性） */
function containsUtf16(buf, s) {
  return buf.indexOf(Buffer.from(s, 'utf16le')) >= 0
}

/**
 * 把 DLL 字节按**双编码 × 双对齐**解成文本，并把非 ASCII 归一成空格。
 *
 * 为什么必须双对齐：字符串字面量在 #US 堆里是 UTF-16LE，而该堆里每个 blob 前面有压缩长度前缀、
 * blob 起点**不保证是偶数**（实测本 DLL 的建表头部就在奇数偏移 71609）。只按 offset 0 解一次，
 * 那一段会整段解成乱码，于是"抽不到建表语句"而让断言变成空断言（假通过）。
 *
 * 为什么可以归一去非 ASCII：#US 堆里 blob 之间的长度前缀会被解码成孤立的高位字符，
 * 而本插件的建表语句（表名 + 列名 + 类型）**全为 ASCII**，所以把非 ASCII 压成空格后，
 * "片段之间的先后顺序"依然可判定，且不会被长度前缀干扰。
 */
function decodedSqlTexts(buf) {
  return [
    buf.toString('latin1'),
    buf.toString('utf16le').replace(/\u0000/g, ''),
    buf.subarray(1).toString('utf16le').replace(/\u0000/g, ''),
  ].map((t) => t.replace(/[^\x20-\x7e]+/g, ' '))
}

/**
 * 从 DLL 字节里抽 SQL 语句片段（照 promotion 的 dll-content.test.mjs 的做法）。
 *
 * 抽取范围：以 SELECT/INSERT/UPDATE/DELETE/CREATE 开头、到串尾或 240 字符的一段；
 * 只保留真的像 SQL 的片段（含 FROM / INTO / TABLE / SET 之类）。
 * 用途：① 证明"建表语句确实在字节里"（而不是断言了别的东西）；② 让"必须能被抽到"这件事
 * 成为非空断言（抽不到 0 条时，后面的反面断言不可信）。
 */
function extractSqlStatements(buf) {
  const out = []
  for (const text of decodedSqlTexts(buf)) {
    const re = /\b(?:SELECT|INSERT|UPDATE|DELETE|CREATE)\b[^\u0000]{0,240}/gi
    let m
    while ((m = re.exec(text)) !== null) {
      const sql = m[0].replace(/[\u0000-\u001f]+/g, ' ').trim()
      if (/\b(FROM|INTO|TABLE|SET)\b/i.test(sql)) out.push(sql)
    }
  }
  return out
}

test('插件 DLL 存在且体积合理（空文件/半截文件直接失败）', async () => {
  const dll = await findDll()
  const st = await stat(dll)
  assert.ok(st.size > 4096, `DLL 体积异常小（${st.size} B），疑似构建失败或占位文件：${dll}`)
  const buf = await readFile(dll)
  assert.equal(buf.subarray(0, 2).toString('latin1'), 'MZ', '不是合法的 PE 文件（应为 MZ 开头）')
})

test('阳性对照：与本功能无关的元数据字符串必须命中（证明扫描有效、扫的是插件程序集）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const missing = POSITIVE_CONTROLS.filter((s) => !containsString(buf, s))
  assert.deepEqual(
    missing, [],
    `阳性对照未命中：${missing.join('、')} —— 说明扫描本身失效或扫错了文件，此时"目标串命中"没有意义`,
  )
})

test('阴性对照：编造的哨兵串必须扫不到（证明命中是有区分度的）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  assert.equal(containsString(buf, NEGATIVE_CONTROLS[0][0]), false, '阴性对照居然命中了，扫描逻辑不可信')
})

test('目标串：调度器/条件/执行分类/路由/SQL/迁移路径/文案必须都在 DLL 里', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const missing = TARGETS.filter(([s]) => !containsString(buf, s))
  assert.deepEqual(
    missing.map(([s]) => s), [],
    '自动任务的实现没有真正进到将被打包下发的 DLL 里（这正是 qq-bind 实测踩过的缺陷：\n'
    + '  plugin/QqBind.dll 里没有 QqPromotion/TryPromoteOnLogin，而 obj/Release 里有）。\n'
    + '  缺的是：\n'
    + missing.map(([s, why]) => `    - ${s}：${why}`).join('\n')
    + '\n  修复方向：删掉 plugin/bin、plugin/obj 后重建（或加 --rebuild），并确认打包不再从陈旧 bin 回拷。',
  )
})

test('中文文案必须以 UTF-16LE 命中（#US 堆的字面量，排除字节巧合造成的假阳性）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  // 这些串短到"UTF-8 字节序列恰好被蒙中"是有可能的；短中文串尤其如此，
  // 所以专门断言它们作为 UTF-16LE 字面量存在（.NET 把字符串字面量放进 #US 堆）。
  const mustBeUtf16 = [
    ['成功', '单条命令成功'],
    ['失败', '单条命令失败'],
    ['不适用', '单条命令不适用'],
    ['任务不存在', '端点 404 文案'],
    ['任务已保存', '端点成功回包文案'],
    ['任务已删除', '端点成功回包文案'],
    ['任务已开始执行', '手动触发成功回包文案'],
    ['记录不存在', '执行记录 404 文案'],
    ['任务正在执行中', '重复触发拒绝文案'],
    ['任务正在执行中，无法删除', '删除执行中任务的拒绝文案'],
    ['[TaskScheduler]', '日志前缀常量'],
    ['自动任务系统已启动，共 ', '启动日志正文'],
    ['自动任务系统已停止', '停止日志正文'],
    ['任务已保存: ', '保存日志正文'],
    ['任务已删除: ', '删除日志正文'],
    ['任务手动执行: ', '手动执行日志正文'],
    ['写入任务执行记录失败', '落库失败日志正文'],
    ['世界已就绪，自动任务开始参与调度', '世界就绪日志正文'],
    ['Missing task parameter', '旧版英文文案'],
    ['Invalid triggerMode', '旧版英文文案'],
    ['Invalid execMode', '旧版英文文案'],
    ['Invalid condition type', '旧版英文文案'],
    ['Invalid task format', '旧版英文文案'],
  ]
  const missing = mustBeUtf16.filter(([s]) => !containsUtf16(buf, s))
  assert.deepEqual(
    missing.map(([s]) => s), [],
    '以下文案没有以 UTF-16LE 字面量出现在 DLL 里（#US 堆）：\n'
    + missing.map(([s, why]) => `    - ${s}：${why}`).join('\n')
    + '\n  这通常说明文案被改写了、或被挪到了别的程序集。',
  )
})

test('BOSS 名称表：18 个中文名逐个命中，且顺序与源码一致（服端认得的名字就是它）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  assert.equal(BOSS_NAMES.length, 18, 'BOSS 名表必须是 18 项（与旧版 TaskScheduler.cs:139-159 一致）')

  const missing = BOSS_NAMES.filter((n) => !containsUtf16(buf, n))
  assert.deepEqual(missing, [], `BOSS 名称表在 DLL 里缺项：${missing.join('、')}（boss_defeated 条件会恒 false）`)

  // 顺序断言：字典初始化器按源码顺序把这些名字写进 #US 堆，
  // 因此它们的 UTF-16LE 首次出现偏移必须是严格递增的。
  const offsets = BOSS_NAMES.map((n) => buf.indexOf(Buffer.from(n, 'utf16le')))
  assert.ok(offsets.every((o) => o >= 0), '存在无法定位的 BOSS 名（上一行的命中判定与这里不一致）')
  for (let i = 1; i < offsets.length; i++) {
    assert.ok(
      offsets[i] > offsets[i - 1],
      `BOSS 名称顺序与源码不一致：第 ${i} 项「${BOSS_NAMES[i]}」(偏移 ${offsets[i]})`
      + ` 不晚于第 ${i - 1} 项「${BOSS_NAMES[i - 1]}」(偏移 ${offsets[i - 1]})。\n`
      + '  这份字典是服端"认得的 BOSS 名"的唯一来源，顺序变动说明有人改过这张表，需要复核。',
    )
  }
})

test('SQL 建表语句：完整 DDL 与全部列名必须能从字节里扫出来（双编码 × 双对齐）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)

  // 1) 表名（常量 Table 的值）与建表语句头部（插值洞之前的字面量）
  assert.equal(containsString(buf, 'task_execution_logs'), true,
    'DLL 里没有 task_execution_logs —— 执行记录表名常量缺失，落库逻辑等于没做')
  assert.equal(containsString(buf, 'CREATE TABLE IF NOT EXISTS '), true,
    'DLL 里没有 "CREATE TABLE IF NOT EXISTS " —— 建表语句缺失或不是幂等写法')

  // 2) "建表头部 + 表名 + 左括号"必须按 DDL 顺序出现。
  //    注意：`$@"CREATE TABLE IF NOT EXISTS {Table} ..."` 的插值洞不会被 Roslyn 折叠，
  //    #US 堆里是两段独立 blob（中间夹着堆的长度前缀），所以**不能**断言
  //    `CREATE TABLE IF NOT EXISTS task_execution_logs` 这个合并串，
  //    只能按下面这条归一化正则断言"三段相邻且顺序正确"（理由见文件头注释第 1 条）。
  const ddlHeadRx = /CREATE TABLE IF NOT EXISTS\s+task_execution_logs\s*\(/
  const texts = decodedSqlTexts(buf)
  const headVariants = texts.filter((t) => ddlHeadRx.test(t))
  assert.ok(
    headVariants.length >= 1,
    'DLL 字节里读不出 "CREATE TABLE IF NOT EXISTS <表名> (" 的顺序。\n'
    + '  说明：DDL 是插值字符串，字节里是 "CREATE TABLE IF NOT EXISTS " 与 "task_execution_logs"\n'
    + '  两段独立字面量，因此判据是"两段按 DDL 顺序相邻"而不是那个物理上不存在的合并串。\n'
    + '  这里一条都对不上，说明建表语句没进 DLL，或表名与 DDL 模板被拆散/改写过。',
  )

  // 3) 13 个列定义必须逐个命中，且**按源码顺序**出现在同一份解码文本里
  const columnVariant = texts.find((t) => DDL_COLUMNS.every((d) => t.includes(d)))
  assert.ok(
    columnVariant,
    'DLL 字节里没有一份可读文本包含全部 13 个列定义，缺的是：\n'
    + DDL_COLUMNS.filter((d) => !texts.some((t) => t.includes(d))).map((d) => `    - ${d}`).join('\n')
    + '\n  执行记录表的列结构是"旧版历史记录继续可见"的前提（表名与列名都必须逐字沿用旧版）。',
  )
  const colOffsets = DDL_COLUMNS.map((d) => columnVariant.indexOf(d))
  for (let i = 1; i < colOffsets.length; i++) {
    assert.ok(
      colOffsets[i] > colOffsets[i - 1],
      `建表语句的列顺序与源码不一致：第 ${i} 列「${DDL_COLUMNS[i]}」出现在第 ${i - 1} 列「${DDL_COLUMNS[i - 1]}」之前。\n`
      + '  列顺序变动意味着有人改过表结构，存量库上的 CREATE TABLE IF NOT EXISTS 是 no-op，'
      + '  新列不会生效、旧表会对不上，必须复核。',
    )
  }

  // 4) 逐项断言任务要求的 14 个列名（Id 的自增部分由 AutoIncrementIdColumn 插值提供）
  const missingCols = DDL_COLUMN_NAMES.filter(
    (c) => c === 'Id'
      ? !texts.some((t) => /(\s|^)Id\s/.test(t))
      : !DDL_COLUMNS.some((d) => d.startsWith(`${c} `)),
  )
  assert.deepEqual(missingCols, [], `建表语句缺少列：${missingCols.join('、')}`)

  // 5) 自增主键必须至少命中一种方言写法（SqlCompat.AutoIncrementIdColumn 的三条分支）
  const autoInc = ['AUTOINCREMENT', 'AUTO_INCREMENT', 'SERIAL PRIMARY KEY'].filter((k) => containsString(buf, k))
  assert.ok(
    autoInc.length >= 1,
    'DLL 里没有任何自增主键写法（AUTOINCREMENT / AUTO_INCREMENT / SERIAL PRIMARY KEY）——'
    + 'SqlCompat.AutoIncrementIdColumn 缺失或建表语句不自增，Id 列会取不到值',
  )
  // Postgres 那一支是旧版缺陷 D28 的修法，必须真的在产物里
  assert.equal(containsString(buf, 'SERIAL PRIMARY KEY'), true,
    'DLL 里没有 SERIAL PRIMARY KEY —— Postgres 分支缺失（旧版在 Postgres 下建表会失败，D28 没修）')

  // 6) 两个索引名（旧版一个索引都没建，D12）与幂等建索引
  for (const idx of ['idx_tel_taskid', 'idx_tel_triggered']) {
    assert.equal(containsString(buf, idx), true, `DLL 里没有索引名 ${idx} —— 补索引没进产物，列表页会全表扫`)
  }
  assert.equal(containsString(buf, 'CREATE INDEX IF NOT EXISTS '), true,
    'DLL 里没有 "CREATE INDEX IF NOT EXISTS " —— 幂等建索引缺失（重启会重复建/报错）')
  assert.equal(containsString(buf, 'information_schema.statistics'), true,
    'DLL 里没有 information_schema.statistics —— MySQL 分支的索引存在性检查缺失')
})

test('SQL 语句抽取非空且只碰本插件的表（抽不到任何 SQL 时反面断言不可信）', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const sqls = extractSqlStatements(buf)
  assert.ok(
    sqls.length >= 1,
    '一条 SQL 都抽不出来 —— 抽取逻辑失效（对齐/编码没覆盖到），此时后面的反面断言等于空断言',
  )
  const ddl = sqls.filter((s) => /CREATE\s+TABLE/i.test(s))
  assert.ok(
    ddl.length >= 1,
    `抽不到建表语句（只抽到 ${sqls.length} 条片段）：\n` + sqls.map((s) => `    ${s.slice(0, 80)}`).join('\n'),
  )
  assert.ok(
    ddl.some((s) => /CREATE TABLE IF NOT EXISTS\s+task_execution_logs\s*\(/.test(s)),
    '抽到的建表语句里没有"表名 + 左括号"紧跟建表头部：\n' + ddl.map((s) => `    ${s.slice(0, 120)}`).join('\n'),
  )
  // 反面：任何抽取出来的 SQL 都不许提到别的插件的表
  for (const sql of sqls) {
    assert.doesNotMatch(
      sql, /player_daily_stat|hourly_online_snapshot/i,
      `DLL 的 SQL 片段里出现了别的插件的表：${sql.slice(0, 120)}`,
    )
  }
})

test('★★ 阴性对照：不得写入别的插件的表（player_daily_stat / daily_min / 整点快照）★★', async () => {
  const dll = await findDll()
  const buf = await readFile(dll)
  const forbidden = NEGATIVE_CONTROLS.slice(1)
  for (const [s, why] of forbidden) {
    assert.equal(
      containsString(buf, s), false,
      `DLL 里出现了 "${s}"：${why}。\n`
      + '  player_daily_stat 的每分钟 +1 由 online-stats 插件负责'
      + '（plugins/online-stats/plugin/OnlineStatsData.cs:130-153），\n'
      + '  本插件若再写一次，玩家的累计时长会翻倍、所有时长阈值提前一半触发；\n'
      + '  另一个插件的配置文件名/命名空间出现在本件里，说明是从 promotion / qq-bind 复制粘贴过来的。',
    )
  }
  // 反过来必须出现本件自己的身份（否则上面的"扫不到"可能是"扫错了文件"）
  assert.equal(containsString(buf, 'TaskSchedulerPlugin'), true, '本件入口类型 TaskSchedulerPlugin 必须存在')
  assert.equal(containsString(buf, 'task-scheduler-config.json'), true, '本件的配置文件名必须存在')
  assert.equal(containsString(buf, 'task_execution_logs'), true, '本件的执行记录表名必须存在')
})

test('发行目录镜像里的 DLL 与源码目录逐字节一致（同步后不许有第二份不同内容）', async () => {
  const dll = await findDll()
  const mirror = path.join(mirrorPluginDir, path.basename(dll))
  let mirrorBuf
  try {
    mirrorBuf = await readFile(mirror)
  } catch (err) {
    if (err.code === 'ENOENT') {
      // 镜像目录不存在（本插件尚未同步到 tsweb-dist-lite，或别人只 checkout 了源码目录）
      // → 跳过，不误报。同步之后这条用例会自动开始生效。
      return
    }
    throw err
  }
  const src = await readFile(dll)
  const sha = (b) => createHash('sha256').update(b).digest('hex')
  assert.equal(
    sha(mirrorBuf), sha(src),
    `两份 DLL 内容不一致：\n  源码 ${dll}\n  镜像 ${mirror}\n  请重新同步（镜像必须逐字节一致）`,
  )
})
