/**
 * 测试用的最小宿主（假 ctx）+ 假游戏服半 —— 不启动任何服务进程、不依赖 express / cordis。
 *
 * 为什么自己搓一个（与 plugins/promotion/test/support/fake-host.mjs 同一理由）：
 *   本机 `node --test test/` 会因 `spawn EPERM`（沙箱不允许管道捕获子进程）整体失败，
 *   测试必须能逐个 `node test/<名>.test.mjs` 跑；同时"不启动/重启任何服务进程"是本次任务的
 *   硬约定，所以**不引入真实 HTTP 监听**，而是直接调用插件注册在 app.get/app.post 上的
 *   处理函数（与真实 express 的用法一致：插件只用 (req,res) 两个参数）。
 *
 * 覆盖到的宿主契约（plugins/task-scheduler/index.js 依赖的全部服务）：
 *   webServer.app.get/post、auth.verifyAuth/requireAdmin、servers.list/getRaw、
 *   tshock.fetchFor（**记录全部调用**，供断言"下发确实发生/参数正确"）、
 *   paths.dataOf、ctx.on/ctx.emit（连接恢复补推靠它触发）
 */
import path from 'node:path'

export function makeFakeHost({ dataDir, servers = [], fetchFor }) {
  const routes = { get: new Map(), post: new Map() }
  const listeners = new Map()
  const events = []
  const calls = []
  const raw = new Map(servers.map((s) => [String(s.raw.id), { ...s.raw }]))

  const app = {
    get(routePath, ...handlers) {
      routes.get.set(routePath, handlers[handlers.length - 1])
    },
    post(routePath, ...handlers) {
      routes.post.set(routePath, handlers[handlers.length - 1])
    },
  }

  const ctx = {
    webServer: { app },
    // 鉴权中间件在测试里直接放行（本件只关心处理逻辑；鉴权链路由宿主保证，
    // "是否真的挂了 admin-only"由 host-api.test.mjs 单独断言 admin 数组的来源）
    auth: {
      verifyAuth: () => (req, res, next) => next(),
      requireAdmin: () => (req, res, next) => next(),
    },
    paths: { dataOf: (n) => path.join(dataDir, n) },
    logger: { info() {}, warn() {}, error() {} },
    servers: {
      list: async () => [...raw.values()].map((s) => ({ ...s })),
      getRaw: (id) => (raw.has(String(id)) ? { ...raw.get(String(id)) } : null),
    },
    tshock: {
      async fetchFor(server, pathname, params) {
        calls.push({ serverId: server.id, pathname, params: { ...params } })
        return fetchFor(server, pathname, params)
      },
    },
    emit(name, payload) {
      events.push({ name, payload })
    },
    on(name, fn) {
      listeners.set(name, fn)
      return () => listeners.delete(name)
    },
  }

  return {
    ctx,
    /** 全部游戏服调用（含参数），供"下发确实发生/参数正确"类断言 */
    calls,
    /** 插件 emit 的事件 */
    events,
    /** 改假服务器记录（例如临时置 enabled=false） */
    setRaw(id, patch) {
      raw.set(String(id), { ...(raw.get(String(id)) || {}), ...patch })
    },
    /** 触发宿主事件（连接恢复补推靠它） */
    fire(name, payload) {
      const fn = listeners.get(name)
      if (!fn) return false
      fn(payload)
      return true
    },
    listenerCount: () => listeners.size,
    /** 直接调用插件注册的某个端点（不经网络） */
    async call(method, url, { query = {}, body = {}, headers = {} } = {}) {
      const u = new URL(url, 'http://localhost')
      const merged = { ...Object.fromEntries(u.searchParams.entries()), ...query }
      const handler = routes[method].get(u.pathname)
      if (!handler) throw new Error(`插件未注册该路由: ${method.toUpperCase()} ${u.pathname}`)
      let data = null
      let status = 200
      const res = {
        headersSent: false,
        status(code) {
          status = code
          return res
        },
        json(payload) {
          data = payload
          return res
        },
      }
      await handler({ query: merged, body, headers, user: { username: 'tester' } }, res)
      return { status, data }
    },
    hasRoute: (method, routePath) => routes[method].has(routePath),
    /** 只取"插件实际注册的路由清单"，用于断言旧版 7 条契约端点一个都没缺 */
    routePaths: () => ({ get: [...routes.get.keys()], post: [...routes.post.keys()] }),
  }
}

/** 轮询等待条件成立（用于等异步下发/重试完成）；超时抛错，不静默通过 */
export async function waitFor(cond, { timeoutMs = 3000, intervalMs = 10, label = '条件' } = {}) {
  const started = Date.now()
  for (;;) {
    const v = await cond()
    if (v) return v
    if (Date.now() - started > timeoutMs) throw new Error(`等待超时：${label}`)
    await new Promise((r) => setTimeout(r, intervalMs))
  }
}

/**
 * 假游戏服半（TaskScheduler.dll 的端点行为）。
 *
 * 逐服可设行为（对齐 plugin/TaskSchedulerEndpoints.cs 的真实返回）：
 *   ok          正常应用并回报 applied=true
 *   missing     未安装 DLL（旧版契约端点 404；本件映射成 501 + serverHalfMissing）
 *   forbidden   REST token 权限不足（401/403）
 *   stale       服端已有更新版本 → HTTP 200 + applied=false + stale=true
 *   conflict    服端有任务而收到空列表且没带 allowEmpty → HTTP 409（空列表守卫）
 *   badRequest  参数被拒（400）
 *   saveFail    应用了但落盘失败（saveError 非空）
 *   serverError 服端 500
 *   raise       fetchFor 自身抛错（服务器记录损坏等）
 *
 * 端点与参数形态与 plugin/TaskSchedulerEndpoints.cs 逐字对齐：
 *   /data/tasks/snapshot    参数 version / tasks / ts / allowEmpty
 *   /data/tasks/status      无参
 *   /data/tasks/run         参数 id / force
 *   /data/tasks/log         参数 taskId / page / pageSize
 *   /data/tasks/log/detail  参数 id
 */
export function makeGameHalf({ serverIds = [] } = {}) {
  const applied = new Map()
  const behavior = new Map(serverIds.map((id) => [String(id), 'ok']))
  /** 服端认为"自己当前已有几个任务"（空列表守卫用它判断） */
  const serverTaskCount = new Map(serverIds.map((id) => [String(id), 0]))
  /** 服端版本号（stale 判定用） */
  const serverVersion = new Map(serverIds.map((id) => [String(id), 0]))
  /** 服端本地改动计数（/save、/delete 造成） */
  const localEdits = new Map(serverIds.map((id) => [String(id), 0]))
  /** 服端 source（rest / legacy / legacy-alt / file / default） */
  const source = new Map(serverIds.map((id) => [String(id), 'default']))
  /** 服端运行期状态：taskId -> { lastRunAt, lastRunStatus, runCount, running } */
  const runtime = new Map(serverIds.map((id) => [String(id), new Map()]))
  /** 执行记录（供 /log 与 /log/detail） */
  const logs = new Map(serverIds.map((id) => [String(id), []]))
  /** 记录 /run 收到的参数，供"force 有没有真的传下去"断言 */
  const runCalls = []

  return {
    applied,
    behavior,
    serverTaskCount,
    serverVersion,
    runtime,
    logs,
    runCalls,
    setBehavior(id, mode) {
      behavior.set(String(id), mode)
    },
    setServerTaskCount(id, n) {
      serverTaskCount.set(String(id), Number(n))
    },
    setServerVersion(id, v) {
      serverVersion.set(String(id), Number(v))
    },
    setRuntime(id, taskId, patch) {
      const m = runtime.get(String(id)) || new Map()
      m.set(String(taskId), { ...(m.get(String(taskId)) || {}), ...patch })
      runtime.set(String(id), m)
    },
    setSource(id, s) {
      source.set(String(id), s)
    },
    setLocalEdits(id, n) {
      localEdits.set(String(id), Number(n))
    },
    addLog(id, log) {
      const list = logs.get(String(id)) || []
      list.push(log)
      logs.set(String(id), list)
    },

    fetchFor(server, pathname, params) {
      const id = String(server.id)
      const mode = behavior.get(id) || 'ok'

      if (mode === 'raise') throw new Error('服务器记录损坏（假）')
      if (mode === 'missing') return { ok: false, status: 404, data: {} }
      if (mode === 'forbidden') return { ok: false, status: 403, data: {} }
      // serverError 对**所有**端点生效（否则只有 snapshot 会 500，fetchStatus 却成功，
      // 造出"一边失败一边成功"的假象，测不出真实映射）
      if (mode === 'serverError') return { ok: false, status: 500, data: { error: '服务器内部错误（假）' } }

      if (pathname === '/data/tasks/snapshot') {
        if (mode === 'badRequest') return { ok: false, status: 400, data: { error: 'version 必须是正整数' } }
        if (mode === 'serverError') return { ok: false, status: 500, data: { error: '应用配置失败（假）' } }
        if (mode === 'stale') {
          return {
            ok: true,
            status: 200,
            data: {
              ok: true,
              applied: false,
              stale: true,
              version: Number(serverVersion.get(id) || 99),
              reason: '收到的 version 早于当前 version',
            },
          }
        }

        let tasks
        try {
          tasks = JSON.parse(params.tasks)
        } catch (err) {
          return { ok: false, status: 400, data: { error: `tasks 不是合法 JSON：${err.message}` } }
        }
        if (!Array.isArray(tasks)) {
          return { ok: false, status: 400, data: { error: 'tasks 必须是 JSON 数组' } }
        }
        const needVersion = Number(params.version)
        if (!Number.isFinite(needVersion) || needVersion <= 0) {
          return { ok: false, status: 400, data: { error: 'version 必须是正整数' } }
        }
        // 空列表守卫：服端已有任务 + 收到空列表 + 没带 allowEmpty=1 → 409
        const curCount = Number(serverTaskCount.get(id) || 0)
        if (tasks.length === 0 && curCount > 0 && params.allowEmpty !== '1') {
          return {
            ok: false,
            status: 409,
            data: {
              error: `拒绝应用空任务列表：服端当前有 ${curCount} 个任务，而本次下发没有带 allowEmpty=1`,
            },
          }
        }

        serverVersion.set(id, needVersion)
        serverTaskCount.set(id, tasks.length)
        source.set(id, 'rest')
        applied.set(id, { version: needVersion, tasks })
        runtime.set(id, new Map(tasks.map((t) => [String(t.id), {
          lastRunAt: '', lastRunStatus: '', runCount: 0, running: false,
        }])))

        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            applied: true,
            stale: false,
            version: needVersion,
            updatedAt: '2026-01-01T00:00:00',
            taskCount: tasks.length,
            saveError: mode === 'saveFail' ? '磁盘只读（假）' : '',
            notes: [],
            localEdits: Number(localEdits.get(id) || 0),
            scheduler: { running: true, tickIntervalMs: 1000, worldReady: true, executorGroup: 'superadmin' },
          },
        }
      }

      if (pathname === '/data/tasks/status') {
        const tasks = (applied.get(id)?.tasks) || []
        const rt = runtime.get(id) || new Map()
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            version: Number(serverVersion.get(id) || 0),
            updatedAt: '2026-01-01T00:00:00',
            source: source.get(id) || 'default',
            file: 'X:/tshock/task-scheduler-config.json',
            legacyFile: 'X:/tshock/TSWeb/Tasks/tasks.json',
            legacyFileAlt: 'X:/tshock/tasks.json',
            migratedFrom: '',
            saveError: '',
            loadError: '',
            localEdits: Number(localEdits.get(id) || 0),
            notes: [],
            countError: '',
            taskCount: tasks.length,
            tasks: tasks.map((t) => {
              const r = rt.get(String(t.id)) || {}
              return {
                id: t.id,
                name: t.name,
                enabled: t.enabled,
                triggerMode: t.triggerMode,
                intervalSeconds: t.intervalSeconds,
                dailyTime: t.dailyTime,
                condition: t.condition,
                execMode: t.execMode,
                commands: t.commands,
                commandCount: (t.commands || []).length,
                lastRunAt: r.lastRunAt || '',
                lastDailyRunAt: '',
                lastRunStatus: r.lastRunStatus || '',
                runCount: Number(r.runCount || 0),
                running: r.running === true,
                lastForced: false,
                runCountFromDb: Number(r.runCount || 0),
                runCountInMemory: Number(r.runCount || 0),
              }
            }),
            knownBossNames: [],
            scheduler: { running: true, tickIntervalMs: 1000, worldReady: true, executorGroup: 'superadmin' },
          },
        }
      }

      if (pathname === '/data/tasks/run') {
        runCalls.push({ serverId: id, id: params.id, force: params.force })
        return { ok: true, status: 200, data: { ok: true, message: '任务已开始执行', taskId: params.id } }
      }

      if (pathname === '/data/tasks/log') {
        const list = logs.get(id) || []
        const taskId = String(params.taskId || '')
        const filtered = taskId ? list.filter((l) => String(l.taskId) === taskId) : list
        const page = Number(params.page || 1) || 1
        const pageSize = Number(params.pageSize || 20) || 20
        const start = (page - 1) * pageSize
        return {
          ok: true,
          status: 200,
          data: {
            ok: true,
            logs: filtered.slice(start, start + pageSize),
            total: filtered.length,
            page,
            pageSize,
          },
        }
      }

      if (pathname === '/data/tasks/log/detail') {
        const list = logs.get(id) || []
        const hit = list.find((l) => String(l.id) === String(params.id))
        if (!hit) return { ok: false, status: 404, data: { error: '记录不存在' } }
        return { ok: true, status: 200, data: { ok: true, log: hit } }
      }

      return { ok: false, status: 500, data: { error: `未预期的路径 ${pathname}` } }
    },
  }
}

/** 造一个任务对象（字段与 config.js:86-98 的服务端默认值一致） */
export function makeTask(patch = {}) {
  return {
    id: patch.id || 'task0000000000000000000000000001',
    name: patch.name || '测试任务',
    enabled: patch.enabled === undefined ? true : patch.enabled,
    triggerMode: patch.triggerMode || 'manual',
    intervalSeconds: patch.intervalSeconds === undefined ? 0 : patch.intervalSeconds,
    dailyTime: patch.dailyTime || '00:00',
    condition: patch.condition || { type: 'always', not: false, params: { min: 0, max: 9999, bossNames: [], playerNames: [] } },
    execMode: patch.execMode || 'sequential',
    commands: patch.commands || ['/bc 测试'],
  }
}
