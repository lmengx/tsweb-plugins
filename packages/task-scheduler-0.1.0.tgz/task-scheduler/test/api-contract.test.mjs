/**
 * task-scheduler 前端半 —— **宿主 api() 契约**一致性测试（client/task-scheduler.js）
 *
 * 为什么必须有这个文件（补它的直接原因是一次真实事故）：
 *   缺陷 A —— 本插件 client 的 6 处写操作（新建/保存、启停、执行、删除、补推、采纳）
 *   曾把请求体写成 `{ method:'POST', body:{...} }`，而宿主 `api()` **只认 `options.json`，
 *   完全没有 `options.body` 分支**（权威实现 plugins/web/public/app.js:222-244）。
 *   于是这 6 个请求全都发出**空 body**：UI 上看是"点了没反应/保存了但没生效"，
 *   而服务端只看到缺参数 —— 整条前端写路径静默失效。
 *   修复前，本插件的 190 个用例**全绿**依旧：`test/client-ui.test.mjs:641` 的桩是
 *   `api: () => Promise.resolve({...})`，它**完全忽略 options**，没有任何用例断言过"请求的形状"。
 *
 * 所以本文件不再依赖"桩吞掉 options"，而是**把契约本身变成断言**：
 *   ① 从**权威实现**（plugins/web/public/app.js）里抽出 `api()` 真正认哪些 option 键；
 *   ② 用**运行时副本**（tsweb-dist-lite/plugins/web/public/app.js）交叉核对（必须逐字节一致
 *      且抽出的契约完全相同）——否则"修了源码但用户拿到的是旧副本"，本文件会红；
 *   ③ 扫 client 里**每个** api 调用点的第二实参，断言它的键都在契约里；
 *   ④ 单独再加一条"整份 client 源码里不得出现 `body:`"的钝断言；
 *   ⑤ 用**宿主半真实注册的路由**（plugins/task-scheduler/index.js 的 app.get/app.post）
 *      判断该端点该用什么方法，断言写操作都显式带 `method:'POST'`+`json`、
 *      只读端点不会误带 `json`（api() 见 json 会把方法推成 POST，那是同一类静默失效）。
 *
 * 为什么 ③ 与 ④ 两条都要写（而不是只写一条）：
 *   ④ 只能证明"此刻没有 body"，它挡不住**同一类**错误的其它写法（`data:`/`payload:`/`query:`）；
 *   ③ 是"按契约白名单校验"，任何 api() 不认的键都会被抓住，包括将来新造的键名。
 *   反过来 ③ 也挡不住"把 body 拼成变量再传"这类绕过静态扫描的写法，所以 ④ 作为钝兜底保留。
 *   两者互为补集，缺一条都会留下这个缺陷类的变体。
 *
 * 运行：node test/api-contract.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile, readdir } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const pluginDir = path.resolve(here, '..')
const repoRoot = path.resolve(pluginDir, '..', '..')
const clientDir = path.join(pluginDir, 'client')
/** 权威实现：宿主 api() 的真身 */
const hostAppFile = path.join(repoRoot, 'plugins', 'web', 'public', 'app.js')
/** 运行时副本：用户实际加载到的那份（必须与权威实现同源） */
const runtimeAppFile = path.join(repoRoot, 'tsweb-dist-lite', 'plugins', 'web', 'public', 'app.js')
/** 宿主半：路由注册的真身（判断端点该用什么方法） */
const hostIndexFile = path.join(pluginDir, 'index.js')

// ════════════════════════════════════════════
//  极简 JS 片段扫描器
//  （只够抽"调用点 + 第二实参对象字面量的顶层键"，不追求完整解析；够用且可读）
// ════════════════════════════════════════════

/** 跳过一个字符串字面量（'...' / "..." / `...`，含 ${} 插值），返回结束后的下标 */
function skipString(src, i) {
  const quote = src[i]
  i += 1
  while (i < src.length) {
    const c = src[i]
    if (c === '\\') { i += 2; continue }
    if (quote === '`' && c === '$' && src[i + 1] === '{') {
      i = skipBalanced(src, i + 1, '{', '}') + 1
      continue
    }
    if (c === quote) return i + 1
    i += 1
  }
  return i
}

/** 从 src[openIdx]（等于 open 字符）跳到配对闭合处，返回闭合字符的下标 */
function skipBalanced(src, openIdx, open, close) {
  let depth = 0
  let i = openIdx
  while (i < src.length) {
    const c = src[i]
    if (c === "'" || c === '"' || c === '`') { i = skipString(src, i); continue }
    if (c === '/' && src[i + 1] === '/') {
      const e = src.indexOf('\n', i)
      i = e < 0 ? src.length : e
      continue
    }
    if (c === '/' && src[i + 1] === '*') {
      const e = src.indexOf('*/', i + 2)
      i = e < 0 ? src.length : e + 2
      continue
    }
    if (c === open) depth += 1
    else if (c === close) {
      depth -= 1
      if (depth === 0) return i
    }
    i += 1
  }
  return src.length
}

/** 把"括号内部"的文本按顶层逗号切成片段 */
function splitTopLevel(inner) {
  const parts = []
  let depth = 0
  let start = 0
  let i = 0
  while (i < inner.length) {
    const c = inner[i]
    if (c === "'" || c === '"' || c === '`') { i = skipString(inner, i); continue }
    if (c === '/' && inner[i + 1] === '/') {
      const e = inner.indexOf('\n', i)
      i = e < 0 ? inner.length : e
      continue
    }
    if (c === '/' && inner[i + 1] === '*') {
      const e = inner.indexOf('*/', i + 2)
      i = e < 0 ? inner.length : e + 2
      continue
    }
    if (c === '(' || c === '[' || c === '{') depth += 1
    else if (c === ')' || c === ']' || c === '}') depth -= 1
    else if (c === ',' && depth === 0) { parts.push(inner.slice(start, i)); start = i + 1 }
    i += 1
  }
  parts.push(inner.slice(start))
  return parts.map((p) => p.trim()).filter((p) => p !== '')
}

/** 取实参列表（expr 形如 "表达式("，返回 [实参源码...] 与闭合下标） */
function callArgs(src, openParenIdx) {
  const closeIdx = skipBalanced(src, openParenIdx, '(', ')')
  return { args: splitTopLevel(src.slice(openParenIdx + 1, closeIdx)), closeIdx }
}

/**
 * 取对象字面量的顶层键。片段不是 `{...}` 形式时返回 null（表示"不是字面量，无法静态判断"）。
 * 返回 { keys: string[], spread: boolean, hasDynamic: boolean, text: string }
 */
function objectLiteralKeys(expr) {
  const text = expr.trim()
  if (!text.startsWith('{')) return null
  const close = skipBalanced(text, 0, '{', '}')
  if (close >= text.length && text[close] !== '}') return null
  const inner = text.slice(1, close)
  const keys = []
  let spread = false
  for (const part of splitTopLevel(inner)) {
    if (part.startsWith('...')) { spread = true; continue }
    const m = part.match(/^([A-Za-z_$][\w$]*)\s*(?::|$)/)
    if (m) keys.push(m[1])
    else if (part !== '') spread = true // 计算属性名/别的写法：无法静态枚举，按"含动态"处理
  }
  return { keys, spread, text }
}

/** 抽出源码里所有"宿主 api 调用点"（callee 为 call/api/tsw.api/window.tsweb.api） */
function findApiCallSites(src) {
  const sites = []
  const re = /(?:^|[^\w$.])(call|api|tsw\.api|window\.tsweb\.api)\s*\(/g
  let m
  while ((m = re.exec(src)) !== null) {
    const callee = m[1]
    const parenIdx = m.index + m[0].length - 1
    // 排除函数**定义**（`function api(`）与箭头函数体里那个转发（`api(path, opts).then`）
    const before = src.slice(Math.max(0, m.index - 12), m.index + m[0].length)
    if (/function\s+(api|call)\s*\($/.test(before)) continue
    const { args } = callArgs(src, parenIdx)
    if (args.length < 2) continue
    const second = objectLiteralKeys(args[1])
    if (!second) continue
    // 第一实参里的第一个字符串字面量当作路径（含查询串）
    const lit = args[0].match(/'([^']*)'|"([^"]*)"|`([^`]*)`/)
    sites.push({
      callee,
      line: src.slice(0, m.index).split('\n').length,
      rawPath: lit ? (lit[1] ?? lit[2] ?? lit[3]) : '',
      optionsText: second.text,
      keys: second.keys,
      spread: second.spread,
    })
  }
  return sites
}

/** 去掉查询串与末尾拼接，得到可路由匹配的路径前缀 */
function routePathOf(rawPath) {
  return String(rawPath).split('?')[0]
}

// ════════════════════════════════════════════
//  ① 从权威实现里抽 api() 契约
// ════════════════════════════════════════════

/** 取 functionName 的函数体源码（含花括号），用配对扫描，不靠缩进猜 */
function functionBody(src, header) {
  const idx = src.indexOf(header)
  assert.ok(idx >= 0, `没找到 ${header}（web 的 api() 实现可能被改名/移动了，本文件需要跟着改）`)
  const braceIdx = src.indexOf('{', idx)
  assert.ok(braceIdx > 0, `${header} 后面应有函数体`)
  const closeIdx = skipBalanced(src, braceIdx, '{', '}')
  assert.ok(closeIdx > braceIdx, `${header} 的函数体括号不配对（扫描器或源码有问题）`)
  return src.slice(braceIdx, closeIdx + 1)
}

/** api() 认的 option 键 = 函数体里出现的 options.<key> */
function apiContractOf(appSrc) {
  const body = functionBody(appSrc, 'async function api(')
  const keys = new Set()
  const re = /\boptions\.([A-Za-z_$][\w$]*)/g
  let m
  while ((m = re.exec(body)) !== null) keys.add(m[1])
  return { body, keys: [...keys].sort() }
}

test('契约：从权威实现 plugins/web/public/app.js 抽出 api() 认哪些 option 键', async () => {
  const appSrc = await readFile(hostAppFile, 'utf8')
  const { body, keys } = apiContractOf(appSrc)

  // 契约就是这三个键。多一个或少一个都必须让人看到，因为 client 的请求形状全靠它。
  assert.deepEqual(keys, ['headers', 'json', 'method'],
    `api() 认的 option 键变了：${keys.join(', ')}。` +
    '若确实新增了键，请同步更新本断言与 client 的用法；若删了键，全仓 client 都要跟着改。')

  // ★ 缺陷 A 的核心：api() **没有** body 分支。它自己拼 fetch 的 body（:239 body: body）。
  assert.equal(keys.includes('body'), false,
    'api() 不应认 options.body —— 传 body 等于把整个请求体丢掉（缺陷 A 的成因）')
  assert.ok(/body\s*:\s*body/.test(body),
    'api() 的 fetch 里应仍然是自己拼的 body（选项里的 json 才是唯一入口）')
  // 方法推导规则：显式 method 优先，其次"有 json 就当 POST"，否则 GET
  assert.ok(/options\.method\s*\|\|/.test(body),
    'api() 应以 options.method 优先推导 HTTP 方法')
  assert.ok(/options\.json\s*!==\s*undefined\s*\?\s*'POST'\s*:\s*'GET'/.test(body),
    'api() 应在给了 json 时推成 POST、否则 GET（漏 method 的写操作会退化成 GET）')
  assert.ok(/JSON\.stringify\(options\.json\)/.test(body), 'api() 应把 options.json 序列化进 body')
})

test('契约：运行时副本 tsweb-dist-lite 的 app.js 与权威实现逐字节一致且契约相同', async () => {
  const authoritative = await readFile(hostAppFile)
  let runtime = null
  try {
    runtime = await readFile(runtimeAppFile)
  } catch (err) {
    if (err.code !== 'ENOENT') throw err
  }
  // 运行时副本缺失时**明确跳过**，不伪装成通过（照本仓 dist-sync 的做法）
  if (!runtime) {
    assert.ok(true, `运行时副本不存在（${runtimeAppFile}），本用例未做交叉核对`)
    return
  }
  const sha = (b) => createHash('sha256').update(b).digest('hex')
  assert.equal(sha(runtime), sha(authoritative),
    '运行时副本与权威实现不一致：用户实际加载的是另一份 api()。' +
    '改了 plugins/web/public/app.js 就必须同步 tsweb-dist-lite/plugins/web/public/app.js')

  const a = apiContractOf(authoritative.toString('utf8')).keys
  const b = apiContractOf(runtime.toString('utf8')).keys
  assert.deepEqual(b, a, '两份 app.js 抽出的 api() 契约必须相同')
  // 运行时副本里也不能有 options.body 分支（否则"源码没有、运行时能用"会让人误判）
  assert.equal(/options\.body/.test(runtime.toString('utf8')), false,
    '运行时副本里不得出现 options.body 分支')
})

// ════════════════════════════════════════════
//  ② 宿主路由表（判断端点该用什么方法）
// ════════════════════════════════════════════

async function hostRoutes() {
  const src = await readFile(hostIndexFile, 'utf8')
  const get = new Set()
  const post = new Set()
  const re = /app\.(get|post)\(\s*'([^']+)'/g
  let m
  while ((m = re.exec(src)) !== null) {
    ;(m[1] === 'get' ? get : post).add(m[2])
  }
  return { get, post }
}

test('前置：能从宿主半抽出真实注册的路由（否则后面的方法断言是空转）', async () => {
  const { get, post } = await hostRoutes()
  assert.ok(get.size >= 5, `应抽出至少 5 条 GET 路由，实际 ${get.size}`)
  assert.ok(post.size >= 4, `应抽出至少 4 条 POST 路由，实际 ${post.size}`)
  for (const p of ['/api/task-scheduler/tasks/list', '/api/task-scheduler/status']) {
    assert.ok(get.has(p), `GET 路由表应含 ${p}`)
  }
  for (const p of ['/api/task-scheduler/tasks/save', '/api/task-scheduler/tasks/delete',
    '/api/task-scheduler/tasks/run', '/api/task-scheduler/push', '/api/task-scheduler/adopt']) {
    assert.ok(post.has(p), `POST 路由表应含 ${p}`)
  }
})

// ════════════════════════════════════════════
//  ③ 扫 client：请求形状必须在契约内
// ════════════════════════════════════════════

async function clientFiles() {
  const names = (await readdir(clientDir, { withFileTypes: true }))
    .filter((e) => e.isFile() && e.name.endsWith('.js'))
    .map((e) => e.name)
    .sort()
  return names.map((n) => ({ name: n, file: path.join(clientDir, n) }))
}

test('client：所有 api 调用点的 option 键都在 api() 契约内（缺陷 A 的主闸门）', async () => {
  const appSrc = await readFile(hostAppFile, 'utf8')
  const { keys: recognized } = apiContractOf(appSrc)
  const known = new Set(recognized)

  const files = await clientFiles()
  assert.ok(files.length > 0, 'client 目录下应有 .js 文件')
  const violations = []
  let siteCount = 0
  for (const f of files) {
    const src = await readFile(f.file, 'utf8')
    for (const site of findApiCallSites(src)) {
      siteCount += 1
      const bad = site.keys.filter((k) => !known.has(k))
      if (bad.length) {
        violations.push(`client/${f.name}:${site.line} 传了 api() 不认的键 ${bad.join('、')}（${site.optionsText}）`)
      }
      // 对象字面量里若有展开/计算属性，静态扫描看不全 —— 显式报出来，不假装验过
      if (site.spread) {
        violations.push(`client/${f.name}:${site.line} 第二实参含展开/动态键，静态扫描无法确认其形状：${site.optionsText}`)
      }
    }
  }
  // 只有"带第二实参"的调用点才会被扫到 —— 也就是 6 处写操作
  // （新建/保存 960、启停 1044、执行 1060、删除 1075、补推 1087、采纳 1100）。
  // 读操作以 call('/api/...') 形式调用、不带 option，由下一个用例单独覆盖。
  assert.ok(siteCount >= 6,
    `应扫到至少 6 个带 option 的 api 调用点，实际 ${siteCount}（扫描器可能失效了）`)
  assert.deepEqual(violations, [],
    '这些调用把参数放在了 api() 不认的键上，参数会被静默丢弃：\n' + violations.join('\n'))
})

test('client：整份源码里不得出现 body: 键（缺陷 A 的钝兜底）', async () => {
  const files = await clientFiles()
  const bad = []
  for (const f of files) {
    const src = await readFile(f.file, 'utf8')
    src.split('\n').forEach((line, i) => {
      // 只看代码，不看注释（注释里说明"为什么不用 body"是允许且应该的）
      const code = line.replace(/\/\/.*$/, '').replace(/^\s*\*.*$/, '')
      if (/\bbody\s*:/.test(code)) bad.push(`client/${f.name}:${i + 1}: ${line.trim()}`)
    })
  }
  assert.deepEqual(bad, [],
    'client 里出现了 body: —— 宿主 api() 没有 options.body 分支，这些请求会发空 body（缺陷 A）：\n' + bad.join('\n'))
})

test('client：写操作必须显式带 method:POST 与 json（漏 method 会被 api() 推成 GET）', async () => {
  const { get, post } = await hostRoutes()
  const files = await clientFiles()
  const problems = []
  const writeSites = []

  for (const f of files) {
    const src = await readFile(f.file, 'utf8')
    for (const site of findApiCallSites(src)) {
      const route = routePathOf(site.rawPath)
      const isPost = post.has(route)
      const isGet = get.has(route)
      const where = `client/${f.name}:${site.line} ${route}`
      if (!isPost && !isGet) {
        problems.push(`${where} 不在宿主注册的路由里（端点写错了？）`)
        continue
      }
      if (isPost) {
        writeSites.push(where)
        const m = site.optionsText.match(/method\s*:\s*'([A-Z]+)'/)
        if (!m) problems.push(`${where} 是 POST 端点但没有显式 method（api() 会推成 GET，参数全丢）`)
        else if (m[1] !== 'POST') problems.push(`${where} 是 POST 端点却写了 method:'${m[1]}'`)
        if (!site.keys.includes('json')) problems.push(`${where} 是 POST 端点但没有 json（会发空 body）`)
      } else if (isGet && !isPost) {
        // 只读端点传了 json，api() 会把它推成 POST —— 同一类静默失效
        if (site.keys.includes('json')) problems.push(`${where} 是只读 GET 端点却传了 json（api() 会推成 POST）`)
        const m = site.optionsText.match(/method\s*:\s*'([A-Z]+)'/)
        if (m && m[1] !== 'GET') problems.push(`${where} 是只读端点却写了 method:'${m[1]}'`)
      }
    }
  }

  // 6 处写操作（新建/保存、启停、执行、删除、补推、采纳），行号见 client/task-scheduler.js
  assert.ok(writeSites.length >= 6,
    `应识别出至少 6 个写操作调用点（新建/保存 960、启停 1044、执行 1060、删除 1075、补推 1087、采纳 1100），` +
    `实际 ${writeSites.length}：\n${writeSites.join('\n')}`)
  assert.deepEqual(problems, [], '写/读端点的方法与请求体不匹配：\n' + problems.join('\n'))
})

test('client：读操作（列表/详情/日志/状态）确实没带请求体', async () => {
  const files = await clientFiles()
  const srcs = []
  for (const f of files) srcs.push({ name: f.name, src: await readFile(f.file, 'utf8') })

  const reads = ['/api/task-scheduler/tasks/list', '/api/task-scheduler/status',
    '/api/task-scheduler/tasks/get', '/api/task-scheduler/tasks/log']
  for (const p of reads) {
    const hit = srcs.some((s) => s.src.includes(p))
    assert.ok(hit, `client 里应能读到端点 ${p}（扫描假设它存在）`)
  }
  // 读端点应当以不带第二实参的形式调用（api() 默认 GET）
  const bare = srcs[0].src.match(/(?:call|api)\('\/api\/task-scheduler\/(?:tasks\/list|status)'\)/g) || []
  assert.ok(bare.length >= 2, `读端点应以 call('/api/...') 形式调用（默认 GET），实际命中 ${bare.length} 处`)
})
