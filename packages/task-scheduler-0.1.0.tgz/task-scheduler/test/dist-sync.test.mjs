/**
 * 发行目录同步测试（本仓既有约定：见 plugins/status-panel/test/dist-sync.test.mjs）
 *
 * 本件要求"每改一个文件都要同步到 tsweb-dist-lite/plugins/task-scheduler/ 并校验 SHA256 一致"。
 * 一次性手工核对过不算数——下次改完源码忘了同步、或者只同步了一半，没人会知道。
 * 本文件把这条要求变成可复跑的断言：
 *   ① 源码插件目录里的每个文件，发行目录里都有一份**逐字节相同**的副本
 *   ② 发行目录里不得有源码目录没有的多余文件（否则会下发一份"来历不明"的旧文件）
 *   ③ 排除 bin/ obj/ 这类构建中间产物（发行目录不该带它们）
 *
 * 发行目录不存在时**跳过并明确说明**，不伪装成通过（早先 promotion 的同类用例在目录缺失时静默 return，
 * 结果是"记 pass 但什么都没验证"；这里用 skip 让"没验证"这件事在测试输出里看得见）。
 *
 * 运行：node test/dist-sync.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readdir, readFile, stat } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
import { createHash } from 'node:crypto'

const here = path.dirname(fileURLToPath(import.meta.url))
const srcDir = path.resolve(here, '..')
const distDir = path.resolve(srcDir, '..', '..', 'tsweb-dist-lite', 'plugins', 'task-scheduler')

/** 递归列出相对路径（跳过 bin/obj：构建中间产物不进发行目录） */
async function listFiles(root, base = root) {
  const out = []
  let entries
  try {
    entries = await readdir(root, { withFileTypes: true })
  } catch (err) {
    if (err.code === 'ENOENT') return null
    throw err
  }
  for (const e of entries) {
    const abs = path.join(root, e.name)
    const rel = path.relative(base, abs).replace(/\\/g, '/')
    if (e.isDirectory()) {
      if (e.name === 'bin' || e.name === 'obj' || e.name === 'node_modules') continue
      out.push(...(await listFiles(abs, base)))
    } else {
      out.push(rel)
    }
  }
  return out
}

function sha256(buf) {
  return createHash('sha256').update(buf).digest('hex')
}

let distExists = false
try {
  distExists = (await stat(distDir)).isDirectory()
} catch (err) {
  if (err.code !== 'ENOENT') throw err
}

test('发行目录存在且是目录（不存在就跳过，并说明"未验证"）', { skip: distExists ? false : `发行目录不存在：${distDir}（本用例未做任何验证）` }, () => {
  assert.ok(distExists)
})

test('源码目录里的每个文件在发行目录里都有一份逐字节相同的副本', { skip: distExists ? false : '发行目录不存在' }, async () => {
  const src = await listFiles(srcDir)
  assert.ok(src && src.length > 0, '源码目录应能列出文件')
  assert.equal(src.some((f) => f.startsWith('plugin/bin/') || f.startsWith('plugin/obj/')), false,
    '列出时不应包含 bin/obj 中间产物')

  const missing = []
  const differing = []
  for (const rel of src) {
    let buf
    try {
      buf = await readFile(path.join(distDir, rel))
    } catch (err) {
      if (err.code === 'ENOENT') { missing.push(rel); continue }
      throw err
    }
    const a = sha256(await readFile(path.join(srcDir, rel)))
    if (a !== sha256(buf)) differing.push(`${rel}（源码 ${a.slice(0, 12)}… / 发行 ${sha256(buf).slice(0, 12)}…）`)
  }
  assert.deepEqual(missing, [], `发行目录缺少这些文件（说明没同步）：${missing.join('、')}`)
  assert.deepEqual(differing, [], `这些文件两边内容不一致（说明同步过一次后又改了源码）：${differing.join('、')}`)
})

test('发行目录里没有源码目录没有的多余文件', { skip: distExists ? false : '发行目录不存在' }, async () => {
  const dist = await listFiles(distDir)
  const src = new Set(await listFiles(srcDir))
  const extra = (dist || []).filter((f) => !src.has(f))
  assert.deepEqual(extra, [], `发行目录里有源码目录不存在的文件：${extra.join('、')}`)
})

test('发行目录里不得出现构建中间产物（bin/ obj/）', { skip: distExists ? false : '发行目录不存在' }, async () => {
  const all = []
  async function walk(root, base) {
    for (const e of await readdir(root, { withFileTypes: true })) {
      const abs = path.join(root, e.name)
      if (e.isDirectory()) {
        all.push(path.relative(base, abs).replace(/\\/g, '/'))
        await walk(abs, base)
      }
    }
  }
  await walk(distDir, distDir)
  const bad = all.filter((d) => /(^|\/)(bin|obj)(\/|$)/.test(d))
  assert.deepEqual(bad, [], `发行目录不应包含构建中间产物：${bad.join('、')}`)
})

test('关键文件确实在发行目录里（防止"整体同步了但漏掉入口"）', { skip: distExists ? false : '发行目录不存在' }, async () => {
  for (const rel of ['package.json', 'index.js', 'config.js', 'gameOps.js', 'audit.js',
    'client/task-scheduler.js', 'plugin/TaskScheduler.dll']) {
    const s = await stat(path.join(distDir, rel))
    assert.ok(s.isFile(), `发行目录缺少 ${rel}`)
  }
  // package.json 的关键字段在发行侧也要对
  const pkg = JSON.parse(await readFile(path.join(distDir, 'package.json'), 'utf8'))
  assert.equal(pkg.name, 'task-scheduler')
  assert.equal(pkg.tsweb.client, './client/task-scheduler.js')
  assert.deepEqual(pkg.tsweb.dll, ['./plugin/*.dll'])
})
