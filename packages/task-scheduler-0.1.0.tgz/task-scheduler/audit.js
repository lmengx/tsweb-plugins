/**
 * 本件审计流水（<dataDir>/task-scheduler/audit.jsonl，追加写）
 *
 * 事件名（动作名带插件名前缀，便于在统一审计视图里按功能分组）：
 *   task-scheduler.config.write   管理员改了某台服务器的任务配置（保存任务 / 删除任务 / 采纳服端配置）
 *   task-scheduler.task.run       管理员手动执行了某任务（谁、什么时候、是否强制）
 *   task-scheduler.config.push    一次下发尝试及其逐服结果（含自动重试与周期对账）
 *
 * 为什么"配置变更"和"执行"都要记（本件必改缺陷之三：越权）：
 *   旧版保存任务只需 `data.rest.invsee` 权限、后端只需 requireManager（admin + subadmin），
 *   而执行时**恒以 superadmin 身份**跑命令（旧版 TaskScheduler.cs:470-472 硬编码组名）。
 *   于是一个子管理员可以：用自己有的低权限，持久化一条任意 superadmin 命令，等它自动执行。
 *   本件的边界是"宿主侧 REST 一律 admin-only"（比旧版更严），
 *   而审计是这条边界的**可追溯证据**——谁能配置任务，必须留下记录。
 *
 * 写法照 plugins/promotion/audit.js：JSONL 追加 + 单文件上限轮转，按插件各存一份，
 * 不依赖其它插件、不共享文件。
 */
import { appendFile, mkdir, readFile, stat, rename } from 'node:fs/promises'
import path from 'node:path'

/** 单文件上限（超过则轮转为 audit.jsonl.1），避免无限增长 */
const MAX_BYTES = 8 * 1024 * 1024

/** 本件的审计动作名（唯一权威定义，测试与文档都引这里） */
export const ACTIONS = {
  /** 任务配置变更（保存 / 删除 / 采纳服端配置 / 启停） */
  configWrite: 'task-scheduler.config.write',
  /** 手动执行一个任务 */
  taskRun: 'task-scheduler.task.run',
  /** 一次下发（含逐服结果；成功与失败都记，失败是排障主线） */
  configPush: 'task-scheduler.config.push',
}

export class AuditLog {
  constructor({ file }) {
    if (!file) throw new Error('AuditLog 需要 file 路径')
    this.file = file
    this.dir = path.dirname(file)
  }

  /**
   * 追加一条审计。
   * @param {string} action 见 ACTIONS
   * @param {object} entry  { actor, ...detail }
   */
  async append(action, entry = {}) {
    // 载荷里带 action 是**编程错误**：它会覆盖掉审计动作名本身
    // （曾经的写法是 `{ action: String(action), ...entry }`，而 saveTask 的载荷里正好有个
    //   action: 'create'/'update'，于是审计里记的动作变成了 create/update，
    //   按 ACTIONS 前缀过滤就再也查不到这类记录。宁可当场炸，也不要写出错误归类的审计。）
    if (entry && Object.prototype.hasOwnProperty.call(entry, 'action')) {
      throw new Error('审计载荷不得包含 action 字段（会覆盖审计动作名）；请改用 op 之类的字段名')
    }
    const line = JSON.stringify({
      t: new Date().toISOString(),
      actor: entry.actor != null ? String(entry.actor) : '',
      ...entry,
      // action 放在最后：即使将来有人绕过上面的检查塞进来，审计动作名仍然是权威值
      action: String(action),
    }) + '\n'
    await mkdir(this.dir, { recursive: true })
    await this._rotateIfNeeded()
    await appendFile(this.file, line, 'utf8')
    return true
  }

  async _rotateIfNeeded() {
    try {
      const st = await stat(this.file)
      if (st.size >= MAX_BYTES) await rename(this.file, `${this.file}.1`)
    } catch (err) {
      if (err.code !== 'ENOENT') throw err
    }
  }

  /** 读取最近 n 条（新的在前）；文件不存在返回空数组，坏行降级为 parse-error 行 */
  async tail(limit = 100) {
    const n = Math.min(Math.max(1, Number(limit) || 100), 1000)
    let raw
    try {
      raw = await readFile(this.file, 'utf8')
    } catch (err) {
      if (err.code === 'ENOENT') return []
      throw err
    }
    const lines = raw.split('\n').filter((l) => l.trim() !== '')
    const out = []
    for (let i = lines.length - 1; i >= 0 && out.length < n; i--) {
      try {
        out.push(JSON.parse(lines[i]))
      } catch {
        out.push({ t: null, action: 'parse-error', raw: lines[i].slice(0, 200) })
      }
    }
    return out
  }
}
