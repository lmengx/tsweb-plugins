/**
 * 自动任务（task-scheduler）—— 任务模型 / 归一 / 校验 / 下发载荷
 *
 * 本件是旧版 TsWeb「自动任务」的插件化重写。模型的**字段名与默认值逐字照搬**
 * 旧版 TsWeb/plugin/TaskScheduler.cs:29-96（AutoTask / TaskCondition / ConditionParams），
 * 前端的下拉标签与模板照搬 TsWeb/frontend/src/views/console/TasksView.vue:30-103。
 *
 * 为什么校验放在这里而不是端点里：
 *   保存路径有两条（前端 /api/task-scheduler/save 与终端/脚本），校验必须单点定义，
 *   否则两条路径的接受范围会漂移（旧版正是只有 REST 一处校验，见规格 §4.7）。
 *
 * 两类校验的区别（这是旧版缺陷 D13 的修法）：
 *   1. **硬拒绝（400）**：旧版服务端本来就拒绝的三种枚举（triggerMode / execMode /
 *      condition.type），**报错文案逐字照搬**（旧版 TaskScheduler.cs:669-680 的
 *      "Invalid triggerMode" 等），外加「任务名称为空」——旧版前端已强制（TasksView.vue:240），
 *      服务端却放行，导致无名任务可以在界面上存在。
 *   2. **警告（warnings，不拒绝）**：旧版放行、但会让任务"看起来正常却永远不触发"的取值，
 *      例如 interval 任务的 intervalSeconds<=0、dailyTime 不是 HH:mm、命令列表为空。
 *      这里**不硬拒绝**，理由：硬拒绝会让从旧版迁移过来的存量配置无法保存（那些配置
 *      在旧版是合法的），而管理员需要能先把它读进来再修。所以改为把问题**显式回给界面**，
 *      由界面展示（旧版是静默放行，界面上完全看不出来，见 D13）。
 *
 * 约定：禁止 emoji；中文注释。
 */

/** 触发模式（旧版 TaskScheduler.cs:669 的白名单 + TasksView.vue:37-41 的标签） */
export const TRIGGER_MODES = [
  { value: 'manual', label: '手动执行' },
  { value: 'interval', label: '间隔执行' },
  { value: 'daily', label: '每天定时' },
]

/** 执行方式（旧版 TaskScheduler.cs:672 + TasksView.vue:43-46） */
export const EXEC_MODES = [
  { value: 'sequential', label: '顺序执行' },
  { value: 'concurrent', label: '并发执行' },
]

/** 条件类型（旧版 TaskScheduler.cs:678-680 + TasksView.vue:30-35） */
export const CONDITION_TYPES = [
  { value: 'always', label: '无条件' },
  { value: 'online_count', label: '在线人数' },
  { value: 'boss_defeated', label: 'BOSS已击败' },
  { value: 'player_online', label: '指定玩家在线' },
]

/**
 * BOSS 名称列表（条件 boss_defeated 的选项）。
 * **逐字照搬** TsWeb/frontend/src/api/tasksApi.js:43-47（18 项，顺序一致），
 * 与服端 TaskSchedulerRunner.BossNpcIds 的字典键**必须完全相同**——服端遇到不认识的名字
 * 直接判条件为 false（旧版行为，见规格 §6.2(3)），键不一致会让条件永远不满足。
 */
export const BOSS_NAMES = [
  '史莱姆王', '克苏鲁之眼', '世界吞噬者', '克苏鲁之脑', '蜂后', '巨鹿',
  '骷髅王', '血肉墙', '史莱姆皇后', '毁灭者', '机械骷髅王', '双子魔眼',
  '世纪之花', '石巨人', '猪龙鱼公爵', '光之女皇', '拜月教教徒', '月亮领主',
]

/** 合法取值集合（校验用） */
const TRIGGER_MODE_SET = new Set(TRIGGER_MODES.map((x) => x.value))
const EXEC_MODE_SET = new Set(EXEC_MODES.map((x) => x.value))
const CONDITION_TYPE_SET = new Set(CONDITION_TYPES.map((x) => x.value))

/** `HH:mm` 严格格式（00:00-23:59）；旧版靠字符串等值比较，格式不对就永不触发（规格 §5.2） */
export const DAILY_TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/

/** ConditionalParams 的默认值（旧版 TaskScheduler.cs:92-95：min=0 / max=9999） */
export function defaultParams() {
  return { min: 0, max: 9999, bossNames: [], playerNames: [] }
}

/** 条件默认值（旧版 TaskScheduler.cs:80-87：type=always / not=false） */
export function defaultCondition() {
  return { type: 'always', not: false, params: defaultParams() }
}

/**
 * 单个任务的**服务端默认值**——逐字照搬旧版 C# 模型
 * （TaskScheduler.cs:31-59：id 空串交给服务端生成、triggerMode=manual、
 *   intervalSeconds=0、dailyTime="00:00"、execMode=sequential、commands=[]）。
 *
 * 注意与**前端新建表单**默认值不同（TasksView.vue:120-132 给 intervalSeconds=600、
 * dailyTime='04:00'）：前端默认值属于界面行为，由 client 自己定义，不放到这里，
 * 否则本函数的语义会与"服端默认值"混淆（规格 §10.4 专门记了这处差异）。
 */
export function defaultTask() {
  return {
    id: '',
    name: '',
    enabled: true,
    triggerMode: 'manual',
    intervalSeconds: 0,
    dailyTime: '00:00',
    condition: defaultCondition(),
    execMode: 'sequential',
    commands: [],
  }
}

/** 配置根（旧版 TaskConfig，TaskScheduler.cs:22-26） */
export function emptyConfig() {
  return { tasks: [] }
}

// ════════════════════════════════════════════
//  归一
// ════════════════════════════════════════════

function toInt(value, fallback) {
  const n = Number(value)
  return Number.isFinite(n) ? Math.trunc(n) : fallback
}

function toStr(value) {
  return value == null ? '' : String(value)
}

function toStrList(value) {
  if (!Array.isArray(value)) return []
  return value.map(toStr)
}

/**
 * 生成任务 id：**与旧版同格式**——`Guid.NewGuid().ToString("N")`，即 32 位小写十六进制、
 * 无连字符（旧版 TaskScheduler.cs:32、665-666 两处都是这个格式）。
 * 前端新建时给空串，由服务端补（TasksView.vue:122）。
 */
export function newTaskId() {
  return globalThis.crypto.randomUUID().replace(/-/g, '').toLowerCase()
}

/**
 * 归一单个任务：把任意输入折成"字段齐全、类型正确"的一份。
 *
 * 刻意**只做类型归一，不做取值裁剪**：取值合法性交给 validateTask，
 * 这样"归一后仍非法"的值能在界面上被指名报出来，而不是被悄悄改掉
 * （旧版没有归一也没有校验，两者都缺）。
 *
 * 运行期字段（lastRunAt/lastRunStatus/runCount/running/lastDailyRunAt）**一律不接受客户端输入**：
 * 旧版新建任务时客户端可以塞 lastDailyRunAt，把日期设成今天即可让该 daily 任务当天不触发
 * （规格 §12 D14）。本件由服务端独占这些字段（见 index.js 的 saveTask）。
 */
export function normalizeTask(raw) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {}
  const cond = src.condition && typeof src.condition === 'object' && !Array.isArray(src.condition)
    ? src.condition
    : {}
  const params = cond.params && typeof cond.params === 'object' && !Array.isArray(cond.params)
    ? cond.params
    : {}

  return {
    id: toStr(src.id).trim(),
    name: toStr(src.name),
    enabled: src.enabled === undefined ? true : src.enabled === true,
    triggerMode: toStr(src.triggerMode) || 'manual',
    intervalSeconds: toInt(src.intervalSeconds, 0),
    dailyTime: src.dailyTime === undefined || src.dailyTime === null ? '00:00' : toStr(src.dailyTime),
    condition: {
      type: toStr(cond.type) || 'always',
      not: cond.not === true,
      params: {
        min: toInt(params.min, 0),
        max: params.max === undefined || params.max === null ? 9999 : toInt(params.max, 9999),
        bossNames: toStrList(params.bossNames),
        playerNames: toStrList(params.playerNames),
      },
    },
    execMode: toStr(src.execMode) || 'sequential',
    commands: toStrList(src.commands),
  }
}

/** 归一整个配置（{ tasks: [...] }） */
export function normalizeConfig(raw) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {}
  const tasks = Array.isArray(src.tasks) ? src.tasks : []
  return { tasks: tasks.filter((t) => t && typeof t === 'object').map(normalizeTask) }
}

// ════════════════════════════════════════════
//  校验
// ════════════════════════════════════════════

/** 构造带 HTTP 状态码的错误（宿主路由按 err.status 回码） */
export function httpError(status, message, extra = {}) {
  const err = new Error(message)
  err.status = status
  Object.assign(err, extra)
  return err
}

/**
 * 硬校验：不通过就抛 400。
 *
 * 三种枚举的报错文案**逐字照搬**旧版（TaskScheduler.cs:669-680）：
 *   "Invalid triggerMode" / "Invalid execMode" / "Invalid condition type"
 * 保持逐字是为了让从旧版切过来的调用方/脚本不需要改判断逻辑。
 *
 * @param task 已经过 normalizeTask 的对象
 * @param opts.strictId true 时要求 id 非空（更新既有任务必须带 id）
 */
export function validateTask(task, { strictId = false } = {}) {
  if (!task || typeof task !== 'object') throw httpError(400, 'Invalid task format')
  if (strictId && !task.id) throw httpError(400, 'Missing task id')

  // 名称非空：旧版**前端**强制（TasksView.vue:240「请输入任务名称」）、服务端放行（D13）。
  // 这里补上服务端校验——无名任务在卡片列表上无法辨认，是明确的缺陷。
  if (task.name.trim() === '') throw httpError(400, '请输入任务名称')

  if (!TRIGGER_MODE_SET.has(task.triggerMode)) throw httpError(400, 'Invalid triggerMode')
  if (!EXEC_MODE_SET.has(task.execMode)) throw httpError(400, 'Invalid execMode')
  if (!task.condition || !CONDITION_TYPE_SET.has(task.condition.type)) {
    throw httpError(400, 'Invalid condition type')
  }
  return task
}

/**
 * 软校验：返回"不会拒绝保存、但会让任务不按预期工作"的问题清单，交给界面展示。
 *
 * 这一条针对旧版最危险的一类静默失败（规格 §12 D13）：任务保存成功、界面显示正常，
 * 但因为它永远不会触发（间隔<=0 / 时间格式不对）或什么也不做（命令为空），
 * 管理员完全看不出来。本件把它变成**可见的警告**。
 *
 * 文案是中文（面向管理员），逐条指名问题所在。
 */
export function taskWarnings(task) {
  const out = []
  if (!task) return out

  if (task.triggerMode === 'interval' && task.intervalSeconds <= 0) {
    out.push('触发模式为「间隔执行」但间隔不是正数：该任务永远不会自动触发')
  }
  if (task.triggerMode === 'daily' && !DAILY_TIME_RE.test(task.dailyTime)) {
    out.push(`每日时间「${task.dailyTime}」不是 HH:mm 格式（00:00-23:59）：该任务永远不会自动触发`)
  }
  if (task.triggerMode === 'manual') {
    out.push('触发模式为「手动执行」：不会自动触发，只能由管理员点「执行」')
  }
  if (task.commands.length === 0) {
    out.push('命令列表为空：执行时不会有任何动作，但仍会记一条成功记录')
  } else {
    const blanks = task.commands
      .map((c, i) => (c.trim() === '' ? i + 1 : 0))
      .filter((n) => n > 0)
    if (blanks.length > 0) {
      out.push(`第 ${blanks.join('、')} 条命令为空：执行时该条会被记为失败`)
    }
  }

  const p = task.condition.params
  if (task.condition.type === 'online_count' && p.min > p.max) {
    out.push(`在线人数条件为 ≥${p.min} 且 ≤${p.max}：区间为空，条件永远不满足`)
  }
  if (task.condition.type === 'boss_defeated') {
    if (p.bossNames.length === 0) out.push('未选择任何 BOSS：条件永远不满足（旧版同）')
    const unknown = p.bossNames.filter((n) => !BOSS_NAMES.includes(n))
    if (unknown.length > 0) {
      out.push(`无法识别的 BOSS 名称「${unknown.join('、')}」：服端遇到不认识的名字会判条件不满足`)
    }
  }
  if (task.condition.type === 'player_online' && p.playerNames.length === 0) {
    out.push('未指定任何玩家：条件永远不满足（旧版同）')
  }
  if (task.condition.type === 'player_online' && p.playerNames.length > 0) {
    out.push('玩家名匹配区分大小写且必须完全相等（旧版行为）：名字写错会导致条件永远不满足')
  }
  return out
}

/** 整个配置的警告（逐任务带名字，便于界面定位） */
export function configWarnings(config) {
  const out = []
  for (const task of config?.tasks || []) {
    for (const w of taskWarnings(task)) {
      out.push({ taskId: task.id, taskName: task.name || '(未命名)', warning: w })
    }
  }
  return out
}

/**
 * 下发载荷（宿主 → 游戏服半 /data/tasks/snapshot）。
 *
 * 传输走 **GET + query**，与既有插件一致（plugins/promotion/gameOps.js:8-12 的取舍说明：
 * TShock 的 SecureRestCommand 语义就是"带 token 的 GET"，插件侧只读 args.Parameters；
 * "form body 是否被解析进 Parameters"在本项目没有先例可证，赌它会解析等于把失败做成静默）。
 *
 * `ts` 只用于日志与排障，不参与判定。
 */
export function toGamePayload(config, version) {
  // 显式守卫：传数组是**用错了**（那是任务列表，不是配置对象）。
  // 不守的话 normalizeConfig 会把数组归一成 { tasks: [] }，于是静默下发一份空配置把服端任务清空——
  // 属于最难发现的失败形态（两端都以为成功）。宁可在这里当场炸掉。
  if (Array.isArray(config)) {
    throw new Error('toGamePayload 需要配置对象 { tasks: [...] }，收到的是任务数组；'
      + '请传 { tasks } 而不是 tasks 本身（否则会静默下发空配置）')
  }
  const cfg = normalizeConfig(config)
  return {
    version,
    tasks: JSON.stringify(cfg.tasks),
    ts: new Date().toISOString(),
  }
}

/**
 * 下发载荷的字节上限守卫（规格 §12 D24 的处理）。
 *
 * 旧版把整份 task JSON 放进 URL query，受"请求行过长"限制（旧版自研 REST 服务端
 * WebRestServer.cs:598 是 65536 字符）。本件沿用 query 传输，但**显式设上限并明确报错**：
 * 超限时宁可让下发失败并对管理员说明原因，也不依赖远端报一个看不懂的 400/500。
 */
export const MAX_PAYLOAD_CHARS = 48 * 1024

/** 载荷是否超限；返回 null 表示正常，否则返回可读原因 */
export function payloadTooLarge(payload, max = MAX_PAYLOAD_CHARS) {
  const size = payload.tasks.length
  if (size <= max) return null
  return `任务配置过大（${size} 字符 > 上限 ${max} 字符）：命令文本太多，而下发端点走 URL query 传输，`
    + `请拆分任务或缩短单条命令后重试`
}
