/**
 * 自动任务（task-scheduler）—— 宿主半
 *
 * 这是旧版 TsWeb「自动任务」的插件化重写。旧版的真正形态是**进程内的一块调度器**：
 *   - 一份 JSON 配置 <TShock.SavePath>/TSWeb/Tasks/tasks.json（规格 §4.1）
 *   - 一个 1 秒节拍的调度器 + 条件判定 + 命令执行（旧版 plugin/TaskScheduler.cs:250-437）
 *   - 一张 SQLite/MySQL 表 task_execution_logs（旧版 :535-559）
 *   - 7 个 REST 端点 /data/tasks/*（旧版 plugin/Main.cs:252-258 注册）
 *   - 前端 1 个页面 + 1 个 API 模块 + 1 条路由（旧版 TasksView.vue / tasksApi.js）
 *
 * 本件的职责分工（**这是本次任务给定的架构，不是自选的**）：
 *   宿主半（本文件）  任务配置 CRUD + 持久化 + 下发（失败重试 / 连接恢复补推 / 周期对账 / 状态自证）
 *                     + tasks 界面 + 执行日志分页查看（代理服端端点）+ 审计
 *   前端半            /s/tasks：任务卡片列表 + 新建/编辑弹窗 + 执行记录，照 TasksView.vue
 *   游戏服半          TaskScheduler.dll：1 秒轮询调度器 + 条件判定 + 命令执行 + 建表与写日志
 *                     + 7 个旧版端点 + 配置接收
 *
 * 为什么调度必须落在游戏服半（而不能像 promotion 那样主要在宿主）：
 *   1. `boss_defeated` 条件要读 **TShock 进程内**的 `Main.BestiaryTracker.Kills`
 *      （旧版 TaskScheduler.cs:318-331 → GetWorldInfo.cs:332-341），宿主拿不到；
 *   2. `online_count` / `player_online` 同理是服端进程内状态；
 *   3. 命令必须在服端进程内执行，且**走 Commands.HandleCommand**——不经过
 *      `POST /api/base/players/command`（TShock /v3/server/rawcmd）：
 *      那条通道的 token 账号所在组与 `tshock.rest.command` 权限在本项目**未确认**
 *      （规格 §13.4），押注它等于把"所有任务静默全废"变成一个可能的后果；
 *      而 DLL 直接用进程内 API，不依赖任何 REST token，也不受 TShock REST 权限配置影响。
 *
 * 三条必须一致的行为（与旧版逐条对齐，见交付报告的语义对照表）：
 *   1. **1 秒节拍**（旧版 timer 周期，规格 §8.1），判定粒度就是秒；
 *   2. **配置变更立即下发**：POST /api/task-scheduler/tasks/save 在同一请求里完成
 *      落盘 + 下发，并把逐服结果原样回显（这一条是"界面显示已启用、实际没生效"
 *      那类静默失效的解药）；
 *   3. **下发/执行失败永不静默**：逐服状态进 pushStatus，经 /status 与保存响应回给前端，
 *      同时按退避重试；服端端点失败时返回**真实失败**（不再是旧版那种恒 200）。
 *
 * 与旧版的**有意差异**（每条都在交付报告里给了理由）：
 *   D1  interval 任务不再"每次开服立刻触发一次"（lastRunAt 落盘，无历史以当前时间为起点）
 *   D-失败检测 命令成功/失败/不适用按真实结果记，不再无条件 success=true
 *   D-越权   宿主侧 REST 一律 admin-only + 审计（旧版保存只需 data.rest.invsee、后端 requireManager）
 *   D3/并发  任务定义与运行期状态分离，配置替换不再丢运行期状态，且全部加锁
 *
 * 依赖：webServer / auth / servers / tshock / paths（全部由宿主或基础插件提供）
 * 约定：禁止 emoji；状态数据走 ctx.paths.dataOf('task-scheduler')（不在插件目录内）
 */
import { copyFile, mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { join } from 'node:path'

import { ACTIONS, AuditLog } from './audit.js'
import {
  configWarnings,
  emptyConfig,
  httpError,
  MAX_PAYLOAD_CHARS,
  newTaskId,
  normalizeConfig,
  normalizeTask,
  payloadTooLarge,
  taskWarnings,
  toGamePayload,
  validateTask,
} from './config.js'
import { DLL_NAME, LEGACY_ENDPOINTS, createGameOps } from './gameOps.js'

export const name = 'task-scheduler'
export const inject = ['webServer', 'auth', 'servers', 'tshock', 'paths']

/**
 * 下发/对账节奏。**不写进任务配置**：task 定义要与旧版一字不差
 * （旧版是进程内功能，没有"下发"这个概念）。
 *
 * 三个数值的理由：
 *   retryBaseMs / retryMaxMs  失败退避：从 2 秒起翻倍到 5 分钟封顶。
 *                             不设成固定短间隔是因为下发失败常见于"目标服没开机"，
 *                             无退避会把日志刷满且毫无收益。
 *   reconcileMs               周期对账：30 分钟一次无条件重推（自愈：服端重装 DLL、
 *                             服端配置被本地改动、某次下发在两侧都不留痕地丢了，都能被纠回）。
 */
export const PUSH_DEFAULTS = {
  retryBaseMs: 2000,
  retryMaxMs: 300000,
  reconcileMs: 1800000,
}

/** 单次手动下发可指定的服务器上限（防止一次请求把几十台服串行打完） */
const PUSH_LIMIT = 50

/** 执行记录分页上限（旧版前端固定 pageSize=20，规格 §12 D10 指出没有分页控件） */
const LOG_PAGE_SIZE_MAX = 200

/**
 * 任务定义的**比较键**：用于"宿主配置与服端配置是否一致"的对账。
 * 只包含定义字段（运行期字段不参与比较——它们本来就该由服端主导）。
 */
function taskFingerprint(task) {
  const t = normalizeTask(task)
  return JSON.stringify([
    t.id, t.name, t.enabled, t.triggerMode, t.intervalSeconds, t.dailyTime,
    t.condition.type, t.condition.not,
    t.condition.params.min, t.condition.params.max,
    t.condition.params.bossNames, t.condition.params.playerNames,
    t.execMode, t.commands,
  ])
}

export class TaskSchedulerService {
  constructor({ ctx, dataDir, configFile, auditFile, push }) {
    this.ctx = ctx
    this.dataDir = dataDir
    this.configFile = configFile || join(dataDir, 'tasks.json')
    this.auditFile = auditFile || join(dataDir, 'audit.jsonl')

    /**
     * 权威配置存储：**按服务器分开**。
     *
     * 为什么按服务器分而不是像 promotion 那样一份全局配置：旧版的 tasks.json 是
     * **每台游戏服各自一份**（进程内配置），而且任务内容天生是"服专属"的——
     * `online_count` / `boss_defeated` 判的是那台服的状态，`/off` 关的是那台服。
     * 若做成一份全局配置下发到所有服，一个「凌晨关服」模板就会关掉**所有**服务器，
     * 这是旧版不存在的行为，属于危险的语义扩大。
     */
    this.store = { version: 1, updatedAt: '', servers: {} }
    /** 读配置时发现的问题（文件损坏等），如实回显给管理员（旧版 D29：损坏即静默清空） */
    this.storeError = ''

    this.push = { ...PUSH_DEFAULTS, ...(push && typeof push === 'object' ? push : {}) }

    this.gameOps = createGameOps({ ctx })
    this.audit = new AuditLog({ file: this.auditFile })

    /**
     * 宿主侧期望的配置版本，**每次下发尝试都自增**（单调）。
     * 服端会拒绝比它当前版本更旧的载荷（stale），所以"重试"必须带新版本号，
     * 否则一次乱序到达的旧请求会把新配置覆盖回去。
     * 版本号是**全局**的（不是每服一个）：每台服各自比较自己的 current version，
     * 全局单调对它同样成立，而全局单点更容易排障。
     */
    this.desiredVersion = 0
    /** serverId → { version, revision, at, ok, reason }（该服**已确认应用**的那一次下发） */
    this.acked = new Map()
    /** serverId → { attempts, nextAt, lastReason, lastAt }（失败重试状态） */
    this.retry = new Map()
    /** 最近一次已知的启用服务器 id 集合（用于把"从未推过的服"也纳入未确认统计） */
    this.knownServerIds = new Set()

    this.retryTimer = null
    this.reconcileTimer = null
    this.stopped = false
    /** 正在进行的下发 promise（按服串行化，避免两次下发交错把版本号弄乱） */
    this.inflight = new Map()
  }

  // ════════════════════════════════════════════
  //  持久化
  // ════════════════════════════════════════════

  /**
   * 读宿主侧任务配置。
   *
   * 损坏时**不静默清空**（旧版 D29：LoadConfig 抛错→Tasks 空集合→下一次保存把文件覆盖成空，
   * 用户的全部任务一次性消失）。这里：
   *   1. 把坏文件另存为 tasks.json.corrupt-<时间戳>（保留证据，管理员可手工修回）；
   *   2. 内存里保持空配置，同时把原因写进 storeError，由界面显示；
   *   3. **不在损坏状态下自动写盘**，直到管理员明确做一次保存（那时才会覆盖）。
   */
  async loadStore() {
    let raw
    try {
      raw = await readFile(this.configFile, 'utf8')
    } catch (err) {
      if (err.code === 'ENOENT') {
        this.store = { version: 1, updatedAt: new Date().toISOString(), servers: {} }
        this.storeError = ''
        return this.store
      }
      throw err
    }
    try {
      const parsed = JSON.parse(raw)
      const servers = parsed && typeof parsed.servers === 'object' && parsed.servers !== null
        ? parsed.servers
        : {}
      const out = {}
      for (const [id, entry] of Object.entries(servers)) {
        const cfg = normalizeConfig(entry && typeof entry === 'object' ? entry : {})
        out[String(id)] = {
          revision: Number.isFinite(Number(entry?.revision)) ? Math.trunc(Number(entry.revision)) : 1,
          updatedAt: typeof entry?.updatedAt === 'string' ? entry.updatedAt : '',
          tasks: cfg.tasks,
        }
      }
      this.store = { version: 1, updatedAt: typeof parsed?.updatedAt === 'string' ? parsed.updatedAt : '', servers: out }
      this.storeError = ''
    } catch (err) {
      const backup = `${this.configFile}.corrupt-${Date.now()}`
      try {
        await copyFile(this.configFile, backup)
      } catch (copyErr) {
        if (copyErr.code !== 'ENOENT') {
          console.error(`[task-scheduler] 备份损坏配置失败：${copyErr.message}`)
        }
      }
      this.store = { version: 1, updatedAt: new Date().toISOString(), servers: {} }
      this.storeError = `任务配置文件无法解析（${err.message}）；已另存为 ${backup}，`
        + `当前显示为空配置。在修复该文件或保存一次配置之前，不会覆盖磁盘上的原文件。`
      console.error(`[task-scheduler] 任务配置解析失败：${err.message}（已另存 ${backup}）`)
    }
    return this.store
  }

  /** 原子写：临时文件 + 备份 + rename（照 plugins/promotion/config.js:saveConfig 的做法） */
  async saveStore() {
    this.store.updatedAt = new Date().toISOString()
    const payload = JSON.stringify(this.store, null, 2)
    await mkdir(join(this.dataDir), { recursive: true })
    const tmp = `${this.configFile}.tmp`
    await writeFile(tmp, payload, 'utf8')
    try {
      await copyFile(this.configFile, `${this.configFile}.bak`)
    } catch (err) {
      if (err.code !== 'ENOENT') throw err
    }
    await rename(tmp, this.configFile)
    this.storeError = ''
    return this.configFile
  }

  // ════════════════════════════════════════════
  //  配置读写（宿主侧 CRUD）
  // ════════════════════════════════════════════

  /** 取某台服务器的配置条目（create=true 时不存在则创建） */
  entryOf(serverId, { create = false } = {}) {
    const key = String(serverId)
    const cur = this.store.servers[key]
    if (cur) return cur
    if (!create) return null
    // 新条目从 revision **0** 起：0 的语义是"宿主从未为该服保存过配置"，
    // 于是第一次保存后正好是 1（早先这里给 1，第一次保存后变成 2，编号白跳一格）
    const fresh = { revision: 0, updatedAt: new Date().toISOString(), tasks: [] }
    this.store.servers[key] = fresh
    return fresh
  }

  /** 该服务器当前的配置修订号（0 = 宿主从未为该服保存过配置） */
  revisionOf(serverId) {
    return this.entryOf(serverId)?.revision ?? 0
  }

  /** 列出某服的宿主侧任务定义（深拷贝，调用方改动不会污染存储） */
  listTasks(serverId) {
    const entry = this.entryOf(serverId)
    if (!entry) return []
    return entry.tasks.map((t) => normalizeTask(t))
  }

  /** 取单个任务（含 commands） */
  getTask(serverId, id) {
    const entry = this.entryOf(serverId)
    if (!entry) return null
    const hit = entry.tasks.find((t) => t.id === id)
    return hit ? normalizeTask(hit) : null
  }

  /**
   * 保存任务（新建或更新）。
   *
   * **记什么由服务端说了算**：运行期字段（lastRunAt/lastRunStatus/runCount/running/lastDailyRunAt）
   * 一律不接受客户端输入——旧版允许客户端在"新建"时把它们塞进来，于是把 `lastDailyRunAt`
   * 设成今天就能让一个 daily 任务当天不触发（规格 §12 D14）。这里由 normalizeTask 只取定义字段，
   * 运行期状态完全由服端主导。
   *
   * @returns { task, warnings, created }
   */
  async saveTask(serverId, rawTask, { actor = '' } = {}) {
    const incoming = normalizeTask(rawTask)
    const isUpdate = incoming.id !== ''
    if (isUpdate) validateTask(incoming, { strictId: true })
    else validateTask(incoming)

    const entry = this.entryOf(serverId, { create: true })
    const now = new Date().toISOString()
    let created = false

    const finalTask = { ...incoming, id: incoming.id || newTaskId() }

    if (isUpdate) {
      const idx = entry.tasks.findIndex((t) => t.id === finalTask.id)
      if (idx < 0) throw httpError(404, '任务不存在')
    } else if (entry.tasks.some((t) => t.id === finalTask.id)) {
      // 新建：id 由服务端生成（旧版 TaskScheduler.cs:665-666 同），且**不接受客户端指定**
      // 一个已存在的 id（那等于改名覆盖，旧版会静默替换，见规格 §9.3 ③）
      throw httpError(409, `任务 id ${finalTask.id} 已存在`)
    }

    // 先在内存里算出"保存之后的任务清单"，据此校验下发载荷大小。
    // 为什么不放到下发时再报错：那时任务已经落盘，界面显示"保存成功"、下发却永远失败，
    // 管理员看不出问题出在这条任务上。这里当场拒绝，并且**不落盘**。
    const candidate = isUpdate
      ? entry.tasks.map((t) => (t.id === finalTask.id ? finalTask : t))
      : [...entry.tasks, finalTask]
    const tooLarge = payloadTooLarge(toGamePayload({ tasks: candidate }, 1), MAX_PAYLOAD_CHARS)
    if (tooLarge) throw httpError(400, tooLarge)

    entry.tasks = candidate
    if (!isUpdate) created = true

    entry.revision += 1
    entry.updatedAt = now
    await this.saveStore()

    await this.audit.append(ACTIONS.configWrite, {
      actor,
      serverId: String(serverId),
      op: created ? 'create' : 'update',
      taskId: finalTask.id,
      taskName: finalTask.name,
      triggerMode: finalTask.triggerMode,
      execMode: finalTask.execMode,
      commandCount: finalTask.commands.length,
      enabled: finalTask.enabled,
    })

    return { task: finalTask, warnings: taskWarnings(finalTask), created }
  }

  /** 删除任务 */
  async deleteTask(serverId, id, { actor = '' } = {}) {
    const entry = this.entryOf(serverId)
    if (!entry) throw httpError(404, '任务不存在')
    const idx = entry.tasks.findIndex((t) => t.id === id)
    if (idx < 0) throw httpError(404, '任务不存在')
    const [removed] = entry.tasks.splice(idx, 1)
    entry.revision += 1
    entry.updatedAt = new Date().toISOString()
    await this.saveStore()

    await this.audit.append(ACTIONS.configWrite, {
      actor,
      serverId: String(serverId),
      op: 'delete',
      taskId: removed.id,
      taskName: removed.name,
    })
    return { task: normalizeTask(removed) }
  }

  // ════════════════════════════════════════════
  //  下发（推送 / 重试 / 对账 / 自证）
  // ════════════════════════════════════════════

  /** 当前处于"未确认"状态的服务器 id（含从未推过的） */
  pendingServerIds() {
    const out = []
    for (const [serverId, entry] of Object.entries(this.store.servers)) {
      const ack = this.acked.get(serverId)
      if (!ack || ack.revision !== entry.revision) out.push(serverId)
    }
    return out
  }

  /** 记一次下发结果（成功/失败都记，失败是排障主线） */
  recordPush(serverId, { ok, version, revision, reason = '', extra = {} }) {
    const key = String(serverId)
    const at = new Date().toISOString()
    if (ok) {
      this.acked.set(key, { version, revision, at, ok: true, reason: '' })
      this.retry.delete(key)
    } else {
      const prev = this.retry.get(key) || { attempts: 0 }
      const attempts = prev.attempts + 1
      const delay = Math.min(this.push.retryBaseMs * (2 ** (attempts - 1)), this.push.retryMaxMs)
      this.retry.set(key, { attempts, nextAt: Date.now() + delay, lastReason: reason, lastAt: at })
    }
    return { ok, version, revision, at, reason, ...extra }
  }

  /**
   * 向指定服务器下发配置（同一台服串行化）。
   *
   * 返回结构化结果，**永不抛**：调用方负责把结果带给界面。
   */
  async pushToServer(serverId, { reason = 'change', actor = '' } = {}) {
    const key = String(serverId)
    const entry = this.entryOf(key)
    if (!entry) {
      return { serverId: key, ok: false, skipped: true, reason: '宿主侧没有该服务器的任务配置（未配置过，不下发）' }
    }
    const raw = this.ctx.servers.getRaw(key)
    if (!raw) {
      const r = this.recordPush(key, {
        ok: false,
        version: this.desiredVersion,
        revision: entry.revision,
        reason: '服务器不存在（可能已被删除）',
      })
      return { serverId: key, skipped: true, ...r }
    }
    if (raw.enabled === false) {
      // 未启用的服务器不算"下发失败"，但也不算"已确认"——它在启用后会被对账补推
      return { serverId: key, ok: false, skipped: true, reason: '服务器未启用，暂不下发（启用后将自动补推）' }
    }

    const version = ++this.desiredVersion
    // 注意：entry.tasks 是**数组**，而 toGamePayload 收的是配置对象 { tasks }。
    // 早先这里直接传了数组，normalizeConfig 会把数组当成"没有 tasks 字段"而归一成空列表，
    // 于是每一次下发携带的都是**空任务列表**——服端任务被静默清空，宿主界面却显示"已生效"。
    // 这正是本件要消灭的静默失败形态，现由 config.js:toGamePayload 的显式守卫 +
    // test/push.test.mjs 的"载荷里必须有刚保存的任务"用例钉住。
    const payload = toGamePayload({ tasks: entry.tasks }, version)

    // 空列表保护（宿主侧，与服端 /snapshot 的同一个守卫配对）：
    //   1. 任务列表为空、且宿主的配置文件读取失败（storeError）→ **拒绝下发**。
    //      这里的"空"来自读取失败而不是管理员的删除，发出去会把服端任务全部清空
    //      （这正是旧版 D29 家族"配置被意外清空"的形态，只不过发生在跨进程边界上）。
    //   2. 其余情况带 allowEmpty：列表为空时 '1'（确属管理员删光），非空时 '0'。
    //      服端只在 allowEmpty=1 时才接受空列表，两端必须一致，否则"删光全部任务"永远下发不成功。
    if (entry.tasks.length === 0 && this.storeError) {
      const r = this.recordPush(key, {
        ok: false,
        version,
        revision: entry.revision,
        reason: `宿主任务配置读取失败（${this.storeError}）且任务列表为空：拒绝下发空配置，以免清空游戏服上的任务`,
      })
      return { serverId: key, ...r }
    }
    payload.allowEmpty = entry.tasks.length === 0 ? '1' : '0'

    const tooLarge = payloadTooLarge(payload, MAX_PAYLOAD_CHARS)
    if (tooLarge) {
      const r = this.recordPush(key, { ok: false, version, revision: entry.revision, reason: tooLarge })
      return { serverId: key, ...r }
    }

    const res = await this.gameOps.pushSnapshot(raw, payload)
    if (!res.ok) {
      const r = this.recordPush(key, {
        ok: false,
        version,
        revision: entry.revision,
        reason: res.reason || '下发失败',
        extra: {
          serverHalfMissing: res.serverHalfMissing === true,
          hint: res.hint || '',
          httpStatus: res.status,
        },
      })
      return { serverId: key, ...r }
    }

    const data = res.data && typeof res.data === 'object' ? res.data : {}
    // 服端明确拒绝（stale：这是一份比它当前版本更旧的载荷）时**不算成功**：
    // 那说明有并发下发乱序到达，必须重推，否则界面会显示"已生效"而实际没生效。
    if (data.applied === false) {
      const r = this.recordPush(key, {
        ok: false,
        version,
        revision: entry.revision,
        reason: `服端未应用本次下发（${data.stale ? '版本更旧已被拒绝' : '原因未说明'}，服端当前版本 ${data.version}）`,
      })
      return { serverId: key, ...r }
    }
    if (typeof data.saveError === 'string' && data.saveError !== '') {
      // 服端应用了但落盘失败：内存里生效、重启后会丢——这属于"必须让管理员看见"的状态
      const r = this.recordPush(key, {
        ok: false,
        version,
        revision: entry.revision,
        reason: `服端已应用但落盘失败：${data.saveError}`,
      })
      return { serverId: key, ...r }
    }

    const r = this.recordPush(key, { ok: true, version, revision: entry.revision })
    void actor
    void reason
    return { serverId: key, ...r, taskCount: entry.tasks.length, serverVersion: data.version }
  }

  /** 串行化：同一台服务器同一时刻只允许一次下发的进行状态（避免版本号交错） */
  async pushOne(serverId, opts) {
    const key = String(serverId)
    const prev = this.inflight.get(key) || Promise.resolve()
    const next = prev.then(() => this.pushToServer(key, opts), () => this.pushToServer(key, opts))
    this.inflight.set(key, next.catch(() => {}))
    return next
  }

  /**
   * 批量下发。
   *
   * @param serverIds 目标服务器；缺省 = 所有"未确认"的服
   * @returns { total, ok, results, pendingCount }
   */
  async pushConfig({ serverIds = null, reason = 'change', actor = '' } = {}) {
    let targets
    if (Array.isArray(serverIds)) {
      if (serverIds.length > PUSH_LIMIT) {
        throw httpError(400, `一次最多下发 ${PUSH_LIMIT} 台服务器（收到 ${serverIds.length} 台）`)
      }
      targets = serverIds.map(String)
    } else {
      targets = this.pendingServerIds()
    }

    const results = []
    for (const id of targets) {
      results.push(await this.pushOne(id, { reason, actor }))
    }

    const okCount = results.filter((r) => r.ok).length
    const failed = results.filter((r) => !r.ok && !r.skipped)
    const skipped = results.filter((r) => r.skipped)
    if (targets.length > 0) {
      await this.audit.append(ACTIONS.configPush, {
        actor,
        reason,
        total: targets.length,
        ok: okCount,
        failed: failed.length,
        failedServers: failed.map((r) => ({ serverId: r.serverId, reason: r.reason })),
        versions: results.map((r) => ({ serverId: r.serverId, version: r.version })),
      })
    }

    if (failed.length > 0) this._scheduleRetry()

    return {
      total: targets.length,
      /**
       * ok 的语义是"**目标全部真的收到了**"。
       * 因此 skipped（例如服务器未启用 → 根本没发请求）**不能**算 ok：
       * 早先只判 `failed.length === 0`，于是"一台都没下发"会回报 ok:true，
       * 界面显示"已下发"、实际什么都没发生——正是要消灭的静默失败形态。
       */
      ok: results.length > 0 && failed.length === 0 && skipped.length === 0,
      okCount,
      failedCount: failed.length,
      skippedCount: skipped.length,
      results,
      pendingCount: this.pendingServerIds().length,
    }
  }

  /**
   * 失败退避重试：到点了就把仍未确认的服重推一遍。
   *
   * **必须与周期对账用不同的定时器字段**：早先两者共用 this.timer，而 startReconcile() 在插件启动时
   * 就占用它，于是 `if (this.timer) return` 恒真 —— 「失败重试」这条路径**从来没有真正跑起来过**，
   * 只是被 30 分钟一次的周期对账掩盖着（表面能恢复，实际退避重试是死代码）。
   * 这是典型的"文档说会重试、代码不重试"的静默失效，由 test/push.test.mjs 的重试用例钉住。
   */
  _scheduleRetry() {
    if (this.stopped) return
    const pending = this.pendingServerIds()
    if (pending.length === 0) return
    const now = Date.now()
    let due = now + this.push.retryBaseMs
    for (const id of pending) {
      const r = this.retry.get(id)
      if (r && Number.isFinite(r.nextAt)) due = Math.min(due, r.nextAt)
      else due = Math.min(due, now + this.push.retryBaseMs)
    }
    // 最小间隔取 min(500, retryBaseMs)：
    // 生产默认 retryBaseMs=2000 时下限就是 500ms（避免退避被算成 0 而变成忙等）；
    // 而测试把节奏调到毫秒级时也要真的按毫秒跑，否则一次用例被迫等半秒。
    const floor = Math.min(500, this.push.retryBaseMs)
    const delay = Math.max(floor, Math.min(due - now, this.push.retryMaxMs))
    // 已经有定时器就重排（保证"最早的截止时间"说了算），否则一次更早的失败会被旧定时器拖后
    if (this.retryTimer) clearTimeout(this.retryTimer)
    this.retryTimer = setTimeout(() => {
      this.retryTimer = null
      void this._retryTick()
    }, delay)
    if (typeof this.retryTimer.unref === 'function') this.retryTimer.unref()
  }

  async _retryTick() {
    if (this.stopped) return
    const now = Date.now()
    const due = this.pendingServerIds().filter((id) => {
      const r = this.retry.get(id)
      return !r || r.nextAt <= now
    })
    try {
      if (due.length > 0) await this.pushConfig({ serverIds: due, reason: 'retry' })
    } catch (err) {
      console.error(`[task-scheduler] 重试下发失败：${err.message}`)
    }
    this._scheduleRetry()
  }

  /**
   * 周期对账：**无条件**把每台已配置服务器的宿主配置重推一遍。
   *
   * 为什么需要（而不只是"失败重试"）：失败重试只覆盖"宿主知道失败了"的情况。
   * 现实里还有"两侧都不留痕"的丢失——服端重装了 DLL、服端配置被本地改过、
   * 某次下发在网络的半路上消失了。周期对账是这两类问题的自愈手段。
   */
  async reconcile(reason = 'reconcile') {
    const ids = Object.keys(this.store.servers)
    if (ids.length === 0) return { total: 0, ok: true, okCount: 0, failedCount: 0, skippedCount: 0, results: [], pendingCount: 0 }
    return this.pushConfig({ serverIds: ids, reason })
  }

  /** 列出当前全部服务器的下发/对账状态（供 /status 与界面显示） */
  async pushStatus({ probe = false } = {}) {
    let servers = []
    try {
      servers = await this.ctx.servers.list()
      this.knownServerIds = new Set(servers.map((s) => String(s.id)))
    } catch (err) {
      // 服务器列表取不到：如实说明，不伪造空列表（那会让界面显示"没有需要下发的服务器"）
      return {
        servers: [],
        error: `读取服务器列表失败：${err.message}`,
        desiredVersion: this.desiredVersion,
        pendingCount: 0,
      }
    }

    const out = []
    for (const s of servers) {
      const id = String(s.id)
      const entry = this.entryOf(id)
      const ack = this.acked.get(id)
      const rt = this.retry.get(id)
      const row = {
        serverId: id,
        name: s.name,
        enabled: s.enabled !== false,
        configured: !!entry,
        taskCount: entry ? entry.tasks.length : 0,
        revision: entry ? entry.revision : 0,
        ackRevision: ack ? ack.revision : 0,
        ackedAt: ack?.at || '',
        ackedVersion: ack?.version || 0,
        pending: !!entry && (!ack || ack.revision !== entry.revision),
        retryAttempts: rt?.attempts || 0,
        retryNextAt: rt?.nextAt ? new Date(rt.nextAt).toISOString() : '',
        lastError: rt?.lastReason || '',
      }
      if (probe && entry) row.probe = await this.probeServer(id)
      out.push(row)
    }

    // 已删除但仍留在配置里的服务器（孤儿配置）：必须显示出来，否则"某台的配置还在但没人推"无人可知
    for (const id of Object.keys(this.store.servers)) {
      if (!this.knownServerIds.has(id)) {
        const entry = this.store.servers[id]
        out.push({
          serverId: id,
          name: '(服务器已删除)',
          enabled: false,
          configured: true,
          orphan: true,
          taskCount: entry.tasks.length,
          revision: entry.revision,
          pending: false,
          lastError: '该服务器已不在服务器列表中，其任务配置仍保留（不会被下发）',
        })
      }
    }

    return {
      servers: out,
      desiredVersion: this.desiredVersion,
      pendingCount: this.pendingServerIds().length,
      configFile: this.configFile,
      storeError: this.storeError,
      dllName: DLL_NAME,
      legacyEndpoints: LEGACY_ENDPOINTS.map((e) => e.path),
    }
  }

  /**
   * 服端自证（probe）：读服端 /data/tasks/status，与宿主配置做**逐任务对账**。
   *
   * 这是本件对"不许静默失败"的核心手段，照 plugins/promotion 的"下发状态可查 + probe 自证"：
   *   宿主只知道"我推成功了"，不知道"服端现在是哪一份"。probe 把服端当前生效的
   *   任务清单、版本号、调度器状态、迁移来源取回来，与宿主逐条比对，
   *   把"只在宿主有 / 只在服端有 / 两边不一致"三类差异指名报出来。
   */
  async probeServer(serverId) {
    const key = String(serverId)
    const raw = this.ctx.servers.getRaw(key)
    if (!raw) return { ok: false, reason: '服务器不存在' }
    const res = await this.gameOps.fetchStatus(raw)
    if (!res.ok) {
      return {
        ok: false,
        reason: res.reason || '读取服端状态失败',
        serverHalfMissing: res.serverHalfMissing === true,
        hint: res.hint || '',
      }
    }
    const data = res.data && typeof res.data === 'object' ? res.data : {}
    const serverTasks = Array.isArray(data.tasks) ? data.tasks.map(normalizeTask) : []
    const hostTasks = this.listTasks(key)

    const hostById = new Map(hostTasks.map((t) => [t.id, t]))
    const serverById = new Map(serverTasks.map((t) => [t.id, t]))
    const onlyInHost = []
    const onlyInServer = []
    const differing = []
    const same = []
    for (const [id, t] of hostById) {
      if (!serverById.has(id)) onlyInHost.push({ id, name: t.name })
      else if (taskFingerprint(t) !== taskFingerprint(serverById.get(id))) {
        differing.push({ id, name: t.name })
      } else same.push({ id, name: t.name })
    }
    for (const [id, t] of serverById) {
      if (!hostById.has(id)) onlyInServer.push({ id, name: t.name })
    }

    const inSync = onlyInHost.length === 0 && onlyInServer.length === 0 && differing.length === 0
    return {
      ok: true,
      inSync,
      serverVersion: Number(data.version || 0),
      serverUpdatedAt: String(data.updatedAt || ''),
      serverTaskCount: serverTasks.length,
      hostTaskCount: hostTasks.length,
      same,
      onlyInHost,
      onlyInServer,
      differing,
      // 服端自己的信息：调度器在不在跑、配置从哪来、有没有本地改动
      scheduler: data.scheduler && typeof data.scheduler === 'object' ? data.scheduler : null,
      source: String(data.source || ''),
      file: String(data.file || ''),
      legacyFile: String(data.legacyFile || ''),
      localEdits: Number(data.localEdits || 0),
      saveError: String(data.saveError || ''),
      loadError: String(data.loadError || ''),
      notes: Array.isArray(data.notes) ? data.notes.map(String) : [],
      unadopted: !this.entryOf(key) && serverTasks.length > 0,
    }
  }

  /**
   * 采纳服端已有的任务配置到宿主（迁移入口）。
   *
   * 为什么需要它：旧版的任务定义原本只存在**游戏服的 tasks.json** 里。
   * 新架构下宿主是配置权威，若宿主对某台服"没有任何配置"，界面会显示"暂无任务"，
   * 而服端其实还在按迁移过来的任务自动跑——这就是两端不一致的静默状态。
   * 采纳是**显式动作**（不是悄悄把服端配置写成宿主配置），并记审计。
   */
  async adoptFromServer(serverId, { actor = '' } = {}) {
    const key = String(serverId)
    const raw = this.ctx.servers.getRaw(key)
    if (!raw) throw httpError(404, '服务器不存在')
    const res = await this.gameOps.fetchStatus(raw)
    if (!res.ok) {
      throw httpError(res.status === 501 ? 501 : 502, res.reason || '读取服端状态失败', {
        serverHalfMissing: res.serverHalfMissing === true,
        hint: res.hint || '',
      })
    }
    const data = res.data && typeof res.data === 'object' ? res.data : {}
    const tasks = Array.isArray(data.tasks) ? data.tasks.map(normalizeTask) : []

    const existing = this.entryOf(key)
    if (existing && existing.tasks.length > 0) {
      // 采纳是"从无到有"的动作；已有配置时拒绝，避免把宿主的任务整份冲掉
      throw httpError(409, '该服务器在宿主侧已有任务配置，采纳会覆盖它；请先确认后再操作（如需强制采纳请先清空）')
    }

    const entry = this.entryOf(key, { create: true })
    entry.tasks = tasks
    entry.revision += 1
    entry.updatedAt = new Date().toISOString()
    await this.saveStore()

    await this.audit.append(ACTIONS.configWrite, {
      actor,
      serverId: key,
      op: 'adopt',
      taskCount: tasks.length,
      serverVersion: data.version,
      source: data.source,
    })

    return {
      taskCount: tasks.length,
      tasks,
      warnings: configWarnings({ tasks }),
      serverVersion: Number(data.version || 0),
      source: String(data.source || ''),
      legacyFile: String(data.legacyFile || ''),
    }
  }

  // ════════════════════════════════════════════
  //  手动执行 / 执行记录（代理服端）
  // ════════════════════════════════════════════

  /**
   * 手动执行一个任务。
   *
   * 语义逐条照旧版（TaskScheduler.cs:736-764）：
   *   - 走服端 /data/tasks/run，由**服端**执行（调度器与执行器都在那边）；
   *   - `force=1` 跳过条件判断；缺省/0 走条件判断；
   *   - **不看 enabled**：禁用中的任务也能被手动执行（界面同样不禁用「执行」按钮）；
   *   - **发射即返回**：拿不到本次执行结果，只能事后查记录（旧版同，规格 §5.3）。
   */
  async runTask(serverId, id, force, { actor = '' } = {}) {
    const key = String(serverId)
    const task = this.getTask(key, id)
    if (!task) throw httpError(404, '任务不存在')

    const raw = this.ctx.servers.getRaw(key)
    if (!raw) throw httpError(404, '服务器不存在')

    const res = await this.gameOps.runTask(raw, id, force)
    if (!res.ok) {
      throw httpError(res.status === 501 ? 501 : (res.status || 502), res.reason || '执行失败', {
        serverHalfMissing: res.serverHalfMissing === true,
        hint: res.hint || '',
      })
    }

    await this.audit.append(ACTIONS.taskRun, {
      actor,
      serverId: key,
      taskId: id,
      taskName: task.name,
      force: force === true,
      triggerMode: task.triggerMode,
      execMode: task.execMode,
      commandCount: task.commands.length,
    })

    return { taskId: id, force: force === true, serverResponse: res.data }
  }

  /**
   * 执行记录分页（代理服端 /data/tasks/log）。
   *
   * 旧版把分页固定成 page=1&pageSize=20 且界面没有翻页控件（规格 §12 D10）；
   * 本件保留同样的默认值，但把 page/pageSize 真正接通（界面加了翻页）。
   */
  async listLogs(serverId, { taskId = '', page = 1, pageSize = 20 } = {}) {
    const key = String(serverId)
    const raw = this.ctx.servers.getRaw(key)
    if (!raw) throw httpError(404, '服务器不存在')
    const p = Math.max(1, Number(page) || 1)
    const ps = Math.min(Math.max(1, Number(pageSize) || 20), LOG_PAGE_SIZE_MAX)
    const res = await this.gameOps.listLogs(raw, { taskId, page: p, pageSize: ps })
    if (!res.ok) {
      throw httpError(res.status === 501 ? 501 : (res.status || 502), res.reason || '读取执行记录失败', {
        serverHalfMissing: res.serverHalfMissing === true,
        hint: res.hint || '',
      })
    }
    return res.data
  }

  /** 执行记录详情（代理服端 /data/tasks/log/detail） */
  async logDetail(serverId, id) {
    const key = String(serverId)
    const raw = this.ctx.servers.getRaw(key)
    if (!raw) throw httpError(404, '服务器不存在')
    const res = await this.gameOps.logDetail(raw, id)
    if (!res.ok) {
      throw httpError(res.status === 501 ? 501 : (res.status || 502), res.reason || '读取记录详情失败', {
        serverHalfMissing: res.serverHalfMissing === true,
        hint: res.hint || '',
      })
    }
    return res.data
  }

  // ════════════════════════════════════════════
  //  生命周期
  // ════════════════════════════════════════════

  /** 启动周期对账定时器（unref：不阻止进程退出） */
  startReconcile() {
    if (this.reconcileTimer) return
    this.reconcileTimer = setTimeout(() => {
      this.reconcileTimer = null
      void (async () => {
        try {
          await this.reconcile('periodic')
        } catch (err) {
          console.error(`[task-scheduler] 周期对账失败：${err.message}`)
        }
        this.startReconcile()
      })()
    }, this.push.reconcileMs)
    if (typeof this.reconcileTimer.unref === 'function') this.reconcileTimer.unref()
  }

  dispose() {
    this.stopped = true
    for (const key of ['retryTimer', 'reconcileTimer']) {
      if (this[key]) {
        clearTimeout(this[key])
        this[key] = null
      }
    }
  }
}

// ════════════════════════════════════════════
//  插件入口
// ════════════════════════════════════════════

export async function apply(ctx, options = {}) {
  const dataDir = ctx.paths.dataOf('task-scheduler')
  // options.push：只用于测试把"重试/对账节奏"调到毫秒级（配置里没有节奏字段，见 PUSH_DEFAULTS）
  const service = new TaskSchedulerService({ ctx, dataDir, push: options.push })
  const app = ctx.webServer.app

  /**
   * 鉴权：**一律 admin-only**。
   *
   * 这是本件必改缺陷之三（越权）的修法。旧版的两道门都比这宽：
   *   - TShock 侧端点权限是 `data.rest.invsee`（旧版 Main.cs:254-258）——一个"看数据"的权限；
   *   - 旧版后端是 `requireManager`（admin + **subadmin**）。
   *   而任务执行恒以 `superadmin` 身份跑命令（旧版 :470-472 硬编码组名），
   *   于是**子管理员可以持久化任意 superadmin 命令**，等它到点自动执行。
   * 本件把"谁能配置任务"收成 admin（`requireAdmin()` 的实现是 usergroup !== 'admin' → 403，
   * 见 plugins/accounts/index.js:320-328），并给每次变更写审计。
   *
   * 服端执行身份仍然是 superadmin——这是**功能必需**：大量命令的正常使用需要权限，
   * 换成一个低权限组会让任务大面积失败。所以边界放在"配置权"上，而不是执行身份上。
   * 这个权衡在交付报告里写明了。
   */
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]

  /** 解析目标服务器（照 plugins/base/index.js 的 resolveServer：x-server-id 头 > query > 第一台） */
  async function resolveRaw(req) {
    const id = req.headers['x-server-id'] || (req.query && req.query.serverId)
    if (id) {
      const raw = ctx.servers.getRaw(String(id))
      if (raw) return raw
      throw httpError(404, '目标服务器不存在')
    }
    const list = await ctx.servers.list()
    if (!list || list.length === 0) throw httpError(400, '尚未配置任何服务器')
    const raw = ctx.servers.getRaw(list[0].id)
    if (!raw) throw httpError(400, '尚未配置任何服务器')
    return raw
  }

  /** 统一错误出口：**HTTP 状态码 + body.status 双写**，杜绝旧版"恒 200"的静默失败形态 */
  function fail(res, err) {
    const status = Number(err?.status) || 500
    console.error(`[task-scheduler] ${status} ${err?.message || err}`)
    res.status(status).json({
      status,
      ok: false,
      error: err?.message || String(err),
      ...(err?.serverHalfMissing ? { serverHalfMissing: true, hint: err.hint || '' } : {}),
    })
  }

  /** 成功出口：body 里同时给 `status`（旧版前端按它判断）与 `ok` */
  function ok(res, body) {
    res.json({ status: 200, ok: true, ...body })
  }

  /** 从请求里取 task 对象：兼容旧版 `task=<JSON串>` 与现代化的 `{ task: {...} }` 两种形态 */
  function readTaskBody(req) {
    const body = req.body && typeof req.body === 'object' ? req.body : {}
    const raw = body.task !== undefined ? body.task : req.query?.task
    if (raw === undefined || raw === null || raw === '') throw httpError(400, '缺少 task 参数')
    if (typeof raw === 'string') {
      try {
        return JSON.parse(raw)
      } catch (err) {
        throw httpError(400, `task 不是合法 JSON：${err.message}`)
      }
    }
    if (typeof raw === 'object') return raw
    throw httpError(400, 'task 参数类型不正确（应为对象或 JSON 字符串）')
  }

  /** `force` 解析：**接受旧版的 0/1 与 true/false**；其余取值明确报错（不再静默当 false） */
  function readForce(raw) {
    if (raw === undefined || raw === null || raw === '') return false
    const s = String(raw).trim().toLowerCase()
    if (s === '1' || s === 'true') return true
    if (s === '0' || s === 'false') return false
    throw httpError(400, `force 取值不合法（只接受 0/1/true/false，收到 ${JSON.stringify(raw)}）`)
  }

  // ── 任务列表（配置 + 服端运行期状态）────────────────────────────
  // 旧版 /data/tasks/list 由服端直接给（含运行期状态、不含 commands）。
  // 本件由宿主给：定义来自宿主权威配置，运行期状态从服端取回来合并；
  // 取不到服端时**如实标注 runtimeError**（界面会显示"服端状态不可用"），
  // 绝不假装"没有运行期状态"。
  app.get('/api/task-scheduler/tasks/list', ...admin, async (req, res) => {
    try {
      const raw = await resolveRaw(req)
      const serverId = String(raw.id)
      const tasks = service.listTasks(serverId)

      let runtime = new Map()
      let runtimeError = ''
      let remote = null
      // **无论宿主有没有任务都要问服端一次**：
      //   - 宿主有任务 → 取运行期状态（lastRunAt/lastRunStatus/runCount/running）合并进列表
      //   - 宿主**没有**任务 → 也要问，否则 `unadopted`（服端有任务、宿主没有，通常是旧版
      //     配置迁移过来的）永远算不出来，而这个提示正是"旧数据怎么进来"的唯一入口。
      //     早先只在 tasks.length > 0 时去问，`unadopted` 因此恒为 null——属于静默失效，
      //     由 test/push.test.mjs 的 unadopted 用例挡下。
      {
        const st = await service.gameOps.fetchStatus(raw)
        if (st.ok && st.data && Array.isArray(st.data.tasks)) {
          remote = st.data
          runtime = new Map(st.data.tasks.map((t) => [String(t.id), t]))
        } else {
          runtimeError = st.reason || '读取游戏服任务运行状态失败'
        }
      }

      const list = tasks.map((t) => {
        const rt = runtime.get(t.id) || {}
        return {
          id: t.id,
          name: t.name,
          enabled: t.enabled,
          triggerMode: t.triggerMode,
          intervalSeconds: t.intervalSeconds,
          dailyTime: t.dailyTime,
          condition: t.condition,
          execMode: t.execMode,
          commandCount: t.commands.length,
          // 运行期字段：来自服端（旧版 /list 也返回这几个）
          lastRunAt: rt.lastRunAt || '',
          lastRunStatus: rt.lastRunStatus || '',
          runCount: Number(rt.runCount || 0),
          running: rt.running === true,
          // 运行期状态是否可用：false 时上面四个字段没有意义，界面必须提示
          runtimeAvailable: runtime === null ? false : runtime.has(t.id) || runtimeError === '',
          // 该任务是否已在服端存在（宿主有、服端没有 = 尚未下发成功）
          presentOnServer: runtime === null ? null : runtime.has(t.id),
        }
      })

      const unadopted = remote && tasks.length === 0 && Array.isArray(remote.tasks) && remote.tasks.length > 0
        ? { count: remote.tasks.length, names: remote.tasks.map((t) => t.name), source: String(remote.source || ''), legacyFile: String(remote.legacyFile || '') }
        : null

      ok(res, {
        serverId,
        serverName: raw.name,
        tasks: list,
        total: list.length,
        warnings: configWarnings({ tasks }),
        runtimeError,
        serverVersion: remote ? Number(remote.version || 0) : null,
        serverEditsPending: remote ? Number(remote.localEdits || 0) : 0,
        unadopted,
        configFile: service.configFile,
        storeError: service.storeError,
        dllName: DLL_NAME,
        legacyEndpoints: LEGACY_ENDPOINTS.map((e) => e.path),
      })
    } catch (err) {
      fail(res, err)
    }
  })

  // ── 单任务（含 commands）────────────────────────────────────────
  app.get('/api/task-scheduler/tasks/get', ...admin, async (req, res) => {
    try {
      const raw = await resolveRaw(req)
      const id = String(req.query?.id || '')
      if (!id) throw httpError(400, '缺少 id 参数')
      const task = service.getTask(String(raw.id), id)
      if (!task) throw httpError(404, '任务不存在')

      // 运行期字段：旧版 /get 不含它们（[JsonIgnore]），但界面要显示，
      // 所以这里额外给一个 runtime 块（不改 task 本身的字段形状，仍与旧版一致）
      let runtime = null
      let runtimeError = ''
      const st = await service.gameOps.fetchStatus(raw)
      if (st.ok && st.data && Array.isArray(st.data.tasks)) {
        const hit = st.data.tasks.find((t) => String(t.id) === id)
        runtime = hit
          ? {
            lastRunAt: hit.lastRunAt || '',
            lastRunStatus: hit.lastRunStatus || '',
            lastDailyRunAt: hit.lastDailyRunAt || '',
            runCount: Number(hit.runCount || 0),
            running: hit.running === true,
            lastForced: hit.lastForced === true,
          }
          : null
      } else {
        runtimeError = st.reason || '读取游戏服任务运行状态失败'
      }

      ok(res, {
        serverId: String(raw.id),
        task,
        runtime,
        runtimeError,
        warnings: taskWarnings(task),
      })
    } catch (err) {
      fail(res, err)
    }
  })

  // ── 保存（新建/更新）→ 落盘 + 立即下发 ──────────────────────────
  app.post('/api/task-scheduler/tasks/save', ...admin, async (req, res) => {
    try {
      const raw = await resolveRaw(req)
      const serverId = String(raw.id)
      const incoming = readTaskBody(req)
      const actor = req.user?.username || req.user?.name || ''

      const { task, warnings, created } = await service.saveTask(serverId, incoming, { actor })
      const push = await service.pushConfig({ serverIds: [serverId], reason: created ? 'create' : 'update', actor })

      ok(res, {
        message: '任务已保存',
        id: task.id,
        created,
        task,
        warnings,
        push,
        // 下发失败**显式**回给界面（旧版这里是彻底静默的：界面只看到"已保存"）
        pushOk: push.ok,
        pushError: push.ok ? '' : (push.results[0]?.reason || '下发失败'),
      })
    } catch (err) {
      fail(res, err)
    }
  })

  // ── 删除 → 落盘 + 立即下发 ─────────────────────────────────────
  app.post('/api/task-scheduler/tasks/delete', ...admin, async (req, res) => {
    try {
      const raw = await resolveRaw(req)
      const serverId = String(raw.id)
      const id = String((req.body && req.body.id) || req.query?.id || '')
      if (!id) throw httpError(400, '缺少 id 参数')
      const actor = req.user?.username || req.user?.name || ''

      // 旧版在任务运行中拒绝删除（"任务正在执行中，无法删除"）。
      // 运行状态只有服端知道，所以这里先问一次服端——这是**旧版语义的保留**，
      // 不是新增限制。（存在极小的竞态窗口：查询与下发之间任务可能刚好开始执行，
      // 届时服端会自然地把该任务从待调度集合里移除，正在执行的那一次照常跑完。）
      const st = await service.gameOps.fetchStatus(raw)
      if (st.ok && st.data && Array.isArray(st.data.tasks)) {
        const hit = st.data.tasks.find((t) => String(t.id) === id)
        if (hit && hit.running === true) throw httpError(409, '任务正在执行中，无法删除')
      }

      const { task } = await service.deleteTask(serverId, id, { actor })
      const push = await service.pushConfig({ serverIds: [serverId], reason: 'delete', actor })

      ok(res, {
        message: '任务已删除',
        id: task.id,
        task,
        push,
        pushOk: push.ok,
        pushError: push.ok ? '' : (push.results[0]?.reason || '下发失败'),
      })
    } catch (err) {
      fail(res, err)
    }
  })

  // ── 手动执行（代理服端）────────────────────────────────────────
  app.post('/api/task-scheduler/tasks/run', ...admin, async (req, res) => {
    try {
      const raw = await resolveRaw(req)
      const id = String((req.body && req.body.id) || req.query?.id || '')
      if (!id) throw httpError(400, '缺少 id 参数')
      const force = readForce((req.body && req.body.force !== undefined) ? req.body.force : req.query?.force)
      const actor = req.user?.username || req.user?.name || ''
      const out = await service.runTask(String(raw.id), id, force, { actor })
      ok(res, { message: '任务已开始执行', taskId: out.taskId, force: out.force })
    } catch (err) {
      fail(res, err)
    }
  })

  // ── 执行记录分页 / 详情（代理服端）──────────────────────────────
  // 路径同时注册 `log`（旧版契约，/data/tasks/log）与 `logs`（本次任务描述里的写法），
  // 避免调用方因为一个字母的差异而拿不到数据。
  const logListHandler = async (req, res) => {
    try {
      const raw = await resolveRaw(req)
      const taskId = String(req.query?.taskId || '')
      const page = req.query?.page
      const pageSize = req.query?.pageSize
      const data = await service.listLogs(String(raw.id), { taskId, page, pageSize })
      const body = data && typeof data === 'object' ? data : {}
      ok(res, {
        serverId: String(raw.id),
        logs: Array.isArray(body.logs) ? body.logs : [],
        total: Number(body.total || 0),
        page: Number(body.page || page || 1),
        pageSize: Number(body.pageSize || pageSize || 20),
      })
    } catch (err) {
      fail(res, err)
    }
  }
  app.get('/api/task-scheduler/tasks/log', ...admin, logListHandler)
  app.get('/api/task-scheduler/tasks/logs', ...admin, logListHandler)

  const logDetailHandler = async (req, res) => {
    try {
      const raw = await resolveRaw(req)
      const id = String(req.query?.id || '')
      if (!id) throw httpError(400, '缺少 id 参数')
      const data = await service.logDetail(String(raw.id), id)
      const body = data && typeof data === 'object' ? data : {}
      const log = body.log || null
      if (!log) throw httpError(404, '记录不存在')
      ok(res, { serverId: String(raw.id), log })
    } catch (err) {
      fail(res, err)
    }
  }
  app.get('/api/task-scheduler/tasks/log/detail', ...admin, logDetailHandler)
  app.get('/api/task-scheduler/tasks/logs/detail', ...admin, logDetailHandler)

  // ── 下发状态（含 probe 自证）───────────────────────────────────
  app.get('/api/task-scheduler/status', ...admin, async (req, res) => {
    try {
      const probe = String(req.query?.probe || '') === '1' || String(req.query?.probe || '') === 'true'
      const status = await service.pushStatus({ probe })
      ok(res, status)
    } catch (err) {
      fail(res, err)
    }
  })

  // ── 手动重推（界面的「重新下发」按钮）──────────────────────────
  app.post('/api/task-scheduler/push', ...admin, async (req, res) => {
    try {
      const body = req.body && typeof req.body === 'object' ? req.body : {}
      const actor = req.user?.username || req.user?.name || ''
      let serverIds = null
      if (Array.isArray(body.serverIds)) serverIds = body.serverIds.map(String)
      else if (body.serverId) serverIds = [String(body.serverId)]
      const push = await service.pushConfig({ serverIds, reason: 'manual', actor })
      ok(res, { push, pendingCount: push.pendingCount })
    } catch (err) {
      fail(res, err)
    }
  })

  // ── 采纳服端已有配置（旧版数据迁移入口）────────────────────────
  app.post('/api/task-scheduler/adopt', ...admin, async (req, res) => {
    try {
      const raw = await resolveRaw(req)
      const actor = req.user?.username || req.user?.name || ''
      const out = await service.adoptFromServer(String(raw.id), { actor })
      const push = await service.pushConfig({ serverIds: [String(raw.id)], reason: 'adopt', actor })
      ok(res, { message: `已采纳服端 ${out.taskCount} 个任务`, ...out, push })
    } catch (err) {
      fail(res, err)
    }
  })

  // ── 审计尾部 ───────────────────────────────────────────────────
  app.get('/api/task-scheduler/audit', ...admin, async (req, res) => {
    try {
      const limit = Number(req.query?.limit || 100)
      ok(res, { entries: await service.audit.tail(limit) })
    } catch (err) {
      fail(res, err)
    }
  })

  // ── 启动 ───────────────────────────────────────────────────────
  // 做成一个**可 await 的**启动流程：apply 会等它就绪再返回 dispose
  // （与 plugins/promotion/index.js:623,778 同款——loader.js:239 是 `return await mod.apply(c)`，
  //  所以 apply 可以是 async 且把 dispose 函数作为 promise 的结果返回）。
  // 这样测试里 `await apply(ctx)` 之后配置一定已经读进来了，不必靠轮询去猜。
  const ready = (async () => {
    await service.loadStore()
    const configured = Object.keys(service.store.servers).length
    console.log(
      `[task-scheduler] 已挂载：任务界面 /s/tasks；`
      + `已配置 ${configured} 台服务器；下发端点 ${LEGACY_ENDPOINTS.map((e) => e.path).join(' ')}`
      + `（需要游戏服安装 ${DLL_NAME}）；`
      + `对账周期 ${Math.round(service.push.reconcileMs / 60000)} 分钟`
      + (service.storeError ? `；配置读取有问题：${service.storeError}` : ''),
    )
    // 启动即补推一次未确认的配置（等价于"连接恢复补推"的首次触发）
    try {
      await service.pushConfig({ reason: 'startup' })
    } catch (err) {
      console.error(`[task-scheduler] 启动补推失败：${err.message}`)
    }
    service.startReconcile()
  })()

  // 连接恢复补推 / 服务器列表加载后补推。
  // 订阅放在 await ready **之前**：这样"启动过程中就发生的连接恢复"不会被漏掉
  // （事件回调自己 await ready，保证不会在配置读进来之前下发）。
  // 订阅失败只降级"补推"这一层兜底，插件照常工作，但**必须记日志**（不静默）。
  try {
    ctx.on('push/connected', () => {
      void ready.then(() => service.pushConfig({ reason: 'reconnect' })).catch((err) => {
        console.error(`[task-scheduler] 连接恢复补推失败：${err.message}`)
      })
    })
    ctx.on('servers/loaded', () => {
      void ready.then(() => service.pushConfig({ reason: 'servers-loaded' })).catch((err) => {
        console.error(`[task-scheduler] 服务器列表加载后补推失败：${err.message}`)
      })
    })
  } catch (err) {
    console.error(`[task-scheduler] 事件订阅失败（连接恢复补推不可用）：${err.message}`)
  }

  await ready.catch((err) => {
    // 启动流程自身出错**不能**让插件挂不上（那会让整个界面消失、连配置都改不了）：
    // 记日志并在没有对账定时器的状态下继续提供端点，管理员仍能读配置/改配置/手动下发。
    console.error(`[task-scheduler] 启动流程异常（插件仍会挂载，但自动对账可能不可用）：${err.message}`)
    try { service.startReconcile() } catch { /* 已经启动或不可用：忽略 */ }
  })

  return () => service.dispose()
}
