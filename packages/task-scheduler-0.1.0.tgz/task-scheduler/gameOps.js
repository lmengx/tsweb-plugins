/**
 * 自动任务 —— 游戏服调用层（宿主 → TShock）
 *
 * 端点前缀 `/data/tasks/*`（**沿用旧版前缀**，见规格 §9.1 的路由清单）：
 * 旧版这 7 个端点由 TSWeb 主插件注册、前端经后端通用代理直连。本件把它们**原样保留**
 * 在游戏服半 TaskScheduler.dll 里，语义逐条对齐（见 endpoints 表），这样：
 *   1. 任何按旧版契约写的调用方（脚本、其它工具）不需要改；
 *   2. 日志表/任务定义都在同一侧，不存在"两套后端各自记一份日志"的分裂。
 *
 * 传输契约：**GET + query 参数**。理由与既有插件一致
 * （plugins/promotion/gameOps.js:8-12、plugins/base/index.js 的注释）：
 * TShock 的 SecureRestCommand 语义是"带 token 的 GET"，插件侧只读 args.Parameters；
 * "form body 是否被解析进 Parameters"在本项目没有先例可证，赌它会解析等于把失败做成静默。
 * 注意旧版前端 tasksApi.js:16 是用 POST 发 `task=<JSON串>` 的——但那是**旧版自研后端**的
 * /api/tshock/* 通用代理转发，最终落到 TShock 侧仍是 args.Parameters（含 query 与 form 合并）。
 * 本件统一走 query，与 promotion / base / online-stats 的既有做法一致。
 *
 * 错误语义照 promotion / online-stats 的既有约定，保证"游戏服半缺失"在各插件里表现一致：
 *   404      → 501 + serverHalfMissing=true（目标服没装 TaskScheduler.dll）
 *   401/403  → 502（token 缺 data.rest.invsee 权限）
 *   400      → 400 + 服端原文（参数被服端拒绝，不要让管理员只看到"游戏服返回异常"）
 *   网络/超时 → 502
 *
 * **失败永不静默**（本件必改缺陷之四）：本文件的每个调用都返回结构化结果，
 * 调用方必须把 ok=false 的原因一路带到界面；不提供任何"失败返回空数组"的便捷封装
 * （那正是旧版让"全服在线数静默失效"的形态，对照 plugins/base/plugin/WebRestServer 的历史教训）。
 */

/** 游戏服半的端点前缀 */
export const SERVER_HALF_PREFIX = '/data/tasks'

/** 游戏服半的 DLL 名（报错文案用） */
export const DLL_NAME = 'TaskScheduler.dll'

/** 本件端点的权限节点（与 TShock 侧 SecureRestCommand 注册的权限一致，照旧版 Main.cs:254） */
export const REST_PERMISSION = 'data.rest.invsee'

/**
 * 旧版 7 个端点的**契约表**（唯一权威定义：文档、测试与实现都引这里）。
 *
 * `commandsReturned` / `runtimeFields` 两列是逐条对齐旧版语义的关键：
 *   - `/data/tasks/list` **不返回 commands**（旧版 TaskScheduler.cs:604-631），只给 commandCount；
 *     前端要编辑时必须再调 `/get`（TasksView.vue:219-235 的 openEdit 就是这么做的）。
 *   - 运行期字段只有 `/list` 返回（lastRunAt/lastRunStatus/runCount/running）；
 *     `/get` 返回的是 AutoTask 的序列化结果，旧版里那 4 个字段带 [JsonIgnore] 故**不在**其中。
 */
export const LEGACY_ENDPOINTS = [
  {
    path: '/data/tasks/list',
    method: 'GET',
    dll: 'TaskSchedulerEndpoints.List',
    returns: '任务列表（不含 commands，含 commandCount 与运行期状态）',
  },
  {
    path: '/data/tasks/get',
    method: 'GET',
    dll: 'TaskSchedulerEndpoints.Get',
    returns: '单个任务完整定义（含 commands）',
  },
  {
    path: '/data/tasks/save',
    method: 'GET',
    dll: 'TaskSchedulerEndpoints.Save',
    returns: '{ status:200, message:"任务已保存", id }',
  },
  {
    path: '/data/tasks/delete',
    method: 'GET',
    dll: 'TaskSchedulerEndpoints.Delete',
    returns: '{ status:200, message:"任务已删除" }',
  },
  {
    path: '/data/tasks/run',
    method: 'GET',
    dll: 'TaskSchedulerEndpoints.Run',
    returns: '{ status:200, message:"任务已开始执行", taskId }',
  },
  {
    path: '/data/tasks/log',
    method: 'GET',
    dll: 'TaskSchedulerEndpoints.LogList',
    returns: '{ status:200, logs:[...], total, page, pageSize }',
  },
  {
    path: '/data/tasks/log/detail',
    method: 'GET',
    dll: 'TaskSchedulerEndpoints.LogDetail',
    returns: '{ status:200, log:{ ...含 commands 明细 } }',
  },
]

/**
 * 本件新增的两个端点（**不是**旧版契约，是"下发 + 自证"协议，照 plugins/promotion 的做法）：
 *   GET /data/tasks/snapshot   接收宿主下发的整份任务配置（幂等，带单调版本号，拒绝旧载荷）
 *   GET /data/tasks/status     服端当前生效的整份配置 + 调度器状态 + 迁移来源（排障/自证）
 *
 * 为什么不复用 /data/tasks/save：那个是**单任务**、且按旧版语义会改运行期状态
 * （SaveTaskApi 的替换语义，规格 §9.3 ③）。整份替换需要"保留 id 相同的任务运行期字段"
 * 与"oldVersion 拒绝"两条保证，混进 /save 会让旧调用方的行为发生变化。
 */
export const SNAPSHOT_ENDPOINT = '/data/tasks/snapshot'
export const STATUS_ENDPOINT = '/data/tasks/status'

/** 构造带 status 的错误（宿主路由按 err.status 回状态码） */
export function httpError(status, message, extra = {}) {
  const err = new Error(message)
  err.status = status
  Object.assign(err, extra)
  return err
}

/**
 * "端点缺失（404）"的默认口径：本件自己的端点在 404 时只可能是游戏服没装 TaskScheduler.dll。
 * 文案要给出**可操作**的下一步（装在哪个页面点哪个按钮）。
 */
const DEFAULT_MISSING = {
  status: 501,
  dllName: DLL_NAME,
  message: `游戏服端未安装 ${DLL_NAME}`,
  hint: '请在「插件下发」页对该服务器启用本插件',
}

/** 把 query 值统一成字符串（undefined/null 一律空串，避免拼出 "undefined"） */
function qv(value) {
  return value == null ? '' : String(value)
}

/**
 * 创建游戏服调用层。
 *
 * @param ctx 宿主上下文（需要 ctx.tshock.fetchFor 与 ctx.servers）
 */
export function createGameOps({ ctx }) {
  /**
   * 一次 GET 调用。返回 { ok, status, data, serverId, pathname, params }，
   * **不抛异常**——调用方（路由层）按 ok 决定回什么码，这样"失败原因"能完整上行。
   *
   * 传 absolute=true 时不拼本件前缀（取别的插件的端点，如 base 的用户组列表）。
   */
  async function callGet(server, pathname, params = {}, { absolute = false, missing = DEFAULT_MISSING } = {}) {
    const path = absolute ? pathname : `${SERVER_HALF_PREFIX}${pathname}`
    let result
    try {
      result = await ctx.tshock.fetchFor(server, path, params)
    } catch (err) {
      // fetchFor 自身抛错（服务器记录损坏、URL 构造失败等）：归为 502，附原文
      return {
        ok: false,
        status: 502,
        serverId: server.id,
        pathname: path,
        params,
        data: null,
        reason: `调用游戏服失败：${err.message}`,
      }
    }

    const status = Number(result?.status || 0)
    const data = result?.data ?? null

    if (status === 404) {
      /**
       * 404 有两种含义，必须区分开（不区分就会把业务错误说成"没装 DLL"，
       * 让管理员去查一个根本没坏的东西）：
       *   a) 路由不存在 → 目标服没装 TaskScheduler.dll（回包通常是空/HTML，没有我们的字段）
       *   b) 处理器自己回的 404 → 业务语义，例如"执行记录不存在"（回包带 error/message）
       * 判别依据：回包里有没有一句人话。
       */
      const msg = serverMessage(data)
      if (msg) {
        return {
          ok: false,
          status: 404,
          serverId: server.id,
          pathname: path,
          params,
          data,
          reason: msg,
        }
      }
      return {
        ok: false,
        status: missing.status,
        serverId: server.id,
        pathname: path,
        params,
        data,
        serverHalfMissing: true,
        dllName: missing.dllName,
        reason: missing.message,
        hint: missing.hint,
      }
    }
    if (status === 401 || status === 403) {
      return {
        ok: false,
        status: 502,
        serverId: server.id,
        pathname: path,
        params,
        data,
        reason: `游戏服拒绝了本次调用（HTTP ${status}）：该服务器的 TShock REST token 需要 ${REST_PERMISSION} 权限`,
      }
    }
    /**
     * 其余 4xx 一律**保留服端状态码与原文**（400 参数被拒、409 空列表守卫等）。
     * 早先只有 400 被单独放行，409 会掉进下面的"5xx/异常"分支被压成 502 +
     * 一句笼统的"游戏服返回异常"，服端辛苦写明的拒绝理由（"拒绝应用空任务列表…"）就丢了。
     */
    if (status >= 400 && status < 500) {
      return {
        ok: false,
        status,
        serverId: server.id,
        pathname: path,
        params,
        data,
        reason: serverMessage(data) || `游戏服拒绝了本次请求（HTTP ${status}）`,
      }
    }
    if (!result?.ok || status >= 500) {
      return {
        ok: false,
        status: 502,
        serverId: server.id,
        pathname: path,
        params,
        data,
        reason: `游戏服返回异常（HTTP ${status || '无响应'}）`,
      }
    }
    return { ok: true, status, serverId: server.id, pathname: path, params, data }
  }

  /** 从服端回包里取一句人话（服端各端的字段名不完全统一：error / message / detail） */
  function serverMessage(data) {
    if (!data || typeof data !== 'object') return ''
    for (const key of ['error', 'message', 'detail']) {
      const v = data[key]
      if (typeof v === 'string' && v.trim() !== '') return v.trim()
    }
    return ''
  }

  return {
    callGet,
    serverMessage,

    /**
     * 下发整份任务配置（宿主权威 → 游戏服）。
     *
     * 返回值**永远**是结构化结果（不抛），调用方负责把它写进 pushStatus 并回给界面。
     * 服端会拒绝 version 更旧的载荷（stale=true），所以重试必须带**新的** version
     * （见 index.js 的 desiredVersion 注释）。
     *
     * `allowEmpty=1` 只在宿主**明确**要下发空任务列表时发送：服端在"自己还有任务、
     * 收到的却是空列表、又没带 allowEmpty"时会拒绝（HTTP 409），这是两端的同一个守卫——
     * 防止宿主侧的读取异常/采纳失败把服端任务静默清空（旧版 D29 家族的形态）。
     */
    async pushSnapshot(server, payload) {
      return callGet(server, '/snapshot', {
        version: qv(payload.version),
        tasks: qv(payload.tasks),
        ts: qv(payload.ts),
        allowEmpty: payload.allowEmpty === '1' ? '1' : '0',
      })
    },

    /** 读服端自证状态（当前生效配置 + 调度器状态 + 迁移来源 + 运行期同步情况） */
    async fetchStatus(server) {
      return callGet(server, '/status', {})
    },

    /** 手动执行（force=true 跳过条件判断，照旧版 /data/tasks/run?id=&force=） */
    async runTask(server, id, force) {
      return callGet(server, '/run', { id, force: force ? 1 : 0 })
    },

    /** 任务列表（旧版语义：不含 commands，含运行期状态） */
    async listTasks(server) {
      return callGet(server, '/list', {})
    },

    /** 单任务完整定义（旧版语义：含 commands） */
    async getTask(server, id) {
      return callGet(server, '/get', { id })
    },

    /** 执行记录分页（旧版 /data/tasks/log?taskId=&page=&pageSize=） */
    async listLogs(server, { taskId = '', page = 1, pageSize = 20 } = {}) {
      return callGet(server, '/log', { taskId, page: qv(page), pageSize: qv(pageSize) })
    },

    /** 执行记录详情（含逐条命令结果与完整输出） */
    async logDetail(server, id) {
      return callGet(server, '/log/detail', { id })
    },
  }
}
