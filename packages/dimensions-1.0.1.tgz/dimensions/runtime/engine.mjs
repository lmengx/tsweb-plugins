import { createRequire as __createRequire } from "node:module"; const require = __createRequire(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// tmp/market-local-init-r10-snapshot/plugins/dimensions/node_modules/utf8/utf8.js
var require_utf8 = __commonJS({
  "tmp/market-local-init-r10-snapshot/plugins/dimensions/node_modules/utf8/utf8.js"(exports) {
    (function(root) {
      var stringFromCharCode = String.fromCharCode;
      function ucs2decode(string) {
        var output = [];
        var counter = 0;
        var length = string.length;
        var value;
        var extra;
        while (counter < length) {
          value = string.charCodeAt(counter++);
          if (value >= 55296 && value <= 56319 && counter < length) {
            extra = string.charCodeAt(counter++);
            if ((extra & 64512) == 56320) {
              output.push(((value & 1023) << 10) + (extra & 1023) + 65536);
            } else {
              output.push(value);
              counter--;
            }
          } else {
            output.push(value);
          }
        }
        return output;
      }
      function ucs2encode(array) {
        var length = array.length;
        var index = -1;
        var value;
        var output = "";
        while (++index < length) {
          value = array[index];
          if (value > 65535) {
            value -= 65536;
            output += stringFromCharCode(value >>> 10 & 1023 | 55296);
            value = 56320 | value & 1023;
          }
          output += stringFromCharCode(value);
        }
        return output;
      }
      function checkScalarValue(codePoint) {
        if (codePoint >= 55296 && codePoint <= 57343) {
          throw Error(
            "Lone surrogate U+" + codePoint.toString(16).toUpperCase() + " is not a scalar value"
          );
        }
      }
      function createByte(codePoint, shift) {
        return stringFromCharCode(codePoint >> shift & 63 | 128);
      }
      function encodeCodePoint(codePoint) {
        if ((codePoint & 4294967168) == 0) {
          return stringFromCharCode(codePoint);
        }
        var symbol = "";
        if ((codePoint & 4294965248) == 0) {
          symbol = stringFromCharCode(codePoint >> 6 & 31 | 192);
        } else if ((codePoint & 4294901760) == 0) {
          checkScalarValue(codePoint);
          symbol = stringFromCharCode(codePoint >> 12 & 15 | 224);
          symbol += createByte(codePoint, 6);
        } else if ((codePoint & 4292870144) == 0) {
          symbol = stringFromCharCode(codePoint >> 18 & 7 | 240);
          symbol += createByte(codePoint, 12);
          symbol += createByte(codePoint, 6);
        }
        symbol += stringFromCharCode(codePoint & 63 | 128);
        return symbol;
      }
      function utf8encode(string) {
        var codePoints = ucs2decode(string);
        var length = codePoints.length;
        var index = -1;
        var codePoint;
        var byteString = "";
        while (++index < length) {
          codePoint = codePoints[index];
          byteString += encodeCodePoint(codePoint);
        }
        return byteString;
      }
      function readContinuationByte() {
        if (byteIndex >= byteCount) {
          throw Error("Invalid byte index");
        }
        var continuationByte = byteArray[byteIndex] & 255;
        byteIndex++;
        if ((continuationByte & 192) == 128) {
          return continuationByte & 63;
        }
        throw Error("Invalid continuation byte");
      }
      function decodeSymbol() {
        var byte1;
        var byte2;
        var byte3;
        var byte4;
        var codePoint;
        if (byteIndex > byteCount) {
          throw Error("Invalid byte index");
        }
        if (byteIndex == byteCount) {
          return false;
        }
        byte1 = byteArray[byteIndex] & 255;
        byteIndex++;
        if ((byte1 & 128) == 0) {
          return byte1;
        }
        if ((byte1 & 224) == 192) {
          byte2 = readContinuationByte();
          codePoint = (byte1 & 31) << 6 | byte2;
          if (codePoint >= 128) {
            return codePoint;
          } else {
            throw Error("Invalid continuation byte");
          }
        }
        if ((byte1 & 240) == 224) {
          byte2 = readContinuationByte();
          byte3 = readContinuationByte();
          codePoint = (byte1 & 15) << 12 | byte2 << 6 | byte3;
          if (codePoint >= 2048) {
            checkScalarValue(codePoint);
            return codePoint;
          } else {
            throw Error("Invalid continuation byte");
          }
        }
        if ((byte1 & 248) == 240) {
          byte2 = readContinuationByte();
          byte3 = readContinuationByte();
          byte4 = readContinuationByte();
          codePoint = (byte1 & 7) << 18 | byte2 << 12 | byte3 << 6 | byte4;
          if (codePoint >= 65536 && codePoint <= 1114111) {
            return codePoint;
          }
        }
        throw Error("Invalid UTF-8 detected");
      }
      var byteArray;
      var byteCount;
      var byteIndex;
      function utf8decode(byteString) {
        byteArray = ucs2decode(byteString);
        byteCount = byteArray.length;
        byteIndex = 0;
        var codePoints = [];
        var tmp;
        while ((tmp = decodeSymbol()) !== false) {
          codePoints.push(tmp);
        }
        return ucs2encode(codePoints);
      }
      root.version = "3.0.0";
      root.encode = utf8encode;
      root.decode = utf8decode;
    })(typeof exports === "undefined" ? exports.utf8 = {} : exports);
  }
});

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/runtime.ts
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { isIP } from "node:net";

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/listenserver.ts
import * as Net2 from "net";

// tmp/market-local-init-r10-snapshot/plugins/dimensions/node_modules/uuid/dist-node/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 256).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}

// tmp/market-local-init-r10-snapshot/plugins/dimensions/node_modules/uuid/dist-node/rng.js
var rnds8 = new Uint8Array(16);
function rng() {
  return crypto.getRandomValues(rnds8);
}

// tmp/market-local-init-r10-snapshot/plugins/dimensions/node_modules/uuid/dist-node/v4.js
function v4(options, buf, offset) {
  if (!buf && !options && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return _v4(options, buf, offset);
}
function _v4(options, buf, offset) {
  options = options || {};
  const rnds = options.random ?? options.rng?.() ?? rng();
  if (rnds.length < 16) {
    throw new Error("Random bytes length must be >= 16");
  }
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    if (offset < 0 || offset + 16 > buf.length) {
      throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
    }
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return unsafeStringify(rnds);
}
var v4_default = v4;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/utils.ts
var utf8 = __toESM(require_utf8(), 1);

// tmp/market-local-init-r10-snapshot/plugins/dimensions/node_modules/@popstarfreas/packetfactory/app/bufferwriter.js
var BufferWriter = class {
  constructor(buffer) {
    this._offset = 0;
    this._buffer = buffer;
  }
  changeOffset(offset) {
    this._offset = offset;
  }
  packInt16(int16) {
    this._buffer.writeInt16LE(int16, this._offset);
    this._offset += 2;
    return this;
  }
  packUInt16(uint16) {
    this._buffer.writeUInt16LE(uint16, this._offset);
    this._offset += 2;
    return this;
  }
  packInt32(int32) {
    this._buffer.writeInt32LE(int32, this._offset);
    this._offset += 4;
    return this;
  }
  packUInt32(uint32) {
    this._buffer.writeUInt32LE(uint32, this._offset);
    this._offset += 4;
    return this;
  }
  packInt64(int64) {
    this._buffer.writeBigInt64LE(int64, this._offset);
    this._offset += 8;
    return this;
  }
  packUInt64(uint64) {
    this._buffer.writeBigUInt64LE(uint64, this._offset);
    this._offset += 8;
    return this;
  }
  packSingle(single) {
    this._buffer.writeFloatLE(single, this._offset);
    this._offset += 4;
    return this;
  }
  packDouble(double) {
    this._buffer.writeDoubleLE(double, this._offset);
    this._offset += 8;
    return this;
  }
  packByte(byte) {
    if (byte < 0)
      byte = -byte;
    this._buffer.writeUInt8(byte, this._offset);
    this._offset += 1;
    return this;
  }
  packSByte(byte) {
    this._buffer.writeInt8(byte, this._offset);
    this._offset += 1;
    return this;
  }
  packBytes(bytes) {
    for (const byte of bytes) {
      this.packByte(byte);
    }
    return this;
  }
  packHex(hex) {
    const buf = Buffer.from(hex, "hex");
    buf.copy(this._buffer, this._offset, 0);
    this._offset += buf.length;
    return this;
  }
  packBuffer(buffer) {
    buffer.copy(this._buffer, this._offset, 0);
    this._offset += buffer.length;
    return this;
  }
  packString(str) {
    const packedStr = Buffer.from(str, "utf8");
    const strLen = packedStr.length;
    if (strLen >= 128) {
      this.packByte(strLen % 128 + 128);
      this.packByte(Math.floor(strLen / 128));
    } else {
      this.packByte(strLen);
    }
    this.packBuffer(packedStr);
    return this;
  }
  packColor(color) {
    this.packByte(color.R);
    this.packByte(color.G);
    this.packByte(color.B);
    return this;
  }
  packNetworkText(networkText) {
    this.packByte(networkText.mode);
    this.packString(networkText.text);
    if (networkText.substitutionList) {
      this.packByte(networkText.substitutionList.length);
      for (let i = 0; i < networkText.substitutionList.length; i++) {
        this.packNetworkText(networkText.substitutionList[i]);
      }
    } else if (networkText.mode != 0) {
      this.packByte(0);
    }
    return this;
  }
  get data() {
    return this._buffer;
  }
  get packedLength() {
    return this._offset;
  }
  get slicedData() {
    return this._buffer.slice(0, this._offset);
  }
};
var bufferwriter_default = BufferWriter;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/node_modules/@popstarfreas/packetfactory/app/dumbpacketwriter.js
var PacketWriter = class {
  constructor(buffer) {
    this._writer = new bufferwriter_default(buffer);
  }
  updateSize() {
    const offset = this._writer._offset;
    this._writer._buffer.writeUInt16LE(offset, 0);
  }
  setType(type) {
    this.packUInt16(3);
    this.packByte(type);
    return this;
  }
  packInt16(int16) {
    this._writer.packInt16(int16);
    this.updateSize();
    return this;
  }
  packUInt16(uint16) {
    this._writer.packUInt16(uint16);
    this.updateSize();
    return this;
  }
  packInt32(int32) {
    this._writer.packInt32(int32);
    this.updateSize();
    return this;
  }
  packUInt32(uint32) {
    this._writer.packUInt32(uint32);
    this.updateSize();
    return this;
  }
  packSingle(single) {
    this._writer.packSingle(single);
    this.updateSize();
    return this;
  }
  packDouble(single) {
    this._writer.packSingle(single);
    this.updateSize();
    return this;
  }
  packByte(byte) {
    this._writer.packByte(byte);
    this.updateSize();
    return this;
  }
  packSByte(byte) {
    this._writer.packSByte(byte);
    this.updateSize();
    return this;
  }
  packInt64(int64) {
    this._writer.packInt64(int64);
    this.updateSize();
    return this;
  }
  packUInt64(uint64) {
    this._writer.packUInt64(uint64);
    this.updateSize();
    return this;
  }
  packHex(hex) {
    this._writer.packHex(hex);
    this.updateSize();
    return this;
  }
  packBuffer(buffer) {
    this._writer.packBuffer(buffer);
    this.updateSize();
    return this;
  }
  packBytes(bytes) {
    this._writer.packBytes(bytes);
    this.updateSize();
    return this;
  }
  packString(str) {
    this._writer.packString(str);
    this.updateSize();
    return this;
  }
  packNetworkText(networkText) {
    this.packByte(networkText.mode);
    this.packString(networkText.text);
    return this;
  }
  packColor(color) {
    this.packByte(color.R);
    this.packByte(color.G);
    this.packByte(color.B);
    return this;
  }
  get data() {
    return this._writer.data;
  }
};
var dumbpacketwriter_default = PacketWriter;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/node_modules/@popstarfreas/packetfactory/app/networktext.js
var NetworkText = class {
  constructor(mode, text, substitutionList = void 0) {
    this._mode = mode;
    this._text = text;
    this._substitutionList = substitutionList;
  }
  get mode() {
    return this._mode;
  }
  get text() {
    return this._text;
  }
  get substitutionList() {
    return this._substitutionList;
  }
  toString() {
    return this._text;
  }
};
var networktext_default = NetworkText;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/node_modules/@popstarfreas/packetfactory/app/bufferreader.js
var BufferReader = class {
  constructor(data2) {
    this.head = 0;
    this._data = data2;
  }
  get bytesLeft() {
    return this._data.length - this.head;
  }
  /**
   * Gets the data still stored by the reader
   *
   * @return The hex data still stored by the reader
   */
  get data() {
    return this._data;
  }
  set buffer(data2) {
    this._data = data2;
    this.head = 0;
  }
  /**
   * Reads a byte from the data
   *
   * @return The byte removed
   */
  readByte() {
    const byte = this._data.readUInt8(this.head);
    this.head += 1;
    return byte;
  }
  /**
   * Reads a certain number of bytes from the data
   *
   * @return The bytes removed
   */
  readBytes(amount) {
    const bytes = [];
    for (let i = 0; i < amount; i++) {
      bytes.push(this.readByte());
    }
    return bytes;
  }
  /**
   * Reads a chunk of data and returns it in a buffer
   *
   * @param size The number of bytes to read
   */
  readBuffer(size) {
    const buffer = this._data.slice(this.head, this.head + size);
    this.head += size;
    return buffer;
  }
  /**
   * Reads three bytes from the data and puts them into a color object
   *
   * @return The color object {R, G, B}
   */
  readColor() {
    const color = {
      R: this.readByte(),
      G: this.readByte(),
      B: this.readByte()
    };
    return color;
  }
  /**
   * Reads a byte and converts it into an sbyte
   *
   * @return The sbyte removed
   */
  readSByte() {
    const byte = this._data.readInt8(this.head);
    this.head += 1;
    return byte;
  }
  /**
   * Reads 2 bytes from the data, converting it to a signed int16
   * as an int16.
   *
   * @return An int16
   */
  readInt16() {
    const int16 = this._data.readInt16LE(this.head);
    this.head += 2;
    return int16;
  }
  /**
   * Reads 2 bytes from the data and converts it to an unsigned int16
   *
   * @return A uint16
   */
  readUInt16() {
    const uint16 = this._data.readUInt16LE(this.head);
    this.head += 2;
    return uint16;
  }
  /**
   * Reads 4 bytes from the data, converting it into a signed int32
   *
   * Perf: https://jsperf.com/conv-dimen-1
   * @return The signed int32 removed from the data
   */
  readInt32() {
    const int32 = this._data.readInt32LE(this.head);
    this.head += 4;
    return int32;
  }
  /**
   * Reads 4 bytes from the data, converting it into an unsigned int32
   *
   * @return The unsigned int32 removed from the data
   */
  readUInt32() {
    const uint32 = this._data.readUInt32LE(this.head);
    this.head += 4;
    return uint32;
  }
  /**
   * Reads 8 bytes from the data, converting it into an unsigned int64
   *
   * @return The unsigned int64 removed from the data
   */
  readUInt64() {
    const uint64 = this._data.readBigUInt64LE(this.head);
    this.head += 8;
    return uint64;
  }
  /**
   * Reads 8 bytes from the data, converting it into an unsigned int64
   *
   * @return The unsigned int64 removed from the data
   */
  readInt64() {
    const int64 = this._data.readBigInt64LE(this.head);
    this.head += 8;
    return int64;
  }
  /**
   * Alias for readFloat()
   *
   * @return The single removed from the data
   */
  readSingle() {
    const single = this._data.readFloatLE(this.head);
    this.head += 4;
    return single;
  }
  /**
   * Reads 8 bytes from the data converting it into a double
   *
   * @return The double removed from the data
   */
  readDouble() {
    const double = this._data.readDoubleLE(this.head);
    this.head += 8;
    return double;
  }
  /**
   * Reads a certain number of bytes for the string length, and then further
   * bytes depending on the length, converting it into a string of characters.
   *
   * @return The string removed from the data
   */
  readString() {
    const firstByte = this.readByte();
    let strLength = firstByte;
    if (firstByte >= 128) {
      const secondByte = this.readByte();
      strLength = firstByte - 128 + (secondByte << 7);
    }
    const strContent = this._data.slice(this.head, this.head + strLength).toString("utf8");
    this.head += strLength;
    return strContent;
  }
  /**
   * Reads the mode byte and the string bytes
   *
   * @return The text
   */
  readNetworkText() {
    const mode = this.readByte();
    const text = this.readString();
    let substitutionList;
    if (mode != 0) {
      const substitutionListLength = this.readByte();
      if (substitutionListLength > 0) {
        substitutionList = new Array(substitutionListLength);
        for (let i = 0; i < substitutionListLength; i++) {
          substitutionList[i] = this.readNetworkText();
        }
      }
    }
    return new networktext_default(mode, text, substitutionList);
  }
};
var bufferreader_default = BufferReader;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/node_modules/@popstarfreas/packetfactory/app/utils.js
function getPackedStringByteLen(str) {
  const strLen = Buffer.from(str, "utf8").length;
  if (strLen >= 128) {
    return 2 + strLen;
  }
  return 1 + strLen;
}

// tmp/market-local-init-r10-snapshot/plugins/dimensions/node_modules/@popstarfreas/packetfactory/app/packetwriter.js
var PacketWriter2 = class {
  constructor(writerCls = dumbpacketwriter_default) {
    this._queue = [];
    this._size = 0;
    this._data = null;
    this._writerCls = writerCls;
  }
  compile() {
    const writer = new this._writerCls(Buffer.allocUnsafe(this._size));
    for (const item of this._queue) {
      writer[item.method](item.value);
    }
    this._data = writer.data;
  }
  setType(type) {
    this._queue.push({ method: "setType", value: type });
    if (this._size === 0)
      this._size = 3;
    return this;
  }
  packInt16(int16) {
    this._queue.push({ method: "packInt16", value: int16 });
    this._size += 2;
    return this;
  }
  packUInt16(uint16) {
    this._queue.push({ method: "packUInt16", value: uint16 });
    this._size += 2;
    return this;
  }
  packInt32(int32) {
    this._queue.push({ method: "packInt32", value: int32 });
    this._size += 4;
    return this;
  }
  packUInt32(uint32) {
    this._queue.push({ method: "packUInt32", value: uint32 });
    this._size += 4;
    return this;
  }
  packInt64(int64) {
    this._queue.push({ method: "packInt64", value: int64 });
    this._size += 8;
    return this;
  }
  packUInt64(uint64) {
    this._queue.push({ method: "packUInt64", value: uint64 });
    this._size += 8;
    return this;
  }
  packSingle(single) {
    this._queue.push({ method: "packSingle", value: single });
    this._size += 4;
    return this;
  }
  packDouble(double) {
    this._queue.push({ method: "packDouble", value: double });
    this._size += 8;
    return this;
  }
  packByte(byte) {
    this._queue.push({ method: "packByte", value: byte });
    this._size += 1;
    return this;
  }
  packSByte(byte) {
    this._queue.push({ method: "packSByte", value: byte });
    this._size += 1;
    return this;
  }
  packBytes(bytes) {
    this._queue.push({ method: "packBytes", value: bytes });
    this._size += bytes.length;
    return this;
  }
  packHex(hex) {
    if (hex.length % 2 !== 0) {
      throw new Error("Tried to pack invalid hex string.");
    }
    this._queue.push({ method: "packHex", value: hex });
    this._size += hex.length / 2;
    return this;
  }
  packBuffer(buffer) {
    this._queue.push({ method: "packBuffer", value: buffer });
    this._size += buffer.length;
    return this;
  }
  packString(str) {
    this._queue.push({ method: "packString", value: str });
    this._size += getPackedStringByteLen(str);
    return this;
  }
  packNetworkText(networkText) {
    this.packByte(networkText.mode);
    this.packString(networkText.text);
    if (networkText.substitutionList) {
      this.packByte(networkText.substitutionList.length);
      for (let i = 0; i < networkText.substitutionList.length; i++) {
        this.packNetworkText(networkText.substitutionList[i]);
      }
    } else if (networkText.mode != 0) {
      this.packByte(0);
    }
    return this;
  }
  packColor(color) {
    this.packByte(color.R);
    this.packByte(color.G);
    this.packByte(color.B);
    return this;
  }
  get data() {
    if (this._data === null) {
      this.compile();
    }
    return this._data;
  }
};
var packetwriter_default = PacketWriter2;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/utils.ts
function getProperIP(ip) {
  if (typeof ip === "undefined") return void 0;
  let IPFromRequest = ip;
  let indexOfColon = IPFromRequest.lastIndexOf(":");
  let IP = IPFromRequest.substring(indexOfColon + 1, IPFromRequest.length);
  return IP;
}
function getPacketTypeFromBuffer(buf) {
  return buf.readUInt8(2);
}
function getPacketsFromBuffer(buf) {
  const reader = new bufferreader_default(buf);
  let packets = [];
  let end = false;
  let length;
  let data2;
  let packetType;
  let bufferPacket = Buffer.allocUnsafe(0);
  if (buf.length > 1) {
    while (!end) {
      length = reader.readUInt16();
      if (length < 3) {
        return { type: "InvalidPacketLength", length };
      } else {
        data2 = buf.slice(reader.head - 2, reader.head - 2 + length);
        reader.head += length - 2;
        if (reader.head > buf.length) {
          bufferPacket = data2;
          end = true;
        } else {
          packetType = getPacketTypeFromBuffer(data2);
          packets.push({
            packetType,
            data: data2
          });
          if (reader.head === buf.length - 1) {
            bufferPacket = buf.slice(buf.length - 1, buf.length);
            end = true;
          } else if (reader.head === buf.length) {
            end = true;
          }
        }
      }
    }
  } else {
    bufferPacket = buf.slice(0, 1);
  }
  return { type: "ValidPackets", bufferPacket, packets };
}

// tmp/market-local-init-r10-snapshot/plugins/dimensions/node_modules/terraria-packet/dist/Export.js
import * as Nodezlib from "node:zlib";
var __defProp2 = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp2(target, name, { get: all[name], enumerable: true });
};
var PacketV1449_AnglerQuest_exports = {};
__export(PacketV1449_AnglerQuest_exports, {
  parse: () => parse,
  toBuffer: () => toBuffer
});
var PacketType_exports = {};
__export(PacketType_exports, {
  fromInt: () => fromInt,
  packetName: () => packetName,
  toInt: () => toInt
});
function fromInt(n) {
  switch (n) {
    case 1:
      return "ConnectRequest";
    case 2:
      return "Disconnect";
    case 3:
      return "PlayerSlotSet";
    case 4:
      return "PlayerInfo";
    case 5:
      return "PlayerInventorySlot";
    case 6:
      return "WorldDataRequest";
    case 7:
      return "WorldInfo";
    case 8:
      return "InitialTileSectionsRequest";
    case 9:
      return "Status";
    case 10:
      return "TileSectionSend";
    case 11:
      return "TileSectionFrame";
    case 12:
      return "PlayerSpawn";
    case 13:
      return "PlayerUpdate";
    case 14:
      return "PlayerActive";
    case 16:
      return "PlayerHealth";
    case 17:
      return "TileModify";
    case 18:
      return "TimeSet";
    case 19:
      return "DoorUse";
    case 20:
      return "TileSquareSend";
    case 21:
      return "ItemDropUpdate";
    case 22:
      return "ItemOwner";
    case 23:
      return "NpcUpdate";
    case 24:
      return "NpcItemStrike";
    case 27:
      return "ProjectileSync";
    case 28:
      return "NpcStrike";
    case 29:
      return "ProjectileDestroy";
    case 30:
      return "PvpToggle";
    case 31:
      return "ChestOpen";
    case 32:
      return "ChestItem";
    case 33:
      return "ActiveContainerSync";
    case 34:
      return "ChestPlace";
    case 35:
      return "HealEffect";
    case 36:
      return "Zones";
    case 37:
      return "PasswordRequired";
    case 38:
      return "PasswordSend";
    case 39:
      return "ItemOwnerRemove";
    case 40:
      return "NpcTalk";
    case 41:
      return "PlayerAnimation";
    case 42:
      return "PlayerMana";
    case 43:
      return "ManaEffect";
    case 45:
      return "PlayerTeam";
    case 46:
      return "SignRead";
    case 47:
      return "SignNew";
    case 48:
      return "LiquidSet";
    case 49:
      return "PlayerSpawnSelf";
    case 50:
      return "PlayerBuffsSet";
    case 51:
      return "NpcSpecialEffect";
    case 52:
      return "ChestOrTempleUnlock";
    case 53:
      return "NpcBuffAdd";
    case 54:
      return "NpcBuffUpdate";
    case 55:
      return "PlayerBuffAdd";
    case 56:
      return "NpcNameUpdate";
    case 57:
      return "GoodEvilUpdate";
    case 58:
      return "HarpPlay";
    case 59:
      return "SwitchHit";
    case 60:
      return "NpcHomeUpdate";
    case 61:
      return "BossOrInvasionSpawn";
    case 62:
      return "PlayerDodge";
    case 63:
      return "TilePaint";
    case 64:
      return "WallPaint";
    case 65:
      return "Teleport";
    case 66:
      return "PlayerHealOther";
    case 67:
      return "DimensionsUpdate";
    case 68:
      return "ClientUuid";
    case 69:
      return "ChestName";
    case 70:
      return "NpcCatch";
    case 71:
      return "NpcRelease";
    case 72:
      return "TravellingMerchantInventory";
    case 73:
      return "TeleportationPotion";
    case 74:
      return "AnglerQuest";
    case 75:
      return "AnglerQuestComplete";
    case 76:
      return "AnglerQuestsCompletedAmount";
    case 77:
      return "TemporaryAnimationCreate";
    case 78:
      return "InvasionProgressReport";
    case 79:
      return "ObjectPlace";
    case 80:
      return "PlayerChestIndexSync";
    case 81:
      return "CombatNumberCreate";
    case 82:
      return "NetModuleLoad";
    case 83:
      return "NpcKillCount";
    case 84:
      return "PlayerStealth";
    case 85:
      return "ItemForceIntoNearestChest";
    case 86:
      return "TileEntityUpdate";
    case 87:
      return "TileEntityPlace";
    case 88:
      return "ItemDropModify";
    case 89:
      return "ItemFramePlace";
    case 90:
      return "ItemDropInstancedUpdate";
    case 91:
      return "EmoteBubble";
    case 92:
      return "ExtraValueSync";
    case 93:
      return "SocialHandshake";
    case 94:
      return "Unused";
    case 95:
      return "PortalKill";
    case 96:
      return "PlayerTeleportPortal";
    case 97:
      return "NpcKilledNotification";
    case 98:
      return "EventNotification";
    case 99:
      return "MinionTargetUpdate";
    case 100:
      return "NpcTeleportPortal";
    case 101:
      return "ShieldStrengthsUpdate";
    case 102:
      return "NebulaLevelUp";
    case 103:
      return "MoonLordCountdown";
    case 104:
      return "NpcShopItem";
    case 105:
      return "GemLockToggle";
    case 106:
      return "SmokePoof";
    case 107:
      return "ChatMessageSmart";
    case 108:
      return "WiredCannonShot";
    case 109:
      return "MassWireOperation";
    case 110:
      return "MassWireOperationPay";
    case 111:
      return "PartyToggle";
    case 112:
      return "TreeGrowFx";
    case 113:
      return "CrystalInvasionStart";
    case 114:
      return "CrystalInvasionWipeAll";
    case 115:
      return "MinionAttackTargetUpdate";
    case 116:
      return "CrystalInvasionSendWaitTime";
    case 117:
      return "PlayerDamage";
    case 118:
      return "PlayerDeath";
    case 119:
      return "CombatTextCreate";
    case 120:
      return "Emoji";
    case 121:
      return "TileEntityDisplayDollItemSync";
    case 122:
      return "TileEntityInteractionRequest";
    case 123:
      return "WeaponsRackTryPlacing";
    case 124:
      return "TileEntityHatRackItemSync";
    case 125:
      return "TilePickingSync";
    case 126:
      return "RevengeMarkerSync";
    case 127:
      return "RevengeMarkerRemove";
    case 128:
      return "GolfBallLandInCup";
    case 129:
      return "ClientFinishConnectingToServer";
    case 130:
      return "NpcFishOut";
    case 131:
      return "NpcTamper";
    case 132:
      return "LegacySoundPlay";
    case 133:
      return "FoodPlatterTryPlacing";
    case 134:
      return "PlayerLuckFactorsUpdate";
    case 135:
      return "PlayerDead";
    case 136:
      return "CavernMonsterTypeSync";
    case 137:
      return "NpcBuffRemovalRequest";
    case 138:
      return "ClientSyncedInventory";
    case 139:
      return "CountsAsHostForGameplaySet";
    case 140:
      return "CreditsOrSlimeTransform";
    case 141:
      return "LucyAxeMessage";
    case 142:
      return "PiggyBankVoidLensUpdate";
    case 143:
      return "DungeonDefendersEventAttemptSkipWait";
    case 144:
      return "HaveDryadDoStardewAnimation";
    case 145:
      return "ItemDropShimmeredUpdate";
    case 146:
      return "ShimmerEffectOrCoinLuck";
    case 147:
      return "LoadoutSwitch";
    case 148:
      return "ItemDropProtectedUpdate";
    case 149:
      return "DeadCellsDisplayJarTryPlacing";
    case 150:
      return "PlayerSpectate";
    case 151:
      return "ItemDropClear";
    case 152:
      return "PlayerItemUseSound";
    case 153:
      return "NpcHurtByDebuff";
    case 154:
      return "Ping";
    case 155:
      return "ChestResize";
    case 156:
      return "LeashedEntityAnchorInsertItem";
    case 157:
      return "PlayerTeamUpdate";
    case 158:
      return "PlayerTeamSwapSpawn";
    case 159:
      return "SectionRequest";
    case 160:
      return "ItemDropPosition";
    case 161:
      return "HostToken";
    case 162:
      return "ServerInfo";
    case 163:
      return "PlayerPlatformInfo";
    default:
      return;
  }
}
function toInt(self) {
  switch (self) {
    case "ConnectRequest":
      return 1;
    case "Disconnect":
      return 2;
    case "PlayerSlotSet":
      return 3;
    case "PlayerInfo":
      return 4;
    case "PlayerInventorySlot":
      return 5;
    case "WorldDataRequest":
      return 6;
    case "WorldInfo":
      return 7;
    case "InitialTileSectionsRequest":
      return 8;
    case "Status":
      return 9;
    case "TileSectionSend":
      return 10;
    case "TileSectionFrame":
      return 11;
    case "PlayerSpawn":
      return 12;
    case "PlayerUpdate":
      return 13;
    case "PlayerActive":
      return 14;
    case "PlayerHealth":
      return 16;
    case "TileModify":
      return 17;
    case "TimeSet":
      return 18;
    case "DoorUse":
      return 19;
    case "TileSquareSend":
      return 20;
    case "ItemDropUpdate":
      return 21;
    case "ItemOwner":
      return 22;
    case "NpcUpdate":
      return 23;
    case "NpcItemStrike":
      return 24;
    case "ProjectileSync":
      return 27;
    case "NpcStrike":
      return 28;
    case "ProjectileDestroy":
      return 29;
    case "PvpToggle":
      return 30;
    case "ChestOpen":
      return 31;
    case "ChestItem":
      return 32;
    case "ActiveContainerSync":
      return 33;
    case "ChestPlace":
      return 34;
    case "HealEffect":
      return 35;
    case "Zones":
      return 36;
    case "PasswordRequired":
      return 37;
    case "PasswordSend":
      return 38;
    case "ItemOwnerRemove":
      return 39;
    case "NpcTalk":
      return 40;
    case "PlayerAnimation":
      return 41;
    case "PlayerMana":
      return 42;
    case "ManaEffect":
      return 43;
    case "PlayerTeam":
      return 45;
    case "SignRead":
      return 46;
    case "SignNew":
      return 47;
    case "LiquidSet":
      return 48;
    case "PlayerSpawnSelf":
      return 49;
    case "PlayerBuffsSet":
      return 50;
    case "NpcSpecialEffect":
      return 51;
    case "ChestOrTempleUnlock":
      return 52;
    case "NpcBuffAdd":
      return 53;
    case "NpcBuffUpdate":
      return 54;
    case "PlayerBuffAdd":
      return 55;
    case "NpcNameUpdate":
      return 56;
    case "GoodEvilUpdate":
      return 57;
    case "HarpPlay":
      return 58;
    case "SwitchHit":
      return 59;
    case "NpcHomeUpdate":
      return 60;
    case "BossOrInvasionSpawn":
      return 61;
    case "PlayerDodge":
      return 62;
    case "TilePaint":
      return 63;
    case "WallPaint":
      return 64;
    case "Teleport":
      return 65;
    case "PlayerHealOther":
      return 66;
    case "DimensionsUpdate":
      return 67;
    case "ClientUuid":
      return 68;
    case "ChestName":
      return 69;
    case "NpcCatch":
      return 70;
    case "NpcRelease":
      return 71;
    case "TravellingMerchantInventory":
      return 72;
    case "TeleportationPotion":
      return 73;
    case "AnglerQuest":
      return 74;
    case "AnglerQuestComplete":
      return 75;
    case "AnglerQuestsCompletedAmount":
      return 76;
    case "TemporaryAnimationCreate":
      return 77;
    case "InvasionProgressReport":
      return 78;
    case "ObjectPlace":
      return 79;
    case "PlayerChestIndexSync":
      return 80;
    case "CombatNumberCreate":
      return 81;
    case "NetModuleLoad":
      return 82;
    case "NpcKillCount":
      return 83;
    case "PlayerStealth":
      return 84;
    case "ItemForceIntoNearestChest":
      return 85;
    case "TileEntityUpdate":
      return 86;
    case "TileEntityPlace":
      return 87;
    case "ItemDropModify":
      return 88;
    case "ItemFramePlace":
      return 89;
    case "ItemDropInstancedUpdate":
      return 90;
    case "EmoteBubble":
      return 91;
    case "ExtraValueSync":
      return 92;
    case "SocialHandshake":
      return 93;
    case "Unused":
      return 94;
    case "PortalKill":
      return 95;
    case "PlayerTeleportPortal":
      return 96;
    case "NpcKilledNotification":
      return 97;
    case "EventNotification":
      return 98;
    case "MinionTargetUpdate":
      return 99;
    case "NpcTeleportPortal":
      return 100;
    case "ShieldStrengthsUpdate":
      return 101;
    case "NebulaLevelUp":
      return 102;
    case "MoonLordCountdown":
      return 103;
    case "NpcShopItem":
      return 104;
    case "GemLockToggle":
      return 105;
    case "SmokePoof":
      return 106;
    case "ChatMessageSmart":
      return 107;
    case "WiredCannonShot":
      return 108;
    case "MassWireOperation":
      return 109;
    case "MassWireOperationPay":
      return 110;
    case "PartyToggle":
      return 111;
    case "TreeGrowFx":
      return 112;
    case "CrystalInvasionStart":
      return 113;
    case "CrystalInvasionWipeAll":
      return 114;
    case "MinionAttackTargetUpdate":
      return 115;
    case "CrystalInvasionSendWaitTime":
      return 116;
    case "PlayerDamage":
      return 117;
    case "PlayerDeath":
      return 118;
    case "CombatTextCreate":
      return 119;
    case "Emoji":
      return 120;
    case "TileEntityDisplayDollItemSync":
      return 121;
    case "TileEntityInteractionRequest":
      return 122;
    case "WeaponsRackTryPlacing":
      return 123;
    case "TileEntityHatRackItemSync":
      return 124;
    case "TilePickingSync":
      return 125;
    case "RevengeMarkerSync":
      return 126;
    case "RevengeMarkerRemove":
      return 127;
    case "GolfBallLandInCup":
      return 128;
    case "ClientFinishConnectingToServer":
      return 129;
    case "NpcFishOut":
      return 130;
    case "NpcTamper":
      return 131;
    case "LegacySoundPlay":
      return 132;
    case "FoodPlatterTryPlacing":
      return 133;
    case "PlayerLuckFactorsUpdate":
      return 134;
    case "PlayerDead":
      return 135;
    case "CavernMonsterTypeSync":
      return 136;
    case "NpcBuffRemovalRequest":
      return 137;
    case "ClientSyncedInventory":
      return 138;
    case "CountsAsHostForGameplaySet":
      return 139;
    case "CreditsOrSlimeTransform":
      return 140;
    case "LucyAxeMessage":
      return 141;
    case "PiggyBankVoidLensUpdate":
      return 142;
    case "DungeonDefendersEventAttemptSkipWait":
      return 143;
    case "HaveDryadDoStardewAnimation":
      return 144;
    case "ItemDropShimmeredUpdate":
      return 145;
    case "ShimmerEffectOrCoinLuck":
      return 146;
    case "LoadoutSwitch":
      return 147;
    case "ItemDropProtectedUpdate":
      return 148;
    case "DeadCellsDisplayJarTryPlacing":
      return 149;
    case "PlayerSpectate":
      return 150;
    case "ItemDropClear":
      return 151;
    case "PlayerItemUseSound":
      return 152;
    case "NpcHurtByDebuff":
      return 153;
    case "Ping":
      return 154;
    case "ChestResize":
      return 155;
    case "LeashedEntityAnchorInsertItem":
      return 156;
    case "PlayerTeamUpdate":
      return 157;
    case "PlayerTeamSwapSpawn":
      return 158;
    case "SectionRequest":
      return 159;
    case "ItemDropPosition":
      return 160;
    case "HostToken":
      return 161;
    case "ServerInfo":
      return 162;
    case "PlayerPlatformInfo":
      return 163;
  }
}
function packetName(packetType) {
  switch (packetType) {
    case "ConnectRequest":
      return "ConnectRequest";
    case "Disconnect":
      return "Disconnect";
    case "PlayerSlotSet":
      return "PlayerSlotSet";
    case "PlayerInfo":
      return "PlayerInfo";
    case "PlayerInventorySlot":
      return "PlayerInventorySlot";
    case "WorldDataRequest":
      return "WorldDataRequest";
    case "WorldInfo":
      return "WorldInfo";
    case "InitialTileSectionsRequest":
      return "InitialTileSectionsRequest";
    case "Status":
      return "Status";
    case "TileSectionSend":
      return "TileSectionSend";
    case "TileSectionFrame":
      return "TileSectionFrame";
    case "PlayerSpawn":
      return "PlayerSpawn";
    case "PlayerUpdate":
      return "PlayerUpdate";
    case "PlayerActive":
      return "PlayerActive";
    case "PlayerHealth":
      return "PlayerHealth";
    case "TileModify":
      return "TileModify";
    case "TimeSet":
      return "TimeSet";
    case "DoorUse":
      return "DoorUse";
    case "TileSquareSend":
      return "TileSquareSend";
    case "ItemDropUpdate":
      return "ItemDropUpdate";
    case "ItemOwner":
      return "ItemOwner";
    case "NpcUpdate":
      return "NpcUpdate";
    case "NpcItemStrike":
      return "NpcItemStrike";
    case "ProjectileSync":
      return "ProjectileSync";
    case "NpcStrike":
      return "NpcStrike";
    case "ProjectileDestroy":
      return "ProjectileDestroy";
    case "PvpToggle":
      return "PvpToggle";
    case "ChestOpen":
      return "ChestOpen";
    case "ChestItem":
      return "ChestItem";
    case "ActiveContainerSync":
      return "ActiveContainerSync";
    case "ChestPlace":
      return "ChestPlace";
    case "HealEffect":
      return "HealEffect";
    case "Zones":
      return "Zones";
    case "PasswordRequired":
      return "PasswordRequired";
    case "PasswordSend":
      return "PasswordSend";
    case "ItemOwnerRemove":
      return "ItemOwnerRemove";
    case "NpcTalk":
      return "NpcTalk";
    case "PlayerAnimation":
      return "PlayerAnimation";
    case "PlayerMana":
      return "PlayerMana";
    case "ManaEffect":
      return "ManaEffect";
    case "PlayerTeam":
      return "PlayerTeam";
    case "SignRead":
      return "SignRead";
    case "SignNew":
      return "SignNew";
    case "LiquidSet":
      return "LiquidSet";
    case "PlayerSpawnSelf":
      return "PlayerSpawnSelf";
    case "PlayerBuffsSet":
      return "PlayerBuffsSet";
    case "NpcSpecialEffect":
      return "NpcSpecialEffect";
    case "ChestOrTempleUnlock":
      return "ChestOrTempleUnlock";
    case "NpcBuffAdd":
      return "NpcBuffAdd";
    case "NpcBuffUpdate":
      return "NpcBuffUpdate";
    case "PlayerBuffAdd":
      return "PlayerBuffAdd";
    case "NpcNameUpdate":
      return "NpcNameUpdate";
    case "GoodEvilUpdate":
      return "GoodEvilUpdate";
    case "HarpPlay":
      return "HarpPlay";
    case "SwitchHit":
      return "SwitchHit";
    case "NpcHomeUpdate":
      return "NpcHomeUpdate";
    case "BossOrInvasionSpawn":
      return "BossOrInvasionSpawn";
    case "PlayerDodge":
      return "PlayerDodge";
    case "TilePaint":
      return "TilePaint";
    case "WallPaint":
      return "WallPaint";
    case "Teleport":
      return "Teleport";
    case "PlayerHealOther":
      return "PlayerHealOther";
    case "DimensionsUpdate":
      return "DimensionsUpdate";
    case "ClientUuid":
      return "ClientUuid";
    case "ChestName":
      return "ChestName";
    case "NpcCatch":
      return "NpcCatch";
    case "NpcRelease":
      return "NpcRelease";
    case "TravellingMerchantInventory":
      return "TravellingMerchantInventory";
    case "TeleportationPotion":
      return "TeleportationPotion";
    case "AnglerQuest":
      return "AnglerQuest";
    case "AnglerQuestComplete":
      return "AnglerQuestComplete";
    case "AnglerQuestsCompletedAmount":
      return "AnglerQuestsCompletedAmount";
    case "TemporaryAnimationCreate":
      return "TemporaryAnimationCreate";
    case "InvasionProgressReport":
      return "InvasionProgressReport";
    case "ObjectPlace":
      return "ObjectPlace";
    case "PlayerChestIndexSync":
      return "PlayerChestIndexSync";
    case "CombatNumberCreate":
      return "CombatNumberCreate";
    case "NetModuleLoad":
      return "NetModuleLoad";
    case "NpcKillCount":
      return "NpcKillCount";
    case "PlayerStealth":
      return "PlayerStealth";
    case "ItemForceIntoNearestChest":
      return "ItemForceIntoNearestChest";
    case "TileEntityUpdate":
      return "TileEntityUpdate";
    case "TileEntityPlace":
      return "TileEntityPlace";
    case "ItemDropModify":
      return "ItemDropModify";
    case "ItemFramePlace":
      return "ItemFramePlace";
    case "ItemDropInstancedUpdate":
      return "ItemDropInstancedUpdate";
    case "EmoteBubble":
      return "EmoteBubble";
    case "ExtraValueSync":
      return "ExtraValueSync";
    case "SocialHandshake":
      return "SocialHandshake";
    case "Unused":
      return "Unused";
    case "PortalKill":
      return "PortalKill";
    case "PlayerTeleportPortal":
      return "PlayerTeleportPortal";
    case "NpcKilledNotification":
      return "NpcKilledNotification";
    case "EventNotification":
      return "EventNotification";
    case "MinionTargetUpdate":
      return "MinionTargetUpdate";
    case "NpcTeleportPortal":
      return "NpcTeleportPortal";
    case "ShieldStrengthsUpdate":
      return "ShieldStrengthsUpdate";
    case "NebulaLevelUp":
      return "NebulaLevelUp";
    case "MoonLordCountdown":
      return "MoonLordCountdown";
    case "NpcShopItem":
      return "NpcShopItem";
    case "GemLockToggle":
      return "GemLockToggle";
    case "SmokePoof":
      return "SmokePoof";
    case "ChatMessageSmart":
      return "ChatMessageSmart";
    case "WiredCannonShot":
      return "WiredCannonShot";
    case "MassWireOperation":
      return "MassWireOperation";
    case "MassWireOperationPay":
      return "MassWireOperationPay";
    case "PartyToggle":
      return "PartyToggle";
    case "TreeGrowFx":
      return "TreeGrowFx";
    case "CrystalInvasionStart":
      return "CrystalInvasionStart";
    case "CrystalInvasionWipeAll":
      return "CrystalInvasionWipeAll";
    case "MinionAttackTargetUpdate":
      return "MinionAttackTargetUpdate";
    case "CrystalInvasionSendWaitTime":
      return "CrystalInvasionSendWaitTime";
    case "PlayerDamage":
      return "PlayerDamage";
    case "PlayerDeath":
      return "PlayerDeath";
    case "CombatTextCreate":
      return "CombatTextCreate";
    case "Emoji":
      return "Emoji";
    case "TileEntityDisplayDollItemSync":
      return "TileEntityDisplayDollItemSync";
    case "TileEntityInteractionRequest":
      return "TileEntityInteractionRequest";
    case "WeaponsRackTryPlacing":
      return "WeaponsRackTryPlacing";
    case "TileEntityHatRackItemSync":
      return "TileEntityHatRackItemSync";
    case "TilePickingSync":
      return "TilePickingSync";
    case "RevengeMarkerSync":
      return "RevengeMarkerSync";
    case "RevengeMarkerRemove":
      return "RevengeMarkerRemove";
    case "GolfBallLandInCup":
      return "GolfBallLandInCup";
    case "ClientFinishConnectingToServer":
      return "ClientFinishConnectingToServer";
    case "NpcFishOut":
      return "NpcFishOut";
    case "NpcTamper":
      return "NpcTamper";
    case "LegacySoundPlay":
      return "LegacySoundPlay";
    case "FoodPlatterTryPlacing":
      return "FoodPlatterTryPlacing";
    case "PlayerLuckFactorsUpdate":
      return "PlayerLuckFactorsUpdate";
    case "PlayerDead":
      return "PlayerDead";
    case "CavernMonsterTypeSync":
      return "CavernMonsterTypeSync";
    case "NpcBuffRemovalRequest":
      return "NpcBuffRemovalRequest";
    case "ClientSyncedInventory":
      return "ClientSyncedInventory";
    case "CountsAsHostForGameplaySet":
      return "CountsAsHostForGameplaySet";
    case "CreditsOrSlimeTransform":
      return "CreditsOrSlimeTransform";
    case "LucyAxeMessage":
      return "LucyAxeMessage";
    case "PiggyBankVoidLensUpdate":
      return "PiggyBankVoidLensUpdate";
    case "DungeonDefendersEventAttemptSkipWait":
      return "DungeonDefendersEventAttemptSkipWait";
    case "HaveDryadDoStardewAnimation":
      return "HaveDryadDoStardewAnimation";
    case "ItemDropShimmeredUpdate":
      return "ItemDropShimmeredUpdate";
    case "ShimmerEffectOrCoinLuck":
      return "ShimmerEffectOrCoinLuck";
    case "LoadoutSwitch":
      return "LoadoutSwitch";
    case "ItemDropProtectedUpdate":
      return "ItemDropProtectedUpdate";
    case "DeadCellsDisplayJarTryPlacing":
      return "DeadCellsDisplayJarTryPlacing";
    case "PlayerSpectate":
      return "PlayerSpectate";
    case "ItemDropClear":
      return "ItemDropClear";
    case "PlayerItemUseSound":
      return "PlayerItemUseSound";
    case "NpcHurtByDebuff":
      return "NpcHurtByDebuff";
    case "Ping":
      return "Ping";
    case "ChestResize":
      return "ChestResize";
    case "LeashedEntityAnchorInsertItem":
      return "LeashedEntityAnchorInsertItem";
    case "PlayerTeamUpdate":
      return "PlayerTeamUpdate";
    case "PlayerTeamSwapSpawn":
      return "PlayerTeamSwapSpawn";
    case "SectionRequest":
      return "SectionRequest";
    case "ItemDropPosition":
      return "ItemDropPosition";
    case "HostToken":
      return "HostToken";
    case "ServerInfo":
      return "ServerInfo";
    case "PlayerPlatformInfo":
      return "PlayerPlatformInfo";
  }
}
function throwWithMessage(str) {
  throw new Error(str);
}
function isExtension(e) {
  if (e == null) {
    return false;
  } else {
    return typeof e.RE_EXN_ID === "string";
  }
}
function internalToException(e) {
  if (isExtension(e)) {
    return e;
  } else {
    return {
      RE_EXN_ID: "JsExn",
      _1: e
    };
  }
}
function readByteUnsafe(prim) {
  return prim.readByte();
}
function readUInt16Unsafe(prim) {
  return prim.readUInt16();
}
function readInt16Unsafe(prim) {
  return prim.readInt16();
}
function readUInt32Unsafe(prim) {
  return prim.readUInt32();
}
function readInt32Unsafe(prim) {
  return prim.readInt32();
}
function readUInt64Unsafe(prim) {
  return prim.readUInt64();
}
function readStringUnsafe(prim) {
  return prim.readString();
}
function readSingleUnsafe(prim) {
  return prim.readSingle();
}
function readSByteUnsafe(prim) {
  return prim.readSByte();
}
function readColorUnsafe(prim) {
  return prim.readColor();
}
function readNetworkTextUnsafe(prim) {
  return prim.readNetworkText();
}
function getBytesLeftUnsafe(prim) {
  return prim.bytesLeft;
}
function withContext(fn, reader, context) {
  try {
    return {
      TAG: "Ok",
      _0: fn(reader)
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function readByte(reader, context) {
  return withContext(readByteUnsafe, reader, context);
}
function readBool(reader, context) {
  return withContext((reader2) => reader2.readByte() === 1, reader, context);
}
function readUInt16(reader, context) {
  return withContext(readUInt16Unsafe, reader, context);
}
function readInt16(reader, context) {
  return withContext(readInt16Unsafe, reader, context);
}
function readUInt32(reader, context) {
  return withContext(readUInt32Unsafe, reader, context);
}
function readInt32(reader, context) {
  return withContext(readInt32Unsafe, reader, context);
}
function readUInt64(reader, context) {
  return withContext(readUInt64Unsafe, reader, context);
}
function readString(reader, context) {
  return withContext(readStringUnsafe, reader, context);
}
function readBytes(reader, count, context) {
  return withContext((reader2) => reader2.readBytes(count), reader, context);
}
function read7BitEncodedInt(reader, context) {
  return withContext((reader2) => {
    let result = 0;
    let shift = 0;
    let $$continue = true;
    while ($$continue) {
      if (shift >= 35) {
        throwWithMessage("Invalid 7-bit encoded int");
      }
      let byte = reader2.readByte();
      result = result | (byte & 127) << shift;
      if ((byte & 128) === 0) {
        $$continue = false;
      } else {
        shift = shift + 7 | 0;
      }
    }
    ;
    return result;
  }, reader, context);
}
function readSingle(reader, context) {
  return withContext(readSingleUnsafe, reader, context);
}
function readSByte(reader, context) {
  return withContext(readSByteUnsafe, reader, context);
}
function readColor(reader, context) {
  return withContext(readColorUnsafe, reader, context);
}
function readBuffer(reader, bytes, context) {
  return withContext((reader2) => reader2.readBuffer(bytes), reader, context);
}
function readNetworkText(reader, context) {
  return withContext(readNetworkTextUnsafe, reader, context);
}
function getBytesLeft(reader) {
  return withContext(getBytesLeftUnsafe, reader, "getBytesLeft");
}
var ErrorAwarePacketWriter_exports = {};
__export(ErrorAwarePacketWriter_exports, {
  data: () => data,
  make: () => make,
  packBool: () => packBool,
  packBuffer: () => packBuffer,
  packByte: () => packByte,
  packBytes: () => packBytes,
  packColor: () => packColor,
  packInt16: () => packInt16,
  packInt32: () => packInt32,
  packNetworkText: () => packNetworkText,
  packSByte: () => packSByte,
  packSingle: () => packSingle,
  packString: () => packString,
  packUInt16: () => packUInt16,
  packUInt32: () => packUInt32,
  packUInt64: () => packUInt64,
  setType: () => setType
});
var BufferWriter2 = class {
  constructor(buffer) {
    this._offset = 0;
    this._buffer = buffer;
  }
  changeOffset(offset) {
    this._offset = offset;
  }
  packInt16(int16) {
    this._buffer.writeInt16LE(int16, this._offset);
    this._offset += 2;
    return this;
  }
  packUInt16(uint16) {
    this._buffer.writeUInt16LE(uint16, this._offset);
    this._offset += 2;
    return this;
  }
  packInt32(int32) {
    this._buffer.writeInt32LE(int32, this._offset);
    this._offset += 4;
    return this;
  }
  packUInt32(uint32) {
    this._buffer.writeUInt32LE(uint32, this._offset);
    this._offset += 4;
    return this;
  }
  packInt64(int64) {
    this._buffer.writeBigInt64LE(int64, this._offset);
    this._offset += 8;
    return this;
  }
  packUInt64(uint64) {
    this._buffer.writeBigUInt64LE(uint64, this._offset);
    this._offset += 8;
    return this;
  }
  packSingle(single) {
    this._buffer.writeFloatLE(single, this._offset);
    this._offset += 4;
    return this;
  }
  packDouble(double) {
    this._buffer.writeDoubleLE(double, this._offset);
    this._offset += 8;
    return this;
  }
  packByte(byte) {
    if (byte < 0)
      byte = -byte;
    this._buffer.writeUInt8(byte, this._offset);
    this._offset += 1;
    return this;
  }
  packSByte(byte) {
    this._buffer.writeInt8(byte, this._offset);
    this._offset += 1;
    return this;
  }
  packBytes(bytes) {
    for (const byte of bytes) {
      this.packByte(byte);
    }
    return this;
  }
  packHex(hex) {
    const buf = Buffer.from(hex, "hex");
    buf.copy(this._buffer, this._offset, 0);
    this._offset += buf.length;
    return this;
  }
  packBuffer(buffer) {
    buffer.copy(this._buffer, this._offset, 0);
    this._offset += buffer.length;
    return this;
  }
  packString(str) {
    const packedStr = Buffer.from(str, "utf8");
    const strLen = packedStr.length;
    if (strLen >= 128) {
      this.packByte(strLen % 128 + 128);
      this.packByte(Math.floor(strLen / 128));
    } else {
      this.packByte(strLen);
    }
    this.packBuffer(packedStr);
    return this;
  }
  packColor(color) {
    this.packByte(color.R);
    this.packByte(color.G);
    this.packByte(color.B);
    return this;
  }
  packNetworkText(networkText) {
    this.packByte(networkText.mode);
    this.packString(networkText.text);
    if (networkText.substitutionList) {
      this.packByte(networkText.substitutionList.length);
      for (let i = 0; i < networkText.substitutionList.length; i++) {
        this.packNetworkText(networkText.substitutionList[i]);
      }
    } else if (networkText.mode != 0) {
      this.packByte(0);
    }
    return this;
  }
  get data() {
    return this._buffer;
  }
  get packedLength() {
    return this._offset;
  }
  get slicedData() {
    return this._buffer.slice(0, this._offset);
  }
};
var bufferwriter_default2 = BufferWriter2;
var PacketWriter3 = class {
  constructor(buffer) {
    this._writer = new bufferwriter_default2(buffer);
  }
  updateSize() {
    const offset = this._writer._offset;
    this._writer._buffer.writeUInt16LE(offset, 0);
  }
  setType(type) {
    this.packUInt16(3);
    this.packByte(type);
    return this;
  }
  packInt16(int16) {
    this._writer.packInt16(int16);
    this.updateSize();
    return this;
  }
  packUInt16(uint16) {
    this._writer.packUInt16(uint16);
    this.updateSize();
    return this;
  }
  packInt32(int32) {
    this._writer.packInt32(int32);
    this.updateSize();
    return this;
  }
  packUInt32(uint32) {
    this._writer.packUInt32(uint32);
    this.updateSize();
    return this;
  }
  packSingle(single) {
    this._writer.packSingle(single);
    this.updateSize();
    return this;
  }
  packDouble(single) {
    this._writer.packSingle(single);
    this.updateSize();
    return this;
  }
  packByte(byte) {
    this._writer.packByte(byte);
    this.updateSize();
    return this;
  }
  packSByte(byte) {
    this._writer.packSByte(byte);
    this.updateSize();
    return this;
  }
  packInt64(int64) {
    this._writer.packInt64(int64);
    this.updateSize();
    return this;
  }
  packUInt64(uint64) {
    this._writer.packUInt64(uint64);
    this.updateSize();
    return this;
  }
  packHex(hex) {
    this._writer.packHex(hex);
    this.updateSize();
    return this;
  }
  packBuffer(buffer) {
    this._writer.packBuffer(buffer);
    this.updateSize();
    return this;
  }
  packBytes(bytes) {
    this._writer.packBytes(bytes);
    this.updateSize();
    return this;
  }
  packString(str) {
    this._writer.packString(str);
    this.updateSize();
    return this;
  }
  packNetworkText(networkText) {
    this.packByte(networkText.mode);
    this.packString(networkText.text);
    return this;
  }
  packColor(color) {
    this.packByte(color.R);
    this.packByte(color.G);
    this.packByte(color.B);
    return this;
  }
  get data() {
    return this._writer.data;
  }
};
var dumbpacketwriter_default2 = PacketWriter3;
var NetworkText2 = class {
  constructor(mode, text, substitutionList = void 0) {
    this._mode = mode;
    this._text = text;
    this._substitutionList = substitutionList;
  }
  get mode() {
    return this._mode;
  }
  get text() {
    return this._text;
  }
  get substitutionList() {
    return this._substitutionList;
  }
  toString() {
    return this._text;
  }
};
var networktext_default2 = NetworkText2;
var BufferReader2 = class {
  constructor(data2) {
    this.head = 0;
    this._data = data2;
  }
  get bytesLeft() {
    return this._data.length - this.head;
  }
  /**
   * Gets the data still stored by the reader
   *
   * @return The hex data still stored by the reader
   */
  get data() {
    return this._data;
  }
  set buffer(data2) {
    this._data = data2;
    this.head = 0;
  }
  /**
   * Reads a byte from the data
   *
   * @return The byte removed
   */
  readByte() {
    const byte = this._data.readUInt8(this.head);
    this.head += 1;
    return byte;
  }
  /**
   * Reads a certain number of bytes from the data
   *
   * @return The bytes removed
   */
  readBytes(amount) {
    const bytes = [];
    for (let i = 0; i < amount; i++) {
      bytes.push(this.readByte());
    }
    return bytes;
  }
  /**
   * Reads a chunk of data and returns it in a buffer
   *
   * @param size The number of bytes to read
   */
  readBuffer(size) {
    const buffer = this._data.slice(this.head, this.head + size);
    this.head += size;
    return buffer;
  }
  /**
   * Reads three bytes from the data and puts them into a color object
   *
   * @return The color object {R, G, B}
   */
  readColor() {
    const color = {
      R: this.readByte(),
      G: this.readByte(),
      B: this.readByte()
    };
    return color;
  }
  /**
   * Reads a byte and converts it into an sbyte
   *
   * @return The sbyte removed
   */
  readSByte() {
    const byte = this._data.readInt8(this.head);
    this.head += 1;
    return byte;
  }
  /**
   * Reads 2 bytes from the data, converting it to a signed int16
   * as an int16.
   *
   * @return An int16
   */
  readInt16() {
    const int16 = this._data.readInt16LE(this.head);
    this.head += 2;
    return int16;
  }
  /**
   * Reads 2 bytes from the data and converts it to an unsigned int16
   *
   * @return A uint16
   */
  readUInt16() {
    const uint16 = this._data.readUInt16LE(this.head);
    this.head += 2;
    return uint16;
  }
  /**
   * Reads 4 bytes from the data, converting it into a signed int32
   *
   * Perf: https://jsperf.com/conv-dimen-1
   * @return The signed int32 removed from the data
   */
  readInt32() {
    const int32 = this._data.readInt32LE(this.head);
    this.head += 4;
    return int32;
  }
  /**
   * Reads 4 bytes from the data, converting it into an unsigned int32
   *
   * @return The unsigned int32 removed from the data
   */
  readUInt32() {
    const uint32 = this._data.readUInt32LE(this.head);
    this.head += 4;
    return uint32;
  }
  /**
   * Reads 8 bytes from the data, converting it into an unsigned int64
   *
   * @return The unsigned int64 removed from the data
   */
  readUInt64() {
    const uint64 = this._data.readBigUInt64LE(this.head);
    this.head += 8;
    return uint64;
  }
  /**
   * Reads 8 bytes from the data, converting it into an unsigned int64
   *
   * @return The unsigned int64 removed from the data
   */
  readInt64() {
    const int64 = this._data.readBigInt64LE(this.head);
    this.head += 8;
    return int64;
  }
  /**
   * Alias for readFloat()
   *
   * @return The single removed from the data
   */
  readSingle() {
    const single = this._data.readFloatLE(this.head);
    this.head += 4;
    return single;
  }
  /**
   * Reads 8 bytes from the data converting it into a double
   *
   * @return The double removed from the data
   */
  readDouble() {
    const double = this._data.readDoubleLE(this.head);
    this.head += 8;
    return double;
  }
  /**
   * Reads a certain number of bytes for the string length, and then further
   * bytes depending on the length, converting it into a string of characters.
   *
   * @return The string removed from the data
   */
  readString() {
    const firstByte = this.readByte();
    let strLength = firstByte;
    if (firstByte >= 128) {
      const secondByte = this.readByte();
      strLength = firstByte - 128 + (secondByte << 7);
    }
    const strContent = this._data.slice(this.head, this.head + strLength).toString("utf8");
    this.head += strLength;
    return strContent;
  }
  /**
   * Reads the mode byte and the string bytes
   *
   * @return The text
   */
  readNetworkText() {
    const mode = this.readByte();
    const text = this.readString();
    let substitutionList;
    if (mode != 0) {
      const substitutionListLength = this.readByte();
      if (substitutionListLength > 0) {
        substitutionList = new Array(substitutionListLength);
        for (let i = 0; i < substitutionListLength; i++) {
          substitutionList[i] = this.readNetworkText();
        }
      }
    }
    return new networktext_default2(mode, text, substitutionList);
  }
};
var bufferreader_default2 = BufferReader2;
function getPackedStringByteLen2(str) {
  const strLen = Buffer.from(str, "utf8").length;
  if (strLen >= 128) {
    return 2 + strLen;
  }
  return 1 + strLen;
}
var PacketWriter22 = class {
  constructor(writerCls = dumbpacketwriter_default2) {
    this._queue = [];
    this._size = 0;
    this._data = null;
    this._writerCls = writerCls;
  }
  compile() {
    const writer = new this._writerCls(Buffer.allocUnsafe(this._size));
    for (const item of this._queue) {
      writer[item.method](item.value);
    }
    this._data = writer.data;
  }
  setType(type) {
    this._queue.push({ method: "setType", value: type });
    if (this._size === 0)
      this._size = 3;
    return this;
  }
  packInt16(int16) {
    this._queue.push({ method: "packInt16", value: int16 });
    this._size += 2;
    return this;
  }
  packUInt16(uint16) {
    this._queue.push({ method: "packUInt16", value: uint16 });
    this._size += 2;
    return this;
  }
  packInt32(int32) {
    this._queue.push({ method: "packInt32", value: int32 });
    this._size += 4;
    return this;
  }
  packUInt32(uint32) {
    this._queue.push({ method: "packUInt32", value: uint32 });
    this._size += 4;
    return this;
  }
  packInt64(int64) {
    this._queue.push({ method: "packInt64", value: int64 });
    this._size += 8;
    return this;
  }
  packUInt64(uint64) {
    this._queue.push({ method: "packUInt64", value: uint64 });
    this._size += 8;
    return this;
  }
  packSingle(single) {
    this._queue.push({ method: "packSingle", value: single });
    this._size += 4;
    return this;
  }
  packDouble(double) {
    this._queue.push({ method: "packDouble", value: double });
    this._size += 8;
    return this;
  }
  packByte(byte) {
    this._queue.push({ method: "packByte", value: byte });
    this._size += 1;
    return this;
  }
  packSByte(byte) {
    this._queue.push({ method: "packSByte", value: byte });
    this._size += 1;
    return this;
  }
  packBytes(bytes) {
    this._queue.push({ method: "packBytes", value: bytes });
    this._size += bytes.length;
    return this;
  }
  packHex(hex) {
    if (hex.length % 2 !== 0) {
      throw new Error("Tried to pack invalid hex string.");
    }
    this._queue.push({ method: "packHex", value: hex });
    this._size += hex.length / 2;
    return this;
  }
  packBuffer(buffer) {
    this._queue.push({ method: "packBuffer", value: buffer });
    this._size += buffer.length;
    return this;
  }
  packString(str) {
    this._queue.push({ method: "packString", value: str });
    this._size += getPackedStringByteLen2(str);
    return this;
  }
  packNetworkText(networkText) {
    this.packByte(networkText.mode);
    this.packString(networkText.text);
    if (networkText.substitutionList) {
      this.packByte(networkText.substitutionList.length);
      for (let i = 0; i < networkText.substitutionList.length; i++) {
        this.packNetworkText(networkText.substitutionList[i]);
      }
    } else if (networkText.mode != 0) {
      this.packByte(0);
    }
    return this;
  }
  packColor(color) {
    this.packByte(color.R);
    this.packByte(color.G);
    this.packByte(color.B);
    return this;
  }
  get data() {
    if (this._data === null) {
      this.compile();
    }
    return this._data;
  }
};
var packetwriter_default2 = PacketWriter22;
function packSingle(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packSingle(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packUInt32(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packUInt32(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packInt32(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packInt32(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packByte(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packByte(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packBool(self, value, context) {
  return packByte(self, value ? 1 : 0, context);
}
function packUInt16(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packUInt16(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packInt16(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packInt16(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packUInt64(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packUInt64(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packString(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packString(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packSByte(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packSByte(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packBytes(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packBytes(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packColor(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packColor(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packBuffer(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packBuffer(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packNetworkText(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packNetworkText(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function setType(self, value) {
  return {
    TAG: "Writing",
    _0: self.setType(value)
  };
}
function data(self) {
  if (self.TAG === "Writing") {
    return {
      TAG: "Ok",
      _0: self._0.data
    };
  } else {
    return {
      TAG: "Error",
      _0: self._0
    };
  }
}
function make() {
  return new packetwriter_default2();
}
var PacketReader = class extends bufferreader_default2 {
  constructor(data2) {
    super(data2);
    this.readUInt16();
    this._type = this.readByte();
  }
  /**
   * Gets the packet type
   *
   * @return The packet type of the packet
   */
  get type() {
    return this._type;
  }
};
var packetreader_default = PacketReader;
function parse(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "anglerQuest");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readBool(reader, "anglerQuestFinished");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        anglerQuest: e._0,
        anglerQuestFinished: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer(self) {
  return data(packBool(packByte(setType(new packetwriter_default2(), toInt("AnglerQuest")), self.anglerQuest, "anglerQuest"), self.anglerQuestFinished, "anglerQuestFinished"));
}
var PacketV1449_AnglerQuestComplete_exports = {};
__export(PacketV1449_AnglerQuestComplete_exports, {
  parse: () => parse2,
  toBuffer: () => toBuffer2
});
function parse2(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
function toBuffer2(_self) {
  return data(setType(make(), toInt("AnglerQuestComplete")));
}
var PacketV1449_BossOrInvasionSpawn_exports = {};
__export(PacketV1449_BossOrInvasionSpawn_exports, {
  parse: () => parse3,
  toBuffer: () => toBuffer3
});
function parse3(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "spawnType");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let rawSpawnType = e$1._0;
  let spawnType;
  let exit = 0;
  switch (rawSpawnType) {
    case -18:
      spawnType = "PeddlersSatchel";
      break;
    case -17:
      spawnType = "CombatBookVolumeTwo";
      break;
    case -16:
      spawnType = "MechQueen";
      break;
    case -15:
      spawnType = "BoughtSlime";
      break;
    case -14:
      spawnType = "BoughtBunny";
      break;
    case -13:
      spawnType = "BoughtDog";
      break;
    case -12:
      spawnType = "BoughtCat";
      break;
    case -11:
      spawnType = "CombatBookUsed";
      break;
    case -10:
      spawnType = "BloodMoon";
      break;
    case -8:
      spawnType = "ImpendingDoom";
      break;
    case -7:
      spawnType = "MartianMoon";
      break;
    case -6:
      spawnType = "Eclipse";
      break;
    case -5:
      spawnType = "SnowMoon";
      break;
    case -4:
      spawnType = "PumpkinMoon";
      break;
    case -3:
      spawnType = "PirateInvasion";
      break;
    case -2:
      spawnType = "FrostInvasion";
      break;
    case -1:
      spawnType = "GoblinInvasion";
      break;
    default:
      exit = 1;
  }
  if (exit === 1) {
    spawnType = rawSpawnType < 0 ? {
      TAG: "Invasion",
      _0: -rawSpawnType | 0
    } : {
      TAG: "Npc",
      _0: rawSpawnType
    };
  }
  return {
    TAG: "Ok",
    _0: {
      playerId: e._0,
      spawnType
    }
  };
}
function packSpawnType(writer, spawnType) {
  if (typeof spawnType === "object") {
    if (spawnType.TAG === "Invasion") {
      return packInt16(writer, -spawnType._0 | 0, "spawnType");
    } else {
      return packInt16(writer, spawnType._0, "spawnType");
    }
  }
  switch (spawnType) {
    case "GoblinInvasion":
      return packInt16(writer, -1, "spawnType");
    case "FrostInvasion":
      return packInt16(writer, -2, "spawnType");
    case "PirateInvasion":
      return packInt16(writer, -3, "spawnType");
    case "PumpkinMoon":
      return packInt16(writer, -4, "spawnType");
    case "SnowMoon":
      return packInt16(writer, -5, "spawnType");
    case "Eclipse":
      return packInt16(writer, -6, "spawnType");
    case "MartianMoon":
      return packInt16(writer, -7, "spawnType");
    case "ImpendingDoom":
      return packInt16(writer, -8, "spawnType");
    case "BloodMoon":
      return packInt16(writer, -10, "spawnType");
    case "CombatBookUsed":
      return packInt16(writer, -11, "spawnType");
    case "BoughtCat":
      return packInt16(writer, -12, "spawnType");
    case "BoughtDog":
      return packInt16(writer, -13, "spawnType");
    case "BoughtBunny":
      return packInt16(writer, -14, "spawnType");
    case "BoughtSlime":
      return packInt16(writer, -15, "spawnType");
    case "MechQueen":
      return packInt16(writer, -16, "spawnType");
    case "CombatBookVolumeTwo":
      return packInt16(writer, -17, "spawnType");
    case "PeddlersSatchel":
      return packInt16(writer, -18, "spawnType");
  }
}
function toBuffer3(self) {
  return data(packSpawnType(packInt16(setType(make(), toInt("BossOrInvasionSpawn")), self.playerId, "playerId"), self.spawnType));
}
var PacketV1449_ChatMessageSmart_exports = {};
__export(PacketV1449_ChatMessageSmart_exports, {
  parse: () => parse4,
  toBuffer: () => toBuffer4
});
function parse4(payload) {
  let reader = new packetreader_default(payload);
  let e = readColor(reader, "color");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readNetworkText(reader, "message");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "widthLimit");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        color: e._0,
        message: e$1._0,
        widthLimit: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function toBuffer4(self) {
  return data(packInt16(packNetworkText(packColor(setType(make(), toInt("ChatMessageSmart")), self.color, "color"), self.message, "message"), self.widthLimit, "widthLimit"));
}
var PacketV1449_ChestItem_exports = {};
__export(PacketV1449_ChestItem_exports, {
  parse: () => parse5,
  toBuffer: () => toBuffer5
});
function parse5(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "chestId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "slot");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "stack");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "prefix");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt16(reader, "itemNetId");
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        chestId: e._0,
        slot: e$1._0,
        stack: e$2._0,
        prefix: e$3._0,
        itemNetId: e$4._0
      }
    };
  } else {
    return e$4;
  }
}
function toBuffer5(self) {
  return data(packInt16(packByte(packInt16(packByte(packInt16(setType(make(), toInt("ChestItem")), self.chestId, "chestId"), self.slot, "slot"), self.stack, "stack"), self.prefix, "prefix"), self.itemNetId, "itemNetId"));
}
var PacketV1449_ChestOrTempleUnlock_exports = {};
__export(PacketV1449_ChestOrTempleUnlock_exports, {
  parse: () => parse6,
  toBuffer: () => toBuffer6
});
function unlockTypeToInt(self) {
  switch (self) {
    case "Chest":
      return 1;
    case "TempleDoor":
      return 2;
    case "ChestLock":
      return 3;
  }
}
function unlockTypeFromInt(self) {
  switch (self) {
    case 1:
      return "Chest";
    case 2:
      return "TempleDoor";
    case 3:
      return "ChestLock";
    default:
      return;
  }
}
function parse6(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "unlockType");
  if (e.TAG !== "Ok") {
    return e;
  }
  let unlockType = unlockTypeFromInt(e._0);
  let e$1 = unlockType !== void 0 ? {
    TAG: "Ok",
    _0: unlockType
  } : {
    TAG: "Error",
    _0: {
      context: "Packet_ChestOrTempleUnlock.parse",
      error: new Error("Unknown unlock type")
    }
  };
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "x");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt16(reader, "y");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        unlockType: e$1._0,
        x: e$2._0,
        y: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function toBuffer6(self) {
  return data(packInt16(packInt16(packByte(setType(make(), toInt("ChestOrTempleUnlock")), unlockTypeToInt(self.unlockType), "unlockType"), self.x, "x"), self.y, "y"));
}
var PacketV1449_ChestPlace_exports = {};
__export(PacketV1449_ChestPlace_exports, {
  Action: () => Action,
  parse: () => parse7,
  toBuffer: () => toBuffer7
});
function toInt2(action) {
  switch (action) {
    case "PlaceChest":
      return 0;
    case "KillChest":
      return 1;
    case "PlaceDresser":
      return 2;
    case "KillDresser":
      return 3;
    case "PlaceContainer":
      return 4;
    case "KillContainer":
      return 5;
  }
}
function fromInt2(action) {
  switch (action) {
    case 0:
      return "PlaceChest";
    case 1:
      return "KillChest";
    case 2:
      return "PlaceDresser";
    case 3:
      return "KillDresser";
    case 4:
      return "PlaceContainer";
    case 5:
      return "KillContainer";
    default:
      return;
  }
}
function toString(action) {
  switch (action) {
    case "PlaceChest":
      return "PlaceChest";
    case "KillChest":
      return "KillChest";
    case "PlaceDresser":
      return "PlaceDresser";
    case "KillDresser":
      return "KillDresser";
    case "PlaceContainer":
      return "PlaceContainer";
    case "KillContainer":
      return "KillContainer";
  }
}
var Action = {
  toInt: toInt2,
  fromInt: fromInt2,
  toString
};
function parse7(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "action");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt16(reader, "style");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt16(reader, "id");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let action = fromInt2(e._0);
  let action$1 = action !== void 0 ? {
    TAG: "Ok",
    _0: action
  } : {
    TAG: "Error",
    _0: {
      context: "ChestPlace.parse.action",
      error: new Error("Unknown action")
    }
  };
  if (action$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        action: action$1._0,
        x: e$1._0,
        y: e$2._0,
        style: e$3._0,
        id: e$4._0
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: action$1._0
    };
  }
}
function packAction(writer, action) {
  let byte;
  switch (action) {
    case "PlaceChest":
      byte = 0;
      break;
    case "KillChest":
      byte = 1;
      break;
    case "PlaceDresser":
      byte = 2;
      break;
    case "KillDresser":
      byte = 3;
      break;
    case "PlaceContainer":
      byte = 4;
      break;
    case "KillContainer":
      byte = 5;
      break;
  }
  return packByte(writer, byte, "action");
}
function toBuffer7(self) {
  return data(packInt16(packInt16(packInt16(packInt16(packAction(setType(make(), toInt("ChestPlace")), self.action), self.x, "x"), self.y, "y"), self.style, "style"), self.id, "id"));
}
var PacketV1449_ClientFinishConnectingToServer_exports = {};
__export(PacketV1449_ClientFinishConnectingToServer_exports, {
  parse: () => parse8,
  toBuffer: () => toBuffer8
});
function parse8(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
function toBuffer8(_self) {
  return data(setType(make(), toInt("ClientFinishConnectingToServer")));
}
var PacketV1449_ConnectRequest_exports = {};
__export(PacketV1449_ConnectRequest_exports, {
  parse: () => parse9,
  toBuffer: () => toBuffer9
});
function parse9(payload) {
  let reader = new packetreader_default(payload);
  let e = readString(reader, "version");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        version: e._0
      }
    };
  } else {
    return e;
  }
}
function toBuffer9(self) {
  return data(packString(setType(make(), toInt("ConnectRequest")), self.version, "version"));
}
var PacketV1449_CountsAsHostForGameplaySet_exports = {};
__export(PacketV1449_CountsAsHostForGameplaySet_exports, {
  parse: () => parse10,
  toBuffer: () => toBuffer10
});
function parse10(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readBool(reader, "countsAsHost");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        countsAsHost: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer10(self) {
  return data(packBool(packByte(setType(new packetwriter_default2(), toInt("CountsAsHostForGameplaySet")), self.playerId, "playerId"), self.countsAsHost, "countsAsHost"));
}
var PacketV1449_CreditsOrSlimeTransform_exports = {};
__export(PacketV1449_CreditsOrSlimeTransform_exports, {
  EventType: () => EventType,
  parse: () => parse11,
  toBuffer: () => toBuffer11
});
function fromInt3(num) {
  switch (num) {
    case 0:
      return "CreditsTimeRemainingSet";
    case 1:
      return "CopperSlimeTransform";
    case 2:
      return "ElderSlimeTransform";
    default:
      return;
  }
}
function toInt3(eventType) {
  switch (eventType) {
    case "CreditsTimeRemainingSet":
      return 0;
    case "CopperSlimeTransform":
      return 1;
    case "ElderSlimeTransform":
      return 2;
  }
}
function parse11(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "eventType");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "value");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let eventType = fromInt3(e._0);
  if (eventType !== void 0) {
    return {
      TAG: "Ok",
      _0: {
        eventType,
        value: e$1._0
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: {
        context: "Packet_CreditsOrSlimeTransform.parse",
        error: new Error("Unknown event type")
      }
    };
  }
}
function toBuffer11(self) {
  return data(packInt32(packByte(setType(make(), toInt("CreditsOrSlimeTransform")), toInt3(self.eventType), "eventType"), self.value, "value"));
}
var EventType = {};
var PacketV1449_CrystalInvasionStart_exports = {};
__export(PacketV1449_CrystalInvasionStart_exports, {
  parse: () => parse12,
  toBuffer: () => toBuffer12
});
function parse12(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer12(self) {
  return data(packInt16(packInt16(setType(make(), toInt("CrystalInvasionStart")), self.x, "x"), self.y, "y"));
}
var PacketV1449_DimensionsUpdate_exports = {};
__export(PacketV1449_DimensionsUpdate_exports, {
  UpdateType: () => UpdateType,
  parse: () => parse13,
  toBuffer: () => toBuffer13
});
function map(opt, f) {
  if (opt.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: f(opt._0)
    };
  } else {
    return opt;
  }
}
function mapError(r, f) {
  if (r.TAG === "Ok") {
    return r;
  } else {
    return {
      TAG: "Error",
      _0: f(r._0)
    };
  }
}
function all4(param) {
  let d = param[3];
  let c = param[2];
  let b = param[1];
  let a = param[0];
  if (a.TAG === "Ok") {
    if (b.TAG === "Ok") {
      if (c.TAG === "Ok") {
        if (d.TAG === "Ok") {
          return {
            TAG: "Ok",
            _0: [
              a._0,
              b._0,
              c._0,
              d._0
            ]
          };
        } else {
          return {
            TAG: "Error",
            _0: d._0
          };
        }
      } else {
        return {
          TAG: "Error",
          _0: c._0
        };
      }
    } else {
      return {
        TAG: "Error",
        _0: b._0
      };
    }
  } else {
    return {
      TAG: "Error",
      _0: a._0
    };
  }
}
function toInt4(self) {
  switch (self) {
    case "RealIpAddress":
      return 0;
    case "GamemodesJoinMode":
      return 1;
    case "SwitchServer":
      return 2;
    case "SwitchServerManual":
      return 3;
    case "RttUpdate":
      return 6;
  }
}
function fromInt4(n) {
  switch (n) {
    case 0:
      return "RealIpAddress";
    case 1:
      return "GamemodesJoinMode";
    case 2:
      return "SwitchServer";
    case 3:
      return "SwitchServerManual";
    case 6:
      return "RttUpdate";
    default:
      return;
  }
}
var UpdateType = {
  toInt: toInt4,
  fromInt: fromInt4
};
function parse13(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "updateType");
  if (e.TAG !== "Ok") {
    return e;
  }
  let match = fromInt4(e._0);
  if (match === void 0) {
    return {
      TAG: "Error",
      _0: {
        context: "DimensionsUpdate.parse.updateType",
        error: new Error("Unknown updateType")
      }
    };
  }
  switch (match) {
    case "RealIpAddress":
      let e$1 = readString(reader, "ip");
      if (e$1.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "RealIpAddress",
            _0: e$1._0
          }
        };
      } else {
        return e$1;
      }
    case "GamemodesJoinMode":
      return {
        TAG: "Ok",
        _0: "GamemodesJoinMode"
      };
    case "SwitchServer":
      let e$2 = readString(reader, "dimensionName");
      if (e$2.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "SwitchServer",
            _0: e$2._0
          }
        };
      } else {
        return e$2;
      }
    case "SwitchServerManual":
      let e$3 = readString(reader, "ip");
      if (e$3.TAG !== "Ok") {
        return e$3;
      }
      let e$4 = readUInt16(reader, "port");
      if (e$4.TAG !== "Ok") {
        return e$4;
      }
      let bytesLeft = getBytesLeft(reader);
      let e$5;
      e$5 = bytesLeft.TAG === "Ok" ? bytesLeft._0 > 0 ? map(readString(reader, "serverName"), (v) => v) : {
        TAG: "Ok",
        _0: void 0
      } : {
        TAG: "Error",
        _0: bytesLeft._0
      };
      if (e$5.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "SwitchServerManual",
            _0: {
              serverName: e$5._0,
              ip: e$3._0,
              port: e$4._0
            }
          }
        };
      } else {
        return e$5;
      }
    case "RttUpdate":
      let e$6 = readByte(reader, "playerId");
      if (e$6.TAG !== "Ok") {
        return e$6;
      }
      let e$7 = readInt32(reader, "clientRttMicros");
      if (e$7.TAG !== "Ok") {
        return e$7;
      }
      let e$8 = readInt32(reader, "serverRttMicros");
      if (e$8.TAG !== "Ok") {
        return e$8;
      }
      let e$9 = readInt32(reader, "overallRttMicros");
      if (e$9.TAG !== "Ok") {
        return e$9;
      }
      let e$10 = readUInt64(reader, "updatedAt");
      if (e$10.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "RttUpdate",
            _0: {
              playerId: e$6._0,
              clientRttMicros: e$7._0,
              serverRttMicros: e$8._0,
              overallRttMicros: e$9._0,
              updatedAt: e$10._0
            }
          }
        };
      } else {
        return e$10;
      }
  }
}
function gamemodesJoinModeToBuffer() {
  return data(packInt16(setType(make(), toInt("DimensionsUpdate")), 1, "updateType"));
}
function toBuffer13(self) {
  if (typeof self !== "object") {
    return gamemodesJoinModeToBuffer();
  }
  switch (self.TAG) {
    case "RealIpAddress":
      let ip = self._0;
      return data(packString(packInt16(setType(make(), toInt("DimensionsUpdate")), 0, "updateType"), ip, "ip"));
    case "SwitchServer":
      let dimensionName = self._0;
      return data(packString(packInt16(setType(make(), toInt("DimensionsUpdate")), 2, "updateType"), dimensionName, "dimensionName"));
    case "SwitchServerManual":
      let match = self._0;
      let ip$1 = match.ip;
      let port = match.port;
      let serverName = match.serverName;
      return data((serverName !== void 0 ? (__x) => packString(__x, serverName, "serverName") : (writer) => writer)(packUInt16(packString(packInt16(setType(make(), toInt("DimensionsUpdate")), 3, "updateType"), ip$1, "ip"), port, "port")));
    case "RttUpdate":
      let rttUpdate = self._0;
      return data(packUInt64(packInt32(packInt32(packInt32(packByte(packInt16(setType(make(), toInt("DimensionsUpdate")), 6, "updateType"), rttUpdate.playerId, "playerId"), rttUpdate.clientRttMicros, "clientRttMicros"), rttUpdate.serverRttMicros, "serverRttMicros"), rttUpdate.overallRttMicros, "overallRttMicros"), rttUpdate.updatedAt, "updatedAt"));
  }
}
var PacketV1449_ExtraValueSync_exports = {};
__export(PacketV1449_ExtraValueSync_exports, {
  parse: () => parse14,
  toBuffer: () => toBuffer14
});
function parse14(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "npcSlotId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "extraValue");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "x");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "y");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcSlotId: e._0,
        extraValue: e$1._0,
        x: e$2._0,
        y: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function toBuffer14(self) {
  return data(packSingle(packSingle(packInt32(packInt16(setType(make(), toInt("ExtraValueSync")), self.npcSlotId, "npcSlotId"), self.extraValue, "extraValue"), self.x, "x"), self.y, "y"));
}
var PacketV1449_HaveDryadDoStardewAnimation_exports = {};
__export(PacketV1449_HaveDryadDoStardewAnimation_exports, {
  parse: () => parse15,
  toBuffer: () => toBuffer15
});
function parse15(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
function toBuffer15(_self) {
  return data(setType(make(), toInt("HaveDryadDoStardewAnimation")));
}
var PacketV1449_InvasionProgressReport_exports = {};
__export(PacketV1449_InvasionProgressReport_exports, {
  parse: () => parse16,
  toBuffer: () => toBuffer16
});
function parse16(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt32(reader, "progress");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "progressMax");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSByte(reader, "icon");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSByte(reader, "wave");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        progress: e._0,
        progressMax: e$1._0,
        icon: e$2._0,
        wave: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function toBuffer16(self) {
  return data(packSByte(packSByte(packInt32(packInt32(setType(make(), toInt("InvasionProgressReport")), self.progress, "progress"), self.progressMax, "progressMax"), self.icon, "icon"), self.wave, "wave"));
}
var PacketV1449_ItemDropShimmeredUpdate_exports = {};
__export(PacketV1449_ItemDropShimmeredUpdate_exports, {
  parse: () => parse17,
  toBuffer: () => toBuffer17
});
function parse17(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "itemDropId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "vx");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readSingle(reader, "vy");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readInt16(reader, "stack");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readByte(reader, "prefix");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readByte(reader, "noDelay");
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let e$8 = readInt16(reader, "itemId");
  if (e$8.TAG !== "Ok") {
    return e$8;
  }
  let e$9 = readByte(reader, "shimmered");
  if (e$9.TAG !== "Ok") {
    return e$9;
  }
  let e$10 = readSingle(reader, "shimmeredTime");
  if (e$10.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        itemDropId: e._0,
        x: e$1._0,
        y: e$2._0,
        vx: e$3._0,
        vy: e$4._0,
        stack: e$5._0,
        prefix: e$6._0,
        noDelay: e$7._0,
        itemId: e$8._0,
        shimmered: e$9._0 === 1,
        shimmeredTime: e$10._0
      }
    };
  } else {
    return e$10;
  }
}
function toBuffer17(self) {
  return data(packSingle(packByte(packInt16(packByte(packByte(packInt16(packSingle(packSingle(packSingle(packSingle(packInt16(setType(make(), toInt("ItemDropShimmeredUpdate")), self.itemDropId, "itemDropId"), self.x, "x"), self.y, "y"), self.vx, "vx"), self.vy, "vy"), self.stack, "stack"), self.prefix, "prefix"), self.noDelay, "noDelay"), self.itemId, "itemId"), self.shimmered ? 1 : 0, "shimmered"), self.shimmeredTime, "shimmeredTime"));
}
var PacketV1449_ItemDropUpdate_exports = {};
__export(PacketV1449_ItemDropUpdate_exports, {
  parse: () => parse18,
  toBuffer: () => toBuffer18
});
function parse18(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "itemDropId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "vx");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readSingle(reader, "vy");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readInt16(reader, "stack");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readByte(reader, "prefix");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readByte(reader, "noDelay");
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let e$8 = readInt16(reader, "itemId");
  if (e$8.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        itemDropId: e._0,
        x: e$1._0,
        y: e$2._0,
        vx: e$3._0,
        vy: e$4._0,
        stack: e$5._0,
        prefix: e$6._0,
        noDelay: e$7._0,
        itemId: e$8._0
      }
    };
  } else {
    return e$8;
  }
}
function toBuffer18(self) {
  return data(packInt16(packByte(packByte(packInt16(packSingle(packSingle(packSingle(packSingle(packInt16(setType(make(), toInt("ItemDropUpdate")), self.itemDropId, "itemDropId"), self.x, "x"), self.y, "y"), self.vx, "vx"), self.vy, "vy"), self.stack, "stack"), self.prefix, "prefix"), self.noDelay, "noDelay"), self.itemId, "itemId"));
}
var Packet_ItemOwner_exports = {};
__export(Packet_ItemOwner_exports, {
  Decode: () => Decode,
  Encode: () => Encode,
  parse: () => parse19,
  toBuffer: () => toBuffer19
});
function parse19(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "itemDropId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "owner");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "positionX");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "positionY");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        itemDropId: e._0,
        owner: e$1._0,
        position: {
          x: e$2._0,
          y: e$3._0
        }
      }
    };
  } else {
    return e$3;
  }
}
var Decode = {
  readInt16,
  readByte,
  readSingle,
  parse: parse19
};
function toBuffer19(self) {
  return data(packSingle(packSingle(packByte(packInt16(setType(make(), toInt("ItemOwner")), self.itemDropId, "itemDropId"), self.owner, "owner"), self.position.x, "positionX"), self.position.y, "positionY"));
}
var Encode = {
  packInt16,
  packByte,
  packSingle,
  setType,
  data,
  toBuffer: toBuffer19
};
var PacketV1449_ItemOwnerRemove_exports = {};
__export(PacketV1449_ItemOwnerRemove_exports, {
  parse: () => parse20,
  toBuffer: () => toBuffer20
});
function parse20(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "itemDropId");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        itemDropId: e._0
      }
    };
  } else {
    return e;
  }
}
function toBuffer20(self) {
  return data(packInt16(setType(make(), toInt("ItemOwnerRemove")), self.itemDropId, "itemDropId"));
}
var PacketV1449_LoadoutSwitch_exports = {};
__export(PacketV1449_LoadoutSwitch_exports, {
  parse: () => parse21,
  toBuffer: () => toBuffer21
});
var Array16_exports = {};
__export(Array16_exports, {
  asArray: () => asArray,
  fromArray: () => fromArray2,
  fromBitFlagsPair: () => fromBitFlagsPair,
  toBitFlagsPair: () => toBitFlagsPair
});
function some(x) {
  if (x === void 0) {
    return {
      BS_PRIVATE_NESTED_SOME_NONE: 0
    };
  } else if (x !== null && x.BS_PRIVATE_NESTED_SOME_NONE !== void 0) {
    return {
      BS_PRIVATE_NESTED_SOME_NONE: x.BS_PRIVATE_NESTED_SOME_NONE + 1 | 0
    };
  } else {
    return x;
  }
}
function valFromOption(x) {
  if (x === null || x.BS_PRIVATE_NESTED_SOME_NONE === void 0) {
    return x;
  }
  let depth = x.BS_PRIVATE_NESTED_SOME_NONE;
  if (depth === 0) {
    return;
  } else {
    return {
      BS_PRIVATE_NESTED_SOME_NONE: depth - 1 | 0
    };
  }
}
function make2(length, x) {
  if (length <= 0) {
    return [];
  }
  let arr = new Array(length);
  arr.fill(x);
  return arr;
}
var BitFlags_exports = {};
__export(BitFlags_exports, {
  flag1: () => flag1,
  flag2: () => flag2,
  flag3: () => flag3,
  flag4: () => flag4,
  flag5: () => flag5,
  flag6: () => flag6,
  flag7: () => flag7,
  flag8: () => flag8,
  flagN: () => flagN,
  forEach: () => forEach,
  fromArray: () => fromArray,
  fromByte: () => fromByte,
  fromFlags: () => fromFlags,
  toByte: () => toByte
});
var ArrayExt_exports = {};
__export(ArrayExt_exports, {
  getOr: () => getOr2,
  intoChunks: () => intoChunks
});
function mapOr(opt, $$default, f) {
  if (opt !== void 0) {
    return f(valFromOption(opt));
  } else {
    return $$default;
  }
}
function map2(opt, f) {
  if (opt !== void 0) {
    return some(f(valFromOption(opt)));
  }
}
function flatMap(opt, f) {
  if (opt !== void 0) {
    return f(valFromOption(opt));
  }
}
function getOr(opt, $$default) {
  if (opt !== void 0) {
    return valFromOption(opt);
  } else {
    return $$default;
  }
}
function isSome(x) {
  return x !== void 0;
}
function intoChunks(self, chunkSize) {
  let chunked = [];
  let len = self.length;
  let max2 = (Math.ceil(len / chunkSize) | 0) - 1 | 0;
  for (let i = 0; i <= max2; ++i) {
    let __x = self.slice(i * chunkSize | 0, (i + 1 | 0) * chunkSize | 0);
    chunked.push(__x);
  }
  return chunked;
}
function getOr2(self, index, or) {
  return getOr(self[index], or);
}
function fromByte(byte) {
  return byte;
}
function fromFlags(flag12, flag22, flag32, flag42, flag52, flag62, flag72, flag82) {
  let byte = 0;
  byte = byte | (flag12 ? 1 : 0);
  byte = byte | (flag22 ? 2 : 0);
  byte = byte | (flag32 ? 4 : 0);
  byte = byte | (flag42 ? 8 : 0);
  byte = byte | (flag52 ? 16 : 0);
  byte = byte | (flag62 ? 32 : 0);
  byte = byte | (flag72 ? 64 : 0);
  byte = byte | (flag82 ? 128 : 0);
  return byte;
}
function fromArray(flags) {
  return fromFlags(getOr2(flags, 0, false), getOr2(flags, 1, false), getOr2(flags, 2, false), getOr2(flags, 3, false), getOr2(flags, 4, false), getOr2(flags, 5, false), getOr2(flags, 6, false), getOr2(flags, 7, false));
}
function flagN(self, n) {
  return (self & n) === n;
}
function flag1(__x) {
  return (__x & 1) === 1;
}
function flag2(__x) {
  return (__x & 2) === 2;
}
function flag3(__x) {
  return (__x & 4) === 4;
}
function flag4(__x) {
  return (__x & 8) === 8;
}
function flag5(__x) {
  return (__x & 16) === 16;
}
function flag6(__x) {
  return (__x & 32) === 32;
}
function flag7(__x) {
  return (__x & 64) === 64;
}
function flag8(__x) {
  return (__x & 128) === 128;
}
function forEach(self, fn) {
  fn((self & 1) === 1);
  fn((self & 2) === 2);
  fn((self & 4) === 4);
  fn((self & 8) === 8);
  fn((self & 16) === 16);
  fn((self & 32) === 32);
  fn((self & 64) === 64);
  fn((self & 128) === 128);
}
function toByte(self) {
  return self;
}
function fromArray2(a) {
  if (a.length === 16) {
    return a;
  }
}
function fromBitFlagsPair(a, b) {
  let array = make2(16, false);
  array[0] = flag1(a);
  array[1] = flag2(a);
  array[2] = flag3(a);
  array[3] = flag4(a);
  array[4] = flag5(a);
  array[5] = flag6(a);
  array[6] = flag7(a);
  array[7] = flag8(a);
  array[8] = flag1(b);
  array[9] = flag2(b);
  array[10] = flag3(b);
  array[11] = flag4(b);
  array[12] = flag5(b);
  array[13] = flag6(b);
  array[14] = flag7(b);
  array[15] = flag8(b);
  return array;
}
function toBitFlagsPair(self) {
  let a = fromArray(self.slice(0, 8));
  let b = fromArray(self.slice(8, 16));
  return [
    a,
    b
  ];
}
function asArray(self) {
  return self;
}
function parse21(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "loadout");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readUInt16(reader, "hideVisibleAccessory");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let hideVisibleAccessory = e$2._0;
  let flags0 = fromByte(hideVisibleAccessory & 255);
  let flags1 = fromByte(hideVisibleAccessory >> 8 & 255);
  let hideVisibleAccessory$1 = fromBitFlagsPair(flags0, flags1);
  return {
    TAG: "Ok",
    _0: {
      playerId: e._0,
      loadout: e$1._0,
      hideVisibleAccessory: hideVisibleAccessory$1
    }
  };
}
function toBuffer21(self) {
  let match = toBitFlagsPair(self.hideVisibleAccessory);
  let hideVisibleAccessory = toByte(match[0]) | toByte(match[1]) << 8;
  return data(packUInt16(packByte(packByte(setType(make(), toInt("LoadoutSwitch")), self.playerId, "playerId"), self.loadout, "loadout"), hideVisibleAccessory, "hideVisibleAccessory"));
}
var Packet_NetModuleLoad_exports = {};
__export(Packet_NetModuleLoad_exports, {
  Buffer: () => Buffer2,
  Decode: () => Decode2,
  Encode: () => Encode2,
  NetModuleType: () => NetModuleType,
  maxNpcIndexSentinel: () => maxNpcIndexSentinel,
  parse: () => parse23,
  powerLevelToInt: () => powerLevelToInt,
  pylonActionToInt: () => pylonActionToInt,
  toBuffer: () => toBuffer22
});
function min(x, y) {
  if (x < y) {
    return x;
  } else {
    return y;
  }
}
function concatMany(arrs) {
  let lenArrs = arrs.length;
  let totalLen = 0;
  for (let i = 0; i < lenArrs; ++i) {
    totalLen = totalLen + arrs[i].length | 0;
  }
  let result = new Array(totalLen);
  totalLen = 0;
  for (let j = 0; j < lenArrs; ++j) {
    let cur = arrs[j];
    for (let k = 0, k_finish = cur.length; k < k_finish; ++k) {
      result[totalLen] = cur[k];
      totalLen = totalLen + 1 | 0;
    }
  }
  return result;
}
var CreativePowers_exports = {};
__export(CreativePowers_exports, {
  CreativePowerType: () => CreativePowerType,
  PerPlayerSliderPower: () => PerPlayerSliderPower,
  PerPlayerTogglePower: () => PerPlayerTogglePower,
  pack: () => pack$2,
  parse: () => parse$2,
  toString: () => toString$2
});
function toString2(self) {
  return `PerPlayerSliderPower { playerId: ` + self.playerId.toString() + `, value: ` + self.value.toString() + ` }`;
}
function pack(writer, self) {
  return packSingle(packByte(writer, self.playerId, "playerId"), self.value, "value");
}
function parse22(reader) {
  return {
    playerId: reader.readByte(),
    value: reader.readSingle()
  };
}
function toString$1(self) {
  if (self.TAG === "Everyone") {
    return `Everyone { values: ` + self._0.map((value) => {
      if (value) {
        return "1";
      } else {
        return "0";
      }
    }).join(", ") + ` }`;
  } else {
    return `Player { playerId: ` + self._0.toString() + `, value: ` + (self._1 ? "true" : "false") + ` }`;
  }
}
function pack$1(writer, self) {
  if (self.TAG === "Everyone") {
    let values = self._0;
    let bytes = intoChunks(values, 8).map(fromArray).map(toByte);
    return packBytes(packByte(writer, 0, "everyoneType"), bytes, "everyoneValues");
  } else {
    let playerId = self._0;
    let value = self._1;
    return packByte(packByte(packByte(writer, 1, "playerType"), playerId, "playerId"), value ? 1 : 0, "playerValue");
  }
}
function parse$1(reader) {
  let match = reader.readByte();
  if (match !== 0) {
    if (match !== 1) {
      return;
    } else {
      return {
        TAG: "Player",
        _0: reader.readByte(),
        _1: reader.readByte() === 1
      };
    }
  } else {
    let toggles = [];
    for (let _for = 1; _for <= 32; ++_for) {
      let byte = reader.readByte();
      forEach(fromByte(byte), (flag) => {
        toggles.push(flag);
      });
    }
    toggles.pop();
    return {
      TAG: "Everyone",
      _0: toggles
    };
  }
}
function toString$2(self) {
  if (typeof self !== "object") {
    switch (self) {
      case "StartDayImmediately":
        return `StartDayImmediately`;
      case "StartNoonImmediately":
        return `StartNoonImmediately`;
      case "StartNightImmediately":
        return `StartNightImmediately`;
      case "StartMidnightImmediately":
        return `StartMidnightImmediately`;
    }
  } else {
    switch (self.TAG) {
      case "FreezeTime":
        return `FreezeTime { value: ` + (self._0 ? "true" : "false") + ` }`;
      case "GodmodePower":
        return `GodmodePower { message: ` + toString$1(self._0) + ` }`;
      case "ModifyWindDirectionAndStrength":
        return `ModifyWindDirectionAndStrength { value: ` + self._0.toString() + ` }`;
      case "ModifyRainPower":
        return `ModifyRainPower { value: ` + self._0.toString() + ` }`;
      case "ModifyTimeRate":
        return `ModifyTimeRate { value: ` + self._0.toString() + ` }`;
      case "FreezeRainPower":
        return `FreezeRainPower { value: ` + (self._0 ? "true" : "false") + ` }`;
      case "FreezeWindDirectionAndStrength":
        return `FreezeWindDirectionAndStrength { value: ` + (self._0 ? "true" : "false") + ` }`;
      case "FarPlacementRangePower":
        return `FarPlacementRangePower { message: ` + toString$1(self._0) + ` }`;
      case "DifficultySliderPower":
        return `DifficultySliderPower { value: ` + self._0.toString() + ` }`;
      case "StopBiomeSpreadPower":
        return `StopBiomeSpreadPower { value: ` + (self._0 ? "true" : "false") + ` }`;
      case "SpawnRateSliderPerPlayerPower":
        return `SpawnRateSliderPerPlayerPower { sliderPower: ` + toString2(self._0) + ` }`;
    }
  }
}
function toString$3(self) {
  switch (self) {
    case "FreezeTime":
      return "FreezeTime";
    case "StartDayImmediately":
      return "StartDayImmediately";
    case "StartNoonImmediately":
      return "StartNoonImmediately";
    case "StartNightImmediately":
      return "StartNightImmediately";
    case "StartMidnightImmediately":
      return "StartMidnightImmediately";
    case "GodmodePower":
      return "GodmodePower";
    case "ModifyWindDirectionAndStrength":
      return "ModifyWindDirectionAndStrength";
    case "ModifyRainPower":
      return "ModifyRainPower";
    case "ModifyTimeRate":
      return "ModifyTimeRate";
    case "FreezeRainPower":
      return "FreezeRainPower";
    case "FreezeWindDirectionAndStrength":
      return "FreezeWindDirectionAndStrength";
    case "FarPlacementRangePower":
      return "FarPlacementRangePower";
    case "DifficultySliderPower":
      return "DifficultySliderPower";
    case "StopBiomeSpreadPower":
      return "StopBiomeSpreadPower";
    case "SpawnRateSliderPerPlayerPower":
      return "SpawnRateSliderPerPlayerPower";
  }
}
function fromInt5(n) {
  switch (n) {
    case 0:
      return "FreezeTime";
    case 1:
      return "StartDayImmediately";
    case 2:
      return "StartNoonImmediately";
    case 3:
      return "StartNightImmediately";
    case 4:
      return "StartMidnightImmediately";
    case 5:
      return "GodmodePower";
    case 6:
      return "ModifyWindDirectionAndStrength";
    case 7:
      return "ModifyRainPower";
    case 8:
      return "ModifyTimeRate";
    case 9:
      return "FreezeRainPower";
    case 10:
      return "FreezeWindDirectionAndStrength";
    case 11:
      return "FarPlacementRangePower";
    case 12:
      return "DifficultySliderPower";
    case 13:
      return "StopBiomeSpreadPower";
    case 14:
      return "SpawnRateSliderPerPlayerPower";
    default:
      return;
  }
}
function toInt5(self) {
  switch (self) {
    case "FreezeTime":
      return 0;
    case "StartDayImmediately":
      return 1;
    case "StartNoonImmediately":
      return 2;
    case "StartNightImmediately":
      return 3;
    case "StartMidnightImmediately":
      return 4;
    case "GodmodePower":
      return 5;
    case "ModifyWindDirectionAndStrength":
      return 6;
    case "ModifyRainPower":
      return 7;
    case "ModifyTimeRate":
      return 8;
    case "FreezeRainPower":
      return 9;
    case "FreezeWindDirectionAndStrength":
      return 10;
    case "FarPlacementRangePower":
      return 11;
    case "DifficultySliderPower":
      return 12;
    case "StopBiomeSpreadPower":
      return 13;
    case "SpawnRateSliderPerPlayerPower":
      return 14;
  }
}
var CreativePowerType = {
  toString: toString$3,
  fromInt: fromInt5,
  toInt: toInt5
};
function pack$2(writer, self) {
  if (typeof self !== "object") {
    switch (self) {
      case "StartDayImmediately":
        return packUInt16(writer, 1, "startDayImmediatelyType");
      case "StartNoonImmediately":
        return packUInt16(writer, 2, "startNoonImmediatelyType");
      case "StartNightImmediately":
        return packUInt16(writer, 3, "startNightImmediatelyType");
      case "StartMidnightImmediately":
        return packUInt16(writer, 4, "startMidnightImmediatelyType");
    }
  } else {
    switch (self.TAG) {
      case "FreezeTime":
        let value = self._0;
        return packByte(packUInt16(writer, 0, "freezeTimeType"), value ? 1 : 0, "freezeTimeValue");
      case "GodmodePower":
        let message = self._0;
        return pack$1(packUInt16(writer, 5, "godmodePowerType"), message);
      case "ModifyWindDirectionAndStrength":
        let value$1 = self._0;
        return packSingle(packUInt16(writer, 6, "modifyWindDirectionAndStrengthType"), value$1, "modifyWindDirectionAndStrengthValue");
      case "ModifyRainPower":
        let value$2 = self._0;
        return packSingle(packUInt16(writer, 7, "modifyRainPowerType"), value$2, "modifyRainPowerValue");
      case "ModifyTimeRate":
        let value$3 = self._0;
        return packSingle(packUInt16(writer, 8, "modifyTimeRateType"), value$3, "modifyTimeRateValue");
      case "FreezeRainPower":
        let on = self._0;
        return packByte(packUInt16(writer, 9, "freezeRainPowerType"), on ? 1 : 0, "freezeRainPowerValue");
      case "FreezeWindDirectionAndStrength":
        let on$1 = self._0;
        return packByte(packUInt16(writer, 10, "freezeWindDirectionAndStrengthType"), on$1 ? 1 : 0, "freezeWindDirectionAndStrengthValue");
      case "FarPlacementRangePower":
        let message$1 = self._0;
        return pack$1(packUInt16(writer, 11, "farPlacementRangePowerType"), message$1);
      case "DifficultySliderPower":
        let value$4 = self._0;
        return packSingle(packUInt16(writer, 12, "difficultySliderPowerType"), value$4, "difficultySliderPowerValue");
      case "StopBiomeSpreadPower":
        let on$2 = self._0;
        return packByte(packUInt16(writer, 13, "stopBiomeSpreadPowerType"), on$2 ? 1 : 0, "stopBiomeSpreadPowerValue");
      case "SpawnRateSliderPerPlayerPower":
        let message$2 = self._0;
        return pack(packUInt16(writer, 14, "spawnRateSliderPerPlayerPowerType"), message$2);
    }
  }
}
function parse$2(reader) {
  let match = reader.readUInt16();
  switch (match) {
    case 0:
      return {
        TAG: "FreezeTime",
        _0: reader.readByte() === 1
      };
    case 1:
      return "StartDayImmediately";
    case 2:
      return "StartNoonImmediately";
    case 3:
      return "StartNightImmediately";
    case 4:
      return "StartMidnightImmediately";
    case 5:
      return map2(parse$1(reader), (m) => ({
        TAG: "GodmodePower",
        _0: m
      }));
    case 6:
      return {
        TAG: "ModifyWindDirectionAndStrength",
        _0: reader.readSingle()
      };
    case 7:
      return {
        TAG: "ModifyRainPower",
        _0: reader.readSingle()
      };
    case 8:
      return {
        TAG: "ModifyTimeRate",
        _0: reader.readSingle()
      };
    case 9:
      return {
        TAG: "FreezeRainPower",
        _0: reader.readByte() === 1
      };
    case 10:
      return {
        TAG: "FreezeWindDirectionAndStrength",
        _0: reader.readByte() === 1
      };
    case 11:
      return map2(parse$1(reader), (m) => ({
        TAG: "FarPlacementRangePower",
        _0: m
      }));
    case 12:
      return {
        TAG: "DifficultySliderPower",
        _0: reader.readSingle()
      };
    case 13:
      return {
        TAG: "StopBiomeSpreadPower",
        _0: reader.readByte() === 1
      };
    case 14:
      return map2(parse22(reader), (m) => ({
        TAG: "SpawnRateSliderPerPlayerPower",
        _0: m
      }));
    default:
      return;
  }
}
var PerPlayerSliderPower = {
  pack,
  parse: parse22
};
var PerPlayerTogglePower = {
  pack: pack$1,
  parse: parse$1
};
function pylonActionToInt(pylonAction) {
  switch (pylonAction) {
    case "Added":
      return 0;
    case "Removed":
      return 1;
    case "RequestTeleport":
      return 2;
  }
}
function powerLevelToInt(powerLevel) {
  switch (powerLevel) {
    case "LockedForEveryone":
      return 0;
    case "CanBeChangedByHostAlone":
      return 1;
    case "CanBeChangedByEveryone":
      return 2;
  }
}
function fromInt6(n) {
  switch (n) {
    case 0:
      return "Liquid";
    case 1:
      return "Text";
    case 2:
      return "Ping";
    case 3:
      return "Ambience";
    case 4:
      return "Bestiary";
    case 5:
      return "CreativePower";
    case 6:
      return "CreativeUnlocksPlayerReport";
    case 7:
      return "TeleportPylon";
    case 8:
      return "Particles";
    case 9:
      return "CreativePowerPermissions";
    case 10:
      return "Banners";
    case 11:
      return "CraftingRequests";
    case 12:
      return "TagEffectState";
    case 13:
      return "LeashedEntity";
    case 14:
      return "UnbreakableWallScan";
    default:
      return;
  }
}
function toInt6(self) {
  switch (self) {
    case "Liquid":
      return 0;
    case "Text":
      return 1;
    case "Ping":
      return 2;
    case "Ambience":
      return 3;
    case "Bestiary":
      return 4;
    case "CreativePower":
      return 5;
    case "CreativeUnlocksPlayerReport":
      return 6;
    case "TeleportPylon":
      return 7;
    case "Particles":
      return 8;
    case "CreativePowerPermissions":
      return 9;
    case "Banners":
      return 10;
    case "CraftingRequests":
      return 11;
    case "TagEffectState":
      return 12;
    case "LeashedEntity":
      return 13;
    case "UnbreakableWallScan":
      return 14;
  }
}
var NetModuleType = {
  fromInt: fromInt6,
  toInt: toInt6
};
function pack7BitEncodedInt(writer, value, context) {
  let writer$1 = writer;
  let remaining = value;
  let $$continue = true;
  while ($$continue) {
    let byte = remaining & 127;
    remaining = remaining >>> 7;
    if (remaining !== 0) {
      byte = byte | 128;
    }
    writer$1 = packByte(writer$1, byte, context);
    if (remaining === 0) {
      $$continue = false;
    }
  }
  ;
  return writer$1;
}
function liquidToBuffer(liquid) {
  let writer = packUInt16(packUInt16(setType(make(), toInt("NetModuleLoad")), 0, "moduleType"), liquid.changes.length, "changesCount");
  liquid.changes.forEach((change) => {
    packByte(packByte(packInt16(packInt16(writer, change.y, "y"), change.x, "x"), change.amount, "amount"), change.liquidType, "liquidType");
  });
  return data(writer);
}
function clientTextToBuffer(commandId, message) {
  return data(packString(packString(packUInt16(setType(make(), toInt("NetModuleLoad")), 1, "moduleType"), commandId, "commandId"), message, "message"));
}
function serverTextToBuffer(playerId, networkText, color) {
  return data(packColor(packNetworkText(packByte(packUInt16(setType(make(), toInt("NetModuleLoad")), 1, "moduleType"), playerId, "playerId"), networkText, "networkText"), color, "color"));
}
function pingToBuffer(ping) {
  return data(packSingle(packSingle(packUInt16(setType(make(), toInt("NetModuleLoad")), 2, "moduleType"), ping.x, "x"), ping.y, "y"));
}
function ambienceToBuffer(ambience) {
  return data(packByte(packInt32(packByte(packUInt16(setType(make(), toInt("NetModuleLoad")), 3, "moduleType"), ambience.playerId, "playerId"), ambience.seed, "seed"), ambience.skyEntityType, "skyEntityType"));
}
function bestiaryToBuffer(bestiary) {
  let writer = packUInt16(setType(make(), toInt("NetModuleLoad")), 4, "moduleType");
  let _count = bestiary.unlockType;
  let tmp;
  tmp = typeof _count !== "object" ? _count === "Sight" ? packByte(writer, 1, "unlockTypeByte") : packByte(writer, 2, "unlockTypeByte") : packByte(writer, 0, "unlockTypeByte");
  packInt16(tmp, bestiary.npcId, "npcId");
  let count = bestiary.unlockType;
  let tmp$1;
  tmp$1 = typeof count !== "object" ? writer : pack7BitEncodedInt(writer, count._0, "killCount");
  return data(tmp$1);
}
function creativePowerToBuffer(creativePower) {
  return data(pack$2(packUInt16(setType(make(), toInt("NetModuleLoad")), 5, "moduleType"), creativePower));
}
function creativeUnlocksPlayerReportToBuffer(unlockReport) {
  return data(packUInt16(packUInt16(packByte(packUInt16(setType(make(), toInt("NetModuleLoad")), 6, "moduleType"), unlockReport.userId, "userId"), unlockReport.itemId, "itemId"), unlockReport.researchedCount, "researchedCount"));
}
function teleportPylonToBuffer(teleportPylon) {
  return data(packByte(packInt16(packInt16(packByte(packUInt16(setType(make(), toInt("NetModuleLoad")), 7, "moduleType"), pylonActionToInt(teleportPylon.pylonAction), "pylonAction"), teleportPylon.x, "x"), teleportPylon.y, "y"), teleportPylon.pylonType, "pylonType"));
}
function particlesToBuffer(particle) {
  return data(packByte(packInt32(packSingle(packSingle(packSingle(packSingle(packByte(packUInt16(setType(make(), toInt("NetModuleLoad")), 8, "moduleType"), particle.particleType, "particleType"), particle.x, "x"), particle.y, "y"), particle.vx, "vx"), particle.vy, "vy"), particle.shaderIndex, "shaderIndex"), particle.invokedByPlayer, "invokedByPlayer"));
}
function creativePowerPermissionsToBuffer(creativePowerPermission) {
  return data(packByte(packUInt16(packByte(packUInt16(setType(make(), toInt("NetModuleLoad")), 9, "moduleType"), 0, "messageType"), creativePowerPermission.powerType, "powerType"), powerLevelToInt(creativePowerPermission.powerLevel), "powerLevel"));
}
function bannersToBuffer(message) {
  let writer = packUInt16(setType(make(), toInt("NetModuleLoad")), 10, "moduleType");
  switch (message.TAG) {
    case "BannerFullState":
      let state = message._0;
      let writer$1 = packInt16(packByte(writer, 0, "messageType"), state.killCounts.length, "killCountLength");
      state.killCounts.forEach((count) => {
        packInt32(writer$1, count, "killCount");
      });
      let writer$2 = packInt16(writer$1, state.claimableCounts.length, "claimableCountLength");
      state.claimableCounts.forEach((count) => {
        packUInt16(writer$2, count, "claimableCount");
      });
      return data(writer$2);
    case "BannerKillCountUpdate":
      let match = message._0;
      return data(packInt32(packInt16(packByte(writer, 1, "messageType"), match.bannerId, "bannerId"), match.killCount, "killCount"));
    case "BannerClaimCountUpdate":
      let match$1 = message._0;
      return data(packUInt16(packInt16(packByte(writer, 2, "messageType"), match$1.bannerId, "bannerId"), match$1.claimCount, "claimCount"));
    case "BannerClaimRequest":
      let match$2 = message._0;
      return data(packUInt16(packInt16(packByte(writer, 3, "messageType"), match$2.bannerId, "bannerId"), match$2.amount, "amount"));
    case "BannerClaimResponse":
      let match$3 = message._0;
      return data(packBool(packUInt16(packInt16(packByte(writer, 4, "messageType"), match$3.bannerId, "bannerId"), match$3.amount, "amount"), match$3.granted, "granted"));
  }
}
function craftingRequestsToBuffer(message) {
  let writer = packUInt16(setType(make(), toInt("NetModuleLoad")), 11, "moduleType");
  if (message.TAG !== "CraftingRequest") {
    return data(packBool(writer, message._0.approved, "approved"));
  }
  let request = message._0;
  let writer$1 = pack7BitEncodedInt(writer, request.items.length, "itemsCount");
  request.items.forEach((item) => {
    pack7BitEncodedInt(packInt32(writer$1, item.itemIdOrRecipeGroup, "itemIdOrRecipeGroup"), item.stack, "stack");
  });
  let writer$2 = pack7BitEncodedInt(writer$1, request.chestIndexes.length, "chestCount");
  request.chestIndexes.forEach((chestIndex) => {
    pack7BitEncodedInt(writer$2, chestIndex, "chestIndex");
  });
  return data(writer$2);
}
function packSparseNpcTimes(writer, entries) {
  let writer$1 = {
    contents: writer
  };
  entries.forEach((entry) => {
    writer$1.contents = packInt32(packByte(writer$1.contents, entry.npcIndex, "npcIndex"), entry.time, "npcTime");
  });
  return packByte(writer$1.contents, 200, "npcIndexSentinel");
}
function tagEffectStateToBuffer(message) {
  let writer = packUInt16(setType(make(), toInt("NetModuleLoad")), 12, "moduleType");
  switch (message.TAG) {
    case "TagFullState":
      let match = message._0;
      let procTimeLeft = match.procTimeLeft;
      let writer$1 = packSparseNpcTimes(packInt16(packByte(packByte(writer, match.ownerId, "ownerId"), 0, "messageType"), match.effectType, "effectType"), match.timeLeft);
      if (procTimeLeft !== void 0) {
        return data(packSparseNpcTimes(writer$1, procTimeLeft));
      } else {
        return data(writer$1);
      }
    case "TagChangeActiveEffect":
      let match$1 = message._0;
      return data(packInt16(packByte(packByte(writer, match$1.ownerId, "ownerId"), 1, "messageType"), match$1.effectType, "effectType"));
    case "TagApplyTagToNpc":
      let match$2 = message._0;
      return data(packByte(packByte(packByte(writer, match$2.ownerId, "ownerId"), 2, "messageType"), match$2.npcIndex, "npcIndex"));
    case "TagEnableProcOnNpc":
      let match$3 = message._0;
      return data(packByte(packByte(packByte(writer, match$3.ownerId, "ownerId"), 3, "messageType"), match$3.npcIndex, "npcIndex"));
    case "TagClearProcOnNpc":
      let match$4 = message._0;
      return data(packByte(packByte(packByte(writer, match$4.ownerId, "ownerId"), 4, "messageType"), match$4.npcIndex, "npcIndex"));
  }
}
function leashedEntityToBuffer(message) {
  let writer = packUInt16(setType(make(), toInt("NetModuleLoad")), 13, "moduleType");
  switch (message.TAG) {
    case "LeashedRemove":
      return data(pack7BitEncodedInt(packByte(writer, 0, "messageType"), message._0.slot, "slot"));
    case "LeashedFullSync":
      let match = message._0;
      return data(packBuffer(packInt16(packInt16(pack7BitEncodedInt(pack7BitEncodedInt(packByte(writer, 1, "messageType"), match.slot, "slot"), match.entityType, "entityType"), match.anchorX, "anchorX"), match.anchorY, "anchorY"), match.payload, "payload"));
    case "LeashedPartialSync":
      let match$1 = message._0;
      return data(packBuffer(pack7BitEncodedInt(pack7BitEncodedInt(packByte(writer, 2, "messageType"), match$1.slot, "slot"), match$1.entityType, "entityType"), match$1.payload, "payload"));
  }
}
function unbreakableWallScanToBuffer(payload) {
  return data(packBool(packByte(packUInt16(setType(make(), toInt("NetModuleLoad")), 14, "moduleType"), payload.playerId, "playerId"), payload.insideUnbreakableWalls, "insideUnbreakableWalls"));
}
function toBuffer22(self) {
  switch (self.TAG) {
    case "Liquid":
      return liquidToBuffer(self._0);
    case "ClientText":
      return clientTextToBuffer(self._0, self._1);
    case "ServerText":
      return serverTextToBuffer(self._0, self._1, self._2);
    case "Ping":
      return pingToBuffer(self._0);
    case "Ambience":
      return ambienceToBuffer(self._0);
    case "Bestiary":
      return bestiaryToBuffer(self._0);
    case "CreativePower":
      return creativePowerToBuffer(self._0);
    case "CreativeUnlocksPlayerReport":
      return creativeUnlocksPlayerReportToBuffer(self._0);
    case "TeleportPylon":
      return teleportPylonToBuffer(self._0);
    case "Particles":
      return particlesToBuffer(self._0);
    case "CreativePowerPermissions":
      return creativePowerPermissionsToBuffer(self._0);
    case "Banners":
      return bannersToBuffer(self._0);
    case "CraftingRequests":
      return craftingRequestsToBuffer(self._0);
    case "TagEffectState":
      return tagEffectStateToBuffer(self._0);
    case "LeashedEntity":
      return leashedEntityToBuffer(self._0);
    case "UnbreakableWallScan":
      return unbreakableWallScanToBuffer(self._0);
  }
}
var Encode2 = {
  packInt32,
  packInt16,
  packNetworkText,
  packColor,
  packString,
  packUInt16,
  packByte,
  packSingle,
  packBool,
  packBuffer,
  setType,
  data,
  pack7BitEncodedInt,
  liquidToBuffer,
  clientTextToBuffer,
  serverTextToBuffer,
  pingToBuffer,
  ambienceToBuffer,
  bestiaryToBuffer,
  creativePowerToBuffer,
  creativeUnlocksPlayerReportToBuffer,
  teleportPylonToBuffer,
  particlesToBuffer,
  creativePowerPermissionsToBuffer,
  bannersToBuffer,
  craftingRequestsToBuffer,
  packSparseNpcTimes,
  tagEffectStateToBuffer,
  leashedEntityToBuffer,
  unbreakableWallScanToBuffer,
  toBuffer: toBuffer22
};
function parseLiquid(reader) {
  let e = readUInt16(reader, "changesCount");
  if (e.TAG !== "Ok") {
    return e;
  }
  let changesCount = e._0;
  let readChanges = (_idx, _acc) => {
    while (true) {
      let acc = _acc;
      let idx = _idx;
      if (idx >= changesCount) {
        return {
          TAG: "Ok",
          _0: acc.toReversed()
        };
      }
      let e2 = readInt16(reader, "y");
      if (e2.TAG !== "Ok") {
        return e2;
      }
      let e$12 = readInt16(reader, "x");
      if (e$12.TAG !== "Ok") {
        return e$12;
      }
      let e$2 = readByte(reader, "amount");
      if (e$2.TAG !== "Ok") {
        return e$2;
      }
      let e$3 = readByte(reader, "liquidType");
      if (e$3.TAG !== "Ok") {
        return e$3;
      }
      _acc = concatMany([
        [{
          x: e$12._0,
          y: e2._0,
          amount: e$2._0,
          liquidType: e$3._0
        }],
        acc
      ]);
      _idx = idx + 1 | 0;
      continue;
    }
    ;
  };
  let e$1 = readChanges(0, []);
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        TAG: "Liquid",
        _0: {
          changes: e$1._0
        }
      }
    };
  } else {
    return e$1;
  }
}
function parseText(reader, fromServer) {
  if (fromServer) {
    let e = readByte(reader, "playerId");
    if (e.TAG !== "Ok") {
      return e;
    }
    let e$1 = readNetworkText(reader, "message");
    if (e$1.TAG !== "Ok") {
      return e$1;
    }
    let e$2 = readColor(reader, "color");
    if (e$2.TAG === "Ok") {
      return {
        TAG: "Ok",
        _0: {
          TAG: "ServerText",
          _0: e._0,
          _1: e$1._0,
          _2: e$2._0
        }
      };
    } else {
      return e$2;
    }
  }
  let e$3 = readString(reader, "commandId");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readString(reader, "message");
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        TAG: "ClientText",
        _0: e$3._0,
        _1: e$4._0
      }
    };
  } else {
    return e$4;
  }
}
function parsePing(reader) {
  let e = readSingle(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "y");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        TAG: "Ping",
        _0: {
          x: e._0,
          y: e$1._0
        }
      }
    };
  } else {
    return e$1;
  }
}
function parseAmbience(reader) {
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "seed");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "skyEntityType");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        TAG: "Ambience",
        _0: {
          playerId: e._0,
          seed: e$1._0,
          skyEntityType: e$2._0
        }
      }
    };
  } else {
    return e$2;
  }
}
function parseBestiary(reader) {
  let e = readByte(reader, "rawBestiaryUnlockType");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "npcId");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2;
  switch (e._0) {
    case 0:
      let e$3 = read7BitEncodedInt(reader, "killCount");
      e$2 = e$3.TAG === "Ok" ? {
        TAG: "Ok",
        _0: {
          TAG: "Kill",
          _0: e$3._0
        }
      } : e$3;
      break;
    case 1:
      e$2 = {
        TAG: "Ok",
        _0: "Sight"
      };
      break;
    case 2:
      e$2 = {
        TAG: "Ok",
        _0: "Chat"
      };
      break;
    default:
      e$2 = {
        TAG: "Error",
        _0: {
          context: "Packet_NetModuleLoad.parseBestiary",
          error: new Error("Unknown bestiary unlock type")
        }
      };
  }
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        TAG: "Bestiary",
        _0: {
          unlockType: e$2._0,
          npcId: e$1._0
        }
      }
    };
  } else {
    return e$2;
  }
}
function parseCreativePower(reader) {
  let p = parse$2(reader);
  if (p !== void 0) {
    return {
      TAG: "Ok",
      _0: {
        TAG: "CreativePower",
        _0: p
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: {
        context: "Packet_NetModuleLoad.parseCreativePower",
        error: new Error("Failed to parse creative power")
      }
    };
  }
}
function parseCreativeUnlocksPlayerReport(reader) {
  let e = readByte(reader, "userId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readUInt16(reader, "itemId");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readUInt16(reader, "researchedCount");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        TAG: "CreativeUnlocksPlayerReport",
        _0: {
          userId: e._0,
          itemId: e$1._0,
          researchedCount: e$2._0
        }
      }
    };
  } else {
    return e$2;
  }
}
function parseTeleportPylon(reader) {
  let e = readByte(reader, "rawPylonAction");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "pylonType");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let pylonAction;
  switch (e._0) {
    case 0:
      pylonAction = "Added";
      break;
    case 1:
      pylonAction = "Removed";
      break;
    case 2:
      pylonAction = "RequestTeleport";
      break;
    default:
      pylonAction = void 0;
  }
  if (pylonAction !== void 0) {
    return {
      TAG: "Ok",
      _0: {
        TAG: "TeleportPylon",
        _0: {
          pylonAction,
          x: e$1._0,
          y: e$2._0,
          pylonType: e$3._0
        }
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: {
        context: "Packet_NetModuleLoad.parseTeleportPylon",
        error: new Error("Unknown pylon action")
      }
    };
  }
}
function parseParticle(reader) {
  let e = readByte(reader, "particleType");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "vx");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readSingle(reader, "vy");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readInt32(reader, "shaderIndex");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readByte(reader, "invokedByPlayer");
  if (e$6.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        TAG: "Particles",
        _0: {
          particleType: e._0,
          x: e$1._0,
          y: e$2._0,
          vx: e$3._0,
          vy: e$4._0,
          shaderIndex: e$5._0,
          invokedByPlayer: e$6._0
        }
      }
    };
  } else {
    return e$6;
  }
}
function parseCreativePowerPermission(reader) {
  let e = readByte(reader, "messageType");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readUInt16(reader, "powerType");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "rawPowerLevel");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let powerLevel;
  switch (e$2._0) {
    case 0:
      powerLevel = "LockedForEveryone";
      break;
    case 1:
      powerLevel = "CanBeChangedByHostAlone";
      break;
    case 2:
      powerLevel = "CanBeChangedByEveryone";
      break;
    default:
      powerLevel = void 0;
  }
  if (powerLevel !== void 0) {
    return {
      TAG: "Ok",
      _0: {
        TAG: "CreativePowerPermissions",
        _0: {
          powerType: e$1._0,
          powerLevel
        }
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: {
        context: "Packet_NetModuleLoad.parseCreativePowerPermission",
        error: new Error("Unknown creative power permission level")
      }
    };
  }
}
function parseBanners(reader) {
  let e = readByte(reader, "messageType");
  if (e.TAG !== "Ok") {
    return e;
  }
  switch (e._0) {
    case 0:
      let e$1 = readInt16(reader, "killCountLength");
      if (e$1.TAG !== "Ok") {
        return e$1;
      }
      let killCountLength = e$1._0;
      let readKillCounts = (_idx, _acc) => {
        while (true) {
          let acc = _acc;
          let idx = _idx;
          if (idx >= killCountLength) {
            return {
              TAG: "Ok",
              _0: acc.toReversed()
            };
          }
          let e2 = readInt32(reader, "killCount");
          if (e2.TAG !== "Ok") {
            return e2;
          }
          _acc = concatMany([
            [e2._0],
            acc
          ]);
          _idx = idx + 1 | 0;
          continue;
        }
        ;
      };
      let e$2 = readKillCounts(0, []);
      if (e$2.TAG !== "Ok") {
        return e$2;
      }
      let e$3 = readInt16(reader, "claimableCountLength");
      if (e$3.TAG !== "Ok") {
        return e$3;
      }
      let claimableCountLength = e$3._0;
      let readClaimableCounts = (_idx, _acc) => {
        while (true) {
          let acc = _acc;
          let idx = _idx;
          if (idx >= claimableCountLength) {
            return {
              TAG: "Ok",
              _0: acc.toReversed()
            };
          }
          let e2 = readUInt16(reader, "claimableCount");
          if (e2.TAG !== "Ok") {
            return e2;
          }
          _acc = concatMany([
            [e2._0],
            acc
          ]);
          _idx = idx + 1 | 0;
          continue;
        }
        ;
      };
      let e$4 = readClaimableCounts(0, []);
      if (e$4.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "Banners",
            _0: {
              TAG: "BannerFullState",
              _0: {
                killCounts: e$2._0,
                claimableCounts: e$4._0
              }
            }
          }
        };
      } else {
        return e$4;
      }
    case 1:
      let e$5 = readInt16(reader, "bannerId");
      if (e$5.TAG !== "Ok") {
        return e$5;
      }
      let e$6 = readInt32(reader, "killCount");
      if (e$6.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "Banners",
            _0: {
              TAG: "BannerKillCountUpdate",
              _0: {
                bannerId: e$5._0,
                killCount: e$6._0
              }
            }
          }
        };
      } else {
        return e$6;
      }
    case 2:
      let e$7 = readInt16(reader, "bannerId");
      if (e$7.TAG !== "Ok") {
        return e$7;
      }
      let e$8 = readUInt16(reader, "claimCount");
      if (e$8.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "Banners",
            _0: {
              TAG: "BannerClaimCountUpdate",
              _0: {
                bannerId: e$7._0,
                claimCount: e$8._0
              }
            }
          }
        };
      } else {
        return e$8;
      }
    case 3:
      let e$9 = readInt16(reader, "bannerId");
      if (e$9.TAG !== "Ok") {
        return e$9;
      }
      let e$10 = readUInt16(reader, "amount");
      if (e$10.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "Banners",
            _0: {
              TAG: "BannerClaimRequest",
              _0: {
                bannerId: e$9._0,
                amount: e$10._0
              }
            }
          }
        };
      } else {
        return e$10;
      }
    case 4:
      let e$11 = readInt16(reader, "bannerId");
      if (e$11.TAG !== "Ok") {
        return e$11;
      }
      let e$12 = readUInt16(reader, "amount");
      if (e$12.TAG !== "Ok") {
        return e$12;
      }
      let e$13 = readBool(reader, "granted");
      if (e$13.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "Banners",
            _0: {
              TAG: "BannerClaimResponse",
              _0: {
                bannerId: e$11._0,
                amount: e$12._0,
                granted: e$13._0
              }
            }
          }
        };
      } else {
        return e$13;
      }
    default:
      return {
        TAG: "Error",
        _0: {
          context: "Packet_NetModuleLoad.parseBanners",
          error: new Error("Unknown banner message type")
        }
      };
  }
}
function parseCraftingRequests(reader, fromServer) {
  if (fromServer) {
    let e = readBool(reader, "approved");
    if (e.TAG === "Ok") {
      return {
        TAG: "Ok",
        _0: {
          TAG: "CraftingRequests",
          _0: {
            TAG: "CraftingResponse",
            _0: {
              approved: e._0
            }
          }
        }
      };
    } else {
      return e;
    }
  }
  let e$1 = read7BitEncodedInt(reader, "itemsCount");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let itemsCount = e$1._0;
  let readItems = (_idx, _acc) => {
    while (true) {
      let acc = _acc;
      let idx = _idx;
      if (idx >= itemsCount) {
        return {
          TAG: "Ok",
          _0: acc.toReversed()
        };
      }
      let e = readInt32(reader, "itemIdOrRecipeGroup");
      if (e.TAG !== "Ok") {
        return e;
      }
      let e$12 = read7BitEncodedInt(reader, "stack");
      if (e$12.TAG !== "Ok") {
        return e$12;
      }
      _acc = concatMany([
        [{
          itemIdOrRecipeGroup: e._0,
          stack: e$12._0
        }],
        acc
      ]);
      _idx = idx + 1 | 0;
      continue;
    }
    ;
  };
  let e$2 = readItems(0, []);
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = read7BitEncodedInt(reader, "chestCount");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let chestCount = e$3._0;
  let readChests = (_idx, _acc) => {
    while (true) {
      let acc = _acc;
      let idx = _idx;
      if (idx >= chestCount) {
        return {
          TAG: "Ok",
          _0: acc.toReversed()
        };
      }
      let e = read7BitEncodedInt(reader, "chestIndex");
      if (e.TAG !== "Ok") {
        return e;
      }
      _acc = concatMany([
        [e._0],
        acc
      ]);
      _idx = idx + 1 | 0;
      continue;
    }
    ;
  };
  let e$4 = readChests(0, []);
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        TAG: "CraftingRequests",
        _0: {
          TAG: "CraftingRequest",
          _0: {
            items: e$2._0,
            chestIndexes: e$4._0
          }
        }
      }
    };
  } else {
    return e$4;
  }
}
function readSparseNpcTimes(reader) {
  let _acc = [];
  while (true) {
    let acc = _acc;
    let e = readByte(reader, "npcIndex");
    if (e.TAG !== "Ok") {
      return e;
    }
    let npcIndex = e._0;
    if (npcIndex >= 200) {
      return {
        TAG: "Ok",
        _0: acc.toReversed()
      };
    }
    let e$1 = readInt32(reader, "npcTime");
    if (e$1.TAG !== "Ok") {
      return e$1;
    }
    _acc = concatMany([
      [{
        npcIndex,
        time: e$1._0
      }],
      acc
    ]);
    continue;
  }
  ;
}
function parseTagEffectState(reader) {
  let e = readByte(reader, "ownerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let ownerId = e._0;
  let e$1 = readByte(reader, "messageType");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  switch (e$1._0) {
    case 0:
      let e$2 = readInt16(reader, "effectType");
      if (e$2.TAG !== "Ok") {
        return e$2;
      }
      let effectType = e$2._0;
      let e$3 = readSparseNpcTimes(reader);
      if (e$3.TAG !== "Ok") {
        return e$3;
      }
      let timeLeft = e$3._0;
      let e$4 = getBytesLeft(reader);
      if (e$4.TAG !== "Ok") {
        return e$4;
      }
      if (e$4._0 <= 0) {
        return {
          TAG: "Ok",
          _0: {
            TAG: "TagEffectState",
            _0: {
              TAG: "TagFullState",
              _0: {
                ownerId,
                effectType,
                timeLeft,
                procTimeLeft: void 0
              }
            }
          }
        };
      }
      let e$5 = readSparseNpcTimes(reader);
      if (e$5.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "TagEffectState",
            _0: {
              TAG: "TagFullState",
              _0: {
                ownerId,
                effectType,
                timeLeft,
                procTimeLeft: e$5._0
              }
            }
          }
        };
      } else {
        return e$5;
      }
    case 1:
      let e$6 = readInt16(reader, "effectType");
      if (e$6.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "TagEffectState",
            _0: {
              TAG: "TagChangeActiveEffect",
              _0: {
                ownerId,
                effectType: e$6._0
              }
            }
          }
        };
      } else {
        return e$6;
      }
    case 2:
      let e$7 = readByte(reader, "npcIndex");
      if (e$7.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "TagEffectState",
            _0: {
              TAG: "TagApplyTagToNpc",
              _0: {
                ownerId,
                npcIndex: e$7._0
              }
            }
          }
        };
      } else {
        return e$7;
      }
    case 3:
      let e$8 = readByte(reader, "npcIndex");
      if (e$8.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "TagEffectState",
            _0: {
              TAG: "TagEnableProcOnNpc",
              _0: {
                ownerId,
                npcIndex: e$8._0
              }
            }
          }
        };
      } else {
        return e$8;
      }
    case 4:
      let e$9 = readByte(reader, "npcIndex");
      if (e$9.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "TagEffectState",
            _0: {
              TAG: "TagClearProcOnNpc",
              _0: {
                ownerId,
                npcIndex: e$9._0
              }
            }
          }
        };
      } else {
        return e$9;
      }
    default:
      return {
        TAG: "Error",
        _0: {
          context: "Packet_NetModuleLoad.parseTagEffectState",
          error: new Error("Unknown tag effect state message type")
        }
      };
  }
}
function parseLeashedEntity(reader) {
  let e = readByte(reader, "messageType");
  if (e.TAG !== "Ok") {
    return e;
  }
  switch (e._0) {
    case 0:
      let e$1 = read7BitEncodedInt(reader, "slot");
      if (e$1.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "LeashedEntity",
            _0: {
              TAG: "LeashedRemove",
              _0: {
                slot: e$1._0
              }
            }
          }
        };
      } else {
        return e$1;
      }
    case 1:
      let e$2 = read7BitEncodedInt(reader, "slot");
      if (e$2.TAG !== "Ok") {
        return e$2;
      }
      let e$3 = read7BitEncodedInt(reader, "entityType");
      if (e$3.TAG !== "Ok") {
        return e$3;
      }
      let e$4 = readInt16(reader, "anchorX");
      if (e$4.TAG !== "Ok") {
        return e$4;
      }
      let e$5 = readInt16(reader, "anchorY");
      if (e$5.TAG !== "Ok") {
        return e$5;
      }
      let e$6 = getBytesLeft(reader);
      if (e$6.TAG !== "Ok") {
        return e$6;
      }
      let e$7 = readBuffer(reader, e$6._0, "payload");
      if (e$7.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "LeashedEntity",
            _0: {
              TAG: "LeashedFullSync",
              _0: {
                slot: e$2._0,
                entityType: e$3._0,
                anchorX: e$4._0,
                anchorY: e$5._0,
                payload: e$7._0
              }
            }
          }
        };
      } else {
        return e$7;
      }
    case 2:
      let e$8 = read7BitEncodedInt(reader, "slot");
      if (e$8.TAG !== "Ok") {
        return e$8;
      }
      let e$9 = read7BitEncodedInt(reader, "entityType");
      if (e$9.TAG !== "Ok") {
        return e$9;
      }
      let e$10 = getBytesLeft(reader);
      if (e$10.TAG !== "Ok") {
        return e$10;
      }
      let e$11 = readBuffer(reader, e$10._0, "payload");
      if (e$11.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "LeashedEntity",
            _0: {
              TAG: "LeashedPartialSync",
              _0: {
                slot: e$8._0,
                entityType: e$9._0,
                payload: e$11._0
              }
            }
          }
        };
      } else {
        return e$11;
      }
    default:
      return {
        TAG: "Error",
        _0: {
          context: "Packet_NetModuleLoad.parseLeashedEntity",
          error: new Error("Unknown leashed entity message type")
        }
      };
  }
}
function parseUnbreakableWallScan(reader) {
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readBool(reader, "insideUnbreakableWalls");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        TAG: "UnbreakableWallScan",
        _0: {
          playerId: e._0,
          insideUnbreakableWalls: e$1._0
        }
      }
    };
  } else {
    return e$1;
  }
}
function parse23(payload, fromServer) {
  let reader = new packetreader_default(payload);
  let e = readUInt16(reader, "moduleType");
  if (e.TAG !== "Ok") {
    return e;
  }
  let match = fromInt6(e._0);
  if (match === void 0) {
    return {
      TAG: "Error",
      _0: {
        context: "Packet_NetModuleLoad.parse",
        error: new Error("Unknown net module type")
      }
    };
  }
  switch (match) {
    case "Liquid":
      return parseLiquid(reader);
    case "Text":
      return parseText(reader, fromServer);
    case "Ping":
      return parsePing(reader);
    case "Ambience":
      return parseAmbience(reader);
    case "Bestiary":
      return parseBestiary(reader);
    case "CreativePower":
      return parseCreativePower(reader);
    case "CreativeUnlocksPlayerReport":
      return parseCreativeUnlocksPlayerReport(reader);
    case "TeleportPylon":
      return parseTeleportPylon(reader);
    case "Particles":
      return parseParticle(reader);
    case "CreativePowerPermissions":
      return parseCreativePowerPermission(reader);
    case "Banners":
      return parseBanners(reader);
    case "CraftingRequests":
      return parseCraftingRequests(reader, fromServer);
    case "TagEffectState":
      return parseTagEffectState(reader);
    case "LeashedEntity":
      return parseLeashedEntity(reader);
    case "UnbreakableWallScan":
      return parseUnbreakableWallScan(reader);
  }
}
var Decode2 = {
  readInt32,
  readSingle,
  readUInt16,
  readInt16,
  readString,
  readByte,
  readBool,
  readColor,
  readNetworkText,
  readBuffer,
  getBytesLeft,
  read7BitEncodedInt,
  parseLiquid,
  parseText,
  parsePing,
  parseAmbience,
  parseBestiary,
  parseCreativePower,
  parseCreativeUnlocksPlayerReport,
  parseTeleportPylon,
  parseParticle,
  parseCreativePowerPermission,
  parseBanners,
  parseCraftingRequests,
  readSparseNpcTimes,
  parseTagEffectState,
  parseLeashedEntity,
  parseUnbreakableWallScan,
  parse: parse23
};
var Buffer2;
var maxNpcIndexSentinel = 200;
var PacketV1449_NetModuleLoad_exports = {};
__export(PacketV1449_NetModuleLoad_exports, {
  NetModuleType: () => NetModuleType2,
  parse: () => parse24,
  toBuffer: () => toBuffer23
});
function pylonActionToInt2(pylonAction) {
  switch (pylonAction) {
    case "Added":
      return 0;
    case "Removed":
      return 1;
    case "RequestTeleport":
      return 2;
  }
}
function powerLevelToInt2(powerLevel) {
  switch (powerLevel) {
    case "LockedForEveryone":
      return 0;
    case "CanBeChangedByHostAlone":
      return 1;
    case "CanBeChangedByEveryone":
      return 2;
  }
}
function fromInt7(n) {
  switch (n) {
    case 0:
      return "Liquid";
    case 1:
      return "Text";
    case 2:
      return "Ping";
    case 3:
      return "Ambience";
    case 4:
      return "Bestiary";
    case 5:
      return "CreativeUnlocks";
    case 6:
      return "CreativePower";
    case 7:
      return "CreativeUnlocksPlayerReport";
    case 8:
      return "TeleportPylon";
    case 9:
      return "Particles";
    case 10:
      return "CreativePowerPermissions";
    default:
      return;
  }
}
function toInt7(self) {
  switch (self) {
    case "Liquid":
      return 0;
    case "Text":
      return 1;
    case "Ping":
      return 2;
    case "Ambience":
      return 3;
    case "Bestiary":
      return 4;
    case "CreativeUnlocks":
      return 5;
    case "CreativePower":
      return 6;
    case "CreativeUnlocksPlayerReport":
      return 7;
    case "TeleportPylon":
      return 8;
    case "Particles":
      return 9;
    case "CreativePowerPermissions":
      return 10;
  }
}
var NetModuleType2 = {
  fromInt: fromInt7,
  toInt: toInt7
};
function toBuffer23(self) {
  switch (self.TAG) {
    case "Liquid":
      let liquid = self._0;
      let writer = packUInt16(packUInt16(setType(make(), toInt("NetModuleLoad")), 0, "moduleType"), liquid.changes.length, "changesCount");
      liquid.changes.forEach((change) => {
        packByte(packByte(packInt16(packInt16(writer, change.y, "y"), change.x, "x"), change.amount, "amount"), change.liquidType, "liquidType");
      });
      return data(writer);
    case "ClientText":
      let commandId = self._0;
      let message = self._1;
      return data(packString(packString(packUInt16(setType(make(), toInt("NetModuleLoad")), 1, "moduleType"), commandId, "commandId"), message, "message"));
    case "ServerText":
      let playerId = self._0;
      let networkText = self._1;
      let color = self._2;
      return data(packColor(packNetworkText(packByte(packUInt16(setType(make(), toInt("NetModuleLoad")), 1, "moduleType"), playerId, "playerId"), networkText, "networkText"), color, "color"));
    case "Ping":
      let ping = self._0;
      return data(packSingle(packSingle(packUInt16(setType(make(), toInt("NetModuleLoad")), 2, "moduleType"), ping.x, "x"), ping.y, "y"));
    case "Ambience":
      let ambience = self._0;
      return data(packByte(packInt32(packByte(packUInt16(setType(make(), toInt("NetModuleLoad")), 3, "moduleType"), ambience.playerId, "playerId"), ambience.seed, "seed"), ambience.skyEntityType, "skyEntityType"));
    case "Bestiary":
      let bestiary = self._0;
      let writer$1 = packUInt16(setType(make(), toInt("NetModuleLoad")), 4, "moduleType");
      let _count = bestiary.unlockType;
      let tmp;
      tmp = typeof _count !== "object" ? _count === "Sight" ? packByte(writer$1, 1, "unlockTypeByte") : packByte(writer$1, 2, "unlockTypeByte") : packByte(writer$1, 0, "unlockTypeByte");
      packInt16(tmp, bestiary.npcId, "npcId");
      let count = bestiary.unlockType;
      let tmp$1;
      tmp$1 = typeof count !== "object" ? writer$1 : packUInt16(writer$1, count._0, "killCount");
      return data(tmp$1);
    case "CreativeUnlocks":
      let creativeUnlock = self._0;
      return data(packUInt16(packInt16(packUInt16(setType(make(), toInt("NetModuleLoad")), 5, "moduleType"), creativeUnlock.itemId, "itemId"), creativeUnlock.researchedCount, "researchedCount"));
    case "CreativePower":
      let creativePower = self._0;
      return data(pack$2(packUInt16(setType(make(), toInt("NetModuleLoad")), 6, "moduleType"), creativePower));
    case "CreativeUnlocksPlayerReport":
      let unlockReport = self._0;
      return data(packUInt16(packUInt16(packUInt16(setType(make(), toInt("NetModuleLoad")), 7, "moduleType"), unlockReport.itemId, "itemId"), unlockReport.researchedCount, "researchedCount"));
    case "TeleportPylon":
      let teleportPylon = self._0;
      return data(packByte(packInt16(packInt16(packByte(packUInt16(setType(make(), toInt("NetModuleLoad")), 8, "moduleType"), pylonActionToInt2(teleportPylon.pylonAction), "pylonAction"), teleportPylon.x, "x"), teleportPylon.y, "y"), teleportPylon.pylonType, "pylonType"));
    case "Particles":
      let particle = self._0;
      return data(packByte(packInt32(packSingle(packSingle(packSingle(packSingle(packByte(packUInt16(setType(make(), toInt("NetModuleLoad")), 9, "moduleType"), particle.particleType, "particleType"), particle.x, "x"), particle.y, "y"), particle.vx, "vx"), particle.vy, "vy"), particle.shaderIndex, "shaderIndex"), particle.invokedByPlayer, "invokedByPlayer"));
    case "CreativePowerPermissions":
      let creativePowerPermission = self._0;
      return data(packByte(packByte(packUInt16(setType(make(), toInt("NetModuleLoad")), 10, "moduleType"), creativePowerPermission.powerType, "powerType"), powerLevelToInt2(creativePowerPermission.powerLevel), "powerLevel"));
  }
}
function parse24(payload, fromServer) {
  let reader = new packetreader_default(payload);
  let e = readUInt16(reader, "moduleType");
  if (e.TAG !== "Ok") {
    return e;
  }
  let match = fromInt7(e._0);
  if (match === void 0) {
    return {
      TAG: "Error",
      _0: {
        context: "PacketV1449_NetModuleLoad.parse",
        error: new Error("Unknown net module type")
      }
    };
  }
  switch (match) {
    case "Liquid":
      let e$1 = readUInt16(reader, "changesCount");
      if (e$1.TAG !== "Ok") {
        return e$1;
      }
      let changesCount = e$1._0;
      let readChanges = (_idx, _acc) => {
        while (true) {
          let acc = _acc;
          let idx = _idx;
          if (idx >= changesCount) {
            return {
              TAG: "Ok",
              _0: acc.toReversed()
            };
          }
          let e2 = readInt16(reader, "y");
          if (e2.TAG !== "Ok") {
            return e2;
          }
          let e$16 = readInt16(reader, "x");
          if (e$16.TAG !== "Ok") {
            return e$16;
          }
          let e$210 = readByte(reader, "amount");
          if (e$210.TAG !== "Ok") {
            return e$210;
          }
          let e$3 = readByte(reader, "liquidType");
          if (e$3.TAG !== "Ok") {
            return e$3;
          }
          _acc = concatMany([
            [{
              x: e$16._0,
              y: e2._0,
              amount: e$210._0,
              liquidType: e$3._0
            }],
            acc
          ]);
          _idx = idx + 1 | 0;
          continue;
        }
        ;
      };
      let e$2 = readChanges(0, []);
      if (e$2.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "Liquid",
            _0: {
              changes: e$2._0
            }
          }
        };
      } else {
        return e$2;
      }
    case "Text":
      if (fromServer) {
        let e$3 = readByte(reader, "playerId");
        if (e$3.TAG !== "Ok") {
          return e$3;
        }
        let e$4 = readNetworkText(reader, "message");
        if (e$4.TAG !== "Ok") {
          return e$4;
        }
        let e$5 = readColor(reader, "color");
        if (e$5.TAG === "Ok") {
          return {
            TAG: "Ok",
            _0: {
              TAG: "ServerText",
              _0: e$3._0,
              _1: e$4._0,
              _2: e$5._0
            }
          };
        } else {
          return e$5;
        }
      }
      let e$6 = readString(reader, "commandId");
      if (e$6.TAG !== "Ok") {
        return e$6;
      }
      let e$7 = readString(reader, "message");
      if (e$7.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "ClientText",
            _0: e$6._0,
            _1: e$7._0
          }
        };
      } else {
        return e$7;
      }
    case "Ping":
      let e$8 = readSingle(reader, "x");
      if (e$8.TAG !== "Ok") {
        return e$8;
      }
      let e$9 = readSingle(reader, "y");
      if (e$9.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "Ping",
            _0: {
              x: e$8._0,
              y: e$9._0
            }
          }
        };
      } else {
        return e$9;
      }
    case "Ambience":
      let e$10 = readByte(reader, "playerId");
      if (e$10.TAG !== "Ok") {
        return e$10;
      }
      let e$11 = readInt32(reader, "seed");
      if (e$11.TAG !== "Ok") {
        return e$11;
      }
      let e$12 = readByte(reader, "skyEntityType");
      if (e$12.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "Ambience",
            _0: {
              playerId: e$10._0,
              seed: e$11._0,
              skyEntityType: e$12._0
            }
          }
        };
      } else {
        return e$12;
      }
    case "Bestiary":
      let e$13 = readByte(reader, "rawBestiaryUnlockType");
      if (e$13.TAG !== "Ok") {
        return e$13;
      }
      let e$14 = readInt16(reader, "npcId");
      if (e$14.TAG !== "Ok") {
        return e$14;
      }
      let e$15;
      switch (e$13._0) {
        case 0:
          let e$16 = readUInt16(reader, "killCount");
          e$15 = e$16.TAG === "Ok" ? {
            TAG: "Ok",
            _0: {
              TAG: "Kill",
              _0: e$16._0
            }
          } : e$16;
          break;
        case 1:
          e$15 = {
            TAG: "Ok",
            _0: "Sight"
          };
          break;
        case 2:
          e$15 = {
            TAG: "Ok",
            _0: "Chat"
          };
          break;
        default:
          e$15 = {
            TAG: "Error",
            _0: {
              context: "PacketV1449_NetModuleLoad.parseBestiary",
              error: new Error("Unknown bestiary unlock type")
            }
          };
      }
      if (e$15.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "Bestiary",
            _0: {
              unlockType: e$15._0,
              npcId: e$14._0
            }
          }
        };
      } else {
        return e$15;
      }
    case "CreativeUnlocks":
      let e$17 = readInt16(reader, "itemId");
      if (e$17.TAG !== "Ok") {
        return e$17;
      }
      let e$18 = readUInt16(reader, "researchedCount");
      if (e$18.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "CreativeUnlocks",
            _0: {
              itemId: e$17._0,
              researchedCount: e$18._0
            }
          }
        };
      } else {
        return e$18;
      }
    case "CreativePower":
      let p = parse$2(reader);
      if (p !== void 0) {
        return {
          TAG: "Ok",
          _0: {
            TAG: "CreativePower",
            _0: p
          }
        };
      } else {
        return {
          TAG: "Error",
          _0: {
            context: "PacketV1449_NetModuleLoad.parseCreativePower",
            error: new Error("Failed to parse creative power")
          }
        };
      }
    case "CreativeUnlocksPlayerReport":
      let e$19 = readByte(reader, "unknownByte");
      if (e$19.TAG !== "Ok") {
        return e$19;
      }
      let e$20 = readUInt16(reader, "itemId");
      if (e$20.TAG !== "Ok") {
        return e$20;
      }
      let e$21 = readUInt16(reader, "researchedCount");
      if (e$21.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "CreativeUnlocksPlayerReport",
            _0: {
              itemId: e$20._0,
              researchedCount: e$21._0
            }
          }
        };
      } else {
        return e$21;
      }
    case "TeleportPylon":
      let e$22 = readByte(reader, "rawPylonAction");
      if (e$22.TAG !== "Ok") {
        return e$22;
      }
      let e$23 = readInt16(reader, "x");
      if (e$23.TAG !== "Ok") {
        return e$23;
      }
      let e$24 = readInt16(reader, "y");
      if (e$24.TAG !== "Ok") {
        return e$24;
      }
      let e$25 = readByte(reader, "pylonType");
      if (e$25.TAG !== "Ok") {
        return e$25;
      }
      let pylonAction;
      switch (e$22._0) {
        case 0:
          pylonAction = "Added";
          break;
        case 1:
          pylonAction = "Removed";
          break;
        case 2:
          pylonAction = "RequestTeleport";
          break;
        default:
          pylonAction = void 0;
      }
      if (pylonAction !== void 0) {
        return {
          TAG: "Ok",
          _0: {
            TAG: "TeleportPylon",
            _0: {
              pylonAction,
              x: e$23._0,
              y: e$24._0,
              pylonType: e$25._0
            }
          }
        };
      } else {
        return {
          TAG: "Error",
          _0: {
            context: "PacketV1449_NetModuleLoad.parseTeleportPylon",
            error: new Error("Unknown pylon action")
          }
        };
      }
    case "Particles":
      let e$26 = readByte(reader, "particleType");
      if (e$26.TAG !== "Ok") {
        return e$26;
      }
      let e$27 = readSingle(reader, "x");
      if (e$27.TAG !== "Ok") {
        return e$27;
      }
      let e$28 = readSingle(reader, "y");
      if (e$28.TAG !== "Ok") {
        return e$28;
      }
      let e$29 = readSingle(reader, "vx");
      if (e$29.TAG !== "Ok") {
        return e$29;
      }
      let e$30 = readSingle(reader, "vy");
      if (e$30.TAG !== "Ok") {
        return e$30;
      }
      let e$31 = readInt32(reader, "shaderIndex");
      if (e$31.TAG !== "Ok") {
        return e$31;
      }
      let e$32 = readByte(reader, "invokedByPlayer");
      if (e$32.TAG === "Ok") {
        return {
          TAG: "Ok",
          _0: {
            TAG: "Particles",
            _0: {
              particleType: e$26._0,
              x: e$27._0,
              y: e$28._0,
              vx: e$29._0,
              vy: e$30._0,
              shaderIndex: e$31._0,
              invokedByPlayer: e$32._0
            }
          }
        };
      } else {
        return e$32;
      }
    case "CreativePowerPermissions":
      let e$33 = readByte(reader, "unknownByte");
      if (e$33.TAG !== "Ok") {
        return e$33;
      }
      let e$34 = readUInt16(reader, "powerType");
      if (e$34.TAG !== "Ok") {
        return e$34;
      }
      let e$35 = readByte(reader, "rawPowerLevel");
      if (e$35.TAG !== "Ok") {
        return e$35;
      }
      let powerLevel;
      switch (e$35._0) {
        case 0:
          powerLevel = "LockedForEveryone";
          break;
        case 1:
          powerLevel = "CanBeChangedByHostAlone";
          break;
        case 2:
          powerLevel = "CanBeChangedByEveryone";
          break;
        default:
          powerLevel = void 0;
      }
      if (powerLevel !== void 0) {
        return {
          TAG: "Ok",
          _0: {
            TAG: "CreativePowerPermissions",
            _0: {
              powerType: e$34._0,
              powerLevel
            }
          }
        };
      } else {
        return {
          TAG: "Error",
          _0: {
            context: "PacketV1449_NetModuleLoad.parseCreativePowerPermission",
            error: new Error("Unknown creative power permission level")
          }
        };
      }
  }
}
var PacketV1449_NpcBuffRemovalRequest_exports = {};
__export(PacketV1449_NpcBuffRemovalRequest_exports, {
  parse: () => parse25,
  toBuffer: () => toBuffer24
});
function parse25(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "npcId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readUInt16(reader, "buffType");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcId: e._0,
        buffType: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer24(self) {
  return data(packUInt16(packInt16(setType(make(), toInt("NpcBuffRemovalRequest")), self.npcId, "npcId"), self.buffType, "buffType"));
}
var Packet_NpcBuffUpdate_exports = {};
__export(Packet_NpcBuffUpdate_exports, {
  Decode: () => Decode3,
  Encode: () => Encode3,
  parse: () => parse26,
  toBuffer: () => toBuffer25
});
function parse26(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "npcId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let buffs = [];
  let buffTimes = [];
  let readBuffs = () => {
    while (true) {
      let e2 = readUInt16(reader, "buff");
      if (e2.TAG !== "Ok") {
        return e2;
      }
      let buff = e2._0;
      if (buff === 0) {
        return {
          TAG: "Ok",
          _0: void 0
        };
      }
      let e$12 = readUInt16(reader, "buffTime");
      if (e$12.TAG !== "Ok") {
        return e$12;
      }
      buffs.push(buff);
      buffTimes.push(e$12._0);
      continue;
    }
    ;
  };
  let e$1 = readBuffs();
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcId: e._0,
        buffs,
        buffTimes
      }
    };
  } else {
    return e$1;
  }
}
var Decode3 = {
  readUInt16,
  readInt16,
  parse: parse26
};
function packBuffs(writer, buffs, buffTimes) {
  let len = min(buffs.length, buffTimes.length);
  for (let i = 0; i < len; ++i) {
    packUInt16(writer, buffs[i], `buff` + i.toString());
    packUInt16(writer, buffTimes[i], `buffTime` + i.toString());
  }
  return packUInt16(writer, 0, "buff_terminator");
}
function toBuffer25(self) {
  if (self.buffs.length !== self.buffTimes.length) {
    return {
      TAG: "Error",
      _0: {
        context: "Packet_NpcBuffUpdate.toBuffer",
        error: new Error("Expected buffs and buffTimes to be same length")
      }
    };
  } else {
    return data(packBuffs(packInt16(setType(make(), toInt("NpcBuffUpdate")), self.npcId, "npcId"), self.buffs, self.buffTimes));
  }
}
var Encode3 = {
  packInt16,
  packUInt16,
  setType,
  data,
  packBuffs,
  toBuffer: toBuffer25
};
var PacketV1449_NpcCatch_exports = {};
__export(PacketV1449_NpcCatch_exports, {
  parse: () => parse27,
  toBuffer: () => toBuffer26
});
function parse27(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "npcId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "playerId");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcId: e._0,
        playerId: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer26(self) {
  return data(packByte(packInt16(setType(make(), toInt("NpcCatch")), self.npcId, "npcId"), self.playerId, "playerId"));
}
var PacketV1449_NpcFishOut_exports = {};
__export(PacketV1449_NpcFishOut_exports, {
  parse: () => parse28,
  toBuffer: () => toBuffer27
});
function parse28(payload) {
  let reader = new packetreader_default(payload);
  let e = readUInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readUInt16(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "npcNetId");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        npcNetId: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function toBuffer27(self) {
  return data(packInt16(packUInt16(packUInt16(setType(make(), toInt("NpcFishOut")), self.x, "x"), self.y, "y"), self.npcNetId, "npcNetId"));
}
var PacketV1449_NpcHomeUpdate_exports = {};
__export(PacketV1449_NpcHomeUpdate_exports, {
  parse: () => parse29,
  toBuffer: () => toBuffer28
});
function parse29(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "npcId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "homeTileX");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "homeTileY");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "state");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcId: e._0,
        homeTileX: e$1._0,
        homeTileY: e$2._0,
        state: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function toBuffer28(self) {
  return data(packByte(packInt16(packInt16(packInt16(setType(make(), toInt("NpcHomeUpdate")), self.npcId, "npcId"), self.homeTileX, "homeTileX"), self.homeTileY, "homeTileY"), self.state, "state"));
}
var PacketV1449_NpcKillCount_exports = {};
__export(PacketV1449_NpcKillCount_exports, {
  parse: () => parse30,
  toBuffer: () => toBuffer29
});
function parse30(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "npcId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "killCount");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcId: e._0,
        killCount: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer29(self) {
  return data(packInt32(packInt16(setType(make(), toInt("NpcKillCount")), self.npcId, "npcId"), self.killCount, "killCount"));
}
var PacketV1449_NpcNameUpdate_exports = {};
__export(PacketV1449_NpcNameUpdate_exports, {
  parse: () => parse31,
  toBuffer: () => toBuffer30
});
function parse31(payload, fromServer) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "npcId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1;
  if (fromServer) {
    let e$2 = readString(reader, "name");
    if (e$2.TAG === "Ok") {
      let e$3 = readInt32(reader, "townNpcVariationIndex");
      e$1 = e$3.TAG === "Ok" ? {
        TAG: "Ok",
        _0: {
          name: e$2._0,
          townNpcVariationIndex: e$3._0
        }
      } : e$3;
    } else {
      e$1 = e$2;
    }
  } else {
    e$1 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcId: e._0,
        extraInfo: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer30(self) {
  let writer = packInt16(setType(make(), toInt("NpcNameUpdate")), self.npcId, "npcId");
  let extraInfo = self.extraInfo;
  if (extraInfo !== void 0) {
    return data(packInt32(packString(writer, extraInfo.name, "name"), extraInfo.townNpcVariationIndex, "townNpcVariationIndex"));
  } else {
    return data(writer);
  }
}
var PacketV1449_NpcShopItem_exports = {};
__export(PacketV1449_NpcShopItem_exports, {
  parse: () => parse32,
  toBuffer: () => toBuffer31
});
function parse32(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "slot");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "itemId");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "stack");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "prefix");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt32(reader, "value");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readByte(reader, "flags");
  if (e$5.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        slot: e._0,
        itemId: e$1._0,
        stack: e$2._0,
        prefix: e$3._0,
        value: e$4._0,
        buyOnce: flag1(fromByte(e$5._0))
      }
    };
  } else {
    return e$5;
  }
}
function toBuffer31(self) {
  let flags = fromFlags(self.buyOnce, false, false, false, false, false, false, false);
  return data(packByte(packInt32(packByte(packInt16(packInt16(packByte(setType(make(), toInt("NpcShopItem")), self.slot, "slot"), self.itemId, "itemId"), self.stack, "stack"), self.prefix, "prefix"), self.value, "value"), toByte(flags), "flags"));
}
var PacketV1449_NpcTalk_exports = {};
__export(PacketV1449_NpcTalk_exports, {
  parse: () => parse33,
  toBuffer: () => toBuffer32
});
function parse33(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "npcId");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        npcId: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer32(self) {
  return data(packInt16(packByte(setType(make(), toInt("NpcTalk")), self.playerId, "playerId"), self.npcId, "npcId"));
}
var PacketV1449_NpcTeleportPortal_exports = {};
__export(PacketV1449_NpcTeleportPortal_exports, {
  parse: () => parse34,
  toBuffer: () => toBuffer33
});
function parse34(payload) {
  let reader = new packetreader_default(payload);
  let e = readUInt16(reader, "npcId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "portalColor");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "posX");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "posY");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readSingle(reader, "velX");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readSingle(reader, "velY");
  if (e$5.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcId: e._0,
        portalColor: e$1._0,
        position: {
          x: e$2._0,
          y: e$3._0
        },
        velocity: {
          x: e$4._0,
          y: e$5._0
        }
      }
    };
  } else {
    return e$5;
  }
}
function toBuffer33(self) {
  return data(packSingle(packSingle(packSingle(packSingle(packInt16(packUInt16(setType(make(), toInt("NpcTeleportPortal")), self.npcId, "npcId"), self.portalColor, "portalColor"), self.position.x, "posX"), self.position.y, "posY"), self.velocity.x, "velX"), self.velocity.y, "velY"));
}
var PacketV1449_ObjectPlace_exports = {};
__export(PacketV1449_ObjectPlace_exports, {
  parse: () => parse35,
  toBuffer: () => toBuffer34
});
function parse35(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "objectType");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt16(reader, "style");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readByte(reader, "alternate");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readSByte(reader, "random");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readByte(reader, "direction");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let directionRaw = e$6._0;
  let direction = directionRaw !== 0 ? directionRaw !== 1 ? {
    TAG: "Error",
    _0: {
      context: "ObjectPlace.parse.direction",
      error: new Error("Unknown direction")
    }
  } : {
    TAG: "Ok",
    _0: "Right"
  } : {
    TAG: "Ok",
    _0: "Left"
  };
  if (direction.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        objectType: e$2._0,
        style: e$3._0,
        alternate: e$4._0,
        random: e$5._0,
        direction: direction._0
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: direction._0
    };
  }
}
function toBuffer34(self) {
  let match = self.direction;
  let tmp;
  tmp = match === "Left" ? 0 : 1;
  return data(packByte(packSByte(packByte(packInt16(packInt16(packInt16(packInt16(setType(make(), toInt("ObjectPlace")), self.x, "x"), self.y, "y"), self.objectType, "objectType"), self.style, "style"), self.alternate, "alternate"), self.random, "random"), tmp, "direction"));
}
var PacketV1449_PartyToggle_exports = {};
__export(PacketV1449_PartyToggle_exports, {
  parse: () => parse36,
  toBuffer: () => toBuffer35
});
function parse36(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
function toBuffer35(_self) {
  return data(setType(make(), toInt("PartyToggle")));
}
var PacketV1449_PlayerAnimation_exports = {};
__export(PacketV1449_PlayerAnimation_exports, {
  parse: () => parse37,
  toBuffer: () => toBuffer36
});
function parse37(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "itemRotation");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "itemAnimation");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        itemRotation: e$1._0,
        itemAnimation: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function toBuffer36(self) {
  return data(packInt16(packSingle(packByte(setType(make(), toInt("PlayerAnimation")), self.playerId, "playerId"), self.itemRotation, "itemRotation"), self.itemAnimation, "itemAnimation"));
}
var PacketV1449_PlayerBuffAdd_exports = {};
__export(PacketV1449_PlayerBuffAdd_exports, {
  parse: () => parse38,
  toBuffer: () => toBuffer37
});
function parse38(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readUInt16(reader, "buff");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt32(reader, "time");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        buff: e$1._0,
        time: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function toBuffer37(self) {
  return data(packInt32(packUInt16(packByte(setType(make(), toInt("PlayerBuffAdd")), self.playerId, "playerId"), self.buff, "buff"), self.time, "time"));
}
var Packet_PlayerBuffsSet_exports = {};
__export(Packet_PlayerBuffsSet_exports, {
  Decode: () => Decode4,
  Encode: () => Encode4,
  parse: () => parse39,
  toBuffer: () => toBuffer38
});
function parse39(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let buffs = [];
  let readBuffs = () => {
    while (true) {
      let e2 = readUInt16(reader, "buff");
      if (e2.TAG !== "Ok") {
        return e2;
      }
      let buff = e2._0;
      if (buff === 0) {
        return {
          TAG: "Ok",
          _0: void 0
        };
      }
      buffs.push(buff);
      continue;
    }
    ;
  };
  let e$1 = readBuffs();
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        buffs
      }
    };
  } else {
    return e$1;
  }
}
var Decode4 = {
  readUInt16,
  readByte,
  parse: parse39
};
function packBuffs2(writer, buffs) {
  buffs.forEach((buff, idx) => {
    packUInt16(writer, buff, `buff_` + idx.toString());
  });
  return packUInt16(writer, 0, "buff_terminator");
}
function toBuffer38(self) {
  return data(packBuffs2(packByte(setType(make(), toInt("PlayerBuffsSet")), self.playerId, "playerId"), self.buffs));
}
var Encode4 = {
  packByte,
  packUInt16,
  setType,
  data,
  packBuffs: packBuffs2,
  toBuffer: toBuffer38
};
var PacketV1449_PlayerChestIndexSync_exports = {};
__export(PacketV1449_PlayerChestIndexSync_exports, {
  parse: () => parse40,
  toBuffer: () => toBuffer39
});
function parse40(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "chestId");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        chestId: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer39(self) {
  return data(packInt16(packByte(setType(make(), toInt("PlayerChestIndexSync")), self.playerId, "playerId"), self.chestId, "chestId"));
}
var PacketV1449_PlayerDead_exports = {};
__export(PacketV1449_PlayerDead_exports, {
  parse: () => parse41,
  toBuffer: () => toBuffer40
});
function parse41(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0
      }
    };
  } else {
    return e;
  }
}
function toBuffer40(self) {
  return data(packByte(setType(make(), toInt("PlayerDead")), self.playerId, "playerId"));
}
var PacketV1449_PlayerDeath_exports = {};
__export(PacketV1449_PlayerDeath_exports, {
  parse: () => parse42,
  toBuffer: () => toBuffer41
});
var PlayerDeathReason_exports = {};
__export(PlayerDeathReason_exports, {
  packDeathReason: () => packDeathReason,
  readDeathReason: () => readDeathReason
});
function otherFromByte(byte) {
  switch (byte) {
    case 0:
      return "FallDamage";
    case 1:
      return "Drowning";
    case 2:
      return "Lava";
    case 3:
      return "FallDamage2";
    case 4:
      return "DemonAltar";
    case 5:
      return "CompanionCube";
    case 6:
      return "Suffocation";
    case 7:
      return "Burning";
    case 8:
      return "Poison";
    case 9:
      return "Electrified";
    case 10:
      return "WallOfFleshEscape";
    case 11:
      return "WallOfFleshLicked";
    case 12:
      return "ChaosState";
    case 13:
      return "ChaosState2Male";
    case 14:
      return "ChaosState3Female";
    default:
      return;
  }
}
function otherToByte(other) {
  switch (other) {
    case "FallDamage":
      return 0;
    case "Drowning":
      return 1;
    case "Lava":
      return 2;
    case "FallDamage2":
      return 3;
    case "DemonAltar":
      return 4;
    case "CompanionCube":
      return 5;
    case "Suffocation":
      return 6;
    case "Burning":
      return 7;
    case "Poison":
      return 8;
    case "Electrified":
      return 9;
    case "WallOfFleshEscape":
      return 10;
    case "WallOfFleshLicked":
      return 11;
    case "ChaosState":
      return 12;
    case "ChaosState2Male":
      return 13;
    case "ChaosState3Female":
      return 14;
  }
}
function readDeathReason(reader) {
  let e = readByte(reader, "reasonType");
  if (e.TAG !== "Ok") {
    return e;
  }
  let reasonType = fromByte(e._0);
  let e$1;
  if (flag1(reasonType)) {
    let e$2 = readInt16(reader, "killerPlayerId");
    e$1 = e$2.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$2._0
    } : e$2;
  } else {
    e$1 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$3;
  if (flag2(reasonType)) {
    let e$4 = readInt16(reader, "killerNpcId");
    e$3 = e$4.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$4._0
    } : e$4;
  } else {
    e$3 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$5;
  if (flag3(reasonType)) {
    let e$6 = readInt16(reader, "killerProjectileId");
    e$5 = e$6.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$6._0
    } : e$6;
  } else {
    e$5 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$7;
  if (flag4(reasonType)) {
    let e$8 = readByte(reader, "typeOfDeathOther");
    e$7 = e$8.TAG === "Ok" ? {
      TAG: "Ok",
      _0: otherFromByte(e$8._0)
    } : e$8;
  } else {
    e$7 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let e$9;
  if (flag5(reasonType)) {
    let e$10 = readInt16(reader, "projectileType");
    e$9 = e$10.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$10._0
    } : e$10;
  } else {
    e$9 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$9.TAG !== "Ok") {
    return e$9;
  }
  let e$11;
  if (flag6(reasonType)) {
    let e$12 = readInt16(reader, "itemType");
    e$11 = e$12.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$12._0
    } : e$12;
  } else {
    e$11 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$11.TAG !== "Ok") {
    return e$11;
  }
  let e$13;
  if (flag7(reasonType)) {
    let e$14 = readByte(reader, "itemPrefix");
    e$13 = e$14.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$14._0
    } : e$14;
  } else {
    e$13 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$13.TAG !== "Ok") {
    return e$13;
  }
  let e$15;
  if (flag8(reasonType)) {
    let e$16 = readString(reader, "deathReason");
    e$15 = e$16.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$16._0
    } : e$16;
  } else {
    e$15 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$15.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        killerPlayerId: e$1._0,
        killerNpcId: e$3._0,
        killerProjectileId: e$5._0,
        typeOfDeathOther: e$7._0,
        projectileType: e$9._0,
        itemType: e$11._0,
        itemPrefix: e$13._0,
        deathReason: e$15._0
      }
    };
  } else {
    return e$15;
  }
}
function packFlags(writer, self) {
  let flags = fromFlags(isSome(self.killerPlayerId), isSome(self.killerNpcId), isSome(self.killerProjectileId), isSome(self.typeOfDeathOther), isSome(self.projectileType), isSome(self.itemType), isSome(self.itemPrefix), isSome(self.deathReason));
  return packByte(writer, toByte(flags), "reasonType");
}
function packKillerPlayerId(writer, self) {
  let killerPlayerId = self.killerPlayerId;
  if (killerPlayerId !== void 0) {
    return packInt16(writer, killerPlayerId, "killerPlayerId");
  } else {
    return writer;
  }
}
function packKillerNpcId(writer, self) {
  let killerNpcId = self.killerNpcId;
  if (killerNpcId !== void 0) {
    return packInt16(writer, killerNpcId, "killerNpcId");
  } else {
    return writer;
  }
}
function packKillerProjectileId(writer, self) {
  let killerProjectileId = self.killerProjectileId;
  if (killerProjectileId !== void 0) {
    return packInt16(writer, killerProjectileId, "killerProjectileId");
  } else {
    return writer;
  }
}
function packTypeOfDeathOther(writer, self) {
  let typeOfDeathOther = self.typeOfDeathOther;
  if (typeOfDeathOther !== void 0) {
    return packByte(writer, otherToByte(typeOfDeathOther), "typeOfDeathOther");
  } else {
    return writer;
  }
}
function packProjectileType(writer, self) {
  let projectileType = self.projectileType;
  if (projectileType !== void 0) {
    return packInt16(writer, projectileType, "projectileType");
  } else {
    return writer;
  }
}
function packItemType(writer, self) {
  let itemType = self.itemType;
  if (itemType !== void 0) {
    return packInt16(writer, itemType, "itemType");
  } else {
    return writer;
  }
}
function packItemPrefix(writer, self) {
  let itemPrefix = self.itemPrefix;
  if (itemPrefix !== void 0) {
    return packByte(writer, itemPrefix, "itemPrefix");
  } else {
    return writer;
  }
}
function pack2(writer, self) {
  let writer$1 = packItemPrefix(packItemType(packProjectileType(packTypeOfDeathOther(packKillerProjectileId(packKillerNpcId(packKillerPlayerId(packFlags(writer, self), self), self), self), self), self), self), self);
  let deathReason = self.deathReason;
  if (deathReason !== void 0) {
    return packString(writer$1, deathReason, "deathReason");
  } else {
    return writer$1;
  }
}
var packDeathReason = pack2;
function parse42(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readDeathReason(reader);
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "damage");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "hitDirection");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readByte(reader, "pvp");
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        deathReason: e$1._0,
        damage: e$2._0,
        hitDirection: e$3._0,
        pvp: e$4._0 === 1
      }
    };
  } else {
    return e$4;
  }
}
function toBuffer41(self) {
  return data(packByte(packByte(packInt16(packDeathReason(packByte(setType(make(), toInt("PlayerDeath")), self.playerId, "playerId"), self.deathReason), self.damage, "damage"), self.hitDirection, "hitDirection"), self.pvp ? 1 : 0, "pvp"));
}
var PacketV1449_PlayerDodge_exports = {};
__export(PacketV1449_PlayerDodge_exports, {
  parse: () => parse43,
  toBuffer: () => toBuffer42
});
function dodgeFromByte(b) {
  switch (b) {
    case 1:
      return "Ninja";
    case 2:
      return "Shadow";
    case 4:
      return "BrainOfConfusion";
    default:
      return;
  }
}
function dodgeToByte(d) {
  switch (d) {
    case "Ninja":
      return 1;
    case "Shadow":
      return 2;
    case "BrainOfConfusion":
      return 4;
  }
}
function parse43(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "dodge");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let dodge = dodgeFromByte(e$1._0);
  let dodge$1 = dodge !== void 0 ? {
    TAG: "Ok",
    _0: dodge
  } : {
    TAG: "Error",
    _0: {
      context: "Packet_PlayerDodge.parse.dodge",
      error: new Error("Unknown dodge type")
    }
  };
  if (dodge$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        dodge: dodge$1._0
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: dodge$1._0
    };
  }
}
function toBuffer42(self) {
  return data(packByte(packByte(setType(make(), toInt("PlayerDodge")), self.playerId, "playerId"), dodgeToByte(self.dodge), "dodge"));
}
var PacketV1449_PlayerMana_exports = {};
__export(PacketV1449_PlayerMana_exports, {
  parse: () => parse44,
  toBuffer: () => toBuffer43
});
function parse44(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "mana");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "maxMana");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        mana: e$1._0,
        maxMana: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function toBuffer43(self) {
  return data(packInt16(packInt16(packByte(setType(make(), toInt("PlayerMana")), self.playerId, "playerId"), self.mana, "mana"), self.maxMana, "maxMana"));
}
var PacketV1449_PlayerTeam_exports = {};
__export(PacketV1449_PlayerTeam_exports, {
  parse: () => parse45,
  toBuffer: () => toBuffer44
});
function parse45(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "team");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        team: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer44(self) {
  return data(packByte(packByte(setType(make(), toInt("PlayerTeam")), self.playerId, "playerId"), self.team, "team"));
}
var PacketV1449_PvpToggle_exports = {};
__export(PacketV1449_PvpToggle_exports, {
  parse: () => parse46,
  toBuffer: () => toBuffer45
});
function parse46(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "pvpEnabled");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        pvpEnabled: e$1._0 === 1
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer45(self) {
  return data(packByte(packByte(setType(make(), toInt("PvpToggle")), self.playerId, "playerId"), self.pvpEnabled ? 1 : 0, "pvpEnabled"));
}
var Packet_ShimmerEffectOrCoinLuck_exports = {};
__export(Packet_ShimmerEffectOrCoinLuck_exports, {
  Decode: () => Decode5,
  Encode: () => Encode5,
  parse: () => parse47,
  toBuffer: () => toBuffer46
});
function parse47(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "kind");
  if (e.TAG !== "Ok") {
    return e;
  }
  let kind = e._0;
  if (kind !== 0) {
    if (kind !== 1) {
      return {
        TAG: "Error",
        _0: {
          context: "Packet_ShimmerEffectOrCoinLuck.parse",
          error: new Error("Unknown shimmer effect kind")
        }
      };
    }
    let e$1 = readSingle(reader, "coinLuckX");
    if (e$1.TAG !== "Ok") {
      return e$1;
    }
    let e$2 = readSingle(reader, "coinLuckY");
    if (e$2.TAG !== "Ok") {
      return e$2;
    }
    let e$3 = readInt32(reader, "coinLuckAmount");
    if (e$3.TAG === "Ok") {
      return {
        TAG: "Ok",
        _0: {
          TAG: "CoinLuck",
          _0: {
            position: {
              x: e$1._0,
              y: e$2._0
            },
            amount: e$3._0
          }
        }
      };
    } else {
      return e$3;
    }
  }
  let e$4 = readSingle(reader, "shimmerX");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readSingle(reader, "shimmerY");
  if (e$5.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        TAG: "ShimmerEffect",
        _0: e$4._0,
        _1: e$5._0
      }
    };
  } else {
    return e$5;
  }
}
var Decode5 = {
  readByte,
  readInt32,
  readSingle,
  parse: parse47
};
function toBuffer46(self) {
  let writer = setType(make(), toInt("ShimmerEffectOrCoinLuck"));
  let tmp;
  if (self.TAG === "ShimmerEffect") {
    tmp = packSingle(packSingle(packByte(writer, 0, "kind"), self._0, "shimmerX"), self._1, "shimmerY");
  } else {
    let match = self._0;
    let position = match.position;
    tmp = packInt32(packSingle(packSingle(packByte(writer, 1, "kind"), position.x, "coinLuckX"), position.y, "coinLuckY"), match.amount, "coinLuckAmount");
  }
  return data(tmp);
}
var Encode5 = {
  Writer: void 0,
  packByte,
  packInt32,
  packSingle,
  setType,
  data,
  toBuffer: toBuffer46
};
var PacketV1449_SignNew_exports = {};
__export(PacketV1449_SignNew_exports, {
  parse: () => parse48,
  toBuffer: () => toBuffer47
});
function parse48(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "signId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readString(reader, "text");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readByte(reader, "playerId");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readByte(reader, "flags");
  if (e$5.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        signId: e._0,
        x: e$1._0,
        y: e$2._0,
        text: e$3._0,
        playerId: e$4._0,
        deleteSign: flag1(fromByte(e$5._0))
      }
    };
  } else {
    return e$5;
  }
}
function toBuffer47(self) {
  let flags = fromFlags(self.deleteSign, false, false, false, false, false, false, false);
  return data(packByte(packByte(packString(packInt16(packInt16(packInt16(setType(make(), toInt("SignNew")), self.signId, "signId"), self.x, "x"), self.y, "y"), self.text, "text"), self.playerId, "playerId"), toByte(flags), "flags"));
}
var PacketV1449_SignRead_exports = {};
__export(PacketV1449_SignRead_exports, {
  parse: () => parse49,
  toBuffer: () => toBuffer48
});
function parse49(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer48(self) {
  return data(packInt16(packInt16(setType(make(), toInt("SignRead")), self.x, "x"), self.y, "y"));
}
var PacketV1449_SmokePoof_exports = {};
__export(PacketV1449_SmokePoof_exports, {
  parse: () => parse50,
  toBuffer: () => toBuffer49
});
function parse50(payload) {
  let reader = new packetreader_default(payload);
  let e = readUInt32(reader, "packedPosition");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        packedPosition: e._0
      }
    };
  } else {
    return e;
  }
}
function toBuffer49(self) {
  return data(packUInt32(setType(make(), toInt("SmokePoof")), self.packedPosition, "packedPosition"));
}
var PacketV1449_SocialHandshake_exports = {};
__export(PacketV1449_SocialHandshake_exports, {
  parse: () => parse51,
  toBuffer: () => toBuffer50
});
function parse51(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
function toBuffer50(_self) {
  return data(setType(make(), toInt("SocialHandshake")));
}
var PacketV1449_Status_exports = {};
__export(PacketV1449_Status_exports, {
  parse: () => parse52,
  toBuffer: () => toBuffer51
});
function parse52(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt32(reader, "max");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readNetworkText(reader, "text");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "flags");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let flags = fromByte(e$2._0);
  return {
    TAG: "Ok",
    _0: {
      max: e._0,
      text: e$1._0,
      flags: {
        hideStatusTextPercent: flag1(flags),
        statusTextHasShadows: flag2(flags),
        runCheckBytes: flag3(flags)
      }
    }
  };
}
function flagsToByte(flags) {
  let byte = 0;
  byte = byte | (flags.hideStatusTextPercent ? 1 : 0);
  byte = byte | (flags.statusTextHasShadows ? 2 : 0);
  byte = byte | (flags.runCheckBytes ? 4 : 0);
  return byte;
}
function toBuffer51(self) {
  return data(packByte(packNetworkText(packInt32(setType(make(), toInt("Status")), self.max, "max"), self.text, "text"), flagsToByte(self.flags), "flags"));
}
var PacketV1449_SwitchHit_exports = {};
__export(PacketV1449_SwitchHit_exports, {
  parse: () => parse53,
  toBuffer: () => toBuffer52
});
function parse53(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer52(self) {
  return data(packInt16(packInt16(setType(make(), toInt("SwitchHit")), self.x, "x"), self.y, "y"));
}
var Packet_Teleport_exports = {};
__export(Packet_Teleport_exports, {
  Decode: () => Decode6,
  Encode: () => Encode6,
  parse: () => parse54,
  toBuffer: () => toBuffer53
});
function parse54(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "flags");
  if (e.TAG !== "Ok") {
    return e;
  }
  let flags = fromByte(e._0);
  let getPositionFromTarget = flag3(flags);
  let match = flag1(flags);
  let match$1 = flag2(flags);
  let teleportType = match ? match$1 ? "TeleportAck" : "Npc" : match$1 ? "PlayerToPlayer" : "Player";
  let e$1 = readInt16(reader, "targetId");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "x");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "y");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readByte(reader, "style");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = flag4(flags) ? map(readInt32(reader, "extraInfo"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (e$5.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        teleportType,
        getPositionFromTarget,
        targetId: e$1._0,
        x: e$2._0,
        y: e$3._0,
        style: e$4._0,
        extraInfo: e$5._0
      }
    };
  } else {
    return e$5;
  }
}
var Decode6 = {
  readByte,
  readInt16,
  readSingle,
  readInt32,
  parse: parse54
};
function getFlags(self) {
  return toByte(fromFlags(self.teleportType === "Npc" || self.teleportType === "TeleportAck", self.teleportType === "PlayerToPlayer" || self.teleportType === "TeleportAck", self.getPositionFromTarget, isSome(self.extraInfo), false, false, false, false));
}
function toBuffer53(self) {
  let writer = packByte(packSingle(packSingle(packInt16(packByte(setType(make(), toInt("Teleport")), getFlags(self), "flags"), self.targetId, "targetId"), self.x, "x"), self.y, "y"), self.style, "style");
  let extraInfo = self.extraInfo;
  return data(extraInfo !== void 0 ? packInt32(writer, extraInfo, "extraInfo") : writer);
}
var Encode6 = {
  packByte,
  packInt16,
  packSingle,
  packInt32,
  setType,
  data,
  getFlags,
  toBuffer: toBuffer53
};
var Packet_TeleportationPotion_exports = {};
__export(Packet_TeleportationPotion_exports, {
  Decode: () => Decode7,
  Encode: () => Encode7,
  parse: () => parse55,
  teleportTypeToInt: () => teleportTypeToInt,
  toBuffer: () => toBuffer54
});
function teleportTypeToInt(teleportType) {
  switch (teleportType) {
    case "TeleportationPotion":
      return 0;
    case "MagicConch":
      return 1;
    case "DemonConch":
      return 2;
    case "ShellphoneSpawn":
      return 3;
    case "PlayerNoSpaceTeleport":
      return 4;
  }
}
function parse55(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "teleportType");
  if (e.TAG !== "Ok") {
    return e;
  }
  switch (e._0) {
    case 0:
      return {
        TAG: "Ok",
        _0: {
          teleportType: "TeleportationPotion"
        }
      };
    case 1:
      return {
        TAG: "Ok",
        _0: {
          teleportType: "MagicConch"
        }
      };
    case 2:
      return {
        TAG: "Ok",
        _0: {
          teleportType: "DemonConch"
        }
      };
    case 3:
      return {
        TAG: "Ok",
        _0: {
          teleportType: "ShellphoneSpawn"
        }
      };
    case 4:
      return {
        TAG: "Ok",
        _0: {
          teleportType: "PlayerNoSpaceTeleport"
        }
      };
    default:
      return {
        TAG: "Error",
        _0: {
          context: "Packet_TeleportationPotion.parse",
          error: new Error("Unknown teleport type")
        }
      };
  }
}
var Decode7 = {
  readByte,
  parse: parse55
};
function toBuffer54(self) {
  return data(packByte(setType(make(), toInt("TeleportationPotion")), teleportTypeToInt(self.teleportType), "teleportType"));
}
var Encode7 = {
  Writer: void 0,
  packByte,
  setType,
  data,
  toBuffer: toBuffer54
};
var PacketV1449_TemporaryAnimationCreate_exports = {};
__export(PacketV1449_TemporaryAnimationCreate_exports, {
  parse: () => parse56,
  toBuffer: () => toBuffer55
});
function parse56(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "typeId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readUInt16(reader, "tileType");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "x");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt16(reader, "y");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        typeId: e._0,
        tileType: e$1._0,
        x: e$2._0,
        y: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function toBuffer55(self) {
  return data(packInt16(packInt16(packUInt16(packInt16(setType(make(), toInt("TemporaryAnimationCreate")), self.typeId, "typeId"), self.tileType, "tileType"), self.x, "x"), self.y, "y"));
}
var Packet_TileEntityDisplayDollItemSync_exports = {};
__export(Packet_TileEntityDisplayDollItemSync_exports, {
  Decode: () => Decode8,
  Encode: () => Encode8,
  commandFromInt: () => commandFromInt,
  commandToInt: () => commandToInt,
  parse: () => parse57,
  toBuffer: () => toBuffer56
});
function commandToInt(command) {
  switch (command) {
    case "Equip":
      return 0;
    case "Dye":
      return 1;
    case "Pose":
      return 2;
    case "Misc":
      return 3;
  }
}
function commandFromInt(value) {
  switch (value) {
    case 0:
      return "Equip";
    case 1:
      return "Dye";
    case 2:
      return "Pose";
    case 3:
      return "Misc";
    default:
      return;
  }
}
function parse57(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let playerId = e._0;
  let e$1 = readInt32(reader, "tileEntityId");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let tileEntityId = e$1._0;
  let e$2 = readByte(reader, "itemIndex");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let itemIndex = e$2._0;
  let e$3 = readByte(reader, "command");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let command = commandFromInt(e$3._0);
  if (command === void 0) {
    return {
      TAG: "Error",
      _0: {
        context: "Packet_TileEntityDisplayDollItemSync.parse",
        error: new Error("Unknown display doll command")
      }
    };
  }
  if (command === "Pose") {
    let e$4 = readByte(reader, "pose");
    if (e$4.TAG === "Ok") {
      return {
        TAG: "Ok",
        _0: {
          playerId,
          tileEntityId,
          itemIndex,
          command,
          data: {
            TAG: "PoseValue",
            _0: e$4._0
          }
        }
      };
    } else {
      return e$4;
    }
  }
  let e$5 = readUInt16(reader, "itemId");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readUInt16(reader, "stack");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readByte(reader, "prefix");
  if (e$7.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId,
        tileEntityId,
        itemIndex,
        command,
        data: {
          TAG: "Item",
          _0: {
            itemId: e$5._0,
            stack: e$6._0,
            prefix: e$7._0
          }
        }
      }
    };
  } else {
    return e$7;
  }
}
var Decode8 = {
  readByte,
  readInt32,
  readUInt16,
  parse: parse57
};
function toBuffer56(self) {
  let writer = packByte(packByte(packInt32(packByte(setType(make(), toInt("TileEntityDisplayDollItemSync")), self.playerId, "playerId"), self.tileEntityId, "tileEntityId"), self.itemIndex, "itemIndex"), commandToInt(self.command), "command");
  let pose = self.data;
  let tmp;
  if (pose.TAG === "Item") {
    let match = pose._0;
    tmp = packByte(packUInt16(packUInt16(writer, match.itemId, "itemId"), match.stack, "stack"), match.prefix, "prefix");
  } else {
    tmp = packByte(writer, pose._0, "pose");
  }
  return data(tmp);
}
var Encode8 = {
  Writer: void 0,
  packByte,
  packInt32,
  packUInt16,
  setType,
  data,
  toBuffer: toBuffer56
};
var PacketV1449_TileEntityHatRackItemSync_exports = {};
__export(PacketV1449_TileEntityHatRackItemSync_exports, {
  parse: () => parse58,
  toBuffer: () => toBuffer57
});
function parse58(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "tileEntityId");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "itemIndex");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readUInt16(reader, "itemId");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readUInt16(reader, "stack");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readByte(reader, "prefix");
  if (e$5.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        tileEntityId: e$1._0,
        itemIndex: e$2._0,
        itemId: e$3._0,
        stack: e$4._0,
        prefix: e$5._0
      }
    };
  } else {
    return e$5;
  }
}
function toBuffer57(self) {
  return data(packByte(packUInt16(packUInt16(packByte(packInt32(packByte(setType(make(), toInt("TileEntityHatRackItemSync")), self.playerId, "playerId"), self.tileEntityId, "tileEntityId"), self.itemIndex, "itemIndex"), self.itemId, "itemId"), self.stack, "stack"), self.prefix, "prefix"));
}
var PacketV1449_TileEntityInteractionRequest_exports = {};
__export(PacketV1449_TileEntityInteractionRequest_exports, {
  parse: () => parse59,
  toBuffer: () => toBuffer58
});
function parse59(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt32(reader, "tileEntityId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "playerId");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        tileEntityId: e._0,
        playerId: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer58(self) {
  return data(packByte(packInt32(setType(make(), toInt("TileEntityInteractionRequest")), self.tileEntityId, "tileEntityId"), self.playerId, "playerId"));
}
var PacketV1449_TileEntityPlace_exports = {};
__export(PacketV1449_TileEntityPlace_exports, {
  parse: () => parse60,
  toBuffer: () => toBuffer59
});
function parse60(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "tileEntityType");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        tileEntityType: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function toBuffer59(self) {
  return data(packByte(packInt16(packInt16(setType(make(), toInt("TileEntityPlace")), self.x, "x"), self.y, "y"), self.tileEntityType, "tileEntityType"));
}
var PacketV1449_TileEntityUpdate_exports = {};
__export(PacketV1449_TileEntityUpdate_exports, {
  parse: () => parse61,
  toBuffer: () => toBuffer60
});
function parse61(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt32(reader, "tileEntityId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let tileEntityId = e._0;
  let e$1 = readBool(reader, "hasData");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  if (!e$1._0) {
    return {
      TAG: "Ok",
      _0: {
        tileEntityId,
        payload: "Remove"
      }
    };
  }
  let e$2 = getBytesLeft(reader);
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readBuffer(reader, e$2._0, "tileEntityData");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        tileEntityId,
        payload: {
          TAG: "Data",
          _0: e$3._0
        }
      }
    };
  } else {
    return e$3;
  }
}
function toBuffer60(self) {
  let writer = packInt32(setType(make(), toInt("TileEntityUpdate")), self.tileEntityId, "tileEntityId");
  let tileEntityData = self.payload;
  if (typeof tileEntityData !== "object") {
    return data(packBool(writer, false, "hasData"));
  } else {
    return data(packBuffer(packBool(writer, true, "hasData"), tileEntityData._0, "tileEntityData"));
  }
}
var PacketV1449_TileModify_exports = {};
__export(PacketV1449_TileModify_exports, {
  Action: () => Action2,
  parse: () => parse62,
  toBuffer: () => toBuffer61
});
function fromInt8(action) {
  switch (action) {
    case 0:
      return "KillTile";
    case 1:
      return "PlaceTile";
    case 2:
      return "KillWall";
    case 3:
      return "PlaceWall";
    case 4:
      return "KillTileNoItem";
    case 5:
      return "PlaceWire";
    case 6:
      return "KillWire";
    case 7:
      return "PoundTile";
    case 8:
      return "PlaceActuator";
    case 9:
      return "KillActuator";
    case 10:
      return "PlaceWire2";
    case 11:
      return "KillWire2";
    case 12:
      return "PlaceWire3";
    case 13:
      return "KillWire3";
    case 14:
      return "SlopeTile";
    case 15:
      return "FrameTrack";
    case 16:
      return "PlaceWire4";
    case 17:
      return "KillWire4";
    case 18:
      return "PokeLogicGate";
    case 19:
      return "Actuate";
    case 20:
      return "KillTile2";
    case 21:
      return "ReplaceTile";
    case 22:
      return "ReplaceWall";
    case 23:
      return "SlopePoundTile";
    default:
      return;
  }
}
function toInt8(action) {
  switch (action) {
    case "KillTile":
      return 0;
    case "PlaceTile":
      return 1;
    case "KillWall":
      return 2;
    case "PlaceWall":
      return 3;
    case "KillTileNoItem":
      return 4;
    case "PlaceWire":
      return 5;
    case "KillWire":
      return 6;
    case "PoundTile":
      return 7;
    case "PlaceActuator":
      return 8;
    case "KillActuator":
      return 9;
    case "PlaceWire2":
      return 10;
    case "KillWire2":
      return 11;
    case "PlaceWire3":
      return 12;
    case "KillWire3":
      return 13;
    case "SlopeTile":
      return 14;
    case "FrameTrack":
      return 15;
    case "PlaceWire4":
      return 16;
    case "KillWire4":
      return 17;
    case "PokeLogicGate":
      return 18;
    case "Actuate":
      return 19;
    case "KillTile2":
      return 20;
    case "ReplaceTile":
      return 21;
    case "ReplaceWall":
      return 22;
    case "SlopePoundTile":
      return 23;
  }
}
var Action2 = {
  fromInt: fromInt8,
  toInt: toInt8
};
function parse62(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "action");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "tileX");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "tileY");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt16(reader, "value1");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readByte(reader, "value2");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let action = fromInt8(e._0);
  let action$1 = action !== void 0 ? {
    TAG: "Ok",
    _0: action
  } : {
    TAG: "Error",
    _0: {
      context: "TileModify.parse.action",
      error: new Error("Unknown action")
    }
  };
  if (action$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        action: action$1._0,
        tileX: e$1._0,
        tileY: e$2._0,
        value1: e$3._0,
        value2: e$4._0
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: action$1._0
    };
  }
}
function toBuffer61(self) {
  return data(packByte(packInt16(packInt16(packInt16(packByte(setType(make(), toInt("TileModify")), toInt8(self.action), "action"), self.tileX, "tileX"), self.tileY, "tileY"), self.value1, "value1"), self.value2, "value2"));
}
var PacketV1449_TilePaint_exports = {};
__export(PacketV1449_TilePaint_exports, {
  parse: () => parse63,
  toBuffer: () => toBuffer62
});
function parse63(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "color");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "coat");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        color: e$2._0,
        coat: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function toBuffer62(self) {
  return data(packByte(packByte(packInt16(packInt16(setType(make(), toInt("TilePaint")), self.x, "x"), self.y, "y"), self.color, "color"), self.coat, "coat"));
}
var PacketV1449_TilePickingSync_exports = {};
__export(PacketV1449_TilePickingSync_exports, {
  parse: () => parse64,
  toBuffer: () => toBuffer63
});
function parse64(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "pickPower");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        x: e$1._0,
        y: e$2._0,
        pickPower: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function toBuffer63(self) {
  return data(packByte(packInt16(packInt16(packByte(setType(make(), toInt("TilePickingSync")), self.playerId, "playerId"), self.x, "x"), self.y, "y"), self.pickPower, "pickPower"));
}
var PacketV1449_TileSectionFrame_exports = {};
__export(PacketV1449_TileSectionFrame_exports, {
  parse: () => parse65,
  toBuffer: () => toBuffer64
});
function parse65(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "startX");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "startY");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "endX");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt16(reader, "endY");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        startX: e._0,
        startY: e$1._0,
        endX: e$2._0,
        endY: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function toBuffer64(self) {
  return data(packInt16(packInt16(packInt16(packInt16(setType(make(), toInt("TileSectionFrame")), self.startX, "startX"), self.startY, "startY"), self.endX, "endX"), self.endY, "endY"));
}
var Packet_TileSectionSend_exports = {};
__export(Packet_TileSectionSend_exports, {
  Chest: () => Chest2,
  Entity: () => Entity,
  Sign: () => Sign2,
  parse: () => parse$13,
  toBuffer: () => toBuffer65
});
var for_in = function(o, foo) {
  for (var x in o) {
    foo(x);
  }
};
function equal(a, b) {
  if (a === b) {
    return true;
  }
  let a_type = typeof a;
  if (a_type === "string" || a_type === "number" || a_type === "bigint" || a_type === "boolean" || a_type === "undefined" || a === null) {
    return false;
  }
  let b_type = typeof b;
  if (a_type === "function" || b_type === "function") {
    throw {
      RE_EXN_ID: "Invalid_argument",
      _1: "equal: functional value",
      Error: new Error()
    };
  }
  if (b_type === "number" || b_type === "bigint" || b_type === "undefined" || b === null) {
    return false;
  }
  let tag_a = a.TAG;
  let tag_b = b.TAG;
  if (tag_a !== tag_b) {
    return false;
  }
  let len_a = a.length | 0;
  let len_b = b.length | 0;
  if (len_a === len_b) {
    if (Array.isArray(a)) {
      let _i = 0;
      while (true) {
        let i = _i;
        if (i === len_a) {
          return true;
        }
        if (!equal(a[i], b[i])) {
          return false;
        }
        _i = i + 1 | 0;
        continue;
      }
      ;
    } else if (a instanceof Date && b instanceof Date) {
      return !(a > b || a < b);
    } else {
      let result = {
        contents: true
      };
      let do_key_a = (key) => {
        if (!Object.prototype.hasOwnProperty.call(b, key)) {
          result.contents = false;
          return;
        }
      };
      let do_key_b = (key) => {
        if (!Object.prototype.hasOwnProperty.call(a, key) || !equal(b[key], a[key])) {
          result.contents = false;
          return;
        }
      };
      for_in(a, do_key_a);
      if (result.contents) {
        for_in(b, do_key_b);
      }
      return result.contents;
    }
  } else {
    return false;
  }
}
function notequal(a, b) {
  if ((typeof a === "number" || typeof a === "bigint") && (typeof b === "number" || typeof b === "bigint")) {
    return a !== b;
  } else {
    return !equal(a, b);
  }
}
var map3 = /* @__PURE__ */ new Map([
  [
    379,
    true
  ],
  [
    371,
    true
  ],
  [
    357,
    true
  ],
  [
    408,
    true
  ],
  [
    409,
    true
  ],
  [
    415,
    true
  ],
  [
    416,
    true
  ],
  [
    417,
    true
  ],
  [
    418,
    true
  ],
  [
    232,
    true
  ],
  [
    311,
    true
  ],
  [
    312,
    true
  ],
  [
    313,
    true
  ],
  [
    315,
    true
  ],
  [
    321,
    true
  ],
  [
    322,
    true
  ],
  [
    239,
    true
  ],
  [
    380,
    true
  ],
  [
    367,
    true
  ],
  [
    357,
    true
  ],
  [
    368,
    true
  ],
  [
    369,
    true
  ],
  [
    325,
    true
  ],
  [
    460,
    true
  ],
  [
    326,
    true
  ],
  [
    458,
    true
  ],
  [
    459,
    true
  ],
  [
    327,
    true
  ],
  [
    345,
    true
  ],
  [
    328,
    true
  ],
  [
    329,
    true
  ],
  [
    421,
    true
  ],
  [
    422,
    true
  ],
  [
    426,
    true
  ],
  [
    430,
    true
  ],
  [
    431,
    true
  ],
  [
    432,
    true
  ],
  [
    433,
    true
  ],
  [
    434,
    true
  ],
  [
    446,
    true
  ],
  [
    447,
    true
  ],
  [
    448,
    true
  ],
  [
    427,
    true
  ],
  [
    284,
    true
  ],
  [
    346,
    true
  ],
  [
    347,
    true
  ],
  [
    348,
    true
  ],
  [
    350,
    true
  ],
  [
    370,
    true
  ],
  [
    383,
    true
  ],
  [
    385,
    true
  ],
  [
    396,
    true
  ],
  [
    397,
    true
  ],
  [
    399,
    true
  ],
  [
    401,
    true
  ],
  [
    398,
    true
  ],
  [
    400,
    true
  ],
  [
    402,
    true
  ],
  [
    403,
    true
  ],
  [
    404,
    true
  ],
  [
    407,
    true
  ],
  [
    170,
    true
  ],
  [
    221,
    true
  ],
  [
    272,
    true
  ],
  [
    229,
    true
  ],
  [
    230,
    true
  ],
  [
    222,
    true
  ],
  [
    223,
    true
  ],
  [
    224,
    true
  ],
  [
    225,
    true
  ],
  [
    226,
    true
  ],
  [
    235,
    true
  ],
  [
    191,
    true
  ],
  [
    211,
    true
  ],
  [
    208,
    true
  ],
  [
    192,
    true
  ],
  [
    193,
    true
  ],
  [
    194,
    true
  ],
  [
    195,
    true
  ],
  [
    200,
    true
  ],
  [
    203,
    true
  ],
  [
    204,
    true
  ],
  [
    189,
    true
  ],
  [
    190,
    true
  ],
  [
    198,
    true
  ],
  [
    206,
    true
  ],
  [
    248,
    true
  ],
  [
    249,
    true
  ],
  [
    250,
    true
  ],
  [
    251,
    true
  ],
  [
    252,
    true
  ],
  [
    253,
    true
  ],
  [
    273,
    true
  ],
  [
    274,
    true
  ],
  [
    202,
    true
  ],
  [
    188,
    true
  ],
  [
    179,
    true
  ],
  [
    381,
    true
  ],
  [
    180,
    true
  ],
  [
    181,
    true
  ],
  [
    182,
    true
  ],
  [
    183,
    true
  ],
  [
    196,
    true
  ],
  [
    197,
    true
  ],
  [
    175,
    true
  ],
  [
    176,
    true
  ],
  [
    177,
    true
  ],
  [
    162,
    true
  ],
  [
    163,
    true
  ],
  [
    164,
    true
  ],
  [
    234,
    true
  ],
  [
    137,
    true
  ],
  [
    160,
    true
  ],
  [
    161,
    true
  ],
  [
    145,
    true
  ],
  [
    146,
    true
  ],
  [
    147,
    true
  ],
  [
    148,
    true
  ],
  [
    138,
    true
  ],
  [
    140,
    true
  ],
  [
    151,
    true
  ],
  [
    152,
    true
  ],
  [
    153,
    true
  ],
  [
    154,
    true
  ],
  [
    155,
    true
  ],
  [
    156,
    true
  ],
  [
    157,
    true
  ],
  [
    158,
    true
  ],
  [
    159,
    true
  ],
  [
    130,
    true
  ],
  [
    107,
    true
  ],
  [
    108,
    true
  ],
  [
    111,
    true
  ],
  [
    109,
    true
  ],
  [
    112,
    true
  ],
  [
    116,
    true
  ],
  [
    117,
    true
  ],
  [
    123,
    true
  ],
  [
    118,
    true
  ],
  [
    119,
    true
  ],
  [
    120,
    true
  ],
  [
    121,
    true
  ],
  [
    122,
    true
  ],
  [
    150,
    true
  ],
  [
    199,
    true
  ],
  [
    0,
    true
  ],
  [
    1,
    true
  ],
  [
    2,
    true
  ],
  [
    6,
    true
  ],
  [
    7,
    true
  ],
  [
    8,
    true
  ],
  [
    9,
    true
  ],
  [
    166,
    true
  ],
  [
    167,
    true
  ],
  [
    168,
    true
  ],
  [
    169,
    true
  ],
  [
    10,
    true
  ],
  [
    19,
    true
  ],
  [
    22,
    true
  ],
  [
    23,
    true
  ],
  [
    25,
    true
  ],
  [
    30,
    true
  ],
  [
    37,
    true
  ],
  [
    38,
    true
  ],
  [
    39,
    true
  ],
  [
    40,
    true
  ],
  [
    41,
    true
  ],
  [
    43,
    true
  ],
  [
    44,
    true
  ],
  [
    45,
    true
  ],
  [
    46,
    true
  ],
  [
    47,
    true
  ],
  [
    48,
    true
  ],
  [
    53,
    true
  ],
  [
    54,
    true
  ],
  [
    56,
    true
  ],
  [
    57,
    true
  ],
  [
    58,
    true
  ],
  [
    59,
    true
  ],
  [
    60,
    true
  ],
  [
    63,
    true
  ],
  [
    64,
    true
  ],
  [
    65,
    true
  ],
  [
    66,
    true
  ],
  [
    67,
    true
  ],
  [
    68,
    true
  ],
  [
    75,
    true
  ],
  [
    76,
    true
  ],
  [
    70,
    true
  ],
  [
    384,
    true
  ],
  [
    387,
    true
  ],
  [
    388,
    true
  ]
]);
function isSolid(tileType) {
  return getOr(map3.get(tileType), false);
}
var map4 = /* @__PURE__ */ new Map([
  [
    0,
    false
  ],
  [
    1,
    false
  ],
  [
    2,
    false
  ],
  [
    3,
    true
  ],
  [
    4,
    true
  ],
  [
    5,
    true
  ],
  [
    6,
    false
  ],
  [
    7,
    false
  ],
  [
    8,
    false
  ],
  [
    9,
    false
  ],
  [
    10,
    true
  ],
  [
    11,
    true
  ],
  [
    12,
    true
  ],
  [
    13,
    true
  ],
  [
    14,
    true
  ],
  [
    15,
    true
  ],
  [
    16,
    true
  ],
  [
    17,
    true
  ],
  [
    18,
    true
  ],
  [
    19,
    true
  ],
  [
    20,
    true
  ],
  [
    21,
    true
  ],
  [
    22,
    false
  ],
  [
    23,
    false
  ],
  [
    24,
    true
  ],
  [
    25,
    false
  ],
  [
    26,
    true
  ],
  [
    27,
    true
  ],
  [
    28,
    true
  ],
  [
    29,
    true
  ],
  [
    30,
    false
  ],
  [
    31,
    true
  ],
  [
    32,
    false
  ],
  [
    33,
    true
  ],
  [
    34,
    true
  ],
  [
    35,
    true
  ],
  [
    36,
    true
  ],
  [
    37,
    false
  ],
  [
    38,
    false
  ],
  [
    39,
    false
  ],
  [
    40,
    false
  ],
  [
    41,
    false
  ],
  [
    42,
    true
  ],
  [
    43,
    false
  ],
  [
    44,
    false
  ],
  [
    45,
    false
  ],
  [
    46,
    false
  ],
  [
    47,
    false
  ],
  [
    48,
    false
  ],
  [
    49,
    true
  ],
  [
    50,
    true
  ],
  [
    51,
    false
  ],
  [
    52,
    false
  ],
  [
    53,
    false
  ],
  [
    54,
    false
  ],
  [
    55,
    true
  ],
  [
    56,
    false
  ],
  [
    57,
    false
  ],
  [
    58,
    false
  ],
  [
    59,
    false
  ],
  [
    60,
    false
  ],
  [
    61,
    true
  ],
  [
    62,
    false
  ],
  [
    63,
    false
  ],
  [
    64,
    false
  ],
  [
    65,
    false
  ],
  [
    66,
    false
  ],
  [
    67,
    false
  ],
  [
    68,
    false
  ],
  [
    69,
    false
  ],
  [
    70,
    false
  ],
  [
    71,
    true
  ],
  [
    72,
    true
  ],
  [
    73,
    true
  ],
  [
    74,
    true
  ],
  [
    75,
    false
  ],
  [
    76,
    false
  ],
  [
    77,
    true
  ],
  [
    78,
    true
  ],
  [
    79,
    true
  ],
  [
    80,
    false
  ],
  [
    81,
    true
  ],
  [
    82,
    true
  ],
  [
    83,
    true
  ],
  [
    84,
    true
  ],
  [
    85,
    true
  ],
  [
    86,
    true
  ],
  [
    87,
    true
  ],
  [
    88,
    true
  ],
  [
    89,
    true
  ],
  [
    90,
    true
  ],
  [
    91,
    true
  ],
  [
    92,
    true
  ],
  [
    93,
    true
  ],
  [
    94,
    true
  ],
  [
    95,
    true
  ],
  [
    96,
    true
  ],
  [
    97,
    true
  ],
  [
    98,
    true
  ],
  [
    99,
    true
  ],
  [
    100,
    true
  ],
  [
    101,
    true
  ],
  [
    102,
    true
  ],
  [
    103,
    true
  ],
  [
    104,
    true
  ],
  [
    105,
    true
  ],
  [
    106,
    true
  ],
  [
    107,
    false
  ],
  [
    108,
    false
  ],
  [
    109,
    false
  ],
  [
    110,
    true
  ],
  [
    111,
    false
  ],
  [
    112,
    false
  ],
  [
    113,
    true
  ],
  [
    114,
    true
  ],
  [
    115,
    false
  ],
  [
    116,
    false
  ],
  [
    117,
    false
  ],
  [
    118,
    false
  ],
  [
    119,
    false
  ],
  [
    120,
    false
  ],
  [
    121,
    false
  ],
  [
    122,
    false
  ],
  [
    123,
    false
  ],
  [
    124,
    false
  ],
  [
    125,
    true
  ],
  [
    126,
    true
  ],
  [
    127,
    false
  ],
  [
    128,
    true
  ],
  [
    129,
    true
  ],
  [
    130,
    false
  ],
  [
    131,
    false
  ],
  [
    132,
    true
  ],
  [
    133,
    true
  ],
  [
    134,
    true
  ],
  [
    135,
    true
  ],
  [
    136,
    true
  ],
  [
    137,
    true
  ],
  [
    138,
    true
  ],
  [
    139,
    true
  ],
  [
    140,
    false
  ],
  [
    141,
    true
  ],
  [
    142,
    true
  ],
  [
    143,
    true
  ],
  [
    144,
    true
  ],
  [
    145,
    false
  ],
  [
    146,
    false
  ],
  [
    147,
    false
  ],
  [
    148,
    false
  ],
  [
    149,
    true
  ],
  [
    150,
    false
  ],
  [
    151,
    false
  ],
  [
    152,
    false
  ],
  [
    153,
    false
  ],
  [
    154,
    false
  ],
  [
    155,
    false
  ],
  [
    156,
    false
  ],
  [
    157,
    false
  ],
  [
    158,
    false
  ],
  [
    159,
    false
  ],
  [
    160,
    false
  ],
  [
    161,
    false
  ],
  [
    162,
    false
  ],
  [
    163,
    false
  ],
  [
    164,
    false
  ],
  [
    165,
    true
  ],
  [
    166,
    false
  ],
  [
    167,
    false
  ],
  [
    168,
    false
  ],
  [
    169,
    false
  ],
  [
    170,
    false
  ],
  [
    171,
    true
  ],
  [
    172,
    true
  ],
  [
    173,
    true
  ],
  [
    174,
    true
  ],
  [
    175,
    false
  ],
  [
    176,
    false
  ],
  [
    177,
    false
  ],
  [
    178,
    true
  ],
  [
    179,
    false
  ],
  [
    180,
    false
  ],
  [
    181,
    false
  ],
  [
    182,
    false
  ],
  [
    183,
    false
  ],
  [
    184,
    true
  ],
  [
    185,
    true
  ],
  [
    186,
    true
  ],
  [
    187,
    true
  ],
  [
    188,
    false
  ],
  [
    189,
    false
  ],
  [
    190,
    false
  ],
  [
    191,
    false
  ],
  [
    192,
    false
  ],
  [
    193,
    false
  ],
  [
    194,
    false
  ],
  [
    195,
    false
  ],
  [
    196,
    false
  ],
  [
    197,
    false
  ],
  [
    198,
    false
  ],
  [
    199,
    false
  ],
  [
    200,
    false
  ],
  [
    201,
    true
  ],
  [
    202,
    false
  ],
  [
    203,
    false
  ],
  [
    204,
    false
  ],
  [
    205,
    false
  ],
  [
    206,
    false
  ],
  [
    207,
    true
  ],
  [
    208,
    false
  ],
  [
    209,
    true
  ],
  [
    210,
    true
  ],
  [
    211,
    false
  ],
  [
    212,
    true
  ],
  [
    213,
    false
  ],
  [
    214,
    false
  ],
  [
    215,
    true
  ],
  [
    216,
    true
  ],
  [
    217,
    true
  ],
  [
    218,
    true
  ],
  [
    219,
    true
  ],
  [
    220,
    true
  ],
  [
    221,
    false
  ],
  [
    222,
    false
  ],
  [
    223,
    false
  ],
  [
    224,
    false
  ],
  [
    225,
    false
  ],
  [
    226,
    false
  ],
  [
    227,
    true
  ],
  [
    228,
    true
  ],
  [
    229,
    false
  ],
  [
    230,
    false
  ],
  [
    231,
    true
  ],
  [
    232,
    false
  ],
  [
    233,
    true
  ],
  [
    234,
    false
  ],
  [
    235,
    true
  ],
  [
    236,
    true
  ],
  [
    237,
    true
  ],
  [
    238,
    true
  ],
  [
    239,
    true
  ],
  [
    240,
    true
  ],
  [
    241,
    true
  ],
  [
    242,
    true
  ],
  [
    243,
    true
  ],
  [
    244,
    true
  ],
  [
    245,
    true
  ],
  [
    246,
    true
  ],
  [
    247,
    true
  ],
  [
    248,
    false
  ],
  [
    249,
    false
  ],
  [
    250,
    false
  ],
  [
    251,
    false
  ],
  [
    252,
    false
  ],
  [
    253,
    false
  ],
  [
    254,
    true
  ],
  [
    255,
    false
  ],
  [
    256,
    false
  ],
  [
    257,
    false
  ],
  [
    258,
    false
  ],
  [
    259,
    false
  ],
  [
    260,
    false
  ],
  [
    261,
    false
  ],
  [
    262,
    false
  ],
  [
    263,
    false
  ],
  [
    264,
    false
  ],
  [
    265,
    false
  ],
  [
    266,
    false
  ],
  [
    267,
    false
  ],
  [
    268,
    false
  ],
  [
    269,
    true
  ],
  [
    270,
    true
  ],
  [
    271,
    true
  ],
  [
    272,
    false
  ],
  [
    273,
    false
  ],
  [
    274,
    false
  ],
  [
    275,
    true
  ],
  [
    276,
    true
  ],
  [
    277,
    true
  ],
  [
    278,
    true
  ],
  [
    279,
    true
  ],
  [
    280,
    true
  ],
  [
    281,
    true
  ],
  [
    282,
    true
  ],
  [
    283,
    true
  ],
  [
    284,
    false
  ],
  [
    285,
    true
  ],
  [
    286,
    true
  ],
  [
    287,
    true
  ],
  [
    288,
    true
  ],
  [
    289,
    true
  ],
  [
    290,
    true
  ],
  [
    291,
    true
  ],
  [
    292,
    true
  ],
  [
    293,
    true
  ],
  [
    294,
    true
  ],
  [
    295,
    true
  ],
  [
    296,
    true
  ],
  [
    297,
    true
  ],
  [
    298,
    true
  ],
  [
    299,
    true
  ],
  [
    300,
    true
  ],
  [
    301,
    true
  ],
  [
    302,
    true
  ],
  [
    303,
    true
  ],
  [
    304,
    true
  ],
  [
    305,
    true
  ],
  [
    306,
    true
  ],
  [
    307,
    true
  ],
  [
    308,
    true
  ],
  [
    309,
    true
  ],
  [
    310,
    true
  ],
  [
    311,
    false
  ],
  [
    312,
    false
  ],
  [
    313,
    false
  ],
  [
    314,
    true
  ],
  [
    315,
    false
  ],
  [
    316,
    true
  ],
  [
    317,
    true
  ],
  [
    318,
    true
  ],
  [
    319,
    true
  ],
  [
    320,
    true
  ],
  [
    321,
    false
  ],
  [
    322,
    false
  ],
  [
    323,
    true
  ],
  [
    324,
    true
  ],
  [
    325,
    false
  ],
  [
    326,
    false
  ],
  [
    327,
    false
  ],
  [
    328,
    false
  ],
  [
    329,
    false
  ],
  [
    330,
    false
  ],
  [
    331,
    false
  ],
  [
    332,
    false
  ],
  [
    333,
    false
  ],
  [
    334,
    true
  ],
  [
    335,
    true
  ],
  [
    336,
    false
  ],
  [
    337,
    true
  ],
  [
    338,
    true
  ],
  [
    339,
    true
  ],
  [
    340,
    false
  ],
  [
    341,
    false
  ],
  [
    342,
    false
  ],
  [
    343,
    false
  ],
  [
    344,
    false
  ],
  [
    345,
    false
  ],
  [
    346,
    false
  ],
  [
    347,
    false
  ],
  [
    348,
    false
  ],
  [
    349,
    true
  ],
  [
    350,
    false
  ],
  [
    351,
    false
  ],
  [
    352,
    false
  ],
  [
    353,
    false
  ],
  [
    354,
    true
  ],
  [
    355,
    true
  ],
  [
    356,
    true
  ],
  [
    357,
    false
  ],
  [
    358,
    true
  ],
  [
    359,
    true
  ],
  [
    360,
    true
  ],
  [
    361,
    true
  ],
  [
    362,
    true
  ],
  [
    363,
    true
  ],
  [
    364,
    true
  ],
  [
    365,
    false
  ],
  [
    366,
    false
  ],
  [
    367,
    false
  ],
  [
    368,
    false
  ],
  [
    369,
    false
  ],
  [
    370,
    false
  ],
  [
    371,
    false
  ],
  [
    372,
    true
  ],
  [
    373,
    true
  ],
  [
    374,
    true
  ],
  [
    375,
    true
  ],
  [
    376,
    true
  ],
  [
    377,
    true
  ],
  [
    378,
    true
  ],
  [
    379,
    false
  ],
  [
    380,
    true
  ],
  [
    381,
    false
  ],
  [
    382,
    false
  ],
  [
    383,
    false
  ],
  [
    384,
    false
  ],
  [
    385,
    false
  ],
  [
    386,
    true
  ],
  [
    387,
    true
  ],
  [
    388,
    true
  ],
  [
    389,
    true
  ],
  [
    390,
    true
  ],
  [
    391,
    true
  ],
  [
    392,
    true
  ],
  [
    393,
    true
  ],
  [
    394,
    true
  ],
  [
    395,
    true
  ],
  [
    396,
    false
  ],
  [
    397,
    false
  ],
  [
    398,
    false
  ],
  [
    399,
    false
  ],
  [
    400,
    false
  ],
  [
    401,
    false
  ],
  [
    402,
    false
  ],
  [
    403,
    false
  ],
  [
    404,
    false
  ],
  [
    405,
    true
  ],
  [
    406,
    true
  ],
  [
    407,
    false
  ],
  [
    408,
    false
  ],
  [
    409,
    false
  ],
  [
    410,
    true
  ],
  [
    411,
    true
  ],
  [
    412,
    true
  ],
  [
    413,
    true
  ],
  [
    414,
    true
  ],
  [
    415,
    false
  ],
  [
    416,
    false
  ],
  [
    417,
    false
  ],
  [
    418,
    false
  ],
  [
    419,
    true
  ],
  [
    420,
    true
  ],
  [
    421,
    false
  ],
  [
    422,
    false
  ],
  [
    423,
    true
  ],
  [
    424,
    true
  ],
  [
    425,
    true
  ],
  [
    426,
    false
  ],
  [
    427,
    true
  ],
  [
    428,
    true
  ],
  [
    429,
    true
  ],
  [
    430,
    false
  ],
  [
    431,
    false
  ],
  [
    432,
    false
  ],
  [
    433,
    false
  ],
  [
    434,
    false
  ],
  [
    435,
    false
  ],
  [
    436,
    false
  ],
  [
    437,
    false
  ],
  [
    438,
    false
  ],
  [
    439,
    false
  ],
  [
    440,
    true
  ],
  [
    441,
    true
  ],
  [
    442,
    true
  ],
  [
    443,
    true
  ],
  [
    444,
    true
  ],
  [
    445,
    true
  ],
  [
    446,
    false
  ],
  [
    447,
    false
  ],
  [
    448,
    false
  ],
  [
    449,
    false
  ],
  [
    450,
    false
  ],
  [
    451,
    false
  ],
  [
    452,
    true
  ],
  [
    453,
    true
  ],
  [
    454,
    true
  ],
  [
    455,
    true
  ],
  [
    456,
    true
  ],
  [
    457,
    true
  ],
  [
    458,
    false
  ],
  [
    459,
    false
  ],
  [
    460,
    false
  ],
  [
    461,
    true
  ],
  [
    462,
    true
  ],
  [
    463,
    true
  ],
  [
    464,
    true
  ],
  [
    465,
    true
  ],
  [
    466,
    true
  ],
  [
    467,
    true
  ],
  [
    468,
    true
  ],
  [
    469,
    true
  ],
  [
    470,
    true
  ],
  [
    471,
    true
  ],
  [
    472,
    false
  ],
  [
    473,
    false
  ],
  [
    474,
    false
  ],
  [
    475,
    true
  ],
  [
    476,
    true
  ],
  [
    477,
    false
  ],
  [
    478,
    false
  ],
  [
    479,
    false
  ],
  [
    480,
    true
  ],
  [
    481,
    false
  ],
  [
    482,
    false
  ],
  [
    483,
    false
  ],
  [
    484,
    true
  ],
  [
    485,
    true
  ],
  [
    486,
    true
  ],
  [
    487,
    true
  ],
  [
    488,
    true
  ],
  [
    489,
    true
  ],
  [
    490,
    true
  ],
  [
    491,
    true
  ],
  [
    492,
    false
  ],
  [
    493,
    true
  ],
  [
    494,
    true
  ],
  [
    495,
    false
  ],
  [
    496,
    false
  ],
  [
    497,
    true
  ],
  [
    498,
    false
  ],
  [
    499,
    true
  ],
  [
    500,
    false
  ],
  [
    501,
    false
  ],
  [
    502,
    false
  ],
  [
    503,
    false
  ],
  [
    504,
    false
  ],
  [
    505,
    true
  ],
  [
    506,
    true
  ],
  [
    507,
    false
  ],
  [
    508,
    false
  ],
  [
    509,
    true
  ],
  [
    510,
    true
  ],
  [
    511,
    true
  ],
  [
    512,
    false
  ],
  [
    513,
    false
  ],
  [
    514,
    false
  ],
  [
    515,
    false
  ],
  [
    516,
    false
  ],
  [
    517,
    false
  ],
  [
    518,
    true
  ],
  [
    519,
    true
  ],
  [
    520,
    true
  ],
  [
    521,
    true
  ],
  [
    522,
    true
  ],
  [
    523,
    true
  ],
  [
    524,
    true
  ],
  [
    525,
    true
  ],
  [
    526,
    true
  ],
  [
    527,
    true
  ],
  [
    528,
    false
  ],
  [
    529,
    true
  ],
  [
    530,
    true
  ],
  [
    531,
    true
  ],
  [
    532,
    true
  ],
  [
    533,
    true
  ],
  [
    534,
    false
  ],
  [
    535,
    false
  ],
  [
    536,
    false
  ],
  [
    537,
    false
  ],
  [
    538,
    true
  ],
  [
    539,
    false
  ],
  [
    540,
    false
  ],
  [
    541,
    false
  ],
  [
    542,
    true
  ],
  [
    543,
    true
  ],
  [
    544,
    true
  ],
  [
    545,
    true
  ],
  [
    546,
    false
  ],
  [
    547,
    true
  ],
  [
    548,
    true
  ],
  [
    549,
    true
  ],
  [
    550,
    true
  ],
  [
    551,
    true
  ],
  [
    552,
    true
  ],
  [
    553,
    true
  ],
  [
    554,
    true
  ],
  [
    555,
    true
  ],
  [
    556,
    true
  ],
  [
    557,
    false
  ],
  [
    558,
    true
  ],
  [
    559,
    true
  ],
  [
    560,
    true
  ],
  [
    561,
    false
  ],
  [
    562,
    false
  ],
  [
    563,
    false
  ],
  [
    564,
    true
  ],
  [
    565,
    true
  ],
  [
    566,
    false
  ],
  [
    567,
    true
  ],
  [
    568,
    true
  ],
  [
    569,
    true
  ],
  [
    570,
    true
  ],
  [
    571,
    true
  ],
  [
    572,
    true
  ],
  [
    573,
    true
  ],
  [
    574,
    false
  ],
  [
    575,
    false
  ],
  [
    576,
    false
  ],
  [
    577,
    false
  ],
  [
    578,
    false
  ],
  [
    579,
    true
  ],
  [
    580,
    true
  ],
  [
    581,
    true
  ],
  [
    582,
    true
  ],
  [
    583,
    true
  ],
  [
    584,
    true
  ],
  [
    585,
    true
  ],
  [
    586,
    true
  ],
  [
    587,
    true
  ],
  [
    588,
    true
  ],
  [
    589,
    true
  ],
  [
    590,
    true
  ],
  [
    591,
    true
  ],
  [
    592,
    true
  ],
  [
    593,
    true
  ],
  [
    594,
    true
  ],
  [
    595,
    true
  ],
  [
    596,
    true
  ],
  [
    597,
    true
  ],
  [
    598,
    true
  ],
  [
    599,
    true
  ],
  [
    600,
    true
  ],
  [
    601,
    true
  ],
  [
    602,
    true
  ],
  [
    603,
    true
  ],
  [
    604,
    true
  ],
  [
    605,
    true
  ],
  [
    606,
    true
  ],
  [
    607,
    true
  ],
  [
    608,
    true
  ],
  [
    609,
    true
  ],
  [
    610,
    true
  ],
  [
    611,
    true
  ],
  [
    612,
    true
  ],
  [
    613,
    true
  ],
  [
    614,
    true
  ],
  [
    615,
    true
  ],
  [
    616,
    true
  ],
  [
    617,
    true
  ],
  [
    618,
    false
  ],
  [
    619,
    true
  ],
  [
    620,
    true
  ],
  [
    621,
    true
  ],
  [
    622,
    true
  ],
  [
    623,
    true
  ],
  [
    624,
    true
  ],
  [
    625,
    false
  ],
  [
    626,
    false
  ],
  [
    627,
    false
  ],
  [
    628,
    false
  ],
  [
    629,
    true
  ],
  [
    630,
    true
  ],
  [
    631,
    true
  ],
  [
    632,
    true
  ],
  [
    633,
    false
  ],
  [
    634,
    true
  ],
  [
    635,
    false
  ],
  [
    636,
    false
  ],
  [
    637,
    true
  ],
  [
    638,
    false
  ],
  [
    639,
    true
  ],
  [
    640,
    true
  ],
  [
    641,
    false
  ],
  [
    642,
    true
  ],
  [
    643,
    true
  ],
  [
    644,
    true
  ],
  [
    645,
    true
  ],
  [
    646,
    true
  ],
  [
    647,
    true
  ],
  [
    648,
    true
  ],
  [
    649,
    true
  ],
  [
    650,
    true
  ],
  [
    651,
    true
  ],
  [
    652,
    true
  ],
  [
    653,
    true
  ],
  [
    654,
    true
  ],
  [
    655,
    false
  ],
  [
    656,
    true
  ],
  [
    657,
    true
  ],
  [
    658,
    true
  ],
  [
    659,
    false
  ],
  [
    660,
    true
  ],
  [
    661,
    false
  ],
  [
    662,
    false
  ],
  [
    663,
    true
  ],
  [
    664,
    true
  ],
  [
    665,
    true
  ],
  [
    666,
    false
  ],
  [
    667,
    false
  ],
  [
    668,
    false
  ],
  [
    669,
    false
  ],
  [
    670,
    false
  ],
  [
    671,
    false
  ],
  [
    672,
    false
  ],
  [
    673,
    false
  ],
  [
    674,
    false
  ],
  [
    675,
    false
  ],
  [
    676,
    false
  ],
  [
    677,
    false
  ],
  [
    678,
    false
  ],
  [
    679,
    false
  ],
  [
    680,
    false
  ],
  [
    681,
    false
  ],
  [
    682,
    false
  ],
  [
    683,
    false
  ],
  [
    684,
    false
  ],
  [
    685,
    false
  ],
  [
    686,
    false
  ],
  [
    687,
    false
  ],
  [
    688,
    false
  ],
  [
    689,
    false
  ],
  [
    690,
    false
  ],
  [
    691,
    false
  ],
  [
    692,
    false
  ],
  [
    693,
    true
  ],
  [
    694,
    true
  ],
  [
    695,
    true
  ],
  [
    696,
    true
  ],
  [
    697,
    false
  ],
  [
    698,
    true
  ],
  [
    699,
    true
  ],
  [
    700,
    true
  ],
  [
    701,
    true
  ],
  [
    702,
    true
  ],
  [
    703,
    true
  ],
  [
    704,
    true
  ],
  [
    705,
    true
  ],
  [
    706,
    true
  ],
  [
    707,
    true
  ],
  [
    708,
    false
  ],
  [
    709,
    true
  ],
  [
    710,
    true
  ],
  [
    711,
    true
  ],
  [
    712,
    true
  ],
  [
    713,
    true
  ],
  [
    714,
    true
  ],
  [
    715,
    true
  ],
  [
    716,
    true
  ],
  [
    717,
    false
  ],
  [
    718,
    false
  ],
  [
    719,
    false
  ],
  [
    720,
    true
  ],
  [
    721,
    true
  ],
  [
    722,
    false
  ],
  [
    723,
    true
  ],
  [
    724,
    true
  ],
  [
    725,
    true
  ],
  [
    726,
    true
  ],
  [
    727,
    false
  ],
  [
    728,
    false
  ],
  [
    729,
    false
  ],
  [
    730,
    false
  ],
  [
    731,
    false
  ],
  [
    732,
    false
  ],
  [
    733,
    true
  ],
  [
    734,
    false
  ],
  [
    735,
    false
  ],
  [
    736,
    false
  ],
  [
    737,
    false
  ],
  [
    738,
    false
  ],
  [
    739,
    false
  ],
  [
    740,
    false
  ],
  [
    741,
    false
  ],
  [
    742,
    false
  ],
  [
    743,
    false
  ],
  [
    744,
    false
  ],
  [
    745,
    false
  ],
  [
    746,
    false
  ],
  [
    747,
    false
  ],
  [
    748,
    false
  ],
  [
    749,
    false
  ],
  [
    750,
    false
  ],
  [
    751,
    true
  ],
  [
    752,
    true
  ]
]);
function isImportant(tileType) {
  return getOr(map4.get(tileType), false);
}
function readByteUnsafe2(prim) {
  return prim.readByte();
}
function readInt16Unsafe2(prim) {
  return prim.readInt16();
}
function readInt32Unsafe2(prim) {
  return prim.readInt32();
}
function readStringUnsafe2(prim) {
  return prim.readString();
}
function getBytesLeftUnsafe2(prim) {
  return prim.bytesLeft;
}
function withContext2(fn, reader, context) {
  try {
    return {
      TAG: "Ok",
      _0: fn(reader)
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function readByte2(reader, context) {
  return withContext2(readByteUnsafe2, reader, context);
}
function readInt162(reader, context) {
  return withContext2(readInt16Unsafe2, reader, context);
}
function readInt322(reader, context) {
  return withContext2(readInt32Unsafe2, reader, context);
}
function readString2(reader, context) {
  return withContext2(readStringUnsafe2, reader, context);
}
function readBuffer2(reader, bytes, context) {
  return withContext2((reader2) => reader2.readBuffer(bytes), reader, context);
}
function getBytesLeft2(reader) {
  return withContext2(getBytesLeftUnsafe2, reader, "getBytesLeft");
}
function packInt322(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packInt32(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packByte2(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packByte(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packInt162(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packInt16(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function packString2(self, value, context) {
  if (self.TAG !== "Writing") {
    return self;
  }
  try {
    let writer = self._0.packString(value);
    return {
      TAG: "Writing",
      _0: writer
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          context,
          error: obj._1
        }
      };
    }
    throw obj;
  }
}
function slicedData(self) {
  if (self.TAG === "Writing") {
    return {
      TAG: "Ok",
      _0: self._0.slicedData
    };
  } else {
    return {
      TAG: "Error",
      _0: self._0
    };
  }
}
function make3(buffer) {
  return {
    TAG: "Writing",
    _0: new bufferwriter_default2(buffer)
  };
}
var map5 = /* @__PURE__ */ new Map([
  [
    0,
    false
  ],
  [
    1,
    false
  ],
  [
    2,
    false
  ],
  [
    3,
    true
  ],
  [
    4,
    true
  ],
  [
    5,
    true
  ],
  [
    6,
    false
  ],
  [
    7,
    false
  ],
  [
    8,
    false
  ],
  [
    9,
    false
  ],
  [
    10,
    true
  ],
  [
    11,
    true
  ],
  [
    12,
    true
  ],
  [
    13,
    true
  ],
  [
    14,
    true
  ],
  [
    15,
    true
  ],
  [
    16,
    true
  ],
  [
    17,
    true
  ],
  [
    18,
    true
  ],
  [
    19,
    true
  ],
  [
    20,
    true
  ],
  [
    21,
    true
  ],
  [
    22,
    false
  ],
  [
    23,
    false
  ],
  [
    24,
    true
  ],
  [
    25,
    false
  ],
  [
    26,
    true
  ],
  [
    27,
    true
  ],
  [
    28,
    true
  ],
  [
    29,
    true
  ],
  [
    30,
    false
  ],
  [
    31,
    true
  ],
  [
    32,
    false
  ],
  [
    33,
    true
  ],
  [
    34,
    true
  ],
  [
    35,
    true
  ],
  [
    36,
    true
  ],
  [
    37,
    false
  ],
  [
    38,
    false
  ],
  [
    39,
    false
  ],
  [
    40,
    false
  ],
  [
    41,
    false
  ],
  [
    42,
    true
  ],
  [
    43,
    false
  ],
  [
    44,
    false
  ],
  [
    45,
    false
  ],
  [
    46,
    false
  ],
  [
    47,
    false
  ],
  [
    48,
    false
  ],
  [
    49,
    true
  ],
  [
    50,
    true
  ],
  [
    51,
    false
  ],
  [
    52,
    false
  ],
  [
    53,
    false
  ],
  [
    54,
    false
  ],
  [
    55,
    true
  ],
  [
    56,
    false
  ],
  [
    57,
    false
  ],
  [
    58,
    false
  ],
  [
    59,
    false
  ],
  [
    60,
    false
  ],
  [
    61,
    true
  ],
  [
    62,
    false
  ],
  [
    63,
    false
  ],
  [
    64,
    false
  ],
  [
    65,
    false
  ],
  [
    66,
    false
  ],
  [
    67,
    false
  ],
  [
    68,
    false
  ],
  [
    69,
    false
  ],
  [
    70,
    false
  ],
  [
    71,
    true
  ],
  [
    72,
    true
  ],
  [
    73,
    true
  ],
  [
    74,
    true
  ],
  [
    75,
    false
  ],
  [
    76,
    false
  ],
  [
    77,
    true
  ],
  [
    78,
    true
  ],
  [
    79,
    true
  ],
  [
    80,
    false
  ],
  [
    81,
    true
  ],
  [
    82,
    true
  ],
  [
    83,
    true
  ],
  [
    84,
    true
  ],
  [
    85,
    true
  ],
  [
    86,
    true
  ],
  [
    87,
    true
  ],
  [
    88,
    true
  ],
  [
    89,
    true
  ],
  [
    90,
    true
  ],
  [
    91,
    true
  ],
  [
    92,
    true
  ],
  [
    93,
    true
  ],
  [
    94,
    true
  ],
  [
    95,
    true
  ],
  [
    96,
    true
  ],
  [
    97,
    true
  ],
  [
    98,
    true
  ],
  [
    99,
    true
  ],
  [
    100,
    true
  ],
  [
    101,
    true
  ],
  [
    102,
    true
  ],
  [
    103,
    true
  ],
  [
    104,
    true
  ],
  [
    105,
    true
  ],
  [
    106,
    true
  ],
  [
    107,
    false
  ],
  [
    108,
    false
  ],
  [
    109,
    false
  ],
  [
    110,
    true
  ],
  [
    111,
    false
  ],
  [
    112,
    false
  ],
  [
    113,
    true
  ],
  [
    114,
    true
  ],
  [
    115,
    false
  ],
  [
    116,
    false
  ],
  [
    117,
    false
  ],
  [
    118,
    false
  ],
  [
    119,
    false
  ],
  [
    120,
    false
  ],
  [
    121,
    false
  ],
  [
    122,
    false
  ],
  [
    123,
    false
  ],
  [
    124,
    false
  ],
  [
    125,
    true
  ],
  [
    126,
    true
  ],
  [
    127,
    false
  ],
  [
    128,
    true
  ],
  [
    129,
    true
  ],
  [
    130,
    false
  ],
  [
    131,
    false
  ],
  [
    132,
    true
  ],
  [
    133,
    true
  ],
  [
    134,
    true
  ],
  [
    135,
    true
  ],
  [
    136,
    true
  ],
  [
    137,
    true
  ],
  [
    138,
    true
  ],
  [
    139,
    true
  ],
  [
    140,
    false
  ],
  [
    141,
    true
  ],
  [
    142,
    true
  ],
  [
    143,
    true
  ],
  [
    144,
    true
  ],
  [
    145,
    false
  ],
  [
    146,
    false
  ],
  [
    147,
    false
  ],
  [
    148,
    false
  ],
  [
    149,
    true
  ],
  [
    150,
    false
  ],
  [
    151,
    false
  ],
  [
    152,
    false
  ],
  [
    153,
    false
  ],
  [
    154,
    false
  ],
  [
    155,
    false
  ],
  [
    156,
    false
  ],
  [
    157,
    false
  ],
  [
    158,
    false
  ],
  [
    159,
    false
  ],
  [
    160,
    false
  ],
  [
    161,
    false
  ],
  [
    162,
    false
  ],
  [
    163,
    false
  ],
  [
    164,
    false
  ],
  [
    165,
    true
  ],
  [
    166,
    false
  ],
  [
    167,
    false
  ],
  [
    168,
    false
  ],
  [
    169,
    false
  ],
  [
    170,
    false
  ],
  [
    171,
    true
  ],
  [
    172,
    true
  ],
  [
    173,
    true
  ],
  [
    174,
    true
  ],
  [
    175,
    false
  ],
  [
    176,
    false
  ],
  [
    177,
    false
  ],
  [
    178,
    true
  ],
  [
    179,
    false
  ],
  [
    180,
    false
  ],
  [
    181,
    false
  ],
  [
    182,
    false
  ],
  [
    183,
    false
  ],
  [
    184,
    true
  ],
  [
    185,
    true
  ],
  [
    186,
    true
  ],
  [
    187,
    true
  ],
  [
    188,
    false
  ],
  [
    189,
    false
  ],
  [
    190,
    false
  ],
  [
    191,
    false
  ],
  [
    192,
    false
  ],
  [
    193,
    false
  ],
  [
    194,
    false
  ],
  [
    195,
    false
  ],
  [
    196,
    false
  ],
  [
    197,
    false
  ],
  [
    198,
    false
  ],
  [
    199,
    false
  ],
  [
    200,
    false
  ],
  [
    201,
    true
  ],
  [
    202,
    false
  ],
  [
    203,
    false
  ],
  [
    204,
    false
  ],
  [
    205,
    false
  ],
  [
    206,
    false
  ],
  [
    207,
    true
  ],
  [
    208,
    false
  ],
  [
    209,
    true
  ],
  [
    210,
    true
  ],
  [
    211,
    false
  ],
  [
    212,
    true
  ],
  [
    213,
    false
  ],
  [
    214,
    false
  ],
  [
    215,
    true
  ],
  [
    216,
    true
  ],
  [
    217,
    true
  ],
  [
    218,
    true
  ],
  [
    219,
    true
  ],
  [
    220,
    true
  ],
  [
    221,
    false
  ],
  [
    222,
    false
  ],
  [
    223,
    false
  ],
  [
    224,
    false
  ],
  [
    225,
    false
  ],
  [
    226,
    false
  ],
  [
    227,
    true
  ],
  [
    228,
    true
  ],
  [
    229,
    false
  ],
  [
    230,
    false
  ],
  [
    231,
    true
  ],
  [
    232,
    false
  ],
  [
    233,
    true
  ],
  [
    234,
    false
  ],
  [
    235,
    true
  ],
  [
    236,
    true
  ],
  [
    237,
    true
  ],
  [
    238,
    true
  ],
  [
    239,
    true
  ],
  [
    240,
    true
  ],
  [
    241,
    true
  ],
  [
    242,
    true
  ],
  [
    243,
    true
  ],
  [
    244,
    true
  ],
  [
    245,
    true
  ],
  [
    246,
    true
  ],
  [
    247,
    true
  ],
  [
    248,
    false
  ],
  [
    249,
    false
  ],
  [
    250,
    false
  ],
  [
    251,
    false
  ],
  [
    252,
    false
  ],
  [
    253,
    false
  ],
  [
    254,
    true
  ],
  [
    255,
    false
  ],
  [
    256,
    false
  ],
  [
    257,
    false
  ],
  [
    258,
    false
  ],
  [
    259,
    false
  ],
  [
    260,
    false
  ],
  [
    261,
    false
  ],
  [
    262,
    false
  ],
  [
    263,
    false
  ],
  [
    264,
    false
  ],
  [
    265,
    false
  ],
  [
    266,
    false
  ],
  [
    267,
    false
  ],
  [
    268,
    false
  ],
  [
    269,
    true
  ],
  [
    270,
    true
  ],
  [
    271,
    true
  ],
  [
    272,
    false
  ],
  [
    273,
    false
  ],
  [
    274,
    false
  ],
  [
    275,
    true
  ],
  [
    276,
    true
  ],
  [
    277,
    true
  ],
  [
    278,
    true
  ],
  [
    279,
    true
  ],
  [
    280,
    true
  ],
  [
    281,
    true
  ],
  [
    282,
    true
  ],
  [
    283,
    true
  ],
  [
    284,
    false
  ],
  [
    285,
    true
  ],
  [
    286,
    true
  ],
  [
    287,
    true
  ],
  [
    288,
    true
  ],
  [
    289,
    true
  ],
  [
    290,
    true
  ],
  [
    291,
    true
  ],
  [
    292,
    true
  ],
  [
    293,
    true
  ],
  [
    294,
    true
  ],
  [
    295,
    true
  ],
  [
    296,
    true
  ],
  [
    297,
    true
  ],
  [
    298,
    true
  ],
  [
    299,
    true
  ],
  [
    300,
    true
  ],
  [
    301,
    true
  ],
  [
    302,
    true
  ],
  [
    303,
    true
  ],
  [
    304,
    true
  ],
  [
    305,
    true
  ],
  [
    306,
    true
  ],
  [
    307,
    true
  ],
  [
    308,
    true
  ],
  [
    309,
    true
  ],
  [
    310,
    true
  ],
  [
    311,
    false
  ],
  [
    312,
    false
  ],
  [
    313,
    false
  ],
  [
    314,
    true
  ],
  [
    315,
    false
  ],
  [
    316,
    true
  ],
  [
    317,
    true
  ],
  [
    318,
    true
  ],
  [
    319,
    true
  ],
  [
    320,
    true
  ],
  [
    321,
    false
  ],
  [
    322,
    false
  ],
  [
    323,
    true
  ],
  [
    324,
    true
  ],
  [
    325,
    false
  ],
  [
    326,
    false
  ],
  [
    327,
    false
  ],
  [
    328,
    false
  ],
  [
    329,
    false
  ],
  [
    330,
    false
  ],
  [
    331,
    false
  ],
  [
    332,
    false
  ],
  [
    333,
    false
  ],
  [
    334,
    true
  ],
  [
    335,
    true
  ],
  [
    336,
    false
  ],
  [
    337,
    true
  ],
  [
    338,
    true
  ],
  [
    339,
    true
  ],
  [
    340,
    false
  ],
  [
    341,
    false
  ],
  [
    342,
    false
  ],
  [
    343,
    false
  ],
  [
    344,
    false
  ],
  [
    345,
    false
  ],
  [
    346,
    false
  ],
  [
    347,
    false
  ],
  [
    348,
    false
  ],
  [
    349,
    true
  ],
  [
    350,
    false
  ],
  [
    351,
    false
  ],
  [
    352,
    false
  ],
  [
    353,
    false
  ],
  [
    354,
    true
  ],
  [
    355,
    true
  ],
  [
    356,
    true
  ],
  [
    357,
    false
  ],
  [
    358,
    true
  ],
  [
    359,
    true
  ],
  [
    360,
    true
  ],
  [
    361,
    true
  ],
  [
    362,
    true
  ],
  [
    363,
    true
  ],
  [
    364,
    true
  ],
  [
    365,
    false
  ],
  [
    366,
    false
  ],
  [
    367,
    false
  ],
  [
    368,
    false
  ],
  [
    369,
    false
  ],
  [
    370,
    false
  ],
  [
    371,
    false
  ],
  [
    372,
    true
  ],
  [
    373,
    true
  ],
  [
    374,
    true
  ],
  [
    375,
    true
  ],
  [
    376,
    true
  ],
  [
    377,
    true
  ],
  [
    378,
    true
  ],
  [
    379,
    false
  ],
  [
    380,
    true
  ],
  [
    381,
    false
  ],
  [
    382,
    false
  ],
  [
    383,
    false
  ],
  [
    384,
    false
  ],
  [
    385,
    false
  ],
  [
    386,
    true
  ],
  [
    387,
    true
  ],
  [
    388,
    true
  ],
  [
    389,
    true
  ],
  [
    390,
    true
  ],
  [
    391,
    true
  ],
  [
    392,
    true
  ],
  [
    393,
    true
  ],
  [
    394,
    true
  ],
  [
    395,
    true
  ],
  [
    396,
    false
  ],
  [
    397,
    false
  ],
  [
    398,
    false
  ],
  [
    399,
    false
  ],
  [
    400,
    false
  ],
  [
    401,
    false
  ],
  [
    402,
    false
  ],
  [
    403,
    false
  ],
  [
    404,
    false
  ],
  [
    405,
    true
  ],
  [
    406,
    true
  ],
  [
    407,
    false
  ],
  [
    408,
    false
  ],
  [
    409,
    false
  ],
  [
    410,
    true
  ],
  [
    411,
    true
  ],
  [
    412,
    true
  ],
  [
    413,
    true
  ],
  [
    414,
    true
  ],
  [
    415,
    false
  ],
  [
    416,
    false
  ],
  [
    417,
    false
  ],
  [
    418,
    false
  ],
  [
    419,
    true
  ],
  [
    420,
    true
  ],
  [
    421,
    false
  ],
  [
    422,
    false
  ],
  [
    423,
    true
  ],
  [
    424,
    true
  ],
  [
    425,
    true
  ],
  [
    426,
    false
  ],
  [
    427,
    true
  ],
  [
    428,
    true
  ],
  [
    429,
    true
  ],
  [
    430,
    false
  ],
  [
    431,
    false
  ],
  [
    432,
    false
  ],
  [
    433,
    false
  ],
  [
    434,
    false
  ],
  [
    435,
    true
  ],
  [
    436,
    true
  ],
  [
    437,
    true
  ],
  [
    438,
    true
  ],
  [
    439,
    true
  ],
  [
    440,
    true
  ],
  [
    441,
    true
  ],
  [
    442,
    true
  ],
  [
    443,
    true
  ],
  [
    444,
    true
  ],
  [
    445,
    true
  ],
  [
    446,
    false
  ],
  [
    447,
    false
  ],
  [
    448,
    false
  ],
  [
    449,
    false
  ],
  [
    450,
    false
  ],
  [
    451,
    false
  ],
  [
    452,
    true
  ],
  [
    453,
    true
  ],
  [
    454,
    true
  ],
  [
    455,
    true
  ],
  [
    456,
    true
  ],
  [
    457,
    true
  ],
  [
    458,
    false
  ],
  [
    459,
    false
  ],
  [
    460,
    false
  ],
  [
    461,
    true
  ],
  [
    462,
    true
  ],
  [
    463,
    true
  ],
  [
    464,
    true
  ],
  [
    465,
    true
  ],
  [
    466,
    true
  ],
  [
    467,
    true
  ],
  [
    468,
    true
  ],
  [
    469,
    true
  ],
  [
    470,
    true
  ],
  [
    471,
    true
  ],
  [
    472,
    false
  ],
  [
    473,
    false
  ],
  [
    474,
    false
  ],
  [
    475,
    true
  ],
  [
    476,
    true
  ],
  [
    477,
    false
  ],
  [
    478,
    false
  ],
  [
    479,
    false
  ],
  [
    480,
    true
  ],
  [
    481,
    false
  ],
  [
    482,
    false
  ],
  [
    483,
    false
  ],
  [
    484,
    true
  ],
  [
    485,
    true
  ],
  [
    486,
    true
  ],
  [
    487,
    true
  ],
  [
    488,
    true
  ],
  [
    489,
    true
  ],
  [
    490,
    true
  ],
  [
    491,
    true
  ],
  [
    492,
    false
  ],
  [
    493,
    true
  ],
  [
    494,
    true
  ],
  [
    495,
    false
  ],
  [
    496,
    false
  ],
  [
    497,
    true
  ],
  [
    498,
    false
  ],
  [
    499,
    true
  ],
  [
    500,
    false
  ],
  [
    501,
    false
  ],
  [
    502,
    false
  ],
  [
    503,
    false
  ],
  [
    504,
    false
  ],
  [
    505,
    true
  ],
  [
    506,
    true
  ],
  [
    507,
    false
  ],
  [
    508,
    false
  ],
  [
    509,
    true
  ],
  [
    510,
    true
  ],
  [
    511,
    true
  ],
  [
    512,
    false
  ],
  [
    513,
    false
  ],
  [
    514,
    false
  ],
  [
    515,
    false
  ],
  [
    516,
    false
  ],
  [
    517,
    false
  ],
  [
    518,
    true
  ],
  [
    519,
    true
  ],
  [
    520,
    true
  ],
  [
    521,
    true
  ],
  [
    522,
    true
  ],
  [
    523,
    true
  ],
  [
    524,
    true
  ],
  [
    525,
    true
  ],
  [
    526,
    true
  ],
  [
    527,
    true
  ],
  [
    528,
    false
  ],
  [
    529,
    true
  ],
  [
    530,
    true
  ],
  [
    531,
    true
  ],
  [
    532,
    true
  ],
  [
    533,
    true
  ],
  [
    534,
    false
  ],
  [
    535,
    false
  ],
  [
    536,
    false
  ],
  [
    537,
    false
  ],
  [
    538,
    true
  ],
  [
    539,
    false
  ],
  [
    540,
    false
  ],
  [
    541,
    false
  ],
  [
    542,
    true
  ],
  [
    543,
    true
  ],
  [
    544,
    true
  ],
  [
    545,
    true
  ],
  [
    546,
    false
  ],
  [
    547,
    true
  ],
  [
    548,
    true
  ],
  [
    549,
    true
  ],
  [
    550,
    true
  ],
  [
    551,
    true
  ],
  [
    552,
    true
  ],
  [
    553,
    true
  ],
  [
    554,
    true
  ],
  [
    555,
    true
  ],
  [
    556,
    true
  ],
  [
    557,
    false
  ],
  [
    558,
    true
  ],
  [
    559,
    true
  ],
  [
    560,
    true
  ],
  [
    561,
    false
  ],
  [
    562,
    false
  ],
  [
    563,
    false
  ],
  [
    564,
    true
  ],
  [
    565,
    true
  ],
  [
    566,
    false
  ],
  [
    567,
    true
  ],
  [
    568,
    true
  ],
  [
    569,
    true
  ],
  [
    570,
    true
  ],
  [
    571,
    true
  ],
  [
    572,
    true
  ],
  [
    573,
    true
  ],
  [
    574,
    false
  ],
  [
    575,
    false
  ],
  [
    576,
    false
  ],
  [
    577,
    false
  ],
  [
    578,
    false
  ],
  [
    579,
    true
  ],
  [
    580,
    true
  ],
  [
    581,
    true
  ],
  [
    582,
    true
  ],
  [
    583,
    true
  ],
  [
    584,
    true
  ],
  [
    585,
    true
  ],
  [
    586,
    true
  ],
  [
    587,
    true
  ],
  [
    588,
    true
  ],
  [
    589,
    true
  ],
  [
    590,
    true
  ],
  [
    591,
    true
  ],
  [
    592,
    true
  ],
  [
    593,
    true
  ],
  [
    594,
    true
  ],
  [
    595,
    true
  ],
  [
    596,
    true
  ],
  [
    597,
    true
  ],
  [
    598,
    true
  ],
  [
    599,
    true
  ],
  [
    600,
    true
  ],
  [
    601,
    true
  ],
  [
    602,
    true
  ],
  [
    603,
    true
  ],
  [
    604,
    true
  ],
  [
    605,
    true
  ],
  [
    606,
    true
  ],
  [
    607,
    true
  ],
  [
    608,
    true
  ],
  [
    609,
    true
  ],
  [
    610,
    true
  ],
  [
    611,
    true
  ],
  [
    612,
    true
  ],
  [
    613,
    true
  ],
  [
    614,
    true
  ],
  [
    615,
    true
  ],
  [
    616,
    true
  ],
  [
    617,
    true
  ],
  [
    618,
    false
  ],
  [
    619,
    true
  ],
  [
    620,
    true
  ],
  [
    621,
    true
  ],
  [
    622,
    true
  ],
  [
    623,
    true
  ],
  [
    624,
    true
  ],
  [
    625,
    false
  ],
  [
    626,
    false
  ],
  [
    627,
    false
  ],
  [
    628,
    false
  ],
  [
    629,
    true
  ],
  [
    630,
    true
  ],
  [
    631,
    true
  ],
  [
    632,
    true
  ],
  [
    633,
    false
  ],
  [
    634,
    true
  ],
  [
    635,
    false
  ],
  [
    636,
    false
  ],
  [
    637,
    true
  ],
  [
    638,
    false
  ],
  [
    639,
    true
  ],
  [
    640,
    true
  ],
  [
    641,
    false
  ],
  [
    642,
    true
  ],
  [
    643,
    true
  ],
  [
    644,
    true
  ],
  [
    645,
    true
  ],
  [
    646,
    true
  ],
  [
    647,
    true
  ],
  [
    648,
    true
  ],
  [
    649,
    true
  ],
  [
    650,
    true
  ],
  [
    651,
    true
  ],
  [
    652,
    true
  ],
  [
    653,
    true
  ],
  [
    654,
    true
  ],
  [
    655,
    false
  ],
  [
    656,
    true
  ],
  [
    657,
    true
  ],
  [
    658,
    true
  ],
  [
    659,
    false
  ],
  [
    660,
    true
  ],
  [
    661,
    false
  ],
  [
    662,
    false
  ],
  [
    663,
    true
  ],
  [
    664,
    true
  ],
  [
    665,
    true
  ],
  [
    666,
    false
  ],
  [
    667,
    false
  ],
  [
    668,
    false
  ],
  [
    669,
    false
  ],
  [
    670,
    false
  ],
  [
    671,
    false
  ],
  [
    672,
    false
  ],
  [
    673,
    false
  ],
  [
    674,
    false
  ],
  [
    675,
    false
  ],
  [
    676,
    false
  ],
  [
    677,
    false
  ],
  [
    678,
    false
  ],
  [
    679,
    false
  ],
  [
    680,
    false
  ],
  [
    681,
    false
  ],
  [
    682,
    false
  ],
  [
    683,
    false
  ],
  [
    684,
    false
  ],
  [
    685,
    false
  ],
  [
    686,
    false
  ],
  [
    687,
    false
  ],
  [
    688,
    false
  ],
  [
    689,
    false
  ],
  [
    690,
    false
  ],
  [
    691,
    false
  ],
  [
    692,
    false
  ]
]);
function isImportant2(tileType) {
  return getOr(map5.get(tileType), false);
}
function defaultTileCache() {
  return {
    activeTile: void 0,
    color: void 0,
    wallColor: void 0,
    wall: void 0,
    liquid: void 0,
    lava: false,
    honey: false,
    shimmer: false,
    wire: false,
    wire2: false,
    wire3: false,
    wire4: false,
    halfBrick: false,
    slope: void 0,
    actuator: false,
    inActive: false,
    invisibleBlock: false,
    invisibleWall: false,
    fullbrightBlock: false,
    fullbrightWall: false,
    coatHeader: 0
  };
}
function cacheToTile(cache) {
  return {
    activeTile: cache.activeTile,
    color: cache.color,
    wallColor: cache.wallColor,
    wall: cache.wall,
    liquid: cache.liquid,
    lava: cache.lava,
    honey: cache.honey,
    shimmer: cache.shimmer,
    wire: cache.wire,
    wire2: cache.wire2,
    wire3: cache.wire3,
    wire4: cache.wire4,
    halfBrick: cache.halfBrick,
    slope: cache.slope,
    actuator: cache.actuator,
    inActive: cache.inActive,
    invisibleBlock: cache.invisibleBlock,
    invisibleWall: cache.invisibleWall,
    fullbrightBlock: cache.fullbrightBlock,
    fullbrightWall: cache.fullbrightWall,
    coatHeader: cache.coatHeader
  };
}
function parse66(reader) {
  let e = readInt162(reader, "id");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt162(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt162(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readString2(reader, "name");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        id: e._0,
        x: e$1._0,
        y: e$2._0,
        name: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function pack3(writer, chest) {
  return packString2(packInt162(packInt162(packInt162(writer, chest.id, "id"), chest.x, "x"), chest.y, "y"), chest.name, "name");
}
function parse$12(reader) {
  let e = readInt162(reader, "id");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt162(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt162(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readString2(reader, "name");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        id: e._0,
        x: e$1._0,
        y: e$2._0,
        name: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function pack$12(writer, sign) {
  return packString2(packInt162(packInt162(packInt162(writer, sign.id, "id"), sign.x, "x"), sign.y, "y"), sign.name, "name");
}
var Chest = {
  parse: parse66,
  pack: pack3
};
var Sign = {
  parse: parse$12,
  pack: pack$12
};
function parseTrainingDummyKind(reader) {
  let e = readInt162(reader, "npcSlotId");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcSlotId: e._0
      }
    };
  } else {
    return e;
  }
}
function parseDisplayItem(reader) {
  let e = readInt162(reader, "netId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte2(reader, "prefix");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt162(reader, "stack");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        netId: e._0,
        prefix: e$1._0,
        stack: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function parseLogicSensorKind(reader) {
  let e = readByte2(reader, "checkType");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte2(reader, "on");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        checkType: e._0,
        on: e$1._0 === 1
      }
    };
  } else {
    return e$1;
  }
}
function parseDisplayDollKind(reader) {
  let e = readByte2(reader, "itemsFlags");
  if (e.TAG !== "Ok") {
    return e;
  }
  let itemsFlags = fromByte(e._0);
  let e$1 = readByte2(reader, "dyeFlags");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let dyeFlags = fromByte(e$1._0);
  let e$2 = readByte2(reader, "pose");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte2(reader, "extraFlags");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let extraFlags = fromByte(e$3._0);
  let items = [];
  let dyes = [];
  let misc = [];
  let parseResult = {
    TAG: "Ok",
    _0: void 0
  };
  for (let i = 0; i <= 7; ++i) {
    let match = parseResult;
    if (match.TAG === "Ok") {
      if (flagN(itemsFlags, 1 << i)) {
        let item = parseDisplayItem(reader);
        if (item.TAG === "Ok") {
          items.push(item._0);
        } else {
          parseResult = {
            TAG: "Error",
            _0: item._0
          };
        }
      } else {
        items.push(void 0);
      }
    }
  }
  let match$1 = parseResult;
  if (match$1.TAG === "Ok") {
    if (flag2(extraFlags)) {
      let item$1 = parseDisplayItem(reader);
      if (item$1.TAG === "Ok") {
        items.push(item$1._0);
      } else {
        parseResult = {
          TAG: "Error",
          _0: item$1._0
        };
      }
    } else {
      items.push(void 0);
    }
  }
  for (let i$1 = 0; i$1 <= 7; ++i$1) {
    let match$2 = parseResult;
    if (match$2.TAG === "Ok") {
      if (flagN(dyeFlags, 1 << i$1)) {
        let item$2 = parseDisplayItem(reader);
        if (item$2.TAG === "Ok") {
          dyes.push(item$2._0);
        } else {
          parseResult = {
            TAG: "Error",
            _0: item$2._0
          };
        }
      } else {
        dyes.push(void 0);
      }
    }
  }
  let match$3 = parseResult;
  if (match$3.TAG === "Ok") {
    if (flag3(extraFlags)) {
      let item$3 = parseDisplayItem(reader);
      if (item$3.TAG === "Ok") {
        dyes.push(item$3._0);
      } else {
        parseResult = {
          TAG: "Error",
          _0: item$3._0
        };
      }
    } else {
      dyes.push(void 0);
    }
  }
  let match$4 = parseResult;
  if (match$4.TAG === "Ok") {
    if (flag1(extraFlags)) {
      let item$4 = parseDisplayItem(reader);
      if (item$4.TAG === "Ok") {
        misc.push(item$4._0);
      } else {
        parseResult = {
          TAG: "Error",
          _0: item$4._0
        };
      }
    } else {
      misc.push(void 0);
    }
  }
  let err = parseResult;
  if (err.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        items,
        dyes,
        misc,
        pose: e$2._0
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: err._0
    };
  }
}
function parseHatRackKind(reader) {
  let e = readByte2(reader, "flags");
  if (e.TAG !== "Ok") {
    return e;
  }
  let flags = fromByte(e._0);
  let items = [];
  let dyes = [];
  let parseResult = {
    TAG: "Ok",
    _0: void 0
  };
  for (let i = 0; i <= 1; ++i) {
    let match = parseResult;
    if (match.TAG === "Ok") {
      if (flagN(flags, 1 << i)) {
        let item = parseDisplayItem(reader);
        if (item.TAG === "Ok") {
          items.push(item._0);
        } else {
          parseResult = {
            TAG: "Error",
            _0: item._0
          };
        }
      } else {
        items.push(void 0);
      }
    }
  }
  for (let i$1 = 0; i$1 <= 1; ++i$1) {
    let match$1 = parseResult;
    if (match$1.TAG === "Ok") {
      if (flagN(flags, 1 << (i$1 + 2 | 0))) {
        let item$1 = parseDisplayItem(reader);
        if (item$1.TAG === "Ok") {
          dyes.push(item$1._0);
        } else {
          parseResult = {
            TAG: "Error",
            _0: item$1._0
          };
        }
      } else {
        dyes.push(void 0);
      }
    }
  }
  let err = parseResult;
  if (err.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        items,
        dyes
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: err._0
    };
  }
}
function parseLeashedEntityAnchorKind(reader) {
  let e = readInt162(reader, "itemType");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        itemType: e._0
      }
    };
  } else {
    return e;
  }
}
function parseEntityKind(entityType, reader) {
  switch (entityType) {
    case 0:
      return map(parseTrainingDummyKind(reader), (v) => ({
        TAG: "TrainingDummy",
        _0: v
      }));
    case 1:
      return map(parseDisplayItem(reader), (v) => ({
        TAG: "ItemFrame",
        _0: v
      }));
    case 2:
      return map(parseLogicSensorKind(reader), (v) => ({
        TAG: "LogicSensor",
        _0: v
      }));
    case 3:
      return map(parseDisplayDollKind(reader), (v) => ({
        TAG: "DisplayDoll",
        _0: v
      }));
    case 4:
      return map(parseDisplayItem(reader), (v) => ({
        TAG: "WeaponsRack",
        _0: v
      }));
    case 5:
      return map(parseHatRackKind(reader), (v) => ({
        TAG: "HatRack",
        _0: v
      }));
    case 6:
      return map(parseDisplayItem(reader), (v) => ({
        TAG: "FoodPlatter",
        _0: v
      }));
    case 7:
      return {
        TAG: "Ok",
        _0: {
          TAG: "TeleportationPylon",
          _0: void 0
        }
      };
    case 8:
      return map(parseDisplayItem(reader), (v) => ({
        TAG: "DeadCellsDisplayJar",
        _0: v
      }));
    case 9:
      return map(parseLeashedEntityAnchorKind(reader), (v) => ({
        TAG: "KiteAnchor",
        _0: v
      }));
    case 10:
      return map(parseLeashedEntityAnchorKind(reader), (v) => ({
        TAG: "CritterAnchor",
        _0: v
      }));
    default:
      return {
        TAG: "Error",
        _0: {
          context: "Entity.parse",
          error: new Error("Unknown entity kind: " + entityType.toString())
        }
      };
  }
}
function parse67(reader) {
  let e = readByte2(reader, "entityType");
  if (e.TAG !== "Ok") {
    return e;
  }
  let entityType = e._0;
  let e$1 = readInt322(reader, "id");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt162(reader, "x");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt162(reader, "y");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = parseEntityKind(entityType, reader);
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let entity_id = e$1._0;
  let entity_x = e$2._0;
  let entity_y = e$3._0;
  let entity_entityKind = e$4._0;
  let entity = {
    entityType,
    id: entity_id,
    x: entity_x,
    y: entity_y,
    entityKind: entity_entityKind
  };
  return {
    TAG: "Ok",
    _0: entity
  };
}
function packDisplayItem(writer, displayItem) {
  return packInt162(packByte2(packInt162(writer, displayItem.netId, "netId"), displayItem.prefix, "prefix"), displayItem.stack, "stack");
}
function hasItem(arr, n) {
  return isSome(flatMap(arr[n], (a) => a));
}
function pack4(writer, entity) {
  let writer$1 = packInt162(packInt162(packInt322(packByte2(writer, entity.entityType, "entityType"), entity.id, "id"), entity.x, "x"), entity.y, "y");
  let entityKind = entity.entityKind;
  switch (entityKind.TAG) {
    case "DisplayDoll":
      let displayDollKind = entityKind._0;
      let itemFlags = fromFlags(hasItem(displayDollKind.items, 0), hasItem(displayDollKind.items, 1), hasItem(displayDollKind.items, 2), hasItem(displayDollKind.items, 3), hasItem(displayDollKind.items, 4), hasItem(displayDollKind.items, 5), hasItem(displayDollKind.items, 6), hasItem(displayDollKind.items, 7));
      let dyeFlags = fromFlags(hasItem(displayDollKind.dyes, 0), hasItem(displayDollKind.dyes, 1), hasItem(displayDollKind.dyes, 2), hasItem(displayDollKind.dyes, 3), hasItem(displayDollKind.dyes, 4), hasItem(displayDollKind.dyes, 5), hasItem(displayDollKind.dyes, 6), hasItem(displayDollKind.dyes, 7));
      let extraFlags = fromFlags(hasItem(displayDollKind.misc, 0), hasItem(displayDollKind.items, 8), hasItem(displayDollKind.dyes, 8), false, false, false, false, false);
      packByte2(packByte2(packByte2(packByte2(writer$1, toByte(itemFlags), "itemFlags"), toByte(dyeFlags), "dyeFlags"), displayDollKind.pose, "pose"), toByte(extraFlags), "extraFlags");
      for (let i = 0; i <= 7; ++i) {
        let item = flatMap(displayDollKind.items[i], (a) => a);
        if (item !== void 0) {
          packDisplayItem(writer$1, item);
        }
      }
      let item$1 = flatMap(displayDollKind.items[8], (a) => a);
      if (item$1 !== void 0) {
        packDisplayItem(writer$1, item$1);
      }
      for (let i$1 = 0; i$1 <= 7; ++i$1) {
        let item$2 = flatMap(displayDollKind.dyes[i$1], (a) => a);
        if (item$2 !== void 0) {
          packDisplayItem(writer$1, item$2);
        }
      }
      let item$3 = flatMap(displayDollKind.dyes[8], (a) => a);
      if (item$3 !== void 0) {
        packDisplayItem(writer$1, item$3);
      }
      let item$4 = flatMap(displayDollKind.misc[0], (a) => a);
      if (item$4 !== void 0) {
        packDisplayItem(writer$1, item$4);
      }
      return writer$1;
    case "HatRack":
      let hatRackKind = entityKind._0;
      let flags = fromFlags(hasItem(hatRackKind.items, 0), hasItem(hatRackKind.items, 1), hasItem(hatRackKind.dyes, 0), hasItem(hatRackKind.dyes, 1), false, false, false, false);
      packByte2(writer$1, toByte(flags), "flags");
      for (let i$2 = 0; i$2 <= 1; ++i$2) {
        let item$5 = flatMap(hatRackKind.items[i$2], (a) => a);
        if (item$5 !== void 0) {
          packDisplayItem(writer$1, item$5);
        }
      }
      for (let i$3 = 0; i$3 <= 1; ++i$3) {
        let item$6 = flatMap(hatRackKind.dyes[i$3], (a) => a);
        if (item$6 !== void 0) {
          packDisplayItem(writer$1, item$6);
        }
      }
      return writer$1;
    case "LogicSensor":
      let logicSensorKind = entityKind._0;
      return packByte2(packByte2(writer$1, logicSensorKind.checkType, "checkType"), logicSensorKind.on ? 1 : 0, "on");
    case "TeleportationPylon":
      return writer$1;
    case "TrainingDummy":
      let trainingDummy = entityKind._0;
      return packInt162(writer$1, trainingDummy.npcSlotId, "npcSlotId");
    case "FoodPlatter":
    case "ItemFrame":
    case "WeaponsRack":
    case "DeadCellsDisplayJar":
      return packDisplayItem(writer$1, entityKind._0);
    case "KiteAnchor":
    case "CritterAnchor":
      let leashedEntityAnchor = entityKind._0;
      return packInt162(writer$1, leashedEntityAnchor.itemType, "itemType");
  }
}
function isTheSameAs(self, compTile) {
  let sameHeaders = isSome(self.activeTile) === isSome(compTile.activeTile) && self.inActive === compTile.inActive && self.wire === compTile.wire && self.wire2 === compTile.wire2 && self.wire3 === compTile.wire3 && self.halfBrick === compTile.halfBrick && equal(self.slope, compTile.slope) && self.actuator === compTile.actuator && equal(self.color, compTile.color);
  if (!sameHeaders) {
    return false;
  }
  let match = self.activeTile;
  let match$1 = compTile.activeTile;
  let activeMatches = match !== void 0 ? match$1 !== void 0 && match.tileType === match$1.tileType ? isImportant(match.tileType) ? equal(match.frame, match$1.frame) : true : false : match$1 === void 0;
  if (!activeMatches) {
    return false;
  }
  if (notequal(self.wall, compTile.wall) || notequal(self.liquid, compTile.liquid)) {
    return false;
  }
  let sameWallColor = equal(self.wallColor, compTile.wallColor);
  let sameWire4 = self.wire4 === compTile.wire4;
  let match$2 = compTile.liquid;
  let liquidMatches = match$2 !== void 0 ? sameWallColor && sameWire4 && self.lava === compTile.lava && self.honey === compTile.honey && self.shimmer === compTile.shimmer : sameWallColor && sameWire4;
  if (!liquidMatches || self.invisibleBlock !== compTile.invisibleBlock || self.invisibleWall !== compTile.invisibleWall || self.fullbrightBlock !== compTile.fullbrightBlock) {
    return false;
  } else {
    return self.fullbrightWall === compTile.fullbrightWall;
  }
}
function clearTileCache(tile) {
  tile.activeTile = void 0;
  tile.color = void 0;
  tile.wallColor = void 0;
  tile.wall = void 0;
  tile.liquid = void 0;
  tile.lava = false;
  tile.honey = false;
  tile.shimmer = false;
  tile.wire = false;
  tile.wire2 = false;
  tile.wire3 = false;
  tile.wire4 = false;
  tile.halfBrick = false;
  tile.slope = void 0;
  tile.actuator = false;
  tile.inActive = false;
  tile.invisibleBlock = false;
  tile.invisibleWall = false;
  tile.fullbrightBlock = false;
  tile.fullbrightWall = false;
  tile.coatHeader = 0;
}
function readRepeated(count, parseItem) {
  let items = [];
  let parseResult = {
    TAG: "Ok",
    _0: void 0
  };
  for (let _i = 0; _i < count; ++_i) {
    let match = parseResult;
    if (match.TAG === "Ok") {
      let item = parseItem();
      if (item.TAG === "Ok") {
        items.push(item._0);
      } else {
        parseResult = {
          TAG: "Error",
          _0: item._0
        };
      }
    }
  }
  let err = parseResult;
  if (err.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: items
    };
  } else {
    return {
      TAG: "Error",
      _0: err._0
    };
  }
}
function parse$13(payload) {
  let packetReader = new packetreader_default(payload);
  let e = getBytesLeft(packetReader);
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readBuffer(packetReader, e._0, "deflatedPayload");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let inflated;
  try {
    inflated = {
      TAG: "Ok",
      _0: Nodezlib.inflateRawSync(e$1._0)
    };
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      inflated = {
        TAG: "Error",
        _0: {
          context: "inflateRawSync",
          error: obj._1
        }
      };
    } else {
      throw obj;
    }
  }
  if (inflated.TAG !== "Ok") {
    return inflated;
  }
  let reader = new bufferreader_default2(inflated._0);
  let e$2 = readInt322(reader, "tileX");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt322(reader, "tileY");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt162(reader, "width");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let width = e$4._0;
  let e$5 = readInt162(reader, "height");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let height = e$5._0;
  let tiles = [];
  let tileCache = defaultTileCache();
  let rleCount = {
    contents: 0
  };
  if (height < 0 || width < 0) {
    return {
      TAG: "Error",
      _0: {
        context: "Packet_TileSectionSend.parse",
        error: new Error("Tile section dimensions must be non-negative")
      }
    };
  }
  let parseResult = {
    TAG: "Ok",
    _0: void 0
  };
  let readTile = () => {
    clearTileCache(tileCache);
    let e2 = readByte2(reader, "header5");
    if (e2.TAG !== "Ok") {
      return e2;
    }
    let header5 = fromByte(e2._0);
    let e$16;
    if (flag1(header5)) {
      let e$22 = readByte2(reader, "header4_conditional");
      if (e$22.TAG === "Ok") {
        let header4 = fromByte(e$22._0);
        let e$32;
        if (flag1(header4)) {
          let e$42 = readByte2(reader, "header3_conditional");
          if (e$42.TAG === "Ok") {
            let header3 = fromByte(e$42._0);
            let e$52 = flag1(header3) ? readByte2(reader, "header2_conditional") : {
              TAG: "Ok",
              _0: 0
            };
            e$32 = e$52.TAG === "Ok" ? {
              TAG: "Ok",
              _0: [
                header3,
                e$52._0
              ]
            } : e$52;
          } else {
            e$32 = e$42;
          }
        } else {
          e$32 = {
            TAG: "Ok",
            _0: [
              fromByte(0),
              0
            ]
          };
        }
        if (e$32.TAG === "Ok") {
          let match = e$32._0;
          e$16 = {
            TAG: "Ok",
            _0: [
              header4,
              match[0],
              match[1]
            ]
          };
        } else {
          e$16 = e$32;
        }
      } else {
        e$16 = e$22;
      }
    } else {
      e$16 = {
        TAG: "Ok",
        _0: [
          fromByte(0),
          fromByte(0),
          0
        ]
      };
    }
    if (e$16.TAG !== "Ok") {
      return e$16;
    }
    let match$1 = e$16._0;
    let header2 = match$1[2];
    let header3$1 = match$1[1];
    let header4$1 = match$1[0];
    tileCache.coatHeader = header2;
    tileCache.invisibleBlock = (header2 & 2) !== 0;
    tileCache.invisibleWall = (header2 & 4) !== 0;
    tileCache.fullbrightBlock = (header2 & 8) !== 0;
    tileCache.fullbrightWall = (header2 & 16) !== 0;
    let oldActive = tileCache.activeTile;
    let e$62;
    if (flag2(header5)) {
      let oldType = mapOr(tileCache.activeTile, 0, (active) => active.tileType);
      let e$72;
      if (flag6(header5)) {
        let e$82 = readByte2(reader, "tileType_byte1");
        if (e$82.TAG === "Ok") {
          let e$92 = readByte2(reader, "tileType_byte2");
          e$72 = e$92.TAG === "Ok" ? {
            TAG: "Ok",
            _0: e$92._0 << 8 | e$82._0
          } : e$92;
        } else {
          e$72 = e$82;
        }
      } else {
        e$72 = readByte2(reader, "tileType");
      }
      if (e$72.TAG === "Ok") {
        let tileType = e$72._0;
        let e$102;
        if (isImportant(tileType)) {
          let e$112 = readInt162(reader, "frameX");
          if (e$112.TAG === "Ok") {
            let e$122 = readInt162(reader, "frameY");
            e$102 = e$122.TAG === "Ok" ? {
              TAG: "Ok",
              _0: {
                x: e$112._0,
                y: e$122._0
              }
            } : e$122;
          } else {
            e$102 = e$112;
          }
        } else {
          e$102 = isSome(oldActive) && tileType === oldType ? {
            TAG: "Ok",
            _0: oldActive.frame
          } : {
            TAG: "Ok",
            _0: void 0
          };
        }
        if (e$102.TAG === "Ok") {
          let e$132;
          if (flag4(header3$1)) {
            let e$142 = readByte2(reader, "color");
            if (e$142.TAG === "Ok") {
              tileCache.color = e$142._0;
              e$132 = {
                TAG: "Ok",
                _0: void 0
              };
            } else {
              e$132 = e$142;
            }
          } else {
            e$132 = {
              TAG: "Ok",
              _0: void 0
            };
          }
          if (e$132.TAG === "Ok") {
            tileCache.activeTile = {
              tileType,
              frame: e$102._0
            };
            e$62 = {
              TAG: "Ok",
              _0: void 0
            };
          } else {
            e$62 = e$132;
          }
        } else {
          e$62 = e$102;
        }
      } else {
        e$62 = e$72;
      }
    } else {
      e$62 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$62.TAG !== "Ok") {
      return e$62;
    }
    let e$152;
    if (flag3(header5)) {
      let e$162 = readByte2(reader, "wall");
      if (e$162.TAG === "Ok") {
        tileCache.wall = e$162._0;
        if (flag5(header3$1)) {
          let e$17 = readByte2(reader, "wallColor");
          if (e$17.TAG === "Ok") {
            tileCache.wallColor = e$17._0;
            e$152 = {
              TAG: "Ok",
              _0: void 0
            };
          } else {
            e$152 = e$17;
          }
        } else {
          e$152 = {
            TAG: "Ok",
            _0: void 0
          };
        }
      } else {
        e$152 = e$162;
      }
    } else {
      e$152 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$152.TAG !== "Ok") {
      return e$152;
    }
    let liquidBits = (toByte(header5) & 24) >> 3;
    let e$18;
    if (liquidBits !== 0) {
      let e$19 = readByte2(reader, "liquidValue");
      if (e$19.TAG === "Ok") {
        tileCache.liquid = e$19._0;
        if (flag8(header3$1)) {
          tileCache.shimmer = true;
        } else if (liquidBits > 1) {
          if (liquidBits === 2) {
            tileCache.lava = true;
          } else {
            tileCache.honey = true;
          }
        }
        e$18 = {
          TAG: "Ok",
          _0: void 0
        };
      } else {
        e$18 = e$19;
      }
    } else {
      e$18 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$18.TAG !== "Ok") {
      return e$18;
    }
    if (toByte(header4$1) > 1) {
      if (flag2(header4$1)) {
        tileCache.wire = true;
      }
      if (flag3(header4$1)) {
        tileCache.wire2 = true;
      }
      if (flag4(header4$1)) {
        tileCache.wire3 = true;
      }
      let slopeBits = (toByte(header4$1) & 112) >> 4;
      if (slopeBits !== 0 && isSolid(mapOr(tileCache.activeTile, 0, (tile) => tile.tileType))) {
        if (slopeBits === 1) {
          tileCache.halfBrick = true;
        } else {
          tileCache.slope = slopeBits - 1 | 0;
        }
      }
    }
    let e$20;
    if (toByte(header3$1) > 0) {
      if (flag2(header3$1)) {
        tileCache.actuator = true;
      }
      if (flag3(header3$1)) {
        tileCache.inActive = true;
      }
      if (flag6(header3$1)) {
        tileCache.wire4 = true;
      }
      let e$21;
      if (flag7(header3$1)) {
        let e$22 = readByte2(reader, "wall_highByte");
        if (e$22.TAG === "Ok") {
          tileCache.wall = e$22._0 << 8 | tileCache.wall;
          e$21 = {
            TAG: "Ok",
            _0: void 0
          };
        } else {
          e$21 = e$22;
        }
      } else {
        e$21 = {
          TAG: "Ok",
          _0: void 0
        };
      }
      e$20 = e$21.TAG === "Ok" ? {
        TAG: "Ok",
        _0: void 0
      } : e$21;
    } else {
      e$20 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$20.TAG !== "Ok") {
      return e$20;
    }
    let repeatCountBytes = (toByte(header5) & 192) >> 6;
    let e$23;
    if (repeatCountBytes !== 0) {
      if (repeatCountBytes !== 1) {
        let e$24 = readInt162(reader, "rle_int16");
        if (e$24.TAG === "Ok") {
          rleCount.contents = e$24._0;
          e$23 = {
            TAG: "Ok",
            _0: void 0
          };
        } else {
          e$23 = e$24;
        }
      } else {
        let e$25 = readByte2(reader, "rle_byte");
        if (e$25.TAG === "Ok") {
          rleCount.contents = e$25._0;
          e$23 = {
            TAG: "Ok",
            _0: void 0
          };
        } else {
          e$23 = e$25;
        }
      }
    } else {
      rleCount.contents = 0;
      e$23 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$23.TAG === "Ok") {
      return {
        TAG: "Ok",
        _0: cacheToTile(tileCache)
      };
    } else {
      return e$23;
    }
  };
  for (let _y = 0; _y < height; ++_y) {
    let match = parseResult;
    if (match.TAG === "Ok") {
      let row = [];
      for (let _x = 0; _x < width; ++_x) {
        let match$1 = parseResult;
        if (match$1.TAG === "Ok") {
          if (rleCount.contents !== 0) {
            rleCount.contents = rleCount.contents - 1 | 0;
            row.push(cacheToTile(tileCache));
          } else {
            let tile = readTile();
            if (tile.TAG === "Ok") {
              row.push(tile._0);
            } else {
              parseResult = {
                TAG: "Error",
                _0: tile._0
              };
            }
          }
        }
      }
      let match$2 = parseResult;
      if (match$2.TAG === "Ok") {
        tiles.push(row);
      }
    }
  }
  let err = parseResult;
  if (err.TAG !== "Ok") {
    return {
      TAG: "Error",
      _0: err._0
    };
  }
  let e$6 = readInt162(reader, "chestCount");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readRepeated(e$6._0, () => Chest.parse(reader));
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let e$8 = readInt162(reader, "signCount");
  if (e$8.TAG !== "Ok") {
    return e$8;
  }
  let e$9 = readRepeated(e$8._0, () => Sign.parse(reader));
  if (e$9.TAG !== "Ok") {
    return e$9;
  }
  let e$10 = readInt162(reader, "entityCount");
  if (e$10.TAG !== "Ok") {
    return e$10;
  }
  let e$11 = getBytesLeft2(reader);
  if (e$11.TAG !== "Ok") {
    return e$11;
  }
  let e$12 = readBuffer2(reader, e$11._0, "entitiesBuffer");
  if (e$12.TAG !== "Ok") {
    return e$12;
  }
  let entityReader = new bufferreader_default2(e$12._0);
  let e$13 = readRepeated(e$10._0, () => parse67(entityReader));
  if (e$13.TAG !== "Ok") {
    return e$13;
  }
  let e$14 = getBytesLeft2(entityReader);
  if (e$14.TAG !== "Ok") {
    return e$14;
  }
  let e$15 = e$14._0 === 0 ? {
    TAG: "Ok",
    _0: void 0
  } : {
    TAG: "Error",
    _0: {
      context: "Packet_TileSectionSend.entities",
      error: new Error("Unexpected trailing entity bytes")
    }
  };
  if (e$15.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        height,
        width,
        tileX: e$2._0,
        tileY: e$3._0,
        tiles,
        chests: e$7._0,
        signs: e$9._0,
        entities: e$13._0
      }
    };
  } else {
    return e$15;
  }
}
function getLiquidBitFlags(tile) {
  let hasLiquid = isSome(tile.liquid);
  let liquidBits = hasLiquid ? tile.shimmer ? "One" : tile.honey ? "Three" : tile.lava ? "Two" : "One" : "Zero";
  switch (liquidBits) {
    case "Zero":
      return [
        false,
        false
      ];
    case "One":
      return [
        false,
        true
      ];
    case "Two":
      return [
        true,
        false
      ];
    case "Three":
      return [
        true,
        true
      ];
  }
}
function getSlopeBitFlags(tile) {
  if (tile.halfBrick) {
    return [
      false,
      false,
      true
    ];
  }
  let match = tile.slope;
  if (match === void 0) {
    return [
      false,
      false,
      false
    ];
  }
  switch (match) {
    case 0:
      return [
        false,
        false,
        true
      ];
    case 1:
      return [
        false,
        true,
        false
      ];
    case 2:
      return [
        false,
        true,
        true
      ];
    case 3:
      return [
        true,
        false,
        false
      ];
    case 4:
      return [
        true,
        false,
        true
      ];
    case 5:
      return [
        true,
        true,
        false
      ];
    default:
      return [
        true,
        true,
        true
      ];
  }
}
function getRepeatCountByteLength(repeatCount) {
  if (repeatCount > 255) {
    return 2;
  } else if (repeatCount > 0) {
    return 1;
  } else {
    return 0;
  }
}
function getRepeatCountBitFlags(repeatCount) {
  let repeatCountBytes = getRepeatCountByteLength(repeatCount);
  switch (repeatCountBytes) {
    case 0:
      return [
        false,
        false
      ];
    case 1:
      return [
        false,
        true
      ];
    default:
      return [
        true,
        false
      ];
  }
}
function allowsSaveCompressionBatching(tile) {
  let activeTile = tile.activeTile;
  if (activeTile !== void 0) {
    if (activeTile.tileType !== 520) {
      return activeTile.tileType !== 423;
    } else {
      return false;
    }
  } else {
    return true;
  }
}
function packTile(writer, tile, repeatCount) {
  let coatFlags = (((tile.invisibleBlock ? 2 : 0) + (tile.invisibleWall ? 4 : 0) | 0) + (tile.fullbrightBlock ? 8 : 0) | 0) + (tile.fullbrightWall ? 16 : 0) | 0;
  let header2 = tile.coatHeader | coatFlags;
  let hasLiquid = isSome(tile.liquid);
  let wall = tile.wall;
  let header3 = fromFlags(header2 > 0, tile.actuator, tile.inActive, isSome(tile.color), isSome(tile.wall) && isSome(tile.wallColor), tile.wire4, wall !== void 0 ? wall > 255 : false, tile.shimmer && hasLiquid);
  let match = getSlopeBitFlags(tile);
  let header4 = fromFlags(toByte(header3) > 0, tile.wire, tile.wire2, tile.wire3, match[2], match[1], match[0], false);
  let match$1 = getLiquidBitFlags(tile);
  let match$2 = getRepeatCountBitFlags(repeatCount);
  let activeTile = tile.activeTile;
  let tileFlags = fromFlags(toByte(header4) > 0, isSome(tile.activeTile), isSome(tile.wall), match$1[1], match$1[0], activeTile !== void 0 ? activeTile.tileType > 255 : false, match$2[1], match$2[0]);
  packByte2(writer, toByte(tileFlags), "tileFlags");
  if (flag1(tileFlags)) {
    packByte2(writer, toByte(header4), "header4");
    if (flag1(header4)) {
      packByte2(writer, toByte(header3), "header3");
      if (flag1(header3)) {
        packByte2(writer, header2, "header2");
      }
    }
  }
  let activeTile$1 = tile.activeTile;
  if (activeTile$1 !== void 0) {
    if (flag6(tileFlags)) {
      packByte2(writer, activeTile$1.tileType & 255, "tileType_lowByte");
      packByte2(writer, (activeTile$1.tileType & 65280) >> 8, "tileType_highByte");
    } else {
      packByte2(writer, activeTile$1.tileType, "tileType");
    }
    let match$3 = activeTile$1.frame;
    if (match$3 !== void 0) {
      packInt162(writer, match$3.x, "frameX");
      packInt162(writer, match$3.y, "frameY");
    }
    let color = tile.color;
    if (color !== void 0) {
      packByte2(writer, color, "color");
    }
  }
  let wall$1 = tile.wall;
  if (wall$1 !== void 0) {
    packByte2(writer, wall$1 & 255, "wall_lowByte");
    let wallColor = tile.wallColor;
    if (wallColor !== void 0) {
      packByte2(writer, wallColor, "wallColor");
    }
  }
  let liquid = tile.liquid;
  if (liquid !== void 0) {
    packByte2(writer, liquid, "liquidValue");
  }
  let wall$2 = tile.wall;
  if (wall$2 !== void 0 && wall$2 > 255) {
    packByte2(writer, wall$2 >> 8, "wall_highByte");
  }
  let match$4 = getRepeatCountByteLength(repeatCount);
  if (match$4 !== 0) {
    if (match$4 !== 1) {
      packInt162(writer, repeatCount, "rle_int16");
    } else {
      packByte2(writer, repeatCount, "rle_byte");
    }
  }
  return writer;
}
function decidePackTile(writer, lastTile, tile) {
  let last = lastTile.contents;
  if (last !== void 0) {
    if (isTheSameAs(tile, last.tile) && allowsSaveCompressionBatching(tile)) {
      last.count = last.count + 1 | 0;
    } else {
      packTile(writer, last.tile, last.count);
      lastTile.contents = {
        tile,
        count: 0
      };
    }
  } else {
    lastTile.contents = {
      tile,
      count: 0
    };
  }
}
function toBuffer65(self) {
  let outerPacketWriter = setType(make(), toInt("TileSectionSend"));
  let innerWriter = make3(Buffer.allocUnsafe(64e3));
  packInt162(packInt162(packInt322(packInt322(innerWriter, self.tileX, "tileX"), self.tileY, "tileY"), self.width, "width"), self.height, "height");
  let lastTile = {
    contents: void 0
  };
  for (let y = 0, y_finish = self.height; y < y_finish; ++y) {
    for (let x = 0, x_finish = self.width; x < x_finish; ++x) {
      let tile = self.tiles[y][x];
      decidePackTile(innerWriter, lastTile, tile);
    }
  }
  let lastTileValue = lastTile.contents;
  if (lastTileValue !== void 0) {
    packTile(innerWriter, lastTileValue.tile, lastTileValue.count);
  }
  packInt162(innerWriter, self.chests.length, "chestCount");
  self.chests.forEach((chest) => {
    Chest.pack(innerWriter, chest);
  });
  packInt162(innerWriter, self.signs.length, "signCount");
  self.signs.forEach((sign) => {
    Sign.pack(innerWriter, sign);
  });
  packInt162(innerWriter, self.entities.length, "entityCount");
  self.entities.forEach((entity) => {
    pack4(innerWriter, entity);
  });
  let innerBuffer = slicedData(innerWriter);
  if (innerBuffer.TAG === "Ok") {
    let deflatedPayload = Nodezlib.deflateRawSync(innerBuffer._0);
    return data(packBuffer(outerPacketWriter, deflatedPayload, "deflatedPayload"));
  }
  let e = innerBuffer._0;
  return {
    TAG: "Error",
    _0: {
      context: "innerWriter; " + e.context,
      error: e.error
    }
  };
}
var Chest2;
var Sign2;
var Entity = {
  parse: parse67,
  pack: pack4
};
var Packet_TileSquareSend_exports = {};
__export(Packet_TileSquareSend_exports, {
  Decode: () => Decode9,
  Encode: () => Encode9,
  parse: () => parse68,
  toBuffer: () => toBuffer66
});
function parse68(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "tileX");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "tileY");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "width");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let width = e$2._0;
  let e$3 = readByte(reader, "height");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let height = e$3._0;
  let e$4 = readByte(reader, "changeType");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let readTile = () => {
    let e2 = readByte(reader, "flags1");
    if (e2.TAG !== "Ok") {
      return e2;
    }
    let flags1 = fromByte(e2._0);
    let e$12 = readByte(reader, "flags2");
    if (e$12.TAG !== "Ok") {
      return e$12;
    }
    let flags2 = fromByte(e$12._0);
    let e$22 = readByte(reader, "flags3");
    if (e$22.TAG !== "Ok") {
      return e$22;
    }
    let active = flag1(flags1);
    let hasWall = flag3(flags1);
    let hasLiquid = flag4(flags1);
    let wire2 = flag5(flags1);
    let halfBrick = flag6(flags1);
    let actuator = flag7(flags1);
    let inActive = flag8(flags1);
    let wire22 = flag1(flags2);
    let wire3 = flag2(flags2);
    let e$32;
    if (flag3(flags2)) {
      let e$42 = readByte(reader, "color");
      e$32 = e$42.TAG === "Ok" ? {
        TAG: "Ok",
        _0: e$42._0
      } : e$42;
    } else {
      e$32 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$32.TAG !== "Ok") {
      return e$32;
    }
    let e$5;
    if (flag4(flags2)) {
      let e$6 = readByte(reader, "wallColor");
      e$5 = e$6.TAG === "Ok" ? {
        TAG: "Ok",
        _0: e$6._0
      } : e$6;
    } else {
      e$5 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$5.TAG !== "Ok") {
      return e$5;
    }
    let e$7;
    if (active) {
      let e$8 = readUInt16(reader, "tileType");
      if (e$8.TAG === "Ok") {
        let tileType = e$8._0;
        let e$9;
        if (isImportant(tileType)) {
          let e$10 = readInt16(reader, "frameX");
          if (e$10.TAG === "Ok") {
            let e$11 = readInt16(reader, "frameY");
            e$9 = e$11.TAG === "Ok" ? {
              TAG: "Ok",
              _0: {
                x: e$10._0,
                y: e$11._0
              }
            } : e$11;
          } else {
            e$9 = e$10;
          }
        } else {
          e$9 = {
            TAG: "Ok",
            _0: void 0
          };
        }
        if (e$9.TAG === "Ok") {
          let slope = ((0 + (flag5(flags2) ? 1 : 0) | 0) + (flag6(flags2) ? 2 : 0) | 0) + (flag7(flags2) ? 4 : 0) | 0;
          e$7 = {
            TAG: "Ok",
            _0: {
              tileType,
              slope,
              frame: e$9._0
            }
          };
        } else {
          e$7 = e$9;
        }
      } else {
        e$7 = e$8;
      }
    } else {
      e$7 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$7.TAG !== "Ok") {
      return e$7;
    }
    let e$122;
    if (hasWall) {
      let e$13 = readUInt16(reader, "wall");
      e$122 = e$13.TAG === "Ok" ? {
        TAG: "Ok",
        _0: e$13._0
      } : e$13;
    } else {
      e$122 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$122.TAG !== "Ok") {
      return e$122;
    }
    let e$14;
    if (hasLiquid) {
      let e$15 = readByte(reader, "liquidValue");
      if (e$15.TAG === "Ok") {
        let e$16 = readByte(reader, "liquidType");
        e$14 = e$16.TAG === "Ok" ? {
          TAG: "Ok",
          _0: {
            liquidValue: e$15._0,
            liquidType: e$16._0
          }
        } : e$16;
      } else {
        e$14 = e$15;
      }
    } else {
      e$14 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$14.TAG !== "Ok") {
      return e$14;
    }
    let wire4 = flag8(flags2);
    return {
      TAG: "Ok",
      _0: {
        wire: wire2,
        halfBrick,
        actuator,
        inActive,
        wire2: wire22,
        wire3,
        wire4,
        color: e$32._0,
        wallColor: e$5._0,
        activeTile: e$7._0,
        wall: e$122._0,
        liquid: e$14._0,
        coatHeader: e$22._0
      }
    };
  };
  let tiles = [];
  let parseResult = {
    TAG: "Ok",
    _0: void 0
  };
  for (let _x = 0; _x < width; ++_x) {
    let match = parseResult;
    if (match.TAG === "Ok") {
      let column = [];
      for (let _y = 0; _y < height; ++_y) {
        let match$1 = parseResult;
        if (match$1.TAG === "Ok") {
          let tile = readTile();
          if (tile.TAG === "Ok") {
            column.push(tile._0);
          } else {
            parseResult = {
              TAG: "Error",
              _0: tile._0
            };
          }
        }
      }
      let match$2 = parseResult;
      if (match$2.TAG === "Ok") {
        tiles.push(column);
      }
    }
  }
  let err = parseResult;
  if (err.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        width,
        height,
        changeType: e$4._0,
        tileX: e._0,
        tileY: e$1._0,
        tiles
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: err._0
    };
  }
}
function packTile2(writer, tile) {
  let flags1 = fromFlags(isSome(tile.activeTile), false, isSome(tile.wall), isSome(tile.liquid), tile.wire, tile.halfBrick, tile.actuator, tile.inActive);
  let flags2 = fromFlags(tile.wire2, tile.wire3, isSome(tile.color), isSome(tile.wallColor), mapOr(tile.activeTile, false, (tile2) => (tile2.slope & 1) === 1), mapOr(tile.activeTile, false, (tile2) => (tile2.slope & 2) === 2), mapOr(tile.activeTile, false, (tile2) => (tile2.slope & 4) === 4), tile.wire4);
  packByte(packByte(packByte(writer, toByte(flags1), "flags1"), toByte(flags2), "flags2"), tile.coatHeader, "coatHeader");
  let c = tile.color;
  if (c !== void 0) {
    packByte(writer, c, "color");
  }
  let wc = tile.wallColor;
  if (wc !== void 0) {
    packByte(writer, wc, "wallColor");
  }
  let at = tile.activeTile;
  if (at !== void 0) {
    packUInt16(writer, at.tileType, "tileType");
    if (isImportant(at.tileType)) {
      packInt16(packInt16(writer, mapOr(at.frame, 0, (frame2) => frame2.x), "frameX"), mapOr(at.frame, 0, (frame2) => frame2.y), "frameY");
    }
  }
  let w = tile.wall;
  if (w !== void 0) {
    packUInt16(writer, w, "wall");
  }
  let l = tile.liquid;
  if (l !== void 0) {
    packByte(packByte(writer, l.liquidValue, "liquidValue"), l.liquidType, "liquidType");
  }
  return writer;
}
function packTiles(writer, tiles) {
  for (let x = 0, x_finish = tiles.length; x < x_finish; ++x) {
    for (let y = 0, y_finish = tiles[x].length; y < y_finish; ++y) {
      packTile2(writer, tiles[x][y]);
    }
  }
  return writer;
}
function toBuffer66(self) {
  return data(packTiles(packByte(packByte(packByte(packInt16(packInt16(setType(make(), toInt("TileSquareSend")), self.tileX, "tileX"), self.tileY, "tileY"), self.width, "width"), self.height, "height"), self.changeType, "changeType"), self.tiles));
}
var Decode9 = {
  parse: parse68
};
var Encode9 = {
  toBuffer: toBuffer66
};
var PacketV1449_TimeSet_exports = {};
__export(PacketV1449_TimeSet_exports, {
  parse: () => parse69,
  toBuffer: () => toBuffer67
});
function parse69(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "dayTime");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "time");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "sunModY");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt16(reader, "moonModY");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        dayTime: e._0 === 1,
        time: e$1._0,
        sunModY: e$2._0,
        moonModY: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function toBuffer67(self) {
  return data(packInt16(packInt16(packInt32(packByte(setType(make(), toInt("TimeSet")), self.dayTime ? 1 : 0, "dayTime"), self.time, "time"), self.sunModY, "sunModY"), self.moonModY, "moonModY"));
}
var Packet_TravellingMerchantInventory_exports = {};
__export(Packet_TravellingMerchantInventory_exports, {
  Decode: () => Decode10,
  Encode: () => Encode10,
  parse: () => parse70,
  toBuffer: () => toBuffer68
});
function parse70(payload) {
  let reader = new packetreader_default(payload);
  let items = [];
  let readItems = (_idx) => {
    while (true) {
      let idx = _idx;
      if (idx >= 40) {
        return {
          TAG: "Ok",
          _0: void 0
        };
      }
      let e2 = readInt16(reader, `item` + (idx + 1 | 0).toString());
      if (e2.TAG !== "Ok") {
        return e2;
      }
      items.push(e2._0);
      _idx = idx + 1 | 0;
      continue;
    }
    ;
  };
  let e = readItems(0);
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        items
      }
    };
  } else {
    return e;
  }
}
var Decode10 = {
  readInt16,
  parse: parse70
};
function packItems(writer, items) {
  let _writer = writer;
  let _idx = 0;
  while (true) {
    let idx = _idx;
    let writer$1 = _writer;
    if (idx >= items.length) {
      return writer$1;
    }
    _idx = idx + 1 | 0;
    _writer = packInt16(writer$1, items[idx], `item` + (idx + 1 | 0).toString());
    continue;
  }
  ;
}
function toBuffer68(self) {
  let writer = setType(make(), toInt("TravellingMerchantInventory"));
  return data(packItems(writer, self.items));
}
var Encode10 = {
  Writer: void 0,
  packInt16,
  setType,
  data,
  packItems,
  toBuffer: toBuffer68
};
var PacketV1449_TreeGrowFx_exports = {};
__export(PacketV1449_TreeGrowFx_exports, {
  parse: () => parse71,
  toBuffer: () => toBuffer69
});
function parse71(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "action");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt32(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "style");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt16(reader, "treeType");
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        action: e._0,
        x: e$1._0,
        y: e$2._0,
        style: e$3._0,
        treeType: e$4._0
      }
    };
  } else {
    return e$4;
  }
}
function toBuffer69(self) {
  return data(packInt16(packByte(packInt32(packInt32(packByte(setType(make(), toInt("TreeGrowFx")), self.action, "action"), self.x, "x"), self.y, "y"), self.style, "style"), self.treeType, "treeType"));
}
var PacketV1449_Unused_exports = {};
__export(PacketV1449_Unused_exports, {
  parse: () => parse72
});
function parse72(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
var PacketV1449_WallPaint_exports = {};
__export(PacketV1449_WallPaint_exports, {
  parse: () => parse73,
  toBuffer: () => toBuffer70
});
function parse73(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "color");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "coat");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        color: e$2._0,
        coat: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function toBuffer70(self) {
  return data(packByte(packByte(packInt16(packInt16(setType(make(), toInt("WallPaint")), self.x, "x"), self.y, "y"), self.color, "color"), self.coat, "coat"));
}
var PacketV1449_WeaponsRackTryPlacing_exports = {};
__export(PacketV1449_WeaponsRackTryPlacing_exports, {
  parse: () => parse74,
  toBuffer: () => toBuffer71
});
function parse74(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "itemId");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "prefix");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt16(reader, "stack");
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        itemId: e$2._0,
        prefix: e$3._0,
        stack: e$4._0
      }
    };
  } else {
    return e$4;
  }
}
function toBuffer71(self) {
  return data(packInt16(packInt16(packInt16(packInt16(packInt16(setType(make(), toInt("WeaponsRackTryPlacing")), self.x, "x"), self.y, "y"), self.itemId, "itemId"), self.prefix, "prefix"), self.stack, "stack"));
}
var PacketV1449_WiredCannonShot_exports = {};
__export(PacketV1449_WiredCannonShot_exports, {
  parse: () => parse75,
  toBuffer: () => toBuffer72
});
function parse75(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "damage");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "knockback");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "x");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt16(reader, "y");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt16(reader, "angle");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readInt16(reader, "ammo");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readByte(reader, "playerId");
  if (e$6.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        damage: e._0,
        knockback: e$1._0,
        x: e$2._0,
        y: e$3._0,
        angle: e$4._0,
        ammo: e$5._0,
        playerId: e$6._0
      }
    };
  } else {
    return e$6;
  }
}
function toBuffer72(self) {
  return data(packByte(packInt16(packInt16(packInt16(packInt16(packSingle(packInt16(setType(make(), toInt("WiredCannonShot")), self.damage, "damage"), self.knockback, "knockback"), self.x, "x"), self.y, "y"), self.angle, "angle"), self.ammo, "ammo"), self.playerId, "playerId"));
}
var PacketV1449_WorldDataRequest_exports = {};
__export(PacketV1449_WorldDataRequest_exports, {
  parse: () => parse76,
  toBuffer: () => toBuffer73
});
function parse76(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
function toBuffer73(_self) {
  return {
    TAG: "Ok",
    _0: new packetwriter_default2().setType(toInt("WorldDataRequest")).data
  };
}
var Packet_Zones_exports = {};
__export(Packet_Zones_exports, {
  Decode: () => Decode11,
  Encode: () => Encode11,
  parse: () => parse77,
  toBuffer: () => toBuffer74
});
function parse77(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "zone1");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "zone2");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "zone3");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readByte(reader, "zone4");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readByte(reader, "zone5");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readByte(reader, "townNPCs");
  if (e$6.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        zone1: e$1._0,
        zone2: e$2._0,
        zone3: e$3._0,
        zone4: e$4._0,
        zone5: e$5._0,
        townNPCs: e$6._0
      }
    };
  } else {
    return e$6;
  }
}
var Decode11 = {
  readByte,
  parse: parse77
};
function toBuffer74(self) {
  return data(packByte(packByte(packByte(packByte(packByte(packByte(packByte(setType(make(), toInt("Zones")), self.playerId, "playerId"), self.zone1, "zone1"), self.zone2, "zone2"), self.zone3, "zone3"), self.zone4, "zone4"), self.zone5, "zone5"), self.townNPCs, "townNPCs"));
}
var Encode11 = {
  packByte,
  setType,
  data,
  toBuffer: toBuffer74
};
var Packet_ChestResize_exports = {};
__export(Packet_ChestResize_exports, {
  Decode: () => Decode12,
  Encode: () => Encode12,
  parse: () => parse78,
  toBuffer: () => toBuffer75
});
function parse78(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "chestId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "newSize");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        chestId: e._0,
        newSize: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
var Decode12 = {
  readInt16,
  parse: parse78
};
function toBuffer75(self) {
  return data(packInt16(packInt16(setType(make(), toInt("ChestResize")), self.chestId, "chestId"), self.newSize, "newSize"));
}
var Encode12 = {
  packInt16,
  setType,
  data,
  toBuffer: toBuffer75
};
var Packet_DeadCellsDisplayJarTryPlacing_exports = {};
__export(Packet_DeadCellsDisplayJarTryPlacing_exports, {
  Decode: () => Decode13,
  Encode: () => Encode13,
  parse: () => parse79,
  toBuffer: () => toBuffer76
});
function parse79(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "itemType");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "prefix");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt16(reader, "stack");
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        itemType: e$2._0,
        prefix: e$3._0,
        stack: e$4._0
      }
    };
  } else {
    return e$4;
  }
}
var Decode13 = {
  readInt16,
  readByte,
  parse: parse79
};
function toBuffer76(self) {
  return data(packInt16(packByte(packInt16(packInt16(packInt16(setType(make(), toInt("DeadCellsDisplayJarTryPlacing")), self.x, "x"), self.y, "y"), self.itemType, "itemType"), self.prefix, "prefix"), self.stack, "stack"));
}
var Encode13 = {
  packInt16,
  packByte,
  setType,
  data,
  toBuffer: toBuffer76
};
var Packet_DebugCommand_exports = {};
__export(Packet_DebugCommand_exports, {
  Decode: () => Decode14,
  Encode: () => Encode14,
  parse: () => parse80,
  toBuffer: () => toBuffer77
});
function parse80(payload) {
  let reader = new packetreader_default(payload);
  let e = readString(reader, "command");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "argInt");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "argFloat");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "argFloat2");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        command: e._0,
        argInt: e$1._0,
        argFloat: e$2._0,
        argFloat2: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
var Decode14 = {
  readString,
  readInt32,
  readSingle,
  parse: parse80
};
function toBuffer77(self) {
  return data(packSingle(packSingle(packInt32(packString(setType(make(), toInt("Unused")), self.command, "command"), self.argInt, "argInt"), self.argFloat, "argFloat"), self.argFloat2, "argFloat2"));
}
var Encode14 = {
  packString,
  packInt32,
  packSingle,
  setType,
  data,
  toBuffer: toBuffer77
};
var Packet_HostToken_exports = {};
__export(Packet_HostToken_exports, {
  Decode: () => Decode15,
  Encode: () => Encode15,
  parse: () => parse81,
  toBuffer: () => toBuffer78
});
function parse81(payload) {
  let reader = new packetreader_default(payload);
  let e = readString(reader, "token");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        token: e._0
      }
    };
  } else {
    return e;
  }
}
var Decode15 = {
  readString,
  parse: parse81
};
function toBuffer78(self) {
  return data(packString(setType(make(), toInt("HostToken")), self.token, "token"));
}
var Encode15 = {
  packString,
  setType,
  data,
  toBuffer: toBuffer78
};
var Packet_InitialTileSectionsRequest_exports = {};
__export(Packet_InitialTileSectionsRequest_exports, {
  Decode: () => Decode16,
  Encode: () => Encode16,
  parse: () => parse82,
  toBuffer: () => toBuffer79
});
function parse82(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt32(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "team");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        team: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
var Decode16 = {
  readInt32,
  readByte,
  parse: parse82
};
function toBuffer79(self) {
  return data(packByte(packInt32(packInt32(setType(new packetwriter_default2(), toInt("InitialTileSectionsRequest")), self.x, "x"), self.y, "y"), self.team, "team"));
}
var Encode16 = {
  toBuffer: toBuffer79
};
var Packet_ItemDropClear_exports = {};
__export(Packet_ItemDropClear_exports, {
  Decode: () => Decode17,
  Encode: () => Encode17,
  parse: () => parse83,
  toBuffer: () => toBuffer80
});
function parse83(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "itemDropId");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        itemDropId: e._0
      }
    };
  } else {
    return e;
  }
}
var Decode17 = {
  readInt16,
  parse: parse83
};
function toBuffer80(self) {
  return data(packInt16(setType(make(), toInt("ItemDropClear")), self.itemDropId, "itemDropId"));
}
var Encode17 = {
  packInt16,
  setType,
  data,
  toBuffer: toBuffer80
};
var Packet_ItemDropPosition_exports = {};
__export(Packet_ItemDropPosition_exports, {
  Decode: () => Decode18,
  Encode: () => Encode18,
  parse: () => parse84,
  toBuffer: () => toBuffer81
});
function parse84(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "itemDropId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "positionX");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "positionY");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        itemDropId: e._0,
        position: {
          x: e$1._0,
          y: e$2._0
        }
      }
    };
  } else {
    return e$2;
  }
}
var Decode18 = {
  readInt16,
  readSingle,
  parse: parse84
};
function toBuffer81(self) {
  return data(packSingle(packSingle(packInt16(setType(make(), toInt("ItemDropPosition")), self.itemDropId, "itemDropId"), self.position.x, "positionX"), self.position.y, "positionY"));
}
var Encode18 = {
  packInt16,
  packSingle,
  setType,
  data,
  toBuffer: toBuffer81
};
var Packet_ItemForceIntoNearestChest_exports = {};
__export(Packet_ItemForceIntoNearestChest_exports, {
  Decode: () => Decode19,
  Encode: () => Encode19,
  parse: () => parse85,
  toBuffer: () => toBuffer82
});
function parse85(payload, fromServer) {
  let reader = new packetreader_default(payload);
  if (fromServer) {
    let e = readInt32(reader, "blockedChestCount");
    if (e.TAG !== "Ok") {
      return e;
    }
    let count = e._0;
    let chestIds = [];
    let readChests = (_idx) => {
      while (true) {
        let idx = _idx;
        if (idx >= count) {
          return {
            TAG: "Ok",
            _0: void 0
          };
        }
        let e2 = readUInt16(reader, `blockedChest` + idx.toString());
        if (e2.TAG !== "Ok") {
          return e2;
        }
        chestIds.push(e2._0);
        _idx = idx + 1 | 0;
        continue;
      }
      ;
    };
    let e$1 = readChests(0);
    if (e$1.TAG === "Ok") {
      return {
        TAG: "Ok",
        _0: {
          TAG: "ServerBlockedChests",
          _0: {
            chestIds
          }
        }
      };
    } else {
      return e$1;
    }
  }
  let e$2 = readInt32(reader, "slotCount");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let count$1 = e$2._0;
  let slotIds = [];
  let readSlots = (_idx) => {
    while (true) {
      let idx = _idx;
      if (idx >= count$1) {
        return {
          TAG: "Ok",
          _0: void 0
        };
      }
      let e = readInt16(reader, `slot` + idx.toString());
      if (e.TAG !== "Ok") {
        return e;
      }
      slotIds.push(e._0);
      _idx = idx + 1 | 0;
      continue;
    }
    ;
  };
  let e$3 = readSlots(0);
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readByte(reader, "smartStack");
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        TAG: "ClientRequest",
        _0: {
          slotIds,
          smartStack: e$4._0 !== 0
        }
      }
    };
  } else {
    return e$4;
  }
}
var Decode19 = {
  readInt16,
  readUInt16,
  readInt32,
  readByte,
  parse: parse85
};
function packSlotIds(writer, slotIds) {
  let writer$1 = packInt32(writer, slotIds.length, "slotCount");
  slotIds.forEach((slotId, idx) => {
    packInt16(writer$1, slotId, `slot` + idx.toString());
  });
  return writer$1;
}
function packChestIds(writer, chestIds) {
  let writer$1 = packInt32(writer, chestIds.length, "blockedChestCount");
  chestIds.forEach((chestId, idx) => {
    packUInt16(writer$1, chestId, `blockedChest` + idx.toString());
  });
  return writer$1;
}
function toBuffer82(self) {
  let writer = setType(make(), toInt("ItemForceIntoNearestChest"));
  if (self.TAG !== "ClientRequest") {
    return data(packChestIds(writer, self._0.chestIds));
  }
  let match = self._0;
  return data(packByte(packSlotIds(writer, match.slotIds), match.smartStack ? 1 : 0, "smartStack"));
}
var Encode19 = {
  Writer: void 0,
  packInt16,
  packUInt16,
  packInt32,
  packByte,
  setType,
  data,
  packSlotIds,
  packChestIds,
  toBuffer: toBuffer82
};
var Packet_LeashedEntityAnchorInsertItem_exports = {};
__export(Packet_LeashedEntityAnchorInsertItem_exports, {
  Decode: () => Decode20,
  Encode: () => Encode20,
  parse: () => parse86,
  toBuffer: () => toBuffer83
});
function parse86(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "itemType");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        itemType: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
var Decode20 = {
  readInt16,
  parse: parse86
};
function toBuffer83(self) {
  return data(packInt16(packInt16(packInt16(setType(make(), toInt("LeashedEntityAnchorInsertItem")), self.x, "x"), self.y, "y"), self.itemType, "itemType"));
}
var Encode20 = {
  packInt16,
  setType,
  data,
  toBuffer: toBuffer83
};
var Packet_NpcHurtByDebuff_exports = {};
__export(Packet_NpcHurtByDebuff_exports, {
  Decode: () => Decode21,
  Encode: () => Encode21,
  parse: () => parse87,
  toBuffer: () => toBuffer84
});
function parse87(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "npcId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "debuffId");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcId: e._0,
        debuffId: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
var Decode21 = {
  readByte,
  readInt16,
  parse: parse87
};
function toBuffer84(self) {
  return data(packInt16(packByte(setType(make(), toInt("NpcHurtByDebuff")), self.npcId, "npcId"), self.debuffId, "debuffId"));
}
var Encode21 = {
  packByte,
  packInt16,
  setType,
  data,
  toBuffer: toBuffer84
};
var Packet_Ping_exports = {};
__export(Packet_Ping_exports, {
  Decode: () => Decode22,
  Encode: () => Encode22,
  parse: () => parse88,
  toBuffer: () => toBuffer85
});
function parse88(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
var Decode22 = {
  parse: parse88
};
function toBuffer85(_self) {
  return data(setType(make(), toInt("Ping")));
}
var Encode22 = {
  setType,
  data,
  toBuffer: toBuffer85
};
var Packet_PlayerItemUseSound_exports = {};
__export(Packet_PlayerItemUseSound_exports, {
  Decode: () => Decode23,
  Encode: () => Encode23,
  parse: () => parse89,
  toBuffer: () => toBuffer86
});
function parse89(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0
      }
    };
  } else {
    return e;
  }
}
var Decode23 = {
  readByte,
  parse: parse89
};
function toBuffer86(self) {
  return data(packByte(setType(make(), toInt("PlayerItemUseSound")), self.playerId, "playerId"));
}
var Encode23 = {
  packByte,
  setType,
  data,
  toBuffer: toBuffer86
};
var Packet_PlayerLuckFactorsUpdate_exports = {};
__export(Packet_PlayerLuckFactorsUpdate_exports, {
  Decode: () => Decode24,
  Encode: () => Encode24,
  parse: () => parse90,
  toBuffer: () => toBuffer87
});
function parse90(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "ladyBugLuckTimeLeft");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "torchLuck");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "luckPotion");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readByte(reader, "hasGardenGnomeNearby");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let hasGardenGnomeNearby = e$4._0 === 1;
  let e$5 = readByte(reader, "brokenMirrorBadLuck");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let brokenMirrorBadLuck = e$5._0 === 1;
  let e$6 = readSingle(reader, "equipmentBasedLuckBonus");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readSingle(reader, "coinLuck");
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let e$8 = readByte(reader, "kiteLuckLevel");
  if (e$8.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        ladyBugLuckTimeLeft: e$1._0,
        torchLuck: e$2._0,
        luckPotion: e$3._0,
        hasGardenGnomeNearby,
        brokenMirrorBadLuck,
        equipmentBasedLuckBonus: e$6._0,
        coinLuck: e$7._0,
        kiteLuckLevel: e$8._0
      }
    };
  } else {
    return e$8;
  }
}
var Decode24 = {
  readInt32,
  readByte,
  readSingle,
  parse: parse90
};
function toBuffer87(self) {
  return data(packByte(packSingle(packSingle(packByte(packByte(packByte(packSingle(packInt32(packByte(setType(make(), toInt("PlayerLuckFactorsUpdate")), self.playerId, "playerId"), self.ladyBugLuckTimeLeft, "ladyBugLuckTimeLeft"), self.torchLuck, "torchLuck"), self.luckPotion, "luckPotion"), self.hasGardenGnomeNearby ? 1 : 0, "hasGardenGnomeNearby"), self.brokenMirrorBadLuck ? 1 : 0, "brokenMirrorBadLuck"), self.equipmentBasedLuckBonus, "equipmentBasedLuckBonus"), self.coinLuck, "coinLuck"), self.kiteLuckLevel, "kiteLuckLevel"));
}
var Encode24 = {
  packByte,
  packInt32,
  packSingle,
  setType,
  data,
  toBuffer: toBuffer87
};
var Packet_PlayerSpectate_exports = {};
__export(Packet_PlayerSpectate_exports, {
  Decode: () => Decode25,
  Encode: () => Encode25,
  parse: () => parse91,
  toBuffer: () => toBuffer88
});
function parse91(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "targetPlayerId");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        targetPlayerId: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
var Decode25 = {
  readByte,
  readInt16,
  parse: parse91
};
function toBuffer88(self) {
  return data(packInt16(packByte(setType(make(), toInt("PlayerSpectate")), self.playerId, "playerId"), self.targetPlayerId, "targetPlayerId"));
}
var Encode25 = {
  packByte,
  packInt16,
  setType,
  data,
  toBuffer: toBuffer88
};
var Packet_PlayerTeamSwapSpawn_exports = {};
__export(Packet_PlayerTeamSwapSpawn_exports, {
  Decode: () => Decode26,
  Encode: () => Encode26,
  parse: () => parse92,
  toBuffer: () => toBuffer89
});
function parse92(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0
      }
    };
  } else {
    return e;
  }
}
var Decode26 = {
  readByte,
  parse: parse92
};
function toBuffer89(self) {
  return data(packByte(setType(make(), toInt("PlayerTeamSwapSpawn")), self.playerId, "playerId"));
}
var Encode26 = {
  packByte,
  setType,
  data,
  toBuffer: toBuffer89
};
var Packet_PlayerTeamUpdate_exports = {};
__export(Packet_PlayerTeamUpdate_exports, {
  Decode: () => Decode27,
  Encode: () => Encode27,
  parse: () => parse93,
  toBuffer: () => toBuffer90
});
function parse93(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "team");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        team: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
var Decode27 = {
  readByte,
  parse: parse93
};
function toBuffer90(self) {
  return data(packByte(packByte(setType(make(), toInt("PlayerTeamUpdate")), self.playerId, "playerId"), self.team, "team"));
}
var Encode27 = {
  packByte,
  setType,
  data,
  toBuffer: toBuffer90
};
var Packet_SectionRequest_exports = {};
__export(Packet_SectionRequest_exports, {
  Decode: () => Decode28,
  Encode: () => Encode28,
  parse: () => parse94,
  toBuffer: () => toBuffer91
});
function parse94(payload) {
  let reader = new packetreader_default(payload);
  let e = readUInt16(reader, "sectionX");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readUInt16(reader, "sectionY");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        sectionX: e._0,
        sectionY: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
var Decode28 = {
  readUInt16,
  parse: parse94
};
function toBuffer91(self) {
  return data(packUInt16(packUInt16(setType(make(), toInt("SectionRequest")), self.sectionX, "sectionX"), self.sectionY, "sectionY"));
}
var Encode28 = {
  packUInt16,
  setType,
  data,
  toBuffer: toBuffer91
};
var PacketV1449_PlayerSlotSet_exports = {};
__export(PacketV1449_PlayerSlotSet_exports, {
  parse: () => parse95,
  toBuffer: () => toBuffer92
});
function parse95(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerSlotId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "serverWantsToRunCheckBytesInClientLoopThread");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerSlotId: e._0,
        serverWantsToRunCheckBytesInClientLoopThread: e$1._0 === 1
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer92(self) {
  return data(packByte(packByte(setType(make(), toInt("PlayerSlotSet")), self.playerSlotId, "playerSlotId"), self.serverWantsToRunCheckBytesInClientLoopThread ? 1 : 0, "serverWantsToRunCheckBytesInClientLoopThread"));
}
var Packet_PlayerUpdate_exports = {};
__export(Packet_PlayerUpdate_exports, {
  Decode: () => Decode29,
  Encode: () => Encode29,
  parse: () => parse96,
  toBuffer: () => toBuffer93
});
function parse96(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "controlFlags");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let controlFlags = fromByte(e$1._0);
  let e$2 = readByte(reader, "miscFlags1");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let miscFlags1 = fromByte(e$2._0);
  let e$3 = readByte(reader, "miscFlags2");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let miscFlags2 = fromByte(e$3._0);
  let e$4 = readByte(reader, "miscFlags3");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let miscFlags3 = fromByte(e$4._0);
  let control_isHoldingUp = flag1(controlFlags);
  let control_isHoldingDown = flag2(controlFlags);
  let control_isHoldingLeft = flag3(controlFlags);
  let control_isHoldingRight = flag4(controlFlags);
  let control_isHoldingJump = flag5(controlFlags);
  let control_isHoldingItemUse = flag6(controlFlags);
  let control = {
    isHoldingUp: control_isHoldingUp,
    isHoldingDown: control_isHoldingDown,
    isHoldingLeft: control_isHoldingLeft,
    isHoldingRight: control_isHoldingRight,
    isHoldingJump: control_isHoldingJump,
    isHoldingItemUse: control_isHoldingItemUse
  };
  let direction = flag7(controlFlags) ? "Right" : "Left";
  let pulleyDirection = flag1(miscFlags1) ? flag2(miscFlags1) ? "Two" : "One" : void 0;
  let vortexStealthActive = flag4(miscFlags1);
  let gravityDirection = flag5(miscFlags1) ? "Normal" : "Inverted";
  let shieldRaised = flag6(miscFlags1);
  let ghost = flag7(miscFlags1);
  let e$5 = readByte(reader, "selectedItem");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readSingle(reader, "positionX");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readSingle(reader, "positionY");
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let position_x = e$6._0;
  let position_y = e$7._0;
  let position = {
    x: position_x,
    y: position_y
  };
  let e$8;
  if (flag3(miscFlags1)) {
    let e$9 = readSingle(reader, "velocityX");
    if (e$9.TAG === "Ok") {
      let e$10 = readSingle(reader, "velocityY");
      e$8 = e$10.TAG === "Ok" ? {
        TAG: "Ok",
        _0: {
          x: e$9._0,
          y: e$10._0
        }
      } : e$10;
    } else {
      e$8 = e$9;
    }
  } else {
    e$8 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$8.TAG !== "Ok") {
    return e$8;
  }
  let e$11;
  if (flag8(miscFlags1)) {
    let e$12 = readUInt16(reader, "mountType");
    e$11 = e$12.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$12._0
    } : e$12;
  } else {
    e$11 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$11.TAG !== "Ok") {
    return e$11;
  }
  let e$13;
  if (flag7(miscFlags2)) {
    let e$14 = readSingle(reader, "potionOfReturnOrigX");
    if (e$14.TAG === "Ok") {
      let e$15 = readSingle(reader, "potionOfReturnOrigY");
      if (e$15.TAG === "Ok") {
        let e$16 = readSingle(reader, "potionOfReturnHomeX");
        if (e$16.TAG === "Ok") {
          let e$17 = readSingle(reader, "potionOfReturnHomeY");
          e$13 = e$17.TAG === "Ok" ? {
            TAG: "Ok",
            _0: {
              originalUsePosition: {
                x: e$14._0,
                y: e$15._0
              },
              homePosition: {
                x: e$16._0,
                y: e$17._0
              }
            }
          } : e$17;
        } else {
          e$13 = e$16;
        }
      } else {
        e$13 = e$15;
      }
    } else {
      e$13 = e$14;
    }
  } else {
    e$13 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$13.TAG !== "Ok") {
    return e$13;
  }
  let tryKeepingHoveringUp = flag1(miscFlags2);
  let isVoidVaultEnabled = flag2(miscFlags2);
  let isSitting = flag3(miscFlags2);
  let hasFinishedAnyDd2Event = flag4(miscFlags2);
  let isPettingAnimal = flag5(miscFlags2);
  let isTheAnimalBeingPetSmall = flag6(miscFlags2);
  let tryKeepingHoveringDown = flag8(miscFlags2);
  let isSleeping = flag1(miscFlags3);
  let autoReuseAllWeapons = flag2(miscFlags3);
  let controlDownHold = flag3(miscFlags3);
  let isOperatingAnotherEntity = flag4(miscFlags3);
  let controlUseTile = flag5(miscFlags3);
  let e$18;
  if (flag6(miscFlags3)) {
    let e$19 = readSingle(reader, "netCameraTargetX");
    if (e$19.TAG === "Ok") {
      let e$20 = readSingle(reader, "netCameraTargetY");
      e$18 = e$20.TAG === "Ok" ? {
        TAG: "Ok",
        _0: {
          x: e$19._0,
          y: e$20._0
        }
      } : e$20;
    } else {
      e$18 = e$19;
    }
  } else {
    e$18 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$18.TAG !== "Ok") {
    return e$18;
  }
  let lastItemUseAttemptSuccess = flag7(miscFlags3);
  return {
    TAG: "Ok",
    _0: {
      playerId: e._0,
      control,
      direction,
      pulleyDirection,
      vortexStealthActive,
      gravityDirection,
      shieldRaised,
      ghost,
      selectedItem: e$5._0,
      position,
      velocity: e$8._0,
      mountType: e$11._0,
      potionOfReturn: e$13._0,
      tryKeepingHoveringUp,
      isVoidVaultEnabled,
      isSitting,
      hasFinishedAnyDd2Event,
      isPettingAnimal,
      isTheAnimalBeingPetSmall,
      tryKeepingHoveringDown,
      isSleeping,
      autoReuseAllWeapons,
      controlDownHold,
      isOperatingAnotherEntity,
      controlUseTile,
      netCameraTarget: e$18._0,
      lastItemUseAttemptSuccess
    }
  };
}
var Decode29 = {
  readByte,
  readSingle,
  readUInt16,
  parse: parse96
};
function packControlFlags(writer, control, direction) {
  let tmp;
  tmp = direction !== "Left";
  return packByte(writer, toByte(fromFlags(control.isHoldingUp, control.isHoldingDown, control.isHoldingLeft, control.isHoldingRight, control.isHoldingJump, control.isHoldingItemUse, tmp, false)), "controlFlags");
}
function packMiscFlags1(writer, pulleyDirection, velocity, vortexStealthActive, gravityDirection, shieldRaised, ghost, mountType) {
  let tmp;
  tmp = pulleyDirection !== void 0 ? pulleyDirection !== "One" : false;
  let tmp$1;
  tmp$1 = gravityDirection === "Normal";
  return packByte(writer, toByte(fromFlags(pulleyDirection !== void 0, tmp, velocity !== void 0, vortexStealthActive, tmp$1, shieldRaised, ghost, isSome(mountType))), "miscFlags1");
}
function packMiscFlags2(writer, tryKeepingHoveringUp, isVoidVaultEnabled, isSitting, hasFinishedAnyDd2Event, isPettingAnimal, isTheAnimalBeingPetSmall, potionOfReturn, tryKeepingHoveringDown) {
  return packByte(writer, toByte(fromFlags(tryKeepingHoveringUp, isVoidVaultEnabled, isSitting, hasFinishedAnyDd2Event, isPettingAnimal, isTheAnimalBeingPetSmall, potionOfReturn !== void 0, tryKeepingHoveringDown)), "miscFlags2");
}
function packMiscFlags3(writer, isSleeping, autoReuseAllWeapons, controlDownHold, isOperatingAnotherEntity, controlUseTile, netCameraTarget, lastItemUseAttemptSuccess) {
  return packByte(writer, toByte(fromFlags(isSleeping, autoReuseAllWeapons, controlDownHold, isOperatingAnotherEntity, controlUseTile, isSome(netCameraTarget), lastItemUseAttemptSuccess, false)), "miscFlags3");
}
function packVelocity(writer, velocity) {
  if (velocity !== void 0) {
    return packSingle(packSingle(writer, velocity.x, "velocityX"), velocity.y, "velocityY");
  } else {
    return writer;
  }
}
function packMountType(writer, mountType) {
  if (mountType !== void 0) {
    return packUInt16(writer, mountType, "mountType");
  } else {
    return writer;
  }
}
function packPotionOfReturn(writer, potionOfReturn) {
  if (potionOfReturn !== void 0) {
    return packSingle(packSingle(packSingle(packSingle(writer, potionOfReturn.originalUsePosition.x, "potionOfReturnOrigX"), potionOfReturn.originalUsePosition.y, "potionOfReturnOrigY"), potionOfReturn.homePosition.x, "potionOfReturnHomeX"), potionOfReturn.homePosition.y, "potionOfReturnHomeY");
  } else {
    return writer;
  }
}
function packNetCameraTarget(writer, netCameraTarget) {
  if (netCameraTarget !== void 0) {
    return packSingle(packSingle(writer, netCameraTarget.x, "netCameraTargetX"), netCameraTarget.y, "netCameraTargetY");
  } else {
    return writer;
  }
}
function toBuffer93(self) {
  return data(packNetCameraTarget(packPotionOfReturn(packMountType(packVelocity(packSingle(packSingle(packByte(packMiscFlags3(packMiscFlags2(packMiscFlags1(packControlFlags(packByte(setType(make(), toInt("PlayerUpdate")), self.playerId, "playerId"), self.control, self.direction), self.pulleyDirection, self.velocity, self.vortexStealthActive, self.gravityDirection, self.shieldRaised, self.ghost, self.mountType), self.tryKeepingHoveringUp, self.isVoidVaultEnabled, self.isSitting, self.hasFinishedAnyDd2Event, self.isPettingAnimal, self.isTheAnimalBeingPetSmall, self.potionOfReturn, self.tryKeepingHoveringDown), self.isSleeping, self.autoReuseAllWeapons, self.controlDownHold, self.isOperatingAnotherEntity, self.controlUseTile, self.netCameraTarget, self.lastItemUseAttemptSuccess), self.selectedItem, "selectedItem"), self.position.x, "positionX"), self.position.y, "positionY"), self.velocity), self.mountType), self.potionOfReturn), self.netCameraTarget));
}
var Encode29 = {
  packByte,
  packSingle,
  packUInt16,
  setType,
  data,
  packControlFlags,
  packMiscFlags1,
  packMiscFlags2,
  packMiscFlags3,
  packVelocity,
  packMountType,
  packPotionOfReturn,
  packNetCameraTarget,
  toBuffer: toBuffer93
};
var Packet_PlayerInfo_exports = {};
__export(Packet_PlayerInfo_exports, {
  Color: () => Color,
  Decode: () => Decode30,
  Encode: () => Encode30,
  parse: () => parse97,
  toBuffer: () => toBuffer94
});
function getDifficulty(difficultyFlags) {
  if (flag2(difficultyFlags)) {
    return "Hardcore";
  } else if (flag1(difficultyFlags)) {
    return "Mediumcore";
  } else {
    return "Softcore";
  }
}
function parse97(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "skinVariant");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "voiceVariant");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "voicePitchOffset");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readByte(reader, "hair");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readString(reader, "name");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readByte(reader, "hairDye");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readByte(reader, "hideVisuals");
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let e$8 = readByte(reader, "hideVisuals2");
  if (e$8.TAG !== "Ok") {
    return e$8;
  }
  let e$9 = readByte(reader, "hideMisc");
  if (e$9.TAG !== "Ok") {
    return e$9;
  }
  let e$10 = readColor(reader, "hairColor");
  if (e$10.TAG !== "Ok") {
    return e$10;
  }
  let e$11 = readColor(reader, "skinColor");
  if (e$11.TAG !== "Ok") {
    return e$11;
  }
  let e$12 = readColor(reader, "eyeColor");
  if (e$12.TAG !== "Ok") {
    return e$12;
  }
  let e$13 = readColor(reader, "shirtColor");
  if (e$13.TAG !== "Ok") {
    return e$13;
  }
  let e$14 = readColor(reader, "underShirtColor");
  if (e$14.TAG !== "Ok") {
    return e$14;
  }
  let e$15 = readColor(reader, "pantsColor");
  if (e$15.TAG !== "Ok") {
    return e$15;
  }
  let e$16 = readColor(reader, "shoeColor");
  if (e$16.TAG !== "Ok") {
    return e$16;
  }
  let e$17 = readByte(reader, "difficultyFlags");
  if (e$17.TAG !== "Ok") {
    return e$17;
  }
  let difficultyFlags = fromByte(e$17._0);
  let e$18 = readByte(reader, "torchFlags");
  if (e$18.TAG !== "Ok") {
    return e$18;
  }
  let torchFlags = fromByte(e$18._0);
  let difficulty = getDifficulty(difficultyFlags);
  let extraAccessory = flag3(difficultyFlags);
  let mode = flag4(difficultyFlags) ? "Journey" : "Classic";
  let usingBiomeTorches = flag1(torchFlags);
  let happyFunTorchTime = flag2(torchFlags);
  let unlockedBiomeTorches = flag3(torchFlags);
  let unlockedSuperCart = flag4(torchFlags);
  let enabledSuperCart = flag5(torchFlags);
  let e$19 = readByte(reader, "usedFlags");
  let e$20;
  e$20 = e$19.TAG === "Ok" ? {
    TAG: "Ok",
    _0: fromByte(e$19._0)
  } : e$19;
  if (e$20.TAG !== "Ok") {
    return e$20;
  }
  let usedFlags = e$20._0;
  let usedAegisCrystal = flag1(usedFlags);
  let usedAegisFruit = flag2(usedFlags);
  let usedArcaneCrystal = flag3(usedFlags);
  let usedGalaxyPearl = flag4(usedFlags);
  let usedGummyWorm = flag5(usedFlags);
  let usedAmbrosia = flag6(usedFlags);
  let ateArtisanBread = flag7(usedFlags);
  return {
    TAG: "Ok",
    _0: {
      playerId: e._0,
      skinVariant: e$1._0,
      voiceVariant: e$2._0,
      voicePitchOffset: e$3._0,
      hair: e$4._0,
      name: e$5._0,
      hairDye: e$6._0,
      hideVisuals: e$7._0,
      hideVisuals2: e$8._0,
      hideMisc: e$9._0,
      hairColor: e$10._0,
      skinColor: e$11._0,
      eyeColor: e$12._0,
      shirtColor: e$13._0,
      underShirtColor: e$14._0,
      pantsColor: e$15._0,
      shoeColor: e$16._0,
      difficulty,
      mode,
      extraAccessory,
      usingBiomeTorches,
      unlockedBiomeTorches,
      happyFunTorchTime,
      unlockedSuperCart,
      enabledSuperCart,
      usedAegisCrystal,
      usedAegisFruit,
      usedArcaneCrystal,
      usedGalaxyPearl,
      usedGummyWorm,
      usedAmbrosia,
      ateArtisanBread
    }
  };
}
var Decode30 = {
  readSingle,
  readByte,
  readString,
  readColor,
  getDifficulty,
  parse: parse97
};
function packDifficultyFlags(writer, difficulty, extraAccessory, mode) {
  let byte = 0;
  let tmp;
  switch (difficulty) {
    case "Softcore":
      tmp = 0;
      break;
    case "Mediumcore":
      tmp = 1;
      break;
    case "Hardcore":
      tmp = 2;
      break;
  }
  byte = byte | tmp;
  byte = byte | (extraAccessory ? 4 : 0);
  byte = byte | (mode === "Journey" ? 8 : 0);
  return packByte(writer, byte, "difficultyFlags");
}
function packTorchFlags(writer, usingBiomeTorches, happyFunTorchTime, unlockedBiomeTorches, unlockedSuperCart, enabledSuperCart) {
  let byte = 0;
  byte = byte | (usingBiomeTorches ? 1 : 0);
  byte = byte | (happyFunTorchTime ? 2 : 0);
  byte = byte | (unlockedBiomeTorches ? 4 : 0);
  byte = byte | (unlockedSuperCart ? 8 : 0);
  byte = byte | (enabledSuperCart ? 16 : 0);
  return packByte(writer, byte, "torchFlags");
}
function packUsedFlags(writer, usedAegisCrystal, usedAegisFruit, usedArcaneCrystal, usedGalaxyPearl, usedGummyWorm, usedAmbrosia, ateArtisanBread) {
  let byte = 0;
  byte = byte | (usedAegisCrystal ? 1 : 0);
  byte = byte | (usedAegisFruit ? 2 : 0);
  byte = byte | (usedArcaneCrystal ? 4 : 0);
  byte = byte | (usedGalaxyPearl ? 8 : 0);
  byte = byte | (usedGummyWorm ? 16 : 0);
  byte = byte | (usedAmbrosia ? 32 : 0);
  byte = byte | (ateArtisanBread ? 64 : 0);
  return packByte(writer, byte, "usedFlags");
}
function toBuffer94(self) {
  return data(packUsedFlags(packTorchFlags(packDifficultyFlags(packColor(packColor(packColor(packColor(packColor(packColor(packColor(packByte(packByte(packByte(packByte(packString(packByte(packSingle(packByte(packByte(packByte(setType(make(), toInt("PlayerInfo")), self.playerId, "playerId"), self.skinVariant, "skinVariant"), self.voiceVariant, "voiceVariant"), self.voicePitchOffset, "voicePitchOffset"), self.hair, "hair"), self.name, "name"), self.hairDye, "hairDye"), self.hideVisuals, "hideVisuals"), self.hideVisuals2, "hideVisuals2"), self.hideMisc, "hideMisc"), self.hairColor, "hairColor"), self.skinColor, "skinColor"), self.eyeColor, "eyeColor"), self.shirtColor, "shirtColor"), self.underShirtColor, "underShirtColor"), self.pantsColor, "pantsColor"), self.shoeColor, "shoeColor"), self.difficulty, self.extraAccessory, self.mode), self.usingBiomeTorches, self.happyFunTorchTime, self.unlockedBiomeTorches, self.unlockedSuperCart, self.enabledSuperCart), self.usedAegisCrystal, self.usedAegisFruit, self.usedArcaneCrystal, self.usedGalaxyPearl, self.usedGummyWorm, self.usedAmbrosia, self.ateArtisanBread));
}
var Encode30 = {
  packSingle,
  packByte,
  packString,
  packColor,
  setType,
  data,
  packDifficultyFlags,
  packTorchFlags,
  packUsedFlags,
  toBuffer: toBuffer94
};
var Color;
var Packet_PlayerSpawn_exports = {};
__export(Packet_PlayerSpawn_exports, {
  Decode: () => Decode31,
  Encode: () => Encode31,
  parse: () => parse98,
  toBuffer: () => toBuffer95
});
function parse98(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt32(reader, "timeRemaining");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt16(reader, "numberOfDeathsPve");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readInt16(reader, "numberOfDeathsPvp");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readByte(reader, "team");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readByte(reader, "context");
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let rawContext = e$7._0;
  let context;
  switch (rawContext) {
    case 0:
      context = "ReviveFromDeath";
      break;
    case 1:
      context = "SpawningIntoWorld";
      break;
    case 2:
      context = "RecallFromItem";
      break;
    case 3:
      context = "TeamSwap";
      break;
    default:
      context = {
        TAG: "Unknown",
        _0: rawContext
      };
  }
  return {
    TAG: "Ok",
    _0: {
      playerId: e._0,
      x: e$1._0,
      y: e$2._0,
      timeRemaining: e$3._0,
      numberOfDeathsPve: e$4._0,
      numberOfDeathsPvp: e$5._0,
      team: e$6._0,
      context
    }
  };
}
var Decode31 = {
  readByte,
  readInt16,
  readInt32,
  parse: parse98
};
function toBuffer95(self) {
  let n = self.context;
  let tmp;
  if (typeof n !== "object") {
    switch (n) {
      case "ReviveFromDeath":
        tmp = 0;
        break;
      case "SpawningIntoWorld":
        tmp = 1;
        break;
      case "RecallFromItem":
        tmp = 2;
        break;
      case "TeamSwap":
        tmp = 3;
        break;
    }
  } else {
    tmp = n._0;
  }
  return data(packByte(packByte(packInt16(packInt16(packInt32(packInt16(packInt16(packByte(setType(make(), toInt("PlayerSpawn")), self.playerId, "playerId"), self.x, "x"), self.y, "y"), self.timeRemaining, "timeRemaining"), self.numberOfDeathsPve, "numberOfDeathsPve"), self.numberOfDeathsPvp, "numberOfDeathsPvp"), self.team, "team"), tmp, "context"));
}
var Encode31 = {
  toBuffer: toBuffer95
};
var Packet_PlayerInventorySlot_exports = {};
__export(Packet_PlayerInventorySlot_exports, {
  Decode: () => Decode32,
  Encode: () => Encode32,
  parse: () => parse99,
  toBuffer: () => toBuffer96
});
function parse99(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "slot");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "stack");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "prefix");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt16(reader, "itemType");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readByte(reader, "flags");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let flags = fromByte(e$5._0);
  return {
    TAG: "Ok",
    _0: {
      playerId: e._0,
      slot: e$1._0,
      stack: e$2._0,
      prefix: e$3._0,
      itemType: e$4._0,
      favorited: flag1(flags),
      blocked: flag2(flags)
    }
  };
}
var Decode32 = {
  parse: parse99
};
function toBuffer96(self) {
  return data(packByte(packInt16(packByte(packInt16(packInt16(packByte(setType(make(), toInt("PlayerInventorySlot")), self.playerId, "playerId"), self.slot, "slot"), self.stack, "stack"), self.prefix, "prefix"), self.itemType, "itemType"), toByte(fromFlags(self.favorited, self.blocked, false, false, false, false, false, false)), "flags"));
}
var Encode32 = {
  packInt16,
  packByte,
  setType,
  data,
  toBuffer: toBuffer96
};
var PacketV1449_PlayerHealth_exports = {};
__export(PacketV1449_PlayerHealth_exports, {
  parse: () => parse100,
  toBuffer: () => toBuffer97
});
function parse100(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "health");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "maxHealth");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        health: e$1._0,
        maxHealth: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function toBuffer97(self) {
  return data(packInt16(packInt16(packByte(setType(make(), toInt("PlayerHealth")), self.playerId, "playerId"), self.health, "health"), self.maxHealth, "maxHealth"));
}
var PacketV1449_ClientUuid_exports = {};
__export(PacketV1449_ClientUuid_exports, {
  parse: () => parse101,
  toBuffer: () => toBuffer98
});
function parse101(payload) {
  let reader = new packetreader_default(payload);
  let e = readString(reader, "uuid");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        uuid: e._0
      }
    };
  } else {
    return e;
  }
}
function toBuffer98(self) {
  return data(packString(setType(make(), toInt("ClientUuid")), self.uuid, "uuid"));
}
var PacketV1449_ProjectileSync_exports = {};
__export(PacketV1449_ProjectileSync_exports, {
  parse: () => parse102,
  toBuffer: () => toBuffer99
});
function parse102(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "projectileId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "vx");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readSingle(reader, "vy");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readByte(reader, "owner");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readInt16(reader, "projectileType");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readByte(reader, "flags");
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let flags = fromByte(e$7._0);
  let e$8;
  if (flag3(flags)) {
    let e$9 = readByte(reader, "flags2");
    e$8 = e$9.TAG === "Ok" ? {
      TAG: "Ok",
      _0: some(fromByte(e$9._0))
    } : e$9;
  } else {
    e$8 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$8.TAG !== "Ok") {
    return e$8;
  }
  let flags2 = e$8._0;
  let e$10;
  if (flag1(flags)) {
    let e$11 = readSingle(reader, "ai0");
    e$10 = e$11.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$11._0
    } : e$11;
  } else {
    e$10 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$10.TAG !== "Ok") {
    return e$10;
  }
  let e$12;
  if (flag2(flags)) {
    let e$13 = readSingle(reader, "ai1");
    e$12 = e$13.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$13._0
    } : e$13;
  } else {
    e$12 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$12.TAG !== "Ok") {
    return e$12;
  }
  let e$14;
  if (flag4(flags)) {
    let e$15 = readUInt16(reader, "bannerIdToRespondTo");
    e$14 = e$15.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$15._0
    } : e$15;
  } else {
    e$14 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$14.TAG !== "Ok") {
    return e$14;
  }
  let e$16;
  if (flag5(flags)) {
    let e$17 = readInt16(reader, "damage");
    e$16 = e$17.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$17._0
    } : e$17;
  } else {
    e$16 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$16.TAG !== "Ok") {
    return e$16;
  }
  let e$18;
  if (flag6(flags)) {
    let e$19 = readSingle(reader, "knockback");
    e$18 = e$19.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$19._0
    } : e$19;
  } else {
    e$18 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$18.TAG !== "Ok") {
    return e$18;
  }
  let e$20;
  if (flag7(flags)) {
    let e$21 = readInt16(reader, "originalDamage");
    e$20 = e$21.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$21._0
    } : e$21;
  } else {
    e$20 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$20.TAG !== "Ok") {
    return e$20;
  }
  let e$22;
  if (flag8(flags)) {
    let e$23 = readInt16(reader, "projectileUuid");
    e$22 = e$23.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$23._0
    } : e$23;
  } else {
    e$22 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$22.TAG !== "Ok") {
    return e$22;
  }
  let e$24;
  if (flags2 !== void 0 && flag1(valFromOption(flags2))) {
    let e$25 = readSingle(reader, "ai2");
    e$24 = e$25.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$25._0
    } : e$25;
  } else {
    e$24 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$24.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        projectileId: e._0,
        x: e$1._0,
        y: e$2._0,
        vx: e$3._0,
        vy: e$4._0,
        owner: e$5._0,
        projectileType: e$6._0,
        ai: [
          e$10._0,
          e$12._0,
          e$24._0
        ],
        bannerIdToRespondTo: e$14._0,
        damage: e$16._0,
        knockback: e$18._0,
        originalDamage: e$20._0,
        projectileUuid: e$22._0
      }
    };
  } else {
    return e$24;
  }
}
function packOptionalData(writer, self) {
  let match = self.ai;
  let ai2 = match[2];
  let ai1 = match[1];
  let ai0 = match[0];
  let bitFlags2 = fromFlags(isSome(ai2), false, false, false, false, false, false, false);
  let bannerIdToRespondTo = self.bannerIdToRespondTo;
  let bitFlags = fromFlags(isSome(ai0), isSome(ai1), toByte(bitFlags2) !== 0, bannerIdToRespondTo !== void 0 ? bannerIdToRespondTo !== 0 : false, isSome(self.damage), isSome(self.knockback), isSome(self.originalDamage), isSome(self.projectileUuid));
  packByte(writer, toByte(bitFlags), "flags");
  if (flag3(bitFlags)) {
    packByte(writer, toByte(bitFlags2), "flags2");
  }
  if (flag1(bitFlags)) {
    packSingle(writer, ai0, "ai0");
  }
  if (flag2(bitFlags)) {
    packSingle(writer, ai1, "ai1");
  }
  if (flag4(bitFlags)) {
    packUInt16(writer, self.bannerIdToRespondTo, "bannerIdToRespondTo");
  }
  if (flag5(bitFlags)) {
    packInt16(writer, self.damage, "damage");
  }
  if (flag6(bitFlags)) {
    packSingle(writer, self.knockback, "knockback");
  }
  if (flag7(bitFlags)) {
    packInt16(writer, self.originalDamage, "originalDamage");
  }
  if (flag8(bitFlags)) {
    packInt16(writer, self.projectileUuid, "projectileUuid");
  }
  if (flag1(bitFlags2)) {
    packSingle(writer, ai2, "ai2");
  }
  return writer;
}
function toBuffer99(self) {
  return data(packOptionalData(packInt16(packByte(packSingle(packSingle(packSingle(packSingle(packInt16(setType(make(), toInt("ProjectileSync")), self.projectileId, "projectileId"), self.x, "x"), self.y, "y"), self.vx, "vx"), self.vy, "vy"), self.owner, "owner"), self.projectileType, "projectileType"), self));
}
var PacketV1449_PlayerDamage_exports = {};
__export(PacketV1449_PlayerDamage_exports, {
  parse: () => parse103,
  toBuffer: () => toBuffer100
});
function readDamageFlags(reader) {
  let e = readByte(reader, "damageFlags");
  if (e.TAG !== "Ok") {
    return e;
  }
  let flags = fromByte(e._0);
  return {
    TAG: "Ok",
    _0: {
      critical: flag1(flags),
      pvp: flag2(flags)
    }
  };
}
function parse103(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "target");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readDeathReason(reader);
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "damage");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "hitDirection");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readDamageFlags(reader);
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let damageFlags = e$4._0;
  let e$5 = readSByte(reader, "cooldownCounter");
  if (e$5.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        target: e._0,
        deathReason: e$1._0,
        damage: e$2._0,
        hitDirection: e$3._0,
        critical: damageFlags.critical,
        pvp: damageFlags.pvp,
        cooldownCounter: e$5._0
      }
    };
  } else {
    return e$5;
  }
}
function toBuffer100(self) {
  let damageFlags = (self2) => toByte(fromFlags(self2.critical, self2.pvp, false, false, false, false, false, false));
  return data(packSByte(packByte(packByte(packInt16(packDeathReason(packByte(setType(make(), toInt("PlayerDamage")), self.target, "target"), self.deathReason), self.damage, "damage"), self.hitDirection, "hitDirection"), damageFlags(self), "damageFlags"), self.cooldownCounter, "cooldownCounter"));
}
var Packet_WorldInfo_exports = {};
__export(Packet_WorldInfo_exports, {
  Decode: () => Decode33,
  Encode: () => Encode33,
  parse: () => parse104,
  toBuffer: () => toBuffer101
});
function readEventInfo(reader) {
  let e = readByte(reader, "eventInfo1");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "eventInfo2");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "eventInfo3");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "eventInfo4");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readByte(reader, "eventInfo5");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readByte(reader, "eventInfo6");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readByte(reader, "eventInfo7");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readByte(reader, "eventInfo8");
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let e$8 = readByte(reader, "eventInfo9");
  if (e$8.TAG !== "Ok") {
    return e$8;
  }
  let e$9 = readByte(reader, "eventInfo10");
  if (e$9.TAG !== "Ok") {
    return e$9;
  }
  let eventInfo1 = fromByte(e._0);
  let eventInfo2 = fromByte(e$1._0);
  let eventInfo3 = fromByte(e$2._0);
  let eventInfo4 = fromByte(e$3._0);
  let eventInfo5 = fromByte(e$4._0);
  let eventInfo6 = fromByte(e$5._0);
  let eventInfo7 = fromByte(e$6._0);
  let eventInfo8 = fromByte(e$7._0);
  let eventInfo9 = fromByte(e$8._0);
  let eventInfo10 = fromByte(e$9._0);
  let shadowOrbSmashed = flag1(eventInfo1);
  let killedBoss1 = flag2(eventInfo1);
  let killedBoss2 = flag3(eventInfo1);
  let killedBoss3 = flag4(eventInfo1);
  let hardMode = flag5(eventInfo1);
  let killedClown = flag6(eventInfo1);
  let serverSidedCharacters = flag7(eventInfo1);
  let killedPlantBoss = flag8(eventInfo1);
  let killedMechBoss = flag1(eventInfo2);
  let killedMechBoss2 = flag2(eventInfo2);
  let killedMechBoss3 = flag3(eventInfo2);
  let killedAnyMechBoss = flag4(eventInfo2);
  let cloudBg = flag5(eventInfo2);
  let crimson = flag6(eventInfo2);
  let pumpkinMoon = flag7(eventInfo2);
  let snowMoon = flag8(eventInfo2);
  let expertMode = flag1(eventInfo3);
  let fastForwardTime = flag2(eventInfo3);
  let slimeRain = flag3(eventInfo3);
  let killedKingSlime = flag4(eventInfo3);
  let killedQueenBee = flag5(eventInfo3);
  let killedFishron = flag6(eventInfo3);
  let killedMartians = flag7(eventInfo3);
  let killedAncientCultist = flag8(eventInfo3);
  let killedMoonLord = flag1(eventInfo4);
  let killedPumpking = flag2(eventInfo4);
  let killedMourningWood = flag3(eventInfo4);
  let killedIceQueen = flag4(eventInfo4);
  let killedSantank = flag5(eventInfo4);
  let killedEverscream = flag6(eventInfo4);
  let killedGolem = flag7(eventInfo4);
  let birthdayParty = flag8(eventInfo4);
  let killedPirates = flag1(eventInfo5);
  let killedFrostLegion = flag2(eventInfo5);
  let killedGoblins = flag3(eventInfo5);
  let sandstorm = flag4(eventInfo5);
  let dungeonDefendersEvent = flag5(eventInfo5);
  let killedDungeonDefendersTier1 = flag6(eventInfo5);
  let killedDungeonDefendersTier2 = flag7(eventInfo5);
  let killedDungeonDefendersTier3 = flag8(eventInfo5);
  let combatBookUsed = flag1(eventInfo6);
  let manualLanterns = flag2(eventInfo6);
  let killedSolarTower = flag3(eventInfo6);
  let killedVortexTower = flag4(eventInfo6);
  let killedNebulaTower = flag5(eventInfo6);
  let killedStardustTower = flag6(eventInfo6);
  let forceHalloween = flag7(eventInfo6);
  let forceChristmas = flag8(eventInfo6);
  let boughtCat = flag1(eventInfo7);
  let boughtDog = flag2(eventInfo7);
  let boughtBunny = flag3(eventInfo7);
  let freeCake = flag4(eventInfo7);
  let drunkWorld = flag5(eventInfo7);
  let killedEmpressOfLight = flag6(eventInfo7);
  let killedQueenSlime = flag7(eventInfo7);
  let getGoodWorld = flag8(eventInfo7);
  let tenthAnniversaryWorld = flag1(eventInfo8);
  let dontStarveWorld = flag2(eventInfo8);
  let downedDeerClops = flag3(eventInfo8);
  let notTheBeesWorld = flag4(eventInfo8);
  let remixWorld = flag5(eventInfo8);
  let unlockedSlimeBlueSpawn = flag6(eventInfo8);
  let combatBookVolumeTwoWasUsed = flag7(eventInfo8);
  let peddlersSatchelWasUsed = flag8(eventInfo8);
  let unlockedSlimeGreenSpawn = flag1(eventInfo9);
  let unlockedSlimeOldSpawn = flag2(eventInfo9);
  let unlockedSlimePurpleSpawn = flag3(eventInfo9);
  let unlockedSlimeRainbowSpawn = flag4(eventInfo9);
  let unlockedSlimeRedSpawn = flag5(eventInfo9);
  let unlockedSlimeYellowSpawn = flag6(eventInfo9);
  let unlockedSlimeCopperSpawn = flag7(eventInfo9);
  let fastForwardTimeToDusk = flag8(eventInfo9);
  let noTrapsWorld = flag1(eventInfo10);
  let zenithWorld = flag2(eventInfo10);
  let unlockedTruffleSpawn = flag3(eventInfo10);
  let vampireSeed = flag4(eventInfo10);
  let infectedSeed = flag5(eventInfo10);
  let teamBasedSpawnsSeed = flag6(eventInfo10);
  let skyblockWorld = flag7(eventInfo10);
  let dualDungeonsSeed = flag8(eventInfo10);
  return {
    TAG: "Ok",
    _0: {
      shadowOrbSmashed,
      killedBoss1,
      killedBoss2,
      killedBoss3,
      hardMode,
      killedClown,
      serverSidedCharacters,
      killedPlantBoss,
      killedMechBoss,
      killedMechBoss2,
      killedMechBoss3,
      killedAnyMechBoss,
      cloudBg,
      crimson,
      pumpkinMoon,
      snowMoon,
      expertMode,
      fastForwardTime,
      slimeRain,
      killedKingSlime,
      killedQueenBee,
      killedFishron,
      killedMartians,
      killedAncientCultist,
      killedMoonLord,
      killedPumpking,
      killedMourningWood,
      killedIceQueen,
      killedSantank,
      killedEverscream,
      killedGolem,
      birthdayParty,
      killedPirates,
      killedFrostLegion,
      killedGoblins,
      sandstorm,
      dungeonDefendersEvent,
      killedDungeonDefendersTier1,
      killedDungeonDefendersTier2,
      killedDungeonDefendersTier3,
      combatBookUsed,
      manualLanterns,
      killedSolarTower,
      killedVortexTower,
      killedNebulaTower,
      killedStardustTower,
      forceHalloween,
      forceChristmas,
      boughtCat,
      boughtDog,
      boughtBunny,
      freeCake,
      drunkWorld,
      killedEmpressOfLight,
      killedQueenSlime,
      getGoodWorld,
      tenthAnniversaryWorld,
      dontStarveWorld,
      downedDeerClops,
      notTheBeesWorld,
      remixWorld,
      unlockedSlimeBlueSpawn,
      combatBookVolumeTwoWasUsed,
      peddlersSatchelWasUsed,
      unlockedSlimeGreenSpawn,
      unlockedSlimeOldSpawn,
      unlockedSlimePurpleSpawn,
      unlockedSlimeRainbowSpawn,
      unlockedSlimeRedSpawn,
      unlockedSlimeYellowSpawn,
      unlockedSlimeCopperSpawn,
      fastForwardTimeToDusk,
      noTrapsWorld,
      zenithWorld,
      unlockedTruffleSpawn,
      vampireSeed,
      infectedSeed,
      teamBasedSpawnsSeed,
      skyblockWorld,
      dualDungeonsSeed
    }
  };
}
function parse104(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt32(reader, "time");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "dayAndMoonInfo");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "moonPhase");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt16(reader, "maxTilesX");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt16(reader, "maxTilesY");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readInt16(reader, "spawnX");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readInt16(reader, "spawnY");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readInt16(reader, "worldSurface");
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let e$8 = readInt16(reader, "rockLayer");
  if (e$8.TAG !== "Ok") {
    return e$8;
  }
  let e$9 = readInt32(reader, "worldId");
  if (e$9.TAG !== "Ok") {
    return e$9;
  }
  let e$10 = readString(reader, "worldName");
  if (e$10.TAG !== "Ok") {
    return e$10;
  }
  let e$11 = readByte(reader, "gameMode");
  if (e$11.TAG !== "Ok") {
    return e$11;
  }
  let e$12 = readBytes(reader, 16, "worldUniqueId");
  if (e$12.TAG !== "Ok") {
    return e$12;
  }
  let worldUniqueId = fromArray2(e$12._0);
  let e$13 = worldUniqueId !== void 0 ? {
    TAG: "Ok",
    _0: valFromOption(worldUniqueId)
  } : {
    TAG: "Error",
    _0: {
      context: "WorldInfo.parse.worldUniqueId",
      error: new Error("Invalid worldUniqueId")
    }
  };
  if (e$13.TAG !== "Ok") {
    return e$13;
  }
  let e$14 = readUInt64(reader, "worldGeneratorVersion");
  if (e$14.TAG !== "Ok") {
    return e$14;
  }
  let e$15 = readByte(reader, "moonType");
  if (e$15.TAG !== "Ok") {
    return e$15;
  }
  let e$16 = readByte(reader, "treeBackground");
  if (e$16.TAG !== "Ok") {
    return e$16;
  }
  let e$17 = readByte(reader, "treeBackground2");
  if (e$17.TAG !== "Ok") {
    return e$17;
  }
  let e$18 = readByte(reader, "treeBackground3");
  if (e$18.TAG !== "Ok") {
    return e$18;
  }
  let e$19 = readByte(reader, "treeBackground4");
  if (e$19.TAG !== "Ok") {
    return e$19;
  }
  let e$20 = readByte(reader, "corruptionBackground");
  if (e$20.TAG !== "Ok") {
    return e$20;
  }
  let e$21 = readByte(reader, "jungleBackground");
  if (e$21.TAG !== "Ok") {
    return e$21;
  }
  let e$22 = readByte(reader, "snowBackground");
  if (e$22.TAG !== "Ok") {
    return e$22;
  }
  let e$23 = readByte(reader, "hallowBackground");
  if (e$23.TAG !== "Ok") {
    return e$23;
  }
  let e$24 = readByte(reader, "crimsonBackground");
  if (e$24.TAG !== "Ok") {
    return e$24;
  }
  let e$25 = readByte(reader, "desertBackground");
  if (e$25.TAG !== "Ok") {
    return e$25;
  }
  let e$26 = readByte(reader, "oceanBackground");
  if (e$26.TAG !== "Ok") {
    return e$26;
  }
  let e$27 = readByte(reader, "mushroomBackground");
  if (e$27.TAG !== "Ok") {
    return e$27;
  }
  let e$28 = readByte(reader, "underworldBackground");
  if (e$28.TAG !== "Ok") {
    return e$28;
  }
  let e$29 = readByte(reader, "iceBackStyle");
  if (e$29.TAG !== "Ok") {
    return e$29;
  }
  let e$30 = readByte(reader, "jungleBackStyle");
  if (e$30.TAG !== "Ok") {
    return e$30;
  }
  let e$31 = readByte(reader, "hellBackStyle");
  if (e$31.TAG !== "Ok") {
    return e$31;
  }
  let e$32 = readSingle(reader, "windSpeedSet");
  if (e$32.TAG !== "Ok") {
    return e$32;
  }
  let e$33 = readByte(reader, "cloudNumber");
  if (e$33.TAG !== "Ok") {
    return e$33;
  }
  let e$34 = readInt32(reader, "tree1");
  if (e$34.TAG !== "Ok") {
    return e$34;
  }
  let e$35 = readInt32(reader, "tree2");
  if (e$35.TAG !== "Ok") {
    return e$35;
  }
  let e$36 = readInt32(reader, "tree3");
  if (e$36.TAG !== "Ok") {
    return e$36;
  }
  let e$37 = readByte(reader, "treeStyle1");
  if (e$37.TAG !== "Ok") {
    return e$37;
  }
  let e$38 = readByte(reader, "treeStyle2");
  if (e$38.TAG !== "Ok") {
    return e$38;
  }
  let e$39 = readByte(reader, "treeStyle3");
  if (e$39.TAG !== "Ok") {
    return e$39;
  }
  let e$40 = readByte(reader, "treeStyle4");
  if (e$40.TAG !== "Ok") {
    return e$40;
  }
  let e$41 = readInt32(reader, "caveBack1");
  if (e$41.TAG !== "Ok") {
    return e$41;
  }
  let e$42 = readInt32(reader, "caveBack2");
  if (e$42.TAG !== "Ok") {
    return e$42;
  }
  let e$43 = readInt32(reader, "caveBack3");
  if (e$43.TAG !== "Ok") {
    return e$43;
  }
  let e$44 = readByte(reader, "caveBackStyle1");
  if (e$44.TAG !== "Ok") {
    return e$44;
  }
  let e$45 = readByte(reader, "caveBackStyle2");
  if (e$45.TAG !== "Ok") {
    return e$45;
  }
  let e$46 = readByte(reader, "caveBackStyle3");
  if (e$46.TAG !== "Ok") {
    return e$46;
  }
  let e$47 = readByte(reader, "caveBackStyle4");
  if (e$47.TAG !== "Ok") {
    return e$47;
  }
  let e$48 = readByte(reader, "forest1TreeTopStyle");
  if (e$48.TAG !== "Ok") {
    return e$48;
  }
  let e$49 = readByte(reader, "forest2TreeTopStyle");
  if (e$49.TAG !== "Ok") {
    return e$49;
  }
  let e$50 = readByte(reader, "forest3TreeTopStyle");
  if (e$50.TAG !== "Ok") {
    return e$50;
  }
  let e$51 = readByte(reader, "forest4TreeTopStyle");
  if (e$51.TAG !== "Ok") {
    return e$51;
  }
  let e$52 = readByte(reader, "corruptionTreeTopStyle");
  if (e$52.TAG !== "Ok") {
    return e$52;
  }
  let e$53 = readByte(reader, "jungleTreeTopStyle");
  if (e$53.TAG !== "Ok") {
    return e$53;
  }
  let e$54 = readByte(reader, "snowTreeTopStyle");
  if (e$54.TAG !== "Ok") {
    return e$54;
  }
  let e$55 = readByte(reader, "hallowTreeTopStyle");
  if (e$55.TAG !== "Ok") {
    return e$55;
  }
  let e$56 = readByte(reader, "crimsonTreeTopStyle");
  if (e$56.TAG !== "Ok") {
    return e$56;
  }
  let e$57 = readByte(reader, "desertTreeTopStyle");
  if (e$57.TAG !== "Ok") {
    return e$57;
  }
  let e$58 = readByte(reader, "oceanTreeTopStyle");
  if (e$58.TAG !== "Ok") {
    return e$58;
  }
  let e$59 = readByte(reader, "glowingMushroomTreeTopStyle");
  if (e$59.TAG !== "Ok") {
    return e$59;
  }
  let e$60 = readByte(reader, "underworldTreeTopStyle");
  if (e$60.TAG !== "Ok") {
    return e$60;
  }
  let e$61 = readSingle(reader, "rain");
  if (e$61.TAG !== "Ok") {
    return e$61;
  }
  let e$62 = readEventInfo(reader);
  if (e$62.TAG !== "Ok") {
    return e$62;
  }
  let e$63 = readByte(reader, "lowTiles");
  if (e$63.TAG !== "Ok") {
    return e$63;
  }
  let lowTiles = flag1(fromByte(e$63._0));
  let e$64 = readByte(reader, "sundialCooldown");
  if (e$64.TAG !== "Ok") {
    return e$64;
  }
  let e$65 = readByte(reader, "moondialCooldown");
  if (e$65.TAG !== "Ok") {
    return e$65;
  }
  let e$66 = readInt16(reader, "copperOreTier");
  if (e$66.TAG !== "Ok") {
    return e$66;
  }
  let e$67 = readInt16(reader, "ironOreTier");
  if (e$67.TAG !== "Ok") {
    return e$67;
  }
  let e$68 = readInt16(reader, "silverOreTier");
  if (e$68.TAG !== "Ok") {
    return e$68;
  }
  let e$69 = readInt16(reader, "goldOreTier");
  if (e$69.TAG !== "Ok") {
    return e$69;
  }
  let e$70 = readInt16(reader, "cobaltOreTier");
  if (e$70.TAG !== "Ok") {
    return e$70;
  }
  let e$71 = readInt16(reader, "mythrilOreTier");
  if (e$71.TAG !== "Ok") {
    return e$71;
  }
  let e$72 = readInt16(reader, "adamantiteOreTier");
  if (e$72.TAG !== "Ok") {
    return e$72;
  }
  let e$73 = readSByte(reader, "invasionType");
  if (e$73.TAG !== "Ok") {
    return e$73;
  }
  let e$74 = readUInt64(reader, "lobbyId");
  if (e$74.TAG !== "Ok") {
    return e$74;
  }
  let e$75 = readSingle(reader, "sandstormSeverity");
  if (e$75.TAG !== "Ok") {
    return e$75;
  }
  let e$76 = readByte(reader, "extraSpawnPointCount");
  if (e$76.TAG !== "Ok") {
    return e$76;
  }
  let extraSpawnPointCount = e$76._0;
  let extraSpawnPoints = [];
  let readExtraSpawnPoints = (_idx) => {
    while (true) {
      let idx = _idx;
      if (idx >= extraSpawnPointCount) {
        return {
          TAG: "Ok",
          _0: void 0
        };
      }
      let e2 = readInt16(reader, `extraSpawnPointX_` + idx.toString());
      if (e2.TAG !== "Ok") {
        return e2;
      }
      let e$110 = readInt16(reader, `extraSpawnPointY_` + idx.toString());
      if (e$110.TAG !== "Ok") {
        return e$110;
      }
      extraSpawnPoints.push({
        x: e2._0,
        y: e$110._0
      });
      _idx = idx + 1 | 0;
      continue;
    }
    ;
  };
  let e$77 = readExtraSpawnPoints(0);
  if (e$77.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        time: e._0,
        dayAndMoonInfo: e$1._0,
        moonPhase: e$2._0,
        maxTilesX: e$3._0,
        maxTilesY: e$4._0,
        spawnX: e$5._0,
        spawnY: e$6._0,
        worldSurface: e$7._0,
        rockLayer: e$8._0,
        worldId: e$9._0,
        worldName: e$10._0,
        gameMode: e$11._0,
        worldUniqueId: e$13._0,
        worldGeneratorVersion: e$14._0,
        moonType: e$15._0,
        treeBackground: e$16._0,
        treeBackground2: e$17._0,
        treeBackground3: e$18._0,
        treeBackground4: e$19._0,
        corruptionBackground: e$20._0,
        jungleBackground: e$21._0,
        snowBackground: e$22._0,
        hallowBackground: e$23._0,
        crimsonBackground: e$24._0,
        desertBackground: e$25._0,
        oceanBackground: e$26._0,
        mushroomBackground: e$27._0,
        underworldBackground: e$28._0,
        iceBackStyle: e$29._0,
        jungleBackStyle: e$30._0,
        hellBackStyle: e$31._0,
        windSpeedSet: e$32._0,
        cloudNumber: e$33._0,
        tree1: e$34._0,
        tree2: e$35._0,
        tree3: e$36._0,
        treeStyle1: e$37._0,
        treeStyle2: e$38._0,
        treeStyle3: e$39._0,
        treeStyle4: e$40._0,
        caveBack1: e$41._0,
        caveBack2: e$42._0,
        caveBack3: e$43._0,
        caveBackStyle1: e$44._0,
        caveBackStyle2: e$45._0,
        caveBackStyle3: e$46._0,
        caveBackStyle4: e$47._0,
        forest1TreeTopStyle: e$48._0,
        forest2TreeTopStyle: e$49._0,
        forest3TreeTopStyle: e$50._0,
        forest4TreeTopStyle: e$51._0,
        corruptionTreeTopStyle: e$52._0,
        jungleTreeTopStyle: e$53._0,
        snowTreeTopStyle: e$54._0,
        hallowTreeTopStyle: e$55._0,
        crimsonTreeTopStyle: e$56._0,
        desertTreeTopStyle: e$57._0,
        oceanTreeTopStyle: e$58._0,
        glowingMushroomTreeTopStyle: e$59._0,
        underworldTreeTopStyle: e$60._0,
        rain: e$61._0,
        eventInfo: e$62._0,
        lowTiles,
        sundialCooldown: e$64._0,
        moondialCooldown: e$65._0,
        copperOreTier: e$66._0,
        ironOreTier: e$67._0,
        silverOreTier: e$68._0,
        goldOreTier: e$69._0,
        cobaltOreTier: e$70._0,
        mythrilOreTier: e$71._0,
        adamantiteOreTier: e$72._0,
        invasionType: e$73._0,
        lobbyId: e$74._0,
        sandstormSeverity: e$75._0,
        extraSpawnPoints
      }
    };
  } else {
    return e$77;
  }
}
var Decode33 = {
  readByte,
  readInt16,
  readInt32,
  readUInt64,
  readString,
  readBytes,
  readSingle,
  readSByte,
  readEventInfo,
  parse: parse104
};
function packEventInfo(writer, eventInfo) {
  let eventInfo1 = fromFlags(eventInfo.shadowOrbSmashed, eventInfo.killedBoss1, eventInfo.killedBoss2, eventInfo.killedBoss3, eventInfo.hardMode, eventInfo.killedClown, eventInfo.serverSidedCharacters, eventInfo.killedPlantBoss);
  let eventInfo2 = fromFlags(eventInfo.killedMechBoss, eventInfo.killedMechBoss2, eventInfo.killedMechBoss3, eventInfo.killedAnyMechBoss, eventInfo.cloudBg, eventInfo.crimson, eventInfo.pumpkinMoon, eventInfo.snowMoon);
  let eventInfo3 = fromFlags(eventInfo.expertMode, eventInfo.fastForwardTime, eventInfo.slimeRain, eventInfo.killedKingSlime, eventInfo.killedQueenBee, eventInfo.killedFishron, eventInfo.killedMartians, eventInfo.killedAncientCultist);
  let eventInfo4 = fromFlags(eventInfo.killedMoonLord, eventInfo.killedPumpking, eventInfo.killedMourningWood, eventInfo.killedIceQueen, eventInfo.killedSantank, eventInfo.killedEverscream, eventInfo.killedGolem, eventInfo.birthdayParty);
  let eventInfo5 = fromFlags(eventInfo.killedPirates, eventInfo.killedFrostLegion, eventInfo.killedGoblins, eventInfo.sandstorm, eventInfo.dungeonDefendersEvent, eventInfo.killedDungeonDefendersTier1, eventInfo.killedDungeonDefendersTier2, eventInfo.killedDungeonDefendersTier3);
  let eventInfo6 = fromFlags(eventInfo.combatBookUsed, eventInfo.manualLanterns, eventInfo.killedSolarTower, eventInfo.killedVortexTower, eventInfo.killedNebulaTower, eventInfo.killedStardustTower, eventInfo.forceHalloween, eventInfo.forceChristmas);
  let eventInfo7 = fromFlags(eventInfo.boughtCat, eventInfo.boughtDog, eventInfo.boughtBunny, eventInfo.freeCake, eventInfo.drunkWorld, eventInfo.killedEmpressOfLight, eventInfo.killedQueenSlime, eventInfo.getGoodWorld);
  let eventInfo8 = fromFlags(eventInfo.tenthAnniversaryWorld, eventInfo.dontStarveWorld, eventInfo.downedDeerClops, eventInfo.notTheBeesWorld, eventInfo.remixWorld, eventInfo.unlockedSlimeBlueSpawn, eventInfo.combatBookVolumeTwoWasUsed, eventInfo.peddlersSatchelWasUsed);
  let eventInfo9 = fromFlags(eventInfo.unlockedSlimeGreenSpawn, eventInfo.unlockedSlimeOldSpawn, eventInfo.unlockedSlimePurpleSpawn, eventInfo.unlockedSlimeRainbowSpawn, eventInfo.unlockedSlimeRedSpawn, eventInfo.unlockedSlimeYellowSpawn, eventInfo.unlockedSlimeCopperSpawn, eventInfo.fastForwardTimeToDusk);
  let eventInfo10 = fromFlags(eventInfo.noTrapsWorld, eventInfo.zenithWorld, eventInfo.unlockedTruffleSpawn, eventInfo.vampireSeed, eventInfo.infectedSeed, eventInfo.teamBasedSpawnsSeed, eventInfo.skyblockWorld, eventInfo.dualDungeonsSeed);
  return packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(writer, toByte(eventInfo1), "eventInfo1"), toByte(eventInfo2), "eventInfo2"), toByte(eventInfo3), "eventInfo3"), toByte(eventInfo4), "eventInfo4"), toByte(eventInfo5), "eventInfo5"), toByte(eventInfo6), "eventInfo6"), toByte(eventInfo7), "eventInfo7"), toByte(eventInfo8), "eventInfo8"), toByte(eventInfo9), "eventInfo9"), toByte(eventInfo10), "eventInfo10");
}
function packExtraSpawnPoints(writer, extraSpawnPoints) {
  let writer$1 = packByte(writer, extraSpawnPoints.length, "extraSpawnPointCount");
  extraSpawnPoints.forEach((point, idx) => {
    let idxLabel = idx.toString();
    packInt16(packInt16(writer$1, point.x, `extraSpawnPointX_` + idxLabel), point.y, `extraSpawnPointY_` + idxLabel);
  });
  return writer$1;
}
function toBuffer101(self) {
  return data(packExtraSpawnPoints(packSingle(packUInt64(packSByte(packInt16(packInt16(packInt16(packInt16(packInt16(packInt16(packInt16(packByte(packByte(packByte(packEventInfo(packSingle(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packInt32(packInt32(packInt32(packByte(packByte(packByte(packByte(packInt32(packInt32(packInt32(packByte(packSingle(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packByte(packUInt64(packBytes(packByte(packString(packInt32(packInt16(packInt16(packInt16(packInt16(packInt16(packInt16(packByte(packByte(packInt32(setType(make(), toInt("WorldInfo")), self.time, "time"), self.dayAndMoonInfo, "dayAndMoonInfo"), self.moonPhase, "moonPhase"), self.maxTilesX, "maxTilesX"), self.maxTilesY, "maxTilesY"), self.spawnX, "spawnX"), self.spawnY, "spawnY"), self.worldSurface, "worldSurface"), self.rockLayer, "rockLayer"), self.worldId, "worldId"), self.worldName, "worldName"), self.gameMode, "gameMode"), asArray(self.worldUniqueId), "worldUniqueId"), self.worldGeneratorVersion, "worldGeneratorVersion"), self.moonType, "moonType"), self.treeBackground, "treeBackground"), self.treeBackground2, "treeBackground2"), self.treeBackground3, "treeBackground3"), self.treeBackground4, "treeBackground4"), self.corruptionBackground, "corruptionBackground"), self.jungleBackground, "jungleBackground"), self.snowBackground, "snowBackground"), self.hallowBackground, "hallowBackground"), self.crimsonBackground, "crimsonBackground"), self.desertBackground, "desertBackground"), self.oceanBackground, "oceanBackground"), self.mushroomBackground, "mushroomBackground"), self.underworldBackground, "underworldBackground"), self.iceBackStyle, "iceBackStyle"), self.jungleBackStyle, "jungleBackStyle"), self.hellBackStyle, "hellBackStyle"), self.windSpeedSet, "windSpeedSet"), self.cloudNumber, "cloudNumber"), self.tree1, "tree1"), self.tree2, "tree2"), self.tree3, "tree3"), self.treeStyle1, "treeStyle1"), self.treeStyle2, "treeStyle2"), self.treeStyle3, "treeStyle3"), self.treeStyle4, "treeStyle4"), self.caveBack1, "caveBack1"), self.caveBack2, "caveBack2"), self.caveBack3, "caveBack3"), self.caveBackStyle1, "caveBackStyle1"), self.caveBackStyle2, "caveBackStyle2"), self.caveBackStyle3, "caveBackStyle3"), self.caveBackStyle4, "caveBackStyle4"), self.forest1TreeTopStyle, "forest1TreeTopStyle"), self.forest2TreeTopStyle, "forest2TreeTopStyle"), self.forest3TreeTopStyle, "forest3TreeTopStyle"), self.forest4TreeTopStyle, "forest4TreeTopStyle"), self.corruptionTreeTopStyle, "corruptionTreeTopStyle"), self.jungleTreeTopStyle, "jungleTreeTopStyle"), self.snowTreeTopStyle, "snowTreeTopStyle"), self.hallowTreeTopStyle, "hallowTreeTopStyle"), self.crimsonTreeTopStyle, "crimsonTreeTopStyle"), self.desertTreeTopStyle, "desertTreeTopStyle"), self.oceanTreeTopStyle, "oceanTreeTopStyle"), self.glowingMushroomTreeTopStyle, "glowingMushroomTreeTopStyle"), self.underworldTreeTopStyle, "underworldTreeTopStyle"), self.rain, "rain"), self.eventInfo), toByte(fromFlags(self.lowTiles, false, false, false, false, false, false, false)), "lowTiles"), self.sundialCooldown, "sundialCooldown"), self.moondialCooldown, "moondialCooldown"), self.copperOreTier, "copperOreTier"), self.ironOreTier, "ironOreTier"), self.silverOreTier, "silverOreTier"), self.goldOreTier, "goldOreTier"), self.cobaltOreTier, "cobaltOreTier"), self.mythrilOreTier, "mythrilOreTier"), self.adamantiteOreTier, "adamantiteOreTier"), self.invasionType, "invasionType"), self.lobbyId, "lobbyId"), self.sandstormSeverity, "sandstormSeverity"), self.extraSpawnPoints));
}
var Encode33 = {
  packInt16,
  packByte,
  packEventInfo,
  packExtraSpawnPoints,
  toBuffer: toBuffer101
};
var PacketV1449_PlayerActive_exports = {};
__export(PacketV1449_PlayerActive_exports, {
  parse: () => parse105,
  toBuffer: () => toBuffer102
});
function parse105(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "active");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        active: e$1._0 !== 0
      }
    };
  } else {
    return e$1;
  }
}
function toBuffer102(self) {
  return data(packByte(packByte(setType(make(), toInt("PlayerActive")), self.playerId, "playerId"), self.active ? 1 : 0, "active"));
}
var Packet_NpcUpdate_exports = {};
__export(Packet_NpcUpdate_exports, {
  Decode: () => Decode34,
  Encode: () => Encode34,
  parse: () => parse106,
  toBuffer: () => toBuffer103
});
function readNpcFlags1(reader, fieldName) {
  let e = readByte(reader, fieldName);
  if (e.TAG !== "Ok") {
    return e;
  }
  let flags = fromByte(e._0);
  return {
    TAG: "Ok",
    _0: {
      directionX: flag1(flags),
      directionY: flag2(flags),
      ai0: flag3(flags),
      ai1: flag4(flags),
      ai2: flag5(flags),
      ai3: flag6(flags),
      spriteDirection: flag7(flags),
      lifeMax: flag8(flags)
    }
  };
}
function readNpcFlags2(reader, fieldName) {
  let e = readByte(reader, fieldName);
  if (e.TAG !== "Ok") {
    return e;
  }
  let flags = fromByte(e._0);
  return {
    TAG: "Ok",
    _0: {
      statsScaled: flag1(flags),
      spawnedFromStatue: flag2(flags),
      difficulty: flag3(flags),
      spawnNeedsSyncing: flag4(flags),
      shimmerTransparency: flag5(flags)
    }
  };
}
function parse106(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "npcSlotId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "vx");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readSingle(reader, "vy");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readUInt16(reader, "target");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readNpcFlags1(reader, "npcFlags1");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let npcFlags12 = e$6._0;
  let e$7 = readNpcFlags2(reader, "npcFlags2");
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let npcFlags22 = e$7._0;
  let tmp;
  if (npcFlags12.ai0) {
    let e$8 = readSingle(reader, "ai0");
    tmp = e$8.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$8._0
    } : e$8;
  } else {
    tmp = {
      TAG: "Ok",
      _0: void 0
    };
  }
  let tmp$1;
  if (npcFlags12.ai1) {
    let e$9 = readSingle(reader, "ai1");
    tmp$1 = e$9.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$9._0
    } : e$9;
  } else {
    tmp$1 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  let tmp$2;
  if (npcFlags12.ai2) {
    let e$10 = readSingle(reader, "ai2");
    tmp$2 = e$10.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$10._0
    } : e$10;
  } else {
    tmp$2 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  let tmp$3;
  if (npcFlags12.ai3) {
    let e$11 = readSingle(reader, "ai3");
    tmp$3 = e$11.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$11._0
    } : e$11;
  } else {
    tmp$3 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  let e$12 = all4([
    tmp,
    tmp$1,
    tmp$2,
    tmp$3
  ]);
  if (e$12.TAG !== "Ok") {
    return e$12;
  }
  let e$13 = readInt16(reader, "npcTypeId");
  if (e$13.TAG !== "Ok") {
    return e$13;
  }
  let e$14;
  if (npcFlags22.statsScaled) {
    let e$15 = readByte(reader, "playerCountScale");
    e$14 = e$15.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$15._0
    } : e$15;
  } else {
    e$14 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$14.TAG !== "Ok") {
    return e$14;
  }
  let e$16;
  if (npcFlags22.difficulty) {
    let e$17 = readSingle(reader, "difficulty");
    e$16 = e$17.TAG === "Ok" ? {
      TAG: "Ok",
      _0: e$17._0
    } : e$17;
  } else {
    e$16 = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (e$16.TAG !== "Ok") {
    return e$16;
  }
  let e$18;
  if (npcFlags12.lifeMax) {
    e$18 = {
      TAG: "Ok",
      _0: "Max"
    };
  } else {
    let e$19 = readByte(reader, "lifeBytes");
    if (e$19.TAG === "Ok") {
      switch (e$19._0) {
        case 1:
          let e$20 = readSByte(reader, "life_sbyte");
          e$18 = e$20.TAG === "Ok" ? {
            TAG: "Ok",
            _0: {
              TAG: "Byte",
              _0: e$20._0
            }
          } : e$20;
          break;
        case 2:
          let e$21 = readInt16(reader, "life_int16");
          e$18 = e$21.TAG === "Ok" ? {
            TAG: "Ok",
            _0: {
              TAG: "Int16",
              _0: e$21._0
            }
          } : e$21;
          break;
        case 4:
          let e$22 = readInt32(reader, "life_int32");
          e$18 = e$22.TAG === "Ok" ? {
            TAG: "Ok",
            _0: {
              TAG: "Int32",
              _0: e$22._0
            }
          } : e$22;
          break;
        default:
          e$18 = {
            TAG: "Error",
            _0: {
              context: "Packet_NpcUpdate.parse",
              error: new Error("Invalid life byte count")
            }
          };
      }
    } else {
      e$18 = e$19;
    }
  }
  if (e$18.TAG !== "Ok") {
    return e$18;
  }
  let releaseOwner = readByte(reader, "releaseOwner");
  let releaseOwner$1;
  releaseOwner$1 = releaseOwner.TAG === "Ok" ? releaseOwner._0 : void 0;
  return {
    TAG: "Ok",
    _0: {
      npcSlotId: e._0,
      npcTypeId: e$13._0,
      x: e$1._0,
      y: e$2._0,
      vx: e$3._0,
      vy: e$4._0,
      target: e$5._0,
      directionX: npcFlags12.directionX,
      directionY: npcFlags12.directionY,
      ai: e$12._0,
      spriteDirection: npcFlags12.spriteDirection,
      life: e$18._0,
      releaseOwner: releaseOwner$1,
      playerCountScale: e$14._0,
      difficulty: e$16._0,
      spawnedFromStatue: npcFlags22.spawnedFromStatue,
      spawnNeedsSyncing: npcFlags22.spawnNeedsSyncing,
      shimmerTransparency: npcFlags22.shimmerTransparency
    }
  };
}
var Decode34 = {
  readInt32,
  readInt16,
  readSingle,
  readUInt16,
  readByte,
  readSByte,
  readNpcFlags1,
  readNpcFlags2,
  parse: parse106
};
function npcFlags1(self) {
  let match = self.ai;
  return toByte(fromFlags(self.directionX, self.directionY, isSome(match[0]), isSome(match[1]), isSome(match[2]), isSome(match[3]), self.spriteDirection, self.life === "Max"));
}
function npcFlags2(self) {
  return toByte(fromFlags(isSome(self.playerCountScale), self.spawnedFromStatue, isSome(self.difficulty), self.spawnNeedsSyncing, self.shimmerTransparency, false, false, false));
}
function packAi(writer, param) {
  let ai3 = param[3];
  let ai2 = param[2];
  let ai1 = param[1];
  let ai0 = param[0];
  if (ai0 !== void 0) {
    packSingle(writer, ai0, "ai0");
  }
  if (ai1 !== void 0) {
    packSingle(writer, ai1, "ai1");
  }
  if (ai2 !== void 0) {
    packSingle(writer, ai2, "ai2");
  }
  if (ai3 !== void 0) {
    packSingle(writer, ai3, "ai3");
  }
  return writer;
}
function packPlayerCountScale(writer, playerCountScale) {
  if (playerCountScale !== void 0) {
    return packByte(writer, playerCountScale, "playerCountScale");
  } else {
    return writer;
  }
}
function packDifficulty(writer, difficulty) {
  if (difficulty !== void 0) {
    return packSingle(writer, difficulty, "difficulty");
  } else {
    return writer;
  }
}
function packLife(writer, life) {
  if (typeof life !== "object") {
    return writer;
  }
  switch (life.TAG) {
    case "Byte":
      return packSByte(packByte(writer, 1, "lifeBytes"), life._0, "life_sbyte");
    case "Int16":
      return packInt16(packByte(writer, 2, "lifeBytes"), life._0, "life_int16");
    case "Int32":
      return packInt32(packByte(writer, 4, "lifeBytes"), life._0, "life_int32");
  }
}
function packReleaseOwner(writer, releaseOwner) {
  if (releaseOwner !== void 0) {
    return packByte(writer, releaseOwner, "releaseOwner");
  } else {
    return writer;
  }
}
function toBuffer103(self) {
  return data(packReleaseOwner(packLife(packDifficulty(packPlayerCountScale(packInt16(packAi(packByte(packByte(packUInt16(packSingle(packSingle(packSingle(packSingle(packInt16(setType(make(), toInt("NpcUpdate")), self.npcSlotId, "npcSlotId"), self.x, "x"), self.y, "y"), self.vx, "vx"), self.vy, "vy"), self.target, "target"), npcFlags1(self), "npcFlags1"), npcFlags2(self), "npcFlags2"), self.ai), self.npcTypeId, "npcTypeId"), self.playerCountScale), self.difficulty), self.life), self.releaseOwner));
}
var Encode34 = {
  packInt32,
  packInt16,
  packSingle,
  packUInt16,
  packByte,
  packSByte,
  setType,
  data,
  npcFlags1,
  npcFlags2,
  packAi,
  packPlayerCountScale,
  packDifficulty,
  packLife,
  packReleaseOwner,
  toBuffer: toBuffer103
};
var PacketV1449_Disconnect_exports = {};
__export(PacketV1449_Disconnect_exports, {
  parse: () => parse107,
  toBuffer: () => toBuffer104
});
function parse107(payload) {
  let reader = new packetreader_default(payload);
  let e = readNetworkText(reader, "reason");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        reason: e._0
      }
    };
  } else {
    return e;
  }
}
function toBuffer104(self) {
  return data(packNetworkText(setType(make(), toInt("Disconnect")), self.reason, "reason"));
}
var Parser_exports = {};
__export(Parser_exports, {
  parse: () => parse165,
  parseLazy: () => parseLazy
});
function from_fun(closure) {
  return {
    LAZY_DONE: false,
    VAL: closure
  };
}
var make4 = from_fun;
function parse108(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "emojiId");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        emojiId: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function parse109(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
function actionFromInt(self) {
  switch (self) {
    case 0:
      return "OpenDoor";
    case 1:
      return "CloseDoor";
    case 2:
      return "ShiftTrapdoorOpen";
    case 3:
      return "ShiftTrapdoorClose";
    case 4:
      return "ShiftTallGateOpen";
    case 5:
      return "ShiftTallGateClose";
    default:
      return;
  }
}
function parse110(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "action");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "direction");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let action = actionFromInt(e._0);
  let action$1 = action !== void 0 ? {
    TAG: "Ok",
    _0: action
  } : {
    TAG: "Error",
    _0: {
      context: "Packet_DoorUse.parse.action",
      error: new Error("Unknown door action")
    }
  };
  if (action$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        action: action$1._0,
        x: e$1._0,
        y: e$2._0,
        direction: e$3._0 === 0 ? -1 : 1
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: action$1._0
    };
  }
}
function parse111(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "pitch");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        pitch: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function parse112(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "chestId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readString(reader, "name");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        chestId: e._0,
        x: e$1._0,
        y: e$2._0,
        name: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function parse113(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function parse114(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "liquid");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "liquidType");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        liquid: e$2._0,
        liquidType: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function parse115(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "npcId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "damage");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "knockback");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "direction");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readByte(reader, "critical");
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcId: e._0,
        damage: e$1._0,
        knockback: e$2._0,
        direction: e$3._0 - 1 | 0,
        critical: e$4._0 === 1
      }
    };
  } else {
    return e$4;
  }
}
function fromInt9(playerId) {
  if (playerId !== -1) {
    return {
      TAG: "PlayerId",
      _0: playerId
    };
  } else {
    return "All";
  }
}
function parse116(payload) {
  let reader = new packetreader_default(payload);
  let e = readUInt16(reader, "npcId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "setNpcImmunity");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2;
  if (e$1._0 === 1) {
    let e$3 = readInt32(reader, "immunityTime");
    if (e$3.TAG === "Ok") {
      let e$4 = readInt16(reader, "immunityFromPlayerId");
      e$2 = e$4.TAG === "Ok" ? {
        TAG: "Ok",
        _0: [
          e$3._0,
          fromInt9(e$4._0)
        ]
      } : e$4;
    } else {
      e$2 = e$3;
    }
  } else {
    e$2 = {
      TAG: "Ok",
      _0: [
        void 0,
        void 0
      ]
    };
  }
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let match = e$2._0;
  return {
    TAG: "Ok",
    _0: {
      npcId: e._0,
      immunityTime: match[0],
      immunityFromPlayerId: match[1]
    }
  };
}
function parse117(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "healAmount");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        healAmount: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function parse118(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "manaAmount");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        manaAmount: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function parse119(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "npcId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readUInt16(reader, "buffType");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "time");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcId: e._0,
        buffType: e$1._0,
        time: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function parse120(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt32(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "npcType");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "style");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        npcType: e$2._0,
        style: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function parse121(payload) {
  let reader = new packetreader_default(payload);
  let e = readUInt16(reader, "owner");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "portalColor");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        owner: e._0,
        portalColor: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function parse122(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt32(reader, "id");
  if (e.TAG !== "Ok") {
    return e;
  }
  let id = e._0;
  let e$1 = readByte(reader, "anchorType");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let anchorType = e$1._0;
  if (anchorType === 255) {
    return {
      TAG: "Ok",
      _0: {
        id,
        anchor: "Remove"
      }
    };
  }
  let e$2 = readUInt16(reader, "anchorMeta");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let anchorMeta = e$2._0;
  let e$3 = readUInt16(reader, "time");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let time = e$3._0;
  let e$4 = readByte(reader, "emote");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let emoteByte = e$4._0;
  if (emoteByte !== 255) {
    return {
      TAG: "Ok",
      _0: {
        id,
        anchor: {
          TAG: "Anchor",
          anchorType,
          anchorMeta,
          time,
          emote: emoteByte,
          metadata: void 0
        }
      }
    };
  }
  let e$5 = readInt16(reader, "metadata");
  if (e$5.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        id,
        anchor: {
          TAG: "Anchor",
          anchorType,
          anchorMeta,
          time,
          emote: -1,
          metadata: e$5._0
        }
      }
    };
  } else {
    return e$5;
  }
}
function parse123(payload) {
  let reader = new packetreader_default(payload);
  let e = readString(reader, "password");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        password: e._0
      }
    };
  } else {
    return e;
  }
}
function parse124(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readBool(reader, "active");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        active: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function parse125(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readUInt16(reader, "level");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "x");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "y");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        level: e$1._0,
        x: e$2._0,
        y: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function parse126(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "npcId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "playerId");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcId: e._0,
        playerId: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function parse127(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "stealth");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        stealth: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function fromInt10(n) {
  switch (n) {
    case 0:
      return "None";
    case 1:
      return "Stadia";
    case 2:
      return "XBO";
    case 3:
      return "PSN";
    case 4:
      return "Editor";
    case 5:
      return "Nintendo";
    case 6:
      return "Steam";
    case 7:
      return "GameCenter";
    default:
      return;
  }
}
function parse128(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "platformId");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let platformId = e$1._0;
  let platformId$1 = fromInt10(platformId);
  if (platformId$1 !== void 0) {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        platformId: platformId$1
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: {
        context: "Packet_PlayerPlatformInfo.parse",
        error: new Error("Unknown platformId " + platformId.toString())
      }
    };
  }
}
function parse129(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "good");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "evil");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "blood");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        good: e._0,
        evil: e$1._0,
        blood: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function parseFlags2(reader, flags2) {
  let width = flag1(flags2) ? map(readInt16(reader, "width"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (width.TAG !== "Ok") {
    return width;
  }
  let height = flag2(flags2) ? map(readInt16(reader, "height"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (height.TAG !== "Ok") {
    return height;
  }
  let scale = flag3(flags2) ? map(readSingle(reader, "scale"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (scale.TAG !== "Ok") {
    return scale;
  }
  let ammo = flag4(flags2) ? map(readInt16(reader, "ammo"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (ammo.TAG !== "Ok") {
    return ammo;
  }
  let useAmmo = flag5(flags2) ? map(readInt16(reader, "useAmmo"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (useAmmo.TAG !== "Ok") {
    return useAmmo;
  }
  let notAmmo = flag6(flags2) ? map(readByte(reader, "notAmmo"), (v) => v === 1) : {
    TAG: "Ok",
    _0: void 0
  };
  if (notAmmo.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: [
        width._0,
        height._0,
        scale._0,
        ammo._0,
        useAmmo._0,
        notAmmo._0
      ]
    };
  } else {
    return notAmmo;
  }
}
function parse130(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "itemId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "flags1");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let flags1 = fromByte(e$1._0);
  let color;
  if (flag1(flags1)) {
    let e$2 = readByte(reader, "Color.r");
    if (e$2.TAG === "Ok") {
      let e$3 = readByte(reader, "Color.g");
      if (e$3.TAG === "Ok") {
        let e$4 = readByte(reader, "Color.b");
        if (e$4.TAG === "Ok") {
          let e$5 = readByte(reader, "Color.a");
          color = e$5.TAG === "Ok" ? {
            TAG: "Ok",
            _0: {
              r: e$2._0,
              g: e$3._0,
              b: e$4._0,
              a: e$5._0
            }
          } : e$5;
        } else {
          color = e$4;
        }
      } else {
        color = e$3;
      }
    } else {
      color = e$2;
    }
  } else {
    color = {
      TAG: "Ok",
      _0: void 0
    };
  }
  if (color.TAG !== "Ok") {
    return color;
  }
  let damage = flag2(flags1) ? map(readUInt16(reader, "damage"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (damage.TAG !== "Ok") {
    return damage;
  }
  let knockback = flag3(flags1) ? map(readSingle(reader, "knockback"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (knockback.TAG !== "Ok") {
    return knockback;
  }
  let useAnimation = flag4(flags1) ? map(readUInt16(reader, "useAnimation"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (useAnimation.TAG !== "Ok") {
    return useAnimation;
  }
  let useTime = flag5(flags1) ? map(readUInt16(reader, "useTime"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (useTime.TAG !== "Ok") {
    return useTime;
  }
  let shoot = flag6(flags1) ? map(readInt16(reader, "shoot"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (shoot.TAG !== "Ok") {
    return shoot;
  }
  let shootSpeed = flag7(flags1) ? map(readSingle(reader, "shootSpeed"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (shootSpeed.TAG !== "Ok") {
    return shootSpeed;
  }
  let e$6;
  if (flag8(flags1)) {
    let e$7 = readByte(reader, "flags2");
    e$6 = e$7.TAG === "Ok" ? parseFlags2(reader, fromByte(e$7._0)) : e$7;
  } else {
    e$6 = {
      TAG: "Ok",
      _0: [
        void 0,
        void 0,
        void 0,
        void 0,
        void 0,
        void 0
      ]
    };
  }
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let match = e$6._0;
  return {
    TAG: "Ok",
    _0: {
      itemId: e._0,
      color: color._0,
      damage: damage._0,
      knockback: knockback._0,
      useAnimation: useAnimation._0,
      useTime: useTime._0,
      shoot: shoot._0,
      shootSpeed: shootSpeed._0,
      width: match[0],
      height: match[1],
      scale: match[2],
      ammo: match[3],
      useAmmo: match[4],
      notAmmo: match[5]
    }
  };
}
function parse131(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "itemId");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "prefix");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt16(reader, "stack");
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        itemId: e$2._0,
        prefix: e$3._0,
        stack: e$4._0
      }
    };
  } else {
    return e$4;
  }
}
function parse132(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "source");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "variant");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "velocityX");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "velocityY");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let velocity_x = e$2._0;
  let velocity_y = e$3._0;
  let velocity = {
    x: velocity_x,
    y: velocity_y
  };
  let e$4 = readInt32(reader, "positionX");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readInt32(reader, "positionY");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let position_x = e$4._0;
  let position_y = e$5._0;
  let position = {
    x: position_x,
    y: position_y
  };
  return {
    TAG: "Ok",
    _0: {
      source: e._0,
      variant: e$1._0,
      velocity,
      position
    }
  };
}
function parse133(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "tileX");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "tileY");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "width");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let width = e$2._0;
  let e$3 = readByte(reader, "height");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let height = e$3._0;
  let e$4 = readByte(reader, "changeType");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let readTile = () => {
    let e2 = readByte(reader, "flags1");
    if (e2.TAG !== "Ok") {
      return e2;
    }
    let flags1 = fromByte(e2._0);
    let e$12 = readByte(reader, "flags2");
    if (e$12.TAG !== "Ok") {
      return e$12;
    }
    let flags2 = fromByte(e$12._0);
    let e$22 = readByte(reader, "flags3");
    if (e$22.TAG !== "Ok") {
      return e$22;
    }
    let active = flag1(flags1);
    let hasWall = flag3(flags1);
    let hasLiquid = flag4(flags1);
    let wire2 = flag5(flags1);
    let halfBrick = flag6(flags1);
    let actuator = flag7(flags1);
    let inActive = flag8(flags1);
    let wire22 = flag1(flags2);
    let wire3 = flag2(flags2);
    let e$32;
    if (flag3(flags2)) {
      let e$42 = readByte(reader, "color");
      e$32 = e$42.TAG === "Ok" ? {
        TAG: "Ok",
        _0: e$42._0
      } : e$42;
    } else {
      e$32 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$32.TAG !== "Ok") {
      return e$32;
    }
    let e$5;
    if (flag4(flags2)) {
      let e$6 = readByte(reader, "wallColor");
      e$5 = e$6.TAG === "Ok" ? {
        TAG: "Ok",
        _0: e$6._0
      } : e$6;
    } else {
      e$5 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$5.TAG !== "Ok") {
      return e$5;
    }
    let e$7;
    if (active) {
      let e$8 = readUInt16(reader, "tileType");
      if (e$8.TAG === "Ok") {
        let tileType = e$8._0;
        let e$9;
        if (isImportant2(tileType)) {
          let e$10 = readInt16(reader, "frameX");
          if (e$10.TAG === "Ok") {
            let e$11 = readInt16(reader, "frameY");
            e$9 = e$11.TAG === "Ok" ? {
              TAG: "Ok",
              _0: {
                x: e$10._0,
                y: e$11._0
              }
            } : e$11;
          } else {
            e$9 = e$10;
          }
        } else {
          e$9 = {
            TAG: "Ok",
            _0: void 0
          };
        }
        if (e$9.TAG === "Ok") {
          let slope = ((0 + (flag5(flags2) ? 1 : 0) | 0) + (flag6(flags2) ? 2 : 0) | 0) + (flag7(flags2) ? 4 : 0) | 0;
          e$7 = {
            TAG: "Ok",
            _0: {
              tileType,
              slope,
              frame: e$9._0
            }
          };
        } else {
          e$7 = e$9;
        }
      } else {
        e$7 = e$8;
      }
    } else {
      e$7 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$7.TAG !== "Ok") {
      return e$7;
    }
    let e$122;
    if (hasWall) {
      let e$13 = readUInt16(reader, "wall");
      e$122 = e$13.TAG === "Ok" ? {
        TAG: "Ok",
        _0: e$13._0
      } : e$13;
    } else {
      e$122 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$122.TAG !== "Ok") {
      return e$122;
    }
    let e$14;
    if (hasLiquid) {
      let e$15 = readByte(reader, "liquidValue");
      if (e$15.TAG === "Ok") {
        let e$16 = readByte(reader, "liquidType");
        e$14 = e$16.TAG === "Ok" ? {
          TAG: "Ok",
          _0: {
            liquidValue: e$15._0,
            liquidType: e$16._0
          }
        } : e$16;
      } else {
        e$14 = e$15;
      }
    } else {
      e$14 = {
        TAG: "Ok",
        _0: void 0
      };
    }
    if (e$14.TAG !== "Ok") {
      return e$14;
    }
    let wire4 = flag8(flags2);
    return {
      TAG: "Ok",
      _0: {
        wire: wire2,
        halfBrick,
        actuator,
        inActive,
        wire2: wire22,
        wire3,
        wire4,
        color: e$32._0,
        wallColor: e$5._0,
        activeTile: e$7._0,
        wall: e$122._0,
        liquid: e$14._0,
        coatHeader: e$22._0
      }
    };
  };
  let tiles = [];
  let parseResult = {
    TAG: "Ok",
    _0: void 0
  };
  for (let _x = 0; _x < width; ++_x) {
    let match = parseResult;
    if (match.TAG === "Ok") {
      let column = [];
      for (let _y = 0; _y < height; ++_y) {
        let match$1 = parseResult;
        if (match$1.TAG === "Ok") {
          let tile = readTile();
          if (tile.TAG === "Ok") {
            column.push(tile._0);
          } else {
            parseResult = {
              TAG: "Error",
              _0: tile._0
            };
          }
        }
      }
      let match$2 = parseResult;
      if (match$2.TAG === "Ok") {
        tiles.push(column);
      }
    }
  }
  let err = parseResult;
  if (err.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        width,
        height,
        changeType: e$4._0,
        tileX: e._0,
        tileY: e$1._0,
        tiles
      }
    };
  } else {
    return {
      TAG: "Error",
      _0: err._0
    };
  }
}
function parse134(payload) {
  let reader = new packetreader_default(payload);
  let e = readSingle(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readUInt16(reader, "soundIndex");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "flags");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let flags = fromByte(e$3._0);
  let e$4 = flag1(flags) ? map(readInt32(reader, "styleOverride"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = flag2(flags) ? map(readSingle(reader, "volumeOverride"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = flag3(flags) ? map(readSingle(reader, "pitchOverride"), (v) => v) : {
    TAG: "Ok",
    _0: void 0
  };
  if (e$6.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        position: {
          x: e._0,
          y: e$1._0
        },
        soundIndex: e$2._0,
        styleOverride: e$4._0,
        volumeOverride: e$5._0,
        pitchOverride: e$6._0
      }
    };
  } else {
    return e$6;
  }
}
function parse135(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "healAmount");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        healAmount: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function parse136(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
function parse137(payload) {
  let reader = new packetreader_default(payload);
  let e = readSingle(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readColor(reader, "color");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readNetworkText(reader, "text");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        color: e$2._0,
        text: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function parse138(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "effectType");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        effectType: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function parse139(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
function parse140(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "eventId");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        eventId: e._0
      }
    };
  } else {
    return e;
  }
}
function parse141(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readUInt16(reader, "cupX");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readUInt16(reader, "cupY");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readUInt16(reader, "projId");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readUInt16(reader, "projType");
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        cupX: e$1._0,
        cupY: e$2._0,
        projId: e$3._0,
        projType: e$4._0
      }
    };
  } else {
    return e$4;
  }
}
function parse142(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "startX");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "startY");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "endX");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt16(reader, "endY");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readByte(reader, "toolMode");
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        startX: e._0,
        startY: e$1._0,
        endX: e$2._0,
        endY: e$3._0,
        toolMode: e$4._0
      }
    };
  } else {
    return e$4;
  }
}
function parse143(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt32(reader, "maxMoonLordCountdown");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "moonLordCountdown");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        maxMoonLordCountdown: e._0,
        moonLordCountdown: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function parse144(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "projectileId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readByte(reader, "owner");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        projectileId: e._0,
        owner: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function parse145(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt32(reader, "uniqueId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "posX");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "posY");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt32(reader, "npcNetId");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readSingle(reader, "npcHpPercent");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readInt32(reader, "npcTypeAgainstDiscouragement");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readInt32(reader, "npcAiStyleAgainstDiscouragement");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readInt32(reader, "coinValue");
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let e$8 = readSingle(reader, "baseValue");
  if (e$8.TAG !== "Ok") {
    return e$8;
  }
  let e$9 = readBool(reader, "spawnedFromStatue");
  if (e$9.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        uniqueId: e._0,
        position: {
          x: e$1._0,
          y: e$2._0
        },
        npcNetId: e$3._0,
        npcHpPercent: e$4._0,
        npcTypeAgainstDiscouragement: e$5._0,
        npcAiStyleAgainstDiscouragement: e$6._0,
        coinValue: e$7._0,
        baseValue: e$8._0,
        spawnedFromStatue: e$9._0
      }
    };
  } else {
    return e$9;
  }
}
function parse146(payload) {
  let reader = new packetreader_default(payload);
  let e = readSingle(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readColor(reader, "color");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readInt32(reader, "amount");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        color: e$2._0,
        amount: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function parse147(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "y");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        x: e$1._0,
        y: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function parse148(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "chestId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "nameLength");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let nameLength = e$3._0;
  let e$4 = nameLength > 0 && nameLength <= 20 ? readString(reader, "name") : {
    TAG: "Ok",
    _0: ""
  };
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        chestId: e._0,
        x: e$1._0,
        y: e$2._0,
        nameLength,
        name: e$4._0
      }
    };
  } else {
    return e$4;
  }
}
function parse149(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt32(reader, "markerId");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        markerId: e._0
      }
    };
  } else {
    return e;
  }
}
function parse150(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "itemType");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "stack");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readByte(reader, "playerId");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        itemType: e._0,
        stack: e$1._0,
        playerId: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function parse151(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "extraInfo");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "positionX");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "positionY");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let position_x = e$2._0;
  let position_y = e$3._0;
  let position = {
    x: position_x,
    y: position_y
  };
  let e$4 = readSingle(reader, "velocityX");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readSingle(reader, "velocityY");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let velocity_x = e$4._0;
  let velocity_y = e$5._0;
  let velocity = {
    x: velocity_x,
    y: velocity_y
  };
  return {
    TAG: "Ok",
    _0: {
      playerId: e._0,
      extraInfo: e$1._0,
      position,
      velocity
    }
  };
}
function parse152(payload) {
  let reader = new packetreader_default(payload);
  let rows = make2(2, []);
  let error;
  for (let i = 0; i <= 1; ++i) {
    if (error !== void 0) {
      let row = make2(3, 0);
      for (let j = 0; j <= 2; ++j) {
        if (error !== void 0) {
          let value = readUInt16(reader, `monster_` + i.toString() + `_` + j.toString());
          if (value.TAG === "Ok") {
            row[j] = value._0;
          } else {
            error = value._0;
          }
        }
      }
      rows[i] = row;
    }
  }
  let err = error;
  if (err !== void 0) {
    return {
      TAG: "Error",
      _0: err
    };
  } else {
    return {
      TAG: "Ok",
      _0: rows
    };
  }
}
function parse153(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
function parse154(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "x");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "y");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, "itemId");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readByte(reader, "prefix");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readInt16(reader, "stack");
  if (e$4.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        x: e._0,
        y: e$1._0,
        itemId: e$2._0,
        prefix: e$3._0,
        stack: e$4._0
      }
    };
  } else {
    return e$4;
  }
}
function parse155(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "npcId");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        npcId: e._0
      }
    };
  } else {
    return e;
  }
}
function parse156(payload) {
  let reader = new packetreader_default(payload);
  let e = readUInt16(reader, "solar");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readUInt16(reader, "vortex");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readUInt16(reader, "nebula");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readUInt16(reader, "stardust");
  if (e$3.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        solar: e._0,
        vortex: e$1._0,
        nebula: e$2._0,
        stardust: e$3._0
      }
    };
  } else {
    return e$3;
  }
}
function parse157(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
var parse158 = parse18;
function parse159(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt16(reader, "itemDropId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readSingle(reader, "x");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readSingle(reader, "y");
  if (e$2.TAG !== "Ok") {
    return e$2;
  }
  let e$3 = readSingle(reader, "vx");
  if (e$3.TAG !== "Ok") {
    return e$3;
  }
  let e$4 = readSingle(reader, "vy");
  if (e$4.TAG !== "Ok") {
    return e$4;
  }
  let e$5 = readInt16(reader, "stack");
  if (e$5.TAG !== "Ok") {
    return e$5;
  }
  let e$6 = readByte(reader, "prefix");
  if (e$6.TAG !== "Ok") {
    return e$6;
  }
  let e$7 = readByte(reader, "noDelay");
  if (e$7.TAG !== "Ok") {
    return e$7;
  }
  let e$8 = readInt16(reader, "itemId");
  if (e$8.TAG !== "Ok") {
    return e$8;
  }
  let e$9 = readByte(reader, "timeLeftInWhichTheItemCannotBeTakenByEnemies");
  if (e$9.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        itemDropId: e._0,
        x: e$1._0,
        y: e$2._0,
        vx: e$3._0,
        vy: e$4._0,
        stack: e$5._0,
        prefix: e$6._0,
        noDelay: e$7._0,
        itemId: e$8._0,
        timeLeftInWhichTheItemCannotBeTakenByEnemies: e$9._0
      }
    };
  } else {
    return e$9;
  }
}
function tryReading(reader, context) {
  let e = readInt16(reader, context + "_ownerIndex");
  if (e.TAG !== "Ok") {
    return e;
  }
  let ownerIndex = e._0;
  if (ownerIndex === -1) {
    return {
      TAG: "Ok",
      _0: void 0
    };
  }
  let e$1 = readInt16(reader, context + "_expectedIdentity");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt16(reader, context + "_expectedType");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        ownerIndex,
        expectedIdentity: e$1._0,
        expectedType: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function parse160(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = tryReading(reader, "piggyBankProj");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = tryReading(reader, "voidLensChest");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        piggyBankProj: e$1._0,
        voidLensChest: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function parse161(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt16(reader, "targetNpcId");
  if (e$1.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        targetNpcId: e$1._0
      }
    };
  } else {
    return e$1;
  }
}
function parse162(payload) {
  let reader = new packetreader_default(payload);
  let e = readByte(reader, "playerId");
  if (e.TAG !== "Ok") {
    return e;
  }
  let e$1 = readInt32(reader, "anglerQuestsFinished");
  if (e$1.TAG !== "Ok") {
    return e$1;
  }
  let e$2 = readInt32(reader, "golferScoreAccumulated");
  if (e$2.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        playerId: e._0,
        anglerQuestsFinished: e$1._0,
        golferScoreAccumulated: e$2._0
      }
    };
  } else {
    return e$2;
  }
}
function parse163(payload) {
  let reader = new packetreader_default(payload);
  let e = readInt32(reader, "timeLeftBetweenWaves");
  if (e.TAG === "Ok") {
    return {
      TAG: "Ok",
      _0: {
        timeLeftBetweenWaves: e._0
      }
    };
  } else {
    return e;
  }
}
function parse164(_payload) {
  return {
    TAG: "Ok",
    _0: void 0
  };
}
function addPacketContext(packetName2, err) {
  return {
    context: "Packet " + packetName2 + ": " + err.context,
    error: err.error
  };
}
function mapPacket(result, packetName2, fn) {
  return mapError(map(result, fn), (e) => ({
    TAG: "ReaderError",
    _0: addPacketContext(packetName2, e)
  }));
}
function makeParsers(packetName2, parse166, toPacket, toLazyPacket) {
  let parseWrapped = (payload, _fromServer) => mapPacket(parse166(payload), packetName2, toPacket);
  let parseLazyWrapped = (payload, _fromServer) => ({
    TAG: "Ok",
    _0: toLazyPacket(make4(() => mapError(parse166(payload), (e) => addPacketContext(packetName2, e))))
  });
  return {
    parse: parseWrapped,
    parseLazy: parseLazyWrapped
  };
}
function makeParsersWithFromServer(packetName2, parse166, toPacket, toLazyPacket) {
  let parseWrapped = (payload, fromServer) => mapPacket(parse166(payload, fromServer), packetName2, toPacket);
  let parseLazyWrapped = (payload, fromServer) => ({
    TAG: "Ok",
    _0: toLazyPacket(make4(() => mapError(parse166(payload, fromServer), (e) => addPacketContext(packetName2, e))))
  });
  return {
    parse: parseWrapped,
    parseLazy: parseLazyWrapped
  };
}
function getParsers(packetType, fromServer) {
  let packetName2 = packetName(packetType);
  switch (packetType) {
    case "ConnectRequest":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "ConnectRequestFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse9, (a) => ({
            TAG: "ConnectRequest",
            _0: a
          }), (a) => ({
            TAG: "ConnectRequest",
            _0: a
          }))
        };
      }
    case "Disconnect":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse107, (a) => ({
            TAG: "Disconnect",
            _0: a
          }), (a) => ({
            TAG: "Disconnect",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "DisconnectFromClient"
        };
      }
    case "PlayerSlotSet":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse95, (a) => ({
            TAG: "PlayerSlotSet",
            _0: a
          }), (a) => ({
            TAG: "PlayerSlotSet",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "PlayerSlotSetFromClient"
        };
      }
    case "PlayerInfo":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse97, (a) => ({
          TAG: "PlayerInfo",
          _0: a
        }), (a) => ({
          TAG: "PlayerInfo",
          _0: a
        }))
      };
    case "PlayerInventorySlot":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse99, (a) => ({
          TAG: "PlayerInventorySlot",
          _0: a
        }), (a) => ({
          TAG: "PlayerInventorySlot",
          _0: a
        }))
      };
    case "WorldDataRequest":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "WorldDataRequestFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse76, (a) => ({
            TAG: "WorldDataRequest",
            _0: a
          }), (a) => ({
            TAG: "WorldDataRequest",
            _0: a
          }))
        };
      }
    case "WorldInfo":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse104, (a) => ({
            TAG: "WorldInfo",
            _0: a
          }), (a) => ({
            TAG: "WorldInfo",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "WorldInfoFromClient"
        };
      }
    case "InitialTileSectionsRequest":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "InitialTileSectionsRequestFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse82, (a) => ({
            TAG: "InitialTileSectionsRequest",
            _0: a
          }), (a) => ({
            TAG: "InitialTileSectionsRequest",
            _0: a
          }))
        };
      }
    case "Status":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse52, (a) => ({
            TAG: "Status",
            _0: a
          }), (a) => ({
            TAG: "Status",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "StatusFromClient"
        };
      }
    case "TileSectionSend":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse$13, (a) => ({
            TAG: "TileSectionSend",
            _0: a
          }), (a) => ({
            TAG: "TileSectionSend",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "TileSectionSendFromClient"
        };
      }
    case "TileSectionFrame":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse65, (a) => ({
            TAG: "TileSectionFrame",
            _0: a
          }), (a) => ({
            TAG: "TileSectionFrame",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "TileSectionFrameFromClient"
        };
      }
    case "PlayerSpawn":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse98, (a) => ({
          TAG: "PlayerSpawn",
          _0: a
        }), (a) => ({
          TAG: "PlayerSpawn",
          _0: a
        }))
      };
    case "PlayerUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse96, (a) => ({
          TAG: "PlayerUpdate",
          _0: a
        }), (a) => ({
          TAG: "PlayerUpdate",
          _0: a
        }))
      };
    case "PlayerActive":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse105, (a) => ({
            TAG: "PlayerActive",
            _0: a
          }), (a) => ({
            TAG: "PlayerActive",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "PlayerActiveFromClient"
        };
      }
    case "PlayerHealth":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse100, (a) => ({
          TAG: "PlayerHealth",
          _0: a
        }), (a) => ({
          TAG: "PlayerHealth",
          _0: a
        }))
      };
    case "TileModify":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse62, (a) => ({
          TAG: "TileModify",
          _0: a
        }), (a) => ({
          TAG: "TileModify",
          _0: a
        }))
      };
    case "TimeSet":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse69, (a) => ({
            TAG: "TimeSet",
            _0: a
          }), (a) => ({
            TAG: "TimeSet",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "TimeSetFromClient"
        };
      }
    case "DoorUse":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse110, (a) => ({
          TAG: "DoorUse",
          _0: a
        }), (a) => ({
          TAG: "DoorUse",
          _0: a
        }))
      };
    case "TileSquareSend":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse133, (a) => ({
          TAG: "TileSquareSend",
          _0: a
        }), (a) => ({
          TAG: "TileSquareSend",
          _0: a
        }))
      };
    case "ItemDropUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse18, (a) => ({
          TAG: "ItemDropUpdate",
          _0: a
        }), (a) => ({
          TAG: "ItemDropUpdate",
          _0: a
        }))
      };
    case "ItemOwner":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse19, (a) => ({
          TAG: "ItemOwner",
          _0: a
        }), (a) => ({
          TAG: "ItemOwner",
          _0: a
        }))
      };
    case "NpcUpdate":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse106, (a) => ({
            TAG: "NpcUpdate",
            _0: a
          }), (a) => ({
            TAG: "NpcUpdate",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "NpcUpdateFromClient"
        };
      }
    case "NpcItemStrike":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse126, (a) => ({
          TAG: "NpcItemStrike",
          _0: a
        }), (a) => ({
          TAG: "NpcItemStrike",
          _0: a
        }))
      };
    case "ProjectileSync":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse102, (a) => ({
          TAG: "ProjectileSync",
          _0: a
        }), (a) => ({
          TAG: "ProjectileSync",
          _0: a
        }))
      };
    case "NpcStrike":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse115, (a) => ({
          TAG: "NpcStrike",
          _0: a
        }), (a) => ({
          TAG: "NpcStrike",
          _0: a
        }))
      };
    case "ProjectileDestroy":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse144, (a) => ({
          TAG: "ProjectileDestroy",
          _0: a
        }), (a) => ({
          TAG: "ProjectileDestroy",
          _0: a
        }))
      };
    case "PvpToggle":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse46, (a) => ({
          TAG: "PvpToggle",
          _0: a
        }), (a) => ({
          TAG: "PvpToggle",
          _0: a
        }))
      };
    case "ChestOpen":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "ChestOpenFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse113, (a) => ({
            TAG: "ChestOpen",
            _0: a
          }), (a) => ({
            TAG: "ChestOpen",
            _0: a
          }))
        };
      }
    case "ChestItem":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse5, (a) => ({
          TAG: "ChestItem",
          _0: a
        }), (a) => ({
          TAG: "ChestItem",
          _0: a
        }))
      };
    case "ActiveContainerSync":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse148, (a) => ({
          TAG: "ActiveContainerSync",
          _0: a
        }), (a) => ({
          TAG: "ActiveContainerSync",
          _0: a
        }))
      };
    case "ChestPlace":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse7, (a) => ({
          TAG: "ChestPlace",
          _0: a
        }), (a) => ({
          TAG: "ChestPlace",
          _0: a
        }))
      };
    case "HealEffect":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse117, (a) => ({
          TAG: "HealEffect",
          _0: a
        }), (a) => ({
          TAG: "HealEffect",
          _0: a
        }))
      };
    case "Zones":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse77, (a) => ({
          TAG: "Zones",
          _0: a
        }), (a) => ({
          TAG: "Zones",
          _0: a
        }))
      };
    case "PasswordRequired":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse139, (a) => ({
            TAG: "PasswordRequired",
            _0: a
          }), (a) => ({
            TAG: "PasswordRequired",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "PasswordRequiredFromClient"
        };
      }
    case "PasswordSend":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "PasswordSendFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse123, (a) => ({
            TAG: "PasswordSend",
            _0: a
          }), (a) => ({
            TAG: "PasswordSend",
            _0: a
          }))
        };
      }
    case "ItemOwnerRemove":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse20, (a) => ({
          TAG: "ItemOwnerRemove",
          _0: a
        }), (a) => ({
          TAG: "ItemOwnerRemove",
          _0: a
        }))
      };
    case "NpcTalk":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse33, (a) => ({
          TAG: "NpcTalk",
          _0: a
        }), (a) => ({
          TAG: "NpcTalk",
          _0: a
        }))
      };
    case "PlayerAnimation":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse37, (a) => ({
          TAG: "PlayerAnimation",
          _0: a
        }), (a) => ({
          TAG: "PlayerAnimation",
          _0: a
        }))
      };
    case "PlayerMana":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse44, (a) => ({
          TAG: "PlayerMana",
          _0: a
        }), (a) => ({
          TAG: "PlayerMana",
          _0: a
        }))
      };
    case "ManaEffect":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse118, (a) => ({
          TAG: "ManaEffect",
          _0: a
        }), (a) => ({
          TAG: "ManaEffect",
          _0: a
        }))
      };
    case "PlayerTeam":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse45, (a) => ({
          TAG: "PlayerTeam",
          _0: a
        }), (a) => ({
          TAG: "PlayerTeam",
          _0: a
        }))
      };
    case "SignRead":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "SignReadFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse49, (a) => ({
            TAG: "SignRead",
            _0: a
          }), (a) => ({
            TAG: "SignRead",
            _0: a
          }))
        };
      }
    case "SignNew":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse48, (a) => ({
          TAG: "SignNew",
          _0: a
        }), (a) => ({
          TAG: "SignNew",
          _0: a
        }))
      };
    case "LiquidSet":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse114, (a) => ({
          TAG: "LiquidSet",
          _0: a
        }), (a) => ({
          TAG: "LiquidSet",
          _0: a
        }))
      };
    case "PlayerSpawnSelf":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse136, (a) => ({
            TAG: "PlayerSpawnSelf",
            _0: a
          }), (a) => ({
            TAG: "PlayerSpawnSelf",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "PlayerSpawnSelfFromClient"
        };
      }
    case "PlayerBuffsSet":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse39, (a) => ({
          TAG: "PlayerBuffsSet",
          _0: a
        }), (a) => ({
          TAG: "PlayerBuffsSet",
          _0: a
        }))
      };
    case "NpcSpecialEffect":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse138, (a) => ({
          TAG: "NpcSpecialEffect",
          _0: a
        }), (a) => ({
          TAG: "NpcSpecialEffect",
          _0: a
        }))
      };
    case "ChestOrTempleUnlock":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse6, (a) => ({
          TAG: "ChestOrTempleUnlock",
          _0: a
        }), (a) => ({
          TAG: "ChestOrTempleUnlock",
          _0: a
        }))
      };
    case "NpcBuffAdd":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse119, (a) => ({
          TAG: "NpcBuffAdd",
          _0: a
        }), (a) => ({
          TAG: "NpcBuffAdd",
          _0: a
        }))
      };
    case "NpcBuffUpdate":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse26, (a) => ({
            TAG: "NpcBuffUpdate",
            _0: a
          }), (a) => ({
            TAG: "NpcBuffUpdate",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "NpcBuffUpdateFromClient"
        };
      }
    case "PlayerBuffAdd":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse38, (a) => ({
          TAG: "PlayerBuffAdd",
          _0: a
        }), (a) => ({
          TAG: "PlayerBuffAdd",
          _0: a
        }))
      };
    case "NpcNameUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, (__x) => parse31(__x, fromServer), (a) => ({
          TAG: "NpcNameUpdate",
          _0: a
        }), (a) => ({
          TAG: "NpcNameUpdate",
          _0: a
        }))
      };
    case "GoodEvilUpdate":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse129, (a) => ({
            TAG: "GoodEvilUpdate",
            _0: a
          }), (a) => ({
            TAG: "GoodEvilUpdate",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "GoodEvilUpdateFromClient"
        };
      }
    case "HarpPlay":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse111, (a) => ({
          TAG: "HarpPlay",
          _0: a
        }), (a) => ({
          TAG: "HarpPlay",
          _0: a
        }))
      };
    case "SwitchHit":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse53, (a) => ({
          TAG: "SwitchHit",
          _0: a
        }), (a) => ({
          TAG: "SwitchHit",
          _0: a
        }))
      };
    case "NpcHomeUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse29, (a) => ({
          TAG: "NpcHomeUpdate",
          _0: a
        }), (a) => ({
          TAG: "NpcHomeUpdate",
          _0: a
        }))
      };
    case "BossOrInvasionSpawn":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "BossOrInvasionSpawnFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse3, (a) => ({
            TAG: "BossOrInvasionSpawn",
            _0: a
          }), (a) => ({
            TAG: "BossOrInvasionSpawn",
            _0: a
          }))
        };
      }
    case "PlayerDodge":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse43, (a) => ({
          TAG: "PlayerDodge",
          _0: a
        }), (a) => ({
          TAG: "PlayerDodge",
          _0: a
        }))
      };
    case "TilePaint":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse63, (a) => ({
          TAG: "TilePaint",
          _0: a
        }), (a) => ({
          TAG: "TilePaint",
          _0: a
        }))
      };
    case "WallPaint":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse73, (a) => ({
          TAG: "WallPaint",
          _0: a
        }), (a) => ({
          TAG: "WallPaint",
          _0: a
        }))
      };
    case "Teleport":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse54, (a) => ({
          TAG: "Teleport",
          _0: a
        }), (a) => ({
          TAG: "Teleport",
          _0: a
        }))
      };
    case "PlayerHealOther":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse135, (a) => ({
          TAG: "PlayerHealOther",
          _0: a
        }), (a) => ({
          TAG: "PlayerHealOther",
          _0: a
        }))
      };
    case "DimensionsUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse13, (a) => ({
          TAG: "DimensionsUpdate",
          _0: a
        }), (a) => ({
          TAG: "DimensionsUpdate",
          _0: a
        }))
      };
    case "ClientUuid":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "ClientUuidFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse101, (a) => ({
            TAG: "ClientUuid",
            _0: a
          }), (a) => ({
            TAG: "ClientUuid",
            _0: a
          }))
        };
      }
    case "ChestName":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse112, (a) => ({
          TAG: "ChestName",
          _0: a
        }), (a) => ({
          TAG: "ChestName",
          _0: a
        }))
      };
    case "NpcCatch":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "NpcCatchFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse27, (a) => ({
            TAG: "NpcCatch",
            _0: a
          }), (a) => ({
            TAG: "NpcCatch",
            _0: a
          }))
        };
      }
    case "NpcRelease":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "NpcReleaseFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse120, (a) => ({
            TAG: "NpcRelease",
            _0: a
          }), (a) => ({
            TAG: "NpcRelease",
            _0: a
          }))
        };
      }
    case "TravellingMerchantInventory":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse70, (a) => ({
            TAG: "TravellingMerchantInventory",
            _0: a
          }), (a) => ({
            TAG: "TravellingMerchantInventory",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "TravellingMerchantInventoryFromClient"
        };
      }
    case "TeleportationPotion":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse55, (a) => ({
          TAG: "TeleportationPotion",
          _0: a
        }), (a) => ({
          TAG: "TeleportationPotion",
          _0: a
        }))
      };
    case "AnglerQuest":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse, (a) => ({
            TAG: "AnglerQuest",
            _0: a
          }), (a) => ({
            TAG: "AnglerQuest",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "AnglerQuestFromClient"
        };
      }
    case "AnglerQuestComplete":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "AnglerQuestCompleteFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse2, (a) => ({
            TAG: "AnglerQuestComplete",
            _0: a
          }), (a) => ({
            TAG: "AnglerQuestComplete",
            _0: a
          }))
        };
      }
    case "AnglerQuestsCompletedAmount":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse162, (a) => ({
          TAG: "AnglerQuestsCompletedAmount",
          _0: a
        }), (a) => ({
          TAG: "AnglerQuestsCompletedAmount",
          _0: a
        }))
      };
    case "TemporaryAnimationCreate":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse56, (a) => ({
            TAG: "TemporaryAnimationCreate",
            _0: a
          }), (a) => ({
            TAG: "TemporaryAnimationCreate",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "TemporaryAnimationCreateFromClient"
        };
      }
    case "InvasionProgressReport":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse16, (a) => ({
            TAG: "InvasionProgressReport",
            _0: a
          }), (a) => ({
            TAG: "InvasionProgressReport",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "InvasionProgressReportFromClient"
        };
      }
    case "ObjectPlace":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse35, (a) => ({
          TAG: "ObjectPlace",
          _0: a
        }), (a) => ({
          TAG: "ObjectPlace",
          _0: a
        }))
      };
    case "PlayerChestIndexSync":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse40, (a) => ({
            TAG: "PlayerChestIndexSync",
            _0: a
          }), (a) => ({
            TAG: "PlayerChestIndexSync",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "PlayerChestIndexSyncFromClient"
        };
      }
    case "CombatNumberCreate":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse146, (a) => ({
            TAG: "CombatNumberCreate",
            _0: a
          }), (a) => ({
            TAG: "CombatNumberCreate",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "CombatNumberCreateFromClient"
        };
      }
    case "NetModuleLoad":
      return {
        TAG: "Ok",
        _0: makeParsersWithFromServer(packetName2, parse23, (a) => ({
          TAG: "NetModuleLoad",
          _0: a
        }), (a) => ({
          TAG: "NetModuleLoad",
          _0: a
        }))
      };
    case "NpcKillCount":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse30, (a) => ({
            TAG: "NpcKillCount",
            _0: a
          }), (a) => ({
            TAG: "NpcKillCount",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "NpcKillCountFromClient"
        };
      }
    case "PlayerStealth":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse127, (a) => ({
          TAG: "PlayerStealth",
          _0: a
        }), (a) => ({
          TAG: "PlayerStealth",
          _0: a
        }))
      };
    case "ItemForceIntoNearestChest":
      return {
        TAG: "Ok",
        _0: makeParsersWithFromServer(packetName2, parse85, (a) => ({
          TAG: "ItemForceIntoNearestChest",
          _0: a
        }), (a) => ({
          TAG: "ItemForceIntoNearestChest",
          _0: a
        }))
      };
    case "TileEntityUpdate":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse61, (a) => ({
            TAG: "TileEntityUpdate",
            _0: a
          }), (a) => ({
            TAG: "TileEntityUpdate",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "TileEntityUpdateFromClient"
        };
      }
    case "TileEntityPlace":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "TileEntityPlaceFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse60, (a) => ({
            TAG: "TileEntityPlace",
            _0: a
          }), (a) => ({
            TAG: "TileEntityPlace",
            _0: a
          }))
        };
      }
    case "ItemDropModify":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse130, (a) => ({
            TAG: "ItemDropModify",
            _0: a
          }), (a) => ({
            TAG: "ItemDropModify",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "ItemDropModifyFromClient"
        };
      }
    case "ItemFramePlace":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "ItemFramePlaceFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse131, (a) => ({
            TAG: "ItemFramePlace",
            _0: a
          }), (a) => ({
            TAG: "ItemFramePlace",
            _0: a
          }))
        };
      }
    case "ItemDropInstancedUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse158, (a) => ({
          TAG: "ItemDropInstancedUpdate",
          _0: a
        }), (a) => ({
          TAG: "ItemDropInstancedUpdate",
          _0: a
        }))
      };
    case "EmoteBubble":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse122, (a) => ({
            TAG: "EmoteBubble",
            _0: a
          }), (a) => ({
            TAG: "EmoteBubble",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "EmoteBubbleFromClient"
        };
      }
    case "ExtraValueSync":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse14, (a) => ({
          TAG: "ExtraValueSync",
          _0: a
        }), (a) => ({
          TAG: "ExtraValueSync",
          _0: a
        }))
      };
    case "SocialHandshake":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse51, (a) => ({
          TAG: "SocialHandshake",
          _0: a
        }), (a) => ({
          TAG: "SocialHandshake",
          _0: a
        }))
      };
    case "Unused":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse80, (a) => ({
          TAG: "Unused",
          _0: a
        }), (a) => ({
          TAG: "Unused",
          _0: a
        }))
      };
    case "PortalKill":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "PortalKillFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse121, (a) => ({
            TAG: "PortalKill",
            _0: a
          }), (a) => ({
            TAG: "PortalKill",
            _0: a
          }))
        };
      }
    case "PlayerTeleportPortal":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse151, (a) => ({
          TAG: "PlayerTeleportPortal",
          _0: a
        }), (a) => ({
          TAG: "PlayerTeleportPortal",
          _0: a
        }))
      };
    case "NpcKilledNotification":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse155, (a) => ({
            TAG: "NpcKilledNotification",
            _0: a
          }), (a) => ({
            TAG: "NpcKilledNotification",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "NpcKilledNotificationFromClient"
        };
      }
    case "EventNotification":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse140, (a) => ({
            TAG: "EventNotification",
            _0: a
          }), (a) => ({
            TAG: "EventNotification",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "EventNotificationFromClient"
        };
      }
    case "MinionTargetUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse147, (a) => ({
          TAG: "MinionTargetUpdate",
          _0: a
        }), (a) => ({
          TAG: "MinionTargetUpdate",
          _0: a
        }))
      };
    case "NpcTeleportPortal":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse34, (a) => ({
          TAG: "NpcTeleportPortal",
          _0: a
        }), (a) => ({
          TAG: "NpcTeleportPortal",
          _0: a
        }))
      };
    case "ShieldStrengthsUpdate":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse156, (a) => ({
            TAG: "ShieldStrengthsUpdate",
            _0: a
          }), (a) => ({
            TAG: "ShieldStrengthsUpdate",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "ShieldStrengthsUpdateFromClient"
        };
      }
    case "NebulaLevelUp":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse125, (a) => ({
          TAG: "NebulaLevelUp",
          _0: a
        }), (a) => ({
          TAG: "NebulaLevelUp",
          _0: a
        }))
      };
    case "MoonLordCountdown":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse143, (a) => ({
            TAG: "MoonLordCountdown",
            _0: a
          }), (a) => ({
            TAG: "MoonLordCountdown",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "MoonLordCountdownFromClient"
        };
      }
    case "NpcShopItem":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse32, (a) => ({
            TAG: "NpcShopItem",
            _0: a
          }), (a) => ({
            TAG: "NpcShopItem",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "NpcShopItemFromClient"
        };
      }
    case "GemLockToggle":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "GemLockToggleFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse124, (a) => ({
            TAG: "GemLockToggle",
            _0: a
          }), (a) => ({
            TAG: "GemLockToggle",
            _0: a
          }))
        };
      }
    case "SmokePoof":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse50, (a) => ({
            TAG: "SmokePoof",
            _0: a
          }), (a) => ({
            TAG: "SmokePoof",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "SmokePoofFromClient"
        };
      }
    case "ChatMessageSmart":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse4, (a) => ({
            TAG: "ChatMessageSmart",
            _0: a
          }), (a) => ({
            TAG: "ChatMessageSmart",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "ChatMessageSmartFromClient"
        };
      }
    case "WiredCannonShot":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse75, (a) => ({
            TAG: "WiredCannonShot",
            _0: a
          }), (a) => ({
            TAG: "WiredCannonShot",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "WiredCannonShotFromClient"
        };
      }
    case "MassWireOperation":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "MassWireOperationFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse142, (a) => ({
            TAG: "MassWireOperation",
            _0: a
          }), (a) => ({
            TAG: "MassWireOperation",
            _0: a
          }))
        };
      }
    case "MassWireOperationPay":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse150, (a) => ({
            TAG: "MassWireOperationPay",
            _0: a
          }), (a) => ({
            TAG: "MassWireOperationPay",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "MassWireOperationPayFromClient"
        };
      }
    case "PartyToggle":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "PartyToggleFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse36, (a) => ({
            TAG: "PartyToggle",
            _0: a
          }), (a) => ({
            TAG: "PartyToggle",
            _0: a
          }))
        };
      }
    case "TreeGrowFx":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse71, (a) => ({
          TAG: "TreeGrowFx",
          _0: a
        }), (a) => ({
          TAG: "TreeGrowFx",
          _0: a
        }))
      };
    case "CrystalInvasionStart":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "CrystalInvasionStartFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse12, (a) => ({
            TAG: "CrystalInvasionStart",
            _0: a
          }), (a) => ({
            TAG: "CrystalInvasionStart",
            _0: a
          }))
        };
      }
    case "CrystalInvasionWipeAll":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse157, (a) => ({
            TAG: "CrystalInvasionWipeAll",
            _0: a
          }), (a) => ({
            TAG: "CrystalInvasionWipeAll",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "CrystalInvasionWipeAllFromClient"
        };
      }
    case "MinionAttackTargetUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse161, (a) => ({
          TAG: "MinionAttackTargetUpdate",
          _0: a
        }), (a) => ({
          TAG: "MinionAttackTargetUpdate",
          _0: a
        }))
      };
    case "CrystalInvasionSendWaitTime":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse163, (a) => ({
            TAG: "CrystalInvasionSendWaitTime",
            _0: a
          }), (a) => ({
            TAG: "CrystalInvasionSendWaitTime",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "CrystalInvasionSendWaitTimeFromClient"
        };
      }
    case "PlayerDamage":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse103, (a) => ({
          TAG: "PlayerDamage",
          _0: a
        }), (a) => ({
          TAG: "PlayerDamage",
          _0: a
        }))
      };
    case "PlayerDeath":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse42, (a) => ({
          TAG: "PlayerDeath",
          _0: a
        }), (a) => ({
          TAG: "PlayerDeath",
          _0: a
        }))
      };
    case "CombatTextCreate":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse137, (a) => ({
            TAG: "CombatTextCreate",
            _0: a
          }), (a) => ({
            TAG: "CombatTextCreate",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "CombatTextCreateFromClient"
        };
      }
    case "Emoji":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "EmojiFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse108, (a) => ({
            TAG: "Emoji",
            _0: a
          }), (a) => ({
            TAG: "Emoji",
            _0: a
          }))
        };
      }
    case "TileEntityDisplayDollItemSync":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse57, (a) => ({
          TAG: "TileEntityDisplayDollItemSync",
          _0: a
        }), (a) => ({
          TAG: "TileEntityDisplayDollItemSync",
          _0: a
        }))
      };
    case "TileEntityInteractionRequest":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse59, (a) => ({
          TAG: "TileEntityInteractionRequest",
          _0: a
        }), (a) => ({
          TAG: "TileEntityInteractionRequest",
          _0: a
        }))
      };
    case "WeaponsRackTryPlacing":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "WeaponsRackTryPlacingFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse74, (a) => ({
            TAG: "WeaponsRackTryPlacing",
            _0: a
          }), (a) => ({
            TAG: "WeaponsRackTryPlacing",
            _0: a
          }))
        };
      }
    case "TileEntityHatRackItemSync":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse58, (a) => ({
          TAG: "TileEntityHatRackItemSync",
          _0: a
        }), (a) => ({
          TAG: "TileEntityHatRackItemSync",
          _0: a
        }))
      };
    case "TilePickingSync":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse64, (a) => ({
          TAG: "TilePickingSync",
          _0: a
        }), (a) => ({
          TAG: "TilePickingSync",
          _0: a
        }))
      };
    case "RevengeMarkerSync":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse145, (a) => ({
            TAG: "RevengeMarkerSync",
            _0: a
          }), (a) => ({
            TAG: "RevengeMarkerSync",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "RevengeMarkerSyncFromClient"
        };
      }
    case "RevengeMarkerRemove":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse149, (a) => ({
            TAG: "RevengeMarkerRemove",
            _0: a
          }), (a) => ({
            TAG: "RevengeMarkerRemove",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "RevengeMarkerRemoveFromClient"
        };
      }
    case "GolfBallLandInCup":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse141, (a) => ({
          TAG: "GolfBallLandInCup",
          _0: a
        }), (a) => ({
          TAG: "GolfBallLandInCup",
          _0: a
        }))
      };
    case "ClientFinishConnectingToServer":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse8, (a) => ({
            TAG: "ClientFinishConnectingToServer",
            _0: a
          }), (a) => ({
            TAG: "ClientFinishConnectingToServer",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "ClientFinishConnectingToServerFromClient"
        };
      }
    case "NpcFishOut":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "NpcFishOutFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse28, (a) => ({
            TAG: "NpcFishOut",
            _0: a
          }), (a) => ({
            TAG: "NpcFishOut",
            _0: a
          }))
        };
      }
    case "NpcTamper":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse116, (a) => ({
            TAG: "NpcTamper",
            _0: a
          }), (a) => ({
            TAG: "NpcTamper",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "NpcTamperFromClient"
        };
      }
    case "LegacySoundPlay":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse134, (a) => ({
            TAG: "LegacySoundPlay",
            _0: a
          }), (a) => ({
            TAG: "LegacySoundPlay",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "LegacySoundPlayFromClient"
        };
      }
    case "FoodPlatterTryPlacing":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "FoodPlatterTryPlacingFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse154, (a) => ({
            TAG: "FoodPlatterTryPlacing",
            _0: a
          }), (a) => ({
            TAG: "FoodPlatterTryPlacing",
            _0: a
          }))
        };
      }
    case "PlayerLuckFactorsUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse90, (a) => ({
          TAG: "PlayerLuckFactorsUpdate",
          _0: a
        }), (a) => ({
          TAG: "PlayerLuckFactorsUpdate",
          _0: a
        }))
      };
    case "PlayerDead":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse41, (a) => ({
            TAG: "PlayerDead",
            _0: a
          }), (a) => ({
            TAG: "PlayerDead",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "PlayerDeadFromClient"
        };
      }
    case "CavernMonsterTypeSync":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse152, (a) => ({
          TAG: "CavernMonsterTypeSync",
          _0: a
        }), (a) => ({
          TAG: "CavernMonsterTypeSync",
          _0: a
        }))
      };
    case "NpcBuffRemovalRequest":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "NpcBuffRemovalRequestFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse25, (a) => ({
            TAG: "NpcBuffRemovalRequest",
            _0: a
          }), (a) => ({
            TAG: "NpcBuffRemovalRequest",
            _0: a
          }))
        };
      }
    case "ClientSyncedInventory":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "ClientSyncedInventoryFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse153, (a) => ({
            TAG: "ClientSyncedInventory",
            _0: a
          }), (a) => ({
            TAG: "ClientSyncedInventory",
            _0: a
          }))
        };
      }
    case "CountsAsHostForGameplaySet":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse10, (a) => ({
          TAG: "CountsAsHostForGameplaySet",
          _0: a
        }), (a) => ({
          TAG: "CountsAsHostForGameplaySet",
          _0: a
        }))
      };
    case "CreditsOrSlimeTransform":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse11, (a) => ({
          TAG: "CreditsOrSlimeTransform",
          _0: a
        }), (a) => ({
          TAG: "CreditsOrSlimeTransform",
          _0: a
        }))
      };
    case "LucyAxeMessage":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse132, (a) => ({
          TAG: "LucyAxeMessage",
          _0: a
        }), (a) => ({
          TAG: "LucyAxeMessage",
          _0: a
        }))
      };
    case "PiggyBankVoidLensUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse160, (a) => ({
          TAG: "PiggyBankVoidLensUpdate",
          _0: a
        }), (a) => ({
          TAG: "PiggyBankVoidLensUpdate",
          _0: a
        }))
      };
    case "DungeonDefendersEventAttemptSkipWait":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse164, (a) => ({
          TAG: "DungeonDefendersEventAttemptSkipWait",
          _0: a
        }), (a) => ({
          TAG: "DungeonDefendersEventAttemptSkipWait",
          _0: a
        }))
      };
    case "HaveDryadDoStardewAnimation":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse15, (a) => ({
          TAG: "HaveDryadDoStardewAnimation",
          _0: a
        }), (a) => ({
          TAG: "HaveDryadDoStardewAnimation",
          _0: a
        }))
      };
    case "ItemDropShimmeredUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse17, (a) => ({
          TAG: "ItemDropShimmeredUpdate",
          _0: a
        }), (a) => ({
          TAG: "ItemDropShimmeredUpdate",
          _0: a
        }))
      };
    case "ShimmerEffectOrCoinLuck":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse47, (a) => ({
          TAG: "ShimmerEffectOrCoinLuck",
          _0: a
        }), (a) => ({
          TAG: "ShimmerEffectOrCoinLuck",
          _0: a
        }))
      };
    case "LoadoutSwitch":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse21, (a) => ({
          TAG: "LoadoutSwitch",
          _0: a
        }), (a) => ({
          TAG: "LoadoutSwitch",
          _0: a
        }))
      };
    case "ItemDropProtectedUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse159, (a) => ({
          TAG: "ItemDropProtectedUpdate",
          _0: a
        }), (a) => ({
          TAG: "ItemDropProtectedUpdate",
          _0: a
        }))
      };
    case "DeadCellsDisplayJarTryPlacing":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse79, (a) => ({
          TAG: "DeadCellsDisplayJarTryPlacing",
          _0: a
        }), (a) => ({
          TAG: "DeadCellsDisplayJarTryPlacing",
          _0: a
        }))
      };
    case "PlayerSpectate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse91, (a) => ({
          TAG: "PlayerSpectate",
          _0: a
        }), (a) => ({
          TAG: "PlayerSpectate",
          _0: a
        }))
      };
    case "ItemDropClear":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse83, (a) => ({
          TAG: "ItemDropClear",
          _0: a
        }), (a) => ({
          TAG: "ItemDropClear",
          _0: a
        }))
      };
    case "PlayerItemUseSound":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse89, (a) => ({
          TAG: "PlayerItemUseSound",
          _0: a
        }), (a) => ({
          TAG: "PlayerItemUseSound",
          _0: a
        }))
      };
    case "NpcHurtByDebuff":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse87, (a) => ({
          TAG: "NpcHurtByDebuff",
          _0: a
        }), (a) => ({
          TAG: "NpcHurtByDebuff",
          _0: a
        }))
      };
    case "Ping":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse88, (a) => ({
          TAG: "Ping",
          _0: a
        }), (a) => ({
          TAG: "Ping",
          _0: a
        }))
      };
    case "ChestResize":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse78, (a) => ({
          TAG: "ChestResize",
          _0: a
        }), (a) => ({
          TAG: "ChestResize",
          _0: a
        }))
      };
    case "LeashedEntityAnchorInsertItem":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse86, (a) => ({
          TAG: "LeashedEntityAnchorInsertItem",
          _0: a
        }), (a) => ({
          TAG: "LeashedEntityAnchorInsertItem",
          _0: a
        }))
      };
    case "PlayerTeamUpdate":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse93, (a) => ({
          TAG: "PlayerTeamUpdate",
          _0: a
        }), (a) => ({
          TAG: "PlayerTeamUpdate",
          _0: a
        }))
      };
    case "PlayerTeamSwapSpawn":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse92, (a) => ({
          TAG: "PlayerTeamSwapSpawn",
          _0: a
        }), (a) => ({
          TAG: "PlayerTeamSwapSpawn",
          _0: a
        }))
      };
    case "SectionRequest":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse94, (a) => ({
          TAG: "SectionRequest",
          _0: a
        }), (a) => ({
          TAG: "SectionRequest",
          _0: a
        }))
      };
    case "ItemDropPosition":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse84, (a) => ({
          TAG: "ItemDropPosition",
          _0: a
        }), (a) => ({
          TAG: "ItemDropPosition",
          _0: a
        }))
      };
    case "HostToken":
      return {
        TAG: "Ok",
        _0: makeParsers(packetName2, parse81, (a) => ({
          TAG: "HostToken",
          _0: a
        }), (a) => ({
          TAG: "HostToken",
          _0: a
        }))
      };
    case "ServerInfo":
      if (fromServer) {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse109, (a) => ({
            TAG: "ServerInfo",
            _0: a
          }), (a) => ({
            TAG: "ServerInfo",
            _0: a
          }))
        };
      } else {
        return {
          TAG: "Error",
          _0: "ServerInfoFromClient"
        };
      }
    case "PlayerPlatformInfo":
      if (fromServer) {
        return {
          TAG: "Error",
          _0: "PlayerPlatformInfoFromServer"
        };
      } else {
        return {
          TAG: "Ok",
          _0: makeParsers(packetName2, parse128, (a) => ({
            TAG: "PlayerPlatformInfo",
            _0: a
          }), (a) => ({
            TAG: "PlayerPlatformInfo",
            _0: a
          }))
        };
      }
  }
}
function parse165(buffer, fromServer, ignoreOpt) {
  let ignore = ignoreOpt !== void 0 ? ignoreOpt : [];
  let match = buffer.length;
  if (!(match > 2 || match < 0)) {
    return {
      TAG: "Error",
      _0: {
        TAG: "InvalidPacketLength",
        _0: buffer.length
      }
    };
  }
  let packetType = fromInt(buffer[2]);
  if (packetType === void 0) {
    return {
      TAG: "Error",
      _0: {
        TAG: "InvalidPacketType",
        _0: buffer[2]
      }
    };
  }
  if (ignore.includes(packetType)) {
    return {
      TAG: "Error",
      _0: "IgnoredPacket"
    };
  }
  try {
    let parsers = getParsers(packetType, fromServer);
    if (parsers.TAG === "Ok") {
      return parsers._0.parse(buffer, fromServer);
    } else {
      return {
        TAG: "Error",
        _0: parsers._0
      };
    }
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          TAG: "ReaderError",
          _0: {
            context: "Parser.parse",
            error: obj._1
          }
        }
      };
    }
    throw obj;
  }
}
function parseLazy(buffer, fromServer) {
  let match = buffer.length;
  if (!(match > 2 || match < 0)) {
    return {
      TAG: "Error",
      _0: {
        TAG: "InvalidPacketLength",
        _0: buffer.length
      }
    };
  }
  let packetType = fromInt(buffer[2]);
  if (packetType === void 0) {
    return {
      TAG: "Error",
      _0: {
        TAG: "InvalidPacketType",
        _0: buffer[2]
      }
    };
  }
  try {
    let parsers = getParsers(packetType, fromServer);
    if (parsers.TAG === "Ok") {
      return parsers._0.parseLazy(buffer, fromServer);
    } else {
      return {
        TAG: "Error",
        _0: parsers._0
      };
    }
  } catch (raw_obj) {
    let obj = internalToException(raw_obj);
    if (obj.RE_EXN_ID === "JsExn") {
      return {
        TAG: "Error",
        _0: {
          TAG: "ReaderError",
          _0: {
            context: "Parser.parseLazy",
            error: obj._1
          }
        }
      };
    }
    throw obj;
  }
}
var Point_exports = {};
__export(Point_exports, {
  Float: () => Float,
  Int: () => Int
});
function toString3(self) {
  return `{ x: ` + self.x.toString() + `, y: ` + self.y.toString() + ` }`;
}
var Int = {
  toString: toString3
};
function toString$12(self) {
  return `{ x: ` + self.x.toString() + `, y: ` + self.y.toString() + ` }`;
}
var Float = {
  toString: toString$12
};

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/player.ts
var Player = class {
  id;
  name;
  inventory;
  life;
  mana;
  questStats = null;
  allowedNameChange;
  allowedCharacterChange;
  allowedLifeChange;
  allowedManaChange;
  position = {
    x: 0,
    y: 0
  };
  // Visuals
  skinVariant = 0;
  hair = 0;
  hairDye = 0;
  hideVisuals = 0;
  hideVisuals2 = 0;
  hideMisc = 0;
  hairColor = { R: 0, G: 0, B: 0 };
  skinColor = { R: 0, G: 0, B: 0 };
  eyeColor = { R: 0, G: 0, B: 0 };
  shirtColor = { R: 0, G: 0, B: 0 };
  underShirtColor = { R: 0, G: 0, B: 0 };
  pantsColor = { R: 0, G: 0, B: 0 };
  shoeColor = { R: 0, G: 0, B: 0 };
  extraAccessory = false;
  usingBiomeTorches = false;
  unlockedBiomeTorches = false;
  happyFunTorchTime = false;
  unlockedSuperCart = false;
  enabledSuperCart = false;
  usedAegisCrystal = false;
  usedAegisFruit = false;
  usedArcaneCrystal = false;
  usedGalaxyPearl = false;
  usedGummyWorm = false;
  usedAmbrosia = false;
  ateArtisanBread = false;
  voiceVariant = 0;
  voicePitchOffset = 0;
  client;
  difficulty = "Softcore";
  mode = "Classic";
  constructor(client) {
    this.client = client;
    this.id = 0;
    this.name = "";
    this.life = 100;
    this.mana = 20;
    this.allowedNameChange = false;
    this.allowedCharacterChange = false;
    this.allowedLifeChange = false;
    this.allowedManaChange = false;
    this.inventory = [];
  }
  setItem(item) {
    if (this.client === null) {
      return;
    }
    let playerInventorySlot = Packet_PlayerInventorySlot_exports.toBuffer({
      playerId: this.id,
      slot: item.slot,
      stack: item.stack,
      prefix: item.prefix,
      itemType: item.netID,
      favorited: item.favorited,
      blocked: item.blocked
    });
    switch (playerInventorySlot.TAG) {
      case "Ok":
        this.client.sendDirect(playerInventorySlot._0);
        break;
      case "Error":
        this.client.logging.error(`Error creating player inventory slot packet: ${playerInventorySlot._0}`);
        break;
    }
  }
  restoreQuestStats() {
    if (this.client && this.questStats) {
      this.client.sendDirect(new packetwriter_default().setType(76).packByte(this.id).packInt32(this.questStats.anglerQuestsFinished).packInt32(this.questStats.golferScoreAccumulated).data);
    }
  }
  restoreSavedMaxHealth() {
    if (this.client === null) {
      return;
    }
    let playerLife = PacketV1449_PlayerHealth_exports.toBuffer({
      playerId: this.id,
      maxHealth: this.life,
      health: this.life
    });
    switch (playerLife.TAG) {
      case "Ok":
        this.client.sendDirect(playerLife._0);
        break;
      case "Error":
        this.client.logging.error(`Error creating player health packet: ${playerLife._0}`);
        break;
    }
  }
  /**
   * @deprecated Use restoreSavedMaxHealth instead
   */
  setLife() {
    this.restoreSavedMaxHealth();
  }
  restoreSavedMaxMana() {
    if (this.client === null) {
      return;
    }
    let playerMana = PacketV1449_PlayerMana_exports.toBuffer({
      playerId: this.id,
      maxMana: this.mana,
      mana: this.mana
    });
    switch (playerMana.TAG) {
      case "Ok":
        this.client.sendDirect(playerMana._0);
        break;
      case "Error":
        this.client.logging.error(`Error creating player mana packet: ${playerMana._0}`);
        break;
    }
  }
  /**
   * @deprecated Use restoreSavedMaxMana instead
   */
  setMana() {
    this.restoreSavedMaxMana();
  }
  setVisuals() {
    if (this.client === null) {
      return;
    }
    const playerInfo = {
      playerId: this.id,
      skinVariant: this.skinVariant,
      hair: this.hair,
      name: this.name,
      hairDye: this.hairDye,
      hideVisuals: this.hideVisuals,
      hideVisuals2: this.hideVisuals2,
      hideMisc: this.hideMisc,
      hairColor: this.hairColor,
      skinColor: this.skinColor,
      eyeColor: this.eyeColor,
      shirtColor: this.shirtColor,
      underShirtColor: this.underShirtColor,
      pantsColor: this.pantsColor,
      shoeColor: this.shoeColor,
      difficulty: this.difficulty,
      mode: this.mode,
      extraAccessory: this.extraAccessory,
      usingBiomeTorches: this.usingBiomeTorches,
      unlockedBiomeTorches: this.unlockedBiomeTorches,
      happyFunTorchTime: this.happyFunTorchTime,
      unlockedSuperCart: this.unlockedSuperCart,
      enabledSuperCart: this.enabledSuperCart,
      usedAegisCrystal: this.usedAegisCrystal,
      usedAegisFruit: this.usedAegisFruit,
      usedArcaneCrystal: this.usedArcaneCrystal,
      usedGalaxyPearl: this.usedGalaxyPearl,
      usedGummyWorm: this.usedGummyWorm,
      usedAmbrosia: this.usedAmbrosia,
      ateArtisanBread: this.ateArtisanBread,
      voiceVariant: this.voiceVariant,
      voicePitchOffset: this.voicePitchOffset
    };
    const playerInfoPacket = Packet_PlayerInfo_exports.toBuffer(playerInfo);
    if (playerInfoPacket.TAG === "Ok") {
      this.client.sendDirect(playerInfoPacket._0);
    }
  }
};
var player_default = Player;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/packettypes.ts
var PacketTypes = /* @__PURE__ */ ((PacketTypes2) => {
  PacketTypes2[PacketTypes2["ConnectRequest"] = 1] = "ConnectRequest";
  PacketTypes2[PacketTypes2["Disconnect"] = 2] = "Disconnect";
  PacketTypes2[PacketTypes2["ContinueConnecting"] = 3] = "ContinueConnecting";
  PacketTypes2[PacketTypes2["PlayerInfo"] = 4] = "PlayerInfo";
  PacketTypes2[PacketTypes2["PlayerInventorySlot"] = 5] = "PlayerInventorySlot";
  PacketTypes2[PacketTypes2["ContinueConnecting2"] = 6] = "ContinueConnecting2";
  PacketTypes2[PacketTypes2["WorldInfo"] = 7] = "WorldInfo";
  PacketTypes2[PacketTypes2["GetSectionOrRequestSync"] = 8] = "GetSectionOrRequestSync";
  PacketTypes2[PacketTypes2["Status"] = 9] = "Status";
  PacketTypes2[PacketTypes2["SendSection"] = 10] = "SendSection";
  PacketTypes2[PacketTypes2["SectionTileFrame"] = 11] = "SectionTileFrame";
  PacketTypes2[PacketTypes2["SpawnPlayer"] = 12] = "SpawnPlayer";
  PacketTypes2[PacketTypes2["UpdatePlayer"] = 13] = "UpdatePlayer";
  PacketTypes2[PacketTypes2["PlayerActive"] = 14] = "PlayerActive";
  PacketTypes2[PacketTypes2["Null"] = 15] = "Null";
  PacketTypes2[PacketTypes2["PlayerHP"] = 16] = "PlayerHP";
  PacketTypes2[PacketTypes2["ModifyTile"] = 17] = "ModifyTile";
  PacketTypes2[PacketTypes2["Time"] = 18] = "Time";
  PacketTypes2[PacketTypes2["DoorToggle"] = 19] = "DoorToggle";
  PacketTypes2[PacketTypes2["SendTileSquare"] = 20] = "SendTileSquare";
  PacketTypes2[PacketTypes2["UpdateItemDrop"] = 21] = "UpdateItemDrop";
  PacketTypes2[PacketTypes2["UpdateItemOwner"] = 22] = "UpdateItemOwner";
  PacketTypes2[PacketTypes2["NPCUpdate"] = 23] = "NPCUpdate";
  PacketTypes2[PacketTypes2["StrikeNPCwithHeldItem"] = 24] = "StrikeNPCwithHeldItem";
  PacketTypes2[PacketTypes2["ChatMessage"] = 25] = "ChatMessage";
  PacketTypes2[PacketTypes2["PlayerDamage"] = 26] = "PlayerDamage";
  PacketTypes2[PacketTypes2["ProjectileUpdate"] = 27] = "ProjectileUpdate";
  PacketTypes2[PacketTypes2["NPCStrike"] = 28] = "NPCStrike";
  PacketTypes2[PacketTypes2["DestroyProjectile"] = 29] = "DestroyProjectile";
  PacketTypes2[PacketTypes2["TogglePVP"] = 30] = "TogglePVP";
  PacketTypes2[PacketTypes2["GetChestContentsOrActiveChest"] = 31] = "GetChestContentsOrActiveChest";
  PacketTypes2[PacketTypes2["ChestItem"] = 32] = "ChestItem";
  PacketTypes2[PacketTypes2["SetChestNameOrOpenChest"] = 33] = "SetChestNameOrOpenChest";
  PacketTypes2[PacketTypes2["PlaceOrKillChest"] = 34] = "PlaceOrKillChest";
  PacketTypes2[PacketTypes2["HealEffect"] = 35] = "HealEffect";
  PacketTypes2[PacketTypes2["PlayerZone"] = 36] = "PlayerZone";
  PacketTypes2[PacketTypes2["RequestPassword"] = 37] = "RequestPassword";
  PacketTypes2[PacketTypes2["SendPassword"] = 38] = "SendPassword";
  PacketTypes2[PacketTypes2["RemoveItemOwner"] = 39] = "RemoveItemOwner";
  PacketTypes2[PacketTypes2["SetActiveNPC"] = 40] = "SetActiveNPC";
  PacketTypes2[PacketTypes2["PlayerItemAnimation"] = 41] = "PlayerItemAnimation";
  PacketTypes2[PacketTypes2["PlayerMana"] = 42] = "PlayerMana";
  PacketTypes2[PacketTypes2["ManaEffect"] = 43] = "ManaEffect";
  PacketTypes2[PacketTypes2["KillMe"] = 44] = "KillMe";
  PacketTypes2[PacketTypes2["PlayerTeam"] = 45] = "PlayerTeam";
  PacketTypes2[PacketTypes2["RequestSign"] = 46] = "RequestSign";
  PacketTypes2[PacketTypes2["UpdateOrDisplaySign"] = 47] = "UpdateOrDisplaySign";
  PacketTypes2[PacketTypes2["SetLiquid"] = 48] = "SetLiquid";
  PacketTypes2[PacketTypes2["CompleteConnectionAndSpawn"] = 49] = "CompleteConnectionAndSpawn";
  PacketTypes2[PacketTypes2["UpdatePlayerBuff"] = 50] = "UpdatePlayerBuff";
  PacketTypes2[PacketTypes2["SpecialNPCEffect"] = 51] = "SpecialNPCEffect";
  PacketTypes2[PacketTypes2["Unlock"] = 52] = "Unlock";
  PacketTypes2[PacketTypes2["AddNPCBuff"] = 53] = "AddNPCBuff";
  PacketTypes2[PacketTypes2["UpdateNPCBuff"] = 54] = "UpdateNPCBuff";
  PacketTypes2[PacketTypes2["AddPlayerBuff"] = 55] = "AddPlayerBuff";
  PacketTypes2[PacketTypes2["UpdateNPCName"] = 56] = "UpdateNPCName";
  PacketTypes2[PacketTypes2["UpdateGoodOrEvil"] = 57] = "UpdateGoodOrEvil";
  PacketTypes2[PacketTypes2["PlayMusicItem"] = 58] = "PlayMusicItem";
  PacketTypes2[PacketTypes2["HitSwitch"] = 59] = "HitSwitch";
  PacketTypes2[PacketTypes2["NPCHomeUpdate"] = 60] = "NPCHomeUpdate";
  PacketTypes2[PacketTypes2["SpawnBossOrInvasion"] = 61] = "SpawnBossOrInvasion";
  PacketTypes2[PacketTypes2["PlayerDodge"] = 62] = "PlayerDodge";
  PacketTypes2[PacketTypes2["PaintTile"] = 63] = "PaintTile";
  PacketTypes2[PacketTypes2["PaintWall"] = 64] = "PaintWall";
  PacketTypes2[PacketTypes2["PlayerOrNPCTeleport"] = 65] = "PlayerOrNPCTeleport";
  PacketTypes2[PacketTypes2["HealOtherPlayer"] = 66] = "HealOtherPlayer";
  PacketTypes2[PacketTypes2["DimensionsUpdate"] = 67] = "DimensionsUpdate";
  PacketTypes2[PacketTypes2["ClientUUID"] = 68] = "ClientUUID";
  PacketTypes2[PacketTypes2["GetChestName"] = 69] = "GetChestName";
  PacketTypes2[PacketTypes2["CatchNPC_bugs"] = 70] = "CatchNPC_bugs";
  PacketTypes2[PacketTypes2["ReleaseNPC"] = 71] = "ReleaseNPC";
  PacketTypes2[PacketTypes2["TravellingMerchantInventory"] = 72] = "TravellingMerchantInventory";
  PacketTypes2[PacketTypes2["TeleportationPotion"] = 73] = "TeleportationPotion";
  PacketTypes2[PacketTypes2["AnglerQuest"] = 74] = "AnglerQuest";
  PacketTypes2[PacketTypes2["CompleteAnglerquesttoday"] = 75] = "CompleteAnglerquesttoday";
  PacketTypes2[PacketTypes2["NumberOfAnglerQuestsCompleted"] = 76] = "NumberOfAnglerQuestsCompleted";
  PacketTypes2[PacketTypes2["CreateTemporaryAnimation"] = 77] = "CreateTemporaryAnimation";
  PacketTypes2[PacketTypes2["ReportInvasionProgress"] = 78] = "ReportInvasionProgress";
  PacketTypes2[PacketTypes2["PlaceObject"] = 79] = "PlaceObject";
  PacketTypes2[PacketTypes2["SyncPlayerChestIndex"] = 80] = "SyncPlayerChestIndex";
  PacketTypes2[PacketTypes2["CreateCombatText"] = 81] = "CreateCombatText";
  PacketTypes2[PacketTypes2["LoadNetModule"] = 82] = "LoadNetModule";
  PacketTypes2[PacketTypes2["SetNPCKillCount"] = 83] = "SetNPCKillCount";
  PacketTypes2[PacketTypes2["SetPlayerStealth"] = 84] = "SetPlayerStealth";
  PacketTypes2[PacketTypes2["ForceItemIntoNearestChest"] = 85] = "ForceItemIntoNearestChest";
  PacketTypes2[PacketTypes2["UpdateTileEntity"] = 86] = "UpdateTileEntity";
  PacketTypes2[PacketTypes2["PlaceTileEntity"] = 87] = "PlaceTileEntity";
  PacketTypes2[PacketTypes2["AlterItemDrop"] = 88] = "AlterItemDrop";
  PacketTypes2[PacketTypes2["PlaceItemFrame"] = 89] = "PlaceItemFrame";
  PacketTypes2[PacketTypes2["UpdateItemDrop_Instanced"] = 90] = "UpdateItemDrop_Instanced";
  PacketTypes2[PacketTypes2["SyncEmoteBubble"] = 91] = "SyncEmoteBubble";
  PacketTypes2[PacketTypes2["SyncExtraValue"] = 92] = "SyncExtraValue";
  PacketTypes2[PacketTypes2["SocialHandshake"] = 93] = "SocialHandshake";
  PacketTypes2[PacketTypes2["Deprecated"] = 94] = "Deprecated";
  PacketTypes2[PacketTypes2["KillPortal"] = 95] = "KillPortal";
  PacketTypes2[PacketTypes2["PlayerTeleportThroughPortal"] = 96] = "PlayerTeleportThroughPortal";
  PacketTypes2[PacketTypes2["NotifyPlayerNPCKilled"] = 97] = "NotifyPlayerNPCKilled";
  PacketTypes2[PacketTypes2["NotifyPlayerOfEvent"] = 98] = "NotifyPlayerOfEvent";
  PacketTypes2[PacketTypes2["UpdateMinionTarget"] = 99] = "UpdateMinionTarget";
  PacketTypes2[PacketTypes2["NPCTeleportThroughPortal"] = 100] = "NPCTeleportThroughPortal";
  PacketTypes2[PacketTypes2["UpdateShieldStrengths"] = 101] = "UpdateShieldStrengths";
  PacketTypes2[PacketTypes2["NebulaLevelUpRequest"] = 102] = "NebulaLevelUpRequest";
  PacketTypes2[PacketTypes2["UpdateMoonLordCountdown"] = 103] = "UpdateMoonLordCountdown";
  PacketTypes2[PacketTypes2["SetNPCShopItem"] = 104] = "SetNPCShopItem";
  PacketTypes2[PacketTypes2["ToggleGemLock"] = 105] = "ToggleGemLock";
  PacketTypes2[PacketTypes2["PoofofSmoke"] = 106] = "PoofofSmoke";
  PacketTypes2[PacketTypes2["SmartChatMessage"] = 107] = "SmartChatMessage";
  PacketTypes2[PacketTypes2["WiredCannonShot"] = 108] = "WiredCannonShot";
  PacketTypes2[PacketTypes2["MassWireOperation"] = 109] = "MassWireOperation";
  PacketTypes2[PacketTypes2["MassWireOperationConsume"] = 110] = "MassWireOperationConsume";
  PacketTypes2[PacketTypes2["ToggleBirthdayParty"] = 111] = "ToggleBirthdayParty";
  PacketTypes2[PacketTypes2["GrowFX"] = 112] = "GrowFX";
  PacketTypes2[PacketTypes2["CrystalInvasionStart"] = 113] = "CrystalInvasionStart";
  PacketTypes2[PacketTypes2["CrystalInvasionWipeAll"] = 114] = "CrystalInvasionWipeAll";
  PacketTypes2[PacketTypes2["MinionAttackTargetUpdate"] = 115] = "MinionAttackTargetUpdate";
  PacketTypes2[PacketTypes2["CrystalInvasionSendWaitTime"] = 116] = "CrystalInvasionSendWaitTime";
  PacketTypes2[PacketTypes2["PlayerHurtV2"] = 117] = "PlayerHurtV2";
  PacketTypes2[PacketTypes2["PlayerDeathV2"] = 118] = "PlayerDeathV2";
  PacketTypes2[PacketTypes2["CombatTextString"] = 119] = "CombatTextString";
  PacketTypes2[PacketTypes2["Emoji"] = 120] = "Emoji";
  PacketTypes2[PacketTypes2["TEDisplayDollItemSync"] = 121] = "TEDisplayDollItemSync";
  PacketTypes2[PacketTypes2["RequestTileEntityInteraction"] = 122] = "RequestTileEntityInteraction";
  PacketTypes2[PacketTypes2["WeaponsRackTryPlacing"] = 123] = "WeaponsRackTryPlacing";
  PacketTypes2[PacketTypes2["TEHatRackItemSync"] = 124] = "TEHatRackItemSync";
  PacketTypes2[PacketTypes2["SyncTilePicking"] = 125] = "SyncTilePicking";
  PacketTypes2[PacketTypes2["SyncRevengeMarker"] = 126] = "SyncRevengeMarker";
  PacketTypes2[PacketTypes2["RemoveRevengeMarker"] = 127] = "RemoveRevengeMarker";
  PacketTypes2[PacketTypes2["LandGolfBallInCup"] = 128] = "LandGolfBallInCup";
  PacketTypes2[PacketTypes2["FinishedConnectingToServer"] = 129] = "FinishedConnectingToServer";
  PacketTypes2[PacketTypes2["FishOutNPC"] = 130] = "FishOutNPC";
  PacketTypes2[PacketTypes2["TamperWithNPC"] = 131] = "TamperWithNPC";
  PacketTypes2[PacketTypes2["PlayLegacySound"] = 132] = "PlayLegacySound";
  PacketTypes2[PacketTypes2["FoodPlatterTryPlacing"] = 133] = "FoodPlatterTryPlacing";
  PacketTypes2[PacketTypes2["UpdatePlayerLuckFactors"] = 134] = "UpdatePlayerLuckFactors";
  PacketTypes2[PacketTypes2["DeadPlayer"] = 135] = "DeadPlayer";
  PacketTypes2[PacketTypes2["SyncCavernMonsterType"] = 136] = "SyncCavernMonsterType";
  PacketTypes2[PacketTypes2["RequestNPCBuffRemoval"] = 137] = "RequestNPCBuffRemoval";
  PacketTypes2[PacketTypes2["ClientSyncedInventory"] = 138] = "ClientSyncedInventory";
  PacketTypes2[PacketTypes2["SetCountsAsHostForGameplay"] = 139] = "SetCountsAsHostForGameplay";
  PacketTypes2[PacketTypes2["CreditsOrSlimeTransform"] = 140] = "CreditsOrSlimeTransform";
  PacketTypes2[PacketTypes2["LucyAxeMessage"] = 141] = "LucyAxeMessage";
  PacketTypes2[PacketTypes2["PiggyBankVoidLensUpdate"] = 142] = "PiggyBankVoidLensUpdate";
  PacketTypes2[PacketTypes2["DungeonDefendersEventAttemptSkipWait"] = 143] = "DungeonDefendersEventAttemptSkipWait";
  PacketTypes2[PacketTypes2["HaveDryadDoStardewAnimation"] = 144] = "HaveDryadDoStardewAnimation";
  PacketTypes2[PacketTypes2["ItemDropShimmeredUpdate"] = 145] = "ItemDropShimmeredUpdate";
  PacketTypes2[PacketTypes2["ShimmerEffectOrCoinLuck"] = 146] = "ShimmerEffectOrCoinLuck";
  PacketTypes2[PacketTypes2["LoadoutSwitch"] = 147] = "LoadoutSwitch";
  PacketTypes2[PacketTypes2["ItemDropProtectedUpdate"] = 148] = "ItemDropProtectedUpdate";
  PacketTypes2[PacketTypes2["DeadCellsDisplayJarTryPlacing"] = 149] = "DeadCellsDisplayJarTryPlacing";
  PacketTypes2[PacketTypes2["PlayerSpectate"] = 150] = "PlayerSpectate";
  PacketTypes2[PacketTypes2["ItemDropClear"] = 151] = "ItemDropClear";
  PacketTypes2[PacketTypes2["PlayerItemUseSound"] = 152] = "PlayerItemUseSound";
  PacketTypes2[PacketTypes2["NpcHurtByDebuff"] = 153] = "NpcHurtByDebuff";
  PacketTypes2[PacketTypes2["Ping"] = 154] = "Ping";
  PacketTypes2[PacketTypes2["ChestResize"] = 155] = "ChestResize";
  PacketTypes2[PacketTypes2["LeashedEntityAnchorInsertItem"] = 156] = "LeashedEntityAnchorInsertItem";
  PacketTypes2[PacketTypes2["PlayerTeamUpdate"] = 157] = "PlayerTeamUpdate";
  PacketTypes2[PacketTypes2["PlayerTeamSwapSpawn"] = 158] = "PlayerTeamSwapSpawn";
  PacketTypes2[PacketTypes2["SectionRequest"] = 159] = "SectionRequest";
  PacketTypes2[PacketTypes2["ItemDropPosition"] = 160] = "ItemDropPosition";
  PacketTypes2[PacketTypes2["HostToken"] = 161] = "HostToken";
  return PacketTypes2;
})(PacketTypes || {});
var packettypes_default = PacketTypes;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/npc.ts
var NPC = class {
  index;
  type;
  life;
  constructor(index, type, life) {
    this.index = index;
    this.type = type;
    this.life = life;
  }
};
var npc_default = NPC;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/item.ts
var Item = class {
  constructor(slot, stack, prefix, netID, favorited = false, blocked = false) {
    this.favorited = favorited;
    this.blocked = blocked;
    this.slot = slot;
    this.stack = stack;
    this.prefix = prefix;
    this.netID = netID;
  }
  slot;
  stack;
  prefix;
  netID;
};
var item_default = Item;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/clientstate.ts
var ClientState = /* @__PURE__ */ ((ClientState2) => {
  ClientState2[ClientState2["FreshConnection"] = 0] = "FreshConnection";
  ClientState2[ClientState2["FinishinedSendingInventory"] = 1] = "FinishinedSendingInventory";
  ClientState2[ClientState2["ConnectionSwitchEstablished"] = 2] = "ConnectionSwitchEstablished";
  ClientState2[ClientState2["FinalisingSwitch"] = 3] = "FinalisingSwitch";
  ClientState2[ClientState2["FullyConnected"] = 4] = "FullyConnected";
  ClientState2[ClientState2["Disconnected"] = 5] = "Disconnected";
  return ClientState2;
})(ClientState || {});
var clientstate_default = ClientState;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/errorhelper.ts
import * as util from "node:util";
function isRescriptError(e) {
  return e.RE_EXN_ID !== void 0;
}
function toMessage(e) {
  if (e instanceof Error) {
    return e.stack ?? e.message;
  }
  if (isRescriptError(e)) {
    return `Rescript error. ${e.RE_EXN_ID}: ${util.inspect(e._1, { depth: null })}. Error: ${e.Error.stack ?? e.Error.message}`;
  }
  return "Unknown error." + util.inspect(e);
}
var errorhelper_default = {
  toMessage
};

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/disconnectreason.ts
var DisconnectReasonCodes = {
  Blacklisted: "blacklisted",
  BlacklistCheckError: "blacklist_check_error",
  ClientConnectionReset: "client_connection_reset",
  ClientDisconnectedFromDimensions: "client_disconnected_from_dimensions",
  ClientLeftDimension: "client_left_dimension",
  ClientSocketClosed: "client_socket_closed",
  ClientSocketError: "client_socket_error",
  ClientSocketTimeout: "client_socket_timeout",
  ConnectionLimitExceeded: "connection_limit_exceeded",
  ConnectionRateLimitExceeded: "connection_rate_limit_exceeded",
  DimensionSwitch: "dimension_switch",
  DimensionsDisconnectPacket: "dimensions_disconnect_packet",
  NoServersAvailable: "no_servers_available",
  RawSocketDisconnect: "raw_socket_disconnect",
  ServerConnectionRefused: "server_connection_refused",
  ServerConnectionReset: "server_connection_reset",
  ServerDisconnectPacket: "server_disconnect_packet",
  ServerInvalidPacketLength: "server_invalid_packet_length",
  ServerSocketClosed: "server_socket_closed",
  ServerSocketError: "server_socket_error",
  ServerSocketTimeout: "server_socket_timeout"
};
function makeDisconnectReason(code, detail) {
  return {
    code,
    detail: detail.length > 0 ? detail : code
  };
}
function formatDisconnectReason(reason) {
  return `reason: ${reason.code}; detail: ${reason.detail}`;
}
function detailFromDisconnectMessage(reason) {
  if (typeof reason === "string") {
    return reason;
  }
  if (typeof reason === "object" && reason !== null && "text" in reason) {
    const text = reason.text;
    if (typeof text === "string") {
      return text;
    }
  }
  return "Unknown reason";
}
function getErrorCode(error) {
  const code = error.code;
  if (typeof code === "string") {
    return code;
  }
  const match = /\bE[A-Z]+\b/.exec(error.message);
  return match?.[0];
}
function clientSocketErrorReason(error) {
  const code = getErrorCode(error);
  switch (code) {
    case "ECONNRESET":
      return makeDisconnectReason(DisconnectReasonCodes.ClientConnectionReset, `client socket reset: ${error.message}`);
    case "ETIMEDOUT":
      return makeDisconnectReason(DisconnectReasonCodes.ClientSocketTimeout, `client socket timed out: ${error.message}`);
    default:
      return makeDisconnectReason(DisconnectReasonCodes.ClientSocketError, `client socket error: ${error.message}`);
  }
}
function serverSocketErrorReason(error) {
  const code = getErrorCode(error);
  switch (code) {
    case "ECONNREFUSED":
      return makeDisconnectReason(DisconnectReasonCodes.ServerConnectionRefused, `backend socket refused connection: ${error.message}`);
    case "ECONNRESET":
      return makeDisconnectReason(DisconnectReasonCodes.ServerConnectionReset, `backend socket reset: ${error.message}`);
    case "ETIMEDOUT":
      return makeDisconnectReason(DisconnectReasonCodes.ServerSocketTimeout, `backend socket timed out: ${error.message}`);
    default:
      return makeDisconnectReason(DisconnectReasonCodes.ServerSocketError, `backend socket error: ${error.message}`);
  }
}

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/netmodules.ts
var wire326ToParser = /* @__PURE__ */ new Map([[6, 5], [7, 6], [8, 7], [9, 8], [10, 9], [11, 10], [12, 11]]);
var parserToWire326 = new Map([...wire326ToParser].map(([wire2, parser]) => [parser, wire2]));
function parsePacket(data2, fromServer, version, ignored) {
  if (version === "Terraria326" && data2[2] === 82 && data2.length >= 5) {
    const moduleId = data2.readUInt16LE(3);
    if (moduleId === 5) return { TAG: "Error", _0: "IgnoredPacket" };
    const mapped = wire326ToParser.get(moduleId);
    if (mapped !== void 0) {
      data2 = Buffer.from(data2);
      data2.writeUInt16LE(mapped, 3);
    }
  }
  return Parser_exports.parse(data2, fromServer, ignored);
}
function generatedNetModule(data2, version) {
  if (version !== "Terraria326" || data2[2] !== 82 || data2.length < 5) return data2;
  const moduleId = data2.readUInt16LE(3), mapped = parserToWire326.get(moduleId);
  if (moduleId === 12) throw new Error("Terraria 1.4.5.8 \u4E0D\u652F\u6301 TagEffectState \u6A21\u5757");
  if (mapped === void 0) return data2;
  const wire2 = Buffer.from(data2);
  wire2.writeUInt16LE(mapped, 3);
  return wire2;
}

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/terrariaserverpackethandler.ts
var TerrariaServerPacketHandler = class {
  currentServer;
  //private index = 0;
  /**
   * Checks whether the packet was handled by extensions prior to being processed by this class
   *
   * @param server The server object assigned to a player that is sending a packet
   * @param packet The packet that is being sent
   * @return Whether or not the packet was handled (and should not be sent)
   */
  runPriorHandlers(server, packet, source) {
    let handlers = server.client.globalHandlers.extensions;
    let handled = false;
    for (let key in handlers) {
      let handler = handlers[key];
      if (typeof handler.priorPacketHandlers !== "undefined" && typeof handler.priorPacketHandlers.serverHandler !== "undefined") {
        try {
          handled = handler.priorPacketHandlers.serverHandler.handlePacket(server, packet, source);
          if (handled) {
            break;
          }
        } catch (error) {
          if (server.client.options.log.extensionError) {
            const name = handler.name ?? key;
            const logMessage = `[${process.pid}] Extension ${name} Prior Server Packet Handler Error: ${errorhelper_default.toMessage(error)}`;
            server.client.logging.info(logMessage);
          }
        }
      }
    }
    return handled;
  }
  /**
   * Checks whether the packet was handled by extensions after being processed by this class
   *
   * @param server The server object assigned to a player that is sending a packet
   * @param packet The packet that is being sent
   * @return Whether or not the packet was handled (and should not be sent)
   */
  runPostHandlers(server, packet, source) {
    let handlers = server.client.globalHandlers.extensions;
    let handled = false;
    for (let key in handlers) {
      let handler = handlers[key];
      if (typeof handler.postPacketHandlers !== "undefined" && typeof handler.postPacketHandlers.serverHandler !== "undefined") {
        try {
          handled = handler.postPacketHandlers.serverHandler.handlePacket(server, packet, source);
          if (handled) {
            break;
          }
        } catch (error) {
          if (server.client.options.log.extensionError) {
            const name = handler.name ?? key;
            const logMessage = `[${process.pid}] Extension ${name} Post Server Packet Handler Error: ${errorhelper_default.toMessage(error)}`;
            server.client.logging.info(logMessage);
          }
        }
      }
    }
    return handled;
  }
  /**
   * Runs the packet through extension handlers and runs any appropriate handlers of this class
   *
   * @param server The server object assigned to a player that is sending a packet
   * @param packet The packet that is being sent
   * @return The packet data (either origin or modified)
   */
  handlePacket(server, packet, source) {
    this.currentServer = server;
    let priorHandled = this.runPriorHandlers(server, packet, source);
    if (priorHandled) {
      return null;
    }
    const parsedResult = parsePacket(packet.data, true, server.client.version, [
      "TileSectionSend"
    ]);
    let handled = false;
    if (parsedResult.TAG === "Error") {
      const parseError = parsedResult._0;
      if (typeof parseError === "object") {
        switch (parseError.TAG) {
          case "ReaderError":
            if (parseError._0.error instanceof Error) {
              server.client.logging.error(`Error parsing packet: ${parseError._0.context} ${parseError._0.error.message}
${packet.data.toString("hex")}`);
            } else {
              server.client.logging.error(`Error parsing packet: ${parseError._0.context}
${packet.data.toString("hex")}`);
            }
            break;
          default:
            server.client.logging.error(`Error parsing packet: ${packettypes_default[packet.packetType]} ${parseError.TAG}
${packet.data.toString("hex")}`);
            break;
        }
      } else {
        switch (parseError) {
          case "IgnoredPacket":
            server.client.logging.debug(`Ignoring packet: ${packettypes_default[packet.packetType]}`);
            break;
          default:
            server.client.logging.error(`Error parsing packet: ${packettypes_default[packet.packetType]} ${parseError}
${packet.data.toString("hex")}`);
            break;
        }
      }
    } else {
      const parsed = parsedResult._0;
      if (!handled) {
        switch (parsed.TAG) {
          case "TileSectionFrame":
            handled = true;
            break;
          case "Disconnect":
            handled = this.handleDisconnect(parsed._0);
            break;
          case "PlayerSlotSet":
            handled = this.handleContinueConnecting(parsed._0.playerSlotId);
            break;
          case "WorldInfo":
            handled = this.handleWorldInfo(parsed._0);
            break;
          case "PlayerSpawnSelf":
            handled = this.handleCompleteConnectionAndSpawn();
            break;
          case "DimensionsUpdate":
            handled = this.handleDimensionsUpdate(parsed._0);
            break;
          case "NpcUpdate":
            handled = this.handleNPCUpdate(parsed._0);
            break;
          case "ItemDropInstancedUpdate":
            handled = this.handleUpdateItemDrop(parsed._0);
            break;
          case "ItemDropUpdate":
            handled = this.handleUpdateItemDrop(parsed._0);
            break;
          case "PlayerActive":
            handled = this.handlePlayerActive(parsed._0);
            break;
          case "PlayerInventorySlot":
            handled = this.handlePlayerInventorySlot(parsed._0, packet);
            break;
          case "PlayerInfo":
            handled = this.handlePlayerInfo(parsed._0, packet);
            break;
          case "NetModuleLoad":
            handled = this.handleLoadNetModule(parsed._0);
            break;
          default:
            break;
        }
      }
    }
    if (handled) {
      return null;
    }
    let postHandled = this.runPostHandlers(server, packet, source);
    if (postHandled) {
      return null;
    }
    return packet.data;
  }
  /**
   * Passes on the disconnect message as a chat message to the client, unless the client
   * has not fully connected to any Dimension yet.
   *
   * @param packet The disconnect packet
   * @return Whether or not this packet was handled (and should not be sent)
   */
  handleDisconnect(disconnect) {
    const client = this.currentServer.client;
    let reason = new networktext_default(0, "Unknown Reason");
    reason = new networktext_default(disconnect.reason.mode, disconnect.reason.text);
    this.currentServer.setDisconnectReason(makeDisconnectReason(
      DisconnectReasonCodes.ServerDisconnectPacket,
      reason.text
    ));
    if (!client.ingame) {
      client.wasKicked = true;
      client.connected = false;
      client.disconnect(reason);
      if (!this.currentServer.socket.destroyed) {
        this.currentServer.socket.destroy();
      }
      return true;
    } else {
      var color = "C8FF00";
      var message = client.options.language.phrases.dimensionDisconnectedYou;
      const disconnectOnKick = client.options.disconnectOnKick;
      switch (disconnectOnKick.type) {
        case "always":
          client.disconnect(reason);
          return true;
        case "never":
          break;
        case "onKickReasonPrefix":
          for (const prefix of disconnectOnKick.kickReasonPrefixes) {
            if (reason.mode === 0 && reason.text.startsWith(prefix)) {
              client.disconnect(reason.text.substring(prefix.length));
              return true;
            }
          }
          break;
      }
      client.sendChatMessage(message, color);
      client.sendChatMessage(new networktext_default(1, client.options.language.phrases.reason + "{0}", [reason]), color);
      client.wasKicked = true;
      client.connected = false;
      if (!this.currentServer.socket.destroyed) {
        this.currentServer.socket.destroy();
      }
    }
    return true;
  }
  /**
   * Passes on the real IP of the client to the server
   *
   * @param packet The continue connecting packet
   * @return Whether or not this packet was handled (and should not be sent)
   */
  handleContinueConnecting(playerId) {
    this.currentServer.client.player.id = playerId;
    this.currentServer.client.playerIdAssigned = true;
    if (!this.currentServer.isVanilla && !this.currentServer.client.tswebManaged) {
      let ip = getProperIP(this.currentServer.client.socket.remoteAddress);
      const packetData = new packetwriter_default().setType(packettypes_default.DimensionsUpdate).packInt16(0).packString(ip).data;
      this.currentServer.sendDirect(packetData);
    }
    return false;
  }
  /**
   * Restores player data and updates the SSC tracking
   *
   * @param packet The world info packet
   * @return Whether or not this packet was handled (and should not be sent)
   */
  handleWorldInfo(worldInfo2) {
    this.currentServer.isSSC = worldInfo2.eventInfo.serverSidedCharacters;
    if (this.currentServer.client.waitingCharacterRestore && !this.currentServer.isSSC) {
      this.restoreInventory(this.currentServer.client);
      this.restoreLife(this.currentServer.client);
      this.restoreMana(this.currentServer.client);
      this.restoreVisuals(this.currentServer.client);
      this.currentServer.client.player.restoreQuestStats();
    }
    this.currentServer.client.waitingCharacterRestore = false;
    if (this.currentServer.client.state === clientstate_default.ConnectionSwitchEstablished) {
      this.currentServer.spawn.x = worldInfo2.spawnX;
      this.currentServer.spawn.y = worldInfo2.spawnY;
      let getSection = new packetwriter_default().setType(packettypes_default.GetSectionOrRequestSync).packSingle(-1).packSingle(-1).packByte(0).data;
      this.currentServer.sendDirect(getSection);
      this.currentServer.client.state = clientstate_default.FinalisingSwitch;
      if (this.currentServer.client.routingInformation !== null) {
        let dimensionsUpdate = new packetwriter_default().setType(packettypes_default.DimensionsUpdate).packInt16(this.currentServer.client.routingInformation.type).packString(this.currentServer.client.routingInformation.info).data;
        this.currentServer.sendDirect(dimensionsUpdate);
        this.currentServer.client.routingInformation = null;
      }
    }
    return false;
  }
  /**
   * Ensures the player spawns correctly by sending the SpawnPlayer packet
   * that forces them to spawn if they're already in-game (on the world
   *
   * @param _packet The complete connection and spawn packet
   * @return Whether or not the packet has been handled (and is not to be sent)
   */
  handleCompleteConnectionAndSpawn() {
    let server = this.currentServer;
    const completedDimensionSwitch = server.client.state === clientstate_default.FinalisingSwitch;
    if (this.currentServer.client.state === clientstate_default.FinalisingSwitch) {
      this.currentServer.client.state = clientstate_default.FinishinedSendingInventory;
      let spawnPlayer = Packet_PlayerSpawn_exports.toBuffer({
        playerId: this.currentServer.client.player.id,
        x: this.currentServer.spawn.x,
        y: this.currentServer.spawn.y,
        context: "SpawningIntoWorld",
        timeRemaining: 0,
        numberOfDeathsPve: 0,
        numberOfDeathsPvp: 0,
        team: 0
      });
      if (spawnPlayer.TAG === "Error") {
        this.currentServer.client.logging.error(`Error creating spawn player packet: ${spawnPlayer._0}`);
        return true;
      }
      if (typeof server.client !== "undefined" && typeof server.client.socket !== "undefined") {
        server.sendDirect(spawnPlayer._0);
        if (!server.client.preventSpawnOnJoin) {
          server.client.sendDirect(spawnPlayer._0);
        }
      }
    }
    if (server.client.state === clientstate_default.FinishinedSendingInventory) {
      server.client.state = clientstate_default.FullyConnected;
      server.client.sendWaitingPackets();
      server.sendWaitingPackets();
      server.client.sendExtraInformation();
      if (completedDimensionSwitch) {
        this.sendDimensionSwitchPingResponse(server);
      }
      for (let key in server.client.globalHandlers.extensions) {
        const e = server.client.globalHandlers.extensions[key];
        if (e.clientFullyConnectedHandler) {
          try {
            e.clientFullyConnectedHandler(server.client);
          } catch (error) {
            if (server.client.options.log.extensionError) {
              const name = e.name ?? key;
              const logMessage = `[${process.pid}] Extension ${name} Client Fully Connected Handler Error: ${errorhelper_default.toMessage(error)}`;
              server.client.logging.info(logMessage);
            }
          }
        }
      }
    }
    this.currentServer.client.ingame = true;
    return false;
  }
  sendDimensionSwitchPingResponse(server) {
    const ping = Packet_Ping_exports.toBuffer(void 0);
    if (ping.TAG === "Error") {
      server.client.logging.error(`Error creating dimension switch ping packet: ${ping._0}`);
      return;
    }
    const packet = {
      packetType: packettypes_default.Ping,
      data: ping._0
    };
    const processedData = server.getPacketHandler().handlePacket(server, packet, 1 /* Dimensions */);
    if (processedData !== null) {
      server.client.sendDirect(processedData);
    }
  }
  /**
   * Handles the event that a warpplate requests switch of Dimension
   *
   * @param packet The dimensions update packet
   * @return Whether or not the packet has been handled (and is not to be sent)
   */
  handleDimensionsUpdate(dimensionsUpdate) {
    switch (dimensionsUpdate) {
      case "GamemodesJoinMode":
        return true;
      default:
        switch (dimensionsUpdate.TAG) {
          case "RealIpAddress":
            return true;
          case "SwitchServer":
            if (this.currentServer.client.servers[dimensionsUpdate._0.toLowerCase()]) {
              const phrases = this.currentServer.client.options.language.phrases;
              this.currentServer.client.sendChatMessage(phrases.shiftingToDimension.replace("${name}", dimensionsUpdate._0), "FF0000");
              this.currentServer.client.changeServer(this.currentServer.client.servers[dimensionsUpdate._0.toLowerCase()], {
                preventSpawnOnJoin: false
              });
            }
            return true;
          case "SwitchServerManual":
            const currentServerIp = this.currentServer.socket.remoteAddress;
            let ip = dimensionsUpdate._0.ip;
            const port = dimensionsUpdate._0.port;
            if (ip === "127.0.0.1" && typeof currentServerIp !== "undefined") {
              ip = currentServerIp;
            }
            const serverName = dimensionsUpdate._0.serverName ?? `${ip}:${port}`;
            this.currentServer.client.changeServer({
              name: serverName,
              serverIP: ip,
              serverPort: port,
              hidden: false,
              isVanilla: false
            }, {
              preventSpawnOnJoin: false
            });
            return true;
          default:
            return true;
        }
    }
  }
  /**
   * Tracks whether an NPC is alive or not, so it can be cleared when the player switches Dimensions
   *
   * @param packet The NPC Update
   * @return Whether or not the packet has been handled (and is not to be sent)
   */
  handleNPCUpdate(npcUpdate) {
    const { npcSlotId, npcTypeId, life } = npcUpdate;
    let zeroLife = false;
    if (life != "Max") {
      zeroLife = life._0 === 0;
    }
    if (npcTypeId === 0 || zeroLife) {
      this.currentServer.entityTracking.NPCs[npcSlotId] = void 0;
    } else {
      let npc = this.currentServer.entityTracking.NPCs[npcSlotId];
      if (npc === void 0) {
        this.currentServer.entityTracking.NPCs[npcSlotId] = new npc_default(npcSlotId, npcTypeId, life === "Max" ? 1 : life._0);
      } else {
        npc.life = life === "Max" ? 1 : life._0;
        npc.type = npcTypeId;
      }
    }
    return false;
  }
  /**
   * Tracks item drops so they can be cleared when the player switches Dimensions
   *
   * @param packet The update item drop packet
   * @return Whether or not this packet was handled (and should not be sent)
   */
  handleUpdateItemDrop(itemDropUpdate) {
    const { itemDropId, stack, prefix, itemId } = itemDropUpdate;
    if (itemDropId > 0) {
      this.currentServer.entityTracking.items[itemDropId] = new item_default(itemDropId, stack, prefix, itemId);
    } else {
      this.currentServer.entityTracking.items[itemDropId] = void 0;
    }
    return false;
  }
  /**
   * Tracks which players are active so they can be cleared when a player switches Dimensions
   *
   * @param packet The player active packet
   * @return Whether or not this packet was handled (and should not be sent)
   */
  handlePlayerActive(playerActive) {
    let player = void 0;
    if (playerActive.active) {
      player = new player_default(null);
    }
    this.currentServer.entityTracking.players[playerActive.playerId] = player;
    return false;
  }
  /**
   * Holds back slot updates until player is ready to spawn for the first time
   * on the current Dimension
   *
   * @param packet The player inventory slot packet
   */
  handlePlayerInventorySlot(inventorySlot, rawPacket) {
    let handled = false;
    const { playerId } = inventorySlot;
    if (playerId === this.currentServer.client.player.id) {
      if (this.currentServer.client.state !== clientstate_default.FullyConnected) {
        this.currentServer.queuePacketBeforeClientReady(rawPacket);
        handled = true;
      }
    }
    return handled;
  }
  handlePlayerInfo(playerInfo, rawPacket) {
    const nameMismatchesRequireRewrite = this.currentServer.client.options.nameChanges?.mode === "rewrite";
    const isAboutCurrentClient = playerInfo.playerId === this.currentServer.client.player.id;
    const isMismatchedName = this.currentServer.client.player.name !== playerInfo.name;
    const isAllowedToRename = (this.currentServer.client.options.nameChanges?.exclusions.indexOf(this.currentServer.name) ?? -1) > -1;
    if (nameMismatchesRequireRewrite && isAboutCurrentClient && isMismatchedName) {
      if (!isAllowedToRename) {
        const playerInfoPacket = Packet_PlayerInfo_exports.toBuffer({ ...playerInfo, name: this.currentServer.client.player.name });
        if (playerInfoPacket.TAG === "Ok") {
          rawPacket.data = playerInfoPacket._0;
        }
      } else {
        this.currentServer.client.setName(playerInfo.name);
      }
    }
    return false;
  }
  handleLoadNetModule(loadNetModule) {
    switch (loadNetModule.TAG) {
      case "TeleportPylon":
        const value = loadNetModule;
        const { pylonAction, x, y, pylonType } = value._0;
        switch (pylonAction) {
          case "Added":
            if (!this.currentServer.entityTracking.pylons.some((pylon) => pylon.x === x && pylon.y === y && pylon.type === pylonType)) {
              this.currentServer.entityTracking.pylons.push({ x, y, type: pylonType });
            }
            break;
          case "Removed":
            this.currentServer.entityTracking.pylons = this.currentServer.entityTracking.pylons.filter(
              (pylon) => pylon.x !== x || pylon.y !== y || pylon.type !== pylonType
            );
            break;
          case "RequestTeleport":
            break;
        }
        break;
      default:
        break;
    }
    return false;
  }
  /**
   * Sets the players slots back to what they were before they joined the SSC server.
   * Used when a player switches from an SSC server to a non-SSC server
   *
   * @param client Which client is getting its inventory restored
   */
  restoreInventory(client) {
    for (const item of this.currentServer.client.player.inventory) {
      if (typeof item !== "undefined") {
        client.player.setItem(item);
      }
    }
  }
  /**
   * Sets the players life back to what they were before they joined the SSC server.
   * Used when a player switches from an SSC server to a non-SSC server
   *
   * @param client Which client is getting its life restored
   */
  restoreLife(client) {
    client.player.restoreSavedMaxHealth();
  }
  /**
   * Sets the players mana back to what they were before they joined the SSC server.
   * Used when a player switches from an SSC server to a non-SSC server
   *
   * @param client Which client is getting its mana restored
   */
  restoreMana(client) {
    client.player.restoreSavedMaxMana();
  }
  /**
   * Sets the players visuals back to what they were before they joined the SSC server.
   * Used when a player switches from an SSC server to a non-SSC server
   *
   * @param client Which client is getting its visuals restored
   */
  restoreVisuals(client) {
    client.player.setVisuals();
  }
};
var terrariaserverpackethandler_default = TerrariaServerPacketHandler;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/prereadyqueuelimits.ts
var TERRARIA_INVENTORY_SLOTS = 59;
var TERRARIA_ARMOR_SLOTS = 20;
var TERRARIA_DYE_SLOTS = 10;
var TERRARIA_MISC_EQUIP_SLOTS = 5;
var TERRARIA_MISC_DYE_SLOTS = 5;
var TERRARIA_BANK_COUNT = 4;
var TERRARIA_BANK_SLOTS = 40;
var TERRARIA_TRASH_SLOTS = 1;
var TERRARIA_LOADOUT_COUNT = 3;
var TERRARIA_FULL_PLAYER_INVENTORY_PACKETS = TERRARIA_INVENTORY_SLOTS + TERRARIA_ARMOR_SLOTS + TERRARIA_DYE_SLOTS + TERRARIA_MISC_EQUIP_SLOTS + TERRARIA_MISC_DYE_SLOTS + TERRARIA_BANK_COUNT * TERRARIA_BANK_SLOTS + TERRARIA_TRASH_SLOTS + TERRARIA_LOADOUT_COUNT * (TERRARIA_ARMOR_SLOTS + TERRARIA_DYE_SLOTS);
var OBSERVED_PRE_READY_INVENTORY_BURSTS = 5;
var PRE_READY_INVENTORY_BURST_MARGIN = 1;
var MAX_PRE_READY_QUEUE_PACKETS = TERRARIA_FULL_PLAYER_INVENTORY_PACKETS * (OBSERVED_PRE_READY_INVENTORY_BURSTS + PRE_READY_INVENTORY_BURST_MARGIN);
var MAX_PRE_READY_QUEUE_BYTES = 65536;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/terrariaserver.ts
var PRE_READY_QUEUE_LIMIT_REASON = "Backend sent too many packets before client completed connection";
var TerrariaServer = class {
  client;
  socket;
  // Connection Details
  ip;
  port;
  isVanilla;
  // Unique name
  name;
  spawn;
  afterClosed;
  entityTracking;
  isSSC;
  packetQueue;
  bufferPacket;
  packetQueueBytes;
  disconnectReason = null;
  constructor(socket, client) {
    this.socket = socket;
    this.client = client;
    this.reset();
  }
  reset() {
    this.ip = "127.0.0.1";
    this.port = 7777;
    this.isVanilla = false;
    this.name = "";
    this.spawn = {
      x: 0,
      y: 0
    };
    this.bufferPacket = Buffer.allocUnsafe(0);
    this.afterClosed = null;
    this.entityTracking = {
      items: [],
      NPCs: [],
      players: [],
      pylons: []
    };
    this.isSSC = false;
    this.packetQueue = [];
    this.packetQueueBytes = 0;
    this.disconnectReason = null;
  }
  getPacketHandler() {
    return this.client.globalHandlers.terrariaServerPacketHandler;
  }
  /**
   * Sends data if the socket is open, does not invoke any
   * handlers only a send event
   *
   * @param buf
   */
  sendDirect(buf) {
    if (this.socket.writable) {
      if (this.socket.writableLength + buf.length > 8 * 1024 * 1024) {
        this.client.disconnect("\u5B50\u670D\u63A5\u6536\u901F\u5EA6\u8FC7\u6162\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5");
        this.socket.destroy();
        return;
      }
      this.socket.write(buf);
      Object.values(this.client.globalHandlers.extensions).forEach((extension) => {
        if (extension.sendPacketToServerEvent) {
          try {
            extension.sendPacketToServerEvent(this, buf);
          } catch (error) {
            if (this.client.options.log.extensionError) {
              const name = extension.name ?? "unknown";
              const logMessage = `[${process.pid}] Extension ${name} Server Send Packet Event Error: ${errorhelper_default.toMessage(error)}`;
              this.client.logging.info(logMessage);
            }
          }
        }
      });
    }
  }
  /* Handles all data coming from the TerrariaServer */
  handleData(encodedData) {
    const sourceSocket = this.socket;
    const isCurrentConnection = () => this.socket === sourceSocket && !sourceSocket.destroyed && !this.client.disconnecting;
    if (!isCurrentConnection()) return;
    try {
      let bufferPacket = this.bufferPacket;
      let entireData = Buffer.concat([bufferPacket, encodedData]);
      let entireDataInfo = getPacketsFromBuffer(entireData);
      if (entireDataInfo.type === "InvalidPacketLength") {
        this.client.logging.error(`Terraria Server Packet Length Error: Received Packet Length ${entireDataInfo.length}`);
        this.client.sendChatMessage("Disconnected from dimension due to a packet length error. Please try again.");
        this.setDisconnectReason(makeDisconnectReason(
          DisconnectReasonCodes.ServerInvalidPacketLength,
          `backend sent invalid packet length ${entireDataInfo.length}`
        ));
        this.client.disconnectFromServer();
        return;
      }
      this.bufferPacket = entireDataInfo.bufferPacket;
      let allowedPackets = [];
      let packets = entireDataInfo.packets;
      for (const packet of packets) {
        if (!isCurrentConnection()) return;
        try {
          const buf = this.getPacketHandler().handlePacket(this, packet, 0 /* TerrariaServer */);
          if (!isCurrentConnection()) return;
          if (buf !== null) {
            allowedPackets.push(buf);
          }
        } catch (e) {
          if (this.client.options.log.tServerError) {
            this.client.logging.error(`TS handle packet error. PacketType: ${packettypes_default[packet.packetType]} (${packet.packetType}): ${errorhelper_default.toMessage(e)}. Data: ${packet.data.toString("hex")}`);
          }
        }
      }
      if (!isCurrentConnection()) return;
      if (allowedPackets.length > 0) {
        if (!this.client.socket.destroyed && this.client.socket.writable) {
          for (const buf of allowedPackets) {
            if (!isCurrentConnection()) return;
            this.client.sendDirect(buf);
          }
        } else {
          this.setDisconnectReason(makeDisconnectReason(
            DisconnectReasonCodes.ClientDisconnectedFromDimensions,
            "client socket was already closed"
          ));
          this.socket.destroy();
        }
      }
    } catch (e) {
      if (this.client.options.log.tServerError) {
        this.client.logging.error(`TS Handle Data Error: ${errorhelper_default.toMessage(e)}`);
      }
    }
  }
  /* Sends any queued packets from the connection phase to the client */
  sendWaitingPackets() {
    if (!this.socket.destroyed && this.packetQueue.length > 0) {
      for (const packet of this.packetQueue) {
        const packetData = this.getPacketHandler().handlePacket(this, packet.rawPacket, 1 /* Dimensions */);
        if (packetData !== null) {
          this.client.sendDirect(packetData);
        }
      }
      this.packetQueue = [];
      this.packetQueueBytes = 0;
    }
  }
  queuePacketBeforeClientReady(rawPacket) {
    if (this.socket.destroyed || this.client.disconnecting) {
      return false;
    }
    const nextBytes = this.packetQueueBytes + rawPacket.data.length;
    if (this.packetQueue.length >= MAX_PRE_READY_QUEUE_PACKETS || nextBytes > MAX_PRE_READY_QUEUE_BYTES) {
      this.rejectPreReadyPacketQueue();
      return false;
    }
    this.packetQueue.push({
      rawPacket: {
        data: rawPacket.data,
        packetType: rawPacket.packetType
      }
    });
    this.packetQueueBytes = nextBytes;
    return true;
  }
  rejectPreReadyPacketQueue() {
    this.packetQueue = [];
    this.packetQueueBytes = 0;
    this.setDisconnectReason(makeDisconnectReason(
      DisconnectReasonCodes.ServerSocketError,
      PRE_READY_QUEUE_LIMIT_REASON
    ));
    this.client.disconnectFromServer();
  }
  /* Calls all server disconnect pre-handlers from extensions
   * and returns whether the disconnect was handled by them.*/
  handledByPreCloseHandlers() {
    let handlers = this.client.globalHandlers.extensions;
    let handled = false;
    for (let key in handlers) {
      let handler = handlers[key];
      if (typeof handler.serverDisconnectPreHandler !== "undefined") {
        try {
          handled = handler.serverDisconnectPreHandler(this);
          if (handled) {
            break;
          }
        } catch (error) {
          if (this.client.options.log.extensionError) {
            const name = handler.name ?? key;
            const logMessage = `[${process.pid}] Extension ${name} Server Disconnect Pre Handler Error: ${errorhelper_default.toMessage(error)}`;
            this.client.logging.info(logMessage);
          }
        }
      }
    }
    return handled;
  }
  /* Calls all server disconnect handlers from extensions
   * and returns whether the disconnect was handled by them.*/
  handledByCloseHandlers() {
    let handlers = this.client.globalHandlers.extensions;
    let handled = false;
    for (let key in handlers) {
      let handler = handlers[key];
      if (typeof handler.serverDisconnectHandler !== "undefined") {
        try {
          handled = handler.serverDisconnectHandler(this);
          if (handled) {
            break;
          }
        } catch (error) {
          if (this.client.options.log.extensionError) {
            const name = handler.name ?? key;
            const logMessage = `[${process.pid}] Extension ${name} Server Disconnect Handler Error: ${errorhelper_default.toMessage(error)}`;
            this.client.logging.info(logMessage);
          }
        }
      }
    }
    return handled;
  }
  /* Decrements server counts when the socket connection to the TerrariaServer
   * is closed, sends a message to the client and runs any handlers of this
   * event through extensions currently loaded */
  handleClose() {
    this.client.connected = false;
    try {
      if (this.client.countIncremented && this.client.serversDetails[this.name]) {
        this.client.serversDetails[this.name].clientCount--;
        this.client.countIncremented = false;
      }
    } catch (e) {
      if (this.client.options.log.tServerError) {
        this.client.logging.error(`handleClose ERROR: ${errorhelper_default.toMessage(e)}`);
      }
    }
    this.logDisconnect();
    if (this.handledByPreCloseHandlers()) {
      return;
    }
    if (this.client.disconnecting) {
      this.client.state = clientstate_default.Disconnected;
      return;
    }
    if (this.afterClosed !== null) {
      this.afterClosed(this.client);
    } else {
      if (this.handledByCloseHandlers()) {
        return;
      }
      let dimensionsList = "";
      let dimensionNames = Object.keys(this.client.servers);
      for (var i = 0; i < dimensionNames.length; i++) {
        let name = dimensionNames[i];
        let hidden = this.client.servers[name].hidden;
        if (!hidden) {
          dimensionsList += (i > 0 ? ", " : " ") + "/" + dimensionNames[i];
        }
      }
      if (!this.client.wasKicked) {
        this.client.sendChatMessage(this.client.options.language.phrases.dimensionDropped, "00BFFF");
        this.client.sendChatMessage(this.client.options.language.phrases.specifyADimensionToTravel + dimensionsList, "00BFFF");
      } else {
        this.client.sendChatMessage(this.client.options.language.phrases.specifyADimensionToTravel + dimensionsList, "00BFFF");
        this.client.wasKicked = false;
      }
      this.client.state = clientstate_default.Disconnected;
    }
  }
  /* Checks the type of error, if it is because a server is down, the failed connection attempts
   * property is incremented until it reaches 3 at which point it is marked as closed and will not
   * be used by clients.
   *
   * TODO: Handle non-refused errors when the host itself is offline */
  handleError(error) {
    this.setDisconnectReason(serverSocketErrorReason(error));
    let type = error.code;
    if (typeof type !== "string") {
      let matches = / E([A-z]*?) /.exec(error.message);
      type = matches !== null && matches.length > 1 ? matches[1] : "";
    }
    let serverDetails = this.client.serversDetails[this.name];
    if (serverDetails && (type === "ECONNREFUSED" || type === "ETIMEDOUT" || type === "CONNREFUSED" || type === "TIMEDOUT")) {
      if (!serverDetails.disabled && ++serverDetails.failedConnAttempts >= 3) {
        serverDetails.disabled = true;
        serverDetails.disabledTimeout = setTimeout(() => {
          serverDetails.failedConnAttempts = 0;
          serverDetails.disabled = false;
        }, 2e4);
      }
    }
    if (this.client.options.log.tServerError) {
      this.client.logging.error(`TerrariaServer Socket Error: ${errorhelper_default.toMessage(error)}`);
    }
  }
  setDisconnectReason(reason, overwrite = false) {
    if (overwrite || this.disconnectReason === null) {
      this.disconnectReason = reason;
    }
  }
  getDisconnectReason() {
    return this.disconnectReason ?? makeDisconnectReason(
      DisconnectReasonCodes.ServerSocketClosed,
      "backend socket closed"
    );
  }
  getClientCountForLog() {
    const details = this.client.serversDetails[this.name];
    if (!details) {
      return "unknown";
    }
    return Math.max(0, details.clientCount);
  }
  logDisconnect(reason = this.getDisconnectReason()) {
    if (!this.client.options.log.tServerDisconnect) {
      return;
    }
    const ip = getProperIP(this.client.ip || this.client.socket.remoteAddress) ?? "unknown";
    const serverName = this.name || "unknown";
    const clientCount = this.getClientCountForLog();
    const logMessage = `[${process.pid}] Client: ${ip} disconnected from dimension (${formatDisconnectReason(reason)}) ${serverName}: ${clientCount}]`;
    this.client.logging.info(logMessage, {
      disconnectScope: "dimension",
      reasonCode: reason.code,
      reasonDetail: reason.detail,
      clientIp: ip,
      serverName,
      clientCount
    });
  }
};
var terrariaserver_default = TerrariaServer;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/client.ts
import * as Net from "net";

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/clearutils.ts
var ClearUtils = class _ClearUtils {
  static clearPlayers(client) {
    const playerIDs = Object.keys(client.server.entityTracking.players);
    for (var i = 0, len = playerIDs.length; i < len; i++) {
      if (parseInt(playerIDs[i]) === client.player.id)
        continue;
      _ClearUtils.clearPlayer(client, parseInt(playerIDs[i]));
    }
  }
  static clearPlayer(client, playerIndex) {
    const data2 = PacketV1449_PlayerActive_exports.toBuffer({ playerId: playerIndex, active: false });
    if (data2.TAG === "Error") {
      client.logging.error(`Error creating player active packet: ${data2._0}`);
      return;
    }
    const playerActive = { packetType: packettypes_default.PlayerActive, data: data2._0 };
    const playerActivePacket = client.server.getPacketHandler().handlePacket(client.server, playerActive, 1 /* Dimensions */);
    if (playerActivePacket !== null) {
      client.sendDirect(playerActivePacket);
    }
  }
  static clearNPCs(client) {
    for (const npc of client.server.entityTracking.NPCs) {
      if (typeof npc !== "undefined") {
        _ClearUtils.clearNPC(client, npc.index);
      }
    }
  }
  static clearNPC(client, npcIndex) {
    const npc = {
      npcSlotId: npcIndex,
      npcTypeId: 0,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      target: 0,
      directionX: false,
      directionY: false,
      ai: [void 0, void 0, void 0, void 0],
      spriteDirection: false,
      life: {
        TAG: "Byte",
        _0: 0
      },
      releaseOwner: void 0,
      playerCountScale: void 0,
      difficulty: void 0,
      spawnedFromStatue: false,
      spawnNeedsSyncing: false,
      shimmerTransparency: false
    };
    const data2 = Packet_NpcUpdate_exports.toBuffer(npc);
    if (data2.TAG === "Ok") {
      const packet = { packetType: packettypes_default.NPCUpdate, data: data2._0 };
      const finalPacket = client.server.getPacketHandler().handlePacket(client.server, packet, 1 /* Dimensions */);
      if (finalPacket !== null) {
        client.sendDirect(finalPacket);
      }
    }
    client.server.entityTracking.NPCs[npcIndex] = void 0;
  }
  static clearItems(client) {
    for (const item of client.server.entityTracking.items) {
      if (typeof item !== "undefined") {
        _ClearUtils.clearItem(client, item.slot);
      }
    }
  }
  static clearItem(client, itemIndex) {
    const data2 = PacketV1449_ItemDropUpdate_exports.toBuffer({
      itemDropId: itemIndex,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      stack: 0,
      prefix: 0,
      noDelay: 0,
      itemId: 0
    });
    if (data2.TAG === "Error") {
      client.logging.error(`Error creating item drop update packet: ${data2._0}`);
      return;
    }
    const updateItemDrop = {
      data: data2._0,
      packetType: packettypes_default.UpdateItemDrop
    };
    const updateItemDropPacket = client.server.getPacketHandler().handlePacket(client.server, updateItemDrop, 1 /* Dimensions */);
    if (updateItemDropPacket !== null) {
      client.sendDirect(updateItemDropPacket);
    }
  }
  static clearPylons(client) {
    for (const pylon of [...client.server.entityTracking.pylons]) {
      if (typeof pylon !== "undefined") {
        _ClearUtils.clearPylon(client, pylon.x, pylon.y, pylon.type);
      }
    }
  }
  static clearPylon(client, x, y, type) {
    const data2 = Packet_NetModuleLoad_exports.toBuffer({
      TAG: "TeleportPylon",
      _0: {
        pylonAction: "Removed",
        x,
        y,
        pylonType: type
      }
    });
    if (data2.TAG === "Ok") {
      const loadNetModule = {
        data: generatedNetModule(data2._0, client.version),
        packetType: packettypes_default.LoadNetModule
      };
      const loadNetModulePacket = client.server.getPacketHandler().handlePacket(client.server, loadNetModule, 1 /* Dimensions */);
      if (loadNetModulePacket !== null) {
        client.sendDirect(loadNetModulePacket);
      }
    }
  }
  static _godmodePowerDefault = false;
  static _farPlacementRangePowerDefault = true;
  static _spawnRateSliderDefault = 0.5;
  // These packets don't change and only need to be created once
  static _journeyClearPackets = [
    // Per player powers activate before the destination server syncs them
    // when switching dimensions. Therefore, there is a brief moment when
    // they are active. To avoid this situation, they must be set to their
    // default values when switching dimensions
    Packet_NetModuleLoad_exports.toBuffer({
      TAG: "CreativePower",
      _0: {
        TAG: "GodmodePower",
        _0: {
          TAG: "Everyone",
          _0: Array(255).fill(this._godmodePowerDefault)
        }
      }
    }),
    Packet_NetModuleLoad_exports.toBuffer({
      TAG: "CreativePower",
      _0: {
        TAG: "FarPlacementRangePower",
        _0: {
          TAG: "Everyone",
          _0: Array(255).fill(this._farPlacementRangePowerDefault)
        }
      }
    }),
    ...Array.from({ length: 255 }, (_, i) => Packet_NetModuleLoad_exports.toBuffer({
      TAG: "CreativePower",
      _0: {
        TAG: "SpawnRateSliderPerPlayerPower",
        _0: {
          playerId: i,
          value: this._spawnRateSliderDefault
        }
      }
    }))
  ];
  static clearJourneyPowers(client) {
    const packets = [
      ...this._journeyClearPackets,
      Packet_NetModuleLoad_exports.toBuffer({
        TAG: "CreativePower",
        _0: {
          TAG: "GodmodePower",
          _0: {
            TAG: "Player",
            _0: client.player.id,
            _1: this._godmodePowerDefault
          }
        }
      }),
      Packet_NetModuleLoad_exports.toBuffer({
        TAG: "CreativePower",
        _0: {
          TAG: "FarPlacementRangePower",
          _0: {
            TAG: "Player",
            _0: client.player.id,
            _1: this._farPlacementRangePowerDefault
          }
        }
      })
    ];
    for (const buffer of packets) {
      if (buffer.TAG === "Ok") {
        const packet = {
          data: generatedNetModule(buffer._0, client.version),
          packetType: packettypes_default.LoadNetModule
        };
        const processedData = client.server.getPacketHandler().handlePacket(client.server, packet, 1 /* Dimensions */);
        if (processedData !== null) {
          client.sendDirect(processedData);
        }
      }
    }
  }
};
var clearutils_default = ClearUtils;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/tcprtt/types.ts
function unavailableTcpRttSample(error) {
  return {
    available: false,
    rttMicros: null,
    rttMs: null,
    updatedAt: null,
    source: "unavailable",
    error
  };
}

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/client.ts
var PRE_READY_QUEUE_LIMIT_REASON2 = "Connection setup packet queue limit exceeded";
var Client = class _Client {
  static FORCE_DISCONNECT_TIMEOUT_MS = 3e3;
  ID;
  options;
  servers;
  socket;
  ip;
  player;
  globalHandlers;
  server;
  connected;
  state;
  initialConnectionAlreadyCreated;
  ingame;
  disconnecting;
  UUID;
  waitingCharacterRestore;
  wasKicked;
  routingInformation;
  countIncremented;
  serversDetails;
  preventSpawnOnJoin;
  packetQueue;
  logging;
  version;
  tcpRtt;
  clientTcpRtt;
  serverTcpRtt;
  overallTcpRtt;
  playerIdAssigned;
  globalTracking;
  bufferPacket;
  extraJoinInformation;
  disconnectTimeout;
  dimensionsDisconnectReason;
  packetQueueBytes;
  queuedPacketsWhileConnectingBytes;
  // Queued packets while connecting to a server
  queuedPacketsWhileConnecting = [];
  ServerHandleError;
  ServerHandleData;
  ServerHandleClose;
  constructor(args) {
    this.ID = args.id;
    this.options = args.options;
    this.globalTracking = args.globalTracking;
    this.servers = args.servers;
    this.socket = args.socket;
    this.ip = args.socket.remoteAddress;
    this.player = new player_default(this);
    this.globalHandlers = args.globalHandlers;
    this.logging = args.logging;
    this.server = new terrariaserver_default(new Net.Socket(), this);
    this.server.ip = args.server.serverIP;
    this.server.port = args.server.serverPort;
    this.server.name = args.server.name;
    this.server.isVanilla = args.server.isVanilla;
    this.connected = false;
    this.state = clientstate_default.FreshConnection;
    this.bufferPacket = Buffer.allocUnsafe(0);
    this.initialConnectionAlreadyCreated = false;
    this.ingame = false;
    this.disconnecting = false;
    this.UUID = "";
    this.waitingCharacterRestore = false;
    this.wasKicked = false;
    this.routingInformation = null;
    this.countIncremented = false;
    this.serversDetails = args.serversDetails;
    this.preventSpawnOnJoin = false;
    this.ServerHandleError = this.server.handleError.bind(this.server);
    this.ServerHandleData = this.server.handleData.bind(this.server);
    this.ServerHandleClose = this.server.handleClose.bind(this.server);
    this.packetQueue = [];
    this.version = "unknown";
    this.disconnectTimeout = null;
    this.dimensionsDisconnectReason = null;
    this.packetQueueBytes = 0;
    this.queuedPacketsWhileConnectingBytes = 0;
    this.tcpRtt = unavailableTcpRttSample();
    this.clientTcpRtt = this.tcpRtt;
    this.serverTcpRtt = unavailableTcpRttSample();
    this.overallTcpRtt = unavailableTcpRttSample();
    this.playerIdAssigned = false;
  }
  /**
   * Gets the packet handler for this client
   *
   * @return The packet handler
   */
  getPacketHandler() {
    return this.globalHandlers.clientPacketHandler;
  }
  setTcpRttSample(sample) {
    this.tcpRtt = sample;
    this.clientTcpRtt = sample;
  }
  setServerTcpRttSample(sample) {
    this.serverTcpRtt = sample;
  }
  setOverallTcpRttSample(sample) {
    this.overallTcpRtt = sample;
  }
  sendExtraInformation() {
    if (this.extraJoinInformation) {
      this.server.sendDirect(new packetwriter_default().setType(packettypes_default.DimensionsUpdate).packInt16(5).packString(this.extraJoinInformation).data);
    }
  }
  /**
   * Sends the disconnect packet and then closes the socket
   *
   * @param reason The reason for the disconnect
   */
  disconnect(reason) {
    if (this.disconnecting || this.socket.destroyed) {
      return;
    }
    this.setDimensionsDisconnectReason(makeDisconnectReason(
      DisconnectReasonCodes.DimensionsDisconnectPacket,
      detailFromDisconnectMessage(reason)
    ));
    if (typeof reason === "string") {
      reason = new networktext_default(0, reason);
    }
    const disconnect = PacketV1449_Disconnect_exports.toBuffer({
      reason
    });
    switch (disconnect.TAG) {
      case "Ok":
        this.disconnecting = true;
        this.connected = false;
        this.socket.pause();
        this.scheduleForcedDisconnect();
        if (this.socket.writable) {
          const packets = this.getDisconnectPackets(disconnect._0);
          this.socket.end(Buffer.concat(packets));
          for (const packet of packets) {
            this.notifySendPacketToClientEvent(packet);
          }
        } else {
          this.socket.destroy();
        }
        break;
      case "Error":
        this.logging.error(`Error creating disconnect packet: ${disconnect._0}`);
        this.disconnecting = true;
        this.connected = false;
        this.socket.destroy();
        break;
    }
  }
  getDisconnectPackets(disconnectPacket) {
    if (this.ingame) {
      return [disconnectPacket];
    }
    const statusPacket = PacketV1449_Status_exports.toBuffer({
      max: 0,
      text: new networktext_default(0, ""),
      flags: {
        hideStatusTextPercent: true,
        statusTextHasShadows: false,
        runCheckBytes: false
      }
    });
    switch (statusPacket.TAG) {
      case "Ok":
        return [statusPacket._0, disconnectPacket];
      case "Error":
        this.logging.error(`Error creating status clear packet: ${statusPacket._0}`);
        return [disconnectPacket];
    }
  }
  scheduleForcedDisconnect() {
    this.clearForcedDisconnect();
    this.disconnectTimeout = setTimeout(() => {
      if (!this.socket.destroyed) {
        this.socket.destroy();
      }
      this.disconnectTimeout = null;
    }, _Client.FORCE_DISCONNECT_TIMEOUT_MS);
    this.disconnectTimeout.unref?.();
  }
  clearForcedDisconnect() {
    if (this.disconnectTimeout !== null) {
      clearTimeout(this.disconnectTimeout);
      this.disconnectTimeout = null;
    }
  }
  setDimensionsDisconnectReason(reason, overwrite = false) {
    if (overwrite || this.dimensionsDisconnectReason === null) {
      this.dimensionsDisconnectReason = reason;
    }
  }
  getDimensionsDisconnectReason() {
    return this.dimensionsDisconnectReason ?? makeDisconnectReason(
      DisconnectReasonCodes.ClientSocketClosed,
      "client socket closed"
    );
  }
  /**
   * Updates the stored name for this client. Will disconnect them if they try
   * to use a name already in use.
   *
   * @param name The name they are wanting to use
   */
  setName(name) {
    if (this.player.name === name) {
      return;
    }
    if (this.globalTracking.names[name]) {
      this.disconnect(this.options.language.phrases.nameAlreadyOnServer.replace("${name}", name));
      return;
    }
    if (name.length < 2 || name.length > 20) {
      this.disconnect(this.options.language.phrases.characterNameLengthOutOfRange);
      return;
    }
    if (this.player.name !== "") {
      delete this.globalTracking.names[this.player.name];
    }
    this.player.name = name;
    if (name !== "") {
      this.globalTracking.names[name] = true;
    }
  }
  getName() {
    return this.player.name;
  }
  getTrackedPlayerCount() {
    return Object.keys(this.globalTracking.names).length;
  }
  handleDataSend(encodedData) {
    try {
      let bufferPacket = this.bufferPacket;
      let entireData = Buffer.concat([bufferPacket, encodedData]);
      let entireDataInfo = getPacketsFromBuffer(entireData);
      if (entireDataInfo.type === "InvalidPacketLength") {
        this.disconnect(this.options.language.phrases.invalidPacketLength);
        return;
      }
      this.bufferPacket = entireDataInfo.bufferPacket;
      let packets = entireDataInfo.packets;
      if (this.tswebManaged?.isolation?.active) {
        this.tswebManaged.isolation.handle(packets);
        return;
      }
      for (const packet of packets) this.tswebManaged?.onClientPacket?.(packet);
      if (this.initialConnectionAlreadyCreated) {
        if (this.connected || this.state > clientstate_default.FreshConnection) {
          let allowedData = [];
          packets.forEach((packet) => {
            try {
              const buf = this.getPacketHandler().handlePacket(this, packet);
              if (buf !== null) {
                allowedData.push(buf);
              }
            } catch (e) {
              if (this.options.log.clientError) {
                this.logging.error(`Client handle packet error. PacketType: ${packettypes_default[packet.packetType]} (${packet.packetType}): ${errorhelper_default.toMessage(e)}. Data: ${packet.data.toString("hex")}`);
              }
            }
          });
          if (allowedData.length > 0 && this.connected) {
            if (this.server.socket) {
              for (const buf of allowedData) {
                this.server.sendDirect(buf);
              }
            } else {
              this.sendChatMessage(this.options.language.phrases.areYouEvenConnected, "ff0000");
            }
          }
        } else {
          this.queuePacketsWhileConnecting(packets);
        }
      } else {
        if (packets.length === 0) return;
        const greeting = Parser_exports.parse(packets[0].data, false);
        if (greeting.TAG !== "Ok" || greeting._0.TAG !== "ConnectRequest") {
          this.disconnect("\u8BF7\u4F7F\u7528\u6709\u6548\u7684 Terraria \u5BA2\u6237\u7AEF\u8FDE\u63A5");
          return;
        }
        this.version = greeting._0._0.version;
        this.initialConnectionAlreadyCreated = true;
        this.player.allowedCharacterChange = true;
        this.player.allowedLifeChange = true;
        this.player.allowedManaChange = true;
        this.player.allowedNameChange = true;
        this.server.socket.on("data", this.ServerHandleData);
        this.server.socket.on("close", this.ServerHandleClose);
        this.server.socket.on("error", this.ServerHandleError);
        this.server.socket.connect(this.server.port, this.server.ip, () => {
          this.countIncremented = true;
          this.serversDetails[this.server.name].clientCount++;
          this.serversDetails[this.server.name].failedConnAttempts = 0;
          this.connected = true;
          packets.push(...this.queuedPacketsWhileConnecting);
          this.queuedPacketsWhileConnecting = [];
          this.queuedPacketsWhileConnectingBytes = 0;
          let allowedData = [];
          packets.forEach((packet) => {
            const buf = this.getPacketHandler().handlePacket(this, packet);
            if (buf !== null) {
              allowedData.push(buf);
            }
          });
          if (this.options.fakeVersion.enabled) {
            const verText = "Terraria" + this.options.fakeVersion.terrariaVersion;
            let packet = new packetwriter_default().setType(1).packString(verText).data;
            this.server.sendDirect(packet);
          } else {
            if (allowedData.length > 0 && this.connected) {
              if (this.server.socket) {
                for (const buf of allowedData) {
                  this.server.sendDirect(buf);
                }
              } else {
                this.sendChatMessage(this.options.language.phrases.areYouEvenConnected, "ff0000");
              }
            }
          }
        });
      }
    } catch (e) {
      if (this.options.log.clientError) {
        this.logging.error(`Client Handle Send Data Error: ${errorhelper_default.toMessage(e)}`);
      }
    }
  }
  queuePacketsWhileConnecting(packets) {
    for (const packet of packets) {
      const nextBytes = this.queuedPacketsWhileConnectingBytes + packet.data.length;
      if (!this.canQueuePreReadyPacket(this.queuedPacketsWhileConnecting.length, nextBytes)) {
        this.rejectPreReadyPacketQueue();
        return false;
      }
      this.queuedPacketsWhileConnecting.push(packet);
      this.queuedPacketsWhileConnectingBytes = nextBytes;
    }
    return true;
  }
  completeVirtualAdmission() {
    this.initialConnectionAlreadyCreated = true;
    this.packetQueue = [];
    this.packetQueueBytes = 0;
    this.state = clientstate_default.Disconnected;
  }
  queuePacketBeforeFullyConnected(rawPacket) {
    const nextBytes = this.packetQueueBytes + rawPacket.data.length;
    if (!this.canQueuePreReadyPacket(this.packetQueue.length, nextBytes)) {
      this.rejectPreReadyPacketQueue();
      return false;
    }
    this.packetQueue.push({ rawPacket });
    this.packetQueueBytes = nextBytes;
    return true;
  }
  canQueuePreReadyPacket(currentQueueLength, nextBytes) {
    if (this.disconnecting || this.socket.destroyed) {
      return false;
    }
    return currentQueueLength < MAX_PRE_READY_QUEUE_PACKETS && nextBytes <= MAX_PRE_READY_QUEUE_BYTES;
  }
  rejectPreReadyPacketQueue() {
    this.queuedPacketsWhileConnecting = [];
    this.queuedPacketsWhileConnectingBytes = 0;
    this.packetQueue = [];
    this.packetQueueBytes = 0;
    this.disconnect(PRE_READY_QUEUE_LIMIT_REASON2);
  }
  // Useful method for sending a chat message packet to a client */
  sendChatMessage(text, color) {
    if (this.socket.destroyed) {
      return;
    }
    let networkText;
    if (text instanceof networktext_default) {
      networkText = text;
    } else {
      networkText = new networktext_default(0, text);
    }
    if (networkText.text.length > 0) {
      if (typeof color === "undefined") {
        color = "00ff00";
      }
      let colorRgb = {
        R: parseInt(color.substring(0, 2), 16),
        G: parseInt(color.substring(2, 4), 16),
        B: parseInt(color.substring(4, 6), 16)
      };
      let chatMessageData = Packet_NetModuleLoad_exports.toBuffer({
        TAG: "ServerText",
        _0: 255,
        _1: networkText,
        _2: colorRgb
      });
      switch (chatMessageData.TAG) {
        case "Ok":
          const chatMessage = { packetType: packettypes_default.LoadNetModule, data: chatMessageData._0 };
          const chatMessagePacket = this.server.getPacketHandler().handlePacket(this.server, chatMessage, 1 /* Dimensions */);
          if (chatMessagePacket !== null) {
            this.sendDirect(chatMessagePacket);
          }
          break;
        case "Error":
          this.logging.error(`Error creating chat message packet: ${chatMessageData._0}`);
          break;
      }
    }
  }
  /* Sends any queued packets from the connection phase to the server */
  sendWaitingPackets() {
    if (!this.server.socket.destroyed && this.packetQueue.length > 0) {
      for (const packet of this.packetQueue) {
        const data2 = this.globalHandlers.clientPacketHandler.handlePacket(this, packet.rawPacket);
        if (data2 !== null) {
          this.server.sendDirect(data2);
        }
      }
      this.packetQueue = [];
      this.packetQueueBytes = 0;
    }
  }
  sendQueuedPacketsWhileConnecting() {
    if (this.queuedPacketsWhileConnecting.length === 0) {
      return;
    }
    const queuedPackets = this.queuedPacketsWhileConnecting;
    this.queuedPacketsWhileConnecting = [];
    this.queuedPacketsWhileConnectingBytes = 0;
    for (const packet of queuedPackets) {
      try {
        const data2 = this.getPacketHandler().handlePacket(this, packet);
        if (data2 !== null) {
          this.server.sendDirect(data2);
        }
      } catch (e) {
        if (this.options.log.clientError) {
          this.logging.error(`Client handle queued packet error. PacketType: ${packettypes_default[packet.packetType]} (${packet.packetType}): ${errorhelper_default.toMessage(e)}. Data: ${packet.data.toString("hex")}`);
        }
      }
    }
  }
  /* Handles switching from one server to another */
  changeServer(server, options) {
    this.extraJoinInformation = options?.extraJoinInformation;
    clearutils_default.clearPlayers(this);
    clearutils_default.clearNPCs(this);
    clearutils_default.clearItems(this);
    clearutils_default.clearPylons(this);
    clearutils_default.clearJourneyPowers(this);
    let ip = server.serverIP;
    let port = server.serverPort;
    let name = server.name;
    let isVanilla = server.isVanilla;
    if (typeof options !== "undefined" && typeof options.preventSpawnOnJoin !== "undefined") {
      this.preventSpawnOnJoin = options.preventSpawnOnJoin;
    } else {
      this.preventSpawnOnJoin = false;
    }
    this.connected = false;
    this.server.afterClosed = () => {
      this.server.socket.removeListener("data", this.ServerHandleData);
      this.server.socket.removeListener("error", this.ServerHandleError);
      this.server.afterClosed = null;
      this.server.socket.removeListener("close", this.ServerHandleClose);
      this.server.socket = new Net.Socket();
      if (this.server.isSSC) {
        this.waitingCharacterRestore = true;
      } else {
        this.player.allowedCharacterChange = true;
        this.player.allowedLifeChange = true;
        this.player.allowedManaChange = true;
      }
      this.server.reset();
      this.state = clientstate_default.FreshConnection;
      this.server.ip = ip;
      this.server.port = port;
      this.server.name = name;
      this.server.isVanilla = isVanilla;
      this.player.allowedNameChange = true;
      if (this.options.debuffOnSwitch.enabled) {
        for (const debuffId of this.options.debuffOnSwitch.buffTypes) {
          const debuffData = PacketV1449_PlayerBuffAdd_exports.toBuffer({
            playerId: this.player.id,
            buff: debuffId,
            time: 60 * this.options.debuffOnSwitch.debuffTimeInSeconds
          });
          if (debuffData.TAG === "Error") {
            this.logging.error(`Error creating debuff add packet: ${debuffData._0}`);
            return;
          }
          const debuff = {
            data: debuffData._0,
            packetType: packettypes_default.AddPlayerBuff
          };
          const debuffPacket = this.server.getPacketHandler().handlePacket(this.server, debuff, 1 /* Dimensions */);
          if (debuffPacket !== null) {
            this.sendDirect(debuffPacket);
          }
        }
      }
      this.server.socket.on("data", this.ServerHandleData);
      this.server.socket.on("close", this.ServerHandleClose);
      this.server.socket.on("error", this.ServerHandleError);
      this.server.socket.connect(port, ip, () => {
        if (this.options.log.tServerConnect) {
          this.logging.info(`[${process.pid}] TerrariaServer Socket Connection [${ip}:${port}]`);
        }
        this.countIncremented = true;
        if (!this.serversDetails[this.server.name]) {
          this.serversDetails[this.server.name] = { clientCount: 0, failedConnAttempts: 0, disabled: false, disabledTimeout: null };
        }
        this.serversDetails[this.server.name].clientCount++;
        this.serversDetails[this.server.name].failedConnAttempts = 0;
        const verText = this.version;
        var connectPacket = new packetwriter_default().setType(1).packString(verText).data;
        let packet = {
          packetType: packettypes_default.ConnectRequest,
          data: connectPacket
        };
        const allowedData = this.getPacketHandler().handlePacket(this, packet);
        if (allowedData !== null) {
          this.server.sendDirect(packet.data);
        }
        if (typeof options !== "undefined" && typeof options.routingInformation !== "undefined") {
          this.routingInformation = options.routingInformation;
        }
        this.state = this.playerIdAssigned ? clientstate_default.ConnectionSwitchEstablished : clientstate_default.FreshConnection;
        this.connected = true;
        this.sendQueuedPacketsWhileConnecting();
      });
    };
    if (!this.server.socket.destroyed) {
      this.server.setDisconnectReason(makeDisconnectReason(
        DisconnectReasonCodes.DimensionSwitch,
        `switching from ${this.server.name} to ${name}`
      ));
      this.server.socket.destroy();
    } else {
      this.server.afterClosed(this);
    }
  }
  /**
   * Sends data if the socket is open, does not invoke any handlers
   *
   * @param buf
   */
  sendDirect(buf) {
    if (!this.disconnecting && this.socket.writable) {
      if (this.socket.writableLength + buf.length > 8 * 1024 * 1024) {
        this.disconnect("\u8FDE\u63A5\u63A5\u6536\u901F\u5EA6\u8FC7\u6162\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5");
        return;
      }
      this.socket.write(buf);
      this.notifySendPacketToClientEvent(buf);
    }
  }
  notifySendPacketToClientEvent(buf) {
    Object.values(this.globalHandlers.extensions).forEach((extension) => {
      if (extension.sendPacketToClientEvent) {
        try {
          extension.sendPacketToClientEvent(this, buf);
        } catch (error) {
          if (this.options.log.extensionError) {
            const name = extension.name ?? "unknown";
            const logMessage = `[${process.pid}] Extension ${name} Client Send Packet Event Error: ${errorhelper_default.toMessage(error)}`;
            this.logging.info(logMessage);
          }
        }
      }
    });
  }
  disconnectFromServer() {
    this.server.setDisconnectReason(makeDisconnectReason(
      DisconnectReasonCodes.ClientLeftDimension,
      "client left dimension"
    ));
    this.connected = false;
    if (this.countIncremented && this.serversDetails[this.server.name]) {
      this.serversDetails[this.server.name].clientCount--;
      this.countIncremented = false;
    }
    this.server.logDisconnect();
    this.server.socket.destroy();
    this.server.socket.removeListener("data", this.ServerHandleData);
    this.server.socket.removeListener("error", this.ServerHandleError);
    this.server.socket.removeListener("close", this.ServerHandleClose);
  }
  handleError(e) {
    this.setDimensionsDisconnectReason(clientSocketErrorReason(e));
    if (this.options.log.clientError) {
      this.logging.error(`Client Socket Error: ${errorhelper_default.toMessage(e)}`);
    }
  }
  handleClose() {
    this.clearForcedDisconnect();
    if (!this.server.socket.destroyed) {
      this.server.afterClosed = null;
      this.server.setDisconnectReason(makeDisconnectReason(
        DisconnectReasonCodes.ClientDisconnectedFromDimensions,
        "client disconnected from Dimensions"
      ));
      this.server.socket.destroy();
    }
    if (this.getName() !== "") {
      delete this.globalTracking.names[this.getName()];
    }
  }
};
var client_default = Client;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/stringutils.ts
var StringUtils = class {
  static format(raw, ...args) {
    return raw.replace(/{(\d+)}/g, function(match, number) {
      return typeof args[number] != "undefined" ? args[number].toString() : match;
    });
  }
};
var stringutils_default = StringUtils;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/blacklistcheckclient.ts
var MAX_PRE_AUTH_PACKETS = 512;
var MAX_PRE_AUTH_PACKET_BYTES = 64 * 1024;
var MAX_PRE_AUTH_BUFFER_BYTES = 4096;
var EXPECTED_POST_UUID_PACKET_TAGS = /* @__PURE__ */ new Set([
  "PlayerHealth",
  "PlayerMana",
  "PlayerBuffsSet",
  "LoadoutSwitch",
  "PlayerInventorySlot",
  "HostToken",
  "WorldDataRequest",
  "PlayerPlatformInfo"
]);
var BlacklistCheckClient = class {
  constructor(settings) {
    this.settings = settings;
  }
  state = 0 /* WaitingForConnectRequest */;
  name;
  bufferPacket = Buffer.alloc(0);
  packetsReceived = [];
  packetsReceivedBytes = 0;
  clientAcceptedCb;
  clientBlacklistedCb;
  errorCheckingBlacklistCb;
  packetErrorCheckingBlacklistCb;
  socketErrorCb;
  timeoutCb;
  disposed = false;
  setupCallbacks(args) {
    this.clientAcceptedCb = args.clientAcceptedCb;
    this.clientBlacklistedCb = args.clientBlacklistedCb;
    this.errorCheckingBlacklistCb = args.errorCheckingBlacklistCb;
    this.packetErrorCheckingBlacklistCb = args.packetErrorCheckingBlacklistCb;
    this.socketErrorCb = args.socketErrorCb;
    this.timeoutCb = args.timeoutCb;
    this.settings.clientArgs.socket.on("data", this.handleData.bind(this));
    this.settings.clientArgs.socket.on("error", this.handleError.bind(this));
    this.settings.clientArgs.socket.on("timeout", this.handleTimeout.bind(this));
    this.settings.clientArgs.socket.setTimeout(this.settings.clientArgs.options.socketTimeout);
    this.settings.clientArgs.socket.on("close", () => {
      if (this.disposed) {
        return;
      }
      args.disconnectCb();
      this.dispose();
    });
  }
  handleData(data2) {
    if (this.disposed) {
      return;
    }
    let bufferPacket = this.bufferPacket;
    let entireData = Buffer.concat([bufferPacket, data2]);
    let entireDataInfo;
    try {
      entireDataInfo = getPacketsFromBuffer(entireData);
    } catch (error) {
      this.rejectPacket(error instanceof Error ? error : new Error(errorhelper_default.toMessage(error)));
      return;
    }
    if (entireDataInfo.type === "InvalidPacketLength") {
      this.rejectPacket(new Error(`Invalid packet length ${entireDataInfo.length}`));
      return;
    }
    if (entireDataInfo.bufferPacket.length > MAX_PRE_AUTH_BUFFER_BYTES) {
      this.rejectPacket(new Error("Pre-auth packet buffer exceeded maximum size"));
      return;
    }
    this.bufferPacket = entireDataInfo.bufferPacket;
    const packets = entireDataInfo.packets;
    for (const packet of packets) {
      this.handlePacket(packet);
    }
  }
  handlePacket(rawPacket) {
    if (this.disposed) {
      return;
    }
    if (this.runPreHandlers(rawPacket)) {
      return;
    }
    const packetResult = Parser_exports.parseLazy(rawPacket.data, false);
    if (packetResult.TAG === "Error") {
      this.rejectPacket(new Error(`Error parsing packet: ${packetResult._0}`));
      return;
    }
    const packet = packetResult._0;
    switch (packet.TAG) {
      case "ConnectRequest":
        if (this.state !== 0 /* WaitingForConnectRequest */) {
          this.rejectPacket(new Error("Connect request packet received after assigning client ID"));
          return;
        }
        const connectRequestResult = packet._0.VAL();
        if (connectRequestResult.TAG === "Error") {
          this.rejectPacket(new Error("Connect request packet could not be parsed. Error: " + connectRequestResult._0.context));
          return;
        }
        if (!this.queuePreAuthPacket(rawPacket)) {
          return;
        }
        this.state = 1 /* AssignedClientId */;
        this.sendBlacklistCheckSetupPackets();
        break;
      case "PlayerInfo":
        if (this.state !== 1 /* AssignedClientId */) {
          this.rejectPacket(new Error("Client info packet received before connect request"));
          return;
        }
        const playerInfoResult = packet._0.VAL();
        if (playerInfoResult.TAG === "Error") {
          this.rejectPacket(new Error("Client info packet could not be parsed. Error: " + playerInfoResult._0.context));
          return;
        }
        if (!this.queuePreAuthPacket(rawPacket)) {
          return;
        }
        const playerInfo = playerInfoResult._0;
        this.name = playerInfo.name;
        this.state = 2 /* SentPlayerInfo */;
        break;
      case "ClientUuid":
        if (this.state !== 2 /* SentPlayerInfo */) {
          this.rejectPacket(new Error("Client UUID packet received before player info"));
          return;
        }
        const clientUuidResult = packet._0.VAL();
        const ip = getProperIP(this.settings.clientArgs.socket.remoteAddress);
        if (clientUuidResult.TAG === "Error") {
          this.rejectPacket(new Error("Client UUID packet could not be parsed. Error: " + clientUuidResult._0.context));
          return;
        }
        const clientUuid = clientUuidResult._0;
        if (this.name === void 0) {
          this.rejectPacket(new Error("Client name missing"));
          return;
        }
        if (ip === void 0) {
          this.rejectPacket(new Error("Client IP could not be parsed"));
          return;
        }
        if (!this.queuePreAuthPacket(rawPacket)) {
          return;
        }
        this.state = 3 /* SentUuid */;
        this.settings.blacklist.checkInformation(this.name, ip, clientUuid.uuid).then((isBlacklisted) => {
          if (this.disposed) {
            return;
          }
          this.dispose();
          if (isBlacklisted) {
            this.clientBlacklistedCb();
          } else {
            this.clientAcceptedCb(this.bufferPacket, this.packetsReceived);
          }
        }).catch((e) => {
          if (this.disposed) {
            return;
          }
          this.dispose();
          this.errorCheckingBlacklistCb(this.bufferPacket, this.packetsReceived, e);
        });
        break;
      default:
        if (this.state === 3 /* SentUuid */ && EXPECTED_POST_UUID_PACKET_TAGS.has(packet.TAG)) {
          if (!this.queuePreAuthPacket(rawPacket)) {
            return;
          }
          break;
        }
        this.rejectPacket(new Error(`Unexpected packet before blacklist check completed: ${packet.TAG}`));
        return;
    }
    this.runPostHandlers(rawPacket);
  }
  queuePreAuthPacket(rawPacket) {
    if (this.packetsReceived.length >= MAX_PRE_AUTH_PACKETS) {
      this.rejectPacket(new Error("Pre-auth packet count exceeded maximum"));
      return false;
    }
    const nextBytes = this.packetsReceivedBytes + rawPacket.data.length;
    if (nextBytes > MAX_PRE_AUTH_PACKET_BYTES) {
      this.rejectPacket(new Error("Pre-auth packet bytes exceeded maximum"));
      return false;
    }
    this.packetsReceived.push(rawPacket);
    this.packetsReceivedBytes = nextBytes;
    return true;
  }
  rejectPacket(e) {
    if (this.disposed) {
      return;
    }
    this.dispose();
    this.packetErrorCheckingBlacklistCb(e);
  }
  sendBlacklistCheckSetupPackets() {
    this.sendCheckingStatus();
    this.sendPlayerSlotSet();
  }
  sendCheckingStatus() {
    const statusPacket = PacketV1449_Status_exports.toBuffer({
      max: 0,
      text: new networktext_default(0, "Checking access..."),
      flags: {
        hideStatusTextPercent: true,
        statusTextHasShadows: true,
        runCheckBytes: false
      }
    });
    switch (statusPacket.TAG) {
      case "Ok":
        this.writeToSocket(statusPacket._0, "blacklistCheck" /* BlacklistCheck */);
        break;
      case "Error":
        this.settings.clientArgs.logging.error(`Error creating status packet: ${statusPacket._0}`);
        break;
    }
  }
  sendPlayerSlotSet() {
    const playerSlotSetPacket = PacketV1449_PlayerSlotSet_exports.toBuffer({
      playerSlotId: 0,
      serverWantsToRunCheckBytesInClientLoopThread: false
    });
    switch (playerSlotSetPacket.TAG) {
      case "Ok":
        this.writeToSocket(playerSlotSetPacket._0, "blacklistCheckClientSetup" /* BlacklistCheckClientSetup */);
        break;
      case "Error":
        this.settings.clientArgs.logging.error(`Error creating player slot set packet: ${playerSlotSetPacket._0}`);
        break;
    }
  }
  handleError(err) {
    if (this.disposed) {
      return;
    }
    this.dispose();
    this.socketErrorCb(err);
  }
  handleTimeout() {
    if (this.disposed) {
      return;
    }
    this.dispose();
    this.timeoutCb();
  }
  dispose() {
    this.settings.clientArgs.socket.removeAllListeners();
    this.disposed = true;
  }
  getHookContext() {
    let stateString;
    switch (this.state) {
      case 2 /* SentPlayerInfo */:
        stateString = "SentPlayerInfo" /* SentPlayerInfo */;
        break;
      case 3 /* SentUuid */:
        stateString = "SentUuid" /* SentUuid */;
        break;
      default:
        stateString = "AssignedClientId" /* AssignedClientId */;
    }
    return {
      socket: this.settings.clientArgs.socket,
      clientArgs: this.settings.clientArgs,
      state: stateString
    };
  }
  runPreHandlers(packet) {
    const extensions = this.settings.clientArgs.globalHandlers.extensions;
    const context = this.getHookContext();
    for (const key in extensions) {
      const extension = extensions[key];
      if (extension.blacklistCheckPacketPreHandler) {
        try {
          const handled = extension.blacklistCheckPacketPreHandler(context, packet);
          if (handled) {
            return true;
          }
        } catch (error) {
          if (this.settings.clientArgs.options.log.extensionError) {
            const name = extension.name ?? key;
            const logMessage = `[${process.pid}] Extension ${name} BlacklistCheck Pre Handler Error: ${errorhelper_default.toMessage(error)}`;
            this.settings.clientArgs.logging.info(logMessage);
          }
        }
      }
    }
    return false;
  }
  runPostHandlers(packet) {
    const extensions = this.settings.clientArgs.globalHandlers.extensions;
    const context = this.getHookContext();
    for (const key in extensions) {
      const extension = extensions[key];
      if (extension.blacklistCheckPacketPostHandler) {
        try {
          const handled = extension.blacklistCheckPacketPostHandler(context, packet);
          if (handled) {
            return true;
          }
        } catch (error) {
          if (this.settings.clientArgs.options.log.extensionError) {
            const name = extension.name ?? key;
            const logMessage = `[${process.pid}] Extension ${name} BlacklistCheck Post Handler Error: ${errorhelper_default.toMessage(error)}`;
            this.settings.clientArgs.logging.info(logMessage);
          }
        }
      }
    }
    return false;
  }
  writeToSocket(packet, reason) {
    const extensions = this.settings.clientArgs.globalHandlers.extensions;
    const context = {
      socket: this.settings.clientArgs.socket,
      remoteAddress: this.settings.clientArgs.socket.remoteAddress,
      reason,
      clientArgs: this.settings.clientArgs
    };
    const packetWrapper = { packet };
    for (const key in extensions) {
      const extension = extensions[key];
      if (extension.rawSocketWritePreHandler) {
        try {
          const blocked = extension.rawSocketWritePreHandler(context, packetWrapper);
          if (blocked) {
            return;
          }
        } catch (error) {
          if (this.settings.clientArgs.options.log.extensionError) {
            const name = extension.name ?? key;
            const logMessage = `[${process.pid}] Extension ${name} RawSocketWrite Pre Handler Error: ${errorhelper_default.toMessage(error)}`;
            this.settings.clientArgs.logging.info(logMessage);
          }
        }
      }
    }
    this.settings.clientArgs.socket.write(packetWrapper.packet);
    for (const key in extensions) {
      const extension = extensions[key];
      if (extension.rawSocketWritePostHandler) {
        try {
          extension.rawSocketWritePostHandler(context, packetWrapper);
        } catch (error) {
          if (this.settings.clientArgs.options.log.extensionError) {
            const name = extension.name ?? key;
            const logMessage = `[${process.pid}] Extension ${name} RawSocketWrite Post Handler Error: ${errorhelper_default.toMessage(error)}`;
            this.settings.clientArgs.logging.info(logMessage);
          }
        }
      }
    }
  }
};
var blacklistcheckclient_default = BlacklistCheckClient;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/listenserver.ts
var FORCE_SOCKET_CLOSE_TIMEOUT_MS = 3e3;
var ListenServer = class {
  clients;
  /** The clients that are currently being checked for whether they are blacklisted */
  checkingClients;
  servers;
  options;
  port;
  routingServers;
  serversDetails;
  globalHandlers;
  server;
  globalTracking;
  logging;
  blacklist;
  connectionsTracker;
  connectRateTracker;
  tcpRttMonitor;
  limiterInterval = null;
  selectServer;
  ServerHandleError;
  ServerHandleStart;
  constructor(args) {
    this.clients = [];
    this.selectServer = args.selectServer;
    this.checkingClients = [];
    this.servers = args.servers;
    this.options = args.options;
    this.port = args.info.listenPort;
    this.routingServers = args.info.routingServers;
    this.serversDetails = args.serversDetails;
    this.globalHandlers = args.globalHandlers;
    this.globalTracking = args.globalTracking;
    this.logging = args.logging;
    this.blacklist = args.blacklist;
    this.connectionsTracker = args.connectionsTracker;
    this.connectRateTracker = args.connectRateTracker;
    this.tcpRttMonitor = args.tcpRttMonitor;
    for (var i = 0; i < this.routingServers.length; i++) {
      this.serversDetails[this.routingServers[i].name] = {
        clientCount: 0,
        disabled: false,
        disabledTimeout: null,
        failedConnAttempts: 0
      };
    }
    this.ServerHandleError = this.handleError.bind(this);
    this.ServerHandleStart = this.handleStart.bind(this);
    this.server = Net2.createServer();
    this.server.on("connection", (socket) => {
      this.handleSocket(socket).catch((e) => {
        if (this.options.log.clientError) {
          this.logging.error(`Socket Error: ${errorhelper_default.toMessage(e)}`);
        }
      });
    });
    this.server.listen(this.port, args.info.listenHost ?? "0.0.0.0", this.ServerHandleStart);
    this.server.on("error", this.ServerHandleError);
    if (this.options.connectionRateLimit.enabled) {
      this.startConnectionRateLimitTimer();
    }
  }
  startConnectionRateLimitTimer() {
    this.limiterInterval = setInterval(() => {
      this.clearExpiredConnectionRateLimitEntries();
    }, 1e3);
  }
  clearExpiredConnectionRateLimitEntries(now = Date.now()) {
    for (const [ip, entry] of this.connectRateTracker) {
      if (entry.expiresAtMs <= now) {
        this.connectRateTracker.delete(ip);
      }
    }
  }
  /**
   * Finds server with lowest client count
   *
   * @return Either a found routing server or null if one was not found
   */
  chooseServer() {
    if (this.selectServer) return this.selectServer();
    let chosenServer = null;
    let currentClientCount = null;
    let details;
    for (let i = 0; i < this.routingServers.length; i++) {
      details = this.serversDetails[this.routingServers[i].name];
      if (!details.disabled) {
        if (currentClientCount === null || chosenServer === null || details.clientCount < currentClientCount || this.serversDetails[chosenServer.name].disabled) {
          chosenServer = this.routingServers[i];
          currentClientCount = details.clientCount;
        }
      }
    }
    return chosenServer;
  }
  /**
   * Replaces the current blacklist with a new instance
   */
  loadNewBlacklist(blacklist) {
    this.blacklist = blacklist;
  }
  /**
   * Updates this listen server with its new ownership of routing servers
   *
   * @param info The server configuration containing the routing servers for this listen server
   */
  updateInfo(info) {
    this.port = info.listenPort;
    this.routingServers = info.routingServers;
    let details;
    for (let i = 0; i < this.routingServers.length; i++) {
      if (this.serversDetails[this.routingServers[i].name]) {
        details = this.serversDetails[this.routingServers[i].name];
        details.disabled = false;
        details.failedConnAttempts = 0;
      } else {
        this.serversDetails[this.routingServers[i].name] = {
          clientCount: 0,
          disabled: false,
          disabledTimeout: null,
          failedConnAttempts: 0
        };
      }
    }
  }
  /**
   * Destroys all client sockets connected, removing any listeners and resets counts for any servers
   */
  shutdown() {
    this.logging.info(`Server on ${this.port} is now shutting down.`);
    for (let i2 = 0; i2 < this.clients.length; i2++) {
      this.clients[i2].server.socket.removeListener("data", this.clients[i2].ServerHandleData);
      this.clients[i2].server.socket.removeListener("error", this.clients[i2].ServerHandleError);
      this.clients[i2].server.socket.removeListener("close", this.clients[i2].ServerHandleClose);
      this.tcpRttMonitor?.unregister(this.clients[i2]);
      this.clients[i2].disconnect(this.options.language.phrases.close);
    }
    this.clients = [];
    this.server.removeListener("error", this.ServerHandleError);
    this.server.close();
    let details;
    for (var i = 0; i < this.routingServers.length; i++) {
      details = this.serversDetails[this.routingServers[i].name];
      details.clientCount = 0;
    }
    if (this.limiterInterval !== null) {
      clearInterval(this.limiterInterval);
    }
  }
  /**
   * Logs that the server was started
   */
  handleStart() {
    this.logging.info(`Server on ${this.port} started.`);
  }
  /**
   * Writes to a socket with extension hook support.
   * Used for writes that occur before a Client object exists.
   */
  prepareSocketPacketWithHooks(socket, packet, reason, clientArgs) {
    const context = {
      socket,
      remoteAddress: socket.remoteAddress,
      reason,
      clientArgs
    };
    const packetWrapper = { packet };
    for (const extension of Object.values(this.globalHandlers.extensions)) {
      if (extension.rawSocketWritePreHandler) {
        try {
          const blocked = extension.rawSocketWritePreHandler(context, packetWrapper);
          if (blocked) {
            return null;
          }
        } catch (error) {
          if (this.options.log.extensionError) {
            const name = extension.name ?? "unknown";
            const logMessage = `[${process.pid}] Extension ${name} RawSocketWrite Pre Handler Error: ${errorhelper_default.toMessage(error)}`;
            this.logging.info(logMessage);
          }
        }
      }
    }
    return { context, packetWrapper };
  }
  runRawSocketWritePostHandlers(context, packetWrapper) {
    for (const extension of Object.values(this.globalHandlers.extensions)) {
      if (extension.rawSocketWritePostHandler) {
        try {
          extension.rawSocketWritePostHandler(context, packetWrapper);
        } catch (error) {
          if (this.options.log.extensionError) {
            const name = extension.name ?? "unknown";
            const logMessage = `[${process.pid}] Extension ${name} RawSocketWrite Post Handler Error: ${errorhelper_default.toMessage(error)}`;
            this.logging.info(logMessage);
          }
        }
      }
    }
  }
  /**
   * Sends the client the disconnect packet and then drops the connection
   *
   * @param socket The socket to disconnect
   * @param reason The reason to disconnect the client
   */
  disconnectClient(socket, reason, hookReason = "other" /* Other */, disconnectReason = makeDisconnectReason(DisconnectReasonCodes.RawSocketDisconnect, reason)) {
    let kickPacket = PacketV1449_Disconnect_exports.toBuffer({
      reason: new networktext_default(0, reason)
    });
    if (!socket.destroyed) {
      const ip = socket.remoteAddress;
      this.logDimensionsDisconnect(ip, "pre-client", "unknown", disconnectReason);
      switch (kickPacket.TAG) {
        case "Ok":
          const prepared = this.prepareSocketPacketWithHooks(socket, kickPacket._0, hookReason);
          if (prepared === null) {
            socket.destroy();
            return;
          }
          const forceCloseTimeout = setTimeout(() => {
            if (!socket.destroyed) {
              socket.destroy();
            }
          }, FORCE_SOCKET_CLOSE_TIMEOUT_MS);
          forceCloseTimeout.unref?.();
          socket.once("close", () => {
            clearTimeout(forceCloseTimeout);
          });
          if (socket.writable) {
            const packet = this.withPreDisconnectStatusClear(prepared.packetWrapper.packet, hookReason);
            socket.end(packet);
            this.runRawSocketWritePostHandlers(prepared.context, prepared.packetWrapper);
          } else {
            socket.destroy();
          }
          break;
        case "Error":
          this.logging.error(`Error creating disconnect packet: ${kickPacket._0}`);
          socket.destroy();
          break;
      }
    }
  }
  withPreDisconnectStatusClear(packet, hookReason) {
    if (hookReason !== "blacklistCheck" /* BlacklistCheck */) {
      return packet;
    }
    const statusPacket = PacketV1449_Status_exports.toBuffer({
      max: 0,
      text: new networktext_default(0, ""),
      flags: {
        hideStatusTextPercent: true,
        statusTextHasShadows: false,
        runCheckBytes: false
      }
    });
    switch (statusPacket.TAG) {
      case "Ok":
        return Buffer.concat([statusPacket._0, packet]);
      case "Error":
        this.logging.error(`Error creating status clear packet: ${statusPacket._0}`);
        return packet;
    }
  }
  /**
   * Decrements the number of connections in the tracker for a socket's remote address
   *
   * @param socket The socket that is being disconnected
   */
  decrementConnectionTracker(ip) {
    if (this.options.connectionLimit.enabled) {
      const count = this.connectionsTracker.get(ip);
      if (typeof count !== "undefined") {
        if (count === 1) {
          this.connectionsTracker.delete(ip);
        } else {
          this.connectionsTracker.set(ip, count - 1);
        }
      }
    }
  }
  /**
   * Gets a server to connect to for a new socket connection, sets up the appropriate handlers
   * and checks if their IP is blacklisted
   *
   * @param socket The socket of a new client
   */
  async handleSocket(socket) {
    const socketIp = socket.remoteAddress;
    if (this.options.connectionLimit.enabled && this.enforceConnectionLimit(socket)) {
      socket.removeAllListeners();
      return;
    }
    if (this.options.connectionRateLimit.enabled && this.enforceConnectionRateLimit(socket)) {
      if (this.options.connectionLimit.enabled && typeof socketIp !== "undefined") {
        this.decrementConnectionTracker(socketIp);
      }
      socket.removeAllListeners();
      return;
    }
    try {
      for (const extension of Object.values(this.globalHandlers.extensions)) {
        if (extension.socketConnectPreHandler) {
          try {
            const handled = await extension.socketConnectPreHandler(socket);
            if (handled) {
              return;
            }
          } catch (error) {
            if (this.options.log.extensionError) {
              const name = extension.name ?? "unknown";
              const logMessage = `[${process.pid}] Extension ${name} Socket Connect Pre Handler Error: ${errorhelper_default.toMessage(error)}`;
              this.logging.info(logMessage);
            }
          }
        }
      }
    } catch (error) {
      console.log(error);
    }
    this.setupNewSocket(socket);
    for (const extension of Object.values(this.globalHandlers.extensions)) {
      if (extension.socketConnectPostHandler) {
        try {
          extension.socketConnectPostHandler(socket);
        } catch (error) {
          if (this.options.log.extensionError) {
            const name = extension.name ?? "unknown";
            const logMessage = `[${process.pid}] Extension ${name} Socket Connect Post Handler Error: ${errorhelper_default.toMessage(error)}`;
            this.logging.info(logMessage);
          }
        }
      }
    }
  }
  enforceConnectionLimit(socket) {
    let connectionDropped = false;
    const ip = socket.remoteAddress;
    if (typeof ip === "undefined") {
      return connectionDropped;
    }
    const counter = this.connectionsTracker.get(ip);
    if (typeof counter !== "undefined") {
      if (counter + 1 > this.options.connectionLimit.connectionLimitPerIP) {
        this.disconnectClient(
          socket,
          stringutils_default.format(this.options.connectionLimit.kickReason, this.options.connectionLimit.connectionLimitPerIP),
          "connectionLimitExceeded" /* ConnectionLimitExceeded */,
          makeDisconnectReason(
            DisconnectReasonCodes.ConnectionLimitExceeded,
            `connection limit exceeded: ${this.options.connectionLimit.connectionLimitPerIP}`
          )
        );
        connectionDropped = true;
      } else {
        this.connectionsTracker.set(ip, counter + 1);
      }
    } else {
      this.connectionsTracker.set(ip, 1);
    }
    return connectionDropped;
  }
  enforceConnectionRateLimit(socket) {
    let connectionDropped = false;
    const ip = socket.remoteAddress;
    if (typeof ip === "undefined") {
      return connectionDropped;
    }
    const now = Date.now();
    const windowMs = this.options.connectionRateLimit.connectionRateLimitWindowSeconds * 1e3;
    const countLimit = this.options.connectionRateLimit.connectionRateLimitPerIP;
    const countWindow = `${countLimit}/${this.options.connectionRateLimit.connectionRateLimitWindowSeconds}s`;
    const entry = this.connectRateTracker.get(ip);
    if (typeof entry === "undefined" || entry.expiresAtMs <= now) {
      this.connectRateTracker.set(ip, {
        count: 1,
        expiresAtMs: now + windowMs
      });
      return connectionDropped;
    }
    if (entry.count + 1 > countLimit) {
      this.disconnectClient(
        socket,
        this.options.language.phrases.connectionRateLimitExceeded,
        "other" /* Other */,
        makeDisconnectReason(
          DisconnectReasonCodes.ConnectionRateLimitExceeded,
          `connection rate limit exceeded: ${countWindow}`
        )
      );
      connectionDropped = true;
    } else {
      entry.count += 1;
    }
    return connectionDropped;
  }
  /**
   * Checks there is a server available and then sets up listeners and a client object for
   * the socket. Also checking if the ip address of this socket is blacklisted.
   */
  async setupNewSocket(socket) {
    const socketIp = socket.remoteAddress;
    let chosenServer = this.chooseServer();
    if (chosenServer === null) {
      this.logging.warn(`No servers available for ListenServer[Port: ${this.port}]`);
      this.disconnectClient(
        socket,
        this.options.language.phrases.noServersAvailable,
        "other" /* Other */,
        makeDisconnectReason(DisconnectReasonCodes.NoServersAvailable, "no routing servers available")
      );
      if (typeof socketIp !== "undefined") {
        this.decrementConnectionTracker(socketIp);
      }
      return;
    }
    if (this.options.socketNoDelay) {
      socket.setNoDelay(true);
    }
    let clientArgs = {
      id: v4_default(),
      socket,
      server: chosenServer,
      serversDetails: this.serversDetails,
      globalHandlers: this.globalHandlers,
      servers: this.servers,
      options: this.options,
      globalTracking: this.globalTracking,
      logging: this.logging
    };
    if (this.options.blacklist.enabled && this.blacklist) {
      const configuration = this.options.blacklist;
      const client = new blacklistcheckclient_default({
        blacklist: this.blacklist,
        clientArgs
      });
      let preClientConnectionReleased = false;
      const finishBlacklistCheck = (releasePreClientConnection) => {
        const index = this.checkingClients.indexOf(client);
        if (index > -1) {
          this.checkingClients.splice(index, 1);
        }
        if (releasePreClientConnection && !preClientConnectionReleased) {
          preClientConnectionReleased = true;
          if (typeof socketIp !== "undefined") {
            this.decrementConnectionTracker(socketIp);
          }
        }
      };
      client.setupCallbacks({
        clientAcceptedCb: (bufferPacket, packetsReceived) => {
          finishBlacklistCheck(false);
          this.setupNewClient(clientArgs, bufferPacket, packetsReceived);
        },
        clientBlacklistedCb: () => {
          finishBlacklistCheck(true);
          this.kickBlacklisted(clientArgs);
        },
        errorCheckingBlacklistCb: (bufferPacket, packetsReceived, e) => {
          this.logging.error(`Error checking blacklist: ${errorhelper_default.toMessage(e)}`);
          if (configuration.errorPolicy === "DenyJoining") {
            finishBlacklistCheck(true);
            this.disconnectClient(
              socket,
              this.options.language.phrases.blacklistCheckError,
              "blacklistCheck" /* BlacklistCheck */,
              makeDisconnectReason(DisconnectReasonCodes.BlacklistCheckError, errorhelper_default.toMessage(e))
            );
          } else {
            finishBlacklistCheck(false);
            this.setupNewClient(clientArgs, bufferPacket, packetsReceived);
          }
        },
        packetErrorCheckingBlacklistCb: (e) => {
          this.logging.error(`Packet error checking blacklist: ${errorhelper_default.toMessage(e)}`);
          finishBlacklistCheck(true);
          this.disconnectClient(
            socket,
            this.options.language.phrases.blacklistCheckError,
            "blacklistCheck" /* BlacklistCheck */,
            makeDisconnectReason(DisconnectReasonCodes.BlacklistCheckError, errorhelper_default.toMessage(e))
          );
        },
        socketErrorCb: (e) => {
          if (this.options.log.checkingClientError) {
            this.logging.error(`Blacklist check socket error: ${errorhelper_default.toMessage(e)}`);
          }
          finishBlacklistCheck(true);
          socket.destroy();
        },
        timeoutCb: () => {
          if (this.options.log.checkingClientTimeouts) {
            this.logging.warn(`Blacklist check socket timed out: ${getProperIP(socket.remoteAddress) ?? "unknown"}`);
          }
          finishBlacklistCheck(true);
          this.disconnectClient(
            socket,
            this.options.language.phrases.blacklistCheckError,
            "blacklistCheck" /* BlacklistCheck */,
            makeDisconnectReason(DisconnectReasonCodes.ClientSocketTimeout, "blacklist pre-auth socket timed out")
          );
        },
        disconnectCb: () => {
          finishBlacklistCheck(true);
        }
      });
      this.checkingClients.push(client);
    } else {
      this.setupNewClient(clientArgs, void 0, []);
    }
  }
  setupNewClient(clientArgs, bufferPacket, packetsAlreadyReceived) {
    let client = new client_default(clientArgs);
    this.clients.push(client);
    if (this.options.log.clientConnect) {
      this.logging.info(`[Client: ${getProperIP(client.socket.remoteAddress)} connected [${clientArgs.server.name}: ${this.serversDetails[clientArgs.server.name].clientCount + 1}]`);
    }
    this.hookSocketError(client.socket, client);
    this.hookSocketTimeout(client.socket, client);
    this.hookSocketClose(client.socket, client);
    this.extensionClientConnectEvent(client);
    this.hookSocketData(client.socket, client);
    client.handleDataSend(Buffer.concat(packetsAlreadyReceived.map((packet) => packet.data)));
    if (bufferPacket !== void 0) {
      client.handleDataSend(bufferPacket);
    }
    this.tcpRttMonitor?.register(client);
    return client;
  }
  /**
   * Checks the blacklist to see if the ip is blacklisted, and will disconnect the socket if they are
   *
   * @param client The client to check the information against the blacklist
   * @return Whether or not the ip is blacklisted
   */
  kickBlacklisted(client) {
    this.disconnectClient(
      client.socket,
      this.options.language.phrases.blacklisted,
      "blacklistCheck" /* BlacklistCheck */,
      makeDisconnectReason(DisconnectReasonCodes.Blacklisted, "client is blacklisted")
    );
    if (this.options.log.clientBlocked) {
      this.logging.info(`${process.pid}] Client: ${getProperIP(client.socket.remoteAddress)} was blocked from joining.`);
    }
  }
  /**
   * Hook the socket error and pass it into the client object
   *
   * @param socket The socket of the client to listen for errors on
   * @param client The client object associated with the socket
   */
  hookSocketError(socket, client) {
    socket.once("error", (e) => {
      try {
        client.handleError(e);
      } catch (e2) {
        if (this.options.log.clientError) {
          this.logging.error(`handleError Error: ${errorhelper_default.toMessage(e2)}`);
        }
      }
    });
  }
  /**
   *  Simply destroys any sockets that have triggered the timeout
   *
   * @param socket The socket of the client to listen for timeouts on
   * @param client The client object associated with the socket
   */
  hookSocketTimeout(socket, client) {
    socket.once("timeout", () => {
      client.setDimensionsDisconnectReason(makeDisconnectReason(
        DisconnectReasonCodes.ClientSocketTimeout,
        "client socket timed out"
      ));
      if (this.options.log.clientTimeouts) {
        this.logging.warn(`Socket Timeout: ${client.getName()} ${client.ID}`);
      }
      socket.destroy();
    });
  }
  extensionClientConnectEvent(client) {
    for (const extension of Object.values(this.globalHandlers.extensions)) {
      if (extension.clientConnectEvent) {
        try {
          extension.clientConnectEvent(client);
        } catch (error) {
          if (this.options.log.extensionError) {
            const name = extension.name ?? "unknown";
            const logMessage = `[${process.pid}] Extension ${name} Connect Event Error: ${errorhelper_default.toMessage(error)}`;
            this.logging.info(logMessage);
          }
        }
      }
    }
  }
  extensionClientDisconnectEvent(client) {
    for (const extension of Object.values(this.globalHandlers.extensions)) {
      if (extension.clientDisconnectEvent) {
        try {
          extension.clientDisconnectEvent(client);
        } catch (error) {
          if (this.options.log.extensionError) {
            const name = extension.name ?? "unknown";
            const logMessage = `[${process.pid}] Extension ${name} Disconnect Event Error: ${errorhelper_default.toMessage(error)}`;
            this.logging.info(logMessage);
          }
        }
      }
    }
  }
  extensionSocketClosePreHandlers(socket, client) {
    for (const extension of Object.values(this.globalHandlers.extensions)) {
      if (extension.socketClosePreHandler) {
        try {
          const handled = extension.socketClosePreHandler(socket, client);
          if (handled) {
            return true;
          }
        } catch (e) {
          if (this.options.log.extensionError) {
            const name = extension.name ?? "unknown";
            const logMessage = `[${process.pid}] Extension ${name} Disconnect Pre Handler Error: ${errorhelper_default.toMessage(e)}`;
            this.logging.info(logMessage);
          }
        }
      }
    }
    return false;
  }
  extensionSocketClosePostHandlers(socket, client) {
    for (const extension of Object.values(this.globalHandlers.extensions)) {
      if (extension.socketClosePostHandler) {
        try {
          extension.socketClosePostHandler(socket, client);
        } catch (e) {
          if (this.options.log.extensionError) {
            const name = extension.name ?? "unknown";
            const logMessage = `[${process.pid}] Extension ${name} Disconnect Post Handler Error: ${errorhelper_default.toMessage(e)}`;
            this.logging.info(logMessage);
          }
        }
      }
    }
  }
  getClientCountAfterDisconnect(client) {
    const details = this.serversDetails[client.server.name];
    if (!details) {
      return "unknown";
    }
    const pendingDecrement = client.countIncremented ? 1 : 0;
    return Math.max(0, details.clientCount - pendingDecrement);
  }
  logDimensionsDisconnect(ip, serverName, clientCount, reason) {
    if (!this.options.log.clientDisconnect) {
      return;
    }
    const clientIp = getProperIP(ip) ?? "unknown";
    const logMessage = `[${process.pid}] Client: ${clientIp} disconnected from Dimensions (${formatDisconnectReason(reason)}) ${serverName}: ${clientCount}]`;
    this.logging.info(logMessage, {
      disconnectScope: "dimensions",
      reasonCode: reason.code,
      reasonDetail: reason.detail,
      clientIp,
      serverName,
      clientCount
    });
  }
  /**
   * Hook the socket close and pass it into the client object
   *
   * @param socket The socket of the client to listen for closing on
   * @param client The client object associated with the socket
   */
  hookSocketClose(socket, client) {
    socket.once("close", () => {
      if (this.extensionSocketClosePreHandlers(socket, client)) {
        return;
      }
      try {
        const ip = client.ip || socket.remoteAddress;
        if (typeof ip !== "undefined") {
          this.decrementConnectionTracker(ip);
        }
        if (this.options.log.clientDisconnect) {
          const serverName = client.server.name || "unknown";
          this.logDimensionsDisconnect(ip, serverName, this.getClientCountAfterDisconnect(client), client.getDimensionsDisconnectReason());
        }
        this.tcpRttMonitor?.unregister(client);
        client.handleClose();
        for (let i = 0; i < this.clients.length; i++) {
          if (this.clients[i].ID === client.ID) {
            this.clients.splice(i, 1);
            break;
          }
        }
      } catch (e) {
        if (this.options.log.clientError) {
          this.logging.error(`SocketCloseEvent ERROR: ${errorhelper_default.toMessage(e)}`);
        }
      }
      socket.removeAllListeners();
      this.extensionSocketClosePostHandlers(socket, client);
      this.extensionClientDisconnectEvent(client);
    });
  }
  /**
   * Hook the socket data and pass it into the client object
   *
   * @param socket The socket of the client to listen for data on
   * @param client The client object associated with the socket
   */
  hookSocketData(socket, client) {
    socket.on("data", (data2) => {
      try {
        client.handleDataSend(data2);
      } catch (e) {
        if (this.options.log.clientError) {
          this.logging.error(`HandleDataSend ERROR: ${errorhelper_default.toMessage(e)}`);
        }
      }
    });
    socket.setTimeout(this.options.socketTimeout);
  }
  /**
   * Handles when an error event occurs for this listen server
   *
   * @param error The error object containing the error information
   */
  handleError(error) {
    this.logging.error(` Server on ${this.port} encountered an error: ${errorhelper_default.toMessage(error)}.`);
  }
};
var listenserver_default = ListenServer;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/clientpackethandler.ts
var ClientPacketHandler = class {
  currentClient;
  /* Checks whether the packet was handled by extensions prior to being processed by this class */
  runPriorHandlers(client, packet) {
    let handlers = client.globalHandlers.extensions;
    let handled = false;
    for (let key in handlers) {
      let handler = handlers[key];
      if (typeof handler.priorPacketHandlers !== "undefined" && typeof handler.priorPacketHandlers.clientHandler !== "undefined") {
        try {
          handled = handler.priorPacketHandlers.clientHandler.handlePacket(client, packet);
          if (handled) {
            break;
          }
        } catch (error) {
          if (client.options.log.extensionError) {
            const name = handler.name ?? key;
            const logMessage = `[${process.pid}] Extension ${name} Prior Client Packet Handler Error: ${errorhelper_default.toMessage(error)}`;
            client.logging.info(logMessage);
          }
        }
      }
    }
    return handled;
  }
  /* Checks whether the packet was handled by extensions after being processed by this class */
  runPostHandlers(client, packet) {
    let handlers = client.globalHandlers.extensions;
    let handled = false;
    for (let key in handlers) {
      let handler = handlers[key];
      if (typeof handler.postPacketHandlers !== "undefined" && typeof handler.postPacketHandlers.clientHandler !== "undefined") {
        try {
          handled = handler.postPacketHandlers.clientHandler.handlePacket(client, packet);
          if (handled) {
            break;
          }
        } catch (error) {
          if (client.options.log.extensionError) {
            const name = handler.name ?? key;
            const logMessage = `[${process.pid}] Extension ${name} Post Client Packet Handler Error: ${errorhelper_default.toMessage(error)}`;
            client.logging.info(logMessage);
          }
        }
      }
    }
    return handled;
  }
  /* Runs the packet through extension handlers and runs any appropriate handlers of this class */
  handlePacket(client, rawPacket) {
    let priorHandled = this.runPriorHandlers(client, rawPacket);
    if (priorHandled) {
      return null;
    }
    let handled = false;
    const parsedResult = parsePacket(rawPacket.data, false, client.version);
    if (parsedResult.TAG === "Error") {
      const parsed = parsedResult._0;
      if (typeof parsed === "object") {
        switch (parsed.TAG) {
          case "ReaderError":
            if (parsed._0.error instanceof Error) {
              client.logging.error(`Error parsing packet: ${parsed._0.context} ${parsed._0.error.message}
${rawPacket.data.toString("hex")}`);
            } else {
              client.logging.error(`Error parsing packet: ${parsed._0.context}
${rawPacket.data.toString("hex")}`);
            }
            break;
          default:
            client.logging.error(`Error parsing packet: ${parsed.TAG}
${rawPacket.data.toString("hex")}`);
            break;
        }
        return null;
      } else {
        switch (parsed) {
          case "IgnoredPacket":
            client.logging.debug(`Ignoring packet: ${rawPacket.packetType}`);
            break;
          default:
            client.logging.error(`Error parsing packet: ${rawPacket.packetType} ${parsed}
${rawPacket.data.toString("hex")}`);
            return null;
        }
      }
    } else {
      this.currentClient = client;
      const parsed = parsedResult._0;
      switch (parsed.TAG) {
        case "ConnectRequest":
          handled = this.handleConnectRequest(parsed._0);
          break;
        case "PlayerInfo":
          handled = this.handlePlayerInfo(parsed._0, rawPacket);
          break;
        case "PlayerBuffsSet":
          handled = this.handleUpdatePlayerBuff(parsed._0, rawPacket);
          break;
        case "PlayerBuffAdd":
          handled = this.handleAddPlayerBuff(parsed._0);
          break;
        case "PlayerInventorySlot":
          handled = this.handlePlayerInventorySlot(parsed._0);
          break;
        case "AnglerQuestsCompletedAmount":
          if (this.cacheLocalCharacter() && parsed._0.playerId === client.player.id) {
            client.player.questStats = { anglerQuestsFinished: parsed._0.anglerQuestsFinished, golferScoreAccumulated: parsed._0.golferScoreAccumulated };
          }
          break;
        case "PlayerMana":
          handled = this.handlePlayerMana(parsed._0);
          break;
        case "PlayerHealth":
          handled = this.handlePlayerHP(parsed._0, rawPacket);
          break;
        case "PlayerUpdate":
          handled = this.handleUpdatePlayer(parsed._0, rawPacket);
          break;
        case "ItemDropUpdate":
          handled = this.handleUpdateItemDrop(parsed._0, rawPacket);
          break;
        case "ItemOwner":
          handled = this.handleUpdateItemOwner(parsed._0, rawPacket);
          break;
        case "WorldDataRequest":
          if (this.currentClient.state === clientstate_default.FreshConnection) {
            this.currentClient.state = clientstate_default.FinishinedSendingInventory;
          }
          break;
        case "PlayerSpawn":
          handled = this.handleSpawnPlayer(parsed._0);
          break;
        case "NetModuleLoad":
          handled = this.handleLoadNetModule(parsed._0);
          break;
        case "DimensionsUpdate":
          handled = true;
          break;
        case "ClientUuid":
          handled = this.handleClientUUID(parsed._0);
          break;
        case "PlayerStealth":
        case "PlayerDamage":
        case "Zones":
        case "NpcTalk":
        case "NpcNameUpdate":
          handled = this.handlePotentialEarlyPacket(rawPacket);
          break;
      }
    }
    if (handled) {
      return null;
    }
    let postHandled = this.runPostHandlers(client, rawPacket);
    if (postHandled) {
      return null;
    }
    return rawPacket.data;
  }
  handleConnectRequest(connectRequest) {
    if (this.currentClient.version === "unknown") {
      this.currentClient.version = connectRequest?.version ?? "unknown";
    }
    return false;
  }
  /* Updates tracked visuals for player to restore them when they switch from
   * an SSC to a non-SSC server */
  handlePlayerInfo(playerInfo, rawPacket) {
    const player = this.currentClient.player;
    if (player.name !== playerInfo.name) {
      if (player.allowedNameChange) {
        this.currentClient.setName(playerInfo.name);
      } else if (this.currentClient.options.nameChanges?.mode === "rewrite") {
        const data2 = Packet_PlayerInfo_exports.toBuffer({ ...playerInfo, playerId: this.currentClient.player.id, name: player.name });
        if (data2.TAG === "Ok") {
          rawPacket.data = data2._0;
        }
      }
    }
    if (player.allowedCharacterChange) {
      player.skinVariant = playerInfo.skinVariant;
      player.hair = playerInfo.hair;
      player.hairDye = playerInfo.hairDye;
      player.hideVisuals = playerInfo.hideVisuals;
      player.hideVisuals2 = playerInfo.hideVisuals2;
      player.hideMisc = playerInfo.hideMisc;
      player.hairColor = playerInfo.hairColor;
      player.skinColor = playerInfo.skinColor;
      player.eyeColor = playerInfo.eyeColor;
      player.shirtColor = playerInfo.shirtColor;
      player.underShirtColor = playerInfo.underShirtColor;
      player.pantsColor = playerInfo.pantsColor;
      player.shoeColor = playerInfo.shoeColor;
      player.difficulty = playerInfo.difficulty;
      player.voiceVariant = playerInfo.voiceVariant;
      player.voicePitchOffset = playerInfo.voicePitchOffset;
      player.allowedCharacterChange = false;
    }
    return false;
  }
  /* Used to prevent invisibility buff from being sent to the server
   * for used when the config is set to blockInvis = true */
  handleUpdatePlayerBuff(playerBuffsSet, rawPacket) {
    let shouldBlockInvis = false;
    const blockInvis = this.currentClient.options.blockInvis;
    switch (blockInvis) {
      case true:
        shouldBlockInvis = true;
        break;
      case false:
        break;
      default:
        shouldBlockInvis = blockInvis.enabled && blockInvis.servers.some((server) => server.toLowerCase() === this.currentClient.server.name.toLowerCase());
        break;
    }
    if (shouldBlockInvis) {
      const buffs = playerBuffsSet.buffs.map((buff) => {
        if (buff === 10) {
          return 0;
        }
        return buff;
      });
      const buf = Packet_PlayerBuffsSet_exports.toBuffer({ playerId: this.currentClient.player.id, buffs });
      if (buf.TAG === "Error") {
        this.currentClient.logging.error(`Error creating player buffs set: ${buf._0}`);
        return true;
      }
      rawPacket.data = buf._0;
    }
    if (this.currentClient.state !== clientstate_default.FullyConnected) {
      this.currentClient.queuePacketBeforeFullyConnected(rawPacket);
      return true;
    }
    return false;
  }
  /* Used to prevent invisibility buff from being sent to the server
   * for used when the config is set to blockInvis = true */
  handleAddPlayerBuff(playerBuffAdd) {
    let shouldBlockInvis = false;
    const blockInvis = this.currentClient.options.blockInvis;
    switch (blockInvis) {
      case true:
        shouldBlockInvis = true;
        break;
      case false:
        break;
      default:
        shouldBlockInvis = blockInvis.enabled && blockInvis.servers.some((server) => server.toLowerCase() === this.currentClient.server.name.toLowerCase());
        break;
    }
    if (shouldBlockInvis) {
      return playerBuffAdd.buff === 10;
    } else {
      return false;
    }
  }
  /* Tracks the players inventory slots to restore them when they switch
   * from an SSC server to a Non-SSC server */
  handlePlayerInventorySlot(playerInventorySlot) {
    if (this.cacheLocalCharacter() && playerInventorySlot.playerId === this.currentClient.player.id) {
      const { slot, stack, prefix, itemType, favorited, blocked } = playerInventorySlot;
      if (slot >= 0 && slot < 512) this.currentClient.player.inventory[slot] = new item_default(slot, stack, prefix, itemType, favorited, blocked);
    }
    return false;
  }
  cacheLocalCharacter() {
    return !this.currentClient.waitingCharacterRestore && (this.currentClient.state === clientstate_default.FreshConnection || this.currentClient.state === clientstate_default.FullyConnected && !this.currentClient.server.isSSC);
  }
  /* Tracks the player mana to restore it when they switch from an
   * SSC server to a Non-SSC server */
  handlePlayerMana(playerMana) {
    if (!this.currentClient.player.allowedManaChange)
      return false;
    const { maxMana } = playerMana;
    this.currentClient.player.mana = maxMana;
    this.currentClient.player.allowedManaChange = false;
    return false;
  }
  /* Tracks the player HP to restore it when they switch from an
   * SSC server to a Non-SSC server */
  handlePlayerHP(playerHealth, rawPacket) {
    if (!this.currentClient.player.allowedLifeChange) {
      return false;
    }
    const { maxHealth } = playerHealth;
    this.currentClient.player.life = maxHealth;
    this.currentClient.player.allowedLifeChange = false;
    if (this.currentClient.state !== clientstate_default.FullyConnected) {
      this.currentClient.queuePacketBeforeFullyConnected(rawPacket);
      return true;
    }
    return false;
  }
  handleUpdatePlayer(_playerUpdate, rawPacket) {
    if (this.currentClient.state !== clientstate_default.FullyConnected) {
      this.currentClient.queuePacketBeforeFullyConnected(rawPacket);
      return true;
    }
    return false;
  }
  /* Prevents the player sending the item drop packet too early
   * which causes them to be kicked. It also adds it to the packet queue
   * so that it may be sent when the client has fully connected (and wont
   * get kicked for sending it) */
  handleUpdateItemDrop(_itemDropUpdate, rawPacket) {
    if (this.currentClient.state !== clientstate_default.FullyConnected) {
      this.currentClient.queuePacketBeforeFullyConnected(rawPacket);
      return true;
    }
    return false;
  }
  /* Prevents the player sending the item owner packet too early
   * which causes them to be kicked. It also adds it to the packet queue
   * so that it may be sent when the client has fully connected (and wont
   * get kicked for sending it)
   *
   * Note: This packet is important for tShock SSC to work. If this was
   *       prevented outright, SSC would be broken (inventory would be unchangable) */
  handleUpdateItemOwner(_itemOwner, rawPacket) {
    if (this.currentClient.state !== clientstate_default.FullyConnected) {
      this.currentClient.queuePacketBeforeFullyConnected(rawPacket);
      return true;
    }
    return false;
  }
  handleSpawnPlayer(_playerSpawn) {
    if (this.currentClient.state === clientstate_default.FinishinedSendingInventory) {
      this.currentClient.state = clientstate_default.FullyConnected;
    }
    return false;
  }
  /* Handles when a net module update is sent from the client (used only for chat at this time) */
  handleLoadNetModule(netModuleLoad) {
    let handled = false;
    switch (netModuleLoad?.TAG) {
      case "ClientText":
        handled = this.handleChatMessage(netModuleLoad._1);
        break;
    }
    return handled;
  }
  /* Handles any commands sent by the client given they start with "/" */
  handleChatMessage(chatMessage) {
    let handled = false;
    if (chatMessage.length > 1 && chatMessage.substr(0, 1) === "/") {
      let command = this.currentClient.globalHandlers.command.parseCommand(chatMessage);
      handled = this.currentClient.globalHandlers.command.handle(command, this.currentClient);
    }
    return handled;
  }
  /* Updates the clients current tracked UUID */
  handleClientUUID(clientUuid) {
    this.currentClient.UUID = clientUuid.uuid;
    return false;
  }
  /* Some packets should not be sent early to avoid kick for invalid operation at this state */
  handlePotentialEarlyPacket(packet) {
    if (this.currentClient.state !== clientstate_default.FullyConnected) {
      this.currentClient.queuePacketBeforeFullyConnected({
        data: packet.data,
        packetType: packet.packetType
      });
      return true;
    }
    return false;
  }
};
var clientpackethandler_default = ClientPacketHandler;

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/upstream/dimensions/language.ts
var chinese = {
  englishName: "Chinese",
  name: "\u6C49\u8BED",
  isoCode: "zn",
  phrases: {
    nameAlreadyOnServer: "${name} \u5DF2\u7ECF\u8FDB\u5165\u4E86\u670D\u52A1\u5668",
    characterNameLengthOutOfRange: "\u6635\u79F0\u957F\u5EA6\u5FC5\u987B\u57282\u81F320\u4E2A\u5B57\u7B26\u4E4B\u95F4",
    areYouEvenConnected: "\u8BF7\u786E\u4FDD\u4F60\u5DF2\u7ECF\u8FDE\u63A5",
    youAreAlreadyInthatDimension: "\u4F60\u5DF2\u7ECF\u8FDB\u5165\u4E86\u90A3\u4E2A\u4E16\u754C",
    shiftingToDimension: "\u6B63\u5728\u4F20\u9001\u5230 ${name}",
    youNeedToWaitUntilConnected: "\u8BF7\u7B49\u5F85\u4F20\u9001",
    playerCount: "\u5F53\u524D\u5171\u6709 ${total} \u540D\u73A9\u5BB6\u5728\u7EBF",
    availableDimensions: "\u53EF\u4F20\u9001\u7684\u4E16\u754C: ",
    youEnteredTheVoid: "\u4F60\u5DF2\u65AD\u7EBF\uFF0C\u5373\u5C06\u88AB\u8E22\u51FA\u4E16\u754C",
    dimensionDisconnectedYou: "\u4F60\u5DF2\u4E0E\u5F53\u524D\u4E16\u754C\u65AD\u5F00\u8FDE\u63A5",
    reason: "\u539F\u56E0:: ",
    dimensionsCommandName: "\u4E16\u754C",
    specifyADimensionToTravel: "\u8BF7\u9009\u62E9\u9700\u8981\u4F20\u9001\u7684[c/FF00CC:\u4E16\u754C]\uFF1A",
    dimensionDropped: "\u4F60\u6240\u5728\u7684\u4E16\u754C\u5DF2\u4E0E\u60A8\u65AD\u5F00\u8FDE\u63A5",
    blacklisted: "\u60A8\u5DF2\u88AB\u670D\u52A1\u5668\u5217\u5165\u9ED1\u540D\u5355\u3002",
    blacklistCheckError: "\u68C0\u67E5\u60A8\u662F\u5426\u88AB\u5217\u5165\u9ED1\u540D\u5355\u65F6\u51FA\u73B0\u9519\u8BEF\u3002",
    // TODO: This is google translated, should be reviewed by native speaker
    invalidPacketLength: "\u5BA2\u6237\u7AEF\u8FDD\u53CD\u534F\u8BAE\uFF1A\u6570\u636E\u5305\u957F\u5EA6\u65E0\u6548\u3002",
    // TODO: This is google translated, should be reviewed by native speaker
    close: "\u670D\u52A1\u5668\u6B63\u5728\u91CD\u65B0\u542F\u52A8\u3002 \u8BF7\u91CD\u65B0\u52A0\u5165\u3002",
    // TODO: This is google translated, should be reviewed by native speaker
    connectionRateLimitExceeded: "\u8FDE\u63A5\u8BF7\u6C42\u8FC7\u4E8E\u9891\u7E41\u3002\u8BF7\u7A0D\u5019\u518D\u8BD5\u3002",
    // TODO: This is google translated, should be reviewed by native speaker
    noServersAvailable: "\u5F53\u524D\u6CA1\u6709\u53EF\u7528\u7684\u670D\u52A1\u5668\u3002\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    // TODO: This is google translated, should be reviewed by native speaker
    currentTcpRtt: "\u5F53\u524D TCP RTT\uFF1A${clientRtt}\uFF08\u4EE3\u7406\uFF09\uFF0C${serverRtt}\uFF08\u670D\u52A1\u5668\uFF09\uFF0C${overallRtt}\uFF08\u603B\u8BA1\uFF09\u3002",
    // TODO: This is google translated, should be reviewed by native speaker
    tcpRttUnavailable: "\u5F53\u524D\u65E0\u6CD5\u83B7\u53D6 TCP RTT\u3002"
  }
};

// tmp/market-local-init-r10-snapshot/plugins/dimensions/runtime/spawn-attempt.mjs
var SpawnAttempt = class {
  constructor(id, targetId, now = Date.now(), confirmationAmbiguous = false) {
    this.id = id;
    this.targetId = targetId;
    this.startedAt = now;
    this.worldDataSeen = false;
    this.tileSections = 0;
    this.playerSpawnSelfSeen = false;
    this.c2sSpawnConfirmed = false;
    this.result = "connecting";
    this.switchMs = null;
    this.confirmationAmbiguous = confirmationAmbiguous;
  }
  observeServer(type) {
    if (!["connecting", "original_spawn_unconfirmed"].includes(this.result) || this.expired) return;
    if (type === 7) this.worldDataSeen = true;
    if (type === 10) this.tileSections++;
    if (type === 49) {
      this.playerSpawnSelfSeen = true;
      this.result = "original_spawn_unconfirmed";
    }
  }
  observeClient(spawn, playerId, now = Date.now()) {
    if (this.confirmationAmbiguous || this.expired || this.result === "completed" || !this.worldDataSeen || this.tileSections < 1 || !this.playerSpawnSelfSeen || spawn?.playerId !== playerId || spawn.context !== "SpawningIntoWorld") return false;
    this.c2sSpawnConfirmed = true;
    this.result = "completed";
    this.switchMs = now - this.startedAt;
    return true;
  }
  finish(result) {
    if (this.result === "completed" || this.expired) return;
    this.result = result;
    this.expired = true;
    this.switchMs = Date.now() - this.startedAt;
  }
  snapshot() {
    return { id: this.id, targetId: this.targetId, startedAt: this.startedAt, mapReady: this.worldDataSeen && this.tileSections > 0, tileSections: this.tileSections, playerSpawnSelfSeen: this.playerSpawnSelfSeen, c2sSpawnConfirmed: this.c2sSpawnConfirmed, confirmationAmbiguous: this.confirmationAmbiguous, result: this.result, switchMs: this.switchMs };
  }
};

// tmp/market-local-init-r10-snapshot/plugins/dimensions/runtime/routing.mjs
var EntryRouter = class {
  scores = /* @__PURE__ */ new Map();
  snapshots = /* @__PURE__ */ new Map();
  update(rows) {
    for (const row of rows) {
      if (!Number.isSafeInteger(row.online) || row.online < 0 || !Array.isArray(row.sessions)) continue;
      this.snapshots.set(row.id, { online: row.online, sessions: new Set(row.sessions), at: Number.isSafeInteger(row.checkedAt) ? Math.min(Date.now(), row.checkedAt) : Date.now() });
    }
  }
  count(row, clients) {
    const snapshot = this.snapshots.get(row.id);
    const reservations = [...clients.values()].filter((c) => !c.socket.destroyed && (c.tswebManaged?.targetId ? c.tswebManaged.targetId === row.id : c.server.name === row.command) && !snapshot?.sessions.has(c.ID)).length;
    return (snapshot?.online ?? 0) + reservations;
  }
  choose(config, clients, excluded = /* @__PURE__ */ new Set()) {
    const rows = config.targets.filter((t) => t.enabled && t.entry && !excluded.has(t.id) && (!config.requirePopulation || Date.now() - (this.snapshots.get(t.id)?.at ?? 0) < 15e3));
    if (!rows.length) return null;
    if (config.routingMode !== "weight") {
      const free = rows.find((row) => this.count(row, clients) < (row.distributionValue ?? 10));
      if (free) return free;
    }
    let winner = rows[0], total = 0;
    for (const row of rows) {
      const weight = row.distributionValue ?? 10;
      total += weight;
      this.scores.set(row.id, (this.scores.get(row.id) ?? 0) + weight);
      if (this.scores.get(row.id) > this.scores.get(winner.id)) winner = row;
    }
    this.scores.set(winner.id, this.scores.get(winner.id) - total);
    for (const id of this.scores.keys()) if (!rows.some((row) => row.id === id)) this.scores.delete(id);
    return winner;
  }
};

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/captcha.ts
import { randomInt } from "node:crypto";
import { deflateRawSync as deflateRawSync2 } from "node:zlib";
var TIMEOUT = 2e4;
var WIDTH = 8400;
var HEIGHT = 2400;
var SPAWN_X = 4200;
var SPAWN_Y = 248;
var FLOOR_Y = 250;
var SECTION_X = 18;
var SECTION_COLUMNS = 6;
var SECTION_ROWS = 4;
var captchaRoute = { name: "__captcha__", serverIP: "127.0.0.1", serverPort: 0, isVanilla: false, hidden: true };
function frame(type, data2) {
  const packet = Buffer.alloc(data2.length + 3);
  packet.writeUInt16LE(packet.length);
  packet[2] = type;
  data2.copy(packet, 3);
  return packet;
}
function worldInfo(spawnX = SPAWN_X, spawnY = SPAWN_Y) {
  const fields = `time dayAndMoonInfo moonPhase maxTilesX maxTilesY spawnX spawnY worldSurface rockLayer worldId gameMode moonType treeBackground treeBackground2 treeBackground3 treeBackground4 corruptionBackground jungleBackground snowBackground hallowBackground crimsonBackground desertBackground oceanBackground mushroomBackground underworldBackground iceBackStyle jungleBackStyle hellBackStyle windSpeedSet cloudNumber tree1 tree2 tree3 treeStyle1 treeStyle2 treeStyle3 treeStyle4 caveBack1 caveBack2 caveBack3 caveBackStyle1 caveBackStyle2 caveBackStyle3 caveBackStyle4 forest1TreeTopStyle forest2TreeTopStyle forest3TreeTopStyle forest4TreeTopStyle corruptionTreeTopStyle jungleTreeTopStyle snowTreeTopStyle hallowTreeTopStyle crimsonTreeTopStyle desertTreeTopStyle oceanTreeTopStyle glowingMushroomTreeTopStyle underworldTreeTopStyle rain sundialCooldown moondialCooldown copperOreTier ironOreTier silverOreTier goldOreTier cobaltOreTier mythrilOreTier adamantiteOreTier invasionType sandstormSeverity`.split(" ");
  const result = Packet_WorldInfo_exports.toBuffer({
    ...Object.fromEntries(fields.map((key) => [key, 0])),
    time: 27e3,
    dayAndMoonInfo: 1,
    maxTilesX: WIDTH,
    maxTilesY: HEIGHT,
    spawnX,
    spawnY,
    worldSurface: Math.max(300, spawnY + 50),
    rockLayer: Math.max(400, spawnY + 150),
    worldId: 2147483e3,
    worldName: "\u7EF4\u5EA6 \xB7 \u5165\u670D\u9A8C\u8BC1",
    gameMode: 0,
    worldUniqueId: [84, 83, 87, 101, 98, 67, 97, 112, 116, 99, 104, 97, 0, 0, 0, 1],
    worldGeneratorVersion: 0n,
    lobbyId: 0n,
    eventInfo: {},
    lowTiles: false,
    extraSpawnPoints: []
  });
  if (result.TAG !== "Ok") throw new Error("\u65E0\u6CD5\u521B\u5EFA\u9694\u79BB\u9A8C\u8BC1\u4E16\u754C");
  return result._0;
}
function section(x, y) {
  const header = Buffer.alloc(12);
  header.writeInt32LE(x);
  header.writeInt32LE(y, 4);
  header.writeInt16LE(200, 8);
  header.writeInt16LE(150, 10);
  const tiles = [];
  for (let row = y; row < y + 150; row++) {
    tiles.push(row < FLOOR_Y ? Buffer.from([64, 199]) : Buffer.from([66, 1, 199]));
  }
  return frame(10, deflateRawSync2(Buffer.concat([header, ...tiles, Buffer.alloc(6)])));
}
var WORLD = worldInfo();
var WORLD_326 = frame(7, Buffer.concat([WORLD.subarray(3), Buffer.alloc(4)]));
var SECTIONS = Array.from({ length: SECTION_COLUMNS * SECTION_ROWS }, (_, index) => section((SECTION_X + index % SECTION_COLUMNS) * 200, Math.floor(index / SECTION_COLUMNS) * 150));
function captchaTerrain(prepared) {
  if (!prepared) return { world: WORLD, world326: WORLD_326, sections: SECTIONS, area: [SECTION_X, 0, SECTION_X + SECTION_COLUMNS - 1, SECTION_ROWS - 1] };
  const world = worldInfo(prepared.originX + prepared.spawnX, prepared.originY + prepared.spawnY);
  return { world, world326: frame(7, Buffer.concat([world.subarray(3), Buffer.alloc(4)])), sections: prepared.sections.map((data2) => Buffer.from(data2, "base64")), area: prepared.area };
}
var CaptchaGate = class {
  constructor(client, passed, rejected, terrain = captchaTerrain()) {
    this.client = client;
    this.passed = passed;
    this.rejected = rejected;
    this.terrain = terrain;
    client.server.socket.destroy();
    client.server.name = captchaRoute.name;
    this.arm("\u9A8C\u8BC1\u4E16\u754C\u52A0\u8F7D\u8D85\u65F6\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5");
  }
  active = true;
  phase = "greeting";
  code = "";
  deadline = 0;
  timer = null;
  sectionIndex = 0;
  terrainTask = null;
  drainHandler = null;
  arm(reason) {
    if (this.timer) clearTimeout(this.timer);
    this.deadline = Date.now() + TIMEOUT;
    this.timer = setTimeout(() => this.fail(reason), TIMEOUT);
    this.timer.unref?.();
  }
  close() {
    if (this.timer) clearTimeout(this.timer);
    if (this.terrainTask) clearImmediate(this.terrainTask);
    if (this.drainHandler) this.client.socket.off("drain", this.drainHandler);
    this.terrainTask = null;
    this.drainHandler = null;
    this.timer = null;
    this.code = "";
    this.active = false;
    this.phase = "closed";
  }
  sendTerrain() {
    const client = this.client, socket = client.socket;
    if (!this.active || this.phase !== "sending" || client.disconnecting || socket.destroyed) return;
    try {
      let bytes = 0;
      while (this.sectionIndex < this.terrain.sections.length) {
        if (socket.writableNeedDrain) {
          this.drainHandler = () => {
            this.drainHandler = null;
            this.sendTerrain();
          };
          socket.once("drain", this.drainHandler);
          return;
        }
        const data2 = this.terrain.sections[this.sectionIndex++];
        client.sendDirect(data2);
        if (!this.active || client.disconnecting || socket.destroyed) return;
        bytes += data2.length;
        if (bytes >= 256 * 1024) {
          this.terrainTask = setImmediate(() => {
            this.terrainTask = null;
            this.sendTerrain();
          });
          return;
        }
      }
      this.phase = "tiles";
      client.sendDirect(new packetwriter_default().setType(11).packInt16(this.terrain.area[0]).packInt16(this.terrain.area[1]).packInt16(this.terrain.area[2]).packInt16(this.terrain.area[3]).data);
      client.sendDirect(Buffer.from([3, 0, 49]));
    } catch {
      this.fail("\u9A8C\u8BC1\u4E16\u754C\u52A0\u8F7D\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5");
    }
  }
  fail(reason) {
    if (!this.active) return;
    this.close();
    this.rejected(reason);
  }
  handle(packets) {
    try {
      for (const packet of packets) {
        if (!this.active || this.client.disconnecting) return;
        if (Date.now() >= this.deadline) {
          this.fail("\u9A8C\u8BC1\u7801\u9A8C\u8BC1\u8D85\u65F6\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5");
          return;
        }
        this.packet(packet);
      }
      if (this.active && this.phase === "accepted") {
        this.close();
        this.passed();
      }
    } catch {
      this.fail("\u9A8C\u8BC1\u6570\u636E\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5");
    }
  }
  packet(packet) {
    const client = this.client, type = packet.packetType;
    if (this.phase === "greeting") {
      const parsed = Parser_exports.parse(packet.data, false);
      if (parsed.TAG !== "Ok" || parsed._0.TAG !== "ConnectRequest") {
        this.fail("\u8BF7\u4F7F\u7528\u6709\u6548\u7684 Terraria \u5BA2\u6237\u7AEF\u8FDE\u63A5");
        return;
      }
      client.version = parsed._0._0.version;
      if (!["Terraria319", "Terraria326"].includes(client.version)) {
        this.fail("\u9A8C\u8BC1\u7801\u4E16\u754C\u76EE\u524D\u652F\u6301 Terraria 1.4.5.6 / 1.4.5.8");
        return;
      }
      client.player.id = 0;
      client.playerIdAssigned = true;
      for (const key of ["allowedCharacterChange", "allowedLifeChange", "allowedManaChange", "allowedNameChange"]) client.player[key] = true;
      this.phase = "inventory";
      client.sendDirect(Buffer.from([5, 0, 3, 0, 0]));
      return;
    }
    if (type === 25 || type === 82 && packet.data.length >= 5 && packet.data.readUInt16LE(3) === 1) {
      const parsed = Parser_exports.parse(packet.data, false);
      if (this.phase !== "answer" || parsed.TAG !== "Ok" || parsed._0.TAG !== "NetModuleLoad" || parsed._0._0.TAG !== "ClientText" || parsed._0._0._0 !== "Say" || parsed._0._0._1 !== this.code) {
        this.fail("\u9A8C\u8BC1\u7801\u9519\u8BEF\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5");
        return;
      }
      this.phase = "accepted";
      return;
    }
    if (this.phase === "inventory" && [4, 5, 16, 42, 68, 76, 147].includes(type)) {
      client.getPacketHandler().handlePacket(client, packet);
      return;
    }
    if (type === 6 && this.phase === "inventory") {
      this.phase = "world";
      client.sendDirect(client.version === "Terraria326" ? this.terrain.world326 : this.terrain.world);
      return;
    }
    if (type === 8 && this.phase === "world") {
      this.phase = "sending";
      this.sendTerrain();
      return;
    }
    if (type === 12 && this.phase === "tiles") {
      const parsed = Parser_exports.parse(packet.data, false);
      if (parsed.TAG !== "Ok" || parsed._0.TAG !== "PlayerSpawn" || parsed._0._0.playerId !== 0) {
        this.fail("\u9A8C\u8BC1\u4E16\u754C\u51FA\u751F\u4FE1\u606F\u65E0\u6548");
        return;
      }
      client.ingame = true;
      client.state = clientstate_default.FullyConnected;
      this.phase = "answer";
      this.code = randomInt(0, 1e6).toString().padStart(6, "0");
      this.arm("20 \u79D2\u5185\u672A\u5B8C\u6210\u9A8C\u8BC1\u7801\u9A8C\u8BC1\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5");
      client.sendDirect(Buffer.from([3, 0, 129]));
      client.sendChatMessage(`\u3010\u5165\u670D\u9A8C\u8BC1\u3011\u8BF7\u5728 20 \u79D2\u5185\u76F4\u63A5\u8F93\u5165\u9A8C\u8BC1\u7801\uFF1A${this.code}\u3002\u8F93\u5165\u5176\u5B83\u804A\u5929\u6216\u547D\u4EE4\u5C06\u7ACB\u5373\u65AD\u5F00\u8FDE\u63A5\u3002`, "FFD166");
    }
  }
};

// tmp/market-local-init-r10-snapshot/plugins/dimensions/engine/runtime.ts
var HELLO = 32700;
var ACK = 32701;
var PASSWORD_TIMEOUT_MS = 6e4;
var ADMISSION_HANDSHAKE_PACKETS = /* @__PURE__ */ new Set([1, 4, 5, 6, 8, 12, 16, 38, 42, 50, 68, 147, 161]);
var normalizeIp = (ip = "") => ip.startsWith("::ffff:") ? ip.slice(7) : ip;
function signed(key, text) {
  return createHmac("sha256", key).update(text).digest("hex");
}
function safe(a, b) {
  return typeof a === "string" && Buffer.byteLength(a) === Buffer.byteLength(b) && timingSafeEqual(Buffer.from(a), Buffer.from(b));
}
function wire(type, text) {
  return new packetwriter_default().setType(67).packInt16(type).packString(text).data;
}
function stringOf(buf) {
  let size = 0, shift = 0, offset = 5;
  for (let i = 0; i < 5; i++) {
    if (offset >= buf.length) throw new Error("invalid bridge frame");
    const byte = buf[offset++];
    size |= (byte & 127) << shift;
    if (!(byte & 128)) {
      if (size < 0 || size > 8192 || offset + size !== buf.length) throw new Error("invalid bridge length");
      return buf.toString("utf8", offset, offset + size);
    }
    ;
    shift += 7;
  }
  throw new Error("invalid bridge string");
}
var Runtime = class {
  constructor(notify = () => {
  }) {
    this.notify = notify;
  }
  listener = null;
  config;
  clients = /* @__PURE__ */ new Map();
  details = /* @__PURE__ */ Object.create(null);
  routes = /* @__PURE__ */ Object.create(null);
  stopping = false;
  entryRouter = new EntryRouter();
  captchaTerrain = captchaTerrain();
  population(rows) {
    this.entryRouter.update(rows);
    return { updated: rows.length };
  }
  chooseEntry(excluded = /* @__PURE__ */ new Set()) {
    const row = this.entryRouter.choose(this.config, this.clients, excluded);
    return row ? this.routes[row.command] : null;
  }
  // Upstream diagnostics may contain raw packet data; only emit fixed categories.
  log = { info: (_) => {
  }, debug: (_) => {
  }, warn: (_) => {
  }, error: (_) => this.event("protocol.error") };
  meta(client) {
    return client.tswebManaged;
  }
  event(type, extra = {}) {
    this.notify({ type, at: Date.now(), ...extra });
  }
  options() {
    return {
      socketTimeout: 12e4,
      socketNoDelay: true,
      fakeVersion: { enabled: false, terrariaVersion: 0 },
      restApi: { enabled: false, port: 0 },
      blockInvis: false,
      blacklist: { enabled: false },
      log: { clientError: true, tServerError: true, extensionError: true },
      connectionLimit: { enabled: true, connectionLimitPerIP: this.config.connectionLimit, kickReason: "\u540C\u4E00 IP \u8FDE\u63A5\u6570\u8D85\u8FC7\u4E0A\u9650" },
      connectionRateLimit: { enabled: true, connectionRateLimitPerIP: this.config.connectionRate, connectionRateLimitWindowSeconds: 10 },
      redis: { enabled: false },
      tcpRtt: { enabled: false },
      language: chinese,
      debuffOnSwitch: { enabled: true, buffTypes: [149, 156], debuffTimeInSeconds: 2 },
      disconnectOnKick: { type: "always" },
      nameChanges: { mode: "legacy", exclusions: [] },
      hotReload: false
    };
  }
  async configure(config) {
    if (config.captchaEnabled && ["trb", "tsb"].includes(config.captchaWorld?.source) && !config.captchaPreparedWorld) throw new Error("\u9A8C\u8BC1\u7801 TRB \u4E16\u754C\u5C1A\u672A\u5B8C\u6210\u6821\u9A8C\uFF0C\u65E0\u6CD5\u5F00\u653E\u5165\u53E3");
    const terrain = captchaTerrain(config.captchaPreparedWorld);
    if (this.listener && (config.listenHost !== this.config.listenHost || config.listenPort !== this.config.listenPort)) {
      if (this.clients.size) throw new Error("\u5165\u53E3\u5730\u5740\u53D8\u66F4\u4F1A\u65AD\u5F00\u73A9\u5BB6\uFF0C\u8BF7\u5148\u505C\u6B62\u4E2D\u8F6C");
      await this.close();
    }
    this.stopping = false;
    this.config = config;
    this.captchaTerrain = terrain;
    if (config.population) this.population(config.population);
    const next = /* @__PURE__ */ Object.create(null);
    for (const target of config.targets.filter((t) => t.enabled)) {
      next[target.command] = { name: target.command, serverIP: target.host, serverPort: target.port, isVanilla: false, hidden: target.hidden, targetId: target.id };
      this.details[target.command] ??= { clientCount: 0, disabled: false, disabledTimeout: null, failedConnAttempts: 0 };
    }
    for (const key of Object.keys(this.routes)) if (!next[key]) delete this.routes[key];
    Object.assign(this.routes, next);
    const info = { listenHost: config.listenHost, listenPort: config.listenPort, routingServers: config.targets.filter((t) => t.enabled && t.entry).map((t) => this.routes[t.command]) };
    if (this.listener) {
      this.listener.updateInfo(info);
      Object.assign(this.listener.options, this.options());
      for (const client of this.clients.values()) {
        if (this.meta(client)?.isolation?.active) continue;
        const target = this.target(client);
        if (!target || !target.enabled || target.host !== client.server.ip || target.port !== client.server.port) this.fallback(client, "\u5F53\u524D\u5B50\u670D\u5DF2\u79FB\u9664\u6216\u8FDE\u63A5\u5730\u5740\u53D8\u66F4");
      }
    } else {
      const extension = {
        name: "tsweb",
        version: "1",
        author: "lmengx",
        reloadable: false,
        clientConnectEvent: (client) => this.connected(client),
        socketClosePostHandler: (_, client) => this.departed(client),
        clientFullyConnectedHandler: (client) => this.ready(client),
        serverDisconnectHandler: (server) => {
          this.fallback(server.client, "\u5B50\u670D\u8FDE\u63A5\u4E2D\u65AD");
          return true;
        },
        sendPacketToClientEvent: (client, data2) => {
          this.meta(client)?.attempt?.observeServer(data2[2]);
          this.projectilePacket(client, data2, true);
        },
        priorPacketHandlers: {
          clientHandler: { handlePacket: (client, packet) => {
            if (packet.packetType === 67) return true;
            const meta = this.meta(client);
            if (meta?.passwordChatPending && (packet.packetType === 25 || packet.packetType === 82 && packet.data.length >= 5 && packet.data.readUInt16LE(3) === 1)) {
              this.passwordChat(client, packet);
              return true;
            }
            if (meta?.admissionPending && !meta.networkReady && !ADMISSION_HANDSHAKE_PACKETS.has(packet.packetType)) {
              if (packet.packetType === 25 || packet.packetType === 82 && packet.data.length >= 5 && packet.data.readUInt16LE(3) === 1) this.admissionProgress(client, "chat_waiting");
              return true;
            }
            return false;
          } },
          serverHandler: { handlePacket: (server, packet, source) => source === 0 /* TerrariaServer */ && this.serverPacket(server.client, packet) }
        }
      };
      const commands = {
        // Match the complete configured command, never just its first word.
        parseCommand: (message) => ({ name: message.slice(1).trim().replace(/[ \t]+/g, " ").toLowerCase(), args: [] }),
        handle: (command, client) => {
          if (command.name === "dimensions" || command.name === "\u7EF4\u5EA6") {
            client.sendChatMessage("\u53EF\u524D\u5F80\uFF1A" + this.config.targets.filter((t) => t.enabled && !t.hidden).map((t) => `${t.name} /${t.command}`).join("\u3001"));
            return true;
          }
          const route = this.routes[command.name];
          if (route) {
            this.switch(client.ID, route.targetId).catch((error) => client.sendChatMessage(error.message));
            return true;
          }
          return false;
        }
      };
      this.listener = new listenserver_default({ info, selectServer: () => this.config.captchaEnabled ? captchaRoute : this.chooseEntry(), options: this.options(), servers: this.routes, serversDetails: this.details, globalTracking: { names: {}, tcpRtt: { clients: {} } }, globalHandlers: { command: commands, clientPacketHandler: new clientpackethandler_default(), terrariaServerPacketHandler: new terrariaserverpackethandler_default(), extensions: { tsweb: extension } }, connectionsTracker: /* @__PURE__ */ new Map(), connectRateTracker: /* @__PURE__ */ new Map(), logging: this.log });
      await new Promise((resolve, reject) => {
        const socket = this.listener.server;
        socket.once("listening", () => {
          socket.off("error", reject);
          resolve();
        });
        socket.once("error", reject);
      }).catch(async (error) => {
        await this.close();
        throw error;
      });
    }
    return { appliedRevision: config.revision, sessions: this.clients.size };
  }
  target(client) {
    return this.config.targets.find((t) => t.id === this.meta(client)?.targetId);
  }
  connected(client) {
    const meta = { targetId: this.routes[client.server.name]?.targetId, timer: null, ack: false, fallbackUsed: false, initialRouting: !!this.config.routingMode, excluded: /* @__PURE__ */ new Set(), startedAt: Date.now(), pending: null, projectiles: /* @__PURE__ */ new Map(), confirmationAmbiguous: false };
    client.tswebManaged = meta;
    meta.onClientPacket = (packet) => this.clientPacket(client, packet);
    this.clients.set(client.ID, client);
    const change = client.changeServer.bind(client);
    meta.change = (route) => {
      for (const { projectileId, owner } of [...meta.projectiles.values()]) {
        client.sendDirect(new packetwriter_default().setType(29).packInt16(projectileId).packByte(owner).data);
      }
      meta.projectiles.clear();
      meta.targetId = route.targetId;
      change(route);
    };
    client.disconnectFromServer = () => client.server.socket.destroy();
    client.changeServer = (route) => {
      const target = this.config.targets.find((t) => t.enabled && t.command === route.name && t.host === route.serverIP && t.port === route.serverPort);
      if (target) this.switch(client.ID, target.id).catch((error) => client.sendChatMessage(error.message));
    };
    if (this.config.captchaEnabled) {
      meta.targetId = void 0;
      meta.isolation = new CaptchaGate(client, () => {
        if (client.disconnecting || client.socket.destroyed || this.stopping) return;
        const route = this.chooseEntry();
        if (!route) {
          this.disconnect(client, "\u6682\u65E0\u53EF\u7528\u7684\u9ED8\u8BA4\u4E16\u754C\uFF0C\u8BF7\u7A0D\u540E\u91CD\u65B0\u8FDE\u63A5");
          return;
        }
        meta.admissionPending = true;
        meta.admissionStages = /* @__PURE__ */ new Set();
        client.sendChatMessage("\u9A8C\u8BC1\u7801\u6B63\u786E\uFF0C\u6B63\u5728\u8FDE\u63A5\u9ED8\u8BA4\u4E16\u754C\uFF0C\u8BF7\u7A0D\u5019\u3002");
        client.completeVirtualAdmission();
        this.arm(client);
        meta.attempt.targetId = route.targetId;
        meta.change(route);
        this.admissionProgress(client, "connecting");
        this.event("captcha.passed", { sessionId: client.ID });
      }, (reason) => this.disconnect(client, reason), this.captchaTerrain);
    } else this.arm(client);
  }
  admissionProgress(client, stage) {
    const meta = this.meta(client);
    if (!meta?.admissionPending || meta.admissionStages.has(stage)) return;
    meta.admissionStages.add(stage);
    this.event("captcha.route." + stage, { sessionId: client.ID, targetId: meta.targetId });
  }
  arm(client) {
    const meta = this.meta(client);
    clearTimeout(meta.timer);
    meta.ack = false;
    meta.networkReady = false;
    meta.passwordPending = false;
    meta.passwordChatPending = false;
    meta.payload = null;
    meta.key = null;
    if (meta.attempt) {
      if (meta.attempt.playerSpawnSelfSeen && !meta.attempt.c2sSpawnConfirmed) meta.confirmationAmbiguous = true;
      meta.attempt.finish("superseded_by_next_switch");
      this.event("transfer.finished", { sessionId: client.ID, targetId: meta.attempt.targetId, transfer: meta.attempt.snapshot() });
    }
    meta.attempt = new SpawnAttempt(randomBytes(12).toString("hex"), this.target(client)?.id ?? "", Date.now(), meta.confirmationAmbiguous);
    meta.timer = setTimeout(() => {
      if (client.socket.destroyed || this.stopping) return;
      if (meta.networkReady) {
        meta.attempt.finish("original_spawn_unconfirmed");
        this.settle(client);
        this.event("spawn.unconfirmed", { sessionId: client.ID, targetId: this.target(client)?.id });
        return;
      }
      client.server.socket.destroy();
    }, this.config.connectTimeoutMs);
    meta.timer.unref?.();
  }
  clientPacket(client, packet) {
    if (packet.packetType === 6) this.admissionProgress(client, "inventory");
    if (packet.packetType === 8) this.admissionProgress(client, "tiles_requested");
    if (packet.packetType === 12) this.admissionProgress(client, "spawn_confirmed");
    if (packet.packetType === 67) return true;
    if (packet.packetType === 38 && this.meta(client)?.passwordPending) {
      const meta = this.meta(client);
      meta.passwordPending = false;
      meta.passwordChatPending = false;
      clearTimeout(meta.timer);
      meta.timer = setTimeout(() => client.server.socket.destroy(), this.config.connectTimeoutMs);
      meta.timer.unref?.();
    }
    this.projectilePacket(client, packet.data, false);
    if (packet.packetType === 12) {
      const parsed = Parser_exports.parse(packet.data, false);
      if (parsed.TAG === "Ok" && parsed._0.TAG === "PlayerSpawn" && this.meta(client)?.attempt?.observeClient(parsed._0._0, client.player.id)) {
        this.settle(client);
      }
    }
    return false;
  }
  passwordChat(client, packet) {
    try {
      const parsed = Parser_exports.parse(packet.data, false);
      if (parsed.TAG !== "Ok" || parsed._0.TAG !== "NetModuleLoad" || parsed._0._0.TAG !== "ClientText" || parsed._0._0._0 !== "Say") {
        this.disconnect(client, "\u5BC6\u7801\u8F93\u5165\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5");
        return;
      }
      const data2 = new packetwriter_default().setType(38).packString(parsed._0._0._1).data;
      this.clientPacket(client, { packetType: 38, data: data2 });
      client.server.sendDirect(data2);
    } catch {
      this.disconnect(client, "\u5BC6\u7801\u8F93\u5165\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5");
    }
  }
  projectilePacket(client, data2, fromServer) {
    const meta = this.meta(client);
    if (!meta || ![27, 29].includes(data2[2])) return;
    const parsed = Parser_exports.parse(data2, fromServer);
    if (parsed.TAG !== "Ok" || !["ProjectileSync", "ProjectileDestroy"].includes(parsed._0.TAG)) return;
    const { projectileId, owner } = parsed._0._0;
    const key = `${owner}:${projectileId}`;
    if (data2[2] === 29) {
      meta.projectiles.delete(key);
      return;
    }
    if (!meta.projectiles.has(key) && meta.projectiles.size >= 4096) {
      this.disconnect(client, "\u5F39\u5E55\u540C\u6B65\u6570\u91CF\u5F02\u5E38");
      return;
    }
    meta.projectiles.set(key, { projectileId, owner });
  }
  settle(client) {
    const meta = this.meta(client);
    if (!meta.networkReady || !meta.attempt || meta.attempt.result === "connecting") return;
    if (meta.attempt.result === "completed") {
      clearTimeout(meta.timer);
      meta.timer = null;
    }
    meta.pending?.resolve({ sessionId: client.ID, targetId: this.target(client)?.id, connected: true, ...meta.attempt.snapshot() });
    meta.pending = null;
  }
  serverPacket(client, packet) {
    const meta = this.meta(client);
    if (!meta) return false;
    if (packet.packetType === 3) this.admissionProgress(client, "slot");
    if (packet.packetType === 7) this.admissionProgress(client, "world");
    if (packet.packetType === 49) this.admissionProgress(client, "spawn_requested");
    if (packet.packetType === 37) {
      this.admissionProgress(client, "password");
      clearTimeout(meta.timer);
      meta.passwordPending = true;
      meta.passwordChatPending = !!meta.admissionPending;
      meta.timer = setTimeout(() => this.disconnect(client, "60 \u79D2\u5185\u672A\u8F93\u5165\u4E16\u754C\u5BC6\u7801\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5"), PASSWORD_TIMEOUT_MS);
      meta.timer.unref?.();
      if (meta.passwordChatPending) {
        client.sendChatMessage("\u3010\u4E16\u754C\u5BC6\u7801\u3011\u76EE\u6807\u4E16\u754C\u9700\u8981\u5BC6\u7801\uFF0C\u8BF7\u5728 60 \u79D2\u5185\u76F4\u63A5\u5728\u804A\u5929\u6846\u8F93\u5165\u4E16\u754C\u5BC6\u7801\u3002\u6B64\u6B21\u8F93\u5165\u4EC5\u7528\u4E8E\u76EE\u6807\u4E16\u754C\u7684\u5BC6\u7801\u9A8C\u8BC1\uFF0C\u4E0D\u4F1A\u4F5C\u4E3A\u804A\u5929\u6216\u547D\u4EE4\u53D1\u9001\u3002", "FFD166");
        return true;
      }
      return false;
    }
    if (packet.packetType === 2 && meta.initialRouting) {
      this.admissionProgress(client, "rejected");
      this.fallback(client, "\u9ED8\u8BA4\u4E16\u754C\u62D2\u7EDD\u672C\u6B21\u8FDE\u63A5");
      return true;
    }
    if (packet.packetType === 3 && packet.data.length >= 4) {
      const target = this.target(client);
      if (!target?.bridgeKey) {
        this.rejectBackend(client, "\u5B50\u670D\u5C1A\u672A\u5B8C\u6210\u5BF9\u63A5");
        return true;
      }
      const ip = normalizeIp(client.ip);
      if (!isIP(ip)) {
        this.disconnect(client, "\u65E0\u6CD5\u786E\u8BA4\u8FDE\u63A5\u6765\u6E90");
        return true;
      }
      meta.nonce = randomBytes(18).toString("hex");
      const payload = Buffer.from(JSON.stringify({ v: 1, ip, at: Date.now(), nonce: meta.nonce, session: client.ID, dimension: target.id })).toString("base64url");
      meta.payload = payload;
      meta.key = target.bridgeKey;
      client.server.sendDirect(wire(HELLO, payload + "." + signed(meta.key, payload)));
    }
    if (packet.packetType !== 67 || packet.data.length < 5 || packet.data.readInt16LE(3) !== ACK) return false;
    try {
      const value = stringOf(packet.data), expected = meta.payload + "." + signed(meta.key, "ack:" + meta.payload);
      if (!safe(value, expected)) throw new Error("invalid ack");
      meta.ack = true;
    } catch {
      this.rejectBackend(client, "\u5B50\u670D\u8EAB\u4EFD\u9A8C\u8BC1\u5931\u8D25");
    }
    return true;
  }
  ready(client) {
    const meta = this.meta(client);
    if (!meta?.ack) {
      this.rejectBackend(client, "\u5B50\u670D\u672A\u786E\u8BA4\u53EF\u4FE1\u8FDE\u63A5\uFF0C\u8BF7\u68C0\u67E5\u914D\u5957\u63D2\u4EF6");
      return;
    }
    this.admissionProgress(client, "ready");
    meta.admissionPending = false;
    meta.networkReady = true;
    meta.fallbackUsed = false;
    meta.initialRouting = false;
    if (meta.attempt.result === "completed") this.settle(client);
    this.event("joined", { sessionId: client.ID, targetId: this.target(client)?.id });
  }
  switch(sessionId, targetId) {
    const client = this.clients.get(sessionId), target = this.config.targets.find((t) => t.id === targetId && t.enabled);
    if (!client || client.socket.destroyed) return Promise.reject(new Error("\u73A9\u5BB6\u8FDE\u63A5\u5DF2\u7ED3\u675F"));
    if (!target || !this.routes[target.command]) return Promise.reject(new Error("\u76EE\u6807\u5B50\u670D\u4E0D\u53EF\u7528"));
    const meta = this.meta(client);
    if (meta.isolation?.active) return Promise.reject(new Error("\u73A9\u5BB6\u5C1A\u672A\u5B8C\u6210\u5165\u670D\u9A8C\u8BC1\u7801\u9A8C\u8BC1"));
    if (![clientstate_default.FullyConnected, clientstate_default.Disconnected].includes(client.state) || meta.pending && !meta.networkReady) return Promise.reject(new Error("\u6B63\u5728\u8FDE\u63A5\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5"));
    if (client.connected && meta.targetId === target.id) {
      client.sendChatMessage(`\u4F60\u5DF2\u5728\u300C${target.name}\u300D`);
      return Promise.resolve({ sessionId, targetId, connected: true });
    }
    if (meta.pending) {
      meta.attempt.finish("superseded_by_next_switch");
      this.settle(client);
    }
    return new Promise((resolve, reject) => {
      client.sendChatMessage(`\u6B63\u5728\u524D\u5F80\u300C${target.name}\u300D`);
      meta.pending = { resolve, reject };
      meta.fallbackUsed = false;
      this.arm(client);
      meta.attempt.targetId = target.id;
      meta.change(this.routes[target.command]);
      this.event("switching", { sessionId, targetId });
    });
  }
  fallback(client, reason) {
    if (this.stopping || client.disconnecting || client.socket.destroyed) return;
    const meta = this.meta(client);
    if (!meta) return;
    if (meta.isolation?.active) return;
    if (meta.initialRouting) {
      const current = this.target(client);
      if (current) meta.excluded.add(current.id);
      const route = this.chooseEntry(meta.excluded);
      if (route) {
        client.state = clientstate_default.Disconnected;
        this.arm(client);
        meta.attempt.targetId = route.targetId;
        meta.change(route);
        this.event("routing.retry", { sessionId: client.ID, targetId: route.targetId });
        return;
      }
      const lobby = this.config.targets.find((t) => t.id === this.config.fallbackId && t.enabled && !meta.excluded.has(t.id));
      if (lobby) {
        meta.excluded.add(lobby.id);
        client.state = clientstate_default.Disconnected;
        this.arm(client);
        meta.attempt.targetId = lobby.id;
        meta.change(this.routes[lobby.command]);
        this.event("fallback", { sessionId: client.ID, targetId: lobby.id });
        return;
      }
      this.disconnect(client, "\u6240\u6709\u9ED8\u8BA4\u4E16\u754C\u5747\u672A\u63A5\u53D7\u8FDE\u63A5\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5");
      return;
    }
    meta.attempt?.finish("target_stalled");
    clearTimeout(meta.timer);
    meta.pending?.reject(new Error(reason + "\uFF0C\u6B63\u5728\u5C1D\u8BD5\u5907\u7528\u5927\u5385"));
    meta.pending = null;
    const target = this.config.targets.find((t) => t.id === this.config.fallbackId && t.enabled);
    if (!meta.fallbackUsed && target && target.id !== meta.targetId) {
      meta.fallbackUsed = true;
      client.state = clientstate_default.Disconnected;
      client.sendChatMessage(reason + "\uFF0C\u6B63\u5728\u524D\u5F80\u5907\u7528\u5927\u5385");
      this.arm(client);
      meta.attempt.targetId = target.id;
      meta.change(this.routes[target.command]);
      this.event("fallback", { sessionId: client.ID, targetId: target.id });
    } else this.disconnect(client, reason + "\uFF0C\u6682\u65E0\u53EF\u7528\u5927\u5385\uFF0C\u8BF7\u7A0D\u540E\u91CD\u65B0\u8FDE\u63A5");
  }
  rejectBackend(client, reason) {
    if (this.meta(client)?.initialRouting) this.fallback(client, reason);
    else this.disconnect(client, reason);
  }
  disconnect(client, reason) {
    this.meta(client)?.isolation?.close();
    clearTimeout(this.meta(client)?.timer);
    client.disconnect(reason);
    client.server.socket.destroy();
  }
  departed(client) {
    const meta = this.meta(client);
    if (!meta) return;
    meta.isolation?.close();
    clearTimeout(meta.timer);
    meta.attempt?.finish("disconnected");
    meta.pending?.reject(new Error("\u73A9\u5BB6\u8FDE\u63A5\u5DF2\u7ED3\u675F"));
    this.clients.delete(client.ID);
    this.event("left", { sessionId: client.ID });
  }
  sessions() {
    return [...this.clients.values()].filter((c) => !c.socket.destroyed).map((client) => ({ id: client.ID, name: client.getName(), ip: normalizeIp(client.ip), targetId: this.target(client)?.id ?? "", verifying: !!this.meta(client)?.isolation?.active, connected: client.state === clientstate_default.FullyConnected && !!this.meta(client)?.ack, startedAt: this.meta(client)?.startedAt, transfer: this.meta(client)?.attempt?.snapshot() }));
  }
  kick(id) {
    const client = this.clients.get(id);
    if (!client) throw new Error("\u73A9\u5BB6\u8FDE\u63A5\u5DF2\u7ED3\u675F");
    this.disconnect(client, "\u7BA1\u7406\u5458\u5DF2\u7ED3\u675F\u6B64\u8FDE\u63A5");
    return { disconnected: true };
  }
  async close() {
    this.stopping = true;
    const listener = this.listener;
    this.listener = null;
    for (const client of this.clients.values()) {
      this.meta(client)?.isolation?.close();
      clearTimeout(this.meta(client)?.timer);
      this.meta(client)?.pending?.reject(new Error("\u4E2D\u8F6C\u5DF2\u505C\u6B62"));
      client.server.socket.destroy();
      client.socket.destroy();
    }
    for (const detail of Object.values(this.details)) clearTimeout(detail.disabledTimeout);
    if (listener) await new Promise((resolve) => {
      listener.server.once("close", resolve);
      listener.shutdown();
      for (const client of listener.checkingClients ?? []) client.socket?.destroy();
      if (!listener.server.listening) setTimeout(resolve, 10);
    });
    this.clients.clear();
  }
};
export {
  Runtime
};
/*! Bundled license information:

utf8/utf8.js:
  (*! https://mths.be/utf8js v3.0.0 by @mathias *)
*/
