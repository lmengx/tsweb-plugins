import accessContract from './access.js'
/**
 * 插件市场插件（cordis）
 *
 * 职责：从市场仓库（tsweb-plugins）拉取集中索引 market.json，把其中的 tgz 发行包安装到本机运行时插件目录。
 *
 * 市场仓库的约定（只存发行包与元数据，不存源码）：
 *   tsweb-plugins/
 *   ├── market.json                  索引：每个插件当前版本的 name/version/url/sha256/size/dll[]
 *   └── packages/<name>-<ver>.tgz    发行包（顶层 <name>/，含 package.json/index.js/client//plugin/*.dll）
 *
 * 安装/更新完全复用宿主注册表能力：ctx.plugins.installFromTgz / updateFromTgz / uninstall，
 * 因此"市场装"与"本地 tgz 装"走同一条落位与校验路径，不会出现两套逻辑分叉。
 *
 * 两条取包通道：
 *   1. 在线：按 mirrors 顺序从 GitHub raw / gh-proxy 逐个尝试（失败自动切换并记住成功者）
 *   2. 离线：配置 localDir 指向市场仓库工作副本，直接读本地文件（用于 push 之前自测）
 *
 * 配置：<dataDir>/market/config.json（首次运行写出默认值）
 *   { repo, branch, mirrorOrder, localDir, timeoutMs }
 */
import crypto from 'node:crypto'
import { compareVersions, pluginCompatibility } from '../../src/plugin-contract.js'
import fs from 'node:fs/promises'
import path from 'node:path'
import { Service } from '@deepseek-ai/cordis'

export const name = 'market'
// 安装、更新后的游戏服同步统一由宿主 registry 管理。
export const inject = ['webServer', 'auth', 'plugins', 'servers', 'terminal', 'paths']

/** 市场自身在索引与登记表里的插件名；自更新分支用它判定"要更新的就是我自己" */
const SELF_NAME = 'market'
/**
 * 携带游戏服核心件的插件名。base 的 C# 半是游戏服上的核心件（控制台 / 世界启动 / 玩家管理），
 * 市场页要把它与普通业务插件分开呈现（更新影响不同：游戏服 DLL 会重新同步，接收端不随插件走）。
 * 它同时是"可更新的内置插件"，判定在 src/plugin-gates.js。
 */
const CORE_NAME = 'base'

const DEFAULT_CONFIG = {
  repo: 'lmengx/tsweb-plugins',
  branch: 'main',
  /** 镜像候选顺序：失败自动切换到下一个，成功的被记住并优先复用 */
  mirrorOrder: ['cloudflare', 'ghproxy', 'github'],
  /** 离线模式：指向市场仓库工作副本；非空时优先于在线拉取（push 前自测用） */
  localDir: '',
  /** 覆盖下载基址（自建镜像/内网分发/本地联调用）：非空时替代 mirrors 模板，形如 http://host/path */
  mirrorOverride: '',
  /** 拉索引的超时（毫秒）：索引只有几十 KB，短超时快速切换镜像 */
  timeoutMs: 20000,
  /**
   * 下载发行包的超时（毫秒）。
   *
   * 实测教训：base 的包里带 9.5 MB 地图贴图资源，整包 9.76 MB；用同一个 20 秒超时去下载，
   * 在 1.8 Mbps 的镜像上要 43 秒，于是每次都在 20 秒被 abort——市场报"下载发行包失败"，
   * 而失败分支原本不打日志，服务器窗口看起来"毫无反应"。包下载必须独立给足时间。
   */
  packageTimeoutMs: 180000,
  /** 索引缓存有效期（毫秒） */
  cacheTtlMs: 10 * 60 * 1000,
  /** 收藏的插件名（市场页「收藏」栏用；存在服务端，换浏览器/清缓存都不丢） */
  favorites: [],
}

/**
 * 镜像模板：{repo}/{branch} 由配置替换。
 *
 * 注：原设计里的 **Gitee 镜像已移除**。它需要 GitHub Actions 推送同步，但该 CI
 * 从未实现、Gitee 侧也没有同名仓库，候选恒为 404——每次拉索引都要先白撞一次失败。
 * 老配置里残留的 'gitee' 会被 baseUrls() 的 `MIRRORS[id]` 过滤掉，不会报错，无需迁移。
 * 国内兜底由 ghproxy 承担。
 */
const MIRRORS = {
  /**
   * 自建 Cloudflare 镜像（Workers + KV，仓库内容原样托管）：路径就是 /market.json 与 /packages/<file>.tgz，
   * 不套用 {repo}/{branch} 模板。
   *
   * 为什么默认排第一：实测国内网络下 raw.githubusercontent.com 会解析到黑洞地址（TCP 直接不通），
   * gh-proxy 时快时慢（同一文件 43s~144s 波动），而自建 Cloudflare 域名 9.76 MB / 23.8s 稳定可用。
   */
  cloudflare: 'https://market.tlry.me',
  github: 'https://raw.githubusercontent.com/{repo}/{branch}',
  ghproxy: 'https://gh-proxy.com/https://raw.githubusercontent.com/{repo}/{branch}',
}

function sha256(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex')
}

function human(bytes) {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(2) + ' MB'
}

export class MarketService extends Service {
  constructor(ctx, options = {}) {
    // 必须继承 Service 并以 super(ctx,'market') 注册：cordis 不允许插件直接
    // 往 ctx 上赋一个未声明的服务名（会报 cannot set property "market" without provide）
    super(ctx, 'market')
    this.ctx = ctx
    this.dataDir = options.dataDir ?? ctx.paths?.dataOf('market') ?? path.join(process.cwd(), 'data', 'market')
    this.configPath = path.join(this.dataDir, 'config.json')
    this.config = { ...DEFAULT_CONFIG, ...options }
    this.index = null          // market.json 内容
    this.indexAt = 0           // 拉取时间戳（缓存用）
    this.preferredMirror = null
    /** 读配置时发现的问题（文件损坏等），如实回显给管理员；空串 = 正常 */
    this.loadError = ''
  }

  /**
   * 读配置。
   *
   * **文件不存在**（全新安装）与**内容损坏**必须分开处理：
   * 老写法是裸 `catch { await this.saveConfig() }`，两者一视同仁——
   * 于是配置一旦损坏（写一半崩溃、磁盘满、手工改错一个逗号），用户的收藏与镜像偏好
   * 会被**静默清空并覆写**，无备份、无提示，原文件不可恢复。
   *
   * 现在的取向与本仓既有范式一致（见 task-scheduler/index.js:194-205 对旧版缺陷 D29 的修法）：
   * 损坏时把原文件另存为 .corrupt-<ts>、以默认值运行、并把原因记在 loadError 上如实回显，
   * **不覆盖磁盘上的原文件**——用户仍有救回来的机会。
   */
  async loadConfig() {
    let raw
    try {
      raw = await fs.readFile(this.configPath, 'utf8')
    } catch (err) {
      if (err.code === 'ENOENT') {
        // 全新安装：没有文件是正常状态，落一份默认配置
        this.loadError = ''
        await this.saveConfig()
        return this.config
      }
      // 读不了（权限/IO）不当作"没有配置"去覆盖：保留现状并如实报错
      this.loadError = `配置读取失败（${err.message}）；本次按默认值运行，未改动磁盘文件。`
      console.error(`[market] 配置读取失败：${err.message}`)
      return this.config
    }

    try {
      const parsed = JSON.parse(raw)
      this.config = { ...DEFAULT_CONFIG, ...parsed }
      this.loadError = ''
    } catch (err) {
      const backup = `${this.configPath}.corrupt-${Date.now()}`
      try {
        await fs.copyFile(this.configPath, backup)
      } catch (copyErr) {
        console.error(`[market] 备份损坏配置失败：${copyErr.message}`)
      }
      this.config = { ...DEFAULT_CONFIG }
      this.loadError = `配置文件无法解析（${err.message}）；已另存为 ${backup}，`
        + `当前按默认值运行。在修复该文件或保存一次配置之前，不会覆盖磁盘上的原文件。`
      console.error(`[market] 配置解析失败：${err.message}（已另存 ${backup}）`)
    }
    return this.config
  }

  async saveConfig() {
    await fs.mkdir(this.dataDir, { recursive: true })
    await fs.writeFile(this.configPath, JSON.stringify(this.config, null, 2), 'utf8')
  }

  /** 候选基址顺序：成功的镜像优先，其余按配置顺序 */
  baseUrls() {
    const override = String(this.config.mirrorOverride || '').trim()
    if (override) {
      // 覆盖模式下只用一个基址（自建镜像/内网/本地联调），不再尝试公共镜像
      return [{ id: 'override', base: override.replace(/\/+$/, '') }]
    }
    const order = (this.config.mirrorOrder || DEFAULT_CONFIG.mirrorOrder).filter((id) => MIRRORS[id])
    const rest = Object.keys(MIRRORS).filter((id) => !order.includes(id))
    const list = this.preferredMirror
      ? [this.preferredMirror, ...order.filter((i) => i !== this.preferredMirror), ...rest]
      : [...order, ...rest]
    return list.map((id) => ({
      id,
      base: MIRRORS[id].replace('{repo}', this.config.repo).replace('{branch}', this.config.branch),
    }))
  }

  async fetchWithTimeout(url, timeoutMs) {
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), timeoutMs)
    try {
      const res = await fetch(url, { signal: ctrl.signal, redirect: 'follow' })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      return Buffer.from(await res.arrayBuffer())
    } catch (err) {
      // abort 的原始文案是 "This operation was aborted"，对排查毫无信息量：换成"多久没下完"
      if (err?.name === 'AbortError') throw new Error(`超过 ${Math.round(timeoutMs / 1000)} 秒未完成`)
      throw err
    } finally {
      clearTimeout(timer)
    }
  }

  /**
   * 发行包下载超时：取配置下限与实际大小的较大者。
   *
   * 下限 `packageTimeoutMs`（默认 180 秒）覆盖正常网络；再按 32 KB/s 的"极慢但还能用"的速率
   * 折算一个与体积相关的上限，避免大包（base 近 10 MB）在慢线路上被固定超时卡死。
   */
  packageTimeout(entry) {
    const floor = Number(this.config.packageTimeoutMs) > 0 ? Number(this.config.packageTimeoutMs) : DEFAULT_CONFIG.packageTimeoutMs
    const size = Number(entry?.size) > 0 ? Number(entry.size) : 0
    return Math.max(floor, Math.ceil(size / 32768) * 1000)
  }

  /** 拉索引：localDir 优先；在线按镜像逐个尝试 */
  async fetchIndex(force = false) {
    const now = Date.now()
    if (!force && this.index && now - this.indexAt < (this.config.cacheTtlMs || DEFAULT_CONFIG.cacheTtlMs)) {
      return this.index
    }
    const localDir = String(this.config.localDir || '').trim()
    if (localDir) {
      const file = path.join(localDir, 'market.json')
      this.index = JSON.parse(await fs.readFile(file, 'utf8'))
      this.indexAt = now
      return this.index
    }
    const errors = []
    for (const { id, base } of this.baseUrls()) {
      try {
        const buf = await this.fetchWithTimeout(`${base}/market.json`, this.config.timeoutMs || 20000)
        this.index = JSON.parse(buf.toString('utf8'))
        this.indexAt = now
        if (this.preferredMirror !== id) {
          this.preferredMirror = id
          console.log(`[market] 索引来源镜像: ${id}`)
        }
        return this.index
      } catch (err) {
        errors.push(`${id}: ${err.message}`)
      }
    }
    throw new Error('拉取 market.json 失败（已尝试 ' + errors.join(' | ') + '）')
  }

  /** 取发行包字节（本地或在线），并校验 sha256 */
  async fetchPackage(entry, { verify = true } = {}) {
    const localDir = String(this.config.localDir || '').trim()
    let buf
    let from
    if (localDir) {
      const file = path.join(localDir, entry.url.split('/').join(path.sep))
      buf = await fs.readFile(file)
      from = file
    } else {
      const errors = []
      const timeout = this.packageTimeout(entry)
      for (const { id, base } of this.baseUrls()) {
        const started = Date.now()
        try {
          buf = await this.fetchWithTimeout(`${base}/${entry.url}`, timeout)
          from = `${id}:${entry.url}`
          this.preferredMirror = id
          console.log(`[market] 下载 ${entry.url} 完成（${human(buf.length)}，${id}，${((Date.now() - started) / 1000).toFixed(1)}s）`)
          break
        } catch (err) {
          // 失败必须落日志：否则服务器窗口里只有"点了没反应"，无从判断是网络、镜像还是超时
          console.error(`[market] 下载 ${entry.url} 失败（${id}，${((Date.now() - started) / 1000).toFixed(1)}s）: ${err.message}`)
          errors.push(`${id}: ${err.message}`)
        }
      }
      if (!buf) throw new Error(`下载发行包失败（已尝试 ${errors.join(' | ')}）；换镜像见 data/market/config.json 的 mirrorOverride`)
    }
    if (verify && entry.sha256) {
      const got = sha256(buf)
      if (got !== entry.sha256) {
        throw new Error(`sha256 校验失败: 期望 ${entry.sha256.slice(0, 16)}… 实际 ${got.slice(0, 16)}…`)
      }
    }
    return { buf, from, size: buf.length }
  }

  /** 市场索引与本地已装状态对比 */
  async list(force = false) {
    const index = await this.fetchIndex(force)
    const installed = new Map((this.ctx.plugins?.entries || []).map((e) => [e.name, e]))
    const favorites = new Set(this.config.favorites || [])
    return (index.packages || []).map((p) => {
      const cur = installed.get(p.name)
      const installedVersion = cur?.version || null
      const direction = compareVersions(p.version, installedVersion)
      const hasUpdate = Boolean(cur && (direction > 0 || (direction === 0 && p.sha256 && cur.packageHash && cur.packageHash !== p.sha256.toLowerCase())))
      const compatibilityError = pluginCompatibility({ tsweb: { accessApi: p.accessApi, client: p.hasClient ? './dist/index.js' : null, clientApi: p.clientApi, receiverProtocol: p.receiverProtocol } })
      return {
        name: p.name,
        version: p.version,
        description: p.description || '',
        author: p.author || null,
        // 分类标签（索引里可选；老索引没有该字段时为空数组，前端据此不渲染标签区）
        tags: Array.isArray(p.tags) ? p.tags.filter((t) => typeof t === 'string' && t.trim()) : [],
        bundled: p.bundled === true,
        hasClient: p.hasClient === true,
        dll: p.dll || [],
        // 同步不再受旧包 deploy=ask/manual 字段限制。
        deploy: 'auto',
        size: p.size || 0,
        publishedAt: p.publishedAt || null,
        installed: Boolean(cur),
        installedVersion,
        hasUpdate,
        compatible: !compatibilityError,
        compatibilityError,
        olderThanInstalled: direction !== null && direction < 0,
        origin: cur?.source || null,
        favorite: favorites.has(p.name),
        // 市场自身：前端据此标出"这是市场"，更新它时提示"刷新页面后生效"
        self: p.name === SELF_NAME,
        // 核心件（base）：更新会重新同步游戏服上的 DLL，前端给它单独的确认与结果提示
        core: p.name === CORE_NAME,
      }
    })
  }

  /** 收藏 / 取消收藏（持久化到 market config.json） */
  async setFavorite(name, on) {
    const plugin = String(name || '').trim()
    if (!plugin) throw new Error('缺少插件名')
    const set = new Set(this.config.favorites || [])
    if (on) set.add(plugin)
    else set.delete(plugin)
    this.config.favorites = [...set]
    await this.saveConfig()
    return { name: plugin, favorite: on, favorites: this.config.favorites }
  }

  findEntry(index, name) {
    const hit = (index.packages || []).find((p) => p.name === name)
    if (!hit) throw new Error(`市场中不存在插件: ${name}`)
    return hit
  }

  /** 安装：下载 -> 校验 -> 宿主落位并自动按哈希同步。 */
  async install(name, opts = {}) {
    const index = await this.fetchIndex()
    const entry = this.findEntry(index, name)
    const existing = (this.ctx.plugins.entries || []).find((e) => e.name === name)
    if (existing) {
      // 登记在、目录已删（手工删目录/上次中断/换机器）→ 允许重新安装；目录健在才要求走 update
      const dirOk = await this.ctx.plugins.dirExists(name)
      if (dirOk) {
        throw new Error(`${name} 已安装（v${existing.version}），如需升级请用 update`)
      }
      console.log(`[market] 登记存在但目录缺失，按重新安装处理: ${name}`)
    }
    const { buf, from } = await this.fetchPackage(entry)
    console.log(`[market] 安装 ${name}@${entry.version}（${human(buf.length)}，来源 ${from}）`)
    const created = await this.ctx.plugins.installFromTgz(buf, { enable: true, source: 'market' })
    return { name, version: created.version, from, deployed: [], deployFailed: [], deployMode: 'auto',
      deploySkipped: false, backendState: created.status, warning: created.status === 'enabled' ? '后端安装完成，游戏服正在自动按哈希同步' : `插件已安装，后端尚未就绪（${created.status || '未知状态'}），请检查依赖` }
  }

  /** 更新：下载 -> 校验 -> updateFromTgz（失败自动回滚） */
  async update(name, opts = {}) {
    const index = await this.fetchIndex()
    const entry = this.findEntry(index, name)
    const existing = (this.ctx.plugins.entries || []).find((e) => e.name === name)
    if (!existing) throw new Error(`${name} 未安装，请用 install`)
    const { buf, from } = await this.fetchPackage(entry)
    console.log(`[market] 更新 ${name} ${existing.version} -> ${entry.version}（来源 ${from}）`)
    const result = await this.ctx.plugins.updateFromTgz(name, buf)
    return { ...result, from, deployed: [], deployFailed: [], deployMode: 'auto', deploySkipped: false,
      warning: '后端更新完成，游戏服正在自动按哈希同步' }
  }

  /** 自更新准备：获取并校验包；尚未修改安装目录。 */
  async prepareSelfUpdate() {
    const index = await this.fetchIndex()
    const entry = this.findEntry(index, SELF_NAME)
    const existing = (this.ctx.plugins?.entries || []).find((e) => e.name === SELF_NAME)
    if (!existing) throw new Error(`插件未登记，无法自更新: ${SELF_NAME}`)
    const { buf, from, size } = await this.fetchPackage(entry)
    return { buf, from, size, before: existing.version, to: entry.version }
  }

  /** 由宿主执行替换，调用方等待结果；失败和回滚结果返回 HTTP 请求。 */
  async applySelfUpdate(plan) {
    try {
      console.log(`[market] 自更新 ${SELF_NAME} v${plan.before} -> v${plan.to}（来源 ${plan.from}）`)
      const result = await this.ctx.plugins.updateFromTgz(SELF_NAME, plan.buf)
      console.log(`[market] 自更新完成 v${result.to}；服务端半已热重载，前端半需刷新页面后生效`)
      return result
    } catch (err) {
      console.error(`[market] 自更新失败（回滚状态见错误详情）: ${err.message}`)
      throw err
    }
  }

  /** 卸载（含从服务器撤下 DLL，若曾下发） */
  async uninstall(name, opts = {}) {
    const entry = (this.ctx.plugins.entries || []).find((e) => e.name === name)
    if (!entry) throw new Error(`${name} 未安装`)
    const undeployed = []
    for (const [serverId, state] of Object.entries(entry.servers || {})) {
      if (state !== 'loaded') continue
      try {
        await this.ctx.plugins.undeploy(name, serverId)
        undeployed.push(serverId)
      } catch (err) {
        console.error(`[market] 从服务器撤下失败 ${serverId}: ${err.message}`)
      }
    }
    await this.ctx.plugins.uninstall(name)
    return { name, undeployed }
  }

  async refresh() {
    this.index = null
    this.indexAt = 0
    const index = await this.fetchIndex(true)
    return { count: (index.packages || []).length, mirror: this.preferredMirror || (this.config.localDir ? 'local' : 'unknown') }
  }
}

export async function apply(ctx, options = {}) {
  try {
    return await applyInner(ctx, options)
  } catch (err) {
    // cordis 对"等待 inject 后才执行"的插件，apply 异常不会冒泡到加载器，必须在此显式记录
    console.error('[market] 初始化失败: ' + err.message)
    if (process.env.TSWEB_DEBUG) console.error(err.stack)
    throw err
  }
}

async function applyInner(ctx, options = {}) {
  if (process.env.TSWEB_DEBUG) console.log('[market][dbg] apply 被调用，开始加载配置')
  const svc = new MarketService(ctx, options)
  await svc.loadConfig()
  ctx.market = svc

  const app = ctx.auth.access.policyApp(ctx.webServer.app, accessContract, ctx)
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]

  app.get('/api/market/list', ...admin, async (req, res) => {
    try {
      // force=1 时绕过索引缓存（面板「刷新索引」用）
      // configError 随列表回显：配置损坏时管理员必须看到原因与备份路径，
      // 否则只会看到"收藏凭空消失"而无从排查（见 loadConfig）。
      res.json({ success: true, plugins: await svc.list(req.query?.force === '1'), configError: svc.loadError || '' })
    } catch (err) {
      res.status(502).json({ error: err.message })
    }
  })

  // 收藏 / 取消收藏（服务端持久化；收藏栏与列表星标共用）
  app.post('/api/market/favorite', ...admin, async (req, res) => {
    try {
      res.json({ success: true, ...(await svc.setFavorite(String(req.body?.name || ''), req.body?.favorite === true)) })
    } catch (err) {
      res.status(400).json({ error: err.message })
    }
  })

  app.post('/api/market/refresh', ...admin, async (_req, res) => {
    try {
      res.json({ success: true, ...(await svc.refresh()) })
    } catch (err) {
      res.status(502).json({ error: err.message })
    }
  })

  app.post('/api/market/install', ...admin, async (req, res) => {
    try {
      res.json({ success: true, ...(await svc.install(String(req.body?.name || ''), { serverIds: req.body?.serverIds || null })) })
    } catch (err) {
      res.status(400).json({ error: err.message })
    }
  })

  app.post('/api/market/update', ...admin, async (req, res) => {
    const target = String(req.body?.name || '')

    // Await the host-owned update operation so rollback failures reach the caller.
    // The request/response outlive the old market fiber; no old service is used afterwards.
    if (target === SELF_NAME) {
      try {
        const plan = await svc.prepareSelfUpdate()
        const result = await svc.applySelfUpdate(plan)
        res.json({ success: true, ...result, self: true, source: plan.from,
          refreshRequired: true, restartRequired: false })
      } catch (error) { res.status(error.status || 500).json({ error: error.message }) }
      return
    }

    try {
      const result = await svc.update(target, { serverIds: req.body?.serverIds || null })
      /**
       * 普通更新的生效语义（与自更新同一套双标记）：
       * 后端半由 updateFromTgz 热重载、立即生效；前端半仍是页面加载时的旧 bundle。
       * loader 此时已重新加载出该插件的 clientUrl（带 ?v=），非空即表示它有前端半、需要刷新。
       */
      let refreshRequired = false
      try {
        refreshRequired = Boolean(svc.ctx.plugins?.loader?.loaded?.get?.(target)?.clientUrl)
      } catch { /* 拿不到就按"无需刷新"处理，不因此让更新报错 */ }
      res.json({ success: true, ...result, refreshRequired, restartRequired: false })
    } catch (err) {
      res.status(400).json({ error: err.message })
    }
  })

  app.post('/api/market/uninstall', ...admin, async (req, res) => {
    try {
      res.json({ success: true, ...(await svc.uninstall(String(req.body?.name || ''))) })
    } catch (err) {
      res.status(400).json({ error: err.message })
    }
  })

  // ── 终端命令 ──
  const term = ctx.terminal
  if (term?.register) {
    term.register('market-list', '列出市场插件与本地状态', async () => {
      try {
        const rows = await svc.list()
        if (rows.length === 0) { console.log('（市场暂无插件）'); return }
        for (const r of rows) {
          const st = !r.installed ? `未安装 -> 可装 v${r.version}`
            : r.hasUpdate ? `v${r.installedVersion} -> v${r.version}`
              : `已最新 v${r.installedVersion}`
          console.log(`  ${r.name.padEnd(16)} ${st.padEnd(28)} ${r.bundled ? '[自带]' : ''} ${r.description || ''}`)
        }
      } catch (err) {
        console.error('拉取市场索引失败: ' + err.message)
      }
    })
    term.register('market-install', '从市场安装插件并自动同步（用法: market-install <name>）', async (args) => {
      if (!args?.[0] || args.length !== 1 || args[0].startsWith('--')) { console.log('用法: market-install <name>（自动同步）'); return }
      try {
        const r = await svc.install(String(args[0]))
        console.log(`已安装 ${r.name}@${r.version}；游戏服自动按哈希同步`)

      } catch (err) {
        console.error('安装失败: ' + err.message)
      }
    })
    term.register('market-update', '从市场覆盖更新并自动同步（用法: market-update <name>）', async (args) => {
      if (!args?.[0] || args.length !== 1 || args[0].startsWith('--')) { console.log('用法: market-update <name>（自动同步）'); return }
      try {
        const r = await svc.update(String(args[0]))
        console.log(`已更新 ${r.name}: ${r.from} -> ${r.to}；游戏服自动按哈希同步`)

      } catch (err) {
        console.error('更新失败: ' + err.message)
      }
    })
    term.register('market-uninstall', '卸载市场插件（用法: market-uninstall <name>）', async (args) => {
      if (!args?.[0]) { console.log('用法: market-uninstall <name>'); return }
      try {
        const r = await svc.uninstall(String(args[0]))
        console.log(`已卸载 ${r.name}；从 ${r.undeployed.length} 台服务器撤下`)
      } catch (err) {
        console.error('卸载失败: ' + err.message)
      }
    })
    term.register('market-refresh', '强制重拉市场索引', async () => {
      try {
        const r = await svc.refresh()
        console.log(`索引已刷新: ${r.count} 个插件（来源 ${r.mirror}）`)
      } catch (err) {
        console.error('刷新失败: ' + err.message)
      }
    })
  }

  console.log(`[market] 插件市场已就绪（repo=${svc.config.repo} 分支=${svc.config.branch}`
    + (svc.config.localDir ? ` 离线目录=${svc.config.localDir}` : ' 在线模式') + '）')
}
