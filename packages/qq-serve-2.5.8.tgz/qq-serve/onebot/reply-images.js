import sharp from 'sharp'

// Oversized replies keep every page in one message without distortion or loss.
export async function composeReplyImages(images) {
  if (!Array.isArray(images) || !images.length) throw new Error('没有可发送的图片')
  if (images.length === 1) return images
  const metadata = await Promise.all(images.map(image => sharp(image).metadata()))
  if (metadata.some(item => !item.width || !item.height)) return images
  const width = Math.min(2048, Math.max(...metadata.map(item => item.width)))
  const heights = metadata.map(item => Math.round(item.height * width / item.width))
  const height = heights.reduce((sum, value) => sum + value, 0)
  if (height > 4096 || width * height > 8_000_000) return images
  const layers = []; let top = 0
  for (let i = 0; i < images.length; i++) {
    layers.push({ input: await sharp(images[i]).resize({ width }).png().toBuffer(), top, left: 0 })
    top += heights[i]
  }
  const image = await sharp({ create: { width, height, channels: 4, background: '#222c32' } }).composite(layers).png().toBuffer()
  return image.length <= 8 * 1024 * 1024 ? [image] : images
}
