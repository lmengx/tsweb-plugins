const palettes = {
  space: {
    paper: "#0b1426",
    ink: "#e9f0ff",
    muted: "#a0b0cf",
    accent: "#9cc4ff",
    rule: "#293b58",
    panel: "#14233b",
    tile: "#1c3150",
    good: "#9cddbf",
    radius: 18,
  },
  pixel: {
    paper: "#222c32",
    ink: "#f6efd9",
    muted: "#bbc7b8",
    accent: "#f1d496",
    rule: "#4b5d50",
    panel: "#303e3e",
    tile: "#3c4b43",
    good: "#c0dca2",
    radius: 0,
  },
  cream: {
    paper: "#fcf3e8",
    ink: "#4a3930",
    muted: "#80695b",
    accent: "#96563b",
    rule: "#e3d2bd",
    panel: "#fffaf3",
    tile: "#efdfcc",
    good: "#476747",
    radius: 24,
  },
};
const xml = (value) =>
  String(value ?? "").replace(
    /[&<>"']/g,
    (char) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&apos;",
      })[char],
  );
const clean = (value) =>
  String(value ?? "").replace(/[\u0000-\u001f\u007f-\u009f]/g, " ");
const widthOf = (value, size) =>
  Array.from(String(value)).reduce(
    (sum, char) =>
      sum +
      (/[^\x00-\xff]/.test(char) ? 1 : /[ilI1.,: ]/.test(char) ? 0.32 : 0.62) *
        size,
    0,
  );
function wrap(value, width, size) {
  const lines = [];
  let current = "";
  for (const char of clean(value)) {
    if (current && widthOf(current + char, size) > width) {
      lines.push(current);
      current = "";
    }
    current += char;
  }
  lines.push(current);
  return lines;
}
const rect = (x, y, w, h, fill, radius = 0, stroke) =>
  `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${radius}" fill="${fill}"${stroke ? ` stroke="${stroke}"` : ""}/>`;
const text = (x, y, value, size, color, weight = 400, anchor = "start") =>
  `<text x="${x}" y="${y}" font-size="${size}" fill="${color}" font-weight="${weight}" text-anchor="${anchor}">${xml(value)}</text>`;
const rule = (y, color) => `<path d="M48 ${y}H912" stroke="${color}"/>`;
const multiline = (
  lines,
  x,
  y,
  size,
  color,
  weight = 400,
  leading = size + 10,
) =>
  lines
    .map((value, i) => text(x, y + i * leading, value, size, color, weight))
    .join("");
const svg = (body, height, label) =>
  `<svg xmlns="http://www.w3.org/2000/svg" width="960" height="${height}" viewBox="0 0 960 ${height}" role="img"><title>${xml(label)}</title><g font-family="Microsoft YaHei,Noto Sans CJK SC,WenQuanYi Zen Hei,sans-serif">${body}</g></svg>`;
function stamp(value, includeYear = false) {
  const date = new Date(value);
  return Number.isFinite(date.getTime())
    ? new Intl.DateTimeFormat("zh-CN", {
        timeZone: "Asia/Shanghai",
        ...(includeYear ? { year: "numeric" } : {}),
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      }).format(date)
    : "时间未知";
}
function footer(data, height, p, page = 1, pages = 1, label = "TSWEB") {
  return (
    rule(height - 62, p.rule) +
    text(
      48,
      height - 27,
      label + (data.sample ? " · 演示数据 DEMO" : ""),
      18,
      p.muted,
    ) +
    text(
      912,
      height - 27,
      stamp(data.generatedAt) + ` · ${page}/${pages}`,
      18,
      p.muted,
      400,
      "end",
    )
  );
}
function landscape(theme) {
  const pixel = theme === "pixel",
    cream = theme === "cream";
  const moon = cream ? "#e8b568" : "#f3ddaa",
    back = cream ? "#e5d1bb" : pixel ? "#40525a" : "#203d61",
    front = cream ? "#bac5a0" : pixel ? "#63785c" : "#335878";
  let body = `<circle cx="792" cy="111" r="39" fill="${moon}" opacity="0.9"/>`;
  if (!cream)
    for (const [x, y] of [
      [580, 58],
      [685, 96],
      [908, 62],
      [880, 153],
      [650, 46],
      [726, 36],
    ])
      body += rect(x, y, pixel ? 5 : 3, pixel ? 5 : 3, "#dbe7cf");
  body += `<path fill="${back}" d="${pixel ? "M478 292V239H529V205H572V170H618V205H652V237H687V196H731V160H775V205H820V233H865V189H914V230H960V320H478Z" : "M450 320L590 170L683 258L755 153L960 314V320Z"}"/>`;
  body += `<path fill="${front}" d="${pixel ? "M406 306V286H472V267H536V291H610V258H679V281H750V249H819V270H893V284H960V320H406Z" : "M408 320Q545 229 660 286Q825 214 960 283V320Z"}"/>`;
  body += rect(0, 316, 960, 7, cream ? "#a5af82" : "#879f6b");
  body += `<path fill="${cream ? "#71896d" : "#9caf85"}" d="M875 297L898 252L921 297H906V317H891V297Z"/>`;
  return body;
}
function home(data, theme, options) {
  const p = palettes[theme],
    responding = data.rows.filter((row) => row.available).length;
  const total = data.rows
    .filter((row) => row.available)
    .reduce((sum, row) => sum + row.players.length, 0);
  const connected = options.botStatus?.connected;
  let body = rect(0, 0, 960, 540, p.paper) + landscape(theme);
  body += text(48, 47, "TSWEB / ADVENTURE HUB", 18, p.muted);
  body +=
    rect(741, 27, 171, 40, p.panel, p.radius) +
    text(
      827,
      54,
      connected === true
        ? "● 机器人在线"
        : connected === false
          ? "机器人未连接"
          : "机器人状态未知",
      19,
      connected === true ? p.good : p.muted,
      500,
      "middle",
    );
  body += text(48, 132, "下一场冒险，从这里开始。", 43, p.ink, 700);
  body += text(48, 187, "查服务器 · 看在线 · 管理你的游戏账号", 25, p.accent);
  body += text(48, 232, "选择下方菜单，出发去你的世界。", 22, p.muted);
  const metrics = [
    ["可用服务器", `${responding} / ${data.rows.length}`],
    [
      responding !== data.rows.length ? "已确认在线" : "全服在线",
      `${total} 人`,
    ],
    ["账号服务", "注册 · 绑定"],
  ];
  metrics.forEach(([label, value], i) => {
    const x = 48 + i * 296;
    body +=
      rect(x, 349, 272, 103, p.panel, p.radius) +
      text(x + 22, 382, label, 20, p.muted) +
      text(x + 22, 425, value, 32, p.ink, 700);
  });
  if (responding !== data.rows.length)
    body += text(
      48,
      340,
      "部分服务器未响应，在线人数仅统计已响应服务器。",
      17,
      p.muted,
    );
  return svg(
    body + footer(data, 540, p, 1, 1, "TSWEB / 主菜单"),
    540,
    "TSWeb 机器人主页",
  );
}
const amount = (value) =>
  Number.isFinite(value) && value >= 0 ? String(Math.floor(value)) : "未获取";
const duration = (value) =>
  !Number.isFinite(value) || value < 0
    ? "未获取"
    : value < 60
      ? `${Math.floor(value)} 分钟`
      : `${Math.floor(value / 60)} 小时 ${Math.floor(value % 60)} 分钟`;
function account(data, theme, profile) {
  if (!profile || typeof profile.bound !== "boolean")
    throw Object.assign(new Error("账户图片需要真实绑定状态"), { status: 400 });
  const p = palettes[theme],
    bound = profile.bound,
    waiting = !bound && profile.pending === true;
  const status = bound ? "已绑定" : waiting ? "等待游戏内验证" : "未绑定";
  const name = wrap(
    bound
      ? profile.username || "角色名未返回"
      : waiting && profile.username
        ? profile.username
        : "尚未关联游戏账号",
    800,
    38,
  );
  const game = profile.game,
    character = game?.found === true ? game : null;
  const fields = bound
    ? [
        ["资料来源", game?.server || "暂不可用"],
        ["游戏用户组", character?.group || "未获取"],
        ["累计游戏时长", duration(game?.onlineMinutes)],
        ["死亡次数", amount(character?.deaths)],
        ["钓鱼任务", amount(character?.fishingQuests)],
        [
          "游戏资料",
          !game ? "暂不可用" : game.found ? "已获取" : "尚无角色资料",
        ],
      ]
    : [
        ["新玩家", "注册新账号，建立你的游戏角色"],
        ["已有账号", "绑定已有角色，并在游戏内验证"],
        profile.adapter === "onebot"
          ? ["设置密码", "注册后私信机器人：改密码 新密码"]
          : ["旧版 QQ 账号", "通过绑定转移关联原来的角色"],
      ];
  let y = 180 + name.length * 48,
    body = "";
  body +=
    text(48, 47, "TSWEB / ACCOUNT CENTER", 18, p.muted) +
    text(48, 109, "账号服务", 44, p.ink, 700);
  body +=
    rect(647, 76, 265, 47, p.tile, p.radius) +
    text(
      779,
      108,
      "绑定状态：" + status,
      waiting ? 19 : 23,
      bound ? p.good : p.accent,
      700,
      "middle",
    );
  body +=
    text(
      48,
      157,
      bound ? "当前绑定角色" : waiting ? "待验证角色" : "你的游戏身份",
      21,
      p.muted,
    ) + multiline(name, 48, 203, 38, p.ink, 700, 48);
  if (bound) {
    for (let i = 0; i < fields.length; i += 2) {
      const pair = fields
        .slice(i, i + 2)
        .map(([label, value]) => ({ label, lines: wrap(value, 374, 28) }));
      const h = Math.max(...pair.map((field) => field.lines.length)) * 37 + 57;
      pair.forEach((field, col) => {
        const x = 48 + col * 444;
        body +=
          rect(x, y, 420, h, p.panel, p.radius) +
          text(x + 23, y + 30, field.label, 19, p.muted) +
          multiline(field.lines, x + 23, y + 70, 28, p.ink, 600, 37);
      });
      y += h + 16;
    }
    if (profile.boundAt) {
      body += text(
        48,
        y + 21,
        "绑定时间：" + stamp(profile.boundAt, true) + (profile.adapter === "onebot" ? " · QQ " + clean(profile.qq) : " · QQ 官方身份"),
        20,
        p.muted,
      );
      y += 46;
    }
  } else {
    if (waiting) {
      body += text(
        48,
        y + 20,
        "请进入游戏完成验证；取消当前请求后才可重新办理。",
        23,
        p.accent,
      );
      y += 49;
    }
    fields.forEach(([label, value], i) => {
      body +=
        rect(48, y, 864, 91, p.panel, p.radius) +
        text(
          71,
          y + 36,
          String(i + 1).padStart(2, "0") + "  " + label,
          23,
          p.accent,
          700,
        ) +
        text(71, y + 70, value, 23, p.ink);
      y += 105;
    });
  }
  body += text(
    48,
    y + 24,
    bound
      ? "仅展示当前会话用户的账号资料；密码操作仅在私聊开放。"
      : profile.adapter === "onebot"
        ? "群聊发送「注册 角色名」或「绑定 角色名」；私聊改密码。"
        : "选择下方按钮办理；密码仅通过机器人私聊交付。",
    20,
    p.muted,
  );
  const height = Math.max(720, y + 112);
  return svg(
    rect(0, 0, 960, height, p.paper) +
      body +
      footer(data, height, p, 1, 1, "TSWEB / 账户服务"),
    height,
    "账号服务 · " + status,
  );
}
function chips(players) {
  let x = 0,
    y = 0,
    rowHeight = 0;
  const parts = [];
  for (const name of players) {
    const lines = wrap(name, 772, 27),
      w = Math.min(
        816,
        Math.max(88, ...lines.map((value) => widthOf(value, 27) + 32)),
      ),
      h = lines.length * 36 + 18;
    if (x && x + w > 816) {
      y += rowHeight + 12;
      x = 0;
      rowHeight = 0;
    }
    parts.push({ x, y, w, h, lines });
    x += w + 12;
    rowHeight = Math.max(rowHeight, h);
  }
  return { parts, height: y + rowHeight };
}
function blocks(data, kind) {
  if (!data.rows.length) return [{ empty: true, height: 140 }];
  return data.rows.flatMap((row, index) => {
    const title = wrap(row.name, 590, 28),
      addresses = wrap(row.address || "未配置游戏地址", 640, 25);
    if (kind === "servers")
      return [
        {
          row,
          index,
          title,
          addresses,
          height: 64 + title.length * 38 + addresses.length * 34,
        },
      ];
    if (!row.available || !row.players.length)
      return [{ row, index, title, height: 78 + title.length * 38 }];
    const chunks = [];
    for (let start = 0; start < row.players.length;) {
      let end = start + 1,
        layout = chips(row.players.slice(start, end));
      while (end < row.players.length && end - start < 24) {
        const next = chips(row.players.slice(start, end + 1));
        if (next.height > 690) break;
        layout = next;
        end++;
      }
      chunks.push({
        row,
        index,
        title,
        layout,
        continued: start > 0,
        height: 70 + title.length * 38 + layout.height,
      });
      start = end;
    }
    return chunks;
  });
}
export function renderFeedbackPages(value, theme = "pixel") {
  const p = palettes[theme] || palettes.pixel;
  const lines = String(value || "操作完成").split(/\r?\n/).flatMap(line => wrap(clean(line), 800, 27));
  const pages = [];
  for (let start = 0; start < lines.length; start += 38) {
    const chunk = lines.slice(start, start + 38), height = Math.max(320, 240 + chunk.length * 40);
    pages.push(svg(
      rect(0, 0, 960, height, p.paper) +
      text(48, 47, "TSWEB / OneBot", 18, p.muted) +
      text(48, 109, "操作反馈", 40, p.ink, 700) +
      rect(32, 142, 896, height - 210, p.panel, p.radius) +
      multiline(chunk, 64, 188, 27, p.ink, 400, 40) +
      text(48, height - 30, "TSWEB / " + (start / 38 + 1) + " / " + Math.ceil(lines.length / 38), 18, p.muted),
      height, "OneBot 操作反馈"));
  }
  return pages;
}
export function renderSvgPages(
  data,
  kind = "servers",
  theme = "pixel",
  options = {},
) {
  if (
    !Object.hasOwn(palettes, theme) ||
    !["home", "account", "servers", "players"].includes(kind)
  )
    throw Object.assign(new Error("渲染风格或图片类型无效"), { status: 400 });
  if (kind === "home") return [home(data, theme, options)];
  if (kind === "account") return [account(data, theme, options.profile)];
  const p = palettes[theme],
    startY = 210,
    pages = [[]];
  let used = startY;
  for (const block of blocks(data, kind)) {
    if (used + block.height + 96 > 1280 && pages.at(-1).length) {
      pages.push([]);
      used = startY;
    }
    pages.at(-1).push(block);
    used += block.height + 16;
  }
  const responding = data.rows.filter((row) => row.available).length,
    partial = responding !== data.rows.length;
  const total = data.rows
    .filter((row) => row.available)
    .reduce((sum, row) => sum + row.players.length, 0);
  return pages.map((page, pageIndex) => {
    const height = Math.max(
      540,
      startY + page.reduce((sum, block) => sum + block.height + 16, 0) + 80,
    );
    let body =
      rect(0, 0, 960, height, p.paper) +
      text(48, 42, "TSWEB / WORLD NETWORK", 18, p.muted);
    body += text(
      48,
      101,
      kind === "players" ? "此刻，一起冒险。" : "下一站，去哪里？",
      43,
      p.ink,
      700,
    );
    body += text(
      48,
      143,
      kind === "players" ? "全服在线玩家" : "服务器列表 · 游戏连接地址",
      24,
      p.accent,
    );
    body += text(
      912,
      100,
      kind === "players"
        ? `${total} 人`
        : `${responding} / ${data.rows.length}`,
      39,
      p.accent,
      700,
      "end",
    );
    body += text(
      912,
      142,
      kind === "players" ? (partial ? "已确认在线" : "全服在线") : "可用服务器",
      21,
      p.muted,
      400,
      "end",
    );
    body += text(
      48,
      184,
      partial
        ? "部分服务器未响应 · 未知人数不计为 0"
        : "只读实时查询 · 点击消息下方按钮继续操作",
      21,
      p.muted,
    );
    let y = startY;
    for (const block of page) {
      if (block.empty) {
        body += text(
          48,
          y + 56,
          "暂无启用的服务器，请先在后台添加服务器。",
          27,
          p.muted,
        );
        y += block.height + 16;
        continue;
      }
      const { row, index, title } = block;
      body += rect(48, y, 864, block.height, p.panel, p.radius);
      body += text(68, y + 39, String(index + 1).padStart(2, "0"), 20, p.muted);
      body += multiline(
        title.map(
          (value, i) =>
            value + (block.continued && i === title.length - 1 ? " · 续" : ""),
        ),
        112,
        y + 40,
        28,
        p.ink,
        700,
        38,
      );
      body += text(
        888,
        y + 39,
        row.available ? "● 在线" : "未响应",
        20,
        row.available ? p.good : p.muted,
        500,
        "end",
      );
      if (kind === "servers") {
        body += multiline(
          block.addresses,
          112,
          y + 48 + title.length * 38,
          25,
          p.accent,
          400,
          34,
        );
        body += text(
          888,
          y + 82,
          row.available ? row.players.length + " 人" : "人数未知",
          23,
          p.ink,
          500,
          "end",
        );
      } else if (block.layout) {
        for (const chip of block.layout.parts) {
          const cy = y + 56 + title.length * 38 + chip.y;
          body +=
            rect(72 + chip.x, cy, chip.w, chip.h, p.tile, p.radius ? 10 : 0) +
            multiline(chip.lines, 88 + chip.x, cy + 35, 27, p.ink, 400, 36);
        }
      } else
        body += text(
          72,
          y + 51 + title.length * 38,
          row.available
            ? "暂时没有玩家，等你来探索。"
            : "暂未响应，未计入在线人数。",
          25,
          p.muted,
        );
      y += block.height + 16;
    }
    return svg(
      body +
        footer(
          data,
          height,
          p,
          pageIndex + 1,
          pages.length,
          kind === "players" ? "TSWEB / 跨服在线一览" : "TSWEB / 游戏连接地址",
        ),
      height,
      kind === "players" ? "全服在线玩家" : "服务器列表",
    );
  });
}
