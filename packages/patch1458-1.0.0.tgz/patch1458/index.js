/**
 * 1458 临时补丁（patch1458）—— 宿主侧半（cordis）
 *
 * 这个插件的主体是**游戏服半** Patch1458.dll：它向 TShock Bouncer 的 NPC buff 白名单
 * 注入 1.4.5.8 新增的 5 个 NPC debuff，修复"使用 1.4.5.8 新内容（催化手环等）的合法玩家被误踢"。
 * 真正的补丁动作只发生在游戏服进程内，宿主侧无法替代。
 *
 * 宿主侧半的职责（只读、无副作用）：
 *   - 把补丁表（注入哪些 buff、时长上限、依据）以可读形式暴露给面板，便于排障与审计
 *   - 聚合「每台服务器是否已下发本 DLL」的状态（来自注册表），安装后一眼看清哪些服生效了
 *   - GET /api/patch1458/status
 *
 * 刻意不做的事：
 *   - 不建定时器、不写状态文件、不访问游戏服 REST —— 保持零副作用，避免给"装机即生效"引入风险
 *   - 不注册前端半：本插件的 tsweb.deploy = "ask"，安装/更新时的"选择服务器"弹窗由市场插件
 *     （plugins/market/client/market.js 的 pickServers）提供，无需自带界面
 *
 * DLL 下发模式：package.json 的 tsweb.deploy = "ask"
 *   → 市场安装/更新时前端弹窗勾选目标服务器；未指定则跳过下发（可在「插件下发」页手动逐服 deploy）。
 *   → 卸载始终自动从所有已下发（loaded）的服务器撤下 DLL，与 deploy 模式无关。
 *
 * 生效确认：本插件的注入状态只能由游戏服半回答（白名单是 TShock 进程内私有字段），
 *   因此在游戏内用 /patch1458 查看（权限 patch1458.use，安装时自动授予 admin 组）。
 *
 * 依赖：webServer / auth / servers / plugins
 * 约定：禁止 emoji；不写状态数据（因此不需要 ctx.paths）
 */
import { readFileSync } from 'node:fs'

export const name = 'patch1458'
export const inject = ['webServer', 'auth', 'servers', 'plugins']

/** 插件名（= 目录名 = 包名 = 注册表键，三者必须一致；pack-plugin 有硬校验） */
const SELF = 'patch1458'

/** 本插件在游戏服内注册的查询命令与权限节点（与 C# 半保持一致） */
const CHAT_COMMAND = '/patch1458'
const GAME_PERMISSION = 'patch1458.use'

/** 包内版本号：以随包发布的 package.json 为准，便于日志确认实际运行的版本 */
const PKG_VERSION = JSON.parse(
  readFileSync(new URL('./package.json', import.meta.url), 'utf8')
).version

/**
 * 补丁表 —— 与 C# 半 Patch1458Plugin.AddedBuffs 一一对应（改一处必须同步改另一处）。
 *
 * maxTicks 的取值依据：1.4.5.8 原版代码中该 buff 全部施加点的最大时长，与 TShock 收录惯例一致。
 * 来源：1.4.5.8 TerrariaServer.exe 反编译 Projectile.StatusNPC 调用点。
 */
const PATCH_BUFFS = [
  {
    id: 395,
    name: 'PotentAcids',
    cn: '强酸',
    maxTicks: 120,
    basis: '诅咒涂层 60；弹幕 282/283 为 120 → 上限 120',
  },
  {
    id: 397,
    name: 'ChlorophyteSpore',
    cn: '叶绿孢子',
    maxTicks: 300,
    basis: '弹幕 1127 固定 300',
  },
  {
    id: 398,
    name: 'AcceleratePoisons',
    cn: '催化毒液（催化手环）',
    maxTicks: 300,
    basis: '催化手环 catalystBand 固定 300，唯一调用点；也是误踢的主要案例',
  },
  {
    id: 399,
    name: 'BlueLightning',
    cn: '蓝闪电',
    maxTicks: 420,
    basis: '弹幕 1117 LightningStrikeShot 为 60*rand(4,8) = 240..420 → 上限 420',
  },
  {
    id: 400,
    name: 'RedLightning',
    cn: '红闪电',
    maxTicks: 420,
    basis: '弹幕 1122 ArcSurge 为 60*rand(4,8) = 240..420 → 上限 420',
  },
]

/**
 * 已知不覆盖的场景（与 C# 半注释一致，明确写出来避免误会）：
 * 城镇 NPC 的 debuff 白名单是 Bouncer 内硬编码的 BuffID if 链（非集合），无法用字典注入扩展，
 * 因此催化手环等对城镇 NPC 施加新 debuff 仍会被踢；如需放行须改 TShock 源码或 Harmony patch。
 */
const KNOWN_LIMITS = [
  '城镇 NPC 的 debuff 白名单是 TShock 内硬编码 if 链，本补丁无法扩展；对城镇 NPC 施加新 debuff 仍会被踢',
  '本补丁只放行白名单，不改变 Bouncer 其余校验（超时踢 / 禁用检查等）',
]

async function applyInner(ctx) {
  const app = ctx.webServer.app
  const admin = [ctx.auth.verifyAuth(), ctx.auth.requireAdmin()]

  /**
   * 取每台服务器的下发状态。
   * ctx.servers.list() 与 ctx.plugins.listForServer() 都是 async；
   * 注册表服务缺失或单台查询失败时降级为 unknown，不让整个接口 500。
   */
  async function collectServers() {
    let list = []
    try {
      list = (await ctx.servers.list()) || []
    } catch (err) {
      console.error('[patch1458] 读取服务器列表失败: ' + err.message)
      return []
    }

    const out = []
    for (const s of list) {
      let state = 'unknown'
      let online = null
      try {
        const rows = await ctx.plugins.listForServer(String(s.id))
        const row = (rows || []).find((r) => r && r.name === SELF)
        if (row) {
          state = row.state || 'never'
          online = typeof row.online === 'boolean' ? row.online : null
        }
      } catch (err) {
        state = 'unknown'
      }
      out.push({
        id: s.id,
        name: s.name,
        // loaded = 已下发且回执成功；pending = 已下发等待回执
        // unloaded = 未下发；never = 从未操作；error:... = 下发失败；offline = 服务器无下行通道
        dllState: state,
        online,
        active: state === 'loaded',
      })
    }
    return out
  }

  // 补丁状态总览：补丁表 + 各服下发状态
  app.get('/api/patch1458/status', ...admin, async (req, res) => {
    try {
      const servers = await collectServers()
      res.json({
        name: SELF,
        version: PKG_VERSION,
        deployMode: 'ask',
        gameHalf: {
          command: CHAT_COMMAND,
          permission: GAME_PERMISSION,
          note: '注入状态只能由游戏服半回答（白名单是 TShock 进程内私有字段），请在游戏内执行 ' + CHAT_COMMAND + ' 查看',
        },
        buffs: PATCH_BUFFS,
        knownLimits: KNOWN_LIMITS,
        servers,
        summary: {
          total: servers.length,
          active: servers.filter((s) => s.active).length,
        },
      })
    } catch (err) {
      res.status(500).json({ error: err.message })
    }
  })

  console.log(
    `[patch1458] 1458 临时补丁已挂载 v${PKG_VERSION}（宿主侧只读状态；`
    + `补丁本体为游戏服半 Patch1458.dll，deploy=ask：安装时弹窗选择下发服务器）`
  )

  // cordis dispose effect：本插件没有定时器/文件句柄需要回收，路由由注册表按归属自动摘除
  return () => {
    console.log('[patch1458] 已卸载（宿主侧状态接口已移除；游戏服侧 DLL 由 undeploy 控制）')
  }
}

export async function apply(ctx, options = {}) {
  // inject 会让 apply 延迟执行，且其中抛出的异常不会被加载器捕获（表现为"加载成功但什么都没注册"），
  // 因此按《插件开发约定》2.2 自行包一层 try/catch 并打印。
  try {
    return await applyInner(ctx, options)
  } catch (err) {
    console.error('[patch1458] 初始化失败: ' + err.message)
    if (process.env.TSWEB_DEBUG) console.error(err.stack)
    throw err
  }
}
