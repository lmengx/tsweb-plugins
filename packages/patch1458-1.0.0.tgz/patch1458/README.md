# patch1458 —— 1.4.5.8 内容兼容补丁

修复 **TShock 的 NPC buff 白名单未收录 Terraria 1.4.5.8 新增 debuff** 导致**合法玩家被误踢**的问题。

## 症状

使用 1.4.5.8 新内容时，玩家被服务器踢出，提示类似：

```
给 NPC：敌怪 异常添加了buff
```

典型触发：装备 1.4.5.8 新饰品 **催化手环（Catalyst Band）** 后，任意玩家弹幕命中敌怪即触发
`Projectile.StatusNPC → NPC.AddBuff(398, 300)`，客户端必发 53 号包（AddNPCBuff），
而服务器白名单里没有 398 → 误踢。

## 根因

TShock `Bouncer.OnNPCAddBuff` 对客户端 53 号包做**静态白名单**校验：

```
buffType ∉ NPCAddBuffTimeMax  →  Kick("Added buff to ... NPC abnormally.")
```

`NPCAddBuffTimeMax` 是按 1.4.4 / 早期 1.4.5 原版数值抄死的 33 项字典，
**1.4.5.8 新增的 5 个 NPC debuff 全部缺席**。

## 修法

反射取出 `Bouncer.NPCAddBuffTimeMax`（private static），注入下表 5 项：

| buff id | 名称 | 时长上限（tick） | 依据 |
|---------|------|------------------|------|
| 395 | PotentAcids 强酸 | 120 | 诅咒涂层 60；弹幕 282/283 为 120 |
| 397 | ChlorophyteSpore 叶绿孢子 | 300 | 弹幕 1127 固定 300 |
| 398 | AcceleratePoisons 催化毒液 | 300 | 催化手环固定 300（唯一调用点，误踢主因） |
| 399 | BlueLightning 蓝闪电 | 420 | 弹幕 1117 为 60*rand(4,8) |
| 400 | RedLightning 红闪电 | 420 | 弹幕 1122 为 60*rand(4,8) |

不改任何包处理流程，Bouncer 其余防护（超时踢 / 城镇 NPC / 禁用检查）原样保留。
`Dispose` 时**只移除本插件注入的条目**，官方已有条目一律不动，可安全热重载。

## 已知不覆盖

城镇 NPC 的 debuff 白名单是 TShock 内**硬编码的 BuffID if 链**（非集合），无法用字典注入扩展，
因此催化手环等对城镇 NPC 施加新 debuff 仍会被踢。玩家主动攻击城镇 NPC 属边缘场景；
如确需放行须改 TShock 源码或 Harmony patch（本插件刻意不做）。

## 安装与下发

本插件声明 `tsweb.deploy = "ask"`：

1. 在市场页安装本插件
2. 因为含游戏服半 DLL，前端会**弹窗让你勾选要下发到哪些服务器**
3. 确认后 DLL 经 SSE 下发，由 `TsWebHost` 落盘 `ServerPlugins/tsweb/patch1458/` 并反射热加载

也可以在「插件下发」页逐服手动启用/禁用；**卸载时会自动从所有已下发的服务器撤下 DLL**。

## 生效确认

注入状态只能由游戏服半回答（白名单是 TShock 进程内私有字段）。在游戏内执行：

```
/patch1458
```

权限 `patch1458.use`（首次加载时自动授予 admin 组）。输出会逐条列出 5 个 buff 的状态：
`已注入` / `官方已收录` / `缺失 → 未生效`。

面板侧另提供 `GET /api/patch1458/status`（admin 鉴权）：返回补丁表与**每台服务器的 DLL 下发状态**，
用于安装后确认"哪些服生效了"。

## C# 半构建

```bash
cd plugins/patch1458/plugin
dotnet build -c Release
# 产物：bin/Release/net9.0/Patch1458.dll → 复制到 plugin/Patch1458.dll
```

`Patch1458.csproj` 直接引用服务器同版 API（`../../../../TsWeb/plugin/api/*.dll`，与 online-stats 一致），
不依赖 NuGet 上的 TShock 包，保证与目标服务器 API 版本一致。

打包时 `.cs/.csproj/.pdb` 会被 `pack-plugin.mjs` 自动排除，**包内只含已构建的 DLL**。
