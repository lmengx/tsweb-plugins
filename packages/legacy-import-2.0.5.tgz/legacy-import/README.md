# 旧版 QQ 数据导入

旧版 Koishi/TsWeb 使用的绑定表位置是：

```text
C:\Users\lyt\Documents\GitHub\TsWeb\TsWeb\backend\data\qq_accounts.json
```

本地开发实例的导入副本位置是：

```text
C:\Users\lyt\Documents\GitHub\TsWeb\tsweb-cordis\data\legacy-import\qq_accounts.json
```

管理面打开“旧版数据导入”，选择模块“旧版 QQ 台账”，先执行试运行，再执行正式导入。导入会写入统一的 QQ 服务（`qq-serve`）台账，不会覆盖已有角色或 QQ 冲突记录。

本次删除旧版原表前的完整备份位置是：

```text
C:\Users\lyt\Documents\GitHub\TsWeb\tsweb-cordis\data\migration-backups\qq_accounts.json.before-delete-20261026-202527.json
```

## 旧版投票（2.0.5+）

先启用 vote 2.0.3 或更新版本，然后打开「数据导入 → 旧版投票」。上传旧文件，先预览、确认数量和错误，再正式导入。

- 开发目录：旧版 TsWeb 项目的 `backend/data/votes.json`。
- 部署目录直接包含 `services`、`data`、`package.json` 时：取同级 `data/votes.json`。
- 如果旧服务设置 `TSWeb_VOTES_PATH`：取它指向的文件。
- 这是面板后端数据，不在游戏服 `tshock/tsweb` 目录，不是插件 DLL 或 `config.json`。文件内容必须包含 `rounds` 和 `votes` 两个数组。

浏览器选择文件时先将远程旧文件下载到本机；无需把旧文件放进新版插件目录。使用服务端文件模式时，只可读取 `data/legacy-import` 下手动放入的副本。

仅空投票库可导入，保留轮次 ID、选项、提案、选票、历史分值、结束及归档状态。预览不修改投票数据，确认时重新校验并原子落盘。已有数据、无效引用或格式错误会明确拒绝，不覆盖、不静默跳过，不自动寻找或迁移旧文件。
