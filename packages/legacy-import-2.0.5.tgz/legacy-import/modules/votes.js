import { httpError, optionalService } from './registry.js'

export const VOTES_SOURCE_HINT = '在旧版 TsWeb 后端目录获取 backend/data/votes.json；如果部署目录直接包含 services、data、package.json，则取该目录下的 data/votes.json。设置了 TSWeb_VOTES_PATH 时，取该环境变量指定的文件。文件应包含 rounds 和 votes 两个数组，不是 TShock 的 tshock/tsweb 配置。请先下载旧文件，再在此选择文件。'

export function parseVotes(input = {}) {
  let source = input.data ?? input.text
  if (typeof source === 'string') {
    try { source = JSON.parse(source.replace(/^\uFEFF/, '')) }
    catch { throw httpError(400, '请选择旧版 backend/data/votes.json：内容不是合法 JSON') }
  }
  if (!source || !Array.isArray(source.rounds) || !Array.isArray(source.votes)) {
    throw httpError(400, '旧投票文件应包含 rounds 和 votes 数组；请从旧版后端的 backend/data/votes.json 获取')
  }
  return source
}

export function createVotesModule() {
  return {
    id: 'votes', title: '旧版投票', owner: 'legacy-import', builtin: true,
    description: '导入旧版投票轮次、选项、提案、历史选票和分值；保留结束与归档状态。仅空投票库允许导入，预览不写入数据。',
    sourceHint: VOTES_SOURCE_HINT,
    check: ctx => ({
      available: typeof optionalService(ctx, 'vote')?.importData === 'function',
      reason: '请安装并启用 vote 2.0.3 或更新版本', missingPlugin: 'vote',
    }),
    async run(input, { ctx, actor, dryRun = false }) {
      const vote = optionalService(ctx, 'vote')
      if (typeof vote?.importData !== 'function') throw httpError(501, '请安装并启用 vote 2.0.3 或更新版本', { missingPlugin: 'vote' })
      const source = parseVotes(input)
      const counts = await vote.importData(source, actor, { dryRun })
      const appliedCount = counts.rounds + counts.votes
      const voteCounts = new Map()
      for (const ballot of source.votes) voteCounts.set(ballot.roundId, (voteCounts.get(ballot.roundId) || 0) + 1)
      return {
        imported: source.rounds.map(round => ({ id: round.id, title: round.title, votes: voteCounts.get(round.id) || 0 })),
        skipped: [], conflicts: [], applied: !dryRun && appliedCount > 0,
        ...(!dryRun ? { appliedCount } : {}), counts,
        note: `共 ${counts.rounds} 轮投票、${counts.votes} 张选票；${dryRun ? '仅预览，未写入投票库' : '导入完成'}。历史分值保留，不重新计算。`,
      }
    },
  }
}
