const revision = new URL(import.meta.url).search;
const { default: access } = await import(`./access.js${revision}`);
const { GameplayService } = await import(`./service.js${revision}`);
export const name = 'gameplay-settings';
export const inject = ['webServer', 'auth', 'servers', 'tshock'];
export function apply(ctx) {
  try {
    const service = new GameplayService(ctx), controllers = new Set();
    const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx);
    ctx.on('dispose', () => { service.disposed = true; for (const c of controllers) c.abort(); });
    const route = handler => async (req, res) => {
      const controller = new AbortController(); controllers.add(controller);
      const closed = () => { if (!res.writableFinished) controller.abort(); };
      res.on('close', closed);
      try { const result = await handler(req, controller.signal); if (!res.destroyed) res.json(result); }
      catch (err) { if (!res.headersSent && !res.destroyed) res.status(err.status || 502).json({ error: err.message }); }
      finally { controllers.delete(controller); res.off('close', closed); }
    };
    const actor = req => String(req.user?.username || req.auth?.username || '面板管理员');
    app.get('/api/gameplay-settings/config', route((req, signal) => service.call(req.headers['x-server-id'], 'config', {}, signal)));
    app.get('/api/gameplay-settings/status', route((req, signal) => service.call(req.headers['x-server-id'], 'status', {}, signal)));
    app.post('/api/gameplay-settings/config', route((req, signal) => service.save(req.headers['x-server-id'], req.body, actor(req), signal)));
    app.post('/api/gameplay-settings/teams/reset', route((req, signal) => service.reset(req.headers['x-server-id'], req.body, actor(req), signal)));
    app.post('/api/gameplay-settings/teams/assign', route((req, signal) => service.assign(req.headers['x-server-id'], req.body, actor(req), signal)));
    app.get('/api/gameplay-settings/operations/:operationId', route((req, signal) => {
      if (!/^[a-zA-Z0-9-]{16,80}$/.test(req.params.operationId)) throw Object.assign(new Error('操作编号无效'), { status: 400 });
      return service.call(req.headers['x-server-id'], 'operation', { operationId: req.params.operationId }, signal);
    }));
  } catch (err) { console.error('[gameplay-settings] 初始化失败：' + err.message); throw err; }
}
