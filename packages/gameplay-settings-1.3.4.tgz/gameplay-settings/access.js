const actions = [
  ['read', 'GET', 'config'], ['save', 'POST', 'config'], ['status', 'GET', 'status'],
  ['reset', 'POST', 'teams/reset'], ['assign', 'POST', 'teams/assign'], ['operation', 'GET', 'operations/:operationId'],
].map(([id, method, suffix]) => ({ id: `gameplay-settings.${id}`, method,
  path: `/api/gameplay-settings/${suffix}`, module: 'gameplay-settings.manage', scope: 'server' }));
export default {
  owner: 'gameplay-settings', version: 2,
  modules: [{ id: 'gameplay-settings.manage', permission: 'gameplay-settings.manage', title: '玩法设置',
    roles: ['superadmin', 'admin', 'subadmin'], scope: 'server', requires: actions.map(a => a.id) }],
  actions, features: [{ id: 'gameplay-settings:manage', module: 'gameplay-settings.manage', requires: actions.map(a => a.id) }],
};
