// Module permissions authorize both UI features and their backend routes.
export default {
  "owner": "market",
  "version": 2,
  "modules": [
    {
      "id": "market.market",
      "permission": "market.ui.market",
      "title": "插件市场",
      "roles": [
        "superadmin"
      ],
      "scope": "global",
      "requires": [
        "market.get.market.list",
        "market.get.market.installed",
        "market.get.market.progress",
        "market.post.market.favorite",
        "market.post.market.refresh",
        "market.post.market.install",
        "market.post.market.update",
        "market.post.market.hostui",
        "market.post.market.enable",
        "market.post.market.deploy",
        "market.post.market.undeploy",
        "market.post.market.uninstall"
      ]
    }
  ],
  "actions": [
    {
      "id": "market.get.market.list",
      "method": "GET",
      "path": "/api/market/list",
      "scope": "global",
      "module": "market.market"
    },
    {
      "id": "market.get.market.installed",
      "method": "GET",
      "path": "/api/market/installed",
      "scope": "global",
      "module": "market.market"
    },
    {
      "id": "market.post.market.enable",
      "method": "POST",
      "path": "/api/market/enable",
      "scope": "global",
      "module": "market.market"
    },
    {
      "id": "market.post.market.deploy",
      "method": "POST",
      "path": "/api/market/deploy",
      "scope": "global",
      "module": "market.market"
    },
    {
      "id": "market.post.market.undeploy",
      "method": "POST",
      "path": "/api/market/undeploy",
      "scope": "global",
      "module": "market.market"
    },
    {
      "id": "market.post.market.hostui",
      "method": "POST",
      "path": "/api/market/host-ui",
      "scope": "global",
      "module": "market.market"
    },
    {
      "id": "market.get.market.progress",
      "method": "GET",
      "path": "/api/market/progress",
      "scope": "global",
      "module": "market.market"
    },
    {
      "id": "market.post.market.favorite",
      "method": "POST",
      "path": "/api/market/favorite",
      "scope": "global",
      "module": "market.market"
    },
    {
      "id": "market.post.market.refresh",
      "method": "POST",
      "path": "/api/market/refresh",
      "scope": "global",
      "module": "market.market"
    },
    {
      "id": "market.post.market.install",
      "method": "POST",
      "path": "/api/market/install",
      "scope": "global",
      "module": "market.market"
    },
    {
      "id": "market.post.market.update",
      "method": "POST",
      "path": "/api/market/update",
      "scope": "global",
      "module": "market.market"
    },
    {
      "id": "market.post.market.uninstall",
      "method": "POST",
      "path": "/api/market/uninstall",
      "scope": "global",
      "module": "market.market"
    }
  ],
  "features": [
    {
      "id": "market:market",
      "module": "market.market",
      "requires": [
        "market.get.market.list",
        "market.get.market.installed",
        "market.get.market.progress",
        "market.post.market.favorite",
        "market.post.market.refresh",
        "market.post.market.install",
        "market.post.market.update",
        "market.post.market.hostui",
        "market.post.market.enable",
        "market.post.market.deploy",
        "market.post.market.undeploy",
        "market.post.market.uninstall"
      ]
    }
  ]
}
