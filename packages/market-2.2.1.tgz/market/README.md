# 插件市场界面

界面采用选定的「原版留白」方案：居中圆角搜索、标签筛选、结果计数、数字分页，每页十二条。宽屏四列，普通桌面三列，平板两列，手机单列。卡片边框常驻，收藏点亮后显示黄色实心星星。保留全部插件和我的收藏，不显示安装数量概览。

浏览只展示市场索引中的条目，本地数据仅用于补充同名插件的安装状态和已安装版本，不混入本地独有插件或分类。搜索忽略大小写与首尾空格，覆盖包名、中文名、简述、完整描述、分类和作者名称；切换搜索或筛选后回到第一页。

界面使用宿主主题变量，支持浅色、深色与跟随系统。插件名称和收藏位于顶部，简述居中，版本、安装包大小、安装状态及安装/更新按钮位于底部。完整描述、作者、发布时间和已安装版本可在详情查看，不展示来源标识。

## 元数据与缺项

目前列表接口提供 name、version、description、author、tags、size、publishedAt、requires / missingDeps（依赖与缺失依赖），以及安装状态、来源和更新提示。author 可以是字符串或含 name 的对象；空作者和未知包大小不展示，未知大小不会显示为 0 KB。

参考图中的评分、评分人数、下载次数、认证状态、维护者列表及头像尚无对应接口字段或统计来源，因此不展示。当前本地 `tsweb-plugins/market.json` 的九个条目 author 均为空。插件图标与中文名称仍由前端映射维护，市场索引和列表接口没有可配置的图标或展示名称字段。补齐这些展示需要相应的索引字段、列表接口透传，以及下载/评分统计和认证规则，不能仅靠样式生成数据。

## 图标维护

`client/core/plugin-presentation.js` 的 `presentations` 按插件包名配置中文展示名称、图标名和卡片简述 `summary`，市场与已安装页面共用；`ui/presentation.js` 保留兼容导出。详情保留市场原始描述。`iconPaths` 保存静态 SVG 路径，由 `ui/MarketIcon.vue` 渲染。新插件没有配置时显示原包名、默认包裹图标与原始描述。没有后台图标上传入口。侧边栏图标配置独立，不改变市场卡片图标。

修改共享映射后执行 `node scripts/build-client.mjs web market`，使宿主与市场同步更新，或通过既有插件打包流程构建。

## 安装与管理

未安装显示安装；已安装显示安装状态，有新内容时保留更新按钮。市场卡片和详情都不提供禁用或卸载，相关管理由既有已安装插件页面处理。安装、更新与收藏沿用现有接口和错误提示，提交期间阻止重复操作。

## 依赖（tsweb.requires）

插件可以声明 `tsweb.requires`（发布时写入索引，列表接口透出 `requires` / `missingDeps`）。安装或更新前由服务端解析依赖闭包：

- 本机缺依赖时，卡片显示「需依赖 N」标记；点安装/更新**先弹窗**列出依赖（名称、版本、包大小），确认前**不下载任何包**；
- 确认后带 `installDeps: true` 重试：服务端按"被依赖者在前"安装依赖并自动启用，再装目标；结果提示注明"已先处理依赖"；
- 无依赖的插件保持一键安装（请求里 `installDeps: false`）；
- 依赖已装但被禁用 → 自动启用，不重装；
- 卸载被依赖的插件会被注册表拒绝并点名依赖方（例如卸 world-preview 前要先处理 history / house）。

世界预览自 base 2.4.0 起是独立插件 `world-preview`：`history` 与 `house` 声明 `requires: ["world-preview"]`，安装它们时会先弹窗下载世界预览（约 9.1 MB，含 1138 张图格贴图）。

## 镜像与下载

市场内容托管在自建 **Cloudflare R2**（桶 `tlry-plugins`，与 `mods-market` 同一套架构：R2 桶 + 自定义域直出，包不经过 Worker）。键与仓库目录一致：`/market.json` 与 `/packages/<file>.tgz`，公开基址 **`https://cdn.plugin.tlry.me`**。

**这是唯一来源**（2026-10-30 起）：`github`（raw.githubusercontent.com）与 `ghproxy` 已弃用——前者在国内解析到黑洞地址（TCP 不通），后者只是它的公共前缀代理（同一上游、同一失败）；Gitee 镜像更早因 CI 从未实现而移除。老配置 `mirrorOrder` 里残留的 `github`/`ghproxy`/`gitee` 会被 `MIRRORS` 过滤掉，不报错、无需迁移。

发布到 R2 的方式与 mods-market 一致（用本地已安装的 wrangler，不走 npx；本机已 `wrangler login`，无需再传 API Token）：

```powershell
& ..\mods-market\api\node_modules\.bin\wrangler.cmd r2 object put `
  "tlry-plugins/market.json" "--file=..\tsweb-plugins\market.json" `
  '--content-type=application/json; charset=utf-8' '--cache-control=public, max-age=60' --remote
# packages/*.tgz 逐个上传：--content-type=application/octet-stream --cache-control=public, max-age=31536000, immutable
```

## 已安装（第三个页签）

「全部插件 / 我的收藏 / **已安装**」三个页签。已安装页是本机视角：装了什么、各服推到哪一步。

- **页签与分页角标 = 可更新数量**：未进入页签时用市场列表近似（`list()` 的 `hasUpdate` 只对已安装成立），进入后以登记表对照为准；
- **可更新置顶**：列表按"可更新 → 已启用 → 名称"排序，页内用「可更新 · N 置顶」/「已是最新」分区切开（同一 grid，标题行 `grid-column: 1/-1`）；
- **每台服一格状态**：已加载 / 待重启 / 未下发 / 已撤下 / 失败 / 离线 / 无 DLL；
- **动作**：更新（`web` 走前端投放通道，其余走注册表更新）、启用·禁用、卸载（二次确认，写明数据保留）、下发…（就地展开勾选目标服，默认勾"还没成功下发"的，已加载的默认不勾）；
- 数据一次取齐：`GET /api/market/installed`，内部调注册表**服务**（`ctx.plugins`），不用「已安装插件」页的 HTTP 路由——那套属于另一个权限域。

两条硬约束：

1. **面板自身依赖的插件不能从界面停用**（`accounts` / `servers` / `web` / `market`）。registry 只对卸载有门禁、对禁用没有；停掉 market 会 dispose 掉它自己注册的路由，当前请求连回话通道都没了。`setEnabled` 里直接 409 拒绝，启用不受限。
2. **`web` 的"已装版本"取前端投放记录**（`config.hostUi.version`），不是登记版本——两者在登记里恒等，用登记版本会让它永远显示"已是最新"。相应的 `canUpdate` 对 `web` 特判为真（注册表门禁本来拒绝它）。

## 宿主前端投放（`POST /api/market/host-ui`）

面板前端（页面、组件、样式）不是独立插件，而是 `web` 插件的 `public/`——`pack-plugin.mjs` 打包 `web` 时用 `buildHost` 把它现构建进包（约 914 KB 原始 / 267 KB 压缩），所以 **`web` 包就是一份完整的宿主前端**。

`canUpdate('web')` 在宿主里是 false（`src/plugin-gates.js` 的 `BUILTIN`）：换掉自带插件的后端半会打断正在跑的静态服务与侧边栏路由。但"添加服务器向导 / 初始化弹窗"这类改动全在静态资源里，因此市场另开一条投放通道：

1. 从索引取 `web` 条目，下载并按索引 `sha256` 复算校验；
2. 只解出包内 `public/**`，后端文件（`index.js` 等）一律不落盘；
3. 落盘前校验清单：`index.html`、`sdk.js`、`assets/` 下至少一个 `.js` 且 `index.html` 引用它；
4. 旧目录改名成 `public.bak-<时间戳>` → 原子换入新目录，任一步失败自动还原；
5. 投放记录（版本 / sha256 / 备份路径）写进 `<dataDir>/market/config.json` 的 `hostUi`，市场页据此显示"当前前端 vX / 可更新到 vY"。

要点：

- 投放成功后**刷新页面**生效，不需要重启面板、不需要重发整包；
- 发行包重建（`make-dist` / Windows 发行）会把 `plugins/web/public/` 覆盖回自带版本，届时再点一次「更新前端」即可；
- 市场页把 `web` 与 `base`、`market` 一起放在「宿主与核心组件」区，徽标是「前端 bundle」，按钮是「更新前端」——**不要**用普通「更新」，那条路会被门禁 403。

下载相关配置（`<dataDir>/market/config.json`）：

| 键 | 默认 | 说明 |
|---|---|---|
| `mirrorOverride` | 空 | 非空时**只用**它作为基址（基址下就是 `market.json` 和 `packages/...`），适合指向自建镜像或本地联调 |
| `timeoutMs` | 20000 | 拉索引的超时（索引只有几十 KB，短超时便于快速切镜像）。**2.0.3 及更早版本用它同时约束安装包下载**，老版本必须调大才能下 10 MB 级发行包（如 world-preview） |
| `packageTimeoutMs` | 180000 | 2.0.4 起生效：下载发行包的下限超时；实际取它与 `size / 32 KB/s` 的较大者 |

下载失败会写服务器日志（含镜像名、耗时、原因），并在市场页用警示横幅显示，不再只有一闪而过的 toast。



市场索引里的 `market`（市场自身）与 `base`（核心件）不与普通业务插件共用一套提示，因为它们的生效语义不同：

| 项目 | 徽标 | 更新按钮 | 执行前 | 更新后 |
|---|---|---|---|---|
| `market` | 市场自身 | 更新市场 | 弹确认框：服务端半热重载生效、当前页面仍是旧界面、期间勿并行更新其它插件 | 持久横幅「插件市场已更新到 vX」+「刷新页面」按钮，不再重拉列表 |
| `base` | 核心件 | 更新核心件 | 弹确认框：面板半刷新后生效、游戏服 Base.dll 会重新按哈希同步、接收端不随插件更新、其它插件与数据不受影响 | 持久横幅「基础功能已更新到 vX」+ 同步失败台数（若有，黄框）+「刷新页面」按钮 |

结果横幅是页面内元素而非 toast：toast 会被随后的加载/失败提示覆盖，而"要不要刷新页面"必须一直看得见。`deployFailed` 非空时横幅转为警告样式并写明台数，落回普通提示的只有那些既无前端半、也无部署失败的更新。

后端配合点：`GET /api/market/list` 给市场条目带 `self`、给 base 带 `core`；`base` 属于"可更新的内置插件"，判定收口在 `src/plugin-gates.js`（`UPDATABLE_BUILTIN`），所以它能从市场更新，但仍不可卸载。

验证：`node --test plugins/market/test/update-gate.test.mjs plugins/market/test/market-ui.test.mjs plugins/market/test/deploy-failure.test.mjs`。
