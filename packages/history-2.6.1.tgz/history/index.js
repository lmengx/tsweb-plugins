import access from "./access.js?v=2.6.1-retention";
import { HistoryService } from "./service.js?v=2.6.1-retention";
export const name = "history";
export const inject = ["webServer", "auth", "servers", "tshock", "worldMap"];
export function apply(ctx) {
  const service = new HistoryService(ctx);
  const app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx);
  const wrap =
    (suffix, write = false) =>
    async (req, res) => {
      try {
        res.json(await service.call(req, suffix, write));
      } catch (err) {
        res.status(err.status || 502).json({ error: err.message });
      }
    };
  app.get("/api/history/retention", wrap("retention"));
  app.post("/api/history/retention/set", wrap("retention/set", true));
  app.get("/api/history/status", wrap("status"));
  app.get("/api/history/players", wrap("players"));
  app.get("/api/history/catalog", wrap("catalog"));
  app.get("/api/history/map", wrap("map"));
  app.get("/api/history/map-task", wrap("map-task"));
  app.get("/api/history/map-chunk", wrap("map-chunk"));
  app.get("/api/history/map-tile", wrap("map-tile"));
  app.get("/api/history/task", wrap("task"));
  app.get("/api/history/events", wrap("events"));
  app.post("/api/history/query", wrap("query", true));
  app.post("/api/history/preview", wrap("preview", true));
  app.post("/api/history/execute", wrap("execute", true));
  app.post("/api/history/cancel", wrap("cancel", true));
  app.post("/api/history/undo", wrap("undo", true));
  ctx.effect(() => () => {
    service.disposed = true;
  });
}
