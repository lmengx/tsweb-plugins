const reads = [
  ["retention", "GET", "retention"],
  ["status", "GET", "status"],
  ["players", "GET", "players"],
  ["catalog", "GET", "catalog"],
  ["map", "GET", "map"],
  ["map-task", "GET", "map-task"],
  ["map-chunk", "GET", "map-chunk"],
  ["map-tile", "GET", "map-tile"],
  ["query", "POST", "query"],
  ["task", "GET", "task"],
  ["events", "GET", "events"],
].map(([id, method, suffix]) => ({
  id: `history.${id}`,
  method,
  path: `/api/history/${suffix}`,
  module: "history.read",
  scope: "server",
}));
const writes = ["preview", "execute", "cancel", "undo"].map((id) => ({
  id: `history.${id}`,
  method: "POST",
  path: `/api/history/${id}`,
  module: "history.rollback",
  scope: "server",
}));
const manage = {
  id: "history.retention.set",
  method: "POST",
  path: "/api/history/retention/set",
  module: "history.manage",
  scope: "server",
};
export default {
  owner: "history",
  version: 2,
  modules: [
    {
      id: "history.manage",
      permission: "history.manage",
      title: "历史自动清理设置",
      roles: ["superadmin", "admin"],
      scope: "server",
      requires: [...reads.map((a) => a.id), manage.id],
    },
    {
      id: "history.read",
      permission: "history.read",
      title: "地图编辑查询",
      roles: ["superadmin", "admin"],
      scope: "server",
      requires: reads.map((a) => a.id),
    },
    {
      id: "history.rollback",
      permission: "history.rollback",
      title: "地图编辑回退",
      roles: ["superadmin", "admin"],
      scope: "server",
      requires: [...reads, ...writes].map((a) => a.id),
    },
  ],
  actions: [...reads, ...writes, manage],
  features: [
    {
      id: "history:manage",
      module: "history.manage",
      requires: [...reads.map((a) => a.id), manage.id],
    },
    {
      id: "history:browse",
      module: "history.read",
      requires: reads.map((a) => a.id),
    },
    {
      id: "history:rollback",
      module: "history.rollback",
      requires: [...reads, ...writes].map((a) => a.id),
    },
  ],
};
