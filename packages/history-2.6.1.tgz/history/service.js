import { createHmac } from "node:crypto";
export const error = (status, message) =>
  Object.assign(new Error(message), { status });
const idPattern = /^[a-f0-9]{32}$/i;
const id = (value) => {
  if (typeof value !== "string" || !idPattern.test(value))
    throw error(400, "操作编号无效");
  return value;
};
export function filter(input) {
  if (
    !input ||
    typeof input !== "object" ||
    (input.account != null &&
      (typeof input.account !== "string" || input.account.length > 128)) ||
    (!input.account && !Array.isArray(input.accounts))
  )
    throw error(400, "请选择玩家");
  const { from, to } = input;
  if (
    !Number.isSafeInteger(from) ||
    !Number.isSafeInteger(to) ||
    from < 0 ||
    to <= from ||
    to - from > 366 * 86400000
  )
    throw error(400, "请选择一年以内的有效时间范围");
  if (!["before", "after", "either"].includes(input.match || "either"))
    throw error(400, "方块匹配方式无效");
  const result = {
    world: "",
    account: input.account || "",
    from,
    to,
    match: input.match || "either",
  };
  const domain = input.domain || "map";
  if (!["map", "chest"].includes(domain)) throw error(400, "日志类型无效");
  result.domain = domain;
  if (input.ignoreWorld != null && typeof input.ignoreWorld !== "boolean") throw error(400, "世界变动筛选无效");
  result.ignoreWorld = domain === "map" && input.ignoreWorld === true;
  if (input.items != null) {
    if (
      !Array.isArray(input.items) ||
      input.items.length > 100 ||
      input.items.some((i) => !Number.isInteger(i) || i < 1 || i > 65535)
    )
      throw error(400, "物品标签无效");
    result.items = [...new Set(input.items)];
  }
  if (!["include", "exclude"].includes(input.itemMode || "include"))
    throw error(400, "物品筛选方式无效");
  result.itemMode = input.itemMode || "include";
  for (const name of ["tile", "style", "wall"]) {
    const value = input[name];
    if (
      value != null &&
      (!Number.isInteger(value) || value < 0 || value > 65535)
    )
      throw error(400, "方块或样式 ID 无效");
    result[name] = value ?? null;
  }
  for (const key of ["accounts", "blocks", "actions"]) {
    if (input[key] == null) continue;
    if (!Array.isArray(input[key]) || input[key].length > 100)
      throw error(400, "筛选标签过多或无效");
    if (key === "accounts") {
      if (input[key].some((v) => typeof v !== "string" || !v || v.length > 128))
        throw error(400, "玩家标签无效");
      result[key] = [...new Set(input[key])];
    } else if (key === "actions") {
      if (
        input[key].some(
          (v) =>
            !(
              domain === "chest"
                ? [
                    "打开",
                    "关闭",
                    "存入",
                    "取出",
                    "修改物品",
                    "改名",
                    "扩容/缩容",
                    "放置箱子",
                    "拆除箱子",
                    "锁状态",
                  ]
                : ["放置", "拆除", "替换", "涂色", "其他"]
            ).includes(v),
        )
      )
        throw error(400, "操作标签无效");
      result[key] = [...new Set(input[key])];
    } else {
      result[key] = input[key].map((v) => {
        if (!v || typeof v !== "object" || Array.isArray(v))
          throw error(400, "方块标签无效");
        const block = {};
        for (const name of ["tile", "style", "wall"]) {
          if (v[name] != null) {
            if (!Number.isInteger(v[name]) || v[name] < 0 || v[name] > 65535)
              throw error(400, "方块标签无效");
            block[name] = v[name];
          }
        }
        if (block.tile == null && block.wall == null)
          throw error(400, "方块标签缺少编号");
        return block;
      });
    }
    const mode =
      input[
        { accounts: "accountMode", blocks: "blockMode", actions: "actionMode" }[
          key
        ]
      ] || "include";
    if (!["include", "exclude"].includes(mode))
      throw error(400, "标签筛选方式无效");
    result[
      { accounts: "accountMode", blocks: "blockMode", actions: "actionMode" }[
        key
      ]
    ] = mode;
  }
  return result;
}
export function bounds(value) {
  if (
    !value ||
    ["x", "y", "width", "height"].some((k) => !Number.isInteger(value[k])) ||
    value.x < 0 ||
    value.y < 0 ||
    value.width < 1 ||
    value.height < 1 ||
    value.x + value.width > 32768 ||
    value.y + value.height > 32768 ||
    value.width * value.height > 1000000
  )
    throw error(400, "框选范围无效或过大");
  return Object.fromEntries(
    ["x", "y", "width", "height"].map((k) => [k, value[k]]),
  );
}
export class HistoryService {
  constructor(ctx) {
    this.ctx = ctx;
    this.disposed = false;
  }
  async call(req, suffix, write = false) {
    if (this.disposed) throw error(503, "History 正在卸载");
    if (suffix === "map" || suffix === "map-task" || suffix === "map-chunk" || suffix === "map-tile") {
      const coordinate = (value) => {
        if (typeof value !== "string" || !/^\d{1,4}$/.test(value))
          throw error(400, "区块坐标无效");
        return Number(value);
      };
      const data = await this.ctx.worldMap.call(
        req,
        suffix === "map-task" ? id(req.query?.taskId) : undefined,
        suffix === "map-chunk" || suffix === "map-tile"
          ? { [suffix === "map-tile" ? "tile" : "chunk"]: { mapId: id(req.query?.mapId), cx: coordinate(req.query?.cx), cy: coordinate(req.query?.cy), ...(suffix === "map-tile" ? { lod: coordinate(req.query?.lod) } : {}) } }
          : { stream: true, refresh: req.query?.refresh === "1" },
      );
      if (this.disposed) throw error(503, "History 正在卸载");
      return data;
    }
    const serverId =
      req.headers["x-server-id"] ||
      req.query?.serverId ||
      req.user?.serverId ||
      req.user?.extraServerIds?.[0];
    if (typeof serverId !== "string" || !serverId)
      throw error(400, "请先选择服务器");
    const server = this.ctx.servers.getRaw(serverId);
    if (!server) throw error(404, "服务器不存在");
    if (!req.user?.username) throw error(401, "请重新登录");
    const owner = createHmac(
      "sha256",
      server.token || server.pushSecret || "history-local",
    )
      .update(
        JSON.stringify([
          "history-v2",
          serverId,
          req.user.username.toLowerCase(),
        ]),
      )
      .digest("hex");
    const body = req.body || {},
      query = req.query || {};
    let payload = {},
      params = { owner, actor: req.user.username };
    switch (suffix) {
      case "retention/set":
        if (!Number.isInteger(body.retentionDays) || body.retentionDays < 1 || body.retentionDays > 3650)
          throw error(400, "自动清除时间须为 1 至 3650 天的整数");
        payload = { retentionDays: body.retentionDays };
        break;
      case "query":
        payload = filter(body);
        break;
      case "preview":
        payload = { queryId: id(body.queryId), bounds: bounds(body.bounds) };
        if (body.eventIds != null) {
          if (
            !Array.isArray(body.eventIds) ||
            !body.eventIds.length ||
            body.eventIds.length > 512 ||
            body.eventIds.some((v) => !Number.isSafeInteger(v) || v < 1)
          )
            throw error(400, "编辑记录选择无效");
          payload.eventIds = [...new Set(body.eventIds)];
        }
        if (body.groupIds != null) {
          if (
            body.eventIds != null ||
            !Array.isArray(body.groupIds) ||
            !body.groupIds.length ||
            body.groupIds.length > 512 ||
            body.groupIds.some(
              (v) => typeof v !== "string" || !/^[a-f0-9]{64}$/.test(v),
            )
          )
            throw error(400, "箱子分组选择无效");
          payload.groupIds = [...new Set(body.groupIds)];
        }
        if (body.chestEdits != null) {
          if (
            body.eventIds != null ||
            body.groupIds != null ||
            !Array.isArray(body.chestEdits) ||
            !body.chestEdits.length ||
            body.chestEdits.length > 1024 ||
            body.chestEdits.some(
              (p) =>
                !p ||
                typeof p !== "object" ||
                typeof p.groupId !== "string" ||
                !/^[a-f0-9]{64}$/.test(p.groupId) ||
                !Number.isSafeInteger(p.eventId) ||
                p.eventId < 1 ||
                (p.slot != null &&
                  (!Number.isInteger(p.slot) || p.slot < 0 || p.slot > 254)),
            )
          )
            throw error(400, "箱子槽位选择无效");
          payload.chestEdits = body.chestEdits.map((p) => ({
            groupId: p.groupId,
            eventId: p.eventId,
            slot: p.slot ?? null,
          }));
        }
        break;
      case "execute": {
        const force = body.force ?? {};
        if (
          typeof force !== "object" ||
          Array.isArray(force) ||
          Object.keys(force).length > 512 ||
          Object.entries(force).some(
            ([k, v]) =>
              !idPattern.test(k) ||
              typeof v !== "string" ||
              !/^[a-f0-9]{64}$/i.test(v),
          )
        )
          throw error(400, "强制覆盖选择无效");
        payload = {
          planId: id(body.planId),
          requestId: id(body.requestId),
          force,
          confirmItems: body.confirmItems === true,
        };
        break;
      }
      case "undo":
      case "cancel":
        payload = { taskId: id(body.taskId) };
        break;
      case "task":
        params.taskId = id(query.taskId);
        break;
      case "events": {
        params.queryId = id(query.queryId);
        const offset = Number(query.offset || 0);
        if (!Number.isInteger(offset) || offset < 0 || offset > 250000)
          throw error(400, "分页位置无效");
        params.offset = offset;
        break;
      }
    }
    if (payload.chestEdits) {
      const capabilities = await this.ctx.tshock.fetchFor(
        server,
        "/data/history/status",
        params,
        { timeoutMs: 12000 },
      );
      if (this.disposed) throw error(503, "History 正在卸载");
      if (!capabilities.ok || capabilities.data?.chestSlotSelection !== true)
        throw error(
          409,
          "游戏服尚未支持精确槽位回退，请等待 History.dll 2.4.0 同步完成后重试",
        );
    }
    let response;
    try {
      response = write
        ? await this.ctx.tshock.postFor(
            server,
            `/data/history/${suffix}`,
            { ...params, payload: JSON.stringify(payload) },
            { encoding: "form", timeoutMs: 12000 },
          )
        : await this.ctx.tshock.fetchFor(
            server,
            `/data/history/${suffix}`,
            params,
            { timeoutMs: 12000 },
          );
    } catch (err) {
      throw error(502, "连接游戏服失败：" + err.message);
    }
    if (this.disposed) throw error(503, "History 正在卸载");
    const data = response.data,
      status = Number(data?.status || response.status);
    if (status === 401 || status === 403)
      throw error(502, "游戏服令牌需要 history.read、history.rollback 及配置所需的 history.manage 权限");
    if (status === 404 && !data?.error)
      throw error(501, "游戏服尚未启用 History.dll，请检查插件同步状态");
    if (!response.ok || !data || status >= 400 || data.error)
      throw error(
        [400, 404, 409, 503].includes(status) ? status : 502,
        data?.error || "History 返回无效结果",
      );
    return suffix === "status" ? { ...data, chestSlotProxy: true } : data;
  }
}
