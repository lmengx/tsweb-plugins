const groups = {
  houses: [
    ["config", "GET", "config"],
    ["config-save", "POST", "config"],
    ["list", "GET", "houses"],
    ["commands", "POST", "commands"],
    ["settings", "POST", "settings"],
    ["members", "POST", "members"],
    ["players", "GET", "players"],
    ["map", "GET", "map"],
    ["map-task", "GET", "map-task"],
    ["map-chunk", "GET", "map-chunk"],
    ["map-tile", "GET", "map-tile"],
  ],
  buildings: [
    ["files", "GET", "files"],
    ["preview", "GET", "preview"],
    ["preview-chunk", "GET", "preview/chunk"],
    ["download", "GET", "download"],
    ["export", "POST", "export"],
    ["transfer", "POST", "transfer"],
    ["import", "POST", "import"],
    ["delete", "POST", "delete"],
  ],
};
const actions = Object.entries(groups).flatMap(([module, entries]) =>
  entries.map(([id, method, suffix]) => ({
    id: `house.${id}`,
    module: `house.${module}`,
    method,
    path: `/api/house/${suffix}`,
    scope: "server",
  })),
);
export default {
  owner: "house",
  version: 2,
  modules: Object.keys(groups).map((id) => ({
    id: `house.${id}`,
    permission: `house.${id}`,
    title: id === "houses" ? "房屋管理" : "建筑存档",
    roles: ["superadmin", "admin"],
    scope: "server",
    requires: actions
      .filter((a) => a.module === `house.${id}`)
      .map((a) => a.id)
      .concat(
        id === "buildings"
          ? ["house.list", "house.players", "house.config"]
          : [],
      ),
  })),
  actions,
  features: Object.keys(groups).map((id) => ({
    id: `house:${id}`,
    module: `house.${id}`,
    requires: actions
      .filter((a) => a.module === `house.${id}`)
      .map((a) => a.id),
  })),
};
