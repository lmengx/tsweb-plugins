import fs from "node:fs/promises";
const revision = new URL(import.meta.url).search;
const { default: access } = await import(`./access.js${revision}`);
const { HouseService, fileName, fail } = await import(
  `./service.js${revision}`
);
export const name = "house";
export const inject = [
  "webServer",
  "auth",
  "servers",
  "tshock",
  "paths",
  "worldMap",
];
export function apply(ctx) {
  const service = new HouseService(ctx),
    controllers = new Set(),
    app = ctx.auth.access.policyApp(ctx.webServer.app, access, ctx);
  ctx.effect(() => () => {
    service.disposed = true;
    service.previews.clear();
    for (const c of controllers) c.abort();
  });
  const wrap = (handler) => async (req, res) => {
    const c = new AbortController();
    controllers.add(c);
    const close = () => {
      if (!res.writableFinished) c.abort();
    };
    res.on("close", close);
    try {
      const data = await handler(req, c.signal);
      if (!res.destroyed) res.json(data);
    } catch (e) {
      if (!res.headersSent && !res.destroyed)
        res.status(e.status || 500).json({ error: e.message });
    } finally {
      controllers.delete(c);
      res.off("close", close);
    }
  };
  const mutation = (req) => {
    if (
      typeof req.body?.world !== "string" ||
      !/^-?\d{1,12}$/.test(req.body.world)
    )
      throw fail(400, "世界信息已失效，请刷新");
    return { world: req.body.world };
  };
  const register = (method, suffix, handler) =>
    app[method]("/api/house/" + suffix, wrap(handler));
  register("get", "config", (r, s) => service.call(r, "config", {}, s));
  register("post", "config", (r, s) => {
    if (typeof r.body?.enabled !== "boolean") throw fail(400, "启用状态无效");
    return service.call(
      r,
      "config/set",
      { ...mutation(r), enabled: String(r.body.enabled) },
      s,
    );
  });
  register("get", "houses", (r, s) =>
    service.call(
      r,
      "list",
      {
        page: String(r.query.page || 1),
        pageSize: "100",
        query: String(r.query.query || ""),
      },
      s,
    ),
  );
  register("get", "players", (r, s) => service.call(r, "players", {}, s));
  register("post", "settings", (r, s) => {
    const settings = r.body?.settings;
    const fields = [
      "entry",
      "tp",
      "place",
      "break",
      "explosion",
      "liquid",
      "chest",
      "plant",
      "spawn",
      "grave",
      "switch",
      "door",
      "fragile",
      "expelOnViolate",
      "notifyEnter",
      "notifyBreakPlace",
    ];
    if (
      !settings ||
      Array.isArray(settings) ||
      typeof settings !== "object" ||
      !Object.keys(settings).length ||
      Object.keys(settings).length > fields.length ||
      Object.entries(settings).some(
        ([k, v]) => !fields.includes(k) || typeof v !== "boolean",
      )
    )
      throw fail(400, "房屋参数无效");
    if (typeof r.body.name !== "string" || !r.body.name.trim())
      throw fail(400, "请选择房屋");
    return service.call(
      r,
      "settings/save",
      { ...mutation(r), name: r.body.name, settings: JSON.stringify(settings) },
      s,
    );
  });
  register("post", "members", (r, s) => {
    const { name, role, action, accountName, accountId } = r.body || {};
    if (
      typeof name !== "string" ||
      !name.trim() ||
      !(role === "author"
        ? action === "transfer"
        : ["owner", "user"].includes(role) &&
          ["add", "remove"].includes(action))
    )
      throw fail(400, "成员操作无效");
    const target =
      action === "remove"
        ? typeof accountId === "string" &&
          /^[1-9]\d{0,9}$/.test(accountId) &&
          Number(accountId) <= 2147483647
        : typeof accountName === "string" &&
          !!accountName.trim() &&
          accountName.length <= 100;
    if (!target)
      throw fail(
        400,
        action === "remove" ? "账号编号无效" : "请填写完整的游戏账号名",
      );
    return service.call(
      r,
      "members/save",
      {
        ...mutation(r),
        name,
        role,
        action,
        ...(action === "remove"
          ? { accountId }
          : { accountName: accountName.trim() }),
      },
      s,
    );
  });
  register("post", "commands", (r, s) => {
    const list = r.body?.commands;
    if (
      !Array.isArray(list) ||
      list.length > 50 ||
      list.some(
        (c) =>
          !c ||
          typeof c.command !== "string" ||
          !c.command.trim() ||
          c.command.length > 512 ||
          ["enabled", "escape", "asSelf", "bypass"].some(
            (k) => typeof c[k] !== "boolean",
          ),
      )
    )
      throw fail(400, "进入指令无效：最多 50 条，每条 1–512 字符");
    return service.call(
      r,
      "commands/save",
      {
        ...mutation(r),
        name: String(r.body.name || ""),
        commands: JSON.stringify(list),
      },
      s,
    );
  });
  register("get", "files", (r, s) => service.list(r, r.query.source, s));
  register("get", "preview", (r, s) => service.preview(r, s));
  register("get", "preview/chunk", (r) => service.previewChunk(r));
  register("get", "download", async (r, s) => ({
    file: fileName(r.query.file),
    data: (await service.read(r, r.query.source, r.query.file, s)).toString(
      "base64",
    ),
  }));
  register("post", "transfer", (r, s) => {
    mutation(r);
    return service.transfer(r, fileName(r.body.file), s);
  });
  register("post", "export", async (r, s) => {
    const p = mutation(r);
    if (!["local", "backend"].includes(r.body.destination))
      throw fail(400, "导出目标无效");
    const result = await service.call(
      r,
      "buildings/export",
      { ...p, house: String(r.body.house || ""), author: r.user.username },
      s,
    );
    if (r.body.destination === "local") return result;
    try {
      return await service.transfer(r, fileName(result.file), s);
    } catch (e) {
      throw fail(
        e.status || 502,
        `${e.message}；导出文件已保留在服务器本地：${result.file}`,
      );
    }
  });
  register("post", "delete", async (r, s) => {
    const p = mutation(r),
      file = fileName(r.body.file);
    if (r.body.source === "local")
      return service.call(r, "buildings/delete", { ...p, file }, s);
    if (r.body.source !== "backend") throw fail(400, "存档来源无效");
    try {
      await fs.unlink(service.localPath(r, file));
    } catch (e) {
      if (e.code === "ENOENT") throw fail(404, "后端建筑文件不存在");
      throw e;
    }
    for (const [id, v] of service.previews)
      if (
        v.source === "backend" &&
        v.name === file &&
        v.server === service.server(r).id
      )
        service.previews.delete(id);
    return { success: true };
  });
  register("post", "import", async (r, s) => {
    const p = mutation(r),
      b = r.body,
      file = fileName(b.file);
    if (
      b.confirmed !== true ||
      !["player", "coords", "house"].includes(b.anchor) ||
      !["topLeft", "topRight", "bottomLeft", "bottomRight", "center"].includes(
        b.align,
      )
    )
      throw fail(400, "请确认导入位置、对齐及覆盖操作");
    return service.importSaved(
      r,
      {
        ...p,
        file,
        anchor: b.anchor,
        anchorPlayer: String(b.anchorPlayer || ""),
        anchorHouse: String(b.anchorHouse || ""),
        coords: String(b.coords || ""),
        align: b.align,
        confirmed: "1",
      },
      s,
    );
  });
  for (const suffix of ["map", "map-task", "map-chunk", "map-tile"])
    register("get", suffix, (r) => {
      if (suffix === "map")
        return ctx.worldMap.call(r, undefined, { stream: true });
      if (suffix === "map-task") return ctx.worldMap.call(r, r.query.taskId);
      const chunk = {
        mapId: r.query.mapId,
        cx: Number(r.query.cx),
        cy: Number(r.query.cy),
      };
      return ctx.worldMap.call(
        r,
        undefined,
        suffix === "map-tile"
          ? { tile: { ...chunk, lod: Number(r.query.lod) } }
          : { chunk },
      );
    });
}
