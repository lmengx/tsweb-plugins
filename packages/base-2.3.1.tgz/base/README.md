# Base

内置 Cordis 插件和 `Base.dll`，提供玩家、用户组管理及实时世界地图。

## SSC 即时切换（2.2.4）

Base 的 `GET/POST /api/base/ssc` 对应游戏服 `/data/base/ssc` 和 `/data/base/ssc/save`，不依赖文件管理。保存使用文件版本校验，只修改 `sscconfig.json` 的 `Settings.Enabled`，保留其他字段。

保存成功后同时更新 TShock 配置对象与 `Main.ServerSideCharacter`，无需重启，世界选择前也能应用。有世界时在游戏线程执行；线程超时的请求不会在之后补执行。开启时在线已登录玩家载入服务器角色（不把客户端物品导入 SSC），未登录玩家需先登录，尊重 `tshock.ignore.ssc`。关闭前保存符合 TShock 保存条件的在线角色，再同步客户端世界信息。角色保存失败会阻止关闭；角色同步失败明确报错并可重试，读回不能将未完成的同步误判成功。

## 通用图格预览（2.2.0）

`ui/world/` 统一提供 `world-renderer.js`、`WorldSnapshotLayer.vue`、`ClientMapLayer.vue`、`TilePreview.vue` 和共享区块加载器；静态贴图、元数据与帧规则在 `assets/world-v1/`，运行时入口为 `/plugins/base/assets/world-v1/`。调用方直接使用 Base 源模块，不需要安装 History。

`TilePreview` 接收 `{width,height,snapshot,map}` 及可选 `bounds: {x,y,width,height}`；`snapshot` 为 `tsweb-tiles-v1`，可由 `loadChunk(cx,cy,signal)` 惰性提供 gzip base64 内容。低精度使用 `map.base64` 或实时 `map.tiled/loadTile`，详细视图支持缩放、拖动、边界与失败重试。

Node 端 `building-preview.js` 从 `.tsb/.trb` 保存内容校验并解码 raw14，提供 `decodeBuilding`、`buildingChunk`、`buildingOverview`。它不访问游戏世界，不读取 History，也不把箱子物品/标牌正文带入预览。House 用它让服务器本地和后端存档共用同一条渲染路径；格式、大小和编码说明见 House README。

## 实时世界地图（2.1.1）

Base 独立提供地图生成能力，不依赖 History、GenerateMap 或审计数据库。图片来自游戏当前图格、墙、液体、涂色和深度背景，属于地图缩略图，不是客户端视角截屏。

- `GET /api/base/world/map`：创建当前地图任务，返回 `taskId`。
- `GET /api/base/world/map/task?taskId=...`：查询任务进度；完成后返回 `result = { mapId, world, width, height, map: { base64, width, height, started, finished } }`。外层宽高为世界图格尺寸，`map` 内宽高为图片像素尺寸，时间为 Unix 毫秒。
- 网页权限为独立模块 `base.world-map`，默认 admin、superadmin；按目标服务器鉴权。游戏服对应 `/data/base/world/map` 和 `/data/base/world/map/task`，沿用 Base 的 `data.rest.invsee` 令牌权限。
- 其他 Cordis 插件声明 `inject: ['worldMap']` 后，可以在已授权的路由调用 `ctx.worldMap.call(req)` 生成地图，或 `ctx.worldMap.call(req, taskId)` 轮询。调用方负责入口权限；该服务负责服务器选择、可信操作者身份、参数和上游响应校验。History 使用此服务，保留自身 `history.read` / `history.rollback` 网页授权，不要求用户额外获得玩家管理权限或 Base 地图模块。

Base 在游戏线程分段采样，图片宽度最多 1536 像素，每次 tick 调度采用 4ms 软预算，PNG 压缩在后台完成。采样横跨多个 tick，开始和结束时间随结果返回。专用服务器显式提供背景，无需创建 `Main.Map`。

不写磁盘、不保存历史地图快照。结果只为任务轮询暂存在内存，最多 8 个任务，5 分钟后回收；同时最多 2 个生成任务，每位操作者最多 1 个。任务绑定操作者和世界，换世界、卸载时清理；卸载后不接受后台晚到结果。

同一操作者在当前世界重复请求时，若已有排队或生成中的任务，返回同一个 taskId，让快速重进页面或多个标签页继续轮询；即使全服并发已满也可复用自己的任务。任务完成、失败、过期或世界切换后，再次请求会创建新任务，不复用已完成的地图。

History 页面负责“进入时获取一次，后续筛选只更新标记”的调用时机；Base 每次新建任务均采样当前世界，不缓存复用旧底图。

```powershell
dotnet build plugins/base/plugin/Base.csproj -c Release
Copy-Item plugins/base/plugin/bin/Release/net9.0/Base.dll plugins/base/plugin/Base.dll
node --test plugins/base/test/world-map.test.mjs
node scripts/check-access.mjs
```

通过现有插件哈希同步机制下发 `Base.dll`，不下发构建目录里的游戏框架依赖。

## 世界启动向导（2.3.0）
控制台在游戏尚未选择世界时显示 B 版三步向导：选择世界、连接设置、确认启动。世界启动后自动切换实时日志。世界控制完全属于 Base，初始化插件只负责建立连接。

- 默认目录在请求时通过目标游戏进程的 `Main.GetWorldPathFromName(..., false)` 读取，与 TShock 原生 `n` 新建世界的目录解析一致；不提前缓存，也不使用面板账户的文档目录猜测。接口显式返回 `defaultDirectory`，即使该目录为空也默认选中它。第二个选项是目标 TShock 程序目录下的 `world`，仅在手动选择时使用。
- 世界列表与输入都在游戏端 Base.dll 内执行，支持远程面板连接 Windows 游戏服，不要求用户再次选择 PID；不会重启游戏进程。
- `GET /api/base/worlds` 代理 `/data/base/worlds`，返回游戏会话、可选目录、实际准备状态和操作进度。
- `POST /api/base/world-start` 代理游戏端同名接口。必须携带当前游戏会话及幂等请求 ID；指定目录之外的路径、控制字符、无效参数与占用端口都会在发送输入前拒绝。
- 使用原生世界菜单生成/加载世界，确认菜单阶段后才写输入；生成完成后选择刚生成的文件，继续设置端口、人数和密码。不以“发送成功”当成“游戏已就绪”。
- 新建世界的文件名按游戏同一套规则预测：`Main.GetWorldPathFromName` 会把非法文件名字符换成 `-`、空格与点换成 `_`（`我的 世界` → `我的_世界.wld`）。存在性检查与生成轮询都基于这个预测名，名称含空格或句点也能正常进入下一步，不会停在“世界生成超时”。
- 面板侧请求 ID 统一走 `client/core/ids.js` 的 `randomId()`：`crypto.randomUUID` 只在 HTTPS / localhost 存在，局域网普通 HTTP 下退化为 `crypto.getRandomValues` 生成的 v4，缺安全随机数时明确报错而不降级。启动按钮的 ID 取值位于 `try` 内，异常不会把界面锁在“正在启动世界”。
- 9 种特殊世界标志与参考页面的 36 个秘密效果共用 `world-seeds.json`，采用游戏复制种子格式 `尺寸.难度.邪恶.标志.效果|基础种子`；搜索、分类、多选、手动编辑、复制均作用于最终请求。目标游戏不支持的别名禁用并解释。
- 启动参数应用到 Terraria 菜单和 TShock 内存设置（含清空密码），不改写其他配置。菜单控制目前要求 Windows 独立游戏控制台。

验证：`node --test plugins/base/test/world-start-ui.test.mjs`；实机检查 `node scripts/verify-world-start.mjs --allow-game-processes --tshock-dir <纯净目录> --release-dir <完整发行目录> --world <测试wld> [--create-world]`。测试使用独立副本与空闲端口，结束只清理自己启动的进程。

## 从市场更新 Base（2.3.1）

Base 随发行包自带、不可卸载，但**可以从插件市场更新**：`tsweb.publish: true` 让它可以上架，`src/plugin-gates.js` 的 `UPDATABLE_BUILTIN` 放开它的更新通道（`accounts`/`servers`/`web`/`data-items`/`data-projectiles` 仍然只能随发行包升级）。更新只替换 `plugins/base/` 目录并重算 version/packageHash/dlls，登记来源保持 `builtin`，因此卸载保护不变。

更新后的生效范围：面板半刷新页面后生效；游戏服上的 `Base.dll` 由宿主按哈希自动同步（`deploy: all`，接收端对声明了 `TsWeb.BeforeWorld` 的插件允许在世界运行中热替换）；接收端 `TsWebHost.dll` 不随插件更新提升，落后时按发行包升级。市场页对 base 使用单独的确认与结果横幅（见 `plugins/market/README.md`「市场自身与核心件的更新」）。
