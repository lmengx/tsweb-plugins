// Module permissions authorize both UI features and their backend routes.
export default {
  "owner": "base",
  "version": 2,
  "modules": [
    {
      "id": "base.players",
      "permission": "base.ui.players",
      "title": "玩家管理",
      "roles": [
        "superadmin",
        "admin",
        "subadmin"
      ],
      "scope": "server",
      "requires": [
        "base.get.base.players.list",
        "base.patch.base.players.username",
        "base.get.base.players.duplicateips",
        "base.get.base.players.allduplicateips",
        "base.get.base.players.bans",
        "base.get.base.players.kick",
        "base.get.base.players.ban",
        "base.get.base.players.unban",
        "base.get.base.players.clearcharacter",
        "base.get.base.players.password",
        "base.get.base.players.group",
        "base.get.base.players.groups",
        "base.post.base.players.command",
        "base.get.base.players.rename",
        "base.get.base.players.uuid",
        "base.get.base.players.delete",
        "base.get.base.players.export",
        "base.get.base.players.export.all",
        "base.get.base.players.export.list",
        "base.post.base.players.import",
        "base.get.base.players.import.from.server",
        "base.get.base.players.has.character",
        "base.get.base.ip.lookup",
        "base.get.base.players.username",
        "base.get.base.groups.list",
        "base.get.base.bans.list",
        "servers.get.servers.id.players"
      ]
    },
    {
      "id": "base.groups",
      "permission": "base.ui.groups",
      "title": "用户组",
      "roles": [
        "superadmin",
        "admin",
        "subadmin"
      ],
      "scope": "server",
      "requires": [
        "base.get.base.groups.list",
        "base.get.base.groups.read",
        "base.post.base.groups.create",
        "base.post.base.groups.update",
        "base.post.base.groups.delete",
        "base.post.base.groups.permission.add",
        "base.post.base.groups.permission.remove"
      ]
    },
    {
      "id": "base.bans",
      "permission": "base.ui.bans",
      "title": "封禁管理",
      "roles": [
        "superadmin",
        "admin",
        "subadmin"
      ],
      "scope": "server",
      "requires": [
        "base.get.base.bans.list",
        "base.get.base.players.unban"
      ]
    },
    {
      "id": "base.player-tools",
      "permission": "base.ui.player-tools",
      "title": "后端存档与预设",
      "roles": [
        "superadmin"
      ],
      "scope": "server",
      "requires": [
        "base.get.base.plr.list",
        "base.post.base.plr.save",
        "base.get.base.plr.file",
        "base.post.base.plr.delete",
        "base.get.base.presets.list",
        "base.post.base.presets.save",
        "base.get.base.presets.read",
        "base.post.base.presets.delete"
      ]
    },
    {
      "id": "base.terminal",
      "permission": "base.ui.terminal",
      "title": "控制台",
      "roles": [
        "superadmin",
        "admin",
        "subadmin"
      ],
      "scope": "server",
      "requires": [
        "servers.get.events",
        "servers.get.servers.id.console.history",
        "servers.get.servers.id.console.logs",
        "servers.post.servers.id.command",
        "servers.post.servers.id.broadcast"
      ]
    },
    {
      "id": "base.world-map",
      "permission": "base.world-map",
      "title": "实时世界地图",
      "roles": [
        "superadmin",
        "admin"
      ],
      "scope": "server",
      "requires": [
        "base.world-map.capture",
        "base.world-map.task"
      ]
    },
    {
      "id": "base.world-start",
      "permission": "base.ui.world-start",
      "title": "世界启动控制",
      "roles": ["superadmin", "admin"],
      "scope": "server",
      "requires": ["base.get.base.worlds", "base.post.base.world.start"]
    },
    {
      "id": "base.ssc",
      "permission": "base.settings.ssc",
      "title": "SSC 配置",
      "roles": [
        "superadmin",
        "admin"
      ],
      "scope": "server",
      "requires": [
        "base.ssc.read",
        "base.ssc.save"
      ]
    }
  ],
  "actions": [
    {
      "id": "base.get.base.worlds",
      "method": "GET",
      "path": "/api/base/worlds",
      "scope": "server",
      "module": "base.world-start"
    },
    {
      "id": "base.post.base.world.start",
      "method": "POST",
      "path": "/api/base/world-start",
      "scope": "server",
      "module": "base.world-start"
    },
    {
      "id": "base.get.base.players.list",
      "method": "GET",
      "path": "/api/base/players/list",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.patch.base.players.username",
      "method": "PATCH",
      "path": "/api/base/players/:username",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.duplicateips",
      "method": "GET",
      "path": "/api/base/players/duplicateips",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.allduplicateips",
      "method": "GET",
      "path": "/api/base/players/allduplicateips",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.bans",
      "method": "GET",
      "path": "/api/base/players/bans",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.bans.list",
      "method": "GET",
      "path": "/api/base/bans/list",
      "scope": "server",
      "module": "base.bans"
    },
    {
      "id": "base.get.base.players.kick",
      "method": "GET",
      "path": "/api/base/players/kick",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.ban",
      "method": "GET",
      "path": "/api/base/players/ban",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.unban",
      "method": "GET",
      "path": "/api/base/players/unban",
      "scope": "server",
      "module": "base.bans"
    },
    {
      "id": "base.get.base.players.clearcharacter",
      "method": "GET",
      "path": "/api/base/players/clearcharacter",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.password",
      "method": "GET",
      "path": "/api/base/players/password",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.group",
      "method": "GET",
      "path": "/api/base/players/group",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.groups",
      "method": "GET",
      "path": "/api/base/players/groups",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.post.base.players.command",
      "method": "POST",
      "path": "/api/base/players/command",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.rename",
      "method": "GET",
      "path": "/api/base/players/rename",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.uuid",
      "method": "GET",
      "path": "/api/base/players/uuid",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.delete",
      "method": "GET",
      "path": "/api/base/players/delete",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.export",
      "method": "GET",
      "path": "/api/base/players/export",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.export.all",
      "method": "GET",
      "path": "/api/base/players/export-all",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.export.list",
      "method": "GET",
      "path": "/api/base/players/export-list",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.post.base.players.import",
      "method": "POST",
      "path": "/api/base/players/import",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.import.from.server",
      "method": "GET",
      "path": "/api/base/players/import-from-server",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.has.character",
      "method": "GET",
      "path": "/api/base/players/has-character",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.plr.list",
      "method": "GET",
      "path": "/api/base/plr/list",
      "scope": "server",
      "module": "base.player-tools"
    },
    {
      "id": "base.post.base.plr.save",
      "method": "POST",
      "path": "/api/base/plr/save",
      "scope": "server",
      "module": "base.player-tools"
    },
    {
      "id": "base.get.base.plr.file",
      "method": "GET",
      "path": "/api/base/plr/file",
      "scope": "server",
      "module": "base.player-tools"
    },
    {
      "id": "base.post.base.plr.delete",
      "method": "POST",
      "path": "/api/base/plr/delete",
      "scope": "server",
      "module": "base.player-tools"
    },
    {
      "id": "base.get.base.presets.list",
      "method": "GET",
      "path": "/api/base/presets/list",
      "scope": "global",
      "module": "base.player-tools"
    },
    {
      "id": "base.post.base.presets.save",
      "method": "POST",
      "path": "/api/base/presets/save",
      "scope": "global",
      "module": "base.player-tools"
    },
    {
      "id": "base.get.base.presets.read",
      "method": "GET",
      "path": "/api/base/presets/read",
      "scope": "global",
      "module": "base.player-tools"
    },
    {
      "id": "base.post.base.presets.delete",
      "method": "POST",
      "path": "/api/base/presets/delete",
      "scope": "global",
      "module": "base.player-tools"
    },
    {
      "id": "base.get.base.ip.lookup",
      "method": "GET",
      "path": "/api/base/ip-lookup",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.players.username",
      "method": "GET",
      "path": "/api/base/players/:username",
      "scope": "server",
      "module": "base.players"
    },
    {
      "id": "base.get.base.groups.list",
      "method": "GET",
      "path": "/api/base/groups/list",
      "scope": "server",
      "module": "base.groups"
    },
    {
      "id": "base.get.base.groups.read",
      "method": "GET",
      "path": "/api/base/groups/read",
      "scope": "server",
      "module": "base.groups"
    },
    {
      "id": "base.post.base.groups.create",
      "method": "POST",
      "path": "/api/base/groups/create",
      "scope": "server",
      "module": "base.groups"
    },
    {
      "id": "base.post.base.groups.update",
      "method": "POST",
      "path": "/api/base/groups/update",
      "scope": "server",
      "module": "base.groups"
    },
    {
      "id": "base.post.base.groups.delete",
      "method": "POST",
      "path": "/api/base/groups/delete",
      "scope": "server",
      "module": "base.groups"
    },
    {
      "id": "base.post.base.groups.permission.add",
      "method": "POST",
      "path": "/api/base/groups/permission/add",
      "scope": "server",
      "module": "base.groups"
    },
    {
      "id": "base.post.base.groups.permission.remove",
      "method": "POST",
      "path": "/api/base/groups/permission/remove",
      "scope": "server",
      "module": "base.groups"
    },
    {
      "id": "base.world-map.capture",
      "method": "GET",
      "path": "/api/base/world/map",
      "scope": "server",
      "module": "base.world-map"
    },
    {
      "id": "base.world-map.task",
      "method": "GET",
      "path": "/api/base/world/map/task",
      "scope": "server",
      "module": "base.world-map"
    },
    {
      "id": "base.ssc.read",
      "module": "base.ssc",
      "method": "GET",
      "path": "/api/base/ssc",
      "scope": "server"
    },
    {
      "id": "base.ssc.save",
      "module": "base.ssc",
      "method": "POST",
      "path": "/api/base/ssc",
      "scope": "server"
    }
  ],
  "features": [
    {
      "id": "base:players",
      "module": "base.players",
      "requires": [
        "base.get.base.players.list",
        "base.patch.base.players.username",
        "base.get.base.players.duplicateips",
        "base.get.base.players.allduplicateips",
        "base.get.base.players.bans",
        "base.get.base.players.kick",
        "base.get.base.players.ban",
        "base.get.base.players.unban",
        "base.get.base.players.clearcharacter",
        "base.get.base.players.password",
        "base.get.base.players.group",
        "base.get.base.players.groups",
        "base.post.base.players.command",
        "base.get.base.players.rename",
        "base.get.base.players.uuid",
        "base.get.base.players.delete",
        "base.get.base.players.export",
        "base.get.base.players.export.all",
        "base.get.base.players.export.list",
        "base.post.base.players.import",
        "base.get.base.players.import.from.server",
        "base.get.base.players.has.character",
        "base.get.base.ip.lookup",
        "base.get.base.players.username",
        "base.get.base.groups.list",
        "base.get.base.bans.list",
        "servers.get.servers.id.players"
      ]
    },
    {
      "id": "base:player-detail",
      "module": "base.players",
      "requires": [
        "base.get.base.players.list",
        "base.patch.base.players.username",
        "base.get.base.players.duplicateips",
        "base.get.base.players.allduplicateips",
        "base.get.base.players.bans",
        "base.get.base.players.kick",
        "base.get.base.players.ban",
        "base.get.base.players.unban",
        "base.get.base.players.clearcharacter",
        "base.get.base.players.password",
        "base.get.base.players.group",
        "base.get.base.players.groups",
        "base.post.base.players.command",
        "base.get.base.players.rename",
        "base.get.base.players.uuid",
        "base.get.base.players.delete",
        "base.get.base.players.export",
        "base.get.base.players.export.all",
        "base.get.base.players.export.list",
        "base.post.base.players.import",
        "base.get.base.players.import.from.server",
        "base.get.base.players.has.character",
        "base.get.base.ip.lookup",
        "base.get.base.players.username",
        "base.get.base.groups.list",
        "base.get.base.bans.list",
        "servers.get.servers.id.players"
      ]
    },
    {
      "id": "base:groups",
      "module": "base.groups",
      "requires": [
        "base.get.base.groups.list",
        "base.get.base.groups.read",
        "base.post.base.groups.create",
        "base.post.base.groups.update",
        "base.post.base.groups.delete",
        "base.post.base.groups.permission.add",
        "base.post.base.groups.permission.remove"
      ]
    },
    {
      "id": "base:duplicateips",
      "module": "base.players",
      "requires": [
        "base.get.base.players.duplicateips",
        "base.get.base.players.allduplicateips"
      ]
    },
    {
      "id": "base:bans",
      "module": "base.bans",
      "requires": [
        "base.get.base.bans.list",
        "base.get.base.players.unban"
      ]
    },
    {
      "id": "base:player-tools",
      "module": "base.player-tools",
      "requires": [
        "base.get.base.plr.list",
        "base.post.base.plr.save",
        "base.get.base.plr.file",
        "base.post.base.plr.delete",
        "base.get.base.presets.list",
        "base.post.base.presets.save",
        "base.get.base.presets.read",
        "base.post.base.presets.delete"
      ]
    },
    {
      "id": "base:terminal",
      "module": "base.terminal",
      "requires": [
        "servers.get.events",
        "servers.get.servers.id.console.history",
        "servers.get.servers.id.console.logs",
        "servers.post.servers.id.command",
        "servers.post.servers.id.broadcast"
      ]
    },
    {
      "id": "base:world-map",
      "module": "base.world-map",
      "requires": [
        "base.world-map.capture",
        "base.world-map.task"
      ]
    }
  ]
}
