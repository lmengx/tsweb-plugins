import { createHmac } from 'node:crypto'

const fail = (status, message) => Object.assign(new Error(message), { status })

/** Shared by Base routes and authorized plugin routes; never trust browser owner IDs. */
export class WorldMapService {
  constructor(ctx) { this.ctx = ctx; this.disposed = false }
  async call(req, taskId, options = {}) {
    if (this.disposed) throw fail(503, 'Base 地图服务正在卸载')
    const serverId = req.headers['x-server-id'] || req.query?.serverId || req.user?.serverId || req.user?.extraServerIds?.[0]
    if (typeof serverId !== 'string' || !serverId) throw fail(400, '请先选择服务器')
    if (!req.user?.username) throw fail(401, '请重新登录')
    const server = this.ctx.servers.getRaw(serverId)
    if (!server) throw fail(404, '服务器不存在')
    if (taskId !== undefined && (typeof taskId !== 'string' || !/^[a-f0-9]{32}$/i.test(taskId))) throw fail(400, '地图任务编号无效')
    const chunk = options.tile || options.chunk
    if (chunk && (typeof chunk.mapId !== 'string' || !/^[a-f0-9]{32}$/i.test(chunk.mapId) ||
      !Number.isInteger(chunk.cx) || !Number.isInteger(chunk.cy) || chunk.cx < 0 || chunk.cy < 0 || chunk.cx > 1000 || chunk.cy > 1000))
      throw fail(400, '地图或区块坐标无效')
    if (options.tile && (!Number.isInteger(chunk.lod) || chunk.lod < 1 || chunk.lod > 64 || (chunk.lod & (chunk.lod - 1)))) throw fail(400, '地图精度无效')
    const owner = createHmac('sha256', server.token || server.pushSecret || 'base-local')
      .update(JSON.stringify(['base-world-map-v1', serverId, req.user.username.toLowerCase()])).digest('hex')
    let response
    try {
      const path = options.tile ? '/tile' : chunk ? '/chunk' : taskId === undefined ? '' : '/task'
      const parameters = chunk ? { mapId: chunk.mapId, cx: String(chunk.cx), cy: String(chunk.cy), ...(options.tile ? { lod: String(chunk.lod) } : {}) } : taskId === undefined
        ? { ...(options.stream ? { detail: 'stream' } : options.lazy ? { detail: 'lazy' } : options.detail ? { detail: '1' } : {}), ...(options.refresh ? { refresh: '1' } : {}) }
        : { taskId }
      response = await this.ctx.tshock.fetchFor(server, `/data/base/world/map${path}`, { owner, ...parameters }, { timeoutMs: 12000 })
    } catch (err) { throw fail(502, '连接游戏服失败：' + err.message) }
    if (this.disposed) throw fail(503, 'Base 地图服务正在卸载')
    const data = response.data, status = Number(data?.status || response.status)
    if (status === 401 || status === 403) throw fail(502, '游戏服令牌需要 data.rest.invsee 权限以调用 Base 地图服务')
    if (status === 404 && !data?.error) throw fail(501, '游戏服尚未启用新版 Base.dll，请检查插件同步状态')
    if (!response.ok || !data || status >= 400 || data.error) throw fail([400, 404, 409, 503].includes(status) ? status : 502, data?.error || 'Base 地图服务返回无效结果')
    return data
  }
}
